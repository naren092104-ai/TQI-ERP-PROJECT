import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FinanceView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { NewFinanceModal } from "/src/components/NewFinanceModal.tsx";
import Badge from "/src/components/ui/badge.tsx";
import {
  Car,
  Utensils,
  FileText,
  Receipt,
  Plus,
  Search,
  CheckCircle2,
  X,
  Edit3,
  Trash2,
  Eye,
  Send,
  FileSpreadsheet,
  ArrowRight
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "/src/components/ui/table.tsx";
export const FinanceView = ({
  financeEntries,
  panchayats,
  sessions,
  drafts = [],
  onNavigate,
  onAddFinanceEntry,
  onUpdateFinanceEntry,
  onDeleteFinanceEntry,
  onSaveDraft,
  onDeleteDraft,
  onSubmitDraft,
  isOpenNewModal = false,
  onCloseNewModal
}) => {
  _s();
  const [activeTabFilter, setActiveTabFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedPanchayat, setSelectedPanchayat] = useState("");
  const [showModal, setShowModal] = useState(isOpenNewModal);
  const [editingDraft, setEditingDraft] = useState(null);
  const [editingEntry, setEditingEntry] = useState(null);
  const [viewingReceipt, setViewingReceipt] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3e3);
  };
  const totalAdvance = 45e3;
  const totalExpenses = useMemo(() => {
    return financeEntries.filter((e) => e.status === "Approved").reduce((sum, e) => sum + e.amount, 0);
  }, [financeEntries]);
  const totalPending = useMemo(() => {
    return financeEntries.filter((e) => e.status === "Pending" || e.status === "Correction").reduce((sum, e) => sum + e.amount, 0);
  }, [financeEntries]);
  const totalDraftsAmount = useMemo(() => {
    const fromEntries = financeEntries.filter((e) => e.status === "Draft").reduce((sum, e) => sum + e.amount, 0);
    const fromDrafts = drafts.reduce((sum, d) => sum + d.totalAmount, 0);
    return Math.max(fromEntries, fromDrafts);
  }, [financeEntries, drafts]);
  const balance = totalAdvance - totalExpenses;
  const filteredEntries = useMemo(() => {
    return financeEntries.filter((e) => {
      const matchSearch = e.description.toLowerCase().includes(searchTerm.toLowerCase()) || e.remarks && e.remarks.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategory = !selectedCategory || e.category === selectedCategory;
      const matchPanchayat = !selectedPanchayat || e.panchayatId === selectedPanchayat || e.panchayatName.toLowerCase().includes(selectedPanchayat.toLowerCase());
      let matchStatus = true;
      if (activeTabFilter === "drafts") {
        matchStatus = e.status === "Draft";
      } else if (activeTabFilter === "approved") {
        matchStatus = e.status === "Approved";
      } else if (activeTabFilter === "pending") {
        matchStatus = e.status === "Pending" || e.status === "Correction";
      }
      return matchSearch && matchCategory && matchPanchayat && matchStatus;
    });
  }, [financeEntries, searchTerm, selectedCategory, selectedPanchayat, activeTabFilter]);
  const handleEditDraft = (draft) => {
    setEditingDraft(draft);
    setShowModal(true);
  };
  const handleSubmitDraftPackage = (draftId) => {
    if (onSubmitDraft) {
      onSubmitDraft(draftId);
    }
    financeEntries.forEach((e) => {
      if (e.draftId === draftId) {
        onUpdateFinanceEntry(e.id, { status: "Approved" });
      }
    });
    showToast("Draft submitted for approval successfully!");
  };
  const handleDeleteDraftPackage = (draftId) => {
    if (confirm("Are you sure you want to delete this formatted draft session?")) {
      if (onDeleteDraft) {
        onDeleteDraft(draftId);
      }
      financeEntries.forEach((e) => {
        if (e.draftId === draftId) {
          onDeleteFinanceEntry(e.id);
        }
      });
      showToast("Draft removed.");
    }
  };
  const getStatusBadge = (status) => {
    if (status === "Approved") return /* @__PURE__ */ jsxDEV(Badge, { color: "success", size: "sm", children: "Approved" }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 159,
      columnNumber: 39
    }, this);
    if (status === "Draft") return /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: "Draft" }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 160,
      columnNumber: 36
    }, this);
    return /* @__PURE__ */ jsxDEV(Badge, { color: "error", size: "sm", children: status }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 161,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-5 sm:space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-5 right-5 z-[200] rounded-xl bg-gray-900 px-4 py-2.5 text-xs font-semibold text-white shadow-theme-lg dark:bg-white dark:text-gray-900 flex items-center gap-2 animate-in fade-in-0 slide-in-from-bottom-5", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-success-500 shrink-0" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 169,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: toastMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 170,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setToastMessage(null), className: "ml-1 text-gray-400 hover:text-white dark:hover:text-gray-900", children: /* @__PURE__ */ jsxDEV(X, { className: "h-3 w-3" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 172,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 171,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3.5", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Finance & Expenses" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 181,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: "Dharmapuri Cluster" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 184,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 180,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs sm:text-sm text-gray-500 dark:text-gray-400", children: "Track cluster budgets, expense entries, bills, formatted drafts, and TQI statements." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 188,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 179,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 w-full sm:w-auto", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("finance-statement"),
            className: "flex-1 sm:flex-none inline-flex items-center justify-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(FileSpreadsheet, { className: "h-4 w-4 text-gray-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 199,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "TQI Statement" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 200,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 194,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setEditingDraft(null);
              setShowModal(true);
            },
            className: "flex-1 sm:flex-none inline-flex items-center justify-center gap-2 rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 210,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "New Expense Entry" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 211,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 202,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 193,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 178,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Advance" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xl sm:text-2xl font-bold font-mono text-gray-900 dark:text-white", children: [
          "₹",
          totalAdvance.toLocaleString()
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 220,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-gray-400 truncate", children: "Disbursed by State HQ" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 221,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 218,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase tracking-wider text-success-500", children: "Expenses Approved" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 225,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xl sm:text-2xl font-bold font-mono text-success-600 dark:text-success-400", children: [
          "₹",
          totalExpenses.toLocaleString()
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 226,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-success-500/80 truncate", children: "Verified with receipts" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 227,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 224,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase tracking-wider text-brand-500", children: "Remaining Balance" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 231,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xl sm:text-2xl font-bold font-mono text-brand-500", children: [
          "₹",
          balance.toLocaleString()
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 232,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-brand-500/80 truncate", children: "Cluster available fund" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 233,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 230,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase tracking-wider text-warning-500", children: "Saved Drafts" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 237,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-1.5 text-xl sm:text-2xl font-bold font-mono text-warning-600 dark:text-warning-400", children: [
          "₹",
          totalDraftsAmount.toLocaleString()
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 238,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-[11px] text-warning-500/80 truncate", children: [
          drafts.length,
          " formatted drafts"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 239,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 236,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 217,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-200 dark:border-gray-800 pb-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTabFilter("all"),
            className: `rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap ${activeTabFilter === "all" ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"}`,
            children: [
              "All Expenses (",
              financeEntries.length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 246,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTabFilter("drafts"),
            className: `rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap ${activeTabFilter === "drafts" ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"}`,
            children: [
              "Draft Sheets (",
              drafts.length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 257,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTabFilter("approved"),
            className: `rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap ${activeTabFilter === "approved" ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"}`,
            children: [
              "Approved (",
              financeEntries.filter((e) => e.status === "Approved").length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 268,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTabFilter("pending"),
            className: `rounded-xl px-3 py-1.5 text-xs font-semibold transition cursor-pointer whitespace-nowrap ${activeTabFilter === "pending" ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"}`,
            children: [
              "Pending (",
              financeEntries.filter((e) => e.status === "Pending" || e.status === "Correction").length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 279,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 245,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => onNavigate("finance-statement"),
          className: "text-xs font-bold text-brand-500 hover:text-brand-600 transition flex items-center gap-1 cursor-pointer self-end sm:self-auto",
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Statement Format" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 297,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 298,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 292,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 244,
      columnNumber: 7
    }, this),
    activeTabFilter === "drafts" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Saved Draft Sheets (Ready for TQI Formatting & Submission)" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 306,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setEditingDraft(null);
              setShowModal(true);
            },
            className: "rounded-xl bg-brand-500 px-3 py-1.5 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
            children: "+ New Draft Session"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 309,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 305,
        columnNumber: 11
      }, this),
      drafts.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-10 text-center text-gray-400 text-xs rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: "No saved drafts currently." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 322,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: drafts.map(
        (draft) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02] flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                      /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: [
                        draft.sessionDay,
                        " Draft"
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 336,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-mono", children: draft.sessionDate }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 339,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 335,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-900 dark:text-white", children: draft.title }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 341,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-0.5", children: [
                      "Cluster: ",
                      /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-700 dark:text-gray-300", children: draft.clusterName }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 343,
                        columnNumber: 36
                      }, this),
                      " · ",
                      draft.collegeName
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 342,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 334,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right shrink-0", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-base font-bold text-brand-500 block", children: [
                      "₹",
                      draft.totalAmount.toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 347,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-400", children: "Total Amount" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 350,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 346,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 333,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 pt-2 border-t border-gray-100 dark:border-gray-800 text-[11px] text-gray-500 dark:text-gray-400", children: [
                  draft.routes && draft.routes.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-gray-50/50 px-2 py-1 dark:border-gray-800 dark:bg-white/[0.02] font-medium", children: [
                    /* @__PURE__ */ jsxDEV(Car, { className: "w-3.5 h-3.5 text-brand-500" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 358,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      draft.routes.length,
                      " Travel Routes"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 359,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 357,
                    columnNumber: 17
                  }, this),
                  draft.food && /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-gray-50/50 px-2 py-1 dark:border-gray-800 dark:bg-white/[0.02] font-medium", children: [
                    /* @__PURE__ */ jsxDEV(Utensils, { className: "w-3.5 h-3.5 text-warning-500" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 364,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Food Logged" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 365,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 363,
                    columnNumber: 17
                  }, this),
                  draft.stationery && draft.stationery.amount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-gray-50/50 px-2 py-1 dark:border-gray-800 dark:bg-white/[0.02] font-medium", children: [
                    /* @__PURE__ */ jsxDEV(FileText, { className: "w-3.5 h-3.5 text-success-500" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 370,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Stationery (₹",
                      draft.stationery.amount,
                      ")"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 371,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 369,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 355,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 332,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pt-3.5 mt-3.5 border-t border-gray-100 dark:border-gray-800 flex flex-wrap items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => onNavigate("finance-statement", draft.id),
                    className: "rounded-xl border border-brand-200 bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-600 hover:bg-brand-100 dark:border-brand-900/40 dark:bg-brand-500/10 dark:text-brand-400 transition cursor-pointer",
                    children: "Statement Sheet"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 379,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleEditDraft(draft),
                      className: "rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                      children: "Edit"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 388,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleSubmitDraftPackage(draft.id),
                      className: "rounded-xl bg-success-500 px-3 py-1.5 text-xs font-semibold text-white shadow-theme-xs hover:bg-success-600 transition cursor-pointer",
                      children: "Submit"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 395,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleDeleteDraftPackage(draft.id),
                      className: "rounded-lg p-1.5 text-gray-400 hover:bg-error-50 hover:text-error-600 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition cursor-pointer",
                      title: "Delete Draft",
                      children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 408,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 402,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 387,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 378,
                columnNumber: 19
              }, this)
            ]
          },
          draft.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 328,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 326,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 304,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative flex-1", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 422,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search expenses by description, route, or remarks...",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-xs text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 423,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 421,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:flex sm:items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:w-40", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedCategory || "all",
            onValueChange: (val) => setSelectedCategory(val === "all" ? "" : val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Categories" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 439,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 438,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Categories" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 442,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Travel", children: "Travel" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 443,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Food", children: "Food" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 444,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Materials", children: "Materials / Stationery" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 445,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Admin", children: "Admin" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 446,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Other", children: "Other" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 447,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 441,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 434,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 433,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:w-40", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedPanchayat || "all",
            onValueChange: (val) => setSelectedPanchayat(val === "all" ? "" : val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Panchayats" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 458,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 457,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Panchayats" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 461,
                  columnNumber: 17
                }, this),
                panchayats.map(
                  (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 463,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 460,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 453,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 452,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 432,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 420,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "block md:hidden space-y-3", children: filteredEntries.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-10 text-center text-gray-400 text-xs rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: "No expense entries matching current criteria." }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 476,
      columnNumber: 9
    }, this) : filteredEntries.map(
      (entry) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "p-4 rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02] space-y-2.5",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold font-mono text-gray-500 dark:text-gray-400", children: entry.date }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 488,
                    columnNumber: 21
                  }, this),
                  entry.sessionDay && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold bg-gray-100 dark:bg-white/5 px-1.5 py-0.5 rounded text-gray-600 dark:text-gray-300", children: entry.sessionDay }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 490,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: entry.category }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 494,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 487,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white leading-snug", children: entry.description }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 496,
                  columnNumber: 19
                }, this),
                entry.remarks && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400 mt-0.5", children: entry.remarks }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 498,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 486,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right shrink-0", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-sm font-bold text-brand-500 block", children: [
                  "₹",
                  entry.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 503,
                  columnNumber: 19
                }, this),
                getStatusBadge(entry.status)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 502,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 485,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-2 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 dark:text-gray-400 truncate max-w-[150px]", children: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 dark:text-gray-300", children: entry.panchayatName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 512,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 511,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                entry.billUrl ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setViewingReceipt(entry),
                    className: "px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400 text-[11px] font-semibold flex items-center gap-1 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV(Receipt, { className: "h-3.5 w-3.5" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 522,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Bill" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 523,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 517,
                    columnNumber: 15
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV("span", { className: "text-[10.5px] text-error-500 font-semibold px-1.5 py-0.5 bg-error-50 dark:bg-error-500/10 rounded", children: "No Bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 526,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setEditingEntry(entry),
                    className: "p-1 text-gray-500 hover:text-brand-500 rounded-lg hover:bg-gray-100 dark:hover:bg-white/5 cursor-pointer",
                    title: "Edit",
                    children: /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 537,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 531,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      if (confirm(`Delete expense "${entry.description}"?`)) {
                        onDeleteFinanceEntry(entry.id);
                        showToast("Finance entry deleted");
                      }
                    },
                    className: "p-1 text-gray-400 hover:text-error-600 rounded-lg hover:bg-error-50 dark:hover:bg-error-500/10 cursor-pointer",
                    title: "Delete",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 551,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 540,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 515,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 510,
              columnNumber: 15
            }, this)
          ]
        },
        entry.id,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 481,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 474,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "hidden md:block overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Date / Session" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 565,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Category" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 566,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "w-[300px]", children: "Description & Route" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 567,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Panchayat" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 568,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Amount" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 569,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Bill Attachment" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 570,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 571,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 572,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 564,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 563,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: filteredEntries.length === 0 ? /* @__PURE__ */ jsxDEV(TableRow, { children: /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 8, className: "py-12 text-center text-gray-400", children: "No expense entries matching current criteria." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 578,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 577,
        columnNumber: 13
      }, this) : filteredEntries.map(
        (entry) => /* @__PURE__ */ jsxDEV(TableRow, { className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors", children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "whitespace-nowrap", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white block text-xs", children: entry.date }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 586,
              columnNumber: 21
            }, this),
            entry.sessionDay && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-400", children: entry.sessionDay }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 588,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 585,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: entry.category }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 594,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 593,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white block text-xs", children: entry.description }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 599,
              columnNumber: 21
            }, this),
            entry.remarks && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 block", children: entry.remarks }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 601,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 598,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-700 dark:text-gray-300 text-xs", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: entry.panchayatName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 605,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block text-[11px] text-gray-400", children: entry.villageName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 606,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 604,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "font-bold font-mono text-gray-900 dark:text-white text-xs whitespace-nowrap", children: [
            "₹",
            entry.amount.toLocaleString()
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 608,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: entry.billUrl ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setViewingReceipt(entry),
              className: "text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer",
              children: [
                /* @__PURE__ */ jsxDEV(Receipt, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 618,
                  columnNumber: 25
                }, this),
                "View Bill"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 613,
              columnNumber: 17
            },
            this
          ) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-error-500 font-semibold flex items-center gap-1", children: "Missing" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 622,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 611,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: getStatusBadge(entry.status) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 627,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onNavigate("finance-statement", entry.draftId || entry.sessionDay || "all-approved"),
                className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                title: "View Statement Sheet",
                children: /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 640,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 632,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setEditingEntry(entry),
                className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                title: "Edit Entry",
                children: /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 648,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 642,
                columnNumber: 23
              },
              this
            ),
            entry.status !== "Approved" && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  onUpdateFinanceEntry(entry.id, { status: "Pending" });
                  showToast("Entry submitted for review!");
                },
                className: "rounded-lg p-1.5 text-gray-400 hover:bg-success-50 hover:text-success-600 dark:hover:bg-success-500/10 dark:hover:text-success-400 transition cursor-pointer",
                title: "Submit for Review",
                children: /* @__PURE__ */ jsxDEV(Send, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 660,
                  columnNumber: 27
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 651,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (confirm(`Delete finance entry "${entry.description}"?`)) {
                    onDeleteFinanceEntry(entry.id);
                    showToast("Finance entry deleted");
                  }
                },
                className: "rounded-lg p-1.5 text-gray-400 hover:bg-error-50 hover:text-error-600 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition cursor-pointer",
                title: "Delete",
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                  lineNumber: 674,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 663,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 631,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 630,
            columnNumber: 19
          }, this)
        ] }, entry.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 584,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 575,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 562,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 561,
      columnNumber: 7
    }, this),
    viewingReceipt && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-3 sm:p-4 animate-in fade-in-0", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-900 rounded-2xl shadow-theme-xl max-w-lg w-full overflow-hidden border border-gray-200 dark:border-gray-800 animate-in zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-50 dark:bg-white/[0.02] border-b border-gray-100 dark:border-gray-800 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: viewingReceipt.description }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 691,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400", children: [
            viewingReceipt.category,
            " • ₹",
            viewingReceipt.amount
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 692,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 690,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setViewingReceipt(null),
            className: "p-1 text-gray-400 hover:text-gray-700 dark:hover:text-white rounded-lg cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 700,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 696,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 689,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-gray-950 flex justify-center", children: /* @__PURE__ */ jsxDEV(
        "img",
        {
          src: viewingReceipt.billUrl,
          alt: "Receipt",
          className: "max-h-[60vh] object-contain rounded-xl",
          referrerPolicy: "no-referrer"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 704,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 703,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 dark:text-gray-400 truncate max-w-[200px]", children: viewingReceipt.remarks || "Receipt document attached" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 712,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setViewingReceipt(null),
            className: "px-4 py-2 bg-brand-500 text-white font-semibold text-xs rounded-xl shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
            children: "Done"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 715,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 711,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 688,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 687,
      columnNumber: 7
    }, this),
    editingEntry && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-3 sm:p-4 animate-in fade-in-0", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-900 rounded-2xl max-w-md w-full overflow-hidden shadow-theme-xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 space-y-4 animate-in zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4 text-brand-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 732,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Edit Finance Entry" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 733,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 731,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setEditingEntry(null),
            className: "p-1 text-gray-400 hover:text-gray-700 dark:hover:text-white rounded-lg cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 739,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 735,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 730,
        columnNumber: 13
      }, this),
      sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved" ? /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-xl p-3 flex items-center gap-2 text-sm text-gray-700", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 text-success-500" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 745,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "This finance entry belongs to a submitted session and cannot be edited." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 746,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 744,
        columnNumber: 11
      }, this) : null,
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Description / Route" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 751,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: editingEntry.description,
              onChange: (e) => setEditingEntry({ ...editingEntry, description: e.target.value }),
              disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
              className: "w-full h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500 disabled:opacity-50"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 752,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 750,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Session / Day" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 763,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: editingEntry.sessionId || "none",
                onValueChange: (val) => setEditingEntry({ ...editingEntry, sessionId: val === "none" ? void 0 : val }),
                disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs disabled:opacity-50", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Session" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 770,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 769,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "none", children: "No Session" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 773,
                      columnNumber: 23
                    }, this),
                    sessions?.map(
                      (s) => /* @__PURE__ */ jsxDEV(SelectItem, { value: s.id, children: [
                        "Day ",
                        s.dayNumber,
                        " (",
                        s.name,
                        ")"
                      ] }, s.id, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                        lineNumber: 775,
                        columnNumber: 21
                      }, this)
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 772,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 764,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 762,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Category" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 783,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: editingEntry.category,
                onValueChange: (val) => setEditingEntry({ ...editingEntry, category: val }),
                disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs disabled:opacity-50", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Category" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 790,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 789,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Travel", children: "Travel" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 793,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Food", children: "Food" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 794,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Materials", children: "Materials" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 795,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Admin", children: "Admin" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 796,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Other", children: "Other" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                      lineNumber: 797,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                    lineNumber: 792,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 784,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 782,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 761,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Amount (₹)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 805,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                value: editingEntry.amount,
                onChange: (e) => setEditingEntry({
                  ...editingEntry,
                  amount: parseFloat(e.target.value) || 0
                }),
                disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
                className: "w-full h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs font-bold text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500 disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 806,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 804,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Remarks" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
              lineNumber: 822,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: editingEntry.remarks || "",
                onChange: (e) => setEditingEntry({ ...editingEntry, remarks: e.target.value }),
                disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
                className: "w-full h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500 disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
                lineNumber: 823,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 821,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
          lineNumber: 803,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 749,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setEditingEntry(null),
            className: "px-4 py-2 border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 rounded-xl text-xs font-semibold dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer shadow-theme-xs",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 835,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              onUpdateFinanceEntry(editingEntry.id, {
                description: editingEntry.description,
                category: editingEntry.category,
                amount: editingEntry.amount,
                remarks: editingEntry.remarks,
                sessionId: editingEntry.sessionId
              });
              setEditingEntry(null);
              showToast("Finance entry updated");
            },
            disabled: sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Submitted" || sessions?.find((s) => s.id === editingEntry.sessionId)?.status === "Approved",
            className: "px-4 py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold hover:bg-brand-600 transition cursor-pointer shadow-theme-xs disabled:opacity-50",
            children: "Save"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
            lineNumber: 841,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 834,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 729,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
      lineNumber: 728,
      columnNumber: 7
    }, this),
    showModal && /* @__PURE__ */ jsxDEV(
      NewFinanceModal,
      {
        isOpen: showModal,
        initialDraft: editingDraft,
        onClose: () => {
          setShowModal(false);
          setEditingDraft(null);
          if (onCloseNewModal) onCloseNewModal();
        },
        clusterName: "Dharmapuri",
        collegeName: "K.S.Rangasamy college of Technology",
        spocName: "Narendhar",
        financerName: "TQI Finance Team",
        onSaveDraftPackage: (draftPkg) => {
          if (onSaveDraft) {
            onSaveDraft(draftPkg);
          }
          showToast(`Draft sheet "${draftPkg.sessionDay}" saved in TQI format!`);
        },
        onSubmitFinance: (entries, isDraft) => {
          entries.forEach((entry) => onAddFinanceEntry(entry));
          showToast(isDraft ? "Draft entries saved!" : "Finance entries submitted for approval!");
        }
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
        lineNumber: 865,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx",
    lineNumber: 165,
    columnNumber: 5
  }, this);
};
_s(FinanceView, "ORl51chtzt/LQDMIsNZhr9z1UdM=");
_c = FinanceView;
var _c;
$RefreshReg$(_c, "FinanceView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEpzQzs7QUE5SnRDLFNBQWdCQSxVQUFVQyxlQUFlO0FBRXpDLFNBQVNDLHVCQUF1QjtBQUNoQyxPQUFPQyxXQUFXO0FBQ2xCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFFQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLE9BQU9DLGFBQWFDLFdBQVdDLFVBQVVDLGlCQUFpQjtBQWtCNUQsYUFBTUMsY0FBMENBLENBQUM7QUFBQSxFQUN0REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsU0FBUztBQUFBLEVBQ1RDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGlCQUFpQjtBQUFBLEVBQ2pCQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTVDLFNBQW9ELEtBQUs7QUFDdkcsUUFBTSxDQUFDNkMsWUFBWUMsYUFBYSxJQUFJOUMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQytDLGtCQUFrQkMsbUJBQW1CLElBQUloRCxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDaUQsbUJBQW1CQyxvQkFBb0IsSUFBSWxELFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNtRCxXQUFXQyxZQUFZLElBQUlwRCxTQUFTd0MsY0FBYztBQUN6RCxRQUFNLENBQUNhLGNBQWNDLGVBQWUsSUFBSXRELFNBQThCLElBQUk7QUFDMUUsUUFBTSxDQUFDdUQsY0FBY0MsZUFBZSxJQUFJeEQsU0FBOEIsSUFBSTtBQUMxRSxRQUFNLENBQUN5RCxnQkFBZ0JDLGlCQUFpQixJQUFJMUQsU0FBOEIsSUFBSTtBQUM5RSxRQUFNLENBQUMyRCxjQUFjQyxlQUFlLElBQUk1RCxTQUF3QixJQUFJO0FBRXBFLFFBQU02RCxZQUFZQSxDQUFDQyxRQUFnQjtBQUNqQ0Ysb0JBQWdCRSxHQUFHO0FBQ25CQyxlQUFXLE1BQU1ILGdCQUFnQixJQUFJLEdBQUcsR0FBSTtBQUFBLEVBQzlDO0FBRUEsUUFBTUksZUFBZTtBQUVyQixRQUFNQyxnQkFBZ0JoRSxRQUFRLE1BQU07QUFDbEMsV0FBTzRCLGVBQ0pxQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsVUFBVSxFQUNyQ0MsT0FBTyxDQUFDQyxLQUFLSCxNQUFNRyxNQUFNSCxFQUFFSSxRQUFRLENBQUM7QUFBQSxFQUN6QyxHQUFHLENBQUMxQyxjQUFjLENBQUM7QUFFbkIsUUFBTTJDLGVBQWV2RSxRQUFRLE1BQU07QUFDakMsV0FBTzRCLGVBQ0pxQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsYUFBYUQsRUFBRUMsV0FBVyxZQUFZLEVBQ2pFQyxPQUFPLENBQUNDLEtBQUtILE1BQU1HLE1BQU1ILEVBQUVJLFFBQVEsQ0FBQztBQUFBLEVBQ3pDLEdBQUcsQ0FBQzFDLGNBQWMsQ0FBQztBQUVuQixRQUFNNEMsb0JBQW9CeEUsUUFBUSxNQUFNO0FBQ3RDLFVBQU15RSxjQUFjN0MsZUFDakJxQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsT0FBTyxFQUNsQ0MsT0FBTyxDQUFDQyxLQUFLSCxNQUFNRyxNQUFNSCxFQUFFSSxRQUFRLENBQUM7QUFDdkMsVUFBTUksYUFBYTNDLE9BQU9xQyxPQUFPLENBQUNDLEtBQUtNLE1BQU1OLE1BQU1NLEVBQUVDLGFBQWEsQ0FBQztBQUNuRSxXQUFPQyxLQUFLQyxJQUFJTCxhQUFhQyxVQUFVO0FBQUEsRUFDekMsR0FBRyxDQUFDOUMsZ0JBQWdCRyxNQUFNLENBQUM7QUFFM0IsUUFBTWdELFVBQVVoQixlQUFlQztBQUcvQixRQUFNZ0Isa0JBQWtCaEYsUUFBUSxNQUFNO0FBQ3BDLFdBQU80QixlQUFlcUMsT0FBTyxDQUFDQyxNQUFNO0FBQ2xDLFlBQU1lLGNBQ0pmLEVBQUVnQixZQUFZQyxZQUFZLEVBQUVDLFNBQVN4QyxXQUFXdUMsWUFBWSxDQUFDLEtBQzVEakIsRUFBRW1CLFdBQVduQixFQUFFbUIsUUFBUUYsWUFBWSxFQUFFQyxTQUFTeEMsV0FBV3VDLFlBQVksQ0FBQztBQUV6RSxZQUFNRyxnQkFBZ0IsQ0FBQ3hDLG9CQUFvQm9CLEVBQUVxQixhQUFhekM7QUFDMUQsWUFBTTBDLGlCQUNKLENBQUN4QyxxQkFDRGtCLEVBQUV1QixnQkFBZ0J6QyxxQkFDbEJrQixFQUFFd0IsY0FBY1AsWUFBWSxFQUFFQyxTQUFTcEMsa0JBQWtCbUMsWUFBWSxDQUFDO0FBRXhFLFVBQUlRLGNBQWM7QUFDbEIsVUFBSWpELG9CQUFvQixVQUFVO0FBQ2hDaUQsc0JBQWN6QixFQUFFQyxXQUFXO0FBQUEsTUFDN0IsV0FBV3pCLG9CQUFvQixZQUFZO0FBQ3pDaUQsc0JBQWN6QixFQUFFQyxXQUFXO0FBQUEsTUFDN0IsV0FBV3pCLG9CQUFvQixXQUFXO0FBQ3hDaUQsc0JBQWN6QixFQUFFQyxXQUFXLGFBQWFELEVBQUVDLFdBQVc7QUFBQSxNQUN2RDtBQUVBLGFBQU9jLGVBQWVLLGlCQUFpQkUsa0JBQWtCRztBQUFBQSxJQUMzRCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUMvRCxnQkFBZ0JnQixZQUFZRSxrQkFBa0JFLG1CQUFtQk4sZUFBZSxDQUFDO0FBRXJGLFFBQU1rRCxrQkFBa0JBLENBQUNDLFVBQXdCO0FBQy9DeEMsb0JBQWdCd0MsS0FBSztBQUNyQjFDLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFFBQU0yQywyQkFBMkJBLENBQUNDLFlBQW9CO0FBQ3BELFFBQUl6RCxlQUFlO0FBQ2pCQSxvQkFBY3lELE9BQU87QUFBQSxJQUN2QjtBQUNBbkUsbUJBQWVvRSxRQUFRLENBQUM5QixNQUFNO0FBQzVCLFVBQUlBLEVBQUU2QixZQUFZQSxTQUFTO0FBQ3pCN0QsNkJBQXFCZ0MsRUFBRStCLElBQUksRUFBRTlCLFFBQVEsV0FBVyxDQUFDO0FBQUEsTUFDbkQ7QUFBQSxJQUNGLENBQUM7QUFDRFAsY0FBVSw0Q0FBNEM7QUFBQSxFQUN4RDtBQUVBLFFBQU1zQywyQkFBMkJBLENBQUNILFlBQW9CO0FBQ3BELFFBQUlJLFFBQVEsK0RBQStELEdBQUc7QUFDNUUsVUFBSTlELGVBQWU7QUFDakJBLHNCQUFjMEQsT0FBTztBQUFBLE1BQ3ZCO0FBQ0FuRSxxQkFBZW9FLFFBQVEsQ0FBQzlCLE1BQU07QUFDNUIsWUFBSUEsRUFBRTZCLFlBQVlBLFNBQVM7QUFDekI1RCwrQkFBcUIrQixFQUFFK0IsRUFBRTtBQUFBLFFBQzNCO0FBQUEsTUFDRixDQUFDO0FBQ0RyQyxnQkFBVSxnQkFBZ0I7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0MsaUJBQWlCQSxDQUFDakMsV0FBbUI7QUFDekMsUUFBSUEsV0FBVyxXQUFZLFFBQU8sdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUFLLHdCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQzNFLFFBQUlBLFdBQVcsUUFBUyxRQUFPLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBSyxxQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQztBQUNyRSxXQUFPLHVCQUFDLFNBQU0sT0FBTSxTQUFRLE1BQUssTUFBTUEsb0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUM7QUFBQSxFQUNoRDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlDQUVaVDtBQUFBQSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsMk5BQ2I7QUFBQSw2QkFBQyxnQkFBYSxXQUFVLHVDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsVUFBTUEsMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLE1BQ3BCLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUMsZ0JBQWdCLElBQUksR0FBRyxXQUFVLGdFQUNwRSxpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDhFQUE0RSxrQ0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUFJLGtDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw0REFBMEQsb0dBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNM0IsV0FBVyxtQkFBbUI7QUFBQSxZQUM3QyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLG1CQUFnQixXQUFVLDJCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQ2xELHVCQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQTtBQUFBO0FBQUEsVUFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU07QUFDYnFCLDhCQUFnQixJQUFJO0FBQ3BCRiwyQkFBYSxJQUFJO0FBQUEsWUFDbkI7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsY0FDekIsdUJBQUMsVUFBSyxpQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBO0FBQUE7QUFBQSxVQVR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0NBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUZBQXNGLDZCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtIO0FBQUEsUUFDbEgsdUJBQUMsU0FBSSxXQUFVLGdGQUErRTtBQUFBO0FBQUEsVUFBRVksYUFBYXNDLGVBQWU7QUFBQSxhQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsUUFDOUgsdUJBQUMsT0FBRSxXQUFVLDZDQUE0QyxxQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFdBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG9IQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVFQUFzRSxpQ0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFFBQ3RHLHVCQUFDLFNBQUksV0FBVSx5RkFBd0Y7QUFBQTtBQUFBLFVBQUVyQyxjQUFjcUMsZUFBZTtBQUFBLGFBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0k7QUFBQSxRQUN4SSx1QkFBQyxPQUFFLFdBQVUsbURBQWtELHNDQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsV0FIdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUVBQW9FLGlDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsUUFDcEcsdUJBQUMsU0FBSSxXQUFVLGlFQUFnRTtBQUFBO0FBQUEsVUFBRXRCLFFBQVFzQixlQUFlO0FBQUEsYUFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFFBQzFHLHVCQUFDLE9BQUUsV0FBVSxpREFBZ0Qsc0NBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxXQUhyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1RUFBc0UsNEJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxRQUNqRyx1QkFBQyxTQUFJLFdBQVUseUZBQXdGO0FBQUE7QUFBQSxVQUFFN0Isa0JBQWtCNkIsZUFBZTtBQUFBLGFBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEk7QUFBQSxRQUM1SSx1QkFBQyxPQUFFLFdBQVUsbURBQW1EdEU7QUFBQUEsaUJBQU91RTtBQUFBQSxVQUFPO0FBQUEsYUFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRjtBQUFBLFdBSGpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxzSEFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0zRCxtQkFBbUIsS0FBSztBQUFBLFlBQ3ZDLFdBQVcsNEZBQ1RELG9CQUFvQixRQUNoQiw0Q0FDQSx5SEFBeUg7QUFBQSxZQUM1SDtBQUFBO0FBQUEsY0FFWWQsZUFBZTBFO0FBQUFBLGNBQU87QUFBQTtBQUFBO0FBQUEsVUFUdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0zRCxtQkFBbUIsUUFBUTtBQUFBLFlBQzFDLFdBQVcsNEZBQ1RELG9CQUFvQixXQUNoQiw0Q0FDQSx5SEFBeUg7QUFBQSxZQUM1SDtBQUFBO0FBQUEsY0FFWVgsT0FBT3VFO0FBQUFBLGNBQU87QUFBQTtBQUFBO0FBQUEsVUFUL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0zRCxtQkFBbUIsVUFBVTtBQUFBLFlBQzVDLFdBQVcsNEZBQ1RELG9CQUFvQixhQUNoQiw0Q0FDQSx5SEFBeUg7QUFBQSxZQUM1SDtBQUFBO0FBQUEsY0FFUWQsZUFBZXFDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsV0FBVyxVQUFVLEVBQUVtQztBQUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBLFVBVDFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNM0QsbUJBQW1CLFNBQVM7QUFBQSxZQUMzQyxXQUFXLDRGQUNURCxvQkFBb0IsWUFDaEIsNENBQ0EseUhBQXlIO0FBQUEsWUFDNUg7QUFBQTtBQUFBLGNBRU9kLGVBQWVxQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLFdBQVcsYUFBYUQsRUFBRUMsV0FBVyxZQUFZLEVBQUVtQztBQUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBLFVBVHJHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsV0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTXRFLFdBQVcsbUJBQW1CO0FBQUEsVUFDN0MsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxVQUFLLGdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsWUFDdEIsdUJBQUMsY0FBVyxXQUFVLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBO0FBQUE7QUFBQSxRQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3REE7QUFBQSxJQUdDVSxvQkFBb0IsWUFDbkIsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsbURBQWlELDBFQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU07QUFDYlcsOEJBQWdCLElBQUk7QUFDcEJGLDJCQUFhLElBQUk7QUFBQSxZQUNuQjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQW1JO0FBQUE7QUFBQSxVQU4vSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFTQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQ3BCLE9BQU91RSxXQUFXLElBQ2pCLHVCQUFDLFNBQUksV0FBVSxnSkFBOEksMENBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWnZFLGlCQUFPd0U7QUFBQUEsUUFBSSxDQUFDVixVQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLDZDQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFDekJBO0FBQUFBLDhCQUFNVztBQUFBQSx3QkFBVztBQUFBLDJCQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q1gsZ0JBQU1ZLGVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlFO0FBQUEseUJBSjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsbURBQW1EWixnQkFBTWEsU0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkU7QUFBQSxvQkFDN0UsdUJBQUMsT0FBRSxXQUFVLGdDQUE4QjtBQUFBO0FBQUEsc0JBQ2hDLHVCQUFDLFVBQUssV0FBVSxrREFBa0RiLGdCQUFNYyxlQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvRjtBQUFBLHNCQUFPO0FBQUEsc0JBQVdkLE1BQU1lO0FBQUFBLHlCQUR2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxzREFBb0Q7QUFBQTtBQUFBLHNCQUNoRWYsTUFBTWpCLFlBQVl5QixlQUFlO0FBQUEseUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RDtBQUFBLHVCQUoxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLHdIQUNaUjtBQUFBQSx3QkFBTWdCLFVBQVVoQixNQUFNZ0IsT0FBT1AsU0FBUyxLQUNyQyx1QkFBQyxVQUFLLFdBQVUsb0pBQ2Q7QUFBQSwyQ0FBQyxPQUFJLFdBQVUsZ0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsVUFBTVQ7QUFBQUEsNEJBQU1nQixPQUFPUDtBQUFBQSxzQkFBTztBQUFBLHlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QztBQUFBLHVCQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBRURULE1BQU1pQixRQUNMLHVCQUFDLFVBQUssV0FBVSxvSkFDZDtBQUFBLDJDQUFDLFlBQVMsV0FBVSxrQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Q7QUFBQSxvQkFDbEQsdUJBQUMsVUFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQjtBQUFBLHVCQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBRURqQixNQUFNa0IsY0FBY2xCLE1BQU1rQixXQUFXekMsU0FBUyxLQUM3Qyx1QkFBQyxVQUFLLFdBQVUsb0pBQ2Q7QUFBQSwyQ0FBQyxZQUFTLFdBQVUsa0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtEO0FBQUEsb0JBQ2xELHVCQUFDLFVBQUs7QUFBQTtBQUFBLHNCQUFjdUIsTUFBTWtCLFdBQVd6QztBQUFBQSxzQkFBTztBQUFBLHlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QztBQUFBLHVCQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsbUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkNBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsaUhBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNdEMsV0FBVyxxQkFBcUI2RCxNQUFNSSxFQUFFO0FBQUEsb0JBQ3ZELFdBQVU7QUFBQSxvQkFBZ047QUFBQTtBQUFBLGtCQUg1TjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNTCxnQkFBZ0JDLEtBQUs7QUFBQSxzQkFDcEMsV0FBVTtBQUFBLHNCQUFnTjtBQUFBO0FBQUEsb0JBSDVOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLE1BQU1DLHlCQUF5QkQsTUFBTUksRUFBRTtBQUFBLHNCQUNoRCxXQUFVO0FBQUEsc0JBQXVJO0FBQUE7QUFBQSxvQkFIbko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTUMseUJBQXlCTCxNQUFNSSxFQUFFO0FBQUEsc0JBQ2hELFdBQVU7QUFBQSxzQkFDVixPQUFNO0FBQUEsc0JBRU4saUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJCO0FBQUE7QUFBQSxvQkFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEscUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUJBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUE7QUFBQTtBQUFBLFVBbEZLSixNQUFNSTtBQUFBQSxVQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvRkE7QUFBQSxNQUNELEtBdkZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RkE7QUFBQSxTQTlHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0hBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsMEZBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxRQUN4RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT3JEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDc0IsTUFBTXJCLGNBQWNxQixFQUFFOEMsT0FBT0MsS0FBSztBQUFBLFlBQzdDLFdBQVU7QUFBQTtBQUFBLFVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSytPO0FBQUEsV0FQalA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9uRSxvQkFBb0I7QUFBQSxZQUMzQixlQUFlLENBQUNvRSxRQUFRbkUsb0JBQW9CbUUsUUFBUSxRQUFRLEtBQUtBLEdBQUc7QUFBQSxZQUVwRTtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDQztBQUFBLHVDQUFDLGNBQVcsT0FBTSxPQUFNLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUN0Qyx1QkFBQyxjQUFXLE9BQU0sVUFBUyxzQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDakMsdUJBQUMsY0FBVyxPQUFNLFFBQU8sb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQzdCLHVCQUFDLGNBQVcsT0FBTSxhQUFZLHNDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxjQUFXLE9BQU0sU0FBUSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQSxnQkFDL0IsdUJBQUMsY0FBVyxPQUFNLFNBQVEscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUEsbUJBTmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQTtBQUFBO0FBQUEsVUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9sRSxxQkFBcUI7QUFBQSxZQUM1QixlQUFlLENBQUNrRSxRQUFRakUscUJBQXFCaUUsUUFBUSxRQUFRLEtBQUtBLEdBQUc7QUFBQSxZQUVyRTtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDQztBQUFBLHVDQUFDLGNBQVcsT0FBTSxPQUFNLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUNyQ3JGLFdBQVcwRTtBQUFBQSxrQkFBSSxDQUFDWSxNQUNmLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUVsQixJQUM3QmtCLFlBQUVDLFFBRFlELEVBQUVsQixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQSxtQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxTQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pqQiwwQkFBZ0JzQixXQUFXLElBQzFCLHVCQUFDLFNBQUksV0FBVSxpSkFBK0ksNkRBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBdEIsZ0JBQWdCdUI7QUFBQUEsTUFBSSxDQUFDYyxVQUNuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLG9FQUFvRUEsZ0JBQU1DLFFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStGO0FBQUEsa0JBQzlGRCxNQUFNYixjQUNMLHVCQUFDLFVBQUssV0FBVSxnSEFDYmEsZ0JBQU1iLGNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVGLHVCQUFDLFNBQU0sT0FBTSxTQUFRLE1BQUssTUFBTWEsZ0JBQU05QixZQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLHFCQVBqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGdFQUFnRThCLGdCQUFNbkMsZUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0c7QUFBQSxnQkFDL0ZtQyxNQUFNaEMsV0FDTCx1QkFBQyxPQUFFLFdBQVUsdURBQXVEZ0MsZ0JBQU1oQyxXQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRjtBQUFBLG1CQVp0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsb0RBQWtEO0FBQUE7QUFBQSxrQkFDOURnQyxNQUFNL0MsT0FBTytCLGVBQWU7QUFBQSxxQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDRCxlQUFlaUIsTUFBTWxELE1BQU07QUFBQSxtQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG9HQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJEQUNiLGlDQUFDLFVBQUssV0FBVSxnREFBZ0RrRCxnQkFBTTNCLGlCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRixLQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1oyQjtBQUFBQSxzQkFBTUUsVUFDTDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNOUQsa0JBQWtCNEQsS0FBSztBQUFBLG9CQUN0QyxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxXQUFRLFdBQVUsaUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEsc0JBQ2hDLHVCQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBVTtBQUFBO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0EsSUFFQSx1QkFBQyxVQUFLLFdBQVUscUdBQW1HLHVCQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0Y7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTTlELGdCQUFnQjhELEtBQUs7QUFBQSxvQkFDcEMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEI7QUFBQTtBQUFBLGtCQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNO0FBQ2IsMEJBQUlsQixRQUFRLG1CQUFtQmtCLE1BQU1uQyxXQUFXLElBQUksR0FBRztBQUNyRC9DLDZDQUFxQmtGLE1BQU1wQixFQUFFO0FBQzdCckMsa0NBQVUsdUJBQXVCO0FBQUEsc0JBQ25DO0FBQUEsb0JBQ0Y7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQjtBQUFBO0FBQUEsa0JBWDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZQTtBQUFBLG1CQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNDQTtBQUFBLGlCQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRDQTtBQUFBO0FBQUE7QUFBQSxRQXhFS3lELE1BQU1wQjtBQUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEwRUE7QUFBQSxJQUNELEtBbEZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5SUFDYixpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsZUFDQyxpQ0FBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxVQUFRLE1BQUMsOEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxhQUFVLFVBQVEsTUFBQyx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzVCLHVCQUFDLGFBQVUsVUFBUSxNQUFDLFdBQVUsYUFBWSxtQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFLHVCQUFDLGFBQVUsVUFBUSxNQUFDLHlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDN0IsdUJBQUMsYUFBVSxVQUFRLE1BQUMsc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUMxQix1QkFBQyxhQUFVLFVBQVEsTUFBQywrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLGFBQVUsVUFBUSxNQUFDLHNCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsUUFDMUIsdUJBQUMsYUFBVSxVQUFRLE1BQUMsV0FBVSxjQUFhLHVCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FScEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxhQUNFakIsMEJBQWdCc0IsV0FBVyxJQUMxQix1QkFBQyxZQUNDLGlDQUFDLGFBQVUsU0FBUyxHQUFHLFdBQVUsbUNBQWlDLDZEQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsSUFFQXRCLGdCQUFnQnVCO0FBQUFBLFFBQUksQ0FBQ2MsVUFDbkIsdUJBQUMsWUFBd0IsV0FBVSxvRUFDakM7QUFBQSxpQ0FBQyxhQUFVLFdBQVUscUJBQ25CO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlEQUF5REEsZ0JBQU1DLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFDbkZELE1BQU1iLGNBQ0wsdUJBQUMsVUFBSyxXQUFVLDZCQUNiYSxnQkFBTWIsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxhQUNDLGlDQUFDLFNBQU0sT0FBTSxTQUFRLE1BQUssTUFDdkJhLGdCQUFNOUIsWUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsYUFDQztBQUFBLG1DQUFDLFVBQUssV0FBVSx5REFBeUQ4QixnQkFBTW5DLGVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJGO0FBQUEsWUFDMUZtQyxNQUFNaEMsV0FDTCx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DZ0MsZ0JBQU1oQyxXQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLGVBSHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSw0Q0FDbkI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWlCZ0MsZ0JBQU0zQixpQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DMkIsZ0JBQU1HLGVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsZUFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLCtFQUE2RTtBQUFBO0FBQUEsWUFDOUZILE1BQU0vQyxPQUFPK0IsZUFBZTtBQUFBLGVBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQ0VnQixnQkFBTUUsVUFDTDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNOUQsa0JBQWtCNEQsS0FBSztBQUFBLGNBQ3RDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsV0FBUSxXQUFVLGlCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BLElBRUEsdUJBQUMsVUFBSyxXQUFVLGdFQUE4RCx1QkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUNBLHVCQUFDLGFBQ0VqQix5QkFBZWlCLE1BQU1sRCxNQUFNLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxnQ0FDbkIsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUNQbkMsV0FBVyxxQkFBcUJxRixNQUFNdEIsV0FBV3NCLE1BQU1iLGNBQWMsY0FBYztBQUFBLGdCQUVyRixXQUFVO0FBQUEsZ0JBQ1YsT0FBTTtBQUFBLGdCQUVOLGlDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdCO0FBQUE7QUFBQSxjQVIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNakQsZ0JBQWdCOEQsS0FBSztBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTTtBQUFBLGdCQUVOLGlDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBO0FBQUEsY0FONUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxZQUNDQSxNQUFNbEQsV0FBVyxjQUNoQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYmpDLHVDQUFxQm1GLE1BQU1wQixJQUFJLEVBQUU5QixRQUFRLFVBQVUsQ0FBQztBQUNwRFAsNEJBQVUsNkJBQTZCO0FBQUEsZ0JBQ3pDO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUI7QUFBQTtBQUFBLGNBVDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFFRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYixzQkFBSXVDLFFBQVEseUJBQXlCa0IsTUFBTW5DLFdBQVcsSUFBSSxHQUFHO0FBQzNEL0MseUNBQXFCa0YsTUFBTXBCLEVBQUU7QUFDN0JyQyw4QkFBVSx1QkFBdUI7QUFBQSxrQkFDbkM7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBRU4saUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUE7QUFBQSxjQVg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLGVBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkNBLEtBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0NBO0FBQUEsYUE3RmF5RCxNQUFNcEIsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThGQTtBQUFBLE1BQ0QsS0F4R0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBHQTtBQUFBLFNBdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3SEEsS0F6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBIQTtBQUFBLElBR0N6QyxrQkFDQyx1QkFBQyxTQUFJLFdBQVUsNEhBQ2IsaUNBQUMsU0FBSSxXQUFVLDJKQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVIQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxtREFBbURBLHlCQUFlMEIsZUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxPQUFFLFdBQVUsNENBQ1YxQjtBQUFBQSwyQkFBZStCO0FBQUFBLFlBQVM7QUFBQSxZQUFLL0IsZUFBZWM7QUFBQUEsZUFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNYixrQkFBa0IsSUFBSTtBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUE7QUFBQSxVQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLEtBQUtELGVBQWUrRDtBQUFBQSxVQUNwQixLQUFJO0FBQUEsVUFDSixXQUFVO0FBQUEsVUFDVixnQkFBZTtBQUFBO0FBQUEsUUFKakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BSThCLEtBTGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlIQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLG1FQUNiL0QseUJBQWU2QixXQUFXLCtCQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU01QixrQkFBa0IsSUFBSTtBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUFpSTtBQUFBO0FBQUEsVUFGN0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0EsS0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9DQTtBQUFBLElBSURILGdCQUNDLHVCQUFDLFNBQUksV0FBVSw0SEFDYixpQ0FBQyxTQUFJLFdBQVUsZ0xBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkVBQ1o7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDekMsdUJBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLGFBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMsZ0JBQWdCLElBQUk7QUFBQSxZQUNuQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBO0FBQUEsVUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUN6QixVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXLGVBQWVyQyxVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXLGFBQ2hKLHVCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLCtCQUFDLGdCQUFhLFdBQVUsOEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUNsRCx1QkFBQyxVQUFLLHVGQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxXQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsSUFDRTtBQUFBLE1BQ0osdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrR0FBaUcsbUNBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFJO0FBQUEsVUFDckk7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9iLGFBQWE0QjtBQUFBQSxjQUNwQixVQUFVLENBQUNoQixNQUFNWCxnQkFBZ0IsRUFBRSxHQUFHRCxjQUFjNEIsYUFBYWhCLEVBQUU4QyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUNqRixVQUFVbkYsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVyxlQUFlckMsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVztBQUFBLGNBQzNKLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3VNO0FBQUEsYUFQek07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtHQUFpRyw2QkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0g7QUFBQSxZQUMvSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9iLGFBQWFxRSxhQUFhO0FBQUEsZ0JBQ2pDLGVBQWUsQ0FBQ1QsUUFBYTNELGdCQUFnQixFQUFFLEdBQUdELGNBQWNxRSxXQUFXVCxRQUFRLFNBQVNVLFNBQVlWLElBQUksQ0FBQztBQUFBLGdCQUM3RyxVQUFVcEYsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVyxlQUFlckMsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVztBQUFBLGdCQUUzSjtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsbUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxvQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLFFBQU8sMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUEsb0JBQ2xDckMsVUFBVXlFO0FBQUFBLHNCQUFJLENBQUFtQixNQUNiLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUV6QixJQUFHO0FBQUE7QUFBQSx3QkFDNUJ5QixFQUFFRztBQUFBQSx3QkFBVTtBQUFBLHdCQUFHSCxFQUFFTjtBQUFBQSx3QkFBSztBQUFBLDJCQURaTSxFQUFFekIsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUEsdUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBO0FBQUE7QUFBQSxjQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtHQUFpRyx3QkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEg7QUFBQSxZQUMxSDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8zQyxhQUFhaUM7QUFBQUEsZ0JBQ3BCLGVBQWUsQ0FBQzJCLFFBQWEzRCxnQkFBZ0IsRUFBRSxHQUFHRCxjQUFjaUMsVUFBVTJCLElBQUksQ0FBQztBQUFBLGdCQUMvRSxVQUFVcEYsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVyxlQUFlckMsVUFBVTJGLEtBQUssQ0FBQUMsTUFBS0EsRUFBRXpCLE9BQU8zQyxhQUFhcUUsU0FBUyxHQUFHeEQsV0FBVztBQUFBLGdCQUUzSjtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsbUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxxQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLFVBQVMsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLGNBQVcsT0FBTSxRQUFPLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBLG9CQUM3Qix1QkFBQyxjQUFXLE9BQU0sYUFBWSx5QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQSxvQkFDdkMsdUJBQUMsY0FBVyxPQUFNLFNBQVEscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStCO0FBQUEsb0JBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLHVCQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQTtBQUFBLGNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0dBQWlHLDBCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SDtBQUFBLFlBQzVIO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLEtBQUk7QUFBQSxnQkFDSixPQUFPYixhQUFhZ0I7QUFBQUEsZ0JBQ3BCLFVBQVUsQ0FBQ0osTUFDVFgsZ0JBQWdCO0FBQUEsa0JBQ2QsR0FBR0Q7QUFBQUEsa0JBQ0hnQixRQUFRd0QsV0FBVzVELEVBQUU4QyxPQUFPQyxLQUFLLEtBQUs7QUFBQSxnQkFDeEMsQ0FBQztBQUFBLGdCQUVILFVBQVVuRixVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXLGVBQWVyQyxVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXO0FBQUEsZ0JBQzNKLFdBQVU7QUFBQTtBQUFBLGNBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV2lOO0FBQUEsZUFibk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrR0FBaUcsdUJBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlIO0FBQUEsWUFDekg7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2IsYUFBYStCLFdBQVc7QUFBQSxnQkFDL0IsVUFBVSxDQUFDbkIsTUFBTVgsZ0JBQWdCLEVBQUUsR0FBR0QsY0FBYytCLFNBQVNuQixFQUFFOEMsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBQzdFLFVBQVVuRixVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXLGVBQWVyQyxVQUFVMkYsS0FBSyxDQUFBQyxNQUFLQSxFQUFFekIsT0FBTzNDLGFBQWFxRSxTQUFTLEdBQUd4RCxXQUFXO0FBQUEsZ0JBQzNKLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VNO0FBQUEsZUFQek07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxXQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUZBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNWixnQkFBZ0IsSUFBSTtBQUFBLFlBQ25DLFdBQVU7QUFBQSxZQUE4TTtBQUFBO0FBQUEsVUFGMU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYnJCLG1DQUFxQm9CLGFBQWEyQyxJQUFJO0FBQUEsZ0JBQ3BDZixhQUFhNUIsYUFBYTRCO0FBQUFBLGdCQUMxQkssVUFBVWpDLGFBQWFpQztBQUFBQSxnQkFDdkJqQixRQUFRaEIsYUFBYWdCO0FBQUFBLGdCQUNyQmUsU0FBUy9CLGFBQWErQjtBQUFBQSxnQkFDdEJzQyxXQUFXckUsYUFBYXFFO0FBQUFBLGNBQzFCLENBQUM7QUFDRHBFLDhCQUFnQixJQUFJO0FBQ3BCSyx3QkFBVSx1QkFBdUI7QUFBQSxZQUNuQztBQUFBLFlBQ0EsVUFBVTlCLFVBQVUyRixLQUFLLENBQUFDLE1BQUtBLEVBQUV6QixPQUFPM0MsYUFBYXFFLFNBQVMsR0FBR3hELFdBQVcsZUFBZXJDLFVBQVUyRixLQUFLLENBQUFDLE1BQUtBLEVBQUV6QixPQUFPM0MsYUFBYXFFLFNBQVMsR0FBR3hELFdBQVc7QUFBQSxZQUMzSixXQUFVO0FBQUEsWUFBcUo7QUFBQTtBQUFBLFVBYmpLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWdCQTtBQUFBLFdBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxTQWpJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0lBLEtBbklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvSUE7QUFBQSxJQUlEakIsYUFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsUUFBUUE7QUFBQUEsUUFDUixjQUFjRTtBQUFBQSxRQUNkLFNBQVMsTUFBTTtBQUNiRCx1QkFBYSxLQUFLO0FBQ2xCRSwwQkFBZ0IsSUFBSTtBQUNwQixjQUFJYixnQkFBaUJBLGlCQUFnQjtBQUFBLFFBQ3ZDO0FBQUEsUUFDQSxhQUFZO0FBQUEsUUFDWixhQUFZO0FBQUEsUUFDWixVQUFTO0FBQUEsUUFDVCxjQUFhO0FBQUEsUUFDYixvQkFBb0IsQ0FBQ3VGLGFBQWE7QUFDaEMsY0FBSTNGLGFBQWE7QUFDZkEsd0JBQVkyRixRQUFRO0FBQUEsVUFDdEI7QUFDQW5FLG9CQUFVLGdCQUFnQm1FLFNBQVN2QixVQUFVLHdCQUF3QjtBQUFBLFFBQ3ZFO0FBQUEsUUFDQSxpQkFBaUIsQ0FBQ3dCLFNBQVNDLFlBQVk7QUFDckNELGtCQUFRaEMsUUFBUSxDQUFDcUIsVUFBVXBGLGtCQUFrQm9GLEtBQUssQ0FBQztBQUNuRHpELG9CQUFVcUUsVUFBVSx5QkFBeUIseUNBQXlDO0FBQUEsUUFDeEY7QUFBQTtBQUFBLE1BckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFCSTtBQUFBLE9BanRCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb3RCQTtBQUVKO0FBQUV4RixHQTUwQldkLGFBQXVDO0FBQUEsS0FBdkNBO0FBQXVDLElBQUF1RztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJOZXdGaW5hbmNlTW9kYWwiLCJCYWRnZSIsIkNhciIsIlV0ZW5zaWxzIiwiRmlsZVRleHQiLCJSZWNlaXB0IiwiUGx1cyIsIlNlYXJjaCIsIkNoZWNrQ2lyY2xlMiIsIlgiLCJFZGl0MyIsIlRyYXNoMiIsIkV5ZSIsIlNlbmQiLCJGaWxlU3ByZWFkc2hlZXQiLCJBcnJvd1JpZ2h0IiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJUYWJsZSIsIlRhYmxlSGVhZGVyIiwiVGFibGVCb2R5IiwiVGFibGVSb3ciLCJUYWJsZUNlbGwiLCJGaW5hbmNlVmlldyIsImZpbmFuY2VFbnRyaWVzIiwicGFuY2hheWF0cyIsInNlc3Npb25zIiwiZHJhZnRzIiwib25OYXZpZ2F0ZSIsIm9uQWRkRmluYW5jZUVudHJ5Iiwib25VcGRhdGVGaW5hbmNlRW50cnkiLCJvbkRlbGV0ZUZpbmFuY2VFbnRyeSIsIm9uU2F2ZURyYWZ0Iiwib25EZWxldGVEcmFmdCIsIm9uU3VibWl0RHJhZnQiLCJpc09wZW5OZXdNb2RhbCIsIm9uQ2xvc2VOZXdNb2RhbCIsIl9zIiwiYWN0aXZlVGFiRmlsdGVyIiwic2V0QWN0aXZlVGFiRmlsdGVyIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzZWxlY3RlZENhdGVnb3J5Iiwic2V0U2VsZWN0ZWRDYXRlZ29yeSIsInNlbGVjdGVkUGFuY2hheWF0Iiwic2V0U2VsZWN0ZWRQYW5jaGF5YXQiLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJlZGl0aW5nRHJhZnQiLCJzZXRFZGl0aW5nRHJhZnQiLCJlZGl0aW5nRW50cnkiLCJzZXRFZGl0aW5nRW50cnkiLCJ2aWV3aW5nUmVjZWlwdCIsInNldFZpZXdpbmdSZWNlaXB0IiwidG9hc3RNZXNzYWdlIiwic2V0VG9hc3RNZXNzYWdlIiwic2hvd1RvYXN0IiwibXNnIiwic2V0VGltZW91dCIsInRvdGFsQWR2YW5jZSIsInRvdGFsRXhwZW5zZXMiLCJmaWx0ZXIiLCJlIiwic3RhdHVzIiwicmVkdWNlIiwic3VtIiwiYW1vdW50IiwidG90YWxQZW5kaW5nIiwidG90YWxEcmFmdHNBbW91bnQiLCJmcm9tRW50cmllcyIsImZyb21EcmFmdHMiLCJkIiwidG90YWxBbW91bnQiLCJNYXRoIiwibWF4IiwiYmFsYW5jZSIsImZpbHRlcmVkRW50cmllcyIsIm1hdGNoU2VhcmNoIiwiZGVzY3JpcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwicmVtYXJrcyIsIm1hdGNoQ2F0ZWdvcnkiLCJjYXRlZ29yeSIsIm1hdGNoUGFuY2hheWF0IiwicGFuY2hheWF0SWQiLCJwYW5jaGF5YXROYW1lIiwibWF0Y2hTdGF0dXMiLCJoYW5kbGVFZGl0RHJhZnQiLCJkcmFmdCIsImhhbmRsZVN1Ym1pdERyYWZ0UGFja2FnZSIsImRyYWZ0SWQiLCJmb3JFYWNoIiwiaWQiLCJoYW5kbGVEZWxldGVEcmFmdFBhY2thZ2UiLCJjb25maXJtIiwiZ2V0U3RhdHVzQmFkZ2UiLCJ0b0xvY2FsZVN0cmluZyIsImxlbmd0aCIsIm1hcCIsInNlc3Npb25EYXkiLCJzZXNzaW9uRGF0ZSIsInRpdGxlIiwiY2x1c3Rlck5hbWUiLCJjb2xsZWdlTmFtZSIsInJvdXRlcyIsImZvb2QiLCJzdGF0aW9uZXJ5IiwidGFyZ2V0IiwidmFsdWUiLCJ2YWwiLCJwIiwibmFtZSIsImVudHJ5IiwiZGF0ZSIsImJpbGxVcmwiLCJ2aWxsYWdlTmFtZSIsImZpbmQiLCJzIiwic2Vzc2lvbklkIiwidW5kZWZpbmVkIiwiZGF5TnVtYmVyIiwicGFyc2VGbG9hdCIsImRyYWZ0UGtnIiwiZW50cmllcyIsImlzRHJhZnQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaW5hbmNlVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVGFiVHlwZSwgRmluYW5jZUVudHJ5LCBQYW5jaGF5YXQsIEZpbmFuY2VEcmFmdCwgU2Vzc2lvbiB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IE5ld0ZpbmFuY2VNb2RhbCB9IGZyb20gJy4vTmV3RmluYW5jZU1vZGFsJztcbmltcG9ydCBCYWRnZSBmcm9tICcuL3VpL2JhZGdlJztcbmltcG9ydCB7XG4gIENhcixcbiAgVXRlbnNpbHMsXG4gIEZpbGVUZXh0LFxuICBSZWNlaXB0LFxuICBTcGFya2xlcyxcbiAgUGx1cyxcbiAgU2VhcmNoLFxuICBDaGVja0NpcmNsZTIsXG4gIFgsXG4gIEVkaXQzLFxuICBUcmFzaDIsXG4gIEV5ZSxcbiAgU2VuZCxcbiAgRmlsZVNwcmVhZHNoZWV0LFxuICBBcnJvd1JpZ2h0LFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSAnLi91aS9zZWxlY3QnO1xuaW1wb3J0IHsgVGFibGUsIFRhYmxlSGVhZGVyLCBUYWJsZUJvZHksIFRhYmxlUm93LCBUYWJsZUNlbGwgfSBmcm9tICcuL3VpL3RhYmxlJztcblxuaW50ZXJmYWNlIEZpbmFuY2VWaWV3UHJvcHMge1xuICBmaW5hbmNlRW50cmllczogRmluYW5jZUVudHJ5W107XG4gIHBhbmNoYXlhdHM6IFBhbmNoYXlhdFtdO1xuICBzZXNzaW9ucz86IFNlc3Npb25bXTtcbiAgZHJhZnRzPzogRmluYW5jZURyYWZ0W107XG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkFkZEZpbmFuY2VFbnRyeTogKGVudHJ5OiBPbWl0PEZpbmFuY2VFbnRyeSwgJ2lkJz4pID0+IHZvaWQ7XG4gIG9uVXBkYXRlRmluYW5jZUVudHJ5OiAoaWQ6IHN0cmluZywgdXBkYXRlZDogUGFydGlhbDxGaW5hbmNlRW50cnk+KSA9PiB2b2lkO1xuICBvbkRlbGV0ZUZpbmFuY2VFbnRyeTogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uU2F2ZURyYWZ0PzogKGRyYWZ0OiBGaW5hbmNlRHJhZnQpID0+IHZvaWQ7XG4gIG9uRGVsZXRlRHJhZnQ/OiAoZHJhZnRJZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvblN1Ym1pdERyYWZ0PzogKGRyYWZ0SWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgaXNPcGVuTmV3TW9kYWw/OiBib29sZWFuO1xuICBvbkNsb3NlTmV3TW9kYWw/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgRmluYW5jZVZpZXc6IFJlYWN0LkZDPEZpbmFuY2VWaWV3UHJvcHM+ID0gKHtcbiAgZmluYW5jZUVudHJpZXMsXG4gIHBhbmNoYXlhdHMsXG4gIHNlc3Npb25zLFxuICBkcmFmdHMgPSBbXSxcbiAgb25OYXZpZ2F0ZSxcbiAgb25BZGRGaW5hbmNlRW50cnksXG4gIG9uVXBkYXRlRmluYW5jZUVudHJ5LFxuICBvbkRlbGV0ZUZpbmFuY2VFbnRyeSxcbiAgb25TYXZlRHJhZnQsXG4gIG9uRGVsZXRlRHJhZnQsXG4gIG9uU3VibWl0RHJhZnQsXG4gIGlzT3Blbk5ld01vZGFsID0gZmFsc2UsXG4gIG9uQ2xvc2VOZXdNb2RhbCxcbn0pID0+IHtcbiAgY29uc3QgW2FjdGl2ZVRhYkZpbHRlciwgc2V0QWN0aXZlVGFiRmlsdGVyXSA9IHVzZVN0YXRlPCdhbGwnIHwgJ2RyYWZ0cycgfCAnYXBwcm92ZWQnIHwgJ3BlbmRpbmcnPignYWxsJyk7XG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkQ2F0ZWdvcnksIHNldFNlbGVjdGVkQ2F0ZWdvcnldID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXQsIHNldFNlbGVjdGVkUGFuY2hheWF0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGlzT3Blbk5ld01vZGFsKTtcbiAgY29uc3QgW2VkaXRpbmdEcmFmdCwgc2V0RWRpdGluZ0RyYWZ0XSA9IHVzZVN0YXRlPEZpbmFuY2VEcmFmdCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZWRpdGluZ0VudHJ5LCBzZXRFZGl0aW5nRW50cnldID0gdXNlU3RhdGU8RmluYW5jZUVudHJ5IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt2aWV3aW5nUmVjZWlwdCwgc2V0Vmlld2luZ1JlY2VpcHRdID0gdXNlU3RhdGU8RmluYW5jZUVudHJ5IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt0b2FzdE1lc3NhZ2UsIHNldFRvYXN0TWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBzaG93VG9hc3QgPSAobXNnOiBzdHJpbmcpID0+IHtcbiAgICBzZXRUb2FzdE1lc3NhZ2UobXNnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFRvYXN0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgY29uc3QgdG90YWxBZHZhbmNlID0gNDUwMDA7XG5cbiAgY29uc3QgdG90YWxFeHBlbnNlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBmaW5hbmNlRW50cmllc1xuICAgICAgLmZpbHRlcigoZSkgPT4gZS5zdGF0dXMgPT09ICdBcHByb3ZlZCcpXG4gICAgICAucmVkdWNlKChzdW0sIGUpID0+IHN1bSArIGUuYW1vdW50LCAwKTtcbiAgfSwgW2ZpbmFuY2VFbnRyaWVzXSk7XG5cbiAgY29uc3QgdG90YWxQZW5kaW5nID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGZpbmFuY2VFbnRyaWVzXG4gICAgICAuZmlsdGVyKChlKSA9PiBlLnN0YXR1cyA9PT0gJ1BlbmRpbmcnIHx8IGUuc3RhdHVzID09PSAnQ29ycmVjdGlvbicpXG4gICAgICAucmVkdWNlKChzdW0sIGUpID0+IHN1bSArIGUuYW1vdW50LCAwKTtcbiAgfSwgW2ZpbmFuY2VFbnRyaWVzXSk7XG5cbiAgY29uc3QgdG90YWxEcmFmdHNBbW91bnQgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBmcm9tRW50cmllcyA9IGZpbmFuY2VFbnRyaWVzXG4gICAgICAuZmlsdGVyKChlKSA9PiBlLnN0YXR1cyA9PT0gJ0RyYWZ0JylcbiAgICAgIC5yZWR1Y2UoKHN1bSwgZSkgPT4gc3VtICsgZS5hbW91bnQsIDApO1xuICAgIGNvbnN0IGZyb21EcmFmdHMgPSBkcmFmdHMucmVkdWNlKChzdW0sIGQpID0+IHN1bSArIGQudG90YWxBbW91bnQsIDApO1xuICAgIHJldHVybiBNYXRoLm1heChmcm9tRW50cmllcywgZnJvbURyYWZ0cyk7XG4gIH0sIFtmaW5hbmNlRW50cmllcywgZHJhZnRzXSk7XG5cbiAgY29uc3QgYmFsYW5jZSA9IHRvdGFsQWR2YW5jZSAtIHRvdGFsRXhwZW5zZXM7XG5cbiAgLy8gRmlsdGVyZWQgZW50cmllcyBmb3IgdGFibGUgYW5kIG1vYmlsZSBjYXJkc1xuICBjb25zdCBmaWx0ZXJlZEVudHJpZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZmluYW5jZUVudHJpZXMuZmlsdGVyKChlKSA9PiB7XG4gICAgICBjb25zdCBtYXRjaFNlYXJjaCA9XG4gICAgICAgIGUuZGVzY3JpcHRpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgIChlLnJlbWFya3MgJiYgZS5yZW1hcmtzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSk7XG5cbiAgICAgIGNvbnN0IG1hdGNoQ2F0ZWdvcnkgPSAhc2VsZWN0ZWRDYXRlZ29yeSB8fCBlLmNhdGVnb3J5ID09PSBzZWxlY3RlZENhdGVnb3J5O1xuICAgICAgY29uc3QgbWF0Y2hQYW5jaGF5YXQgPVxuICAgICAgICAhc2VsZWN0ZWRQYW5jaGF5YXQgfHxcbiAgICAgICAgZS5wYW5jaGF5YXRJZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXQgfHxcbiAgICAgICAgZS5wYW5jaGF5YXROYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VsZWN0ZWRQYW5jaGF5YXQudG9Mb3dlckNhc2UoKSk7XG5cbiAgICAgIGxldCBtYXRjaFN0YXR1cyA9IHRydWU7XG4gICAgICBpZiAoYWN0aXZlVGFiRmlsdGVyID09PSAnZHJhZnRzJykge1xuICAgICAgICBtYXRjaFN0YXR1cyA9IGUuc3RhdHVzID09PSAnRHJhZnQnO1xuICAgICAgfSBlbHNlIGlmIChhY3RpdmVUYWJGaWx0ZXIgPT09ICdhcHByb3ZlZCcpIHtcbiAgICAgICAgbWF0Y2hTdGF0dXMgPSBlLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJztcbiAgICAgIH0gZWxzZSBpZiAoYWN0aXZlVGFiRmlsdGVyID09PSAncGVuZGluZycpIHtcbiAgICAgICAgbWF0Y2hTdGF0dXMgPSBlLnN0YXR1cyA9PT0gJ1BlbmRpbmcnIHx8IGUuc3RhdHVzID09PSAnQ29ycmVjdGlvbic7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBtYXRjaFNlYXJjaCAmJiBtYXRjaENhdGVnb3J5ICYmIG1hdGNoUGFuY2hheWF0ICYmIG1hdGNoU3RhdHVzO1xuICAgIH0pO1xuICB9LCBbZmluYW5jZUVudHJpZXMsIHNlYXJjaFRlcm0sIHNlbGVjdGVkQ2F0ZWdvcnksIHNlbGVjdGVkUGFuY2hheWF0LCBhY3RpdmVUYWJGaWx0ZXJdKTtcblxuICBjb25zdCBoYW5kbGVFZGl0RHJhZnQgPSAoZHJhZnQ6IEZpbmFuY2VEcmFmdCkgPT4ge1xuICAgIHNldEVkaXRpbmdEcmFmdChkcmFmdCk7XG4gICAgc2V0U2hvd01vZGFsKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdERyYWZ0UGFja2FnZSA9IChkcmFmdElkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAob25TdWJtaXREcmFmdCkge1xuICAgICAgb25TdWJtaXREcmFmdChkcmFmdElkKTtcbiAgICB9XG4gICAgZmluYW5jZUVudHJpZXMuZm9yRWFjaCgoZSkgPT4ge1xuICAgICAgaWYgKGUuZHJhZnRJZCA9PT0gZHJhZnRJZCkge1xuICAgICAgICBvblVwZGF0ZUZpbmFuY2VFbnRyeShlLmlkLCB7IHN0YXR1czogJ0FwcHJvdmVkJyB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBzaG93VG9hc3QoJ0RyYWZ0IHN1Ym1pdHRlZCBmb3IgYXBwcm92YWwgc3VjY2Vzc2Z1bGx5IScpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZURyYWZ0UGFja2FnZSA9IChkcmFmdElkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoY29uZmlybSgnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGZvcm1hdHRlZCBkcmFmdCBzZXNzaW9uPycpKSB7XG4gICAgICBpZiAob25EZWxldGVEcmFmdCkge1xuICAgICAgICBvbkRlbGV0ZURyYWZ0KGRyYWZ0SWQpO1xuICAgICAgfVxuICAgICAgZmluYW5jZUVudHJpZXMuZm9yRWFjaCgoZSkgPT4ge1xuICAgICAgICBpZiAoZS5kcmFmdElkID09PSBkcmFmdElkKSB7XG4gICAgICAgICAgb25EZWxldGVGaW5hbmNlRW50cnkoZS5pZCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgc2hvd1RvYXN0KCdEcmFmdCByZW1vdmVkLicpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBnZXRTdGF0dXNCYWRnZSA9IChzdGF0dXM6IHN0cmluZykgPT4ge1xuICAgIGlmIChzdGF0dXMgPT09ICdBcHByb3ZlZCcpIHJldHVybiA8QmFkZ2UgY29sb3I9XCJzdWNjZXNzXCIgc2l6ZT1cInNtXCI+QXBwcm92ZWQ8L0JhZGdlPjtcbiAgICBpZiAoc3RhdHVzID09PSAnRHJhZnQnKSByZXR1cm4gPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPkRyYWZ0PC9CYWRnZT47XG4gICAgcmV0dXJuIDxCYWRnZSBjb2xvcj1cImVycm9yXCIgc2l6ZT1cInNtXCI+e3N0YXR1c308L0JhZGdlPjtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktNSBzbTpzcGFjZS15LTZcIj5cbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XG4gICAgICB7dG9hc3RNZXNzYWdlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNSByaWdodC01IHotWzIwMF0gcm91bmRlZC14bCBiZy1ncmF5LTkwMCBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUtbGcgZGFyazpiZy13aGl0ZSBkYXJrOnRleHQtZ3JheS05MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYW5pbWF0ZS1pbiBmYWRlLWluLTAgc2xpZGUtaW4tZnJvbS1ib3R0b20tNVwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXN1Y2Nlc3MtNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3Bhbj57dG9hc3RNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRUb2FzdE1lc3NhZ2UobnVsbCl9IGNsYXNzTmFtZT1cIm1sLTEgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGRhcms6aG92ZXI6dGV4dC1ncmF5LTkwMFwiPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIDEuIFBhZ2UgSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTMuNVwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIEZpbmFuY2UgJmFtcDsgRXhwZW5zZXNcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIERoYXJtYXB1cmkgQ2x1c3RlclxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgc206dGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgVHJhY2sgY2x1c3RlciBidWRnZXRzLCBleHBlbnNlIGVudHJpZXMsIGJpbGxzLCBmb3JtYXR0ZWQgZHJhZnRzLCBhbmQgVFFJIHN0YXRlbWVudHMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdmaW5hbmNlLXN0YXRlbWVudCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHNtOmZsZXgtbm9uZSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxGaWxlU3ByZWFkc2hlZXQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNTAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPlRRSSBTdGF0ZW1lbnQ8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIHNldEVkaXRpbmdEcmFmdChudWxsKTtcbiAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBzbTpmbGV4LW5vbmUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYmctYnJhbmQtNTAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+TmV3IEV4cGVuc2UgRW50cnk8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiAyLiBNZXRyaWMgQ2FyZHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTMgc206Z2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNCBzbTpwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlRvdGFsIEFkdmFuY2U8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCBmb250LW1vbm8gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj7igrl7dG90YWxBZHZhbmNlLnRvTG9jYWxlU3RyaW5nKCl9PC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgdHJ1bmNhdGVcIj5EaXNidXJzZWQgYnkgU3RhdGUgSFE8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc206cC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zdWNjZXNzLTUwMFwiPkV4cGVuc2VzIEFwcHJvdmVkPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgZm9udC1tb25vIHRleHQtc3VjY2Vzcy02MDAgZGFyazp0ZXh0LXN1Y2Nlc3MtNDAwXCI+4oK5e3RvdGFsRXhwZW5zZXMudG9Mb2NhbGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1bMTFweF0gdGV4dC1zdWNjZXNzLTUwMC84MCB0cnVuY2F0ZVwiPlZlcmlmaWVkIHdpdGggcmVjZWlwdHM8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc206cC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1icmFuZC01MDBcIj5SZW1haW5pbmcgQmFsYW5jZTwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMS41IHRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIGZvbnQtbW9ubyB0ZXh0LWJyYW5kLTUwMFwiPuKCuXtiYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9PC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWzExcHhdIHRleHQtYnJhbmQtNTAwLzgwIHRydW5jYXRlXCI+Q2x1c3RlciBhdmFpbGFibGUgZnVuZDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNCBzbTpwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXdhcm5pbmctNTAwXCI+U2F2ZWQgRHJhZnRzPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgZm9udC1tb25vIHRleHQtd2FybmluZy02MDAgZGFyazp0ZXh0LXdhcm5pbmctNDAwXCI+4oK5e3RvdGFsRHJhZnRzQW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9PC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtWzExcHhdIHRleHQtd2FybmluZy01MDAvODAgdHJ1bmNhdGVcIj57ZHJhZnRzLmxlbmd0aH0gZm9ybWF0dGVkIGRyYWZ0czwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDMuIEZpbHRlciBUYWJzICYgVmlldyBTdGF0ZW1lbnQgTGluayAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBwYi0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gbm8tc2Nyb2xsYmFyIHB5LTAuNVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiRmlsdGVyKCdhbGwnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiRmlsdGVyID09PSAnYWxsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIEFsbCBFeHBlbnNlcyAoe2ZpbmFuY2VFbnRyaWVzLmxlbmd0aH0pXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWJGaWx0ZXIoJ2RyYWZ0cycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWJGaWx0ZXIgPT09ICdkcmFmdHMnXG4gICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xuICAgICAgICAgICAgICAgIDogJ2JvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgRHJhZnQgU2hlZXRzICh7ZHJhZnRzLmxlbmd0aH0pXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWJGaWx0ZXIoJ2FwcHJvdmVkJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyIHdoaXRlc3BhY2Utbm93cmFwICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYkZpbHRlciA9PT0gJ2FwcHJvdmVkJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIEFwcHJvdmVkICh7ZmluYW5jZUVudHJpZXMuZmlsdGVyKChlKSA9PiBlLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJykubGVuZ3RofSlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYkZpbHRlcigncGVuZGluZycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWJGaWx0ZXIgPT09ICdwZW5kaW5nJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIFBlbmRpbmcgKHtmaW5hbmNlRW50cmllcy5maWx0ZXIoKGUpID0+IGUuc3RhdHVzID09PSAnUGVuZGluZycgfHwgZS5zdGF0dXMgPT09ICdDb3JyZWN0aW9uJykubGVuZ3RofSlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2ZpbmFuY2Utc3RhdGVtZW50Jyl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgaG92ZXI6dGV4dC1icmFuZC02MDAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlciBzZWxmLWVuZCBzbTpzZWxmLWF1dG9cIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4+U3RhdGVtZW50IEZvcm1hdDwvc3Bhbj5cbiAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBERURJQ0FURUQgRFJBRlRTIFNFQ1RJT04gKFdoZW4gJ2RyYWZ0cycgdGFiIGlzIGFjdGl2ZSkgKi99XG4gICAgICB7YWN0aXZlVGFiRmlsdGVyID09PSAnZHJhZnRzJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBTYXZlZCBEcmFmdCBTaGVldHMgKFJlYWR5IGZvciBUUUkgRm9ybWF0dGluZyAmYW1wOyBTdWJtaXNzaW9uKVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRFZGl0aW5nRHJhZnQobnVsbCk7XG4gICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICArIE5ldyBEcmFmdCBTZXNzaW9uXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtkcmFmdHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgdGV4dC14cyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxuICAgICAgICAgICAgICBObyBzYXZlZCBkcmFmdHMgY3VycmVudGx5LlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICB7ZHJhZnRzLm1hcCgoZHJhZnQpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2RyYWZ0LmlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc206cC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkcmFmdC5zZXNzaW9uRGF5fSBEcmFmdFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPntkcmFmdC5zZXNzaW9uRGF0ZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPntkcmFmdC50aXRsZX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBDbHVzdGVyOiA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+e2RyYWZ0LmNsdXN0ZXJOYW1lfTwvc3Bhbj4gJm1pZGRvdDsge2RyYWZ0LmNvbGxlZ2VOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2RyYWZ0LnRvdGFsQW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNDAwXCI+VG90YWwgQW1vdW50PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQnJlYWtkb3duIFBpbGxzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RyYWZ0LnJvdXRlcyAmJiBkcmFmdC5yb3V0ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MC81MCBweC0yIHB5LTEgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJyYW5kLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntkcmFmdC5yb3V0ZXMubGVuZ3RofSBUcmF2ZWwgUm91dGVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAge2RyYWZ0LmZvb2QgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktNTAvNTAgcHgtMiBweS0xIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxVdGVuc2lscyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXdhcm5pbmctNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Rm9vZCBMb2dnZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7ZHJhZnQuc3RhdGlvbmVyeSAmJiBkcmFmdC5zdGF0aW9uZXJ5LmFtb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYXktNTAvNTAgcHgtMiBweS0xIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXN1Y2Nlc3MtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U3RhdGlvbmVyeSAo4oK5e2RyYWZ0LnN0YXRpb25lcnkuYW1vdW50fSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgQmFyICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0zLjUgbXQtMy41IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdmaW5hbmNlLXN0YXRlbWVudCcsIGRyYWZ0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtMjAwIGJnLWJyYW5kLTUwIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTYwMCBob3ZlcjpiZy1icmFuZC0xMDAgZGFyazpib3JkZXItYnJhbmQtOTAwLzQwIGRhcms6YmctYnJhbmQtNTAwLzEwIGRhcms6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBTdGF0ZW1lbnQgU2hlZXRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFZGl0RHJhZnQoZHJhZnQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdERyYWZ0UGFja2FnZShkcmFmdC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLXN1Y2Nlc3MtNTAwIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1zdWNjZXNzLTYwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBTdWJtaXRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZURyYWZ0UGFja2FnZShkcmFmdC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMS41IHRleHQtZ3JheS00MDAgaG92ZXI6YmctZXJyb3ItNTAgaG92ZXI6dGV4dC1lcnJvci02MDAgZGFyazpob3ZlcjpiZy1lcnJvci01MDAvMTAgZGFyazpob3Zlcjp0ZXh0LWVycm9yLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIERyYWZ0XCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIDQuIFNlYXJjaCAmIEZpbHRlciBCYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTIuNSBpdGVtcy1zdHJldGNoIHNtOml0ZW1zLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMVwiPlxuICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGV4cGVuc2VzIGJ5IGRlc2NyaXB0aW9uLCByb3V0ZSwgb3IgcmVtYXJrcy4uLlwiXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGVybX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTEwIHByLTQgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctNDBcIj5cbiAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ2F0ZWdvcnkgfHwgXCJhbGxcIn1cbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRDYXRlZ29yeSh2YWwgPT09IFwiYWxsXCIgPyBcIlwiIDogdmFsKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgQ2F0ZWdvcmllc1wiIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgQ2F0ZWdvcmllczwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlRyYXZlbFwiPlRyYXZlbDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZvb2RcIj5Gb29kPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiTWF0ZXJpYWxzXCI+TWF0ZXJpYWxzIC8gU3RhdGlvbmVyeTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkFkbWluXCI+QWRtaW48L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJPdGhlclwiPk90aGVyPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctNDBcIj5cbiAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGFuY2hheWF0IHx8IFwiYWxsXCJ9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkUGFuY2hheWF0KHZhbCA9PT0gXCJhbGxcIiA/IFwiXCIgOiB2YWwpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBQYW5jaGF5YXRzXCIgLz5cbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbCBQYW5jaGF5YXRzPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIHtwYW5jaGF5YXRzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XG4gICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogNUEuIE1PQklMRSBFWFBFTlNFIENBUkRTIChWaXNpYmxlIG9uIG1vYmlsZSBzY3JlZW5zIDwgNzY4cHgpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9jayBtZDpoaWRkZW4gc3BhY2UteS0zXCI+XG4gICAgICAgIHtmaWx0ZXJlZEVudHJpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCB0ZXh0LXhzIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICBObyBleHBlbnNlIGVudHJpZXMgbWF0Y2hpbmcgY3VycmVudCBjcml0ZXJpYS5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICBmaWx0ZXJlZEVudHJpZXMubWFwKChlbnRyeSkgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e2VudHJ5LmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gc3BhY2UteS0yLjVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCBmb250LW1vbm8gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57ZW50cnkuZGF0ZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zZXNzaW9uRGF5ICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIGJnLWdyYXktMTAwIGRhcms6Ymctd2hpdGUvNSBweC0xLjUgcHktMC41IHJvdW5kZWQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zZXNzaW9uRGF5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwibGlnaHRcIiBzaXplPVwic21cIj57ZW50cnkuY2F0ZWdvcnl9PC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGxlYWRpbmctc251Z1wiPntlbnRyeS5kZXNjcmlwdGlvbn08L2g0PlxuICAgICAgICAgICAgICAgICAge2VudHJ5LnJlbWFya3MgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0wLjVcIj57ZW50cnkucmVtYXJrc308L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAg4oK5e2VudHJ5LmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0JhZGdlKGVudHJ5LnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBtYXgtdy1bMTUwcHhdXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPntlbnRyeS5wYW5jaGF5YXROYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAge2VudHJ5LmJpbGxVcmwgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3aW5nUmVjZWlwdChlbnRyeSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0xIHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6YmctZW1lcmFsZC05NTAvMzAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFJlY2VpcHQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTAuNXB4XSB0ZXh0LWVycm9yLTUwMCBmb250LXNlbWlib2xkIHB4LTEuNSBweS0wLjUgYmctZXJyb3ItNTAgZGFyazpiZy1lcnJvci01MDAvMTAgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIE5vIEJpbGxcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0VudHJ5KGVudHJ5KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1icmFuZC01MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25maXJtKGBEZWxldGUgZXhwZW5zZSBcIiR7ZW50cnkuZGVzY3JpcHRpb259XCI/YCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlRmluYW5jZUVudHJ5KGVudHJ5LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dUb2FzdCgnRmluYW5jZSBlbnRyeSBkZWxldGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWVycm9yLTYwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWVycm9yLTUwIGRhcms6aG92ZXI6YmctZXJyb3ItNTAwLzEwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSlcbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogNUIuIERFU0tUT1AgRVhQRU5TRVMgVEFCTEUgKFZpc2libGUgb24gPj0gNzY4cHgpICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2sgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgIDxUYWJsZT5cbiAgICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+RGF0ZSAvIFNlc3Npb248L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5DYXRlZ29yeTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8VGFibGVDZWxsIGlzSGVhZGVyIGNsYXNzTmFtZT1cInctWzMwMHB4XVwiPkRlc2NyaXB0aW9uICZhbXA7IFJvdXRlPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+UGFuY2hheWF0PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+QW1vdW50PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+QmlsbCBBdHRhY2htZW50PC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+U3RhdHVzPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXIgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPkFjdGlvbnM8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgPC9UYWJsZUhlYWRlcj5cbiAgICAgICAgICA8VGFibGVCb2R5PlxuICAgICAgICAgICAge2ZpbHRlcmVkRW50cmllcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNvbFNwYW49ezh9IGNsYXNzTmFtZT1cInB5LTEyIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIE5vIGV4cGVuc2UgZW50cmllcyBtYXRjaGluZyBjdXJyZW50IGNyaXRlcmlhLlxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgZmlsdGVyZWRFbnRyaWVzLm1hcCgoZW50cnkpID0+IChcbiAgICAgICAgICAgICAgICA8VGFibGVSb3cga2V5PXtlbnRyeS5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MC84MCBkYXJrOmhvdmVyOmJnLXdoaXRlL1swLjAyXSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgYmxvY2sgdGV4dC14c1wiPntlbnRyeS5kYXRlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2VudHJ5LnNlc3Npb25EYXkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zZXNzaW9uRGF5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwibGlnaHRcIiBzaXplPVwic21cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZW50cnkuY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBibG9jayB0ZXh0LXhzXCI+e2VudHJ5LmRlc2NyaXB0aW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2VudHJ5LnJlbWFya3MgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgYmxvY2tcIj57ZW50cnkucmVtYXJrc308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+e2VudHJ5LnBhbmNoYXlhdE5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+e2VudHJ5LnZpbGxhZ2VOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LWJvbGQgZm9udC1tb25vIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQteHMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAg4oK5e2VudHJ5LmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICB7ZW50cnkuYmlsbFVybCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdSZWNlaXB0KGVudHJ5KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgQmlsbFxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lcnJvci01MDAgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTWlzc2luZ1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0JhZGdlKGVudHJ5LnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbk5hdmlnYXRlKCdmaW5hbmNlLXN0YXRlbWVudCcsIGVudHJ5LmRyYWZ0SWQgfHwgZW50cnkuc2Vzc2lvbkRheSB8fCAnYWxsLWFwcHJvdmVkJylcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVmlldyBTdGF0ZW1lbnQgU2hlZXRcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nRW50cnkoZW50cnkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOnRleHQtYnJhbmQtNDAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IEVudHJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAge2VudHJ5LnN0YXR1cyAhPT0gJ0FwcHJvdmVkJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25VcGRhdGVGaW5hbmNlRW50cnkoZW50cnkuaWQsIHsgc3RhdHVzOiAnUGVuZGluZycgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1RvYXN0KCdFbnRyeSBzdWJtaXR0ZWQgZm9yIHJldmlldyEnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLXN1Y2Nlc3MtNTAgaG92ZXI6dGV4dC1zdWNjZXNzLTYwMCBkYXJrOmhvdmVyOmJnLXN1Y2Nlc3MtNTAwLzEwIGRhcms6aG92ZXI6dGV4dC1zdWNjZXNzLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTdWJtaXQgZm9yIFJldmlld1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmZpcm0oYERlbGV0ZSBmaW5hbmNlIGVudHJ5IFwiJHtlbnRyeS5kZXNjcmlwdGlvbn1cIj9gKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlRmluYW5jZUVudHJ5KGVudHJ5LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93VG9hc3QoJ0ZpbmFuY2UgZW50cnkgZGVsZXRlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWVycm9yLTUwIGhvdmVyOnRleHQtZXJyb3ItNjAwIGRhcms6aG92ZXI6YmctZXJyb3ItNTAwLzEwIGRhcms6aG92ZXI6dGV4dC1lcnJvci00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L1RhYmxlQm9keT5cbiAgICAgICAgPC9UYWJsZT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQmlsbCAvIFJlY2VpcHQgTGlnaHRib3ggTW9kYWwgKi99XG4gICAgICB7dmlld2luZ1JlY2VpcHQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS05MDAvNzUgYmFja2Ryb3AtYmx1ci1zbSB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBhbmltYXRlLWluIGZhZGUtaW4tMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCByb3VuZGVkLTJ4bCBzaGFkb3ctdGhlbWUteGwgbWF4LXctbGcgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGFuaW1hdGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctZ3JheS01MCBkYXJrOmJnLXdoaXRlL1swLjAyXSBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZpZXdpbmdSZWNlaXB0LmRlc2NyaXB0aW9ufTwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAge3ZpZXdpbmdSZWNlaXB0LmNhdGVnb3J5fSDigKIg4oK5e3ZpZXdpbmdSZWNlaXB0LmFtb3VudH1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld2luZ1JlY2VpcHQobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWdyYXktOTUwIGZsZXgganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIHNyYz17dmlld2luZ1JlY2VpcHQuYmlsbFVybH1cbiAgICAgICAgICAgICAgICBhbHQ9XCJSZWNlaXB0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC1bNjB2aF0gb2JqZWN0LWNvbnRhaW4gcm91bmRlZC14bFwiXG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG1heC13LVsyMDBweF1cIj5cbiAgICAgICAgICAgICAgICB7dmlld2luZ1JlY2VpcHQucmVtYXJrcyB8fCAnUmVjZWlwdCBkb2N1bWVudCBhdHRhY2hlZCd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdSZWNlaXB0KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHRleHQteHMgcm91bmRlZC14bCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRG9uZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFZGl0IFNpbmdsZSBFbnRyeSBNb2RhbCAqL31cbiAgICAgIHtlZGl0aW5nRW50cnkgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS05MDAvNzUgYmFja2Ryb3AtYmx1ci1zbSB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBhbmltYXRlLWluIGZhZGUtaW4tMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCByb3VuZGVkLTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy10aGVtZS14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHAtNSBzbTpwLTYgc3BhY2UteS00IGFuaW1hdGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWJyYW5kLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+RWRpdCBGaW5hbmNlIEVudHJ5PC9zcGFuPlxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0VudHJ5KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtzZXNzaW9ucz8uZmluZChzID0+IHMuaWQgPT09IGVkaXRpbmdFbnRyeS5zZXNzaW9uSWQpPy5zdGF0dXMgPT09ICdTdWJtaXR0ZWQnIHx8IHNlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ0FwcHJvdmVkJyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBwLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc3VjY2Vzcy01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlRoaXMgZmluYW5jZSBlbnRyeSBiZWxvbmdzIHRvIGEgc3VibWl0dGVkIHNlc3Npb24gYW5kIGNhbm5vdCBiZSBlZGl0ZWQuPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+RGVzY3JpcHRpb24gLyBSb3V0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0VudHJ5LmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0aW5nRW50cnkoeyAuLi5lZGl0aW5nRW50cnksIGRlc2NyaXB0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZXNzaW9ucz8uZmluZChzID0+IHMuaWQgPT09IGVkaXRpbmdFbnRyeS5zZXNzaW9uSWQpPy5zdGF0dXMgPT09ICdTdWJtaXR0ZWQnIHx8IHNlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ0FwcHJvdmVkJ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTkgcHgtMyBiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5TZXNzaW9uIC8gRGF5PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdFbnRyeS5zZXNzaW9uSWQgfHwgXCJub25lXCJ9XG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWw6IGFueSkgPT4gc2V0RWRpdGluZ0VudHJ5KHsgLi4uZWRpdGluZ0VudHJ5LCBzZXNzaW9uSWQ6IHZhbCA9PT0gXCJub25lXCIgPyB1bmRlZmluZWQgOiB2YWwgfSl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZXNzaW9ucz8uZmluZChzID0+IHMuaWQgPT09IGVkaXRpbmdFbnRyeS5zZXNzaW9uSWQpPy5zdGF0dXMgPT09ICdTdWJtaXR0ZWQnIHx8IHNlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ0FwcHJvdmVkJ31cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTZXNzaW9uXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIm5vbmVcIj5ObyBTZXNzaW9uPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9ucz8ubWFwKHMgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtzLmlkfSB2YWx1ZT17cy5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIERheSB7cy5kYXlOdW1iZXJ9ICh7cy5uYW1lfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+Q2F0ZWdvcnk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0VudHJ5LmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsOiBhbnkpID0+IHNldEVkaXRpbmdFbnRyeSh7IC4uLmVkaXRpbmdFbnRyeSwgY2F0ZWdvcnk6IHZhbCB9KX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Nlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ1N1Ym1pdHRlZCcgfHwgc2Vzc2lvbnM/LmZpbmQocyA9PiBzLmlkID09PSBlZGl0aW5nRW50cnkuc2Vzc2lvbklkKT8uc3RhdHVzID09PSAnQXBwcm92ZWQnfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14cyBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IENhdGVnb3J5XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlRyYXZlbFwiPlRyYXZlbDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZvb2RcIj5Gb29kPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiTWF0ZXJpYWxzXCI+TWF0ZXJpYWxzPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQWRtaW5cIj5BZG1pbjwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk90aGVyXCI+T3RoZXI8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5BbW91bnQgKOKCuSk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdFbnRyeS5hbW91bnR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nRW50cnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZWRpdGluZ0VudHJ5LFxuICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSB8fCAwLFxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Nlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ1N1Ym1pdHRlZCcgfHwgc2Vzc2lvbnM/LmZpbmQocyA9PiBzLmlkID09PSBlZGl0aW5nRW50cnkuc2Vzc2lvbklkKT8uc3RhdHVzID09PSAnQXBwcm92ZWQnfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlJlbWFya3M8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRpbmdFbnRyeS5yZW1hcmtzIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRpbmdFbnRyeSh7IC4uLmVkaXRpbmdFbnRyeSwgcmVtYXJrczogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzZXNzaW9ucz8uZmluZChzID0+IHMuaWQgPT09IGVkaXRpbmdFbnRyeS5zZXNzaW9uSWQpPy5zdGF0dXMgPT09ICdTdWJtaXR0ZWQnIHx8IHNlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ0FwcHJvdmVkJ31cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtOSBweC0zIGJnLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0VudHJ5KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyIHNoYWRvdy10aGVtZS14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvblVwZGF0ZUZpbmFuY2VFbnRyeShlZGl0aW5nRW50cnkuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVkaXRpbmdFbnRyeS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IGVkaXRpbmdFbnRyeS5jYXRlZ29yeSxcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBlZGl0aW5nRW50cnkuYW1vdW50LFxuICAgICAgICAgICAgICAgICAgICByZW1hcmtzOiBlZGl0aW5nRW50cnkucmVtYXJrcyxcbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvbklkOiBlZGl0aW5nRW50cnkuc2Vzc2lvbklkLFxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nRW50cnkobnVsbCk7XG4gICAgICAgICAgICAgICAgICBzaG93VG9hc3QoJ0ZpbmFuY2UgZW50cnkgdXBkYXRlZCcpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Nlc3Npb25zPy5maW5kKHMgPT4gcy5pZCA9PT0gZWRpdGluZ0VudHJ5LnNlc3Npb25JZCk/LnN0YXR1cyA9PT0gJ1N1Ym1pdHRlZCcgfHwgc2Vzc2lvbnM/LmZpbmQocyA9PiBzLmlkID09PSBlZGl0aW5nRW50cnkuc2Vzc2lvbklkKT8uc3RhdHVzID09PSAnQXBwcm92ZWQnfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBzaGFkb3ctdGhlbWUteHMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBTYXZlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE5ldyAvIEVkaXQgRmluYW5jZSBFbnRyeSBNb2RhbCAqL31cbiAgICAgIHtzaG93TW9kYWwgJiYgKFxuICAgICAgICA8TmV3RmluYW5jZU1vZGFsXG4gICAgICAgICAgaXNPcGVuPXtzaG93TW9kYWx9XG4gICAgICAgICAgaW5pdGlhbERyYWZ0PXtlZGl0aW5nRHJhZnR9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcbiAgICAgICAgICAgIHNldEVkaXRpbmdEcmFmdChudWxsKTtcbiAgICAgICAgICAgIGlmIChvbkNsb3NlTmV3TW9kYWwpIG9uQ2xvc2VOZXdNb2RhbCgpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2x1c3Rlck5hbWU9XCJEaGFybWFwdXJpXCJcbiAgICAgICAgICBjb2xsZWdlTmFtZT1cIksuUy5SYW5nYXNhbXkgY29sbGVnZSBvZiBUZWNobm9sb2d5XCJcbiAgICAgICAgICBzcG9jTmFtZT1cIk5hcmVuZGhhclwiXG4gICAgICAgICAgZmluYW5jZXJOYW1lPVwiVFFJIEZpbmFuY2UgVGVhbVwiXG4gICAgICAgICAgb25TYXZlRHJhZnRQYWNrYWdlPXsoZHJhZnRQa2cpID0+IHtcbiAgICAgICAgICAgIGlmIChvblNhdmVEcmFmdCkge1xuICAgICAgICAgICAgICBvblNhdmVEcmFmdChkcmFmdFBrZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzaG93VG9hc3QoYERyYWZ0IHNoZWV0IFwiJHtkcmFmdFBrZy5zZXNzaW9uRGF5fVwiIHNhdmVkIGluIFRRSSBmb3JtYXQhYCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvblN1Ym1pdEZpbmFuY2U9eyhlbnRyaWVzLCBpc0RyYWZ0KSA9PiB7XG4gICAgICAgICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KSA9PiBvbkFkZEZpbmFuY2VFbnRyeShlbnRyeSkpO1xuICAgICAgICAgICAgc2hvd1RvYXN0KGlzRHJhZnQgPyAnRHJhZnQgZW50cmllcyBzYXZlZCEnIDogJ0ZpbmFuY2UgZW50cmllcyBzdWJtaXR0ZWQgZm9yIGFwcHJvdmFsIScpO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9GaW5hbmNlVmlldy50c3gifQ==