import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SettingsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import { Check, Info, X, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const SettingsView = ({
  currentUser,
  onUpdateProfile
}) => {
  _s();
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem("tqi_personal_settings");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
      }
    }
    return {
      name: currentUser?.name || "MITHUN P",
      region: "India",
      language: "English",
      email: currentUser?.email || "mithunmithun71548@gmail.com",
      emailVerified: true,
      phone: currentUser?.phone || "",
      mailingAddress: ""
    };
  });
  const [toastMessage, setToastMessage] = useState(null);
  const [isEditingBasic, setIsEditingBasic] = useState(false);
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [isEditingPhone, setIsEditingPhone] = useState(false);
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [basicForm, setBasicForm] = useState({
    name: profile.name,
    region: profile.region,
    language: profile.language
  });
  const [emailForm, setEmailForm] = useState(profile.email);
  const [phoneForm, setPhoneForm] = useState(profile.phone);
  const [addressForm, setAddressForm] = useState(profile.mailingAddress);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4e3);
  };
  const saveProfile = (newProfile) => {
    setProfile(newProfile);
    localStorage.setItem("tqi_personal_settings", JSON.stringify(newProfile));
    if (onUpdateProfile) {
      onUpdateProfile(newProfile);
    }
  };
  const handleSaveBasic = (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      name: basicForm.name.trim() || profile.name,
      region: basicForm.region.trim() || profile.region,
      language: basicForm.language.trim() || profile.language
    };
    saveProfile(updated);
    setIsEditingBasic(false);
    showToast("Basic information saved successfully");
  };
  const handleSaveEmail = (e) => {
    e.preventDefault();
    if (!emailForm.trim()) return;
    const updated = {
      ...profile,
      email: emailForm.trim(),
      emailVerified: true
    };
    saveProfile(updated);
    setIsEditingEmail(false);
    showToast("Primary email updated");
  };
  const handleSavePhone = (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      phone: phoneForm.trim()
    };
    saveProfile(updated);
    setIsEditingPhone(false);
    showToast(phoneForm.trim() ? "Phone number saved" : "Phone number removed");
  };
  const handleSaveAddress = (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      mailingAddress: addressForm.trim()
    };
    saveProfile(updated);
    setIsEditingAddress(false);
    showToast(addressForm.trim() ? "Mailing address saved" : "Mailing address removed");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-4xl py-2 px-1 sm:px-4", children: [
    toastMessage && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-[99999] flex items-center gap-2 rounded-xl bg-gray-900 px-4 py-3 text-xs font-semibold text-white shadow-theme-lg dark:bg-white dark:text-gray-900 animate-in fade-in-0 slide-in-from-bottom-5", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-success-500 shrink-0" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 122,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: toastMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 123,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setToastMessage(null),
          className: "ml-2 text-gray-400 hover:text-white dark:hover:text-gray-900 cursor-pointer",
          children: /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 124,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Personal Information" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-sm text-gray-500 dark:text-gray-400", children: "Manage your basic information, contact methods, and addresses" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 139,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
      lineNumber: 135,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-12", children: [
      /* @__PURE__ */ jsxDEV("section", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-2", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg sm:text-xl font-bold text-gray-900 dark:text-white tracking-tight", children: "Basic Information" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 148,
            columnNumber: 13
          }, this),
          !isEditingBasic ? /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setBasicForm({
                  name: profile.name,
                  region: profile.region,
                  language: profile.language
                });
                setIsEditingBasic(true);
              },
              className: "text-xs sm:text-sm font-semibold text-gray-900 dark:text-gray-100 underline underline-offset-4 hover:text-brand-500 dark:hover:text-brand-400 transition cursor-pointer",
              children: "Edit"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 152,
              columnNumber: 13
            },
            this
          ) : /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setIsEditingBasic(false),
              className: "text-xs sm:text-sm font-semibold text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white transition cursor-pointer",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 167,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 147,
          columnNumber: 11
        }, this),
        !isEditingBasic ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 text-sm animate-in fade-in-0 duration-200", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1", children: "Name" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 180,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white uppercase tracking-tight text-sm sm:text-base", children: profile.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 183,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 179,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1", children: "Region" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 189,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base", children: profile.region }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 192,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 188,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1", children: "Language" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 198,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base", children: profile.language }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 201,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 197,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 178,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSaveBasic, className: "space-y-4 max-w-lg animate-in fade-in-0 duration-200", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5", children: "Full Name *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 209,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: basicForm.name,
                onChange: (e) => setBasicForm({ ...basicForm, name: e.target.value }),
                className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 212,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 208,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5", children: "Region *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 222,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: basicForm.region,
                onChange: (e) => setBasicForm({ ...basicForm, region: e.target.value }),
                className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 225,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 221,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1.5", children: "Language *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 235,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: basicForm.language,
                onChange: (e) => setBasicForm({ ...basicForm, language: e.target.value }),
                className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 238,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 234,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 pt-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
                children: "Save Changes"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 248,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setIsEditingBasic(false),
                className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 254,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 247,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 207,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 dark:border-gray-800 pb-2", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg sm:text-xl font-bold text-gray-900 dark:text-white tracking-tight", children: "Contact Information" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 269,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 268,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Primary Email" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 280,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Info, { className: "h-3.5 w-3.5 text-gray-400" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 281,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 279,
                  columnNumber: 19
                }, this),
                !isEditingEmail && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base", children: profile.email }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 285,
                    columnNumber: 23
                  }, this),
                  profile.emailVerified && /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 rounded-md bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400", children: [
                    /* @__PURE__ */ jsxDEV(Check, { className: "h-3.5 w-3.5 stroke-[2.5]" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                      lineNumber: 290,
                      columnNumber: 27
                    }, this),
                    "Verified"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 289,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 284,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 278,
                columnNumber: 17
              }, this),
              !isEditingEmail && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setEmailForm(profile.email);
                    setIsEditingEmail(true);
                  },
                  className: "text-xs sm:text-sm font-semibold text-gray-900 dark:text-gray-100 underline underline-offset-4 hover:text-brand-500 dark:hover:text-brand-400 transition cursor-pointer shrink-0 mt-1",
                  children: "Edit"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 299,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 277,
              columnNumber: 15
            }, this),
            isEditingEmail && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSaveEmail, className: "space-y-3 max-w-md animate-in fade-in-0 duration-200", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "email",
                  required: true,
                  value: emailForm,
                  onChange: (e) => setEmailForm(e.target.value),
                  className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 314,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
                    children: "Save Email"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 322,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsEditingEmail(false),
                    className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 328,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 321,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 313,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 276,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Primary Phone Number" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 345,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Info, { className: "h-3.5 w-3.5 text-gray-400" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 346,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 344,
                  columnNumber: 19
                }, this),
                !isEditingPhone && /* @__PURE__ */ jsxDEV("div", { children: profile.phone ? /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base font-mono", children: profile.phone }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 351,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base", children: "No phone number added" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 355,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 349,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 343,
                columnNumber: 17
              }, this),
              !isEditingPhone && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setPhoneForm(profile.phone);
                    setIsEditingPhone(true);
                  },
                  className: "text-xs sm:text-sm font-semibold text-gray-900 dark:text-gray-100 underline underline-offset-4 hover:text-brand-500 dark:hover:text-brand-400 transition cursor-pointer shrink-0 mt-1",
                  children: profile.phone ? "Edit" : "Add"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 364,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 342,
              columnNumber: 15
            }, this),
            isEditingPhone && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSavePhone, className: "space-y-3 max-w-md animate-in fade-in-0 duration-200", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "tel",
                  placeholder: "+91 98765 43210",
                  value: phoneForm,
                  onChange: (e) => setPhoneForm(e.target.value),
                  className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 379,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
                    children: "Save Phone"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 387,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIsEditingPhone(false),
                    className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                    lineNumber: 393,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 386,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 378,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 341,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-100 dark:border-gray-800 pb-2", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg sm:text-xl font-bold text-gray-900 dark:text-white tracking-tight", children: "Addresses" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 410,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 409,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Mailing" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 420,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Info, { className: "h-3.5 w-3.5 text-gray-400" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 421,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 419,
                columnNumber: 17
              }, this),
              !isEditingAddress && /* @__PURE__ */ jsxDEV("div", { children: profile.mailingAddress ? /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base whitespace-pre-line", children: profile.mailingAddress }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 426,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm sm:text-base", children: "No mailing address added" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 430,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 424,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 418,
              columnNumber: 15
            }, this),
            !isEditingAddress && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setAddressForm(profile.mailingAddress);
                  setIsEditingAddress(true);
                },
                className: "text-xs sm:text-sm font-semibold text-gray-900 dark:text-gray-100 underline underline-offset-4 hover:text-brand-500 dark:hover:text-brand-400 transition cursor-pointer shrink-0 mt-1",
                children: profile.mailingAddress ? "Edit" : "Add"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 439,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 417,
            columnNumber: 13
          }, this),
          isEditingAddress && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSaveAddress, className: "space-y-3 max-w-lg animate-in fade-in-0 duration-200", children: [
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 3,
                placeholder: "e.g. 12/45, Gandhi Street, Dharmapuri, Tamil Nadu - 636701",
                value: addressForm,
                onChange: (e) => setAddressForm(e.target.value),
                className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-sm text-gray-900 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white resize-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                lineNumber: 454,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
                  children: "Save Address"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 462,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setIsEditingAddress(false),
                  className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
                  lineNumber: 468,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
              lineNumber: 461,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
            lineNumber: 453,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
          lineNumber: 415,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
        lineNumber: 408,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx",
    lineNumber: 118,
    columnNumber: 5
  }, this);
};
_s(SettingsView, "yV34CEZllpf4RgbMauqOH6fpx8E=");
_c = SettingsView;
var _c;
$RefreshReg$(_c, "SettingsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SettingsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhVOztBQXpIVixTQUFnQkEsZ0JBQWdCO0FBQ2hDLFNBQVNDLE9BQU9DLE1BQU1DLEdBQUdDLG9CQUFvQjtBQWV0QyxhQUFNQyxlQUE0Q0EsQ0FBQztBQUFBLEVBQ3hEQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUVKLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJVixTQUFTLE1BQU07QUFDM0MsVUFBTVcsUUFBUUMsYUFBYUMsUUFBUSx1QkFBdUI7QUFDMUQsUUFBSUYsT0FBTztBQUNULFVBQUk7QUFBRSxlQUFPRyxLQUFLQyxNQUFNSixLQUFLO0FBQUEsTUFBRyxTQUFTSyxHQUFHO0FBQUEsTUFBQztBQUFBLElBQy9DO0FBQ0EsV0FBTztBQUFBLE1BQ0xDLE1BQU1YLGFBQWFXLFFBQVE7QUFBQSxNQUMzQkMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxPQUFPZCxhQUFhYyxTQUFTO0FBQUEsTUFDN0JDLGVBQWU7QUFBQSxNQUNmQyxPQUFPaEIsYUFBYWdCLFNBQVM7QUFBQSxNQUM3QkMsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxFQUNGLENBQUM7QUFFRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXpCLFNBQXdCLElBQUk7QUFHcEUsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUM0QixnQkFBZ0JDLGlCQUFpQixJQUFJN0IsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzhCLGdCQUFnQkMsaUJBQWlCLElBQUkvQixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDZ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWpDLFNBQVMsS0FBSztBQUc5RCxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTO0FBQUEsSUFDekNpQixNQUFNUixRQUFRUTtBQUFBQSxJQUNkQyxRQUFRVCxRQUFRUztBQUFBQSxJQUNoQkMsVUFBVVYsUUFBUVU7QUFBQUEsRUFDcEIsQ0FBQztBQUNELFFBQU0sQ0FBQ2lCLFdBQVdDLFlBQVksSUFBSXJDLFNBQVNTLFFBQVFXLEtBQUs7QUFDeEQsUUFBTSxDQUFDa0IsV0FBV0MsWUFBWSxJQUFJdkMsU0FBU1MsUUFBUWEsS0FBSztBQUN4RCxRQUFNLENBQUNrQixhQUFhQyxjQUFjLElBQUl6QyxTQUFTUyxRQUFRYyxjQUFjO0FBRXJFLFFBQU1tQixZQUFZQSxDQUFDQyxRQUFnQjtBQUNqQ2xCLG9CQUFnQmtCLEdBQUc7QUFDbkJDLGVBQVcsTUFBTW5CLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtBQUFBLEVBQzlDO0FBRUEsUUFBTW9CLGNBQWNBLENBQUNDLGVBQStCO0FBQ2xEcEMsZUFBV29DLFVBQVU7QUFDckJsQyxpQkFBYW1DLFFBQVEseUJBQXlCakMsS0FBS2tDLFVBQVVGLFVBQVUsQ0FBQztBQUN4RSxRQUFJdkMsaUJBQWlCO0FBQ25CQSxzQkFBZ0J1QyxVQUFVO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTUcsa0JBQWtCQSxDQUFDakMsTUFBdUI7QUFDOUNBLE1BQUVrQyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVU7QUFBQSxNQUNkLEdBQUcxQztBQUFBQSxNQUNIUSxNQUFNaUIsVUFBVWpCLEtBQUttQyxLQUFLLEtBQUszQyxRQUFRUTtBQUFBQSxNQUN2Q0MsUUFBUWdCLFVBQVVoQixPQUFPa0MsS0FBSyxLQUFLM0MsUUFBUVM7QUFBQUEsTUFDM0NDLFVBQVVlLFVBQVVmLFNBQVNpQyxLQUFLLEtBQUszQyxRQUFRVTtBQUFBQSxJQUNqRDtBQUNBMEIsZ0JBQVlNLE9BQU87QUFDbkJ4QixzQkFBa0IsS0FBSztBQUN2QmUsY0FBVSxzQ0FBc0M7QUFBQSxFQUNsRDtBQUVBLFFBQU1XLGtCQUFrQkEsQ0FBQ3JDLE1BQXVCO0FBQzlDQSxNQUFFa0MsZUFBZTtBQUNqQixRQUFJLENBQUNkLFVBQVVnQixLQUFLLEVBQUc7QUFDdkIsVUFBTUQsVUFBVTtBQUFBLE1BQ2QsR0FBRzFDO0FBQUFBLE1BQ0hXLE9BQU9nQixVQUFVZ0IsS0FBSztBQUFBLE1BQ3RCL0IsZUFBZTtBQUFBLElBQ2pCO0FBQ0F3QixnQkFBWU0sT0FBTztBQUNuQnRCLHNCQUFrQixLQUFLO0FBQ3ZCYSxjQUFVLHVCQUF1QjtBQUFBLEVBQ25DO0FBRUEsUUFBTVksa0JBQWtCQSxDQUFDdEMsTUFBdUI7QUFDOUNBLE1BQUVrQyxlQUFlO0FBQ2pCLFVBQU1DLFVBQVU7QUFBQSxNQUNkLEdBQUcxQztBQUFBQSxNQUNIYSxPQUFPZ0IsVUFBVWMsS0FBSztBQUFBLElBQ3hCO0FBQ0FQLGdCQUFZTSxPQUFPO0FBQ25CcEIsc0JBQWtCLEtBQUs7QUFDdkJXLGNBQVVKLFVBQVVjLEtBQUssSUFBSSx1QkFBdUIsc0JBQXNCO0FBQUEsRUFDNUU7QUFFQSxRQUFNRyxvQkFBb0JBLENBQUN2QyxNQUF1QjtBQUNoREEsTUFBRWtDLGVBQWU7QUFDakIsVUFBTUMsVUFBVTtBQUFBLE1BQ2QsR0FBRzFDO0FBQUFBLE1BQ0hjLGdCQUFnQmlCLFlBQVlZLEtBQUs7QUFBQSxJQUNuQztBQUNBUCxnQkFBWU0sT0FBTztBQUNuQmxCLHdCQUFvQixLQUFLO0FBQ3pCUyxjQUFVRixZQUFZWSxLQUFLLElBQUksMEJBQTBCLHlCQUF5QjtBQUFBLEVBQ3BGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsc0NBRVo1QjtBQUFBQSxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsMk5BQ2I7QUFBQSw2QkFBQyxnQkFBYSxXQUFVLHVDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsVUFBTUEsMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLE1BQ3BCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1DLGdCQUFnQixJQUFJO0FBQUEsVUFDbkMsV0FBVTtBQUFBLFVBRVYsaUNBQUMsS0FBRSxXQUFVLGlCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUE7QUFBQSxRQUw1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSwrRUFBNkUsb0NBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLG1EQUFpRCw2RUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxjQUViO0FBQUEsNkJBQUMsYUFBUSxXQUFVLGFBQ2pCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDZFQUEyRSxpQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0MsQ0FBQ0MsaUJBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUNiUyw2QkFBYTtBQUFBLGtCQUNYbEIsTUFBTVIsUUFBUVE7QUFBQUEsa0JBQ2RDLFFBQVFULFFBQVFTO0FBQUFBLGtCQUNoQkMsVUFBVVYsUUFBUVU7QUFBQUEsZ0JBQ3BCLENBQUM7QUFDRFEsa0NBQWtCLElBQUk7QUFBQSxjQUN4QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQXlLO0FBQUE7QUFBQSxZQVZyTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQSxJQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1BLGtCQUFrQixLQUFLO0FBQUEsY0FDdEMsV0FBVTtBQUFBLGNBQXVJO0FBQUE7QUFBQSxZQUhuSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVDLENBQUNELGlCQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsbUVBQWlFLG9CQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUseUZBQ2JqQixrQkFBUVEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1FQUFpRSxzQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGdFQUNiUixrQkFBUVMsVUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1FQUFpRSx3QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGdFQUNiVCxrQkFBUVUsWUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQSxJQUVBLHVCQUFDLFVBQUssVUFBVThCLGlCQUFpQixXQUFVLHdEQUN6QztBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUVBQW1FLDJCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLE9BQU9mLFVBQVVqQjtBQUFBQSxnQkFDakIsVUFBVSxDQUFDRCxNQUFNbUIsYUFBYSxFQUFFLEdBQUdELFdBQVdqQixNQUFNRCxFQUFFd0MsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBQ3BFLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VNO0FBQUEsZUFUek07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxRUFBbUUsd0JBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsT0FBT3ZCLFVBQVVoQjtBQUFBQSxnQkFDakIsVUFBVSxDQUFDRixNQUFNbUIsYUFBYSxFQUFFLEdBQUdELFdBQVdoQixRQUFRRixFQUFFd0MsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBQ3RFLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VNO0FBQUEsZUFUek07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxRUFBbUUsMEJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsT0FBT3ZCLFVBQVVmO0FBQUFBLGdCQUNqQixVQUFVLENBQUNILE1BQU1tQixhQUFhLEVBQUUsR0FBR0QsV0FBV2YsVUFBVUgsRUFBRXdDLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGdCQUN4RSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt1TTtBQUFBLGVBVHpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFBaUk7QUFBQTtBQUFBLGNBRjdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU05QixrQkFBa0IsS0FBSztBQUFBLGdCQUN0QyxXQUFVO0FBQUEsZ0JBQThMO0FBQUE7QUFBQSxjQUgxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1REE7QUFBQSxXQXBISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0hBO0FBQUEsTUFHQSx1QkFBQyxhQUFRLFdBQVUsYUFDakI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQ2IsaUNBQUMsUUFBRyxXQUFVLDZFQUEyRSxtQ0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUscUJBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGtGQUNiO0FBQUEseUNBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQjtBQUFBLGtCQUNuQix1QkFBQyxRQUFLLFdBQVUsK0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEscUJBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQyxDQUFDQyxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsZ0VBQ2JuQixrQkFBUVcsU0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0NYLFFBQVFZLGlCQUNQLHVCQUFDLFVBQUssV0FBVSw2SkFDZDtBQUFBLDJDQUFDLFNBQU0sV0FBVSw4QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQTtBQUFBLHVCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLG1CQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCQTtBQUFBLGNBRUMsQ0FBQ08sa0JBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNiUyxpQ0FBYTVCLFFBQVFXLEtBQUs7QUFDMUJTLHNDQUFrQixJQUFJO0FBQUEsa0JBQ3hCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUF1TDtBQUFBO0FBQUEsZ0JBTm5NO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNBO0FBQUEsaUJBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsWUFFQ0Qsa0JBQ0MsdUJBQUMsVUFBSyxVQUFVeUIsaUJBQWlCLFdBQVUsd0RBQ3pDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsT0FBT2pCO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3BCLE1BQU1xQixhQUFhckIsRUFBRXdDLE9BQU9DLEtBQUs7QUFBQSxrQkFDNUMsV0FBVTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS3VNO0FBQUEsY0FFdk0sdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFBaUk7QUFBQTtBQUFBLGtCQUY3STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNNUIsa0JBQWtCLEtBQUs7QUFBQSxvQkFDdEMsV0FBVTtBQUFBLG9CQUE4TDtBQUFBO0FBQUEsa0JBSDFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxlQTVESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThEQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxrRkFDYjtBQUFBLHlDQUFDLFVBQUssb0NBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQSxrQkFDMUIsdUJBQUMsUUFBSyxXQUFVLCtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLHFCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0MsQ0FBQ0Msa0JBQ0EsdUJBQUMsU0FDRXJCLGtCQUFRYSxRQUNQLHVCQUFDLFVBQUssV0FBVSwwRUFDYmIsa0JBQVFhLFNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxnRUFBOEQscUNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsbUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsY0FFQyxDQUFDUSxrQkFDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ2JTLGlDQUFhOUIsUUFBUWEsS0FBSztBQUMxQlMsc0NBQWtCLElBQUk7QUFBQSxrQkFDeEI7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVR0QixrQkFBUWEsUUFBUSxTQUFTO0FBQUE7QUFBQSxnQkFSNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxpQkEvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVDUSxrQkFDQyx1QkFBQyxVQUFLLFVBQVV3QixpQkFBaUIsV0FBVSx3REFDekM7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9oQjtBQUFBQSxrQkFDUCxVQUFVLENBQUN0QixNQUFNdUIsYUFBYXZCLEVBQUV3QyxPQUFPQyxLQUFLO0FBQUEsa0JBQzVDLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUt1TTtBQUFBLGNBRXZNLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQWlJO0FBQUE7QUFBQSxrQkFGN0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTTFCLGtCQUFrQixLQUFLO0FBQUEsb0JBQ3RDLFdBQVU7QUFBQSxvQkFBOEw7QUFBQTtBQUFBLGtCQUgxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsZUE1REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4REE7QUFBQSxhQWpJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0lBO0FBQUEsV0F6SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBJQTtBQUFBLE1BR0EsdUJBQUMsYUFBUSxXQUFVLGFBQ2pCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUNiLGlDQUFDLFFBQUcsV0FBVSw2RUFBMkUseUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSx1Q0FBQyxVQUFLLHVCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWE7QUFBQSxnQkFDYix1QkFBQyxRQUFLLFdBQVUsK0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJDO0FBQUEsbUJBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNDLENBQUNDLG9CQUNBLHVCQUFDLFNBQ0V2QixrQkFBUWMsaUJBQ1AsdUJBQUMsVUFBSyxXQUFVLG9GQUNiZCxrQkFBUWMsa0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxnRUFBOEQsd0NBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsaUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsWUFFQyxDQUFDUyxvQkFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYlMsaUNBQWVoQyxRQUFRYyxjQUFjO0FBQ3JDVSxzQ0FBb0IsSUFBSTtBQUFBLGdCQUMxQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVHhCLGtCQUFRYyxpQkFBaUIsU0FBUztBQUFBO0FBQUEsY0FSckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlDQTtBQUFBLFVBRUNTLG9CQUNDLHVCQUFDLFVBQUssVUFBVXVCLG1CQUFtQixXQUFVLHdEQUMzQztBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTTtBQUFBLGdCQUNOLGFBQVk7QUFBQSxnQkFDWixPQUFPZjtBQUFBQSxnQkFDUCxVQUFVLENBQUN4QixNQUFNeUIsZUFBZXpCLEVBQUV3QyxPQUFPQyxLQUFLO0FBQUEsZ0JBQzlDLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3FOO0FBQUEsWUFFck4sdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBaUk7QUFBQTtBQUFBLGdCQUY3STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTXhCLG9CQUFvQixLQUFLO0FBQUEsa0JBQ3hDLFdBQVU7QUFBQSxrQkFBOEw7QUFBQTtBQUFBLGdCQUgxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErREE7QUFBQSxXQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUVBO0FBQUEsU0EvVUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdWQTtBQUFBLE9BMVdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyV0E7QUFFSjtBQUFFekIsR0FsZFdILGNBQXlDO0FBQUEsS0FBekNBO0FBQXlDLElBQUFxRDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNoZWNrIiwiSW5mbyIsIlgiLCJDaGVja0NpcmNsZTIiLCJTZXR0aW5nc1ZpZXciLCJjdXJyZW50VXNlciIsIm9uVXBkYXRlUHJvZmlsZSIsIl9zIiwicHJvZmlsZSIsInNldFByb2ZpbGUiLCJzYXZlZCIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJlIiwibmFtZSIsInJlZ2lvbiIsImxhbmd1YWdlIiwiZW1haWwiLCJlbWFpbFZlcmlmaWVkIiwicGhvbmUiLCJtYWlsaW5nQWRkcmVzcyIsInRvYXN0TWVzc2FnZSIsInNldFRvYXN0TWVzc2FnZSIsImlzRWRpdGluZ0Jhc2ljIiwic2V0SXNFZGl0aW5nQmFzaWMiLCJpc0VkaXRpbmdFbWFpbCIsInNldElzRWRpdGluZ0VtYWlsIiwiaXNFZGl0aW5nUGhvbmUiLCJzZXRJc0VkaXRpbmdQaG9uZSIsImlzRWRpdGluZ0FkZHJlc3MiLCJzZXRJc0VkaXRpbmdBZGRyZXNzIiwiYmFzaWNGb3JtIiwic2V0QmFzaWNGb3JtIiwiZW1haWxGb3JtIiwic2V0RW1haWxGb3JtIiwicGhvbmVGb3JtIiwic2V0UGhvbmVGb3JtIiwiYWRkcmVzc0Zvcm0iLCJzZXRBZGRyZXNzRm9ybSIsInNob3dUb2FzdCIsIm1zZyIsInNldFRpbWVvdXQiLCJzYXZlUHJvZmlsZSIsIm5ld1Byb2ZpbGUiLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiaGFuZGxlU2F2ZUJhc2ljIiwicHJldmVudERlZmF1bHQiLCJ1cGRhdGVkIiwidHJpbSIsImhhbmRsZVNhdmVFbWFpbCIsImhhbmRsZVNhdmVQaG9uZSIsImhhbmRsZVNhdmVBZGRyZXNzIiwidGFyZ2V0IiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXR0aW5nc1ZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ2hlY2ssIEluZm8sIFgsIENoZWNrQ2lyY2xlMiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuaW50ZXJmYWNlIFNldHRpbmdzVmlld1Byb3BzIHtcbiAgY3VycmVudFVzZXI/OiB7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIGVtYWlsOiBzdHJpbmc7XG4gICAgcm9sZT86IHN0cmluZztcbiAgICBwaG9uZT86IHN0cmluZztcbiAgICByZWdpb24/OiBzdHJpbmc7XG4gICAgbGFuZ3VhZ2U/OiBzdHJpbmc7XG4gICAgbWFpbGluZ0FkZHJlc3M/OiBzdHJpbmc7XG4gIH07XG4gIG9uVXBkYXRlUHJvZmlsZT86ICh1cGRhdGVkOiBhbnkpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTZXR0aW5nc1ZpZXc6IFJlYWN0LkZDPFNldHRpbmdzVmlld1Byb3BzPiA9ICh7XG4gIGN1cnJlbnRVc2VyLFxuICBvblVwZGF0ZVByb2ZpbGUsXG59KSA9PiB7XG4gIC8vIExvYWQgc2F2ZWQgcHJvZmlsZSBvciBkZWZhdWx0cyBtYXRjaGluZyB0aGUgZGVzaWduXG4gIGNvbnN0IFtwcm9maWxlLCBzZXRQcm9maWxlXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidHFpX3BlcnNvbmFsX3NldHRpbmdzXCIpO1xuICAgIGlmIChzYXZlZCkge1xuICAgICAgdHJ5IHsgcmV0dXJuIEpTT04ucGFyc2Uoc2F2ZWQpOyB9IGNhdGNoIChlKSB7fVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogY3VycmVudFVzZXI/Lm5hbWUgfHwgXCJNSVRIVU4gUFwiLFxuICAgICAgcmVnaW9uOiBcIkluZGlhXCIsXG4gICAgICBsYW5ndWFnZTogXCJFbmdsaXNoXCIsXG4gICAgICBlbWFpbDogY3VycmVudFVzZXI/LmVtYWlsIHx8IFwibWl0aHVubWl0aHVuNzE1NDhAZ21haWwuY29tXCIsXG4gICAgICBlbWFpbFZlcmlmaWVkOiB0cnVlLFxuICAgICAgcGhvbmU6IGN1cnJlbnRVc2VyPy5waG9uZSB8fCBcIlwiLFxuICAgICAgbWFpbGluZ0FkZHJlc3M6IFwiXCIsXG4gICAgfTtcbiAgfSk7XG5cbiAgY29uc3QgW3RvYXN0TWVzc2FnZSwgc2V0VG9hc3RNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIElubGluZSBlZGl0IHRvZ2dsZSBzdGF0ZXNcbiAgY29uc3QgW2lzRWRpdGluZ0Jhc2ljLCBzZXRJc0VkaXRpbmdCYXNpY10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0VkaXRpbmdFbWFpbCwgc2V0SXNFZGl0aW5nRW1haWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNFZGl0aW5nUGhvbmUsIHNldElzRWRpdGluZ1Bob25lXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRWRpdGluZ0FkZHJlc3MsIHNldElzRWRpdGluZ0FkZHJlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIEZvcm0gc3RhdGVzXG4gIGNvbnN0IFtiYXNpY0Zvcm0sIHNldEJhc2ljRm9ybV0gPSB1c2VTdGF0ZSh7XG4gICAgbmFtZTogcHJvZmlsZS5uYW1lLFxuICAgIHJlZ2lvbjogcHJvZmlsZS5yZWdpb24sXG4gICAgbGFuZ3VhZ2U6IHByb2ZpbGUubGFuZ3VhZ2UsXG4gIH0pO1xuICBjb25zdCBbZW1haWxGb3JtLCBzZXRFbWFpbEZvcm1dID0gdXNlU3RhdGUocHJvZmlsZS5lbWFpbCk7XG4gIGNvbnN0IFtwaG9uZUZvcm0sIHNldFBob25lRm9ybV0gPSB1c2VTdGF0ZShwcm9maWxlLnBob25lKTtcbiAgY29uc3QgW2FkZHJlc3NGb3JtLCBzZXRBZGRyZXNzRm9ybV0gPSB1c2VTdGF0ZShwcm9maWxlLm1haWxpbmdBZGRyZXNzKTtcblxuICBjb25zdCBzaG93VG9hc3QgPSAobXNnOiBzdHJpbmcpID0+IHtcbiAgICBzZXRUb2FzdE1lc3NhZ2UobXNnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFRvYXN0TWVzc2FnZShudWxsKSwgNDAwMCk7XG4gIH07XG5cbiAgY29uc3Qgc2F2ZVByb2ZpbGUgPSAobmV3UHJvZmlsZTogdHlwZW9mIHByb2ZpbGUpID0+IHtcbiAgICBzZXRQcm9maWxlKG5ld1Byb2ZpbGUpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidHFpX3BlcnNvbmFsX3NldHRpbmdzXCIsIEpTT04uc3RyaW5naWZ5KG5ld1Byb2ZpbGUpKTtcbiAgICBpZiAob25VcGRhdGVQcm9maWxlKSB7XG4gICAgICBvblVwZGF0ZVByb2ZpbGUobmV3UHJvZmlsZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVCYXNpYyA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgIC4uLnByb2ZpbGUsXG4gICAgICBuYW1lOiBiYXNpY0Zvcm0ubmFtZS50cmltKCkgfHwgcHJvZmlsZS5uYW1lLFxuICAgICAgcmVnaW9uOiBiYXNpY0Zvcm0ucmVnaW9uLnRyaW0oKSB8fCBwcm9maWxlLnJlZ2lvbixcbiAgICAgIGxhbmd1YWdlOiBiYXNpY0Zvcm0ubGFuZ3VhZ2UudHJpbSgpIHx8IHByb2ZpbGUubGFuZ3VhZ2UsXG4gICAgfTtcbiAgICBzYXZlUHJvZmlsZSh1cGRhdGVkKTtcbiAgICBzZXRJc0VkaXRpbmdCYXNpYyhmYWxzZSk7XG4gICAgc2hvd1RvYXN0KFwiQmFzaWMgaW5mb3JtYXRpb24gc2F2ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVFbWFpbCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFlbWFpbEZvcm0udHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgIC4uLnByb2ZpbGUsXG4gICAgICBlbWFpbDogZW1haWxGb3JtLnRyaW0oKSxcbiAgICAgIGVtYWlsVmVyaWZpZWQ6IHRydWUsXG4gICAgfTtcbiAgICBzYXZlUHJvZmlsZSh1cGRhdGVkKTtcbiAgICBzZXRJc0VkaXRpbmdFbWFpbChmYWxzZSk7XG4gICAgc2hvd1RvYXN0KFwiUHJpbWFyeSBlbWFpbCB1cGRhdGVkXCIpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVQaG9uZSA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgY29uc3QgdXBkYXRlZCA9IHtcbiAgICAgIC4uLnByb2ZpbGUsXG4gICAgICBwaG9uZTogcGhvbmVGb3JtLnRyaW0oKSxcbiAgICB9O1xuICAgIHNhdmVQcm9maWxlKHVwZGF0ZWQpO1xuICAgIHNldElzRWRpdGluZ1Bob25lKGZhbHNlKTtcbiAgICBzaG93VG9hc3QocGhvbmVGb3JtLnRyaW0oKSA/IFwiUGhvbmUgbnVtYmVyIHNhdmVkXCIgOiBcIlBob25lIG51bWJlciByZW1vdmVkXCIpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVBZGRyZXNzID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCB1cGRhdGVkID0ge1xuICAgICAgLi4ucHJvZmlsZSxcbiAgICAgIG1haWxpbmdBZGRyZXNzOiBhZGRyZXNzRm9ybS50cmltKCksXG4gICAgfTtcbiAgICBzYXZlUHJvZmlsZSh1cGRhdGVkKTtcbiAgICBzZXRJc0VkaXRpbmdBZGRyZXNzKGZhbHNlKTtcbiAgICBzaG93VG9hc3QoYWRkcmVzc0Zvcm0udHJpbSgpID8gXCJNYWlsaW5nIGFkZHJlc3Mgc2F2ZWRcIiA6IFwiTWFpbGluZyBhZGRyZXNzIHJlbW92ZWRcIik7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy00eGwgcHktMiBweC0xIHNtOnB4LTRcIj5cbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XG4gICAgICB7dG9hc3RNZXNzYWdlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWdyYXktOTAwIHB4LTQgcHktMyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUtbGcgZGFyazpiZy13aGl0ZSBkYXJrOnRleHQtZ3JheS05MDAgYW5pbWF0ZS1pbiBmYWRlLWluLTAgc2xpZGUtaW4tZnJvbS1ib3R0b20tNVwiPlxuICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXN1Y2Nlc3MtNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3Bhbj57dG9hc3RNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRvYXN0TWVzc2FnZShudWxsKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGRhcms6aG92ZXI6dGV4dC1ncmF5LTkwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNYWluIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTBcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgIFBlcnNvbmFsIEluZm9ybWF0aW9uXG4gICAgICAgIDwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgTWFuYWdlIHlvdXIgYmFzaWMgaW5mb3JtYXRpb24sIGNvbnRhY3QgbWV0aG9kcywgYW5kIGFkZHJlc3Nlc1xuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEyXCI+XG4gICAgICAgIHsvKiBCYXNpYyBJbmZvcm1hdGlvbiBTZWN0aW9uICovfVxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgcGItMlwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgc206dGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgQmFzaWMgSW5mb3JtYXRpb25cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICB7IWlzRWRpdGluZ0Jhc2ljID8gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0QmFzaWNGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogcHJvZmlsZS5uYW1lLFxuICAgICAgICAgICAgICAgICAgICByZWdpb246IHByb2ZpbGUucmVnaW9uLFxuICAgICAgICAgICAgICAgICAgICBsYW5ndWFnZTogcHJvZmlsZS5sYW5ndWFnZSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgc2V0SXNFZGl0aW5nQmFzaWModHJ1ZSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTEwMCB1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC00IGhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBFZGl0XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRWRpdGluZ0Jhc2ljKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7IWlzRWRpdGluZ0Jhc2ljID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgdGV4dC1zbSBhbmltYXRlLWluIGZhZGUtaW4tMCBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIE5hbWVcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy10aWdodCB0ZXh0LXNtIHNtOnRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICAgICAge3Byb2ZpbGUubmFtZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICBSZWdpb25cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICB7cHJvZmlsZS5yZWdpb259XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgTGFuZ3VhZ2VcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICB7cHJvZmlsZS5sYW5ndWFnZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlQmFzaWN9IGNsYXNzTmFtZT1cInNwYWNlLXktNCBtYXgtdy1sZyBhbmltYXRlLWluIGZhZGUtaW4tMCBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSAqXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YmFzaWNGb3JtLm5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJhc2ljRm9ybSh7IC4uLmJhc2ljRm9ybSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIFJlZ2lvbiAqXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YmFzaWNGb3JtLnJlZ2lvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmFzaWNGb3JtKHsgLi4uYmFzaWNGb3JtLCByZWdpb246IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBMYW5ndWFnZSAqXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YmFzaWNGb3JtLmxhbmd1YWdlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCYXNpY0Zvcm0oeyAuLi5iYXNpY0Zvcm0sIGxhbmd1YWdlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB0LTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctYnJhbmQtNTAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFNhdmUgQ2hhbmdlc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFZGl0aW5nQmFzaWMoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIENvbnRhY3QgSW5mb3JtYXRpb24gU2VjdGlvbiAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgcGItMlwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgc206dGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgQ29udGFjdCBJbmZvcm1hdGlvblxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04IHRleHQtc21cIj5cbiAgICAgICAgICAgIHsvKiBQcmltYXJ5IEVtYWlsICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlByaW1hcnkgRW1haWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7IWlzRWRpdGluZ0VtYWlsICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9maWxlLmVtYWlsfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7cHJvZmlsZS5lbWFpbFZlcmlmaWVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbWQgYmctZW1lcmFsZC01MCBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOmJnLWVtZXJhbGQtNTAwLzEwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgc3Ryb2tlLVsyLjVdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmVyaWZpZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7IWlzRWRpdGluZ0VtYWlsICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFbWFpbEZvcm0ocHJvZmlsZS5lbWFpbCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0SXNFZGl0aW5nRW1haWwodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktMTAwIHVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTQgaG92ZXI6dGV4dC1icmFuZC01MDAgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyIHNocmluay0wIG10LTFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBFZGl0XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7aXNFZGl0aW5nRW1haWwgJiYgKFxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlRW1haWx9IGNsYXNzTmFtZT1cInNwYWNlLXktMyBtYXgtdy1tZCBhbmltYXRlLWluIGZhZGUtaW4tMCBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWxGb3JtfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsRm9ybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIFNhdmUgRW1haWxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0VkaXRpbmdFbWFpbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBQcmltYXJ5IFBob25lIE51bWJlciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QcmltYXJ5IFBob25lIE51bWJlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHshaXNFZGl0aW5nUGhvbmUgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIHtwcm9maWxlLnBob25lID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cHJvZmlsZS5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHBob25lIG51bWJlciBhZGRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHshaXNFZGl0aW5nUGhvbmUgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHNldFBob25lRm9ybShwcm9maWxlLnBob25lKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc0VkaXRpbmdQaG9uZSh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtZ3JheS0xMDAgdW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtNCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmhvdmVyOnRleHQtYnJhbmQtNDAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgc2hyaW5rLTAgbXQtMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9maWxlLnBob25lID8gXCJFZGl0XCIgOiBcIkFkZFwifVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2lzRWRpdGluZ1Bob25lICYmIChcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZVBob25lfSBjbGFzc05hbWU9XCJzcGFjZS15LTMgbWF4LXctbWQgYW5pbWF0ZS1pbiBmYWRlLWluLTAgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiKzkxIDk4NzY1IDQzMjEwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bob25lRm9ybX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG9uZUZvcm0oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1icmFuZC01MDAgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBTYXZlIFBob25lXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFZGl0aW5nUGhvbmUoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIEFkZHJlc3NlcyBTZWN0aW9uICovfVxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBwYi0yXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBzbTp0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICBBZGRyZXNzZXNcbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICB7LyogTWFpbGluZyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5NYWlsaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgeyFpc0VkaXRpbmdBZGRyZXNzICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9maWxlLm1haWxpbmdBZGRyZXNzID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXNtIHNtOnRleHQtYmFzZSB3aGl0ZXNwYWNlLXByZS1saW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cHJvZmlsZS5tYWlsaW5nQWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBObyBtYWlsaW5nIGFkZHJlc3MgYWRkZWRcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7IWlzRWRpdGluZ0FkZHJlc3MgJiYgKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRBZGRyZXNzRm9ybShwcm9maWxlLm1haWxpbmdBZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0SXNFZGl0aW5nQWRkcmVzcyh0cnVlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTEwMCB1bmRlcmxpbmUgdW5kZXJsaW5lLW9mZnNldC00IGhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBzaHJpbmstMCBtdC0xXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7cHJvZmlsZS5tYWlsaW5nQWRkcmVzcyA/IFwiRWRpdFwiIDogXCJBZGRcIn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7aXNFZGl0aW5nQWRkcmVzcyAmJiAoXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlQWRkcmVzc30gY2xhc3NOYW1lPVwic3BhY2UteS0zIG1heC13LWxnIGFuaW1hdGUtaW4gZmFkZS1pbi0wIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiAxMi80NSwgR2FuZGhpIFN0cmVldCwgRGhhcm1hcHVyaSwgVGFtaWwgTmFkdSAtIDYzNjcwMVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YWRkcmVzc0Zvcm19XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFkZHJlc3NGb3JtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgcmVzaXplLW5vbmVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1icmFuZC01MDAgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFNhdmUgQWRkcmVzc1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0VkaXRpbmdBZGRyZXNzKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU2V0dGluZ3NWaWV3LnRzeCJ9