import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DateChangeRequestView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { Calendar, XCircle, Send, Search, Eye } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const DateChangeRequestView = ({
  dateChangeRequests,
  sessions,
  currentUserRole,
  currentUserId,
  currentUserClusterId,
  onSubmitRequest,
  onReviewRequest
}) => {
  _s();
  const [activeTab, setActiveTab] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showNewModal, setShowNewModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [selectedSessionId, setSelectedSessionId] = useState("");
  const [requestedDate, setRequestedDate] = useState("");
  const [reason, setReason] = useState("");
  const [reviewRemarks, setReviewRemarks] = useState("");
  const isSuperAdmin = currentUserRole === "Super Admin";
  const visibleRequests = useMemo(() => {
    let filtered = dateChangeRequests;
    if (!isSuperAdmin) {
      filtered = filtered.filter((req) => req.clusterId === currentUserClusterId);
    }
    if (activeTab !== "All") {
      filtered = filtered.filter((req) => req.status === activeTab);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter((req) => {
        const session = sessions.find((s) => s.id === req.sessionId);
        return session?.name.toLowerCase().includes(q) || req.clusterName?.toLowerCase().includes(q);
      });
    }
    return filtered;
  }, [dateChangeRequests, currentUserClusterId, isSuperAdmin, activeTab, searchQuery, sessions]);
  const clusterSessions = useMemo(() => {
    return sessions.filter((s) => s.clusterId === currentUserClusterId);
  }, [sessions, currentUserClusterId]);
  const handleNewRequestSubmit = async (e) => {
    e.preventDefault();
    const session = clusterSessions.find((s) => s.id === selectedSessionId);
    if (!session || !requestedDate || !reason) return;
    setIsSubmitting(true);
    try {
      await onSubmitRequest(selectedSessionId, session.date, requestedDate, reason);
      setShowNewModal(false);
      setSelectedSessionId("");
      setRequestedDate("");
      setReason("");
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleReviewSubmit = async (action) => {
    if (!selectedRequest) return;
    setIsSubmitting(true);
    try {
      await onReviewRequest(selectedRequest.id, action, reviewRemarks);
      setShowReviewModal(false);
      setSelectedRequest(null);
      setReviewRemarks("");
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const getStatusBadge = (status) => {
    switch (status) {
      case "PENDING":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300", children: "Pending" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 109,
          columnNumber: 16
        }, this);
      case "APPROVED":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300", children: "Approved" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 111,
          columnNumber: 16
        }, this);
      case "REJECTED":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300", children: "Rejected" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 113,
          columnNumber: 16
        }, this);
      default:
        return null;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2", children: [
          "Date Change Requests",
          /* @__PURE__ */ jsxDEV("span", { className: "bg-brand-100 text-brand-800 text-sm font-medium px-2.5 py-0.5 rounded-full dark:bg-brand-900/30 dark:text-brand-300", children: dateChangeRequests.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 125,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 dark:text-gray-400 mt-1", children: "Manage and track session date changes" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 129,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      !isSuperAdmin && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setShowNewModal(true),
          className: "flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white px-4 py-2 rounded-lg transition-colors font-medium",
          children: [
            /* @__PURE__ */ jsxDEV(Calendar, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 137,
              columnNumber: 13
            }, this),
            "New Request"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 133,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-gray-200 dark:border-gray-700 flex flex-col md:flex-row justify-between items-start md:items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex space-x-2 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto", children: ["All", "PENDING", "APPROVED", "REJECTED"].map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab(tab),
              className: `px-4 py-2 text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${activeTab === tab ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20 dark:text-brand-300" : "text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"}`,
              children: tab === "All" ? "All Requests" : tab.charAt(0) + tab.slice(1).toLowerCase()
            },
            tab,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 148,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 146,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative w-full md:w-64", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 163,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "Search session or cluster...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: "w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 164,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 145,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse", children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-50 dark:bg-gray-900/50 border-b border-gray-200 dark:border-gray-700 text-sm text-gray-600 dark:text-gray-400", children: [
          isSuperAdmin && /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Cluster" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 178,
            columnNumber: 34
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Session" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 179,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Original Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 180,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Requested Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 181,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Reason" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 182,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Status" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 183,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Actions" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 184,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 177,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 176,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200 dark:divide-gray-700", children: [
          visibleRequests.map((req) => {
            const session = sessions.find((s) => s.id === req.sessionId);
            return /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors", children: [
              isSuperAdmin && /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-sm text-gray-800 dark:text-gray-200", children: req.clusterName || "Unknown Cluster" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 193,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-sm text-gray-800 dark:text-gray-200 font-medium", children: [
                session?.name || "Unknown Session",
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: [
                  "Day ",
                  req.dayNumber || session?.dayNumber
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 199,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 197,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-sm text-gray-600 dark:text-gray-400", children: new Date(req.originalDate).toLocaleDateString() }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 201,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-sm text-gray-600 dark:text-gray-400 font-medium", children: new Date(req.requestedDate).toLocaleDateString() }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 204,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-sm text-gray-600 dark:text-gray-400 max-w-xs truncate", title: req.reason, children: req.reason }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 207,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4", children: getStatusBadge(req.status) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 210,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4", children: isSuperAdmin && req.status === "PENDING" ? /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setSelectedRequest(req);
                    setShowReviewModal(true);
                  },
                  className: "flex items-center gap-1.5 text-sm text-brand-600 hover:text-brand-700 dark:text-brand-400 dark:hover:text-brand-300 font-medium",
                  children: [
                    /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                      lineNumber: 219,
                      columnNumber: 27
                    }, this),
                    "Review"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 215,
                  columnNumber: 23
                },
                this
              ) : /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setSelectedRequest(req);
                    setShowReviewModal(true);
                  },
                  className: "flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200",
                  children: [
                    /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                      lineNumber: 227,
                      columnNumber: 27
                    }, this),
                    "View Details"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 223,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                lineNumber: 213,
                columnNumber: 21
              }, this)
            ] }, req.id, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 191,
              columnNumber: 19
            }, this);
          }),
          visibleRequests.length === 0 && /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: isSuperAdmin ? 7 : 6, className: "p-8 text-center text-gray-500 dark:text-gray-400", children: "No date change requests found." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 237,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 236,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 187,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 175,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 174,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    showNewModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-md overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 dark:text-white", children: "New Date Change Request" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 252,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowNewModal(false), className: "text-gray-400 hover:text-gray-500", children: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 254,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 253,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 251,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleNewRequestSubmit, className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Session" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 259,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedSessionId,
              onValueChange: (val) => setSelectedSessionId(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select a session" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 265,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 264,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: clusterSessions.map(
                  (s) => /* @__PURE__ */ jsxDEV(SelectItem, { value: s.id, children: [
                    s.name,
                    " (Original: ",
                    s.date,
                    ")"
                  ] }, s.id, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                    lineNumber: 269,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 267,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 260,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 258,
          columnNumber: 15
        }, this),
        selectedSessionId && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Original Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 279,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              disabled: true,
              value: clusterSessions.find((s) => s.id === selectedSessionId)?.date || "",
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 280,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 278,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Requested New Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 290,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: requestedDate,
              onChange: (e) => setRequestedDate(e.target.value),
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 291,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 289,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Reason for Change" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 301,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: reason,
              onChange: (e) => setReason(e.target.value),
              rows: 3,
              placeholder: "Explain why the date needs to be changed...",
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 302,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 300,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 flex justify-end gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowNewModal(false),
              className: "px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 transition-colors",
              disabled: isSubmitting,
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 313,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isSubmitting,
              className: "px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50",
              children: [
                /* @__PURE__ */ jsxDEV(Send, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
                  lineNumber: 326,
                  columnNumber: 19
                }, this),
                "Submit Request"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 321,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 312,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 257,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 250,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 249,
      columnNumber: 7
    }, this),
    showReviewModal && selectedRequest && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 dark:text-white", children: isSuperAdmin && selectedRequest.status === "PENDING" ? "Review Request" : "Request Details" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 340,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => {
          setShowReviewModal(false);
          setSelectedRequest(null);
        }, className: "text-gray-400 hover:text-gray-500", children: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 344,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 343,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 339,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Cluster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 350,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm text-gray-900 dark:text-gray-200", children: selectedRequest.clusterName || "N/A" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 351,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 349,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 354,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-1", children: getStatusBadge(selectedRequest.status) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 355,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 353,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Original Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 358,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm text-gray-900 dark:text-gray-200", children: new Date(selectedRequest.originalDate).toLocaleDateString() }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 359,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 357,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Requested Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 362,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block text-sm font-semibold text-brand-600 dark:text-brand-400", children: new Date(selectedRequest.requestedDate).toLocaleDateString() }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 363,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 361,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 348,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Reason" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 368,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-800 dark:text-gray-300 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg border border-gray-100 dark:border-gray-700", children: selectedRequest.reason }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 369,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 367,
          columnNumber: 15
        }, this),
        selectedRequest.status !== "PENDING" && selectedRequest.reviewRemarks && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "block text-xs font-medium text-gray-500 dark:text-gray-400", children: "Review Remarks" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 376,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-800 dark:text-gray-300 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-lg border border-gray-100 dark:border-gray-700", children: selectedRequest.reviewRemarks }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 377,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 375,
          columnNumber: 13
        }, this),
        isSuperAdmin && selectedRequest.status === "PENDING" && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Remarks (Optional)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 385,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: reviewRemarks,
              onChange: (e) => setReviewRemarks(e.target.value),
              rows: 2,
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 386,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 384,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 flex justify-end gap-3 border-t border-gray-200 dark:border-gray-700 mt-6", children: isSuperAdmin && selectedRequest.status === "PENDING" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleReviewSubmit("reject"),
              disabled: isSubmitting,
              className: "px-4 py-2 bg-red-100 text-red-700 hover:bg-red-200 rounded-lg dark:bg-red-900/30 dark:text-red-400 dark:hover:bg-red-900/50 transition-colors disabled:opacity-50",
              children: "Reject"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 398,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleReviewSubmit("approve"),
              disabled: isSubmitting,
              className: "px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors disabled:opacity-50",
              children: "Approve Change"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
              lineNumber: 405,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 397,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowReviewModal(false);
              setSelectedRequest(null);
            },
            className: "px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 transition-colors",
            children: "Close"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
            lineNumber: 414,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
          lineNumber: 395,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
        lineNumber: 347,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 338,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
      lineNumber: 337,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx",
    lineNumber: 120,
    columnNumber: 5
  }, this);
};
_s(DateChangeRequestView, "PCXEnbPW5bVOrCFXX8th+wJktyc=");
_c = DateChangeRequestView;
export default DateChangeRequestView;
var _c;
$RefreshReg$(_c, "DateChangeRequestView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DateChangeRequestView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEdlLFNBZ1NHLFVBaFNIOztBQTVHZixTQUFnQkEsVUFBVUMsZUFBZTtBQUN6QyxTQUFTQyxVQUErQkMsU0FBU0MsTUFBMkJDLFFBQXFCQyxXQUFXO0FBRTVHO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQVlQLE1BQU1DLHdCQUE4REEsQ0FBQztBQUFBLEVBQ25FQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJdEIsU0FBc0QsS0FBSztBQUM3RixRQUFNLENBQUN1QixhQUFhQyxjQUFjLElBQUl4QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDeUIsY0FBY0MsZUFBZSxJQUFJMUIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQzJCLGNBQWNDLGVBQWUsSUFBSTVCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUM2QixpQkFBaUJDLGtCQUFrQixJQUFJOUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQytCLGlCQUFpQkMsa0JBQWtCLElBQUloQyxTQUFtQyxJQUFJO0FBR3JGLFFBQU0sQ0FBQ2lDLG1CQUFtQkMsb0JBQW9CLElBQUlsQyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDcUMsUUFBUUMsU0FBUyxJQUFJdEMsU0FBUyxFQUFFO0FBR3ZDLFFBQU0sQ0FBQ3VDLGVBQWVDLGdCQUFnQixJQUFJeEMsU0FBUyxFQUFFO0FBRXJELFFBQU15QyxlQUFlMUIsb0JBQW9CO0FBRXpDLFFBQU0yQixrQkFBa0J6QyxRQUFRLE1BQU07QUFDcEMsUUFBSTBDLFdBQVc5QjtBQUNmLFFBQUksQ0FBQzRCLGNBQWM7QUFDakJFLGlCQUFXQSxTQUFTQyxPQUFPLENBQUFDLFFBQU9BLElBQUlDLGNBQWM3QixvQkFBb0I7QUFBQSxJQUMxRTtBQUVBLFFBQUlJLGNBQWMsT0FBTztBQUN2QnNCLGlCQUFXQSxTQUFTQyxPQUFPLENBQUFDLFFBQU9BLElBQUlFLFdBQVcxQixTQUFTO0FBQUEsSUFDNUQ7QUFFQSxRQUFJRSxhQUFhO0FBQ2YsWUFBTXlCLElBQUl6QixZQUFZMEIsWUFBWTtBQUNsQ04saUJBQVdBLFNBQVNDLE9BQU8sQ0FBQUMsUUFBTztBQUNoQyxjQUFNSyxVQUFVcEMsU0FBU3FDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsT0FBT1IsSUFBSVMsU0FBUztBQUN6RCxlQUFPSixTQUFTSyxLQUFLTixZQUFZLEVBQUVPLFNBQVNSLENBQUMsS0FBS0gsSUFBSVksYUFBYVIsWUFBWSxFQUFFTyxTQUFTUixDQUFDO0FBQUEsTUFDN0YsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPTDtBQUFBQSxFQUNULEdBQUcsQ0FBQzlCLG9CQUFvQkksc0JBQXNCd0IsY0FBY3BCLFdBQVdFLGFBQWFULFFBQVEsQ0FBQztBQUU3RixRQUFNNEMsa0JBQWtCekQsUUFBUSxNQUFNO0FBQ3BDLFdBQU9hLFNBQVM4QixPQUFPLENBQUFRLE1BQUtBLEVBQUVOLGNBQWM3QixvQkFBb0I7QUFBQSxFQUNsRSxHQUFHLENBQUNILFVBQVVHLG9CQUFvQixDQUFDO0FBRW5DLFFBQU0wQyx5QkFBeUIsT0FBT0MsTUFBdUI7QUFDM0RBLE1BQUVDLGVBQWU7QUFDakIsVUFBTVgsVUFBVVEsZ0JBQWdCUCxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLE9BQU9wQixpQkFBaUI7QUFDcEUsUUFBSSxDQUFDaUIsV0FBVyxDQUFDZixpQkFBaUIsQ0FBQ0UsT0FBUTtBQUUzQ1gsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU1SLGdCQUFnQmUsbUJBQW1CaUIsUUFBUVksTUFBTTNCLGVBQWVFLE1BQU07QUFDNUVULHNCQUFnQixLQUFLO0FBQ3JCTSwyQkFBcUIsRUFBRTtBQUN2QkUsdUJBQWlCLEVBQUU7QUFDbkJFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFNBQVN5QixPQUFPO0FBQ2RDLGNBQVFELE1BQU1BLEtBQUs7QUFBQSxJQUNyQixVQUFDO0FBQ0NyQyxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU11QyxxQkFBcUIsT0FBT0MsV0FBaUM7QUFDakUsUUFBSSxDQUFDbkMsZ0JBQWlCO0FBQ3RCTCxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsWUFBTVAsZ0JBQWdCWSxnQkFBZ0JzQixJQUFJYSxRQUFRM0IsYUFBYTtBQUMvRFQseUJBQW1CLEtBQUs7QUFDeEJFLHlCQUFtQixJQUFJO0FBQ3ZCUSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFNBQVN1QixPQUFPO0FBQ2RDLGNBQVFELE1BQU1BLEtBQUs7QUFBQSxJQUNyQixVQUFDO0FBQ0NyQyxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU15QyxpQkFBaUJBLENBQUNwQixXQUFtQjtBQUN6QyxZQUFRQSxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFBTyx1QkFBQyxVQUFLLFdBQVUsZ0pBQStJLHVCQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNLO0FBQUEsTUFDL0ssS0FBSztBQUNILGVBQU8sdUJBQUMsVUFBSyxXQUFVLGdKQUErSSx3QkFBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1SztBQUFBLE1BQ2hMLEtBQUs7QUFDSCxlQUFPLHVCQUFDLFVBQUssV0FBVSx3SUFBdUksd0JBQXZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0o7QUFBQSxNQUN4SztBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsK0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRFQUEwRTtBQUFBO0FBQUEsVUFFdEYsdUJBQUMsVUFBSyxXQUFVLHVIQUNibEMsNkJBQW1CdUQsVUFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQWdELHFEQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsV0FQcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQyxDQUFDM0IsZ0JBQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWIsZ0JBQWdCLElBQUk7QUFBQSxVQUNuQyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLCtHQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlJQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdFQUNaLFdBQUMsT0FBTyxXQUFXLFlBQVksVUFBVSxFQUFFeUM7QUFBQUEsVUFBSSxDQUFBQyxRQUM5QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNaEQsYUFBYWdELEdBQVU7QUFBQSxjQUN0QyxXQUFXLGdGQUNUakQsY0FBY2lELE1BQ1Ysd0VBQ0EsMkVBQTJFO0FBQUEsY0FHaEZBLGtCQUFRLFFBQVEsaUJBQWlCQSxJQUFJQyxPQUFPLENBQUMsSUFBSUQsSUFBSUUsTUFBTSxDQUFDLEVBQUV2QixZQUFZO0FBQUE7QUFBQSxZQVJ0RXFCO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsUUFDRCxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBTyxXQUFVLDhFQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RjtBQUFBLFVBQzVGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixPQUFPL0M7QUFBQUEsY0FDUCxVQUFVLENBQUNxQyxNQUFNcEMsZUFBZW9DLEVBQUVhLE9BQU9DLEtBQUs7QUFBQSxjQUM5QyxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtvTDtBQUFBLGFBUHRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsb0NBQ2Y7QUFBQSwrQkFBQyxXQUNDLGlDQUFDLFFBQUcsV0FBVSx5SEFDWGpDO0FBQUFBLDBCQUFnQix1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQ3hELHVCQUFDLFFBQUcsV0FBVSxtQkFBa0IsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsVUFDdkMsdUJBQUMsUUFBRyxXQUFVLG1CQUFrQiw2QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUM3Qyx1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLDhCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzlDLHVCQUFDLFFBQUcsV0FBVSxtQkFBa0Isc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEMsdUJBQUMsUUFBRyxXQUFVLG1CQUFrQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxVQUN0Qyx1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBUHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsV0FBTSxXQUFVLGlEQUNkQztBQUFBQSwwQkFBZ0IyQixJQUFJLENBQUN4QixRQUFRO0FBQzVCLGtCQUFNSyxVQUFVcEMsU0FBU3FDLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsT0FBT1IsSUFBSVMsU0FBUztBQUN6RCxtQkFDRSx1QkFBQyxRQUFnQixXQUFVLGdFQUN4QmI7QUFBQUEsOEJBQ0MsdUJBQUMsUUFBRyxXQUFVLGdEQUNYSSxjQUFJWSxlQUFlLHFCQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRix1QkFBQyxRQUFHLFdBQVUsNERBQ1hQO0FBQUFBLHlCQUFTSyxRQUFRO0FBQUEsZ0JBQ2xCLHVCQUFDLFNBQUksV0FBVSw0Q0FBMkM7QUFBQTtBQUFBLGtCQUFLVixJQUFJOEIsYUFBYXpCLFNBQVN5QjtBQUFBQSxxQkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUc7QUFBQSxtQkFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGdEQUNYLGNBQUlDLEtBQUsvQixJQUFJZ0MsWUFBWSxFQUFFQyxtQkFBbUIsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDREQUNYLGNBQUlGLEtBQUsvQixJQUFJVixhQUFhLEVBQUUyQyxtQkFBbUIsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGtFQUFpRSxPQUFPakMsSUFBSVIsUUFDdkZRLGNBQUlSLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLE9BQ1g4Qix5QkFBZXRCLElBQUlFLE1BQU0sS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLE9BQ1hOLDBCQUFnQkksSUFBSUUsV0FBVyxZQUM5QjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU07QUFBRWYsdUNBQW1CYSxHQUFHO0FBQUdmLHVDQUFtQixJQUFJO0FBQUEsa0JBQUc7QUFBQSxrQkFDcEUsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUEsSUFFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLE1BQU07QUFBRUUsdUNBQW1CYSxHQUFHO0FBQUdmLHVDQUFtQixJQUFJO0FBQUEsa0JBQUc7QUFBQSxrQkFDcEUsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxpQkF4Q09lLElBQUlRLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5Q0E7QUFBQSxVQUVKLENBQUM7QUFBQSxVQUNBWCxnQkFBZ0IwQixXQUFXLEtBQzFCLHVCQUFDLFFBQ0MsaUNBQUMsUUFBRyxTQUFTM0IsZUFBZSxJQUFJLEdBQUcsV0FBVSxvREFBa0QsOENBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVEQTtBQUFBLFdBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRUEsS0FyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNFQTtBQUFBLFNBckdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzR0E7QUFBQSxJQUdDZCxnQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLG1GQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHVEQUFzRCx1Q0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRjtBQUFBLFFBQzNGLHVCQUFDLFlBQU8sU0FBUyxNQUFNQyxnQkFBZ0IsS0FBSyxHQUFHLFdBQVUscUNBQ3ZELGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVUrQix3QkFBd0IsV0FBVSxpQkFDaEQ7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1FQUFrRSx1QkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTzFCO0FBQUFBLGNBQ1AsZUFBZSxDQUFDOEMsUUFBUTdDLHFCQUFxQjZDLEdBQUc7QUFBQSxjQUVoRDtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsd0ZBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNFckIsMEJBQWdCVztBQUFBQSxrQkFBSSxDQUFDakIsTUFDcEIsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRUMsSUFDN0JEO0FBQUFBLHNCQUFFRztBQUFBQSxvQkFBSztBQUFBLG9CQUFhSCxFQUFFVTtBQUFBQSxvQkFBSztBQUFBLHVCQURiVixFQUFFQyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUE7QUFBQTtBQUFBLFlBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQ3BCLHFCQUNDLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbUVBQWtFLDZCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRztBQUFBLFVBQ2hHO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsT0FBT3lCLGdCQUFnQlAsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxPQUFPcEIsaUJBQWlCLEdBQUc2QixRQUFRO0FBQUEsY0FDdEUsV0FBVTtBQUFBO0FBQUEsWUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJb0k7QUFBQSxhQU50STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUdGLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbUVBQWtFLGtDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRztBQUFBLFVBQ3JHO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPM0I7QUFBQUEsY0FDUCxVQUFVLENBQUN5QixNQUFNeEIsaUJBQWlCd0IsRUFBRWEsT0FBT0MsS0FBSztBQUFBLGNBQ2hELFdBQVU7QUFBQSxjQUNWLFVBQVE7QUFBQTtBQUFBLFlBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS1U7QUFBQSxhQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtRUFBa0UsaUNBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsVUFDcEc7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9yQztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3VCLE1BQU10QixVQUFVc0IsRUFBRWEsT0FBT0MsS0FBSztBQUFBLGNBQ3pDLE1BQU07QUFBQSxjQUNOLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWLFVBQVE7QUFBQTtBQUFBLFlBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVU7QUFBQSxhQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTlDLGdCQUFnQixLQUFLO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBQ1YsVUFBVUg7QUFBQUEsY0FBYTtBQUFBO0FBQUEsWUFKekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVQTtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlFQTtBQUFBLFNBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRkEsS0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1GQTtBQUFBLElBSURJLG1CQUFtQkUsbUJBQ2xCLHVCQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdURBQ1hVLDBCQUFnQlYsZ0JBQWdCZ0IsV0FBVyxZQUFZLG1CQUFtQixxQkFEN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTTtBQUFFakIsNkJBQW1CLEtBQUs7QUFBR0UsNkJBQW1CLElBQUk7QUFBQSxRQUFHLEdBQUcsV0FBVSxxQ0FDekYsaUNBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsOERBQTZELHVCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLFlBQ3BGLHVCQUFDLFVBQUssV0FBVSxrREFBa0RELDBCQUFnQjBCLGVBQWUsU0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUc7QUFBQSxlQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDhEQUE2RCxzQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxTQUFJLFdBQVUsUUFBUVUseUJBQWVwQyxnQkFBZ0JnQixNQUFNLEtBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsZUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw4REFBNkQsNkJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsWUFDMUYsdUJBQUMsVUFBSyxXQUFVLGtEQUFrRCxjQUFJNkIsS0FBSzdDLGdCQUFnQjhDLFlBQVksRUFBRUMsbUJBQW1CLEtBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThIO0FBQUEsZUFGaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw4REFBNkQsOEJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJGO0FBQUEsWUFDM0YsdUJBQUMsVUFBSyxXQUFVLGtFQUFrRSxjQUFJRixLQUFLN0MsZ0JBQWdCSSxhQUFhLEVBQUUyQyxtQkFBbUIsS0FBN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0k7QUFBQSxlQUZqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSw4REFBNkQsc0JBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsT0FBRSxXQUFVLDJJQUNWL0MsMEJBQWdCTSxVQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVDTixnQkFBZ0JnQixXQUFXLGFBQWFoQixnQkFBZ0JRLGlCQUN2RCx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDhEQUE2RCw4QkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxPQUFFLFdBQVUsMklBQ1ZSLDBCQUFnQlEsaUJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBR0RFLGdCQUFnQlYsZ0JBQWdCZ0IsV0FBVyxhQUMxQyx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1FQUFrRSxrQ0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUc7QUFBQSxVQUNyRztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT1I7QUFBQUEsY0FDUCxVQUFVLENBQUNxQixNQUFNcEIsaUJBQWlCb0IsRUFBRWEsT0FBT0MsS0FBSztBQUFBLGNBQ2hELE1BQU07QUFBQSxjQUNOLFdBQVU7QUFBQTtBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSStLO0FBQUEsYUFOakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsa0ZBQ1pqQywwQkFBZ0JWLGdCQUFnQmdCLFdBQVcsWUFDMUMsbUNBQ0U7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNa0IsbUJBQW1CLFFBQVE7QUFBQSxjQUMxQyxVQUFVeEM7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FBbUs7QUFBQTtBQUFBLFlBSC9LO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNd0MsbUJBQW1CLFNBQVM7QUFBQSxjQUMzQyxVQUFVeEM7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FBdUc7QUFBQTtBQUFBLFlBSG5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUEsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQUVLLGlDQUFtQixLQUFLO0FBQUdFLGlDQUFtQixJQUFJO0FBQUEsWUFBRztBQUFBLFlBQ3RFLFdBQVU7QUFBQSxZQUErSTtBQUFBO0FBQUEsVUFGM0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsS0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFdBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyRUE7QUFBQSxTQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUZBLEtBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RkE7QUFBQSxPQWhUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa1RBO0FBRUo7QUFBRVosR0F0WklSLHVCQUEyRDtBQUFBLEtBQTNEQTtBQXdaTixlQUFlQTtBQUFzQixJQUFBb0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwiQ2FsZW5kYXIiLCJYQ2lyY2xlIiwiU2VuZCIsIlNlYXJjaCIsIkV5ZSIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiRGF0ZUNoYW5nZVJlcXVlc3RWaWV3IiwiZGF0ZUNoYW5nZVJlcXVlc3RzIiwic2Vzc2lvbnMiLCJjdXJyZW50VXNlclJvbGUiLCJjdXJyZW50VXNlcklkIiwiY3VycmVudFVzZXJDbHVzdGVySWQiLCJvblN1Ym1pdFJlcXVlc3QiLCJvblJldmlld1JlcXVlc3QiLCJfcyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInNlYXJjaFF1ZXJ5Iiwic2V0U2VhcmNoUXVlcnkiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJzaG93TmV3TW9kYWwiLCJzZXRTaG93TmV3TW9kYWwiLCJzaG93UmV2aWV3TW9kYWwiLCJzZXRTaG93UmV2aWV3TW9kYWwiLCJzZWxlY3RlZFJlcXVlc3QiLCJzZXRTZWxlY3RlZFJlcXVlc3QiLCJzZWxlY3RlZFNlc3Npb25JZCIsInNldFNlbGVjdGVkU2Vzc2lvbklkIiwicmVxdWVzdGVkRGF0ZSIsInNldFJlcXVlc3RlZERhdGUiLCJyZWFzb24iLCJzZXRSZWFzb24iLCJyZXZpZXdSZW1hcmtzIiwic2V0UmV2aWV3UmVtYXJrcyIsImlzU3VwZXJBZG1pbiIsInZpc2libGVSZXF1ZXN0cyIsImZpbHRlcmVkIiwiZmlsdGVyIiwicmVxIiwiY2x1c3RlcklkIiwic3RhdHVzIiwicSIsInRvTG93ZXJDYXNlIiwic2Vzc2lvbiIsImZpbmQiLCJzIiwiaWQiLCJzZXNzaW9uSWQiLCJuYW1lIiwiaW5jbHVkZXMiLCJjbHVzdGVyTmFtZSIsImNsdXN0ZXJTZXNzaW9ucyIsImhhbmRsZU5ld1JlcXVlc3RTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJkYXRlIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlUmV2aWV3U3VibWl0IiwiYWN0aW9uIiwiZ2V0U3RhdHVzQmFkZ2UiLCJsZW5ndGgiLCJtYXAiLCJ0YWIiLCJjaGFyQXQiLCJzbGljZSIsInRhcmdldCIsInZhbHVlIiwiZGF5TnVtYmVyIiwiRGF0ZSIsIm9yaWdpbmFsRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInZhbCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRhdGVDaGFuZ2VSZXF1ZXN0Vmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2FsZW5kYXIsIENsb2NrLCBDaGVja0NpcmNsZTIsIFhDaXJjbGUsIFNlbmQsIEFsZXJ0Q2lyY2xlLCBGaWx0ZXIsIFNlYXJjaCwgQ2hldnJvbkRvd24sIEV5ZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgdHlwZSB7IERhdGVDaGFuZ2VSZXF1ZXN0LCBTZXNzaW9uLCBVc2VyUm9sZSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJy4vdWkvc2VsZWN0JztcblxuaW50ZXJmYWNlIERhdGVDaGFuZ2VSZXF1ZXN0Vmlld1Byb3BzIHtcbiAgZGF0ZUNoYW5nZVJlcXVlc3RzOiBEYXRlQ2hhbmdlUmVxdWVzdFtdO1xuICBzZXNzaW9uczogU2Vzc2lvbltdO1xuICBjdXJyZW50VXNlclJvbGU6IFVzZXJSb2xlO1xuICBjdXJyZW50VXNlcklkOiBzdHJpbmc7XG4gIGN1cnJlbnRVc2VyQ2x1c3RlcklkOiBzdHJpbmc7XG4gIG9uU3VibWl0UmVxdWVzdDogKHNlc3Npb25JZDogc3RyaW5nLCBvcmlnaW5hbERhdGU6IHN0cmluZywgcmVxdWVzdGVkRGF0ZTogc3RyaW5nLCByZWFzb246IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25SZXZpZXdSZXF1ZXN0OiAocmVxdWVzdElkOiBzdHJpbmcsIGFjdGlvbjogJ2FwcHJvdmUnIHwgJ3JlamVjdCcsIHJlbWFya3M6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbn1cblxuY29uc3QgRGF0ZUNoYW5nZVJlcXVlc3RWaWV3OiBSZWFjdC5GQzxEYXRlQ2hhbmdlUmVxdWVzdFZpZXdQcm9wcz4gPSAoe1xuICBkYXRlQ2hhbmdlUmVxdWVzdHMsXG4gIHNlc3Npb25zLFxuICBjdXJyZW50VXNlclJvbGUsXG4gIGN1cnJlbnRVc2VySWQsXG4gIGN1cnJlbnRVc2VyQ2x1c3RlcklkLFxuICBvblN1Ym1pdFJlcXVlc3QsXG4gIG9uUmV2aWV3UmVxdWVzdFxufSkgPT4ge1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J0FsbCcgfCAnUEVORElORycgfCAnQVBQUk9WRUQnIHwgJ1JFSkVDVEVEJz4oJ0FsbCcpO1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dOZXdNb2RhbCwgc2V0U2hvd05ld01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dSZXZpZXdNb2RhbCwgc2V0U2hvd1Jldmlld01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkUmVxdWVzdCwgc2V0U2VsZWN0ZWRSZXF1ZXN0XSA9IHVzZVN0YXRlPERhdGVDaGFuZ2VSZXF1ZXN0IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTmV3IFJlcXVlc3QgRm9ybSBTdGF0ZVxuICBjb25zdCBbc2VsZWN0ZWRTZXNzaW9uSWQsIHNldFNlbGVjdGVkU2Vzc2lvbklkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3JlcXVlc3RlZERhdGUsIHNldFJlcXVlc3RlZERhdGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIFJldmlldyBGb3JtIFN0YXRlXG4gIGNvbnN0IFtyZXZpZXdSZW1hcmtzLCBzZXRSZXZpZXdSZW1hcmtzXSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBpc1N1cGVyQWRtaW4gPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbic7XG5cbiAgY29uc3QgdmlzaWJsZVJlcXVlc3RzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgbGV0IGZpbHRlcmVkID0gZGF0ZUNoYW5nZVJlcXVlc3RzO1xuICAgIGlmICghaXNTdXBlckFkbWluKSB7XG4gICAgICBmaWx0ZXJlZCA9IGZpbHRlcmVkLmZpbHRlcihyZXEgPT4gcmVxLmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xuICAgIH1cbiAgICBcbiAgICBpZiAoYWN0aXZlVGFiICE9PSAnQWxsJykge1xuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIocmVxID0+IHJlcS5zdGF0dXMgPT09IGFjdGl2ZVRhYik7XG4gICAgfVxuXG4gICAgaWYgKHNlYXJjaFF1ZXJ5KSB7XG4gICAgICBjb25zdCBxID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKTtcbiAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKHJlcSA9PiB7XG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBzZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gcmVxLnNlc3Npb25JZCk7XG4gICAgICAgIHJldHVybiBzZXNzaW9uPy5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHwgcmVxLmNsdXN0ZXJOYW1lPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBmaWx0ZXJlZDtcbiAgfSwgW2RhdGVDaGFuZ2VSZXF1ZXN0cywgY3VycmVudFVzZXJDbHVzdGVySWQsIGlzU3VwZXJBZG1pbiwgYWN0aXZlVGFiLCBzZWFyY2hRdWVyeSwgc2Vzc2lvbnNdKTtcblxuICBjb25zdCBjbHVzdGVyU2Vzc2lvbnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gc2Vzc2lvbnMuZmlsdGVyKHMgPT4gcy5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcbiAgfSwgW3Nlc3Npb25zLCBjdXJyZW50VXNlckNsdXN0ZXJJZF0pO1xuXG4gIGNvbnN0IGhhbmRsZU5ld1JlcXVlc3RTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGNvbnN0IHNlc3Npb24gPSBjbHVzdGVyU2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IHNlbGVjdGVkU2Vzc2lvbklkKTtcbiAgICBpZiAoIXNlc3Npb24gfHwgIXJlcXVlc3RlZERhdGUgfHwgIXJlYXNvbikgcmV0dXJuO1xuICAgIFxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgb25TdWJtaXRSZXF1ZXN0KHNlbGVjdGVkU2Vzc2lvbklkLCBzZXNzaW9uLmRhdGUsIHJlcXVlc3RlZERhdGUsIHJlYXNvbik7XG4gICAgICBzZXRTaG93TmV3TW9kYWwoZmFsc2UpO1xuICAgICAgc2V0U2VsZWN0ZWRTZXNzaW9uSWQoJycpO1xuICAgICAgc2V0UmVxdWVzdGVkRGF0ZSgnJyk7XG4gICAgICBzZXRSZWFzb24oJycpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmV2aWV3U3VibWl0ID0gYXN5bmMgKGFjdGlvbjogJ2FwcHJvdmUnIHwgJ3JlamVjdCcpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkUmVxdWVzdCkgcmV0dXJuO1xuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgb25SZXZpZXdSZXF1ZXN0KHNlbGVjdGVkUmVxdWVzdC5pZCwgYWN0aW9uLCByZXZpZXdSZW1hcmtzKTtcbiAgICAgIHNldFNob3dSZXZpZXdNb2RhbChmYWxzZSk7XG4gICAgICBzZXRTZWxlY3RlZFJlcXVlc3QobnVsbCk7XG4gICAgICBzZXRSZXZpZXdSZW1hcmtzKCcnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1czogc3RyaW5nKSA9PiB7XG4gICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgIGNhc2UgJ1BFTkRJTkcnOlxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwIGRhcms6YmctYW1iZXItOTAwLzMwIGRhcms6dGV4dC1hbWJlci0zMDBcIj5QZW5kaW5nPC9zcGFuPjtcbiAgICAgIGNhc2UgJ0FQUFJPVkVEJzpcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCBkYXJrOmJnLWdyZWVuLTkwMC8zMCBkYXJrOnRleHQtZ3JlZW4tMzAwXCI+QXBwcm92ZWQ8L3NwYW4+O1xuICAgICAgY2FzZSAnUkVKRUNURUQnOlxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAgZGFyazpiZy1yZWQtOTAwLzMwIGRhcms6dGV4dC1yZWQtMzAwXCI+UmVqZWN0ZWQ8L3NwYW4+O1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgRGF0ZSBDaGFuZ2UgUmVxdWVzdHNcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWJyYW5kLTEwMCB0ZXh0LWJyYW5kLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGRhcms6YmctYnJhbmQtOTAwLzMwIGRhcms6dGV4dC1icmFuZC0zMDBcIj5cbiAgICAgICAgICAgICAge2RhdGVDaGFuZ2VSZXF1ZXN0cy5sZW5ndGh9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj5NYW5hZ2UgYW5kIHRyYWNrIHNlc3Npb24gZGF0ZSBjaGFuZ2VzPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIHshaXNTdXBlckFkbWluICYmIChcbiAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd05ld01vZGFsKHRydWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctYnJhbmQtNTAwIGhvdmVyOmJnLWJyYW5kLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICBOZXcgUmVxdWVzdFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgey8qIEZpbHRlcnMgYW5kIFNlYXJjaCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTIgb3ZlcmZsb3cteC1hdXRvIHBiLTIgbWQ6cGItMCB3LWZ1bGwgbWQ6dy1hdXRvXCI+XG4gICAgICAgICAgICB7WydBbGwnLCAnUEVORElORycsICdBUFBST1ZFRCcsICdSRUpFQ1RFRCddLm1hcCh0YWIgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXt0YWJ9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYiBhcyBhbnkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gdGFiIFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1icmFuZC01MCB0ZXh0LWJyYW5kLTcwMCBkYXJrOmJnLWJyYW5kLTkwMC8yMCBkYXJrOnRleHQtYnJhbmQtMzAwJyBcbiAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0YWIgPT09ICdBbGwnID8gJ0FsbCBSZXF1ZXN0cycgOiB0YWIuY2hhckF0KDApICsgdGFiLnNsaWNlKDEpLnRvTG93ZXJDYXNlKCl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWQ6dy02NFwiPlxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiB0cmFuc2Zvcm0gLXRyYW5zbGF0ZS15LTEvMiBoLTQgdy00IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBzZXNzaW9uIG9yIGNsdXN0ZXIuLi5cIiBcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZVwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBkYXJrOmJnLWdyYXktOTAwLzUwIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCB0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAge2lzU3VwZXJBZG1pbiAmJiA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+Q2x1c3RlcjwvdGg+fVxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1tZWRpdW1cIj5TZXNzaW9uPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+T3JpZ2luYWwgRGF0ZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBmb250LW1lZGl1bVwiPlJlcXVlc3RlZCBEYXRlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+UmVhc29uPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+QWN0aW9uczwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMCBkYXJrOmRpdmlkZS1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICB7dmlzaWJsZVJlcXVlc3RzLm1hcCgocmVxKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2Vzc2lvbiA9IHNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSByZXEuc2Vzc2lvbklkKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17cmVxLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwIGRhcms6aG92ZXI6YmctZ3JheS04MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAge2lzU3VwZXJBZG1pbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVxLmNsdXN0ZXJOYW1lIHx8ICdVbmtub3duIENsdXN0ZXInfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uPy5uYW1lIHx8ICdVbmtub3duIFNlc3Npb24nfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkRheSB7cmVxLmRheU51bWJlciB8fCBzZXNzaW9uPy5kYXlOdW1iZXJ9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShyZXEub3JpZ2luYWxEYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHJlcS5yZXF1ZXN0ZWREYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1heC13LXhzIHRydW5jYXRlXCIgdGl0bGU9e3JlcS5yZWFzb259PlxuICAgICAgICAgICAgICAgICAgICAgIHtyZXEucmVhc29ufVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0JhZGdlKHJlcS5zdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2lzU3VwZXJBZG1pbiAmJiByZXEuc3RhdHVzID09PSAnUEVORElORycgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWRSZXF1ZXN0KHJlcSk7IHNldFNob3dSZXZpZXdNb2RhbCh0cnVlKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXNtIHRleHQtYnJhbmQtNjAwIGhvdmVyOnRleHQtYnJhbmQtNzAwIGRhcms6dGV4dC1icmFuZC00MDAgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTMwMCBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJldmlld1xuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTZWxlY3RlZFJlcXVlc3QocmVxKTsgc2V0U2hvd1Jldmlld01vZGFsKHRydWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtc20gdGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0yMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICB7dmlzaWJsZVJlcXVlc3RzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49e2lzU3VwZXJBZG1pbiA/IDcgOiA2fSBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gZGF0ZSBjaGFuZ2UgcmVxdWVzdHMgZm91bmQuXG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBOZXcgUmVxdWVzdCBNb2RhbCAqL31cbiAgICAgIHtzaG93TmV3TW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBzaGFkb3cteGwgdy1mdWxsIG1heC13LW1kIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+TmV3IERhdGUgQ2hhbmdlIFJlcXVlc3Q8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dOZXdNb2RhbChmYWxzZSl9IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgIDxYQ2lyY2xlIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZU5ld1JlcXVlc3RTdWJtaXR9IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xXCI+U2Vzc2lvbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkU2Vzc2lvbklkfVxuICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRTZXNzaW9uSWQodmFsKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCB0ZXh0LXhzIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGEgc2Vzc2lvblwiIC8+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAge2NsdXN0ZXJTZXNzaW9ucy5tYXAoKHMpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3MuaWR9IHZhbHVlPXtzLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzLm5hbWV9IChPcmlnaW5hbDoge3MuZGF0ZX0pXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7c2VsZWN0ZWRTZXNzaW9uSWQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xXCI+T3JpZ2luYWwgRGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2x1c3RlclNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBzZWxlY3RlZFNlc3Npb25JZCk/LmRhdGUgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5SZXF1ZXN0ZWQgTmV3IERhdGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlcXVlc3RlZERhdGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlcXVlc3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5SZWFzb24gZm9yIENoYW5nZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cmVhc29ufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXhwbGFpbiB3aHkgdGhlIGRhdGUgbmVlZHMgdG8gYmUgY2hhbmdlZC4uLlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TmV3TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtZ3JheS03MDAgYmctZ3JheS0xMDAgaG92ZXI6YmctZ3JheS0yMDAgcm91bmRlZC1sZyBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmhvdmVyOmJnLWdyYXktNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJyYW5kLTUwMCBob3ZlcjpiZy1icmFuZC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgU3VibWl0IFJlcXVlc3RcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJldmlldyAvIERldGFpbHMgTW9kYWwgKi99XG4gICAgICB7c2hvd1Jldmlld01vZGFsICYmIHNlbGVjdGVkUmVxdWVzdCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXNtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktODAwIHJvdW5kZWQtMnhsIHNoYWRvdy14bCB3LWZ1bGwgbWF4LXctbGcgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7aXNTdXBlckFkbWluICYmIHNlbGVjdGVkUmVxdWVzdC5zdGF0dXMgPT09ICdQRU5ESU5HJyA/ICdSZXZpZXcgUmVxdWVzdCcgOiAnUmVxdWVzdCBEZXRhaWxzJ31cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7IHNldFNob3dSZXZpZXdNb2RhbChmYWxzZSk7IHNldFNlbGVjdGVkUmVxdWVzdChudWxsKTsgfX0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5DbHVzdGVyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPntzZWxlY3RlZFJlcXVlc3QuY2x1c3Rlck5hbWUgfHwgJ04vQSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+U3RhdHVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xXCI+e2dldFN0YXR1c0JhZGdlKHNlbGVjdGVkUmVxdWVzdC5zdGF0dXMpfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+T3JpZ2luYWwgRGF0ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtZ3JheS0yMDBcIj57bmV3IERhdGUoc2VsZWN0ZWRSZXF1ZXN0Lm9yaWdpbmFsRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+UmVxdWVzdGVkIERhdGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiPntuZXcgRGF0ZShzZWxlY3RlZFJlcXVlc3QucmVxdWVzdGVkRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlJlYXNvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgYmctZ3JheS01MCBkYXJrOmJnLWdyYXktOTAwLzUwIHAtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlcXVlc3QucmVhc29ufVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge3NlbGVjdGVkUmVxdWVzdC5zdGF0dXMgIT09ICdQRU5ESU5HJyAmJiBzZWxlY3RlZFJlcXVlc3QucmV2aWV3UmVtYXJrcyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5SZXZpZXcgUmVtYXJrczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBiZy1ncmF5LTUwIGRhcms6YmctZ3JheS05MDAvNTAgcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSZXF1ZXN0LnJldmlld1JlbWFya3N9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge2lzU3VwZXJBZG1pbiAmJiBzZWxlY3RlZFJlcXVlc3Quc3RhdHVzID09PSAnUEVORElORycgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xXCI+UmVtYXJrcyAoT3B0aW9uYWwpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmV2aWV3UmVtYXJrc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXZpZXdSZW1hcmtzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgbXQtNlwiPlxuICAgICAgICAgICAgICAgIHtpc1N1cGVyQWRtaW4gJiYgc2VsZWN0ZWRSZXF1ZXN0LnN0YXR1cyA9PT0gJ1BFTkRJTkcnID8gKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJldmlld1N1Ym1pdCgncmVqZWN0Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctcmVkLTEwMCB0ZXh0LXJlZC03MDAgaG92ZXI6YmctcmVkLTIwMCByb3VuZGVkLWxnIGRhcms6YmctcmVkLTkwMC8zMCBkYXJrOnRleHQtcmVkLTQwMCBkYXJrOmhvdmVyOmJnLXJlZC05MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBSZWplY3RcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZXZpZXdTdWJtaXQoJ2FwcHJvdmUnKX1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ncmVlbi01MDAgaG92ZXI6YmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmUgQ2hhbmdlXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTaG93UmV2aWV3TW9kYWwoZmFsc2UpOyBzZXRTZWxlY3RlZFJlcXVlc3QobnVsbCk7IH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LWdyYXktNzAwIGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHJvdW5kZWQtbGcgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6YmctZ3JheS03MDAgZGFyazpob3ZlcjpiZy1ncmF5LTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBEYXRlQ2hhbmdlUmVxdWVzdFZpZXc7XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvRGF0ZUNoYW5nZVJlcXVlc3RWaWV3LnRzeCJ9