import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\mode-toggle.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Moon, Sun, Monitor, Check } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { useTheme } from "/src/components/theme-provider.tsx";
export function ModeToggle() {
  _s();
  const { theme, setTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "relative", ref: dropdownRef, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setOpen(!open),
        className: "relative flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors",
        "aria-label": "Toggle theme",
        children: [
          /* @__PURE__ */ jsxDEV(Sun, { className: "h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
            lineNumber: 28,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Moon, { className: "absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
            lineNumber: 29,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Toggle theme" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
            lineNumber: 30,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
        lineNumber: 22,
        columnNumber: 7
      },
      this
    ),
    open && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 mt-1.5 w-36 rounded-xl border border-border bg-popover p-1 text-popover-foreground shadow-xl z-50 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setTheme("light");
            setOpen(false);
          },
          className: `flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors ${theme === "light" ? "bg-muted text-foreground font-bold" : "hover:bg-muted/60"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Sun, { className: "h-4 w-4 text-amber-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
                lineNumber: 43,
                columnNumber: 15
              }, this),
              "Light"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 42,
              columnNumber: 13
            }, this),
            theme === "light" && /* @__PURE__ */ jsxDEV(Check, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 46,
              columnNumber: 35
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
          lineNumber: 35,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setTheme("dark");
            setOpen(false);
          },
          className: `flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors ${theme === "dark" ? "bg-muted text-foreground font-bold" : "hover:bg-muted/60"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Moon, { className: "h-4 w-4 text-indigo-400" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
                lineNumber: 56,
                columnNumber: 15
              }, this),
              "Dark"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 55,
              columnNumber: 13
            }, this),
            theme === "dark" && /* @__PURE__ */ jsxDEV(Check, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 59,
              columnNumber: 34
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
          lineNumber: 48,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setTheme("system");
            setOpen(false);
          },
          className: `flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors ${theme === "system" ? "bg-muted text-foreground font-bold" : "hover:bg-muted/60"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(Monitor, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
                lineNumber: 69,
                columnNumber: 15
              }, this),
              "System"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 68,
              columnNumber: 13
            }, this),
            theme === "system" && /* @__PURE__ */ jsxDEV(Check, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
              lineNumber: 72,
              columnNumber: 36
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
          lineNumber: 61,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_s(ModeToggle, "A+wQY8RTO2SBIUk8yMSud/LbuCY=", false, function() {
  return [useTheme];
});
_c = ModeToggle;
var _c;
$RefreshReg$(_c, "ModeToggle");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/mode-toggle.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJROztBQTNCUixTQUFnQkEsVUFBVUMsUUFBUUMsaUJBQWlCO0FBQ25ELFNBQVNDLE1BQU1DLEtBQUtDLFNBQVNDLGFBQWE7QUFDMUMsU0FBU0MsZ0JBQWdCO0FBRWxCLGdCQUFTQyxhQUFhO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxFQUFFQyxPQUFPQyxTQUFTLElBQUlKLFNBQVM7QUFDckMsUUFBTSxDQUFDSyxNQUFNQyxPQUFPLElBQUliLFNBQVMsS0FBSztBQUN0QyxRQUFNYyxjQUFjYixPQUF1QixJQUFJO0FBRS9DQyxZQUFVLE1BQU07QUFDZCxVQUFNYSxxQkFBcUJBLENBQUNDLE1BQWtCO0FBQzVDLFVBQUlGLFlBQVlHLFdBQVcsQ0FBQ0gsWUFBWUcsUUFBUUMsU0FBU0YsRUFBRUcsTUFBYyxHQUFHO0FBQzFFTixnQkFBUSxLQUFLO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFDQU8sYUFBU0MsaUJBQWlCLGFBQWFOLGtCQUFrQjtBQUN6RCxXQUFPLE1BQU1LLFNBQVNFLG9CQUFvQixhQUFhUCxrQkFBa0I7QUFBQSxFQUMzRSxHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQUksV0FBVSxZQUFXLEtBQUtELGFBQzdCO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQVMsTUFBTUQsUUFBUSxDQUFDRCxJQUFJO0FBQUEsUUFDNUIsV0FBVTtBQUFBLFFBQ1YsY0FBVztBQUFBLFFBRVg7QUFBQSxpQ0FBQyxPQUFJLFdBQVUsNEVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUY7QUFBQSxVQUN2Rix1QkFBQyxRQUFLLFdBQVUsb0ZBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdHO0FBQUEsVUFDaEcsdUJBQUMsVUFBSyxXQUFVLFdBQVUsNEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUE7QUFBQTtBQUFBLE1BUnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsSUFFQ0EsUUFDQyx1QkFBQyxTQUFJLFdBQVUsc0pBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQUVELHFCQUFTLE9BQU87QUFBR0Usb0JBQVEsS0FBSztBQUFBLFVBQUc7QUFBQSxVQUNwRCxXQUFXLHlHQUNUSCxVQUFVLFVBQVUsdUNBQXVDLG1CQUFtQjtBQUFBLFVBR2hGO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEscUNBQUMsT0FBSSxXQUFVLDRCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUE7QUFBQSxpQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0NBLFVBQVUsV0FBVyx1QkFBQyxTQUFNLFdBQVUsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThCO0FBQUE7QUFBQTtBQUFBLFFBWHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQUVDLHFCQUFTLE1BQU07QUFBR0Usb0JBQVEsS0FBSztBQUFBLFVBQUc7QUFBQSxVQUNuRCxXQUFXLHlHQUNUSCxVQUFVLFNBQVMsdUNBQXVDLG1CQUFtQjtBQUFBLFVBRy9FO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEscUNBQUMsUUFBSyxXQUFVLDZCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBO0FBQUEsaUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNDQSxVQUFVLFVBQVUsdUJBQUMsU0FBTSxXQUFVLGlCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBO0FBQUE7QUFBQSxRQVhyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFZQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUFFQyxxQkFBUyxRQUFRO0FBQUdFLG9CQUFRLEtBQUs7QUFBQSxVQUFHO0FBQUEsVUFDckQsV0FBVyx5R0FDVEgsVUFBVSxXQUFXLHVDQUF1QyxtQkFBbUI7QUFBQSxVQUdqRjtBQUFBLG1DQUFDLFVBQUssV0FBVSwyQkFDZDtBQUFBLHFDQUFDLFdBQVEsV0FBVSxtQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Q7QUFBQTtBQUFBLGlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQ0EsVUFBVSxZQUFZLHVCQUFDLFNBQU0sV0FBVSxpQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEI7QUFBQTtBQUFBO0FBQUEsUUFYdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUE7QUFBQSxTQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0NBO0FBQUEsT0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVEQTtBQUVKO0FBQUNELEdBekVlRCxZQUFVO0FBQUEsVUFDSUQsUUFBUTtBQUFBO0FBQUEsS0FEdEJDO0FBQVUsSUFBQWU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJNb29uIiwiU3VuIiwiTW9uaXRvciIsIkNoZWNrIiwidXNlVGhlbWUiLCJNb2RlVG9nZ2xlIiwiX3MiLCJ0aGVtZSIsInNldFRoZW1lIiwib3BlbiIsInNldE9wZW4iLCJkcm9wZG93blJlZiIsImhhbmRsZUNsaWNrT3V0c2lkZSIsImUiLCJjdXJyZW50IiwiY29udGFpbnMiLCJ0YXJnZXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibW9kZS10b2dnbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBNb29uLCBTdW4sIE1vbml0b3IsIENoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnLi90aGVtZS1wcm92aWRlcic7XG5cbmV4cG9ydCBmdW5jdGlvbiBNb2RlVG9nZ2xlKCkge1xuICBjb25zdCB7IHRoZW1lLCBzZXRUaGVtZSB9ID0gdXNlVGhlbWUoKTtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBkcm9wZG93blJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZTogTW91c2VFdmVudCkgPT4ge1xuICAgICAgaWYgKGRyb3Bkb3duUmVmLmN1cnJlbnQgJiYgIWRyb3Bkb3duUmVmLmN1cnJlbnQuY29udGFpbnMoZS50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICAgICAgc2V0T3BlbihmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgcmVmPXtkcm9wZG93blJlZn0+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX1cbiAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgaG92ZXI6YmctbXV0ZWQvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICBhcmlhLWxhYmVsPVwiVG9nZ2xlIHRoZW1lXCJcbiAgICAgID5cbiAgICAgICAgPFN1biBjbGFzc05hbWU9XCJoLTUgdy01IHJvdGF0ZS0wIHNjYWxlLTEwMCB0cmFuc2l0aW9uLWFsbCBkYXJrOi1yb3RhdGUtOTAgZGFyazpzY2FsZS0wXCIgLz5cbiAgICAgICAgPE1vb24gY2xhc3NOYW1lPVwiYWJzb2x1dGUgaC01IHctNSByb3RhdGUtOTAgc2NhbGUtMCB0cmFuc2l0aW9uLWFsbCBkYXJrOnJvdGF0ZS0wIGRhcms6c2NhbGUtMTAwXCIgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPlRvZ2dsZSB0aGVtZTwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7b3BlbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMCBtdC0xLjUgdy0zNiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLXBvcG92ZXIgcC0xIHRleHQtcG9wb3Zlci1mb3JlZ3JvdW5kIHNoYWRvdy14bCB6LTUwIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTVcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0VGhlbWUoJ2xpZ2h0Jyk7IHNldE9wZW4oZmFsc2UpOyB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIHB4LTIuNSBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgdGhlbWUgPT09ICdsaWdodCcgPyAnYmctbXV0ZWQgdGV4dC1mb3JlZ3JvdW5kIGZvbnQtYm9sZCcgOiAnaG92ZXI6YmctbXV0ZWQvNjAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8U3VuIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICBMaWdodFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAge3RoZW1lID09PSAnbGlnaHQnICYmIDxDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRUaGVtZSgnZGFyaycpOyBzZXRPcGVuKGZhbHNlKTsgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1sZyBweC0yLjUgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgIHRoZW1lID09PSAnZGFyaycgPyAnYmctbXV0ZWQgdGV4dC1mb3JlZ3JvdW5kIGZvbnQtYm9sZCcgOiAnaG92ZXI6YmctbXV0ZWQvNjAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8TW9vbiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtaW5kaWdvLTQwMFwiIC8+XG4gICAgICAgICAgICAgIERhcmtcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHt0aGVtZSA9PT0gJ2RhcmsnICYmIDxDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRUaGVtZSgnc3lzdGVtJyk7IHNldE9wZW4oZmFsc2UpOyB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIHB4LTIuNSBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgdGhlbWUgPT09ICdzeXN0ZW0nID8gJ2JnLW11dGVkIHRleHQtZm9yZWdyb3VuZCBmb250LWJvbGQnIDogJ2hvdmVyOmJnLW11dGVkLzYwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPE1vbml0b3IgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgICAgICAgICBTeXN0ZW1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHt0aGVtZSA9PT0gJ3N5c3RlbScgJiYgPENoZWNrIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz59XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9tb2RlLXRvZ2dsZS50c3gifQ==