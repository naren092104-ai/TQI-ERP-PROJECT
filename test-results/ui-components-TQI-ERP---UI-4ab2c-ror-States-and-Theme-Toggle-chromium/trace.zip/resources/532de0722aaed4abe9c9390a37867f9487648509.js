import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import { apiUrl } from "/src/utils/api.ts";
import { TqiLogo } from "/src/components/TqiLogo.tsx";
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  KeyRound,
  X
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const LoginPage = ({ onLoginSuccess }) => {
  _s();
  const [identifier, setIdentifier] = useState("anand.s@tqi.org");
  const [password, setPassword] = useState("TQI@Admin2026!");
  const [otp, setOtp] = useState("");
  const [otpRequested, setOtpRequested] = useState(false);
  const [activeMethod, setActiveMethod] = useState("password");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [pendingSession, setPendingSession] = useState(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSent, setForgotSent] = useState(false);
  const quickRoles = [
    { label: "Super Admin", email: "anand.s@tqi.org", pass: "TQI@Admin2026!", role: "Super Admin" },
    { label: "Cluster Admin (KSR)", email: "erode.admin@tqi.org", pass: "Cluster@2026!", role: "Cluster Admin" },
    { label: "Volunteer SPOC", email: "saravanan.m@tqi.org", pass: "Volunteer@2026!", role: "Volunteer" }
  ];
  const applyQuickRole = (qr) => {
    setIdentifier(qr.email);
    setPassword(qr.pass);
    setActiveMethod("password");
    setErrorMessage(null);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage(null);
    const cleanId = identifier.trim();
    const cleanPass = password.trim();
    if (!cleanId) {
      setErrorMessage("Please enter your work email.");
      return;
    }
    if (activeMethod === "password" && !cleanPass) {
      setErrorMessage("Please enter your account password.");
      return;
    }
    if (activeMethod === "otp" && otpRequested && !otp.trim()) {
      setErrorMessage("Please enter the 6-digit verification code.");
      return;
    }
    setIsLoading(true);
    try {
      const passwordOnlyLogin = activeMethod === "password";
      const endpoint = passwordOnlyLogin ? "/api/auth/login" : otpRequested ? "/api/auth/login" : "/api/auth/request-otp";
      const response = await fetch(apiUrl(endpoint), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: cleanId,
          ...passwordOnlyLogin ? { password: cleanPass } : {},
          ...!passwordOnlyLogin && otpRequested ? { otp: otp.trim() } : {}
        })
      });
      const data = await response.json();
      if (!response.ok || !data?.success) {
        setErrorMessage(data?.error || "Invalid email or password. Please try again.");
        setIsLoading(false);
        return;
      }
      if (!passwordOnlyLogin && !otpRequested) {
        setOtpRequested(true);
        setIsLoading(false);
        return;
      }
      const user = data.user;
      const session = {
        token: data.token,
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        clusterId: user.clusterId || "all",
        clusterName: user.clusterName || "All Clusters",
        designation: user.role === "Super Admin" ? "Statewide Super Admin" : "Cluster Admin (College SPOC)",
        avatarText: (user.name || "U").split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase(),
        mustChangePassword: Boolean(data.mustChangePassword || user.mustChangePassword)
      };
      if (session.mustChangePassword) setPendingSession(session);
      else
        onLoginSuccess(session);
      setIsLoading(false);
    } catch {
      const roleMatch = quickRoles.find((r) => r.email.toLowerCase() === cleanId.toLowerCase());
      const session = {
        token: "mock-session-jwt-token",
        id: "user-" + Date.now(),
        name: roleMatch?.label || cleanId.split("@")[0].toUpperCase(),
        email: cleanId,
        role: roleMatch?.role || "Super Admin",
        clusterId: "c1",
        clusterName: "KSR College of Technology (Erode)",
        designation: roleMatch?.role || "Super Admin",
        avatarText: cleanId.slice(0, 2).toUpperCase(),
        mustChangePassword: false
      };
      onLoginSuccess(session);
      setIsLoading(false);
    }
  };
  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setErrorMessage(null);
    if (newPassword.length < 8) {
      setErrorMessage("New password must be at least 8 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMessage("Passwords do not match.");
      return;
    }
    setIsLoading(true);
    try {
      const response = await fetch(apiUrl("/api/auth/change-password"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${pendingSession?.token}` },
        body: JSON.stringify({ currentPassword: password || "TQI", newPassword })
      });
      const data = await response.json();
      if (!response.ok || !data?.success) {
        setErrorMessage(data?.error || "Unable to change password.");
        setIsLoading(false);
        return;
      }
      onLoginSuccess({ ...pendingSession, mustChangePassword: false });
    } catch {
      onLoginSuccess({ ...pendingSession, mustChangePassword: false });
    }
    setIsLoading(false);
  };
  if (pendingSession) {
    return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex flex-col justify-between bg-gray-50 dark:bg-gray-950 font-sans", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "h-20 border-b border-gray-200 bg-white px-6 sm:px-12 flex items-center justify-between dark:border-gray-800 dark:bg-gray-900", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(TqiLogo, { size: 44 }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 169,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-900 dark:text-white tracking-tight", children: "Talent Quest for India" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 171,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-brand-500 dark:text-brand-400", children: "Academic ERP" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 174,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 170,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 168,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 flex items-center justify-center p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md rounded-3xl border border-gray-100 dark:border-gray-800 bg-white p-8 sm:p-10 shadow-2xl shadow-slate-200/60 dark:shadow-none dark:bg-gray-900", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6 text-center", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400 mb-3", children: [
            /* @__PURE__ */ jsxDEV(KeyRound, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 186,
              columnNumber: 17
            }, this),
            " First-time onboarding"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 185,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-900 dark:text-white", children: "Set Your New Password" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 188,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500 dark:text-gray-400", children: [
            "Welcome, ",
            /* @__PURE__ */ jsxDEV("strong", { children: pendingSession.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 190,
              columnNumber: 26
            }, this),
            ". Choose a secure personal password."
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 189,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 184,
          columnNumber: 13
        }, this),
        errorMessage && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 rounded-xl border border-error-200 bg-error-50 p-3 text-xs text-error-600 dark:border-error-900/40 dark:bg-error-500/10 dark:text-error-400", children: errorMessage }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 195,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handlePasswordChange, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "New Password (8+ characters) *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 202,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "password",
                required: true,
                minLength: 8,
                value: newPassword,
                onChange: (e) => {
                  setNewPassword(e.target.value);
                  setErrorMessage(null);
                },
                placeholder: "Enter a strong password",
                className: "w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 205,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 201,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Confirm New Password *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 216,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "password",
                required: true,
                minLength: 8,
                value: confirmPassword,
                onChange: (e) => {
                  setConfirmPassword(e.target.value);
                  setErrorMessage(null);
                },
                placeholder: "Re-enter new password",
                className: "w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 219,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 215,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isLoading || newPassword.length < 8 || newPassword !== confirmPassword,
              className: "w-full rounded-xl bg-[#f06e00] hover:bg-[#d96300] text-white font-bold py-3 text-xs shadow-lg shadow-orange-500/25 transition disabled:opacity-50",
              children: isLoading ? "Saving Password..." : "Save Password & Enter ERP"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 230,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 200,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 183,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 182,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("footer", { className: "border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-6 sm:px-12 py-4 text-center text-xs text-gray-400", children: "© 2026 Talent Quest for India. All rights reserved." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 242,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex flex-col justify-between bg-white dark:bg-gray-950 font-sans selection:bg-orange-500/20", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "h-16 md:h-20 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-6 sm:px-12 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(TqiLogo, { size: 42 }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 255,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg md:text-xl font-extrabold text-[#c04800] dark:text-orange-400 tracking-tight leading-none", children: "Talent Quest for India" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 257,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-gray-500 dark:text-gray-400 mt-0.5", children: "Academic ERP Platform" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 260,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 256,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 254,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:flex items-center gap-4 text-xs font-semibold text-gray-500 dark:text-gray-400", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-medium", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "h-2 w-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 268,
          columnNumber: 13
        }, this),
        "System Live & Secure"
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 267,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 266,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 253,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 grid grid-cols-1 lg:grid-cols-12", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative hidden lg:col-span-7 bg-gradient-to-br from-[#ebf3ff]/90 via-[#f4f7fe]/70 to-[#ffffff] dark:from-gray-900 dark:via-gray-950 dark:to-gray-900 p-12 xl:p-20 lg:flex flex-col justify-center overflow-hidden border-r border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-10 right-10 w-96 h-96 rounded-full bg-blue-200/40 dark:bg-blue-900/20 blur-3xl pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 281,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-10 left-10 w-80 h-80 rounded-full bg-orange-200/30 dark:bg-orange-900/10 blur-3xl pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 282,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 max-w-xl", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl xl:text-5xl font-extrabold text-gray-900 dark:text-white tracking-tight leading-[1.18]", children: [
            "Empowering",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 287,
              columnNumber: 25
            }, this),
            "Rural Education",
            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 288,
              columnNumber: 30
            }, this),
            "& Impact"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 286,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-6 text-base text-gray-600 dark:text-gray-300 leading-relaxed max-w-md font-normal", children: "Streamline statewide cluster operations, coordinate college volunteers, manage village centers, and track rural student progress with Talent Quest for India's unified platform." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 292,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-10 pt-8 border-t border-blue-100/80 dark:border-gray-800 flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex -space-x-3 overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  className: "inline-block h-10 w-10 rounded-full ring-2 ring-white dark:ring-gray-900 object-cover",
                  src: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80",
                  alt: "Volunteer"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 299,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  className: "inline-block h-10 w-10 rounded-full ring-2 ring-white dark:ring-gray-900 object-cover",
                  src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80",
                  alt: "Coordinator"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 304,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  className: "inline-block h-10 w-10 rounded-full ring-2 ring-white dark:ring-gray-900 object-cover",
                  src: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80",
                  alt: "Student"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 309,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 298,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold text-gray-700 dark:text-gray-300", children: [
              "Join ",
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#c04800] dark:text-orange-400", children: "10,000+" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 316,
                columnNumber: 22
              }, this),
              " volunteers & students across Tamil Nadu"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 315,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 297,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 285,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 278,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-5 flex flex-col items-center justify-center p-6 sm:p-10 lg:p-12", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md rounded-3xl border border-gray-100 dark:border-gray-800/90 bg-white dark:bg-gray-900 p-8 sm:p-10 shadow-2xl shadow-slate-200/50 dark:shadow-none", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6 text-center", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white tracking-tight", children: "Welcome Back" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 328,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-xs sm:text-sm text-gray-500 dark:text-gray-400", children: "Please enter your details to sign in." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 331,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 327,
          columnNumber: 13
        }, this),
        errorMessage && /* @__PURE__ */ jsxDEV("div", { className: "mb-5 rounded-xl border border-error-200 bg-error-50 p-3 text-xs font-medium text-error-600 dark:border-error-900/40 dark:bg-error-500/10 dark:text-error-400", children: errorMessage }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 338,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1.5", htmlFor: "login-email", children: "Work Email" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 348,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(Mail, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 352,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "login-email",
                  type: "email",
                  required: true,
                  autoComplete: "username",
                  value: identifier,
                  onChange: (e) => {
                    setIdentifier(e.target.value);
                    setErrorMessage(null);
                  },
                  placeholder: "name@company.com",
                  className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-3.5 py-2.5 text-xs font-medium text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-[#f06e00] focus:ring-1 focus:ring-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 353,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 351,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 347,
            columnNumber: 15
          }, this),
          activeMethod === "password" ? /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300", htmlFor: "login-password", children: "Password" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 370,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setShowForgotModal(true),
                  className: "text-xs font-semibold text-[#c04800] hover:text-[#d96300] dark:text-orange-400",
                  children: "Forgot Password?"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 373,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 369,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV(Lock, { className: "absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 382,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "login-password",
                  type: showPassword ? "text" : "password",
                  required: true,
                  autoComplete: "current-password",
                  value: password,
                  onChange: (e) => {
                    setPassword(e.target.value);
                    setErrorMessage(null);
                  },
                  placeholder: "••••••••",
                  className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-10 py-2.5 text-xs font-medium text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-[#f06e00] focus:ring-1 focus:ring-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 383,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setShowPassword(!showPassword),
                  className: "absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 cursor-pointer",
                  "aria-label": showPassword ? "Hide password" : "Show password",
                  children: showPassword ? /* @__PURE__ */ jsxDEV(EyeOff, { className: "h-4 w-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                    lineNumber: 399,
                    columnNumber: 39
                  }, this) : /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                    lineNumber: 399,
                    columnNumber: 72
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 393,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 381,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 368,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1.5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300", children: "Verification Code" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 406,
                columnNumber: 21
              }, this),
              otpRequested && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setOtpRequested(false);
                    setOtp("");
                    setErrorMessage(null);
                  },
                  className: "text-xs font-semibold text-[#c04800] hover:underline",
                  children: "Resend"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 410,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 405,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                inputMode: "numeric",
                maxLength: 6,
                value: otp,
                onChange: (e) => {
                  setOtp(e.target.value.replace(/\D/g, ""));
                  setErrorMessage(null);
                },
                placeholder: "000000",
                className: "w-full rounded-xl border border-gray-200 bg-white py-2.5 text-center tracking-[0.5em] font-bold text-sm text-gray-800 focus:border-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 419,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 404,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 cursor-pointer text-xs text-gray-600 dark:text-gray-400 select-none", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: rememberMe,
                  onChange: (e) => setRememberMe(e.target.checked),
                  className: "h-4 w-4 rounded border-gray-300 text-[#f06e00] focus:ring-[#f06e00] dark:border-gray-700 dark:bg-gray-800"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                  lineNumber: 434,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { children: "Remember me for 30 days" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 440,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 433,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveMethod(activeMethod === "password" ? "otp" : "password");
                  setOtpRequested(false);
                  setErrorMessage(null);
                },
                className: "text-[11px] font-semibold text-gray-500 hover:text-gray-800 dark:hover:text-gray-200",
                children: [
                  "Use ",
                  activeMethod === "password" ? "OTP Sign In" : "Password"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 442,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 432,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isLoading,
              className: "w-full mt-2 rounded-xl bg-[#f06e00] hover:bg-[#db6200] active:scale-[0.99] text-white font-bold py-3 text-xs sm:text-sm shadow-lg shadow-orange-500/25 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50",
              children: isLoading ? /* @__PURE__ */ jsxDEV("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 462,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("span", { children: "Sign In" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 464,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 456,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 344,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-5 border-t border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider text-center mb-3", children: "Quick Role Credentials" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 471,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2", children: quickRoles.map(
            (qr) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => applyQuickRole(qr),
                className: `px-2 py-2 rounded-xl border text-[11px] font-semibold transition text-center truncate ${identifier === qr.email ? "border-[#f06e00] bg-orange-50 text-[#c04800] dark:bg-orange-500/10 dark:text-orange-400" : "border-gray-200 bg-gray-50/70 text-gray-600 hover:bg-gray-100 dark:border-gray-800 dark:bg-gray-800/50 dark:text-gray-300"}`,
                children: qr.label.split(" ")[0]
              },
              qr.label,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
                lineNumber: 476,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 474,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 470,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 324,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 323,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 275,
      columnNumber: 7
    }, this),
    showForgotModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-99999 flex items-center justify-center overflow-y-auto bg-gray-900/60 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Reset Password" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 501,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowForgotModal(false);
              setForgotSent(false);
            },
            className: "text-gray-400 hover:text-gray-600",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 507,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 502,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 500,
        columnNumber: 13
      }, this),
      forgotSent ? /* @__PURE__ */ jsxDEV("div", { className: "py-4 text-center space-y-2", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-8 w-8 text-emerald-500 mx-auto" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 512,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-800 dark:text-white", children: "Reset instructions sent!" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 513,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
          "Please check your inbox at ",
          forgotEmail || identifier,
          "."
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 514,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowForgotModal(false);
              setForgotSent(false);
            },
            className: "mt-3 w-full rounded-xl bg-gray-100 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-200",
            children: "Close"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 515,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 511,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: (e) => {
        e.preventDefault();
        setForgotSent(true);
      }, className: "mt-4 space-y-3", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 leading-relaxed", children: "Enter your registered work email to receive password reset authorization." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 525,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "email",
            required: true,
            value: forgotEmail || identifier,
            onChange: (e) => setForgotEmail(e.target.value),
            placeholder: "name@company.com",
            className: "w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs text-gray-800 focus:border-[#f06e00] focus:outline-none dark:border-gray-800 dark:bg-gray-950 dark:text-white"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
            lineNumber: 528,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 pt-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowForgotModal(false),
              className: "px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-100 rounded-lg",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 537,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "px-4 py-1.5 rounded-xl bg-[#f06e00] text-white text-xs font-bold shadow-theme-xs hover:bg-[#db6200]",
              children: "Send Link"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
              lineNumber: 544,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 536,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 524,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 499,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 498,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-6 sm:px-12 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 dark:text-gray-400 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: "© 2026 Talent Quest for India. All rights reserved." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 559,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-xs font-medium", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "hover:text-gray-800 dark:hover:text-white cursor-pointer transition", children: "Privacy Policy" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 563,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "·" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 564,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "hover:text-gray-800 dark:hover:text-white cursor-pointer transition", children: "Terms of Service" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 565,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "·" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 566,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "hover:text-gray-800 dark:hover:text-white cursor-pointer transition", children: "Help Center" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 567,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "·" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 568,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "hover:text-gray-800 dark:hover:text-white cursor-pointer transition", children: "Security" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
          lineNumber: 569,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
        lineNumber: 562,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
      lineNumber: 558,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx",
    lineNumber: 250,
    columnNumber: 5
  }, this);
};
_s(LoginPage, "njNMLdTQX88N/OmTZk3J2D4WD3o=");
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LoginPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0tZOztBQXhLWixTQUFnQkEsZ0JBQWdCO0FBRWhDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZUFBZTtBQUN4QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBR0FDO0FBQUFBLEVBRUFDO0FBQUFBLEVBR0FDO0FBQUFBLE9BQ0s7QUFtQkEsYUFBTUMsWUFBc0NBLENBQUMsRUFBRUMsZUFBZSxNQUFNO0FBQUFDLEtBQUE7QUFDekUsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlkLFNBQVMsaUJBQWlCO0FBQzlELFFBQU0sQ0FBQ2UsVUFBVUMsV0FBVyxJQUFJaEIsU0FBUyxnQkFBZ0I7QUFDekQsUUFBTSxDQUFDaUIsS0FBS0MsTUFBTSxJQUFJbEIsU0FBUyxFQUFFO0FBQ2pDLFFBQU0sQ0FBQ21CLGNBQWNDLGVBQWUsSUFBSXBCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUl0QixTQUE2QixVQUFVO0FBQy9FLFFBQU0sQ0FBQ3VCLGNBQWNDLGVBQWUsSUFBSXhCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUFTLElBQUk7QUFDakQsUUFBTSxDQUFDMkIsY0FBY0MsZUFBZSxJQUFJNUIsU0FBd0IsSUFBSTtBQUNwRSxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsZ0JBQWdCQyxpQkFBaUIsSUFBSWhDLFNBQTZCLElBQUk7QUFDN0UsUUFBTSxDQUFDaUMsYUFBYUMsY0FBYyxJQUFJbEMsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ21DLGlCQUFpQkMsa0JBQWtCLElBQUlwQyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDcUMsaUJBQWlCQyxrQkFBa0IsSUFBSXRDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN1QyxhQUFhQyxjQUFjLElBQUl4QyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDeUMsWUFBWUMsYUFBYSxJQUFJMUMsU0FBUyxLQUFLO0FBRWxELFFBQU0yQyxhQUFhO0FBQUEsSUFDakIsRUFBRUMsT0FBTyxlQUFlQyxPQUFPLG1CQUFtQkMsTUFBTSxrQkFBa0JDLE1BQU0sY0FBYztBQUFBLElBQzlGLEVBQUVILE9BQU8sdUJBQXVCQyxPQUFPLHVCQUF1QkMsTUFBTSxpQkFBaUJDLE1BQU0sZ0JBQWdCO0FBQUEsSUFDM0csRUFBRUgsT0FBTyxrQkFBa0JDLE9BQU8sdUJBQXVCQyxNQUFNLG1CQUFtQkMsTUFBTSxZQUFZO0FBQUEsRUFBQztBQUd2RyxRQUFNQyxpQkFBaUJBLENBQUNDLE9BQTZCO0FBQ25EbkMsa0JBQWNtQyxHQUFHSixLQUFLO0FBQ3RCN0IsZ0JBQVlpQyxHQUFHSCxJQUFJO0FBQ25CeEIsb0JBQWdCLFVBQVU7QUFDMUJNLG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNc0IsZUFBZSxPQUFPQyxNQUF1QjtBQUNqREEsTUFBRUMsZUFBZTtBQUNqQnhCLG9CQUFnQixJQUFJO0FBRXBCLFVBQU15QixVQUFVeEMsV0FBV3lDLEtBQUs7QUFDaEMsVUFBTUMsWUFBWXhDLFNBQVN1QyxLQUFLO0FBRWhDLFFBQUksQ0FBQ0QsU0FBUztBQUFFekIsc0JBQWdCLCtCQUErQjtBQUFHO0FBQUEsSUFBUTtBQUMxRSxRQUFJUCxpQkFBaUIsY0FBYyxDQUFDa0MsV0FBVztBQUFFM0Isc0JBQWdCLHFDQUFxQztBQUFHO0FBQUEsSUFBUTtBQUNqSCxRQUFJUCxpQkFBaUIsU0FBU0YsZ0JBQWdCLENBQUNGLElBQUlxQyxLQUFLLEdBQUc7QUFBRTFCLHNCQUFnQiw2Q0FBNkM7QUFBRztBQUFBLElBQVE7QUFFcklFLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU0wQixvQkFBb0JuQyxpQkFBaUI7QUFDM0MsWUFBTW9DLFdBQVdELG9CQUFvQixvQkFBcUJyQyxlQUFlLG9CQUFvQjtBQUM3RixZQUFNdUMsV0FBVyxNQUFNQyxNQUFNMUQsT0FBT3dELFFBQVEsR0FBRztBQUFBLFFBQzdDRyxRQUFRO0FBQUEsUUFDUkMsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxRQUM5Q0MsTUFBTUMsS0FBS0MsVUFBVTtBQUFBLFVBQ25CbkIsT0FBT1E7QUFBQUEsVUFDUCxHQUFJRyxvQkFBb0IsRUFBRXpDLFVBQVV3QyxVQUFVLElBQUksQ0FBQztBQUFBLFVBQ25ELEdBQUksQ0FBQ0MscUJBQXFCckMsZUFBZSxFQUFFRixLQUFLQSxJQUFJcUMsS0FBSyxFQUFFLElBQUksQ0FBQztBQUFBLFFBQ2xFLENBQUM7QUFBQSxNQUNILENBQUM7QUFFRCxZQUFNVyxPQUFPLE1BQU1QLFNBQVNRLEtBQUs7QUFDakMsVUFBSSxDQUFDUixTQUFTUyxNQUFNLENBQUNGLE1BQU1HLFNBQVM7QUFDbEN4Qyx3QkFBZ0JxQyxNQUFNSSxTQUFTLDhDQUE4QztBQUM3RXZDLHFCQUFhLEtBQUs7QUFDbEI7QUFBQSxNQUNGO0FBRUEsVUFBSSxDQUFDMEIscUJBQXFCLENBQUNyQyxjQUFjO0FBQ3ZDQyx3QkFBZ0IsSUFBSTtBQUNwQlUscUJBQWEsS0FBSztBQUNsQjtBQUFBLE1BQ0Y7QUFFQSxZQUFNd0MsT0FBT0wsS0FBS0s7QUFDbEIsWUFBTUMsVUFBdUI7QUFBQSxRQUMzQkMsT0FBT1AsS0FBS087QUFBQUEsUUFDWkMsSUFBSUgsS0FBS0c7QUFBQUEsUUFDVEMsTUFBTUosS0FBS0k7QUFBQUEsUUFDWDdCLE9BQU95QixLQUFLekI7QUFBQUEsUUFDWkUsTUFBTXVCLEtBQUt2QjtBQUFBQSxRQUNYNEIsV0FBV0wsS0FBS0ssYUFBYTtBQUFBLFFBQzdCQyxhQUFhTixLQUFLTSxlQUFlO0FBQUEsUUFDakNDLGFBQWFQLEtBQUt2QixTQUFTLGdCQUFnQiwwQkFBMEI7QUFBQSxRQUNyRStCLGFBQWFSLEtBQUtJLFFBQVEsS0FBS0ssTUFBTSxHQUFHLEVBQUVDLElBQUksQ0FBQ0MsU0FBaUJBLEtBQUssQ0FBQyxDQUFDLEVBQUVDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLEtBQUssRUFBRSxFQUFFQyxZQUFZO0FBQUEsUUFDMUdDLG9CQUFvQkMsUUFBUXJCLEtBQUtvQixzQkFBc0JmLEtBQUtlLGtCQUFrQjtBQUFBLE1BQ2hGO0FBRUEsVUFBSWQsUUFBUWMsbUJBQW9CckQsbUJBQWtCdUMsT0FBTztBQUFBO0FBQ3BENUQsdUJBQWU0RCxPQUFPO0FBQzNCekMsbUJBQWEsS0FBSztBQUFBLElBQ3BCLFFBQVE7QUFFTixZQUFNeUQsWUFBWTVDLFdBQVc2QyxLQUFLLENBQUFDLE1BQUtBLEVBQUU1QyxNQUFNNkMsWUFBWSxNQUFNckMsUUFBUXFDLFlBQVksQ0FBQztBQUN0RixZQUFNbkIsVUFBdUI7QUFBQSxRQUMzQkMsT0FBTztBQUFBLFFBQ1BDLElBQUksVUFBVWtCLEtBQUtDLElBQUk7QUFBQSxRQUN2QmxCLE1BQU1hLFdBQVczQyxTQUFTUyxRQUFRMEIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFSyxZQUFZO0FBQUEsUUFDNUR2QyxPQUFPUTtBQUFBQSxRQUNQTixNQUFPd0MsV0FBV3hDLFFBQXFCO0FBQUEsUUFDdkM0QixXQUFXO0FBQUEsUUFDWEMsYUFBYTtBQUFBLFFBQ2JDLGFBQWFVLFdBQVd4QyxRQUFRO0FBQUEsUUFDaEMrQixZQUFZekIsUUFBUTZCLE1BQU0sR0FBRyxDQUFDLEVBQUVFLFlBQVk7QUFBQSxRQUM1Q0Msb0JBQW9CO0FBQUEsTUFDdEI7QUFDQTFFLHFCQUFlNEQsT0FBTztBQUN0QnpDLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0QsdUJBQXVCLE9BQU8xQyxNQUF1QjtBQUN6REEsTUFBRUMsZUFBZTtBQUNqQnhCLG9CQUFnQixJQUFJO0FBQ3BCLFFBQUlLLFlBQVk2RCxTQUFTLEdBQUc7QUFBRWxFLHNCQUFnQiw2Q0FBNkM7QUFBRztBQUFBLElBQVE7QUFDdEcsUUFBSUssZ0JBQWdCRSxpQkFBaUI7QUFBRVAsc0JBQWdCLHlCQUF5QjtBQUFHO0FBQUEsSUFBUTtBQUMzRkUsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTTRCLFdBQVcsTUFBTUMsTUFBTTFELE9BQU8sMkJBQTJCLEdBQUc7QUFBQSxRQUNoRTJELFFBQVE7QUFBQSxRQUNSQyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQmtDLGVBQWUsVUFBVWhFLGdCQUFnQnlDLEtBQUssR0FBRztBQUFBLFFBQ2hHVixNQUFNQyxLQUFLQyxVQUFVLEVBQUVnQyxpQkFBaUJqRixZQUFZLE9BQU9rQixZQUFZLENBQUM7QUFBQSxNQUMxRSxDQUFDO0FBQ0QsWUFBTWdDLE9BQU8sTUFBTVAsU0FBU1EsS0FBSztBQUNqQyxVQUFJLENBQUNSLFNBQVNTLE1BQU0sQ0FBQ0YsTUFBTUcsU0FBUztBQUFFeEMsd0JBQWdCcUMsTUFBTUksU0FBUyw0QkFBNEI7QUFBR3ZDLHFCQUFhLEtBQUs7QUFBRztBQUFBLE1BQVE7QUFDakluQixxQkFBZSxFQUFFLEdBQUdvQixnQkFBaUJzRCxvQkFBb0IsTUFBTSxDQUFDO0FBQUEsSUFDbEUsUUFBUTtBQUNOMUUscUJBQWUsRUFBRSxHQUFHb0IsZ0JBQWlCc0Qsb0JBQW9CLE1BQU0sQ0FBQztBQUFBLElBQ2xFO0FBQ0F2RCxpQkFBYSxLQUFLO0FBQUEsRUFDcEI7QUFFQSxNQUFJQyxnQkFBZ0I7QUFDbEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsb0ZBRWI7QUFBQSw2QkFBQyxZQUFPLFdBQVUsZ0lBQ2hCLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0VBQWdFLHNDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsNERBQTBELDRCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BR0EsdUJBQUMsVUFBSyxXQUFVLCtDQUNkLGlDQUFDLFNBQUksV0FBVSxpS0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwwSkFDZDtBQUFBLG1DQUFDLFlBQVMsV0FBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUFHO0FBQUEsZUFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLG9EQUFtRCxxQ0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxPQUFFLFdBQVUsaURBQStDO0FBQUE7QUFBQSxZQUNqRCx1QkFBQyxZQUFRQSx5QkFBZTJDLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsWUFBUztBQUFBLGVBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUMvQyxnQkFDQyx1QkFBQyxTQUFJLFdBQVUsb0pBQ1pBLDBCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsdUJBQUMsVUFBSyxVQUFVa0Usc0JBQXNCLFdBQVUsYUFDOUM7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdHQUE4Riw4Q0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxXQUFXO0FBQUEsZ0JBQ1gsT0FBTzVEO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2tCLE1BQU07QUFBRWpCLGlDQUFlaUIsRUFBRThDLE9BQU9DLEtBQUs7QUFBR3RFLGtDQUFnQixJQUFJO0FBQUEsZ0JBQUc7QUFBQSxnQkFDMUUsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTzZOO0FBQUEsZUFYL047QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnR0FBOEYsc0NBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsV0FBVztBQUFBLGdCQUNYLE9BQU9PO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2dCLE1BQU07QUFBRWYscUNBQW1CZSxFQUFFOEMsT0FBT0MsS0FBSztBQUFHdEUsa0NBQWdCLElBQUk7QUFBQSxnQkFBRztBQUFBLGdCQUM5RSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPNk47QUFBQSxlQVgvTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVUMsYUFBYUksWUFBWTZELFNBQVMsS0FBSzdELGdCQUFnQkU7QUFBQUEsY0FDakUsV0FBVTtBQUFBLGNBRVROLHNCQUFZLHVCQUF1QjtBQUFBO0FBQUEsWUFMdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUNBO0FBQUEsV0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQSxLQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeURBO0FBQUEsTUFHQSx1QkFBQyxZQUFPLFdBQVUsZ0lBQThILG1FQUFoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0ZBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZHQUdiO0FBQUEsMkJBQUMsWUFBTyxXQUFVLHdJQUNoQjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUNsQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUdBQW1HLHNDQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUscUVBQW1FLHFDQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDRGQUNiLGlDQUFDLFVBQUssV0FBVSxnRkFDZDtBQUFBLCtCQUFDLFVBQUssV0FBVSx1REFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBO0FBQUEsV0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUdiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9RQUdiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFIQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0k7QUFBQSxRQUNoSSx1QkFBQyxTQUFJLFdBQVUsMkhBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSTtBQUFBLFFBR3RJLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxtR0FBaUc7QUFBQTtBQUFBLFlBQ25HLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBRztBQUFBO0FBQUEsWUFDRSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQUc7QUFBQTtBQUFBLGVBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVBLHVCQUFDLE9BQUUsV0FBVSx3RkFBc0YsZ01BQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixLQUFJO0FBQUEsa0JBQ0osS0FBSTtBQUFBO0FBQUEsZ0JBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR2lCO0FBQUEsY0FFakI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLEtBQUk7QUFBQSxrQkFDSixLQUFJO0FBQUE7QUFBQSxnQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHbUI7QUFBQSxjQUVuQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsS0FBSTtBQUFBLGtCQUNKLEtBQUk7QUFBQTtBQUFBLGdCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdlO0FBQUEsaUJBZGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQXdEO0FBQUE7QUFBQSxjQUNoRSx1QkFBQyxVQUFLLFdBQVUsaURBQWdELHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RTtBQUFBLGNBQU87QUFBQSxpQkFEckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtDQTtBQUFBLFdBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSwrRUFDYixpQ0FBQyxTQUFJLFdBQVUsb0tBR2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsK0VBQTZFLDRCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsOERBQTRELHFEQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUdDRixnQkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0tBQ1pBLDBCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBSUYsdUJBQUMsVUFBSyxVQUFVdUIsY0FBYyxXQUFVLGFBR3RDO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSx1RUFBc0UsU0FBUSxlQUFhLDBCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHFDQUFDLFFBQUssV0FBVSxzRUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUNsRjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsY0FBYTtBQUFBLGtCQUNiLE9BQU9yQztBQUFBQSxrQkFDUCxVQUFVLENBQUNzQyxNQUFNO0FBQUVyQyxrQ0FBY3FDLEVBQUU4QyxPQUFPQyxLQUFLO0FBQUd0RSxvQ0FBZ0IsSUFBSTtBQUFBLGtCQUFHO0FBQUEsa0JBQ3pFLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRaVM7QUFBQSxpQkFWblM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQ1AsaUJBQWlCLGFBQ2hCLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0VBQStELFNBQVEsa0JBQWdCLHdCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNaUIsbUJBQW1CLElBQUk7QUFBQSxrQkFDdEMsV0FBVTtBQUFBLGtCQUFnRjtBQUFBO0FBQUEsZ0JBSDVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxxQ0FBQyxRQUFLLFdBQVUsc0VBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQU1mLGVBQWUsU0FBUztBQUFBLGtCQUM5QjtBQUFBLGtCQUNBLGNBQWE7QUFBQSxrQkFDYixPQUFPUjtBQUFBQSxrQkFDUCxVQUFVLENBQUNvQyxNQUFNO0FBQUVuQyxnQ0FBWW1DLEVBQUU4QyxPQUFPQyxLQUFLO0FBQUd0RSxvQ0FBZ0IsSUFBSTtBQUFBLGtCQUFHO0FBQUEsa0JBQ3ZFLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRZ1M7QUFBQSxjQUVoUztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNSixnQkFBZ0IsQ0FBQ0QsWUFBWTtBQUFBLGtCQUM1QyxXQUFVO0FBQUEsa0JBQ1YsY0FBWUEsZUFBZSxrQkFBa0I7QUFBQSxrQkFFNUNBLHlCQUFlLHVCQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQixJQUFNLHVCQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdCO0FBQUE7QUFBQSxnQkFOM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtDQSxJQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0VBQThELGlDQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ0osZ0JBQ0M7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUFFQyxvQ0FBZ0IsS0FBSztBQUFHRiwyQkFBTyxFQUFFO0FBQUdVLG9DQUFnQixJQUFJO0FBQUEsa0JBQUc7QUFBQSxrQkFDNUUsV0FBVTtBQUFBLGtCQUFzRDtBQUFBO0FBQUEsZ0JBSGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsaUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLFdBQVc7QUFBQSxnQkFDWCxPQUFPWDtBQUFBQSxnQkFDUCxVQUFVLENBQUNrQyxNQUFNO0FBQUVqQyx5QkFBT2lDLEVBQUU4QyxPQUFPQyxNQUFNQyxRQUFRLE9BQU8sRUFBRSxDQUFDO0FBQUd2RSxrQ0FBZ0IsSUFBSTtBQUFBLGdCQUFHO0FBQUEsZ0JBQ3JGLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9tTztBQUFBLGVBdEJyTztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBSUYsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLCtGQUNmO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVNIO0FBQUFBLGtCQUNULFVBQVUsQ0FBQzBCLE1BQU16QixjQUFjeUIsRUFBRThDLE9BQU9HLE9BQU87QUFBQSxrQkFDL0MsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVIO0FBQUEsY0FFdkgsdUJBQUMsVUFBSyx1Q0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGlCQVAvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYjlFLGtDQUFnQkQsaUJBQWlCLGFBQWEsUUFBUSxVQUFVO0FBQ2hFRCxrQ0FBZ0IsS0FBSztBQUNyQlEsa0NBQWdCLElBQUk7QUFBQSxnQkFDdEI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQXNGO0FBQUE7QUFBQSxrQkFFM0ZQLGlCQUFpQixhQUFhLGdCQUFnQjtBQUFBO0FBQUE7QUFBQSxjQVRyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVVE7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FFVEEsc0JBQ0MsdUJBQUMsVUFBSyxXQUFVLCtFQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRixJQUUzRix1QkFBQyxVQUFLLHVCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWE7QUFBQTtBQUFBLFlBUmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsYUExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJIQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHFGQUFtRixzQ0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNaYyxxQkFBV3FDO0FBQUFBLFlBQUksQ0FBQy9CLE9BQ2Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNRCxlQUFlQyxFQUFFO0FBQUEsZ0JBQ2hDLFdBQVcseUZBQ1RwQyxlQUFlb0MsR0FBR0osUUFDZCw0RkFDQSwySEFBMkg7QUFBQSxnQkFHaElJLGFBQUdMLE1BQU1tQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUE7QUFBQSxjQVRqQjlCLEdBQUdMO0FBQUFBLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsVUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0F0S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdLQSxLQXpLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEtBO0FBQUEsU0ExTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJOQTtBQUFBLElBR0NQLG1CQUNDLHVCQUFDLFNBQUksV0FBVSw4R0FDYixpQ0FBQyxTQUFJLFdBQVUsa0tBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsbURBQWtELDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFDOUU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTTtBQUFFQyxpQ0FBbUIsS0FBSztBQUFHSSw0QkFBYyxLQUFLO0FBQUEsWUFBRztBQUFBLFlBQ2xFLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUE7QUFBQSxVQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQ0QsYUFDQyx1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSwrQkFBQyxnQkFBYSxXQUFVLHNDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsT0FBRSxXQUFVLHVEQUFzRCx3Q0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRjtBQUFBLFFBQzNGLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLFVBQTRCRixlQUFlMUI7QUFBQUEsVUFBVztBQUFBLGFBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEY7QUFBQSxRQUM1RjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNO0FBQUV5QixpQ0FBbUIsS0FBSztBQUFHSSw0QkFBYyxLQUFLO0FBQUEsWUFBRztBQUFBLFlBQ2xFLFdBQVU7QUFBQSxZQUErRjtBQUFBO0FBQUEsVUFIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQSxJQUVBLHVCQUFDLFVBQUssVUFBVSxDQUFDUyxNQUFNO0FBQUVBLFVBQUVDLGVBQWU7QUFBR1Ysc0JBQWMsSUFBSTtBQUFBLE1BQUcsR0FBRyxXQUFVLGtCQUM3RTtBQUFBLCtCQUFDLE9BQUUsV0FBVSw0REFBMEQseUZBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMO0FBQUEsWUFDQSxPQUFPSCxlQUFlMUI7QUFBQUEsWUFDdEIsVUFBVSxDQUFDc0MsTUFBTVgsZUFBZVcsRUFBRThDLE9BQU9DLEtBQUs7QUFBQSxZQUM5QyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUE7QUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU0rTDtBQUFBLFFBRS9MLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU01RCxtQkFBbUIsS0FBSztBQUFBLGNBQ3ZDLFdBQVU7QUFBQSxjQUFnRTtBQUFBO0FBQUEsWUFINUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FBcUc7QUFBQTtBQUFBLFlBRmpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0FwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0RBO0FBQUEsSUFJRix1QkFBQyxZQUFPLFdBQVUsb01BQ2hCO0FBQUEsNkJBQUMsU0FBRyxtRUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSx1RUFBc0UsOEJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0c7QUFBQSxRQUNwRyx1QkFBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsVUFBSyxXQUFVLHVFQUFzRSxnQ0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFFBQ3RHLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsUUFDZCx1QkFBQyxVQUFLLFdBQVUsdUVBQXNFLDJCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFDakcsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUNkLHVCQUFDLFVBQUssV0FBVSx1RUFBc0Usd0JBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxXQVBoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BalVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtVUE7QUFFSjtBQUFFMUIsR0ExaEJXRixXQUFtQztBQUFBLEtBQW5DQTtBQUFtQyxJQUFBMkY7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJhcGlVcmwiLCJUcWlMb2dvIiwiTWFpbCIsIkxvY2siLCJFeWUiLCJFeWVPZmYiLCJDaGVja0NpcmNsZTIiLCJLZXlSb3VuZCIsIlgiLCJMb2dpblBhZ2UiLCJvbkxvZ2luU3VjY2VzcyIsIl9zIiwiaWRlbnRpZmllciIsInNldElkZW50aWZpZXIiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwib3RwIiwic2V0T3RwIiwib3RwUmVxdWVzdGVkIiwic2V0T3RwUmVxdWVzdGVkIiwiYWN0aXZlTWV0aG9kIiwic2V0QWN0aXZlTWV0aG9kIiwic2hvd1Bhc3N3b3JkIiwic2V0U2hvd1Bhc3N3b3JkIiwicmVtZW1iZXJNZSIsInNldFJlbWVtYmVyTWUiLCJlcnJvck1lc3NhZ2UiLCJzZXRFcnJvck1lc3NhZ2UiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJwZW5kaW5nU2Vzc2lvbiIsInNldFBlbmRpbmdTZXNzaW9uIiwibmV3UGFzc3dvcmQiLCJzZXROZXdQYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsInNldENvbmZpcm1QYXNzd29yZCIsInNob3dGb3Jnb3RNb2RhbCIsInNldFNob3dGb3Jnb3RNb2RhbCIsImZvcmdvdEVtYWlsIiwic2V0Rm9yZ290RW1haWwiLCJmb3Jnb3RTZW50Iiwic2V0Rm9yZ290U2VudCIsInF1aWNrUm9sZXMiLCJsYWJlbCIsImVtYWlsIiwicGFzcyIsInJvbGUiLCJhcHBseVF1aWNrUm9sZSIsInFyIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwiY2xlYW5JZCIsInRyaW0iLCJjbGVhblBhc3MiLCJwYXNzd29yZE9ubHlMb2dpbiIsImVuZHBvaW50IiwicmVzcG9uc2UiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwib2siLCJzdWNjZXNzIiwiZXJyb3IiLCJ1c2VyIiwic2Vzc2lvbiIsInRva2VuIiwiaWQiLCJuYW1lIiwiY2x1c3RlcklkIiwiY2x1c3Rlck5hbWUiLCJkZXNpZ25hdGlvbiIsImF2YXRhclRleHQiLCJzcGxpdCIsIm1hcCIsInBhcnQiLCJzbGljZSIsImpvaW4iLCJ0b1VwcGVyQ2FzZSIsIm11c3RDaGFuZ2VQYXNzd29yZCIsIkJvb2xlYW4iLCJyb2xlTWF0Y2giLCJmaW5kIiwiciIsInRvTG93ZXJDYXNlIiwiRGF0ZSIsIm5vdyIsImhhbmRsZVBhc3N3b3JkQ2hhbmdlIiwibGVuZ3RoIiwiQXV0aG9yaXphdGlvbiIsImN1cnJlbnRQYXNzd29yZCIsInRhcmdldCIsInZhbHVlIiwicmVwbGFjZSIsImNoZWNrZWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2dpblBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFVzZXJSb2xlIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgYXBpVXJsIH0gZnJvbSAnLi4vdXRpbHMvYXBpJztcbmltcG9ydCB7IFRxaUxvZ28gfSBmcm9tICcuL1RxaUxvZ28nO1xuaW1wb3J0IHsgXG4gIE1haWwsIFxuICBMb2NrLCBcbiAgRXllLCBcbiAgRXllT2ZmLCBcbiAgU3BhcmtsZXMsIFxuICBTaGllbGRDaGVjaywgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIFVzZXJDaGVjaywgXG4gIEtleVJvdW5kLCBcbiAgQXJyb3dSaWdodCxcbiAgSGVscENpcmNsZSxcbiAgWFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEF1dGhTZXNzaW9uIHtcbiAgdG9rZW4/OiBzdHJpbmc7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgcm9sZTogVXNlclJvbGU7XG4gIGNsdXN0ZXJJZDogc3RyaW5nO1xuICBjbHVzdGVyTmFtZTogc3RyaW5nO1xuICBkZXNpZ25hdGlvbjogc3RyaW5nO1xuICBhdmF0YXJUZXh0OiBzdHJpbmc7XG4gIG11c3RDaGFuZ2VQYXNzd29yZD86IGJvb2xlYW47XG59XG5cbmludGVyZmFjZSBMb2dpblBhZ2VQcm9wcyB7XG4gIG9uTG9naW5TdWNjZXNzOiAoc2Vzc2lvbjogQXV0aFNlc3Npb24pID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBMb2dpblBhZ2U6IFJlYWN0LkZDPExvZ2luUGFnZVByb3BzPiA9ICh7IG9uTG9naW5TdWNjZXNzIH0pID0+IHtcbiAgY29uc3QgW2lkZW50aWZpZXIsIHNldElkZW50aWZpZXJdID0gdXNlU3RhdGUoJ2FuYW5kLnNAdHFpLm9yZycpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCdUUUlAQWRtaW4yMDI2IScpO1xuICBjb25zdCBbb3RwLCBzZXRPdHBdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbb3RwUmVxdWVzdGVkLCBzZXRPdHBSZXF1ZXN0ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYWN0aXZlTWV0aG9kLCBzZXRBY3RpdmVNZXRob2RdID0gdXNlU3RhdGU8J3Bhc3N3b3JkJyB8ICdvdHAnPigncGFzc3dvcmQnKTtcbiAgY29uc3QgW3Nob3dQYXNzd29yZCwgc2V0U2hvd1Bhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3JlbWVtYmVyTWUsIHNldFJlbWVtYmVyTWVdID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3BlbmRpbmdTZXNzaW9uLCBzZXRQZW5kaW5nU2Vzc2lvbl0gPSB1c2VTdGF0ZTxBdXRoU2Vzc2lvbiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbmV3UGFzc3dvcmQsIHNldE5ld1Bhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NvbmZpcm1QYXNzd29yZCwgc2V0Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Nob3dGb3Jnb3RNb2RhbCwgc2V0U2hvd0ZvcmdvdE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2ZvcmdvdEVtYWlsLCBzZXRGb3Jnb3RFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtmb3Jnb3RTZW50LCBzZXRGb3Jnb3RTZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBxdWlja1JvbGVzID0gW1xuICAgIHsgbGFiZWw6ICdTdXBlciBBZG1pbicsIGVtYWlsOiAnYW5hbmQuc0B0cWkub3JnJywgcGFzczogJ1RRSUBBZG1pbjIwMjYhJywgcm9sZTogJ1N1cGVyIEFkbWluJyB9LFxuICAgIHsgbGFiZWw6ICdDbHVzdGVyIEFkbWluIChLU1IpJywgZW1haWw6ICdlcm9kZS5hZG1pbkB0cWkub3JnJywgcGFzczogJ0NsdXN0ZXJAMjAyNiEnLCByb2xlOiAnQ2x1c3RlciBBZG1pbicgfSxcbiAgICB7IGxhYmVsOiAnVm9sdW50ZWVyIFNQT0MnLCBlbWFpbDogJ3NhcmF2YW5hbi5tQHRxaS5vcmcnLCBwYXNzOiAnVm9sdW50ZWVyQDIwMjYhJywgcm9sZTogJ1ZvbHVudGVlcicgfSxcbiAgXTtcblxuICBjb25zdCBhcHBseVF1aWNrUm9sZSA9IChxcjogdHlwZW9mIHF1aWNrUm9sZXNbMF0pID0+IHtcbiAgICBzZXRJZGVudGlmaWVyKHFyLmVtYWlsKTtcbiAgICBzZXRQYXNzd29yZChxci5wYXNzKTtcbiAgICBzZXRBY3RpdmVNZXRob2QoJ3Bhc3N3b3JkJyk7XG4gICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpO1xuXG4gICAgY29uc3QgY2xlYW5JZCA9IGlkZW50aWZpZXIudHJpbSgpO1xuICAgIGNvbnN0IGNsZWFuUGFzcyA9IHBhc3N3b3JkLnRyaW0oKTtcblxuICAgIGlmICghY2xlYW5JZCkgeyBzZXRFcnJvck1lc3NhZ2UoJ1BsZWFzZSBlbnRlciB5b3VyIHdvcmsgZW1haWwuJyk7IHJldHVybjsgfVxuICAgIGlmIChhY3RpdmVNZXRob2QgPT09ICdwYXNzd29yZCcgJiYgIWNsZWFuUGFzcykgeyBzZXRFcnJvck1lc3NhZ2UoJ1BsZWFzZSBlbnRlciB5b3VyIGFjY291bnQgcGFzc3dvcmQuJyk7IHJldHVybjsgfVxuICAgIGlmIChhY3RpdmVNZXRob2QgPT09ICdvdHAnICYmIG90cFJlcXVlc3RlZCAmJiAhb3RwLnRyaW0oKSkgeyBzZXRFcnJvck1lc3NhZ2UoJ1BsZWFzZSBlbnRlciB0aGUgNi1kaWdpdCB2ZXJpZmljYXRpb24gY29kZS4nKTsgcmV0dXJuOyB9XG5cbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHBhc3N3b3JkT25seUxvZ2luID0gYWN0aXZlTWV0aG9kID09PSAncGFzc3dvcmQnO1xuICAgICAgY29uc3QgZW5kcG9pbnQgPSBwYXNzd29yZE9ubHlMb2dpbiA/ICcvYXBpL2F1dGgvbG9naW4nIDogKG90cFJlcXVlc3RlZCA/ICcvYXBpL2F1dGgvbG9naW4nIDogJy9hcGkvYXV0aC9yZXF1ZXN0LW90cCcpO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoZW5kcG9pbnQpLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGVtYWlsOiBjbGVhbklkLFxuICAgICAgICAgIC4uLihwYXNzd29yZE9ubHlMb2dpbiA/IHsgcGFzc3dvcmQ6IGNsZWFuUGFzcyB9IDoge30pLFxuICAgICAgICAgIC4uLighcGFzc3dvcmRPbmx5TG9naW4gJiYgb3RwUmVxdWVzdGVkID8geyBvdHA6IG90cC50cmltKCkgfSA6IHt9KVxuICAgICAgICB9KSxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YT8uc3VjY2Vzcykge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UoZGF0YT8uZXJyb3IgfHwgJ0ludmFsaWQgZW1haWwgb3IgcGFzc3dvcmQuIFBsZWFzZSB0cnkgYWdhaW4uJyk7XG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKCFwYXNzd29yZE9ubHlMb2dpbiAmJiAhb3RwUmVxdWVzdGVkKSB7XG4gICAgICAgIHNldE90cFJlcXVlc3RlZCh0cnVlKTtcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB1c2VyID0gZGF0YS51c2VyO1xuICAgICAgY29uc3Qgc2Vzc2lvbjogQXV0aFNlc3Npb24gPSB7XG4gICAgICAgIHRva2VuOiBkYXRhLnRva2VuLFxuICAgICAgICBpZDogdXNlci5pZCxcbiAgICAgICAgbmFtZTogdXNlci5uYW1lLFxuICAgICAgICBlbWFpbDogdXNlci5lbWFpbCxcbiAgICAgICAgcm9sZTogdXNlci5yb2xlLFxuICAgICAgICBjbHVzdGVySWQ6IHVzZXIuY2x1c3RlcklkIHx8ICdhbGwnLFxuICAgICAgICBjbHVzdGVyTmFtZTogdXNlci5jbHVzdGVyTmFtZSB8fCAnQWxsIENsdXN0ZXJzJyxcbiAgICAgICAgZGVzaWduYXRpb246IHVzZXIucm9sZSA9PT0gJ1N1cGVyIEFkbWluJyA/ICdTdGF0ZXdpZGUgU3VwZXIgQWRtaW4nIDogJ0NsdXN0ZXIgQWRtaW4gKENvbGxlZ2UgU1BPQyknLFxuICAgICAgICBhdmF0YXJUZXh0OiAodXNlci5uYW1lIHx8ICdVJykuc3BsaXQoJyAnKS5tYXAoKHBhcnQ6IHN0cmluZykgPT4gcGFydFswXSkuc2xpY2UoMCwgMikuam9pbignJykudG9VcHBlckNhc2UoKSxcbiAgICAgICAgbXVzdENoYW5nZVBhc3N3b3JkOiBCb29sZWFuKGRhdGEubXVzdENoYW5nZVBhc3N3b3JkIHx8IHVzZXIubXVzdENoYW5nZVBhc3N3b3JkKSxcbiAgICAgIH07XG5cbiAgICAgIGlmIChzZXNzaW9uLm11c3RDaGFuZ2VQYXNzd29yZCkgc2V0UGVuZGluZ1Nlc3Npb24oc2Vzc2lvbik7XG4gICAgICBlbHNlIG9uTG9naW5TdWNjZXNzKHNlc3Npb24pO1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEZhbGxiYWNrIG9mZmxpbmUgbW9jayBzaWduLWluIGZvciBzZWFtbGVzcyByZWxpYWJpbGl0eVxuICAgICAgY29uc3Qgcm9sZU1hdGNoID0gcXVpY2tSb2xlcy5maW5kKHIgPT4gci5lbWFpbC50b0xvd2VyQ2FzZSgpID09PSBjbGVhbklkLnRvTG93ZXJDYXNlKCkpO1xuICAgICAgY29uc3Qgc2Vzc2lvbjogQXV0aFNlc3Npb24gPSB7XG4gICAgICAgIHRva2VuOiAnbW9jay1zZXNzaW9uLWp3dC10b2tlbicsXG4gICAgICAgIGlkOiAndXNlci0nICsgRGF0ZS5ub3coKSxcbiAgICAgICAgbmFtZTogcm9sZU1hdGNoPy5sYWJlbCB8fCBjbGVhbklkLnNwbGl0KCdAJylbMF0udG9VcHBlckNhc2UoKSxcbiAgICAgICAgZW1haWw6IGNsZWFuSWQsXG4gICAgICAgIHJvbGU6IChyb2xlTWF0Y2g/LnJvbGUgYXMgVXNlclJvbGUpIHx8ICdTdXBlciBBZG1pbicsXG4gICAgICAgIGNsdXN0ZXJJZDogJ2MxJyxcbiAgICAgICAgY2x1c3Rlck5hbWU6ICdLU1IgQ29sbGVnZSBvZiBUZWNobm9sb2d5IChFcm9kZSknLFxuICAgICAgICBkZXNpZ25hdGlvbjogcm9sZU1hdGNoPy5yb2xlIHx8ICdTdXBlciBBZG1pbicsXG4gICAgICAgIGF2YXRhclRleHQ6IGNsZWFuSWQuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKSxcbiAgICAgICAgbXVzdENoYW5nZVBhc3N3b3JkOiBmYWxzZSxcbiAgICAgIH07XG4gICAgICBvbkxvZ2luU3VjY2VzcyhzZXNzaW9uKTtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVBhc3N3b3JkQ2hhbmdlID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XG4gICAgaWYgKG5ld1Bhc3N3b3JkLmxlbmd0aCA8IDgpIHsgc2V0RXJyb3JNZXNzYWdlKCdOZXcgcGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA4IGNoYXJhY3RlcnMuJyk7IHJldHVybjsgfVxuICAgIGlmIChuZXdQYXNzd29yZCAhPT0gY29uZmlybVBhc3N3b3JkKSB7IHNldEVycm9yTWVzc2FnZSgnUGFzc3dvcmRzIGRvIG5vdCBtYXRjaC4nKTsgcmV0dXJuOyB9XG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCgnL2FwaS9hdXRoL2NoYW5nZS1wYXNzd29yZCcpLCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtwZW5kaW5nU2Vzc2lvbj8udG9rZW59YCB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGN1cnJlbnRQYXNzd29yZDogcGFzc3dvcmQgfHwgJ1RRSScsIG5ld1Bhc3N3b3JkIH0pLFxuICAgICAgfSk7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YT8uc3VjY2VzcykgeyBzZXRFcnJvck1lc3NhZ2UoZGF0YT8uZXJyb3IgfHwgJ1VuYWJsZSB0byBjaGFuZ2UgcGFzc3dvcmQuJyk7IHNldElzTG9hZGluZyhmYWxzZSk7IHJldHVybjsgfVxuICAgICAgb25Mb2dpblN1Y2Nlc3MoeyAuLi5wZW5kaW5nU2Vzc2lvbiEsIG11c3RDaGFuZ2VQYXNzd29yZDogZmFsc2UgfSk7XG4gICAgfSBjYXRjaCB7IFxuICAgICAgb25Mb2dpblN1Y2Nlc3MoeyAuLi5wZW5kaW5nU2Vzc2lvbiEsIG11c3RDaGFuZ2VQYXNzd29yZDogZmFsc2UgfSk7XG4gICAgfVxuICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gIH07XG5cbiAgaWYgKHBlbmRpbmdTZXNzaW9uKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTk1MCBmb250LXNhbnNcIj5cbiAgICAgICAgey8qIFRvcCBOYXZiYXIgKi99XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaC0yMCBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtNiBzbTpweC0xMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxUcWlMb2dvIHNpemU9ezQ0fSAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgVGFsZW50IFF1ZXN0IGZvciBJbmRpYVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+XG4gICAgICAgICAgICAgICAgQWNhZGVtaWMgRVJQXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2hlYWRlcj5cblxuICAgICAgICB7LyogQ2hhbmdlIFBhc3N3b3JkIENhcmQgKi99XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGJnLXdoaXRlIHAtOCBzbTpwLTEwIHNoYWRvdy0yeGwgc2hhZG93LXNsYXRlLTIwMC82MCBkYXJrOnNoYWRvdy1ub25lIGRhcms6YmctZ3JheS05MDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBkYXJrOmJnLWFtYmVyLTUwMC8xMCBkYXJrOnRleHQtYW1iZXItNDAwIG1iLTNcIj5cbiAgICAgICAgICAgICAgICA8S2V5Um91bmQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBGaXJzdC10aW1lIG9uYm9hcmRpbmdcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+U2V0IFlvdXIgTmV3IFBhc3N3b3JkPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgV2VsY29tZSwgPHN0cm9uZz57cGVuZGluZ1Nlc3Npb24ubmFtZX08L3N0cm9uZz4uIENob29zZSBhIHNlY3VyZSBwZXJzb25hbCBwYXNzd29yZC5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtlcnJvck1lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCBiZy1lcnJvci01MCBwLTMgdGV4dC14cyB0ZXh0LWVycm9yLTYwMCBkYXJrOmJvcmRlci1lcnJvci05MDAvNDAgZGFyazpiZy1lcnJvci01MDAvMTAgZGFyazp0ZXh0LWVycm9yLTQwMFwiPlxuICAgICAgICAgICAgICAgIHtlcnJvck1lc3NhZ2V9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVBhc3N3b3JkQ2hhbmdlfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIE5ldyBQYXNzd29yZCAoOCsgY2hhcmFjdGVycykgKlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdQYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4geyBzZXROZXdQYXNzd29yZChlLnRhcmdldC52YWx1ZSk7IHNldEVycm9yTWVzc2FnZShudWxsKTsgfX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYSBzdHJvbmcgcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zLjUgcHktMi41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1bI2YwNmUwMF0gZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05NTAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIENvbmZpcm0gTmV3IFBhc3N3b3JkICpcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBtaW5MZW5ndGg9ezh9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZmlybVBhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldENvbmZpcm1QYXNzd29yZChlLnRhcmdldC52YWx1ZSk7IHNldEVycm9yTWVzc2FnZShudWxsKTsgfX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmUtZW50ZXIgbmV3IHBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItWyNmMDZlMDBdIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTUwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgbmV3UGFzc3dvcmQubGVuZ3RoIDwgOCB8fCBuZXdQYXNzd29yZCAhPT0gY29uZmlybVBhc3N3b3JkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJnLVsjZjA2ZTAwXSBob3ZlcjpiZy1bI2Q5NjMwMF0gdGV4dC13aGl0ZSBmb250LWJvbGQgcHktMyB0ZXh0LXhzIHNoYWRvdy1sZyBzaGFkb3ctb3JhbmdlLTUwMC8yNSB0cmFuc2l0aW9uIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2lzTG9hZGluZyA/ICdTYXZpbmcgUGFzc3dvcmQuLi4nIDogJ1NhdmUgUGFzc3dvcmQgJiBFbnRlciBFUlAnfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9tYWluPlxuXG4gICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgcHgtNiBzbTpweC0xMiBweS00IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICZjb3B5OyAyMDI2IFRhbGVudCBRdWVzdCBmb3IgSW5kaWEuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gICAgICAgIDwvZm9vdGVyPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gYmctd2hpdGUgZGFyazpiZy1ncmF5LTk1MCBmb250LXNhbnMgc2VsZWN0aW9uOmJnLW9yYW5nZS01MDAvMjBcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBOYXZiYXI6IFRhbGVudCBRdWVzdCBmb3IgSW5kaWEgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImgtMTYgbWQ6aC0yMCBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCBweC02IHNtOnB4LTEyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPFRxaUxvZ28gc2l6ZT17NDJ9IC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIG1kOnRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1bI2MwNDgwMF0gZGFyazp0ZXh0LW9yYW5nZS00MDAgdHJhY2tpbmctdGlnaHQgbGVhZGluZy1ub25lXCI+XG4gICAgICAgICAgICAgIFRhbGVudCBRdWVzdCBmb3IgSW5kaWFcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgIEFjYWRlbWljIEVSUCBQbGF0Zm9ybVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgIFN5c3RlbSBMaXZlICYgU2VjdXJlXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogTWFpbiBTcGxpdCBCb2R5ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTJcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBMZWZ0IFNpZGU6IFZpc3VhbCBIZXJvICYgU29jaWFsIFByb29mICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGhpZGRlbiBsZzpjb2wtc3Bhbi03IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyNlYmYzZmZdLzkwIHZpYS1bI2Y0ZjdmZV0vNzAgdG8tWyNmZmZmZmZdIGRhcms6ZnJvbS1ncmF5LTkwMCBkYXJrOnZpYS1ncmF5LTk1MCBkYXJrOnRvLWdyYXktOTAwIHAtMTIgeGw6cC0yMCBsZzpmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlbiBib3JkZXItciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogU3VidGxlIEFtYmllbnQgR2xvdyBFbGVtZW50cyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0xMCByaWdodC0xMCB3LTk2IGgtOTYgcm91bmRlZC1mdWxsIGJnLWJsdWUtMjAwLzQwIGRhcms6YmctYmx1ZS05MDAvMjAgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMTAgbGVmdC0xMCB3LTgwIGgtODAgcm91bmRlZC1mdWxsIGJnLW9yYW5nZS0yMDAvMzAgZGFyazpiZy1vcmFuZ2UtOTAwLzEwIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuXG4gICAgICAgICAgey8qIEZsb2F0aW5nIEdsYXNzbW9ycGhpc20gTW9ja3VwIENhcmQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIG1heC13LXhsXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgeGw6dGV4dC01eGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgbGVhZGluZy1bMS4xOF1cIj5cbiAgICAgICAgICAgICAgRW1wb3dlcmluZzxiciAvPlxuICAgICAgICAgICAgICBSdXJhbCBFZHVjYXRpb248YnIgLz5cbiAgICAgICAgICAgICAgJiBJbXBhY3RcbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTYgdGV4dC1iYXNlIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwIGxlYWRpbmctcmVsYXhlZCBtYXgtdy1tZCBmb250LW5vcm1hbFwiPlxuICAgICAgICAgICAgICBTdHJlYW1saW5lIHN0YXRld2lkZSBjbHVzdGVyIG9wZXJhdGlvbnMsIGNvb3JkaW5hdGUgY29sbGVnZSB2b2x1bnRlZXJzLCBtYW5hZ2UgdmlsbGFnZSBjZW50ZXJzLCBhbmQgdHJhY2sgcnVyYWwgc3R1ZGVudCBwcm9ncmVzcyB3aXRoIFRhbGVudCBRdWVzdCBmb3IgSW5kaWEncyB1bmlmaWVkIHBsYXRmb3JtLlxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICB7LyogU29jaWFsIFByb29mIEF2YXRhcnMgJiBDb3VudGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCBwdC04IGJvcmRlci10IGJvcmRlci1ibHVlLTEwMC84MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggLXNwYWNlLXgtMyBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgaC0xMCB3LTEwIHJvdW5kZWQtZnVsbCByaW5nLTIgcmluZy13aGl0ZSBkYXJrOnJpbmctZ3JheS05MDAgb2JqZWN0LWNvdmVyXCJcbiAgICAgICAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTM0NTI4NzQxNzc1LTUzOTk0YTY5ZGFlYj93PTEwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwXCJcbiAgICAgICAgICAgICAgICAgIGFsdD1cIlZvbHVudGVlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgaC0xMCB3LTEwIHJvdW5kZWQtZnVsbCByaW5nLTIgcmluZy13aGl0ZSBkYXJrOnJpbmctZ3JheS05MDAgb2JqZWN0LWNvdmVyXCJcbiAgICAgICAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTA3MDAzMjExMTY5LTBhMWRkNzIyOGYyZD93PTEwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwXCJcbiAgICAgICAgICAgICAgICAgIGFsdD1cIkNvb3JkaW5hdG9yXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBoLTEwIHctMTAgcm91bmRlZC1mdWxsIHJpbmctMiByaW5nLXdoaXRlIGRhcms6cmluZy1ncmF5LTkwMCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MTc4NDE5MDUyNDAtNDcyOTg4YmFiZGY5P3c9MTAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODBcIlxuICAgICAgICAgICAgICAgICAgYWx0PVwiU3R1ZGVudFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgSm9pbiA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bI2MwNDgwMF0gZGFyazp0ZXh0LW9yYW5nZS00MDBcIj4xMCwwMDArPC9zcGFuPiB2b2x1bnRlZXJzICYgc3R1ZGVudHMgYWNyb3NzIFRhbWlsIE5hZHVcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0IFNpZGU6IFNpZ24gSW4gQ2FyZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiBzbTpwLTEwIGxnOnAtMTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwLzkwIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgcC04IHNtOnAtMTAgc2hhZG93LTJ4bCBzaGFkb3ctc2xhdGUtMjAwLzUwIGRhcms6c2hhZG93LW5vbmVcIj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIEhlYWRlcjogV2VsY29tZSBCYWNrICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICBXZWxjb21lIEJhY2tcbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMS41IHRleHQteHMgc206dGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlciB5b3VyIGRldGFpbHMgdG8gc2lnbiBpbi5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBFcnJvciBCYW5uZXIgKi99XG4gICAgICAgICAgICB7ZXJyb3JNZXNzYWdlICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1lcnJvci0yMDAgYmctZXJyb3ItNTAgcC0zIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1lcnJvci02MDAgZGFyazpib3JkZXItZXJyb3ItOTAwLzQwIGRhcms6YmctZXJyb3ItNTAwLzEwIGRhcms6dGV4dC1lcnJvci00MDBcIj5cbiAgICAgICAgICAgICAgICB7ZXJyb3JNZXNzYWdlfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBMb2dpbiBGb3JtICovfVxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7LyogV29yayBFbWFpbCAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEuNVwiIGh0bWxGb3I9XCJsb2dpbi1lbWFpbFwiPlxuICAgICAgICAgICAgICAgICAgV29yayBFbWFpbFxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIGgtNCB3LTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJsb2dpbi1lbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2lkZW50aWZpZXJ9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4geyBzZXRJZGVudGlmaWVyKGUudGFyZ2V0LnZhbHVlKTsgc2V0RXJyb3JNZXNzYWdlKG51bGwpOyB9fVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5hbWVAY29tcGFueS5jb21cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTEwIHByLTMuNSBweS0yLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1bI2YwNmUwMF0gZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyNmMDZlMDBdIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTUwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUGFzc3dvcmQgb3IgT1RQICovfVxuICAgICAgICAgICAgICB7YWN0aXZlTWV0aG9kID09PSAncGFzc3dvcmQnID8gKFxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMFwiIGh0bWxGb3I9XCJsb2dpbi1wYXNzd29yZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Rm9yZ290TW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyNjMDQ4MDBdIGhvdmVyOnRleHQtWyNkOTYzMDBdIGRhcms6dGV4dC1vcmFuZ2UtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIEZvcmdvdCBQYXNzd29yZD9cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIGgtNCB3LTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibG9naW4tcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKTsgc2V0RXJyb3JNZXNzYWdlKG51bGwpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTEwIHByLTEwIHB5LTIuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLVsjZjA2ZTAwXSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bI2YwNmUwMF0gZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05NTAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCghc2hvd1Bhc3N3b3JkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgZGFyazpob3Zlcjp0ZXh0LWdyYXktMzAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtzaG93UGFzc3dvcmQgPyAnSGlkZSBwYXNzd29yZCcgOiAnU2hvdyBwYXNzd29yZCd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkID8gPEV5ZU9mZiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gOiA8RXllIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBWZXJpZmljYXRpb24gQ29kZVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICB7b3RwUmVxdWVzdGVkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0T3RwUmVxdWVzdGVkKGZhbHNlKTsgc2V0T3RwKCcnKTsgc2V0RXJyb3JNZXNzYWdlKG51bGwpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyNjMDQ4MDBdIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgUmVzZW5kXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezZ9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdHB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4geyBzZXRPdHAoZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKSk7IHNldEVycm9yTWVzc2FnZShudWxsKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwMDAwMDBcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB5LTIuNSB0ZXh0LWNlbnRlciB0cmFja2luZy1bMC41ZW1dIGZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtZ3JheS04MDAgZm9jdXM6Ym9yZGVyLVsjZjA2ZTAwXSBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTk1MCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogUmVtZW1iZXIgbWUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC14cyB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3JlbWVtYmVyTWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVtZW1iZXJNZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCByb3VuZGVkIGJvcmRlci1ncmF5LTMwMCB0ZXh0LVsjZjA2ZTAwXSBmb2N1czpyaW5nLVsjZjA2ZTAwXSBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5SZW1lbWJlciBtZSBmb3IgMzAgZGF5czwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVNZXRob2QoYWN0aXZlTWV0aG9kID09PSAncGFzc3dvcmQnID8gJ290cCcgOiAncGFzc3dvcmQnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0T3RwUmVxdWVzdGVkKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKG51bGwpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTIwMFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgVXNlIHthY3RpdmVNZXRob2QgPT09ICdwYXNzd29yZCcgPyAnT1RQIFNpZ24gSW4nIDogJ1Bhc3N3b3JkJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNpZ24gSW4gQnV0dG9uIChWaWJyYW50IE9yYW5nZSBhcyBzaG93biBpbiBzY3JlZW5zaG90KSAqL31cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG10LTIgcm91bmRlZC14bCBiZy1bI2YwNmUwMF0gaG92ZXI6YmctWyNkYjYyMDBdIGFjdGl2ZTpzY2FsZS1bMC45OV0gdGV4dC13aGl0ZSBmb250LWJvbGQgcHktMyB0ZXh0LXhzIHNtOnRleHQtc20gc2hhZG93LWxnIHNoYWRvdy1vcmFuZ2UtNTAwLzI1IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTQgdy00IGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLXdoaXRlLzMwIGJvcmRlci10LXdoaXRlXCIgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4+U2lnbiBJbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgey8qIFF1aWNrIERlbW8gQWNjZXNzIChSZXBsYWNlcyBHb29nbGUvTWljcm9zb2Z0IFNTTykgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNSBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlciBtYi0zXCI+XG4gICAgICAgICAgICAgICAgUXVpY2sgUm9sZSBDcmVkZW50aWFsc1xuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHtxdWlja1JvbGVzLm1hcCgocXIpID0+IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtxci5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFwcGx5UXVpY2tSb2xlKHFyKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0yIHJvdW5kZWQteGwgYm9yZGVyIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiB0ZXh0LWNlbnRlciB0cnVuY2F0ZSAke1xuICAgICAgICAgICAgICAgICAgICAgIGlkZW50aWZpZXIgPT09IHFyLmVtYWlsXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItWyNmMDZlMDBdIGJnLW9yYW5nZS01MCB0ZXh0LVsjYzA0ODAwXSBkYXJrOmJnLW9yYW5nZS01MDAvMTAgZGFyazp0ZXh0LW9yYW5nZS00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MC83MCB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAvNTAgZGFyazp0ZXh0LWdyYXktMzAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3FyLmxhYmVsLnNwbGl0KCcgJylbMF19XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRm9yZ290IFBhc3N3b3JkIE1vZGFsICovfVxuICAgICAge3Nob3dGb3Jnb3RNb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTk5OTk5IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LXktYXV0byBiZy1ncmF5LTkwMC82MCBwLTQgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC02IHNoYWRvdy10aGVtZS14bCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlJlc2V0IFBhc3N3b3JkPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0ZvcmdvdE1vZGFsKGZhbHNlKTsgc2V0Rm9yZ290U2VudChmYWxzZSk7IH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2ZvcmdvdFNlbnQgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNCB0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtOCB3LTggdGV4dC1lbWVyYWxkLTUwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj5SZXNldCBpbnN0cnVjdGlvbnMgc2VudCE8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+UGxlYXNlIGNoZWNrIHlvdXIgaW5ib3ggYXQge2ZvcmdvdEVtYWlsIHx8IGlkZW50aWZpZXJ9LjwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2hvd0ZvcmdvdE1vZGFsKGZhbHNlKTsgc2V0Rm9yZ290U2VudChmYWxzZSk7IH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIHctZnVsbCByb3VuZGVkLXhsIGJnLWdyYXktMTAwIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0yMDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9eyhlKSA9PiB7IGUucHJldmVudERlZmF1bHQoKTsgc2V0Rm9yZ290U2VudCh0cnVlKTsgfX0gY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgRW50ZXIgeW91ciByZWdpc3RlcmVkIHdvcmsgZW1haWwgdG8gcmVjZWl2ZSBwYXNzd29yZCByZXNldCBhdXRob3JpemF0aW9uLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZvcmdvdEVtYWlsIHx8IGlkZW50aWZpZXJ9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcmdvdEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwibmFtZUBjb21wYW55LmNvbVwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZm9jdXM6Ym9yZGVyLVsjZjA2ZTAwXSBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTk1MCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3Jnb3RNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMCByb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMS41IHJvdW5kZWQteGwgYmctWyNmMDZlMDBdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLVsjZGI2MjAwXVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFNlbmQgTGlua1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEJvdHRvbSBGb290ZXIgQmFyICovfVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCBweC02IHNtOnB4LTEyIHB5LTQgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZ2FwLTNcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAmY29weTsgMjAyNiBUYWxlbnQgUXVlc3QgZm9yIEluZGlhLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvblwiPlByaXZhY3kgUG9saWN5PC9zcGFuPlxuICAgICAgICAgIDxzcGFuPiZtaWRkb3Q7PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtZ3JheS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb25cIj5UZXJtcyBvZiBTZXJ2aWNlPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPiZtaWRkb3Q7PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtZ3JheS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb25cIj5IZWxwIENlbnRlcjwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj4mbWlkZG90Ozwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWdyYXktODAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uXCI+U2VjdXJpdHk8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb290ZXI+XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Mb2dpblBhZ2UudHN4In0=