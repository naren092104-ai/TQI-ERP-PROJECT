import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AttendanceView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { Badge } from "/src/components/ui/badge.tsx";
import { Check, X, Calendar, MapPin, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { ActionButton } from "/src/components/ui/action-button.tsx";
export const AttendanceView = ({
  attendanceSessions,
  students,
  panchayats,
  draftId,
  onSaveAttendance
}) => {
  _s();
  const [selectedPanchayatId, setSelectedPanchayatId] = useState(
    panchayats[0]?.id || ""
  );
  const [selectedVillageId, setSelectedVillageId] = useState("all");
  useEffect(() => {
    if (panchayats.length > 0) {
      const exists = panchayats.some((p) => p.id === selectedPanchayatId);
      if (!exists) {
        setSelectedPanchayatId(panchayats[0].id);
      }
    }
  }, [panchayats, selectedPanchayatId]);
  const [selectedDay, setSelectedDay] = useState(1);
  const [sessionDate, setSessionDate] = useState("2023-10-24");
  const [sessionTitle, setSessionTitle] = useState("Day 1 Spoken English & Life Skills");
  const [taskTopic, setTaskTopic] = useState("Worksheet & Conversational Drill");
  const [activeTab, setActiveTab] = useState("mark");
  const [saveSuccessMsg, setSaveSuccessMsg] = useState("");
  const [activeDraftSessionId, setActiveDraftSessionId] = useState(draftId || null);
  const currentPanchayat = useMemo(() => {
    return panchayats.find((p) => p.id === selectedPanchayatId) || panchayats[0];
  }, [panchayats, selectedPanchayatId]);
  const availableVillages = useMemo(() => {
    return currentPanchayat?.villages || [];
  }, [currentPanchayat]);
  const handlePanchayatChange = (panchayatId) => {
    setSelectedPanchayatId(panchayatId);
    const panch = panchayats.find((p) => p.id === panchayatId);
    if (panch && panch.villages && panch.villages.length > 0) {
      setSelectedVillageId(panch.villages[0].id);
    } else {
      setSelectedVillageId("all");
    }
  };
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchPanchayat = s.panchayatId === selectedPanchayatId;
      const matchVillage = selectedVillageId === "all" || s.villageId === selectedVillageId;
      return matchPanchayat && matchVillage;
    });
  }, [students, selectedPanchayatId, selectedVillageId]);
  const [recordsMap, setRecordsMap] = useState({});
  useEffect(() => {
    if (draftId) {
      const draft = attendanceSessions.find((s) => s.id === draftId);
      if (draft) {
        if (draft.panchayatId) setSelectedPanchayatId(draft.panchayatId);
        if (draft.villageId) setSelectedVillageId(draft.villageId);
        if (draft.dayNumber) setSelectedDay(draft.dayNumber);
        if (draft.date) setSessionDate(draft.date);
        if (draft.sessionName) setSessionTitle(draft.sessionName);
        if (draft.taskTopic) setTaskTopic(draft.taskTopic);
        const newMap = {};
        draft.records.forEach((rec) => {
          newMap[rec.studentId] = rec;
        });
        setRecordsMap(newMap);
        setActiveDraftSessionId(draft.id);
        return;
      }
    }
    setRecordsMap((prev) => {
      const updated = { ...prev };
      filteredStudents.forEach((st) => {
        if (!updated[st.id]) {
          updated[st.id] = {
            studentId: st.id,
            studentName: st.name,
            code: st.code,
            standard: st.standard,
            villageName: st.villageName,
            status: "Present",
            taskStatus: "Completed",
            taskTitle: taskTopic,
            remarks: ""
          };
        }
      });
      return updated;
    });
  }, [selectedPanchayatId, selectedVillageId, draftId, filteredStudents, taskTopic, attendanceSessions]);
  const handleToggleAttendance = (studentId, status) => {
    setRecordsMap((prev) => {
      const current = prev[studentId] || {
        studentId,
        studentName: students.find((s) => s.id === studentId)?.name || "Student",
        code: students.find((s) => s.id === studentId)?.code || "",
        standard: students.find((s) => s.id === studentId)?.standard || "",
        villageName: students.find((s) => s.id === studentId)?.villageName || "",
        status: "Present",
        taskStatus: "Completed"
      };
      return {
        ...prev,
        [studentId]: {
          ...current,
          status,
          taskStatus: status === "Absent" ? "Not Completed" : current.taskStatus || "Completed"
        }
      };
    });
  };
  const handleToggleTask = (studentId, taskStatus) => {
    setRecordsMap((prev) => {
      const current = prev[studentId] || {
        studentId,
        studentName: students.find((s) => s.id === studentId)?.name || "Student",
        code: students.find((s) => s.id === studentId)?.code || "",
        standard: students.find((s) => s.id === studentId)?.standard || "",
        villageName: students.find((s) => s.id === studentId)?.villageName || "",
        status: "Present",
        taskStatus: "Completed"
      };
      return {
        ...prev,
        [studentId]: {
          ...current,
          taskStatus
        }
      };
    });
  };
  const markAllAttendance = (status) => {
    setRecordsMap((prev) => {
      const updated = { ...prev };
      filteredStudents.forEach((st) => {
        const existing = updated[st.id] || {
          studentId: st.id,
          studentName: st.name,
          code: st.code,
          standard: st.standard,
          villageName: st.villageName,
          status: "Present",
          taskStatus: "Completed"
        };
        updated[st.id] = {
          ...existing,
          status,
          taskStatus: status === "Absent" ? "Not Completed" : existing.taskStatus || "Completed"
        };
      });
      return updated;
    });
  };
  const markAllTasks = (taskStatus) => {
    setRecordsMap((prev) => {
      const updated = { ...prev };
      filteredStudents.forEach((st) => {
        const existing = updated[st.id] || {
          studentId: st.id,
          studentName: st.name,
          code: st.code,
          standard: st.standard,
          villageName: st.villageName,
          status: "Present",
          taskStatus: "Completed"
        };
        updated[st.id] = {
          ...existing,
          taskStatus
        };
      });
      return updated;
    });
  };
  const currentRecordsList = useMemo(() => {
    return filteredStudents.map((st) => {
      const record = recordsMap[st.id];
      if (record) return record;
      return {
        studentId: st.id,
        studentName: st.name,
        code: st.code,
        standard: st.standard,
        villageName: st.villageName,
        status: "Present",
        taskStatus: "Completed",
        taskTitle: taskTopic,
        remarks: ""
      };
    });
  }, [filteredStudents, recordsMap, taskTopic]);
  const presentCount = useMemo(
    () => currentRecordsList.filter((r) => r.status === "Present" || r.status === "Late").length,
    [currentRecordsList]
  );
  const absentCount = useMemo(
    () => currentRecordsList.filter((r) => r.status === "Absent").length,
    [currentRecordsList]
  );
  const tasksCompletedCount = useMemo(
    () => currentRecordsList.filter((r) => r.taskStatus === "Completed").length,
    [currentRecordsList]
  );
  const selectedVillageName = useMemo(() => {
    if (selectedVillageId === "all") return "All Villages";
    return availableVillages.find((v) => v.id === selectedVillageId)?.name || "Village";
  }, [selectedVillageId, availableVillages]);
  const handleSaveAttendanceSession = (isFinalSubmit) => {
    if (filteredStudents.length === 0) {
      alert("No students found for this Panchayat and Village. Please add students first.");
      return;
    }
    const sessionIdToSave = activeDraftSessionId || `att-${Date.now()}`;
    const newSession = {
      id: sessionIdToSave,
      sessionId: `ses-day${selectedDay}`,
      sessionName: sessionTitle || `Day ${selectedDay} Session`,
      panchayatId: selectedPanchayatId,
      panchayatName: currentPanchayat?.name || "Panchayat",
      villageId: selectedVillageId,
      villageName: selectedVillageName,
      date: sessionDate,
      day: `Day ${selectedDay}`,
      dayNumber: selectedDay,
      taskTopic,
      totalCount: filteredStudents.length,
      presentCount,
      absentCount,
      tasksCompletedCount,
      status: isFinalSubmit ? "Submitted" : "Draft",
      lastSaved: isFinalSubmit ? "Submitted just now" : "Saved just now",
      records: currentRecordsList
    };
    onSaveAttendance(newSession);
    setActiveDraftSessionId(sessionIdToSave);
    setSaveSuccessMsg(
      isFinalSubmit ? `Day ${selectedDay} Attendance & Task records submitted successfully for ${currentPanchayat?.name || "Panchayat"} (${selectedVillageName})!` : `Day ${selectedDay} Attendance Draft saved successfully!`
    );
    setTimeout(() => setSaveSuccessMsg(""), 4500);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Attendance & Task Entry" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 304,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            "Day ",
            selectedDay
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 307,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 303,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Step 1: Select Panchayat → Step 2: Select Village → Step 3: Mark Present/Absent & Tasks." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 311,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 302,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 self-start sm:self-auto", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTab("mark"),
            className: `rounded-xl px-4 py-2.5 text-xs font-semibold transition shadow-theme-xs ${activeTab === "mark" ? "bg-brand-500 text-white" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5"}`,
            children: "Mark Attendance & Tasks"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 317,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveTab("history"),
            className: `rounded-xl px-4 py-2.5 text-xs font-semibold transition shadow-theme-xs ${activeTab === "history" ? "bg-brand-500 text-white" : "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5"}`,
            children: [
              "History (",
              attendanceSessions.length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 328,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 316,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
      lineNumber: 301,
      columnNumber: 7
    }, this),
    saveSuccessMsg && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-success-200 bg-success-50 p-4 text-xs font-medium text-success-600 dark:border-success-900/40 dark:bg-success-500/10 dark:text-success-400 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("span", { children: saveSuccessMsg }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 344,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setSaveSuccessMsg(""),
          className: "text-success-600 hover:text-success-800 dark:text-success-400",
          children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "close" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 350,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 345,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
      lineNumber: 343,
      columnNumber: 7
    }, this),
    activeTab === "mark" ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 pb-2 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5 text-brand-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 363,
                columnNumber: 19
              }, this),
              "1. Panchayat"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 362,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedPanchayatId,
                onValueChange: (val) => handlePanchayatChange(val),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 371,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 370,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: [
                      p.name,
                      " Panchayat (",
                      p.activeStudents,
                      " students)"
                    ] }, p.id, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 375,
                      columnNumber: 19
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 373,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 366,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 361,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(MapPin, { className: "w-3.5 h-3.5 text-brand-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 386,
                columnNumber: 19
              }, this),
              "2. Village / Center"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 385,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedVillageId,
                onValueChange: (val) => setSelectedVillageId(val),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Village" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 394,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 393,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: [
                      "All Villages (",
                      currentPanchayat?.name || "Cluster",
                      ")"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 397,
                      columnNumber: 21
                    }, this),
                    availableVillages.map(
                      (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.id, children: [
                        v.name,
                        " (",
                        v.studentCount,
                        " students)"
                      ] }, v.id, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 399,
                        columnNumber: 19
                      }, this)
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 396,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 389,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 384,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-brand-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 410,
                columnNumber: 19
              }, this),
              "3. Date & Day"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 409,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: sessionDate,
                  onChange: (e) => setSessionDate(e.target.value),
                  disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                  className: "flex-1 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-medium text-gray-800 shadow-theme-xs focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white disabled:opacity-50"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 414,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "w-28", children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: String(selectedDay),
                  onValueChange: (val) => setSelectedDay(parseInt(val) || 1),
                  disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full text-brand-500 font-bold disabled:opacity-50", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Day" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 428,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 427,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(
                      (d) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(d), children: [
                        "Day ",
                        d
                      ] }, d, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 432,
                        columnNumber: 23
                      }, this)
                    ) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 430,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 422,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 421,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 413,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 408,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 359,
          columnNumber: 13
        }, this),
        (() => {
          const activeSession = attendanceSessions.find((s) => s.id === activeDraftSessionId);
          if (activeSession && ["Submitted", "Approved", "Completed"].includes(activeSession.status)) {
            return /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-xl p-3 flex items-center gap-2 text-sm text-gray-700", children: [
              /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 text-success-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 449,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "This attendance has been ",
                activeSession.status.toLowerCase(),
                " and cannot be edited."
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 450,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 448,
              columnNumber: 17
            }, this);
          }
          if (activeSession && activeSession.status === "Correction Requested") {
            return /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center gap-2 text-sm text-amber-800", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px] text-amber-600", children: "warning" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 457,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Correction Requested: ",
                activeSession.correctionReason || "Please review and resubmit."
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 458,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 456,
              columnNumber: 17
            }, this);
          }
          return null;
        })(),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-500 dark:text-gray-400 whitespace-nowrap", children: "Today's Topic:" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 468,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "e.g., Phonics Worksheet & Speaking Practice",
                value: taskTopic,
                onChange: (e) => setTaskTopic(e.target.value),
                className: "flex-1 rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-800 shadow-theme-xs focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 471,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 467,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 overflow-x-auto", children: [1, 2, 3, 4, 5, 6].map(
            (day) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setSelectedDay(day),
                className: `rounded-lg px-2.5 py-1 text-xs font-medium transition ${selectedDay === day ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"}`,
                children: [
                  "Day ",
                  day
                ]
              },
              day,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 483,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 481,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 466,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 358,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Enrolled" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 503,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: filteredStudents.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 504,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-400 truncate", children: [
            currentPanchayat?.name || "Panchayat",
            " · ",
            selectedVillageName
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 505,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 502,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-success-500", children: "Present" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 511,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: presentCount }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 512,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-medium text-success-500", children: filteredStudents.length > 0 ? `${Math.round(presentCount / filteredStudents.length * 100)}% Attendance` : "0%" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 513,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 510,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-error-500", children: "Absent" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 521,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: absentCount }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 522,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-medium text-error-500", children: filteredStudents.length > 0 ? `${Math.round(absentCount / filteredStudents.length * 100)}% Absent` : "0%" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 523,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 520,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-warning-500", children: "Tasks Completed" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 531,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: tasksCompletedCount }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 532,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs font-medium text-warning-500", children: filteredStudents.length > 0 ? `${Math.round(tasksCompletedCount / filteredStudents.length * 100)}% Tasks Done` : "0%" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 533,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 530,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 501,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3 pt-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-500 dark:text-gray-400", children: "Attendance:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 544,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => markAllAttendance("Present"),
              disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
              className: "inline-flex items-center gap-1.5 rounded-xl border border-success-200 bg-success-50 px-3 py-1.5 text-xs font-semibold text-success-600 hover:bg-success-100 dark:border-success-900/40 dark:bg-success-500/10 dark:text-success-400 transition disabled:opacity-50 disabled:cursor-not-allowed",
              children: [
                /* @__PURE__ */ jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 551,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "All Present" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 552,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 545,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => markAllAttendance("Absent"),
              disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
              className: "inline-flex items-center gap-1.5 rounded-xl border border-error-200 bg-error-50 px-3 py-1.5 text-xs font-semibold text-error-600 hover:bg-error-100 dark:border-error-900/40 dark:bg-error-500/10 dark:text-error-400 transition disabled:opacity-50 disabled:cursor-not-allowed",
              children: [
                /* @__PURE__ */ jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 560,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "All Absent" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 561,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 554,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 543,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-500 dark:text-gray-400", children: "Tasks:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 566,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => markAllTasks("Completed"),
              disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
              className: "inline-flex items-center gap-1.5 rounded-xl border border-success-200 bg-success-50 px-3 py-1.5 text-xs font-semibold text-success-600 hover:bg-success-100 dark:border-success-900/40 dark:bg-success-500/10 dark:text-success-400 transition disabled:opacity-50 disabled:cursor-not-allowed",
              children: [
                /* @__PURE__ */ jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 573,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "All Tasks Done" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 574,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 567,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => markAllTasks("Not Completed"),
              disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
              className: "inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition disabled:opacity-50 disabled:cursor-not-allowed",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Reset Tasks" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 582,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 576,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 565,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 542,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider", children: [
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Student Roster (",
            filteredStudents.length,
            " Enrolled)"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 590,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] lowercase font-normal", children: "Attendance & Task status" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 593,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 589,
          columnNumber: 13
        }, this),
        filteredStudents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-12 text-center text-gray-400 text-xs", children: "No students found in this selection." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 597,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-gray-100 dark:divide-gray-800", children: filteredStudents.map((st) => {
          const record = recordsMap[st.id] || {
            studentId: st.id,
            studentName: st.name,
            code: st.code,
            standard: st.standard,
            villageName: st.villageName,
            status: "Present",
            taskStatus: "Completed",
            taskTitle: taskTopic,
            remarks: ""
          };
          const isPresent = record.status === "Present";
          const isAbsent = record.status === "Absent";
          const isTaskCompleted = record.taskStatus === "Completed";
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${isAbsent ? "bg-error-50/20 dark:bg-error-950/10" : "hover:bg-gray-50/80 dark:hover:bg-white/[0.02]"}`,
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "w-8 h-8 rounded-full bg-brand-50 text-brand-500 flex items-center justify-center font-bold text-xs shrink-0 dark:bg-brand-500/10 dark:text-brand-400",
                      children: st.avatarLetter || st.name.charAt(0)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 628,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white", children: st.name }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 635,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-[10px] text-gray-400", children: st.code }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 636,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 634,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-0.5", children: [
                      "Std ",
                      st.standard,
                      " · ",
                      st.villageName,
                      " · Parent: ",
                      st.parentName || "—"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                      lineNumber: 640,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 633,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 627,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 self-start sm:self-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleAttendance(st.id, "Present"),
                        disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                        className: `rounded-lg px-2.5 py-1 text-xs font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed ${isPresent ? "bg-success-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"}`,
                        children: "Present"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 649,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleAttendance(st.id, "Absent"),
                        disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                        className: `rounded-lg px-2.5 py-1 text-xs font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed ${isAbsent ? "bg-error-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"}`,
                        children: "Absent"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 661,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 648,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-l border-gray-200 pl-3 dark:border-gray-800 flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleTask(st.id, "Completed"),
                        disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                        className: `rounded-lg px-2.5 py-1 text-xs font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed ${isTaskCompleted ? "bg-brand-500 text-white shadow-theme-xs" : "border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"}`,
                        children: "Task Done"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 676,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleToggleTask(st.id, "Not Completed"),
                        disabled: ["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || ""),
                        className: `rounded-lg px-2.5 py-1 text-xs font-semibold transition disabled:opacity-50 disabled:cursor-not-allowed ${!isTaskCompleted ? "bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-white" : "border border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300"}`,
                        children: "Pending"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                        lineNumber: 688,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                    lineNumber: 675,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 647,
                  columnNumber: 23
                }, this)
              ]
            },
            st.id,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 620,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 601,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 588,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-3 pt-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-900 dark:text-white", children: [
            "Day ",
            selectedDay,
            ":"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 712,
            columnNumber: 15
          }, this),
          " ",
          presentCount,
          " Present · ",
          absentCount,
          " Absent · ",
          tasksCompletedCount,
          " Tasks Done"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 711,
          columnNumber: 13
        }, this),
        !["Submitted", "Approved", "Completed"].includes(attendanceSessions.find((s) => s.id === activeDraftSessionId)?.status || "") && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 w-full sm:w-auto justify-end", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleSaveAttendanceSession(false),
              className: "rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
              children: "Save as Draft"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 718,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            ActionButton,
            {
              onClick: () => handleSaveAttendanceSession(true),
              size: "sm",
              variant: "primary",
              children: "Submit Attendance & Tasks"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 725,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 717,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 710,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
      lineNumber: 356,
      columnNumber: 7
    }, this) : (
      /* SESSION HISTORY TAB */
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Past Recorded Attendance & Task Sessions" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 740,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-400", children: [
            attendanceSessions.length,
            " Sessions Logged"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 743,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 739,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-white/[0.02] dark:text-gray-400", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Session & Day" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 752,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Panchayat & Village" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 753,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 754,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Attendance" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 755,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Tasks Done" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 756,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 757,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5 text-right", children: "Actions" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 758,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 751,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 750,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-100 dark:divide-gray-800 text-xs", children: attendanceSessions.map(
            (session) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors", children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 font-bold text-gray-900 dark:text-white", children: [
                session.day || `Day ${session.dayNumber}`,
                /* @__PURE__ */ jsxDEV("span", { className: "block text-[11px] font-normal text-gray-400", children: session.sessionName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 766,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 764,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-gray-700 dark:text-gray-300", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-900 dark:text-white", children: session.panchayatName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 771,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "block text-[11px] text-gray-400", children: session.villageName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 772,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 770,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-gray-500 dark:text-gray-400 font-mono", children: session.date }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 776,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-success-500", children: session.presentCount || 0 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 778,
                  columnNumber: 23
                }, this),
                " /",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500", children: session.totalCount || session.records.length }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 779,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 777,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 font-bold text-warning-500", children: [
                session.tasksCompletedCount ?? session.records.filter((r) => r.taskStatus === "Completed").length,
                " ",
                "/ ",
                session.records.length
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 781,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: /* @__PURE__ */ jsxDEV(
                Badge,
                {
                  color: session.status === "Submitted" ? "success" : session.status === "Correction Requested" ? "error" : "primary",
                  size: "sm",
                  children: session.status
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 787,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 786,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-right", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    if (session.panchayatId) setSelectedPanchayatId(session.panchayatId);
                    if (session.villageId) setSelectedVillageId(session.villageId);
                    if (session.dayNumber) setSelectedDay(session.dayNumber);
                    if (session.date) setSessionDate(session.date);
                    if (session.sessionName) setSessionTitle(session.sessionName);
                    if (session.taskTopic) setTaskTopic(session.taskTopic);
                    const map = {};
                    session.records.forEach((r) => {
                      map[r.studentId] = r;
                    });
                    setRecordsMap(map);
                    setActiveDraftSessionId(session.id);
                    setActiveTab("mark");
                  },
                  className: "text-xs font-bold text-brand-500 hover:text-brand-600 transition",
                  children: session.status === "Draft" || session.status === "Correction Requested" ? "Continue Entry →" : "View / Edit →"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                  lineNumber: 801,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
                lineNumber: 800,
                columnNumber: 21
              }, this)
            ] }, session.id, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
              lineNumber: 763,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
            lineNumber: 761,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 749,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
          lineNumber: 748,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
        lineNumber: 738,
        columnNumber: 7
      }, this)
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx",
    lineNumber: 299,
    columnNumber: 5
  }, this);
};
_s(AttendanceView, "NIsVHckRiYDiRjSkHteAzj9/t8Y=");
_c = AttendanceView;
var _c;
$RefreshReg$(_c, "AttendanceView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AttendanceView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1NZOztBQS9TWixTQUFnQkEsVUFBVUMsU0FBU0MsaUJBQWlCO0FBRXBELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsT0FBT0MsR0FBR0MsVUFBVUMsUUFBa0JDLG9CQUFvQjtBQUNuRTtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxvQkFBb0I7QUFXdEIsYUFBTUMsaUJBQWdEQSxDQUFDO0FBQUEsRUFDNURDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBRUosUUFBTSxDQUFDQyxxQkFBcUJDLHNCQUFzQixJQUFJdkI7QUFBQUEsSUFDcERrQixXQUFXLENBQUMsR0FBR00sTUFBTTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJMUIsU0FBaUIsS0FBSztBQUd4RUUsWUFBVSxNQUFNO0FBQ2QsUUFBSWdCLFdBQVdTLFNBQVMsR0FBRztBQUN6QixZQUFNQyxTQUFTVixXQUFXVyxLQUFLLENBQUNDLE1BQU1BLEVBQUVOLE9BQU9GLG1CQUFtQjtBQUNsRSxVQUFJLENBQUNNLFFBQVE7QUFDWEwsK0JBQXVCTCxXQUFXLENBQUMsRUFBRU0sRUFBRTtBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDTixZQUFZSSxtQkFBbUIsQ0FBQztBQUNwQyxRQUFNLENBQUNTLGFBQWFDLGNBQWMsSUFBSWhDLFNBQWlCLENBQUM7QUFDeEQsUUFBTSxDQUFDaUMsYUFBYUMsY0FBYyxJQUFJbEMsU0FBaUIsWUFBWTtBQUNuRSxRQUFNLENBQUNtQyxjQUFjQyxlQUFlLElBQUlwQyxTQUFpQixvQ0FBb0M7QUFDN0YsUUFBTSxDQUFDcUMsV0FBV0MsWUFBWSxJQUFJdEMsU0FBaUIsa0NBQWtDO0FBQ3JGLFFBQU0sQ0FBQ3VDLFdBQVdDLFlBQVksSUFBSXhDLFNBQTZCLE1BQU07QUFDckUsUUFBTSxDQUFDeUMsZ0JBQWdCQyxpQkFBaUIsSUFBSTFDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUMyQyxzQkFBc0JDLHVCQUF1QixJQUFJNUMsU0FBd0JtQixXQUFXLElBQUk7QUFHL0YsUUFBTTBCLG1CQUFtQjVDLFFBQVEsTUFBTTtBQUNyQyxXQUFPaUIsV0FBVzRCLEtBQUssQ0FBQ2hCLE1BQU1BLEVBQUVOLE9BQU9GLG1CQUFtQixLQUFLSixXQUFXLENBQUM7QUFBQSxFQUM3RSxHQUFHLENBQUNBLFlBQVlJLG1CQUFtQixDQUFDO0FBRXBDLFFBQU15QixvQkFBb0I5QyxRQUFRLE1BQU07QUFDdEMsV0FBTzRDLGtCQUFrQkcsWUFBWTtBQUFBLEVBQ3ZDLEdBQUcsQ0FBQ0gsZ0JBQWdCLENBQUM7QUFHckIsUUFBTUksd0JBQXdCQSxDQUFDQyxnQkFBd0I7QUFDckQzQiwyQkFBdUIyQixXQUFXO0FBQ2xDLFVBQU1DLFFBQVFqQyxXQUFXNEIsS0FBSyxDQUFDaEIsTUFBTUEsRUFBRU4sT0FBTzBCLFdBQVc7QUFDekQsUUFBSUMsU0FBU0EsTUFBTUgsWUFBWUcsTUFBTUgsU0FBU3JCLFNBQVMsR0FBRztBQUN4REQsMkJBQXFCeUIsTUFBTUgsU0FBUyxDQUFDLEVBQUV4QixFQUFFO0FBQUEsSUFDM0MsT0FBTztBQUNMRSwyQkFBcUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUdBLFFBQU0wQixtQkFBbUJuRCxRQUFRLE1BQU07QUFDckMsV0FBT2dCLFNBQVNvQyxPQUFPLENBQUNDLE1BQU07QUFDNUIsWUFBTUMsaUJBQWlCRCxFQUFFSixnQkFBZ0I1QjtBQUN6QyxZQUFNa0MsZUFBZS9CLHNCQUFzQixTQUFTNkIsRUFBRUcsY0FBY2hDO0FBQ3BFLGFBQU84QixrQkFBa0JDO0FBQUFBLElBQzNCLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ3ZDLFVBQVVLLHFCQUFxQkcsaUJBQWlCLENBQUM7QUFHckQsUUFBTSxDQUFDaUMsWUFBWUMsYUFBYSxJQUFJM0QsU0FBMkMsQ0FBQyxDQUFDO0FBR2pGRSxZQUFVLE1BQU07QUFDZCxRQUFJaUIsU0FBUztBQUNYLFlBQU15QyxRQUFRNUMsbUJBQW1COEIsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUIsT0FBT0wsT0FBTztBQUM3RCxVQUFJeUMsT0FBTztBQUNULFlBQUlBLE1BQU1WLFlBQWEzQix3QkFBdUJxQyxNQUFNVixXQUFXO0FBQy9ELFlBQUlVLE1BQU1ILFVBQVcvQixzQkFBcUJrQyxNQUFNSCxTQUFTO0FBQ3pELFlBQUlHLE1BQU1DLFVBQVc3QixnQkFBZTRCLE1BQU1DLFNBQVM7QUFDbkQsWUFBSUQsTUFBTUUsS0FBTTVCLGdCQUFlMEIsTUFBTUUsSUFBSTtBQUN6QyxZQUFJRixNQUFNRyxZQUFhM0IsaUJBQWdCd0IsTUFBTUcsV0FBVztBQUN4RCxZQUFJSCxNQUFNdkIsVUFBV0MsY0FBYXNCLE1BQU12QixTQUFTO0FBRWpELGNBQU0yQixTQUEyQyxDQUFDO0FBQ2xESixjQUFNSyxRQUFRQyxRQUFRLENBQUNDLFFBQVE7QUFDN0JILGlCQUFPRyxJQUFJQyxTQUFTLElBQUlEO0FBQUFBLFFBQzFCLENBQUM7QUFDRFIsc0JBQWNLLE1BQU07QUFDcEJwQixnQ0FBd0JnQixNQUFNcEMsRUFBRTtBQUNoQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBR0FtQyxrQkFBYyxDQUFDVSxTQUFTO0FBQ3RCLFlBQU1DLFVBQTRDLEVBQUUsR0FBR0QsS0FBSztBQUM1RGpCLHVCQUFpQmMsUUFBUSxDQUFDSyxPQUFPO0FBQy9CLFlBQUksQ0FBQ0QsUUFBUUMsR0FBRy9DLEVBQUUsR0FBRztBQUNuQjhDLGtCQUFRQyxHQUFHL0MsRUFBRSxJQUFJO0FBQUEsWUFDZjRDLFdBQVdHLEdBQUcvQztBQUFBQSxZQUNkZ0QsYUFBYUQsR0FBR0U7QUFBQUEsWUFDaEJDLE1BQU1ILEdBQUdHO0FBQUFBLFlBQ1RDLFVBQVVKLEdBQUdJO0FBQUFBLFlBQ2JDLGFBQWFMLEdBQUdLO0FBQUFBLFlBQ2hCQyxRQUFRO0FBQUEsWUFDUkMsWUFBWTtBQUFBLFlBQ1pDLFdBQVcxQztBQUFBQSxZQUNYMkMsU0FBUztBQUFBLFVBQ1g7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBT1Y7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNoRCxxQkFBcUJHLG1CQUFtQk4sU0FBU2lDLGtCQUFrQmYsV0FBV3JCLGtCQUFrQixDQUFDO0FBR3JHLFFBQU1pRSx5QkFBeUJBLENBQUNiLFdBQW1CUyxXQUEwQztBQUMzRmxCLGtCQUFjLENBQUNVLFNBQVM7QUFDdEIsWUFBTWEsVUFBVWIsS0FBS0QsU0FBUyxLQUFLO0FBQUEsUUFDakNBO0FBQUFBLFFBQ0FJLGFBQWF2RCxTQUFTNkIsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUIsT0FBTzRDLFNBQVMsR0FBR0ssUUFBUTtBQUFBLFFBQy9EQyxNQUFNekQsU0FBUzZCLEtBQUssQ0FBQ1EsTUFBTUEsRUFBRTlCLE9BQU80QyxTQUFTLEdBQUdNLFFBQVE7QUFBQSxRQUN4REMsVUFBVTFELFNBQVM2QixLQUFLLENBQUNRLE1BQU1BLEVBQUU5QixPQUFPNEMsU0FBUyxHQUFHTyxZQUFZO0FBQUEsUUFDaEVDLGFBQWEzRCxTQUFTNkIsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUIsT0FBTzRDLFNBQVMsR0FBR1EsZUFBZTtBQUFBLFFBQ3RFQyxRQUFRO0FBQUEsUUFDUkMsWUFBWTtBQUFBLE1BQ2Q7QUFFQSxhQUFPO0FBQUEsUUFDTCxHQUFHVDtBQUFBQSxRQUNILENBQUNELFNBQVMsR0FBRztBQUFBLFVBQ1gsR0FBR2M7QUFBQUEsVUFDSEw7QUFBQUEsVUFDQUMsWUFBWUQsV0FBVyxXQUFXLGtCQUFrQkssUUFBUUosY0FBYztBQUFBLFFBQzVFO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFHQSxRQUFNSyxtQkFBbUJBLENBQUNmLFdBQW1CVSxlQUE4QztBQUN6Rm5CLGtCQUFjLENBQUNVLFNBQVM7QUFDdEIsWUFBTWEsVUFBVWIsS0FBS0QsU0FBUyxLQUFLO0FBQUEsUUFDakNBO0FBQUFBLFFBQ0FJLGFBQWF2RCxTQUFTNkIsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUIsT0FBTzRDLFNBQVMsR0FBR0ssUUFBUTtBQUFBLFFBQy9EQyxNQUFNekQsU0FBUzZCLEtBQUssQ0FBQ1EsTUFBTUEsRUFBRTlCLE9BQU80QyxTQUFTLEdBQUdNLFFBQVE7QUFBQSxRQUN4REMsVUFBVTFELFNBQVM2QixLQUFLLENBQUNRLE1BQU1BLEVBQUU5QixPQUFPNEMsU0FBUyxHQUFHTyxZQUFZO0FBQUEsUUFDaEVDLGFBQWEzRCxTQUFTNkIsS0FBSyxDQUFDUSxNQUFNQSxFQUFFOUIsT0FBTzRDLFNBQVMsR0FBR1EsZUFBZTtBQUFBLFFBQ3RFQyxRQUFRO0FBQUEsUUFDUkMsWUFBWTtBQUFBLE1BQ2Q7QUFFQSxhQUFPO0FBQUEsUUFDTCxHQUFHVDtBQUFBQSxRQUNILENBQUNELFNBQVMsR0FBRztBQUFBLFVBQ1gsR0FBR2M7QUFBQUEsVUFDSEo7QUFBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTU0sb0JBQW9CQSxDQUFDUCxXQUFpQztBQUMxRGxCLGtCQUFjLENBQUNVLFNBQVM7QUFDdEIsWUFBTUMsVUFBVSxFQUFFLEdBQUdELEtBQUs7QUFDMUJqQix1QkFBaUJjLFFBQVEsQ0FBQ0ssT0FBTztBQUMvQixjQUFNYyxXQUFXZixRQUFRQyxHQUFHL0MsRUFBRSxLQUFLO0FBQUEsVUFDakM0QyxXQUFXRyxHQUFHL0M7QUFBQUEsVUFDZGdELGFBQWFELEdBQUdFO0FBQUFBLFVBQ2hCQyxNQUFNSCxHQUFHRztBQUFBQSxVQUNUQyxVQUFVSixHQUFHSTtBQUFBQSxVQUNiQyxhQUFhTCxHQUFHSztBQUFBQSxVQUNoQkMsUUFBUTtBQUFBLFVBQ1JDLFlBQVk7QUFBQSxRQUNkO0FBQ0FSLGdCQUFRQyxHQUFHL0MsRUFBRSxJQUFJO0FBQUEsVUFDZixHQUFHNkQ7QUFBQUEsVUFDSFI7QUFBQUEsVUFDQUMsWUFBWUQsV0FBVyxXQUFXLGtCQUFrQlEsU0FBU1AsY0FBYztBQUFBLFFBQzdFO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBT1I7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1nQixlQUFlQSxDQUFDUixlQUE4QztBQUNsRW5CLGtCQUFjLENBQUNVLFNBQVM7QUFDdEIsWUFBTUMsVUFBVSxFQUFFLEdBQUdELEtBQUs7QUFDMUJqQix1QkFBaUJjLFFBQVEsQ0FBQ0ssT0FBTztBQUMvQixjQUFNYyxXQUFXZixRQUFRQyxHQUFHL0MsRUFBRSxLQUFLO0FBQUEsVUFDakM0QyxXQUFXRyxHQUFHL0M7QUFBQUEsVUFDZGdELGFBQWFELEdBQUdFO0FBQUFBLFVBQ2hCQyxNQUFNSCxHQUFHRztBQUFBQSxVQUNUQyxVQUFVSixHQUFHSTtBQUFBQSxVQUNiQyxhQUFhTCxHQUFHSztBQUFBQSxVQUNoQkMsUUFBUTtBQUFBLFVBQ1JDLFlBQVk7QUFBQSxRQUNkO0FBQ0FSLGdCQUFRQyxHQUFHL0MsRUFBRSxJQUFJO0FBQUEsVUFDZixHQUFHNkQ7QUFBQUEsVUFDSFA7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUNELGFBQU9SO0FBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFHQSxRQUFNaUIscUJBQXlDdEYsUUFBUSxNQUFNO0FBQzNELFdBQU9tRCxpQkFBaUJvQyxJQUFJLENBQUNqQixPQUFPO0FBQ2xDLFlBQU1rQixTQUFTL0IsV0FBV2EsR0FBRy9DLEVBQUU7QUFDL0IsVUFBSWlFLE9BQVEsUUFBT0E7QUFDbkIsYUFBTztBQUFBLFFBQ0xyQixXQUFXRyxHQUFHL0M7QUFBQUEsUUFDZGdELGFBQWFELEdBQUdFO0FBQUFBLFFBQ2hCQyxNQUFNSCxHQUFHRztBQUFBQSxRQUNUQyxVQUFVSixHQUFHSTtBQUFBQSxRQUNiQyxhQUFhTCxHQUFHSztBQUFBQSxRQUNoQkMsUUFBUTtBQUFBLFFBQ1JDLFlBQVk7QUFBQSxRQUNaQyxXQUFXMUM7QUFBQUEsUUFDWDJDLFNBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUM1QixrQkFBa0JNLFlBQVlyQixTQUFTLENBQUM7QUFFNUMsUUFBTXFELGVBQWV6RjtBQUFBQSxJQUNuQixNQUFNc0YsbUJBQW1CbEMsT0FBTyxDQUFDc0MsTUFBTUEsRUFBRWQsV0FBVyxhQUFhYyxFQUFFZCxXQUFXLE1BQU0sRUFBRWxEO0FBQUFBLElBQ3RGLENBQUM0RCxrQkFBa0I7QUFBQSxFQUNyQjtBQUNBLFFBQU1LLGNBQWMzRjtBQUFBQSxJQUNsQixNQUFNc0YsbUJBQW1CbEMsT0FBTyxDQUFDc0MsTUFBTUEsRUFBRWQsV0FBVyxRQUFRLEVBQUVsRDtBQUFBQSxJQUM5RCxDQUFDNEQsa0JBQWtCO0FBQUEsRUFDckI7QUFDQSxRQUFNTSxzQkFBc0I1RjtBQUFBQSxJQUMxQixNQUFNc0YsbUJBQW1CbEMsT0FBTyxDQUFDc0MsTUFBTUEsRUFBRWIsZUFBZSxXQUFXLEVBQUVuRDtBQUFBQSxJQUNyRSxDQUFDNEQsa0JBQWtCO0FBQUEsRUFDckI7QUFFQSxRQUFNTyxzQkFBc0I3RixRQUFRLE1BQU07QUFDeEMsUUFBSXdCLHNCQUFzQixNQUFPLFFBQU87QUFDeEMsV0FBT3NCLGtCQUFrQkQsS0FBSyxDQUFDaUQsTUFBTUEsRUFBRXZFLE9BQU9DLGlCQUFpQixHQUFHZ0QsUUFBUTtBQUFBLEVBQzVFLEdBQUcsQ0FBQ2hELG1CQUFtQnNCLGlCQUFpQixDQUFDO0FBR3pDLFFBQU1pRCw4QkFBOEJBLENBQUNDLGtCQUEyQjtBQUM5RCxRQUFJN0MsaUJBQWlCekIsV0FBVyxHQUFHO0FBQ2pDdUUsWUFBTSw4RUFBOEU7QUFDcEY7QUFBQSxJQUNGO0FBRUEsVUFBTUMsa0JBQWtCeEQsd0JBQXdCLE9BQU95RCxLQUFLQyxJQUFJLENBQUM7QUFDakUsVUFBTUMsYUFBZ0M7QUFBQSxNQUNwQzlFLElBQUkyRTtBQUFBQSxNQUNKSSxXQUFXLFVBQVV4RSxXQUFXO0FBQUEsTUFDaENnQyxhQUFhNUIsZ0JBQWdCLE9BQU9KLFdBQVc7QUFBQSxNQUMvQ21CLGFBQWE1QjtBQUFBQSxNQUNia0YsZUFBZTNELGtCQUFrQjRCLFFBQVE7QUFBQSxNQUN6Q2hCLFdBQVdoQztBQUFBQSxNQUNYbUQsYUFBYWtCO0FBQUFBLE1BQ2JoQyxNQUFNN0I7QUFBQUEsTUFDTndFLEtBQUssT0FBTzFFLFdBQVc7QUFBQSxNQUN2QjhCLFdBQVc5QjtBQUFBQSxNQUNYTTtBQUFBQSxNQUNBcUUsWUFBWXRELGlCQUFpQnpCO0FBQUFBLE1BQzdCK0Q7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQWhCLFFBQVFvQixnQkFBZ0IsY0FBYztBQUFBLE1BQ3RDVSxXQUFXVixnQkFBZ0IsdUJBQXVCO0FBQUEsTUFDbERoQyxTQUFTc0I7QUFBQUEsSUFDWDtBQUVBbkUscUJBQWlCa0YsVUFBVTtBQUMzQjFELDRCQUF3QnVELGVBQWU7QUFDdkN6RDtBQUFBQSxNQUNFdUQsZ0JBQ0ksT0FBT2xFLFdBQVcseURBQXlEYyxrQkFBa0I0QixRQUFRLFdBQVcsS0FBS3FCLG1CQUFtQixPQUN4SSxPQUFPL0QsV0FBVztBQUFBLElBQ3hCO0FBQ0E2RSxlQUFXLE1BQU1sRSxrQkFBa0IsRUFBRSxHQUFHLElBQUk7QUFBQSxFQUM5QztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw4RUFBNEUsdUNBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBSTtBQUFBO0FBQUEsWUFDekJYO0FBQUFBLGVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQStDLHdHQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTVMsYUFBYSxNQUFNO0FBQUEsWUFDbEMsV0FBVywyRUFDVEQsY0FBYyxTQUNWLDRCQUNBLCtJQUErSTtBQUFBLFlBQ2xKO0FBQUE7QUFBQSxVQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNQyxhQUFhLFNBQVM7QUFBQSxZQUNyQyxXQUFXLDJFQUNURCxjQUFjLFlBQ1YsNEJBQ0EsK0lBQStJO0FBQUEsWUFDbEo7QUFBQTtBQUFBLGNBRU92QixtQkFBbUJXO0FBQUFBLGNBQU87QUFBQTtBQUFBO0FBQUEsVUFUdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsU0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLElBRUNjLGtCQUNDLHVCQUFDLFNBQUksV0FBVSx5TUFDYjtBQUFBLDZCQUFDLFVBQU1BLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUN0QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNQyxrQkFBa0IsRUFBRTtBQUFBLFVBQ25DLFdBQVU7QUFBQSxVQUVWLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUE7QUFBQSxRQUwvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFHREgsY0FBYyxTQUNiLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNkdBQ2Y7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsZ0NBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThDO0FBQUE7QUFBQSxpQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPakI7QUFBQUEsZ0JBQ1AsZUFBZSxDQUFDdUYsUUFBUTVELHNCQUFzQjRELEdBQUc7QUFBQSxnQkFFakQ7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLFVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFM0YscUJBQVdzRTtBQUFBQSxvQkFBSSxDQUFDMUQsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFTixJQUM3Qk07QUFBQUEsd0JBQUUyQztBQUFBQSxzQkFBSztBQUFBLHNCQUFhM0MsRUFBRWdGO0FBQUFBLHNCQUFlO0FBQUEseUJBRHZCaEYsRUFBRU4sSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDZHQUNmO0FBQUEscUNBQUMsVUFBTyxXQUFVLGdDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBO0FBQUEsaUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0M7QUFBQUEsZ0JBQ1AsZUFBZSxDQUFDb0YsUUFBUW5GLHFCQUFxQm1GLEdBQUc7QUFBQSxnQkFFaEQ7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLFVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxvQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLE9BQU07QUFBQTtBQUFBLHNCQUFlaEUsa0JBQWtCNEIsUUFBUTtBQUFBLHNCQUFVO0FBQUEseUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRFO0FBQUEsb0JBQzNFMUIsa0JBQWtCeUM7QUFBQUEsc0JBQUksQ0FBQ08sTUFDdEIsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRXZFLElBQzdCdUU7QUFBQUEsMEJBQUV0QjtBQUFBQSx3QkFBSztBQUFBLHdCQUFHc0IsRUFBRWdCO0FBQUFBLHdCQUFhO0FBQUEsMkJBRFhoQixFQUFFdkUsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUEsdUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBO0FBQUE7QUFBQSxjQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWVBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDZHQUNmO0FBQUEscUNBQUMsWUFBUyxXQUFVLGdDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRDtBQUFBO0FBQUEsaUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9TO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQytFLE1BQU05RSxlQUFlOEUsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGtCQUM5QyxVQUFVLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRUMsU0FBU25HLG1CQUFtQjhCLEtBQUssQ0FBQVEsTUFBS0EsRUFBRTlCLE9BQU9tQixvQkFBb0IsR0FBR2tDLFVBQVUsRUFBRTtBQUFBLGtCQUNuSSxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLK087QUFBQSxjQUUvTyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPdUMsT0FBT3JGLFdBQVc7QUFBQSxrQkFDekIsZUFBZSxDQUFDOEUsUUFBUTdFLGVBQWVxRixTQUFTUixHQUFHLEtBQUssQ0FBQztBQUFBLGtCQUN6RCxVQUFVLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRU0sU0FBU25HLG1CQUFtQjhCLEtBQUssQ0FBQVEsTUFBS0EsRUFBRTlCLE9BQU9tQixvQkFBb0IsR0FBR2tDLFVBQVUsRUFBRTtBQUFBLGtCQUVuSTtBQUFBLDJDQUFDLGlCQUFjLFdBQVUsdURBQ3ZCLGlDQUFDLGVBQVksYUFBWSxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsaUJBQ0UsV0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLEVBQUVXO0FBQUFBLHNCQUFJLENBQUM4QixNQUNwQyx1QkFBQyxjQUFtQixPQUFPRixPQUFPRSxDQUFDLEdBQUU7QUFBQTtBQUFBLHdCQUM5QkE7QUFBQUEsMkJBRFVBLEdBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxlQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLGFBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrRkE7QUFBQSxTQUdFLE1BQU07QUFDTixnQkFBTUMsZ0JBQWdCdkcsbUJBQW1COEIsS0FBSyxDQUFBUSxNQUFLQSxFQUFFOUIsT0FBT21CLG9CQUFvQjtBQUNoRixjQUFJNEUsaUJBQWlCLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRUosU0FBU0ksY0FBYzFDLE1BQU0sR0FBRztBQUMxRixtQkFDRSx1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQ2xELHVCQUFDLFVBQUs7QUFBQTtBQUFBLGdCQUEwQjBDLGNBQWMxQyxPQUFPMkMsWUFBWTtBQUFBLGdCQUFFO0FBQUEsbUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsaUJBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxVQUVKO0FBQ0EsY0FBSUQsaUJBQWlCQSxjQUFjMUMsV0FBVyx3QkFBd0I7QUFDcEUsbUJBQ0UsdUJBQUMsU0FBSSxXQUFVLHFHQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHdEQUF1RCx1QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUM5RSx1QkFBQyxVQUFLO0FBQUE7QUFBQSxnQkFBdUIwQyxjQUFjRSxvQkFBb0I7QUFBQSxtQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkY7QUFBQSxpQkFGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBRUo7QUFDQSxpQkFBTztBQUFBLFFBQ1QsR0FBRztBQUFBLFFBR0gsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDRFQUEwRSw4QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU9wRjtBQUFBQSxnQkFDUCxVQUFVLENBQUMyRSxNQUFNMUUsYUFBYTBFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDNUMsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLaU47QUFBQSxlQVRuTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ1osV0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFMUI7QUFBQUEsWUFBSSxDQUFDaUIsUUFDdkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNekUsZUFBZXlFLEdBQUc7QUFBQSxnQkFDakMsV0FBVyx5REFDVDFFLGdCQUFnQjBFLE1BQ1osNENBQ0EseUhBQXlIO0FBQUEsZ0JBQzVIO0FBQUE7QUFBQSxrQkFFRUE7QUFBQUE7QUFBQUE7QUFBQUEsY0FUQUE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxVQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQTNJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNElBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUZBQWtGLDhCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRztBQUFBLFVBQy9HLHVCQUFDLFNBQUksV0FBVSx5REFBeURyRCwyQkFBaUJ6QixVQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRztBQUFBLFVBQ2hHLHVCQUFDLE9BQUUsV0FBVSx1Q0FDVmtCO0FBQUFBLDhCQUFrQjRCLFFBQVE7QUFBQSxZQUFZO0FBQUEsWUFBV3FCO0FBQUFBLGVBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1FQUFrRSx1QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN4Rix1QkFBQyxTQUFJLFdBQVUseURBQXlESiwwQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxPQUFFLFdBQVUsNkNBQ1Z0QywyQkFBaUJ6QixTQUFTLElBQ3ZCLEdBQUcrRixLQUFLQyxNQUFPakMsZUFBZXRDLGlCQUFpQnpCLFNBQVUsR0FBRyxDQUFDLGlCQUM3RCxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlFQUFnRSxzQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxTQUFJLFdBQVUseURBQXlEaUUseUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEYsdUJBQUMsT0FBRSxXQUFVLDJDQUNWeEMsMkJBQWlCekIsU0FBUyxJQUN2QixHQUFHK0YsS0FBS0MsTUFBTy9CLGNBQWN4QyxpQkFBaUJ6QixTQUFVLEdBQUcsQ0FBQyxhQUM1RCxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1FQUFrRSwrQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxVQUNoRyx1QkFBQyxTQUFJLFdBQVUseURBQXlEa0UsaUNBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsVUFDNUYsdUJBQUMsT0FBRSxXQUFVLDZDQUNWekMsMkJBQWlCekIsU0FBUyxJQUN2QixHQUFHK0YsS0FBS0MsTUFBTzlCLHNCQUFzQnpDLGlCQUFpQnpCLFNBQVUsR0FBRyxDQUFDLGlCQUNwRSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwwREFBeUQsMkJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXlELGtCQUFrQixTQUFTO0FBQUEsY0FDMUMsVUFBVSxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUUrQixTQUFTbkcsbUJBQW1COEIsS0FBSyxDQUFBUSxNQUFLQSxFQUFFOUIsT0FBT21CLG9CQUFvQixHQUFHa0MsVUFBVSxFQUFFO0FBQUEsY0FDbkksV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQzlCLHVCQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUI7QUFBQTtBQUFBO0FBQUEsWUFQbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1PLGtCQUFrQixRQUFRO0FBQUEsY0FDekMsVUFBVSxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUUrQixTQUFTbkcsbUJBQW1COEIsS0FBSyxDQUFBUSxNQUFLQSxFQUFFOUIsT0FBT21CLG9CQUFvQixHQUFHa0MsVUFBVSxFQUFFO0FBQUEsY0FDbkksV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxLQUFFLFdBQVUsaUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEI7QUFBQSxnQkFDMUIsdUJBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQjtBQUFBO0FBQUE7QUFBQSxZQVBsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSwwREFBeUQsc0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTVMsYUFBYSxXQUFXO0FBQUEsY0FDdkMsVUFBVSxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUU2QixTQUFTbkcsbUJBQW1COEIsS0FBSyxDQUFBUSxNQUFLQSxFQUFFOUIsT0FBT21CLG9CQUFvQixHQUFHa0MsVUFBVSxFQUFFO0FBQUEsY0FDbkksV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsaUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQzlCLHVCQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0I7QUFBQTtBQUFBO0FBQUEsWUFQdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1TLGFBQWEsZUFBZTtBQUFBLGNBQzNDLFVBQVUsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFNkIsU0FBU25HLG1CQUFtQjhCLEtBQUssQ0FBQVEsTUFBS0EsRUFBRTlCLE9BQU9tQixvQkFBb0IsR0FBR2tDLFVBQVUsRUFBRTtBQUFBLGNBQ25JLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQTtBQUFBLFlBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5SEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrS0FDYjtBQUFBLGlDQUFDLFVBQUk7QUFBQTtBQUFBLFlBQ2N6QixpQkFBaUJ6QjtBQUFBQSxZQUFPO0FBQUEsZUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQyx3Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxhQUpsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVDeUIsaUJBQWlCekIsV0FBVyxJQUMzQix1QkFBQyxTQUFJLFdBQVUsMENBQXdDLG9EQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsaURBQ1p5QiwyQkFBaUJvQyxJQUFJLENBQUNqQixPQUFPO0FBQzVCLGdCQUFNa0IsU0FBUy9CLFdBQVdhLEdBQUcvQyxFQUFFLEtBQUs7QUFBQSxZQUNsQzRDLFdBQVdHLEdBQUcvQztBQUFBQSxZQUNkZ0QsYUFBYUQsR0FBR0U7QUFBQUEsWUFDaEJDLE1BQU1ILEdBQUdHO0FBQUFBLFlBQ1RDLFVBQVVKLEdBQUdJO0FBQUFBLFlBQ2JDLGFBQWFMLEdBQUdLO0FBQUFBLFlBQ2hCQyxRQUFRO0FBQUEsWUFDUkMsWUFBWTtBQUFBLFlBQ1pDLFdBQVcxQztBQUFBQSxZQUNYMkMsU0FBUztBQUFBLFVBQ1g7QUFFQSxnQkFBTTRDLFlBQVluQyxPQUFPWixXQUFXO0FBQ3BDLGdCQUFNZ0QsV0FBV3BDLE9BQU9aLFdBQVc7QUFDbkMsZ0JBQU1pRCxrQkFBa0JyQyxPQUFPWCxlQUFlO0FBRTlDLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFXLHlGQUNUK0MsV0FBVyx3Q0FBd0MsZ0RBQWdEO0FBQUEsY0FJckc7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBRVR0RCxhQUFHd0QsZ0JBQWdCeEQsR0FBR0UsS0FBS3VELE9BQU8sQ0FBQztBQUFBO0FBQUEsb0JBSHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2Q0FBQyxRQUFHLFdBQVUsbURBQW1EekQsYUFBR0UsUUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUU7QUFBQSxzQkFDekUsdUJBQUMsVUFBSyxXQUFVLHVDQUNiRixhQUFHRyxRQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG9DQUFrQztBQUFBO0FBQUEsc0JBQ3hDSCxHQUFHSTtBQUFBQSxzQkFBUztBQUFBLHNCQUFXSixHQUFHSztBQUFBQSxzQkFBWTtBQUFBLHNCQUFtQkwsR0FBRzBELGNBQWM7QUFBQSx5QkFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVUE7QUFBQSxxQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsU0FBUyxNQUFNaEQsdUJBQXVCVixHQUFHL0MsSUFBSSxTQUFTO0FBQUEsd0JBQ3RELFVBQVUsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFMkYsU0FBU25HLG1CQUFtQjhCLEtBQUssQ0FBQVEsTUFBS0EsRUFBRTlCLE9BQU9tQixvQkFBb0IsR0FBR2tDLFVBQVUsRUFBRTtBQUFBLHdCQUNuSSxXQUFXLDJHQUNUK0MsWUFDSSw4Q0FDQSx5SEFBeUg7QUFBQSx3QkFDNUg7QUFBQTtBQUFBLHNCQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTLE1BQU0zQyx1QkFBdUJWLEdBQUcvQyxJQUFJLFFBQVE7QUFBQSx3QkFDckQsVUFBVSxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUUyRixTQUFTbkcsbUJBQW1COEIsS0FBSyxDQUFBUSxNQUFLQSxFQUFFOUIsT0FBT21CLG9CQUFvQixHQUFHa0MsVUFBVSxFQUFFO0FBQUEsd0JBQ25JLFdBQVcsMkdBQ1RnRCxXQUNJLDRDQUNBLHlIQUF5SDtBQUFBLHdCQUM1SDtBQUFBO0FBQUEsc0JBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVdBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFNBQVMsTUFBTTFDLGlCQUFpQlosR0FBRy9DLElBQUksV0FBVztBQUFBLHdCQUNsRCxVQUFVLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRTJGLFNBQVNuRyxtQkFBbUI4QixLQUFLLENBQUFRLE1BQUtBLEVBQUU5QixPQUFPbUIsb0JBQW9CLEdBQUdrQyxVQUFVLEVBQUU7QUFBQSx3QkFDbkksV0FBVywyR0FDVGlELGtCQUNJLDRDQUNBLHlIQUF5SDtBQUFBLHdCQUM1SDtBQUFBO0FBQUEsc0JBUkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVdBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFNBQVMsTUFBTTNDLGlCQUFpQlosR0FBRy9DLElBQUksZUFBZTtBQUFBLHdCQUN0RCxVQUFVLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRTJGLFNBQVNuRyxtQkFBbUI4QixLQUFLLENBQUFRLE1BQUtBLEVBQUU5QixPQUFPbUIsb0JBQW9CLEdBQUdrQyxVQUFVLEVBQUU7QUFBQSx3QkFDbkksV0FBVywyR0FDVCxDQUFDaUQsa0JBQ0csK0RBQ0EseUhBQXlIO0FBQUEsd0JBQzVIO0FBQUE7QUFBQSxzQkFSTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBV0E7QUFBQSx1QkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxxQkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzREE7QUFBQTtBQUFBO0FBQUEsWUFoRkt2RCxHQUFHL0M7QUFBQUEsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0ZBO0FBQUEsUUFFSixDQUFDLEtBdkdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3R0E7QUFBQSxXQXJISjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUhBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsK0NBQThDO0FBQUE7QUFBQSxZQUFLTztBQUFBQSxZQUFZO0FBQUEsZUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUFRO0FBQUEsVUFDdkYyRDtBQUFBQSxVQUFhO0FBQUEsVUFBbUJFO0FBQUFBLFVBQVk7QUFBQSxVQUFrQkM7QUFBQUEsVUFBb0I7QUFBQSxhQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVDLENBQUMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFc0IsU0FBU25HLG1CQUFtQjhCLEtBQUssQ0FBQVEsTUFBS0EsRUFBRTlCLE9BQU9tQixvQkFBb0IsR0FBR2tDLFVBQVUsRUFBRSxLQUN6SCx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNbUIsNEJBQTRCLEtBQUs7QUFBQSxjQUNoRCxXQUFVO0FBQUEsY0FBaU07QUFBQTtBQUFBLFlBSDdNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNQSw0QkFBNEIsSUFBSTtBQUFBLGNBQy9DLE1BQUs7QUFBQSxjQUNMLFNBQVE7QUFBQSxjQUFTO0FBQUE7QUFBQSxZQUhuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLFNBMVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyWEE7QUFBQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHlIQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1EQUFpRCx3REFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUNiaEY7QUFBQUEsK0JBQW1CVztBQUFBQSxZQUFPO0FBQUEsZUFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLG9DQUNmO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHdLQUNmLGlDQUFDLFFBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsZUFBYyw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYyxtQ0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxRQUFHLFdBQVUsZUFBYyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUNoQyx1QkFBQyxRQUFHLFdBQVUsZUFBYywwQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYywwQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYyxzQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNsQyx1QkFBQyxRQUFHLFdBQVUsMEJBQXlCLHVCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLGVBUGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUseURBQ2RYLDZCQUFtQndFO0FBQUFBLFlBQUksQ0FBQzBDLFlBQ3ZCLHVCQUFDLFFBQW9CLFdBQVUsb0VBQzdCO0FBQUEscUNBQUMsUUFBRyxXQUFVLHVEQUNYQTtBQUFBQSx3QkFBUXpCLE9BQU8sT0FBT3lCLFFBQVFyRSxTQUFTO0FBQUEsZ0JBQ3hDLHVCQUFDLFVBQUssV0FBVSwrQ0FDYnFFLGtCQUFRbkUsZUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGdEQUNaO0FBQUEsdUNBQUMsVUFBSyxXQUFVLCtDQUErQ21FLGtCQUFRMUIsaUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsZ0JBQ3JGLHVCQUFDLFVBQUssV0FBVSxtQ0FDYjBCLGtCQUFRdEQsZUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDBEQUEwRHNELGtCQUFRcEUsUUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxRQUFHLFdBQVUsZUFDWjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4QkFBOEJvRSxrQkFBUXhDLGdCQUFnQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUFPO0FBQUEsZ0JBQUc7QUFBQSxnQkFDbEYsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQndDLGtCQUFReEIsY0FBY3dCLFFBQVFqRSxRQUFRdEMsVUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxtQkFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUNYdUc7QUFBQUEsd0JBQVFyQyx1QkFDUHFDLFFBQVFqRSxRQUFRWixPQUFPLENBQUNzQyxNQUFNQSxFQUFFYixlQUFlLFdBQVcsRUFBRW5EO0FBQUFBLGdCQUFRO0FBQUEsZ0JBQUc7QUFBQSxnQkFDdEV1RyxRQUFRakUsUUFBUXRDO0FBQUFBLG1CQUhyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsZUFDWjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUNFdUcsUUFBUXJELFdBQVcsY0FDZixZQUNBcUQsUUFBUXJELFdBQVcseUJBQ25CLFVBQ0E7QUFBQSxrQkFFTixNQUFLO0FBQUEsa0JBRUpxRCxrQkFBUXJEO0FBQUFBO0FBQUFBLGdCQVZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDBCQUNaO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU07QUFDYix3QkFBSXFELFFBQVFoRixZQUFhM0Isd0JBQXVCMkcsUUFBUWhGLFdBQVc7QUFDbkUsd0JBQUlnRixRQUFRekUsVUFBVy9CLHNCQUFxQndHLFFBQVF6RSxTQUFTO0FBQzdELHdCQUFJeUUsUUFBUXJFLFVBQVc3QixnQkFBZWtHLFFBQVFyRSxTQUFTO0FBQ3ZELHdCQUFJcUUsUUFBUXBFLEtBQU01QixnQkFBZWdHLFFBQVFwRSxJQUFJO0FBQzdDLHdCQUFJb0UsUUFBUW5FLFlBQWEzQixpQkFBZ0I4RixRQUFRbkUsV0FBVztBQUM1RCx3QkFBSW1FLFFBQVE3RixVQUFXQyxjQUFhNEYsUUFBUTdGLFNBQVM7QUFFckQsMEJBQU1tRCxNQUF3QyxDQUFDO0FBQy9DMEMsNEJBQVFqRSxRQUFRQyxRQUFRLENBQUN5QixNQUFNO0FBQzdCSCwwQkFBSUcsRUFBRXZCLFNBQVMsSUFBSXVCO0FBQUFBLG9CQUNyQixDQUFDO0FBQ0RoQyxrQ0FBYzZCLEdBQUc7QUFDakI1Qyw0Q0FBd0JzRixRQUFRMUcsRUFBRTtBQUNsQ2dCLGlDQUFhLE1BQU07QUFBQSxrQkFDckI7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVQwRixrQkFBUXJELFdBQVcsV0FBV3FELFFBQVFyRCxXQUFXLHlCQUM5QyxxQkFDQTtBQUFBO0FBQUEsZ0JBdEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlCQTtBQUFBLGlCQTlET3FELFFBQVExRyxJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStEQTtBQUFBLFVBQ0QsS0FsRUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtRUE7QUFBQSxhQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0ZBLEtBakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrRkE7QUFBQSxXQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkZBO0FBQUE7QUFBQSxPQXBoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNoQkE7QUFFSjtBQUFFSCxHQTV5QldOLGdCQUE2QztBQUFBLEtBQTdDQTtBQUE2QyxJQUFBb0g7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlRWZmZWN0IiwiQmFkZ2UiLCJDaGVjayIsIlgiLCJDYWxlbmRhciIsIk1hcFBpbiIsIkNoZWNrQ2lyY2xlMiIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiQWN0aW9uQnV0dG9uIiwiQXR0ZW5kYW5jZVZpZXciLCJhdHRlbmRhbmNlU2Vzc2lvbnMiLCJzdHVkZW50cyIsInBhbmNoYXlhdHMiLCJkcmFmdElkIiwib25TYXZlQXR0ZW5kYW5jZSIsIl9zIiwic2VsZWN0ZWRQYW5jaGF5YXRJZCIsInNldFNlbGVjdGVkUGFuY2hheWF0SWQiLCJpZCIsInNlbGVjdGVkVmlsbGFnZUlkIiwic2V0U2VsZWN0ZWRWaWxsYWdlSWQiLCJsZW5ndGgiLCJleGlzdHMiLCJzb21lIiwicCIsInNlbGVjdGVkRGF5Iiwic2V0U2VsZWN0ZWREYXkiLCJzZXNzaW9uRGF0ZSIsInNldFNlc3Npb25EYXRlIiwic2Vzc2lvblRpdGxlIiwic2V0U2Vzc2lvblRpdGxlIiwidGFza1RvcGljIiwic2V0VGFza1RvcGljIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwic2F2ZVN1Y2Nlc3NNc2ciLCJzZXRTYXZlU3VjY2Vzc01zZyIsImFjdGl2ZURyYWZ0U2Vzc2lvbklkIiwic2V0QWN0aXZlRHJhZnRTZXNzaW9uSWQiLCJjdXJyZW50UGFuY2hheWF0IiwiZmluZCIsImF2YWlsYWJsZVZpbGxhZ2VzIiwidmlsbGFnZXMiLCJoYW5kbGVQYW5jaGF5YXRDaGFuZ2UiLCJwYW5jaGF5YXRJZCIsInBhbmNoIiwiZmlsdGVyZWRTdHVkZW50cyIsImZpbHRlciIsInMiLCJtYXRjaFBhbmNoYXlhdCIsIm1hdGNoVmlsbGFnZSIsInZpbGxhZ2VJZCIsInJlY29yZHNNYXAiLCJzZXRSZWNvcmRzTWFwIiwiZHJhZnQiLCJkYXlOdW1iZXIiLCJkYXRlIiwic2Vzc2lvbk5hbWUiLCJuZXdNYXAiLCJyZWNvcmRzIiwiZm9yRWFjaCIsInJlYyIsInN0dWRlbnRJZCIsInByZXYiLCJ1cGRhdGVkIiwic3QiLCJzdHVkZW50TmFtZSIsIm5hbWUiLCJjb2RlIiwic3RhbmRhcmQiLCJ2aWxsYWdlTmFtZSIsInN0YXR1cyIsInRhc2tTdGF0dXMiLCJ0YXNrVGl0bGUiLCJyZW1hcmtzIiwiaGFuZGxlVG9nZ2xlQXR0ZW5kYW5jZSIsImN1cnJlbnQiLCJoYW5kbGVUb2dnbGVUYXNrIiwibWFya0FsbEF0dGVuZGFuY2UiLCJleGlzdGluZyIsIm1hcmtBbGxUYXNrcyIsImN1cnJlbnRSZWNvcmRzTGlzdCIsIm1hcCIsInJlY29yZCIsInByZXNlbnRDb3VudCIsInIiLCJhYnNlbnRDb3VudCIsInRhc2tzQ29tcGxldGVkQ291bnQiLCJzZWxlY3RlZFZpbGxhZ2VOYW1lIiwidiIsImhhbmRsZVNhdmVBdHRlbmRhbmNlU2Vzc2lvbiIsImlzRmluYWxTdWJtaXQiLCJhbGVydCIsInNlc3Npb25JZFRvU2F2ZSIsIkRhdGUiLCJub3ciLCJuZXdTZXNzaW9uIiwic2Vzc2lvbklkIiwicGFuY2hheWF0TmFtZSIsImRheSIsInRvdGFsQ291bnQiLCJsYXN0U2F2ZWQiLCJzZXRUaW1lb3V0IiwidmFsIiwiYWN0aXZlU3R1ZGVudHMiLCJzdHVkZW50Q291bnQiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJpbmNsdWRlcyIsIlN0cmluZyIsInBhcnNlSW50IiwiZCIsImFjdGl2ZVNlc3Npb24iLCJ0b0xvd2VyQ2FzZSIsImNvcnJlY3Rpb25SZWFzb24iLCJNYXRoIiwicm91bmQiLCJpc1ByZXNlbnQiLCJpc0Fic2VudCIsImlzVGFza0NvbXBsZXRlZCIsImF2YXRhckxldHRlciIsImNoYXJBdCIsInBhcmVudE5hbWUiLCJzZXNzaW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXR0ZW5kYW5jZVZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQXR0ZW5kYW5jZVNlc3Npb24sIFN0dWRlbnQsIFBhbmNoYXlhdCwgVGFiVHlwZSwgQXR0ZW5kYW5jZVJlY29yZCB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnLi91aS9iYWRnZSc7XG5pbXBvcnQgeyBDaGVjaywgWCwgQ2FsZW5kYXIsIE1hcFBpbiwgU3BhcmtsZXMsIENoZWNrQ2lyY2xlMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdENvbnRlbnQsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdFRyaWdnZXIsXG4gIFNlbGVjdFZhbHVlLFxufSBmcm9tICcuL3VpL3NlbGVjdCc7XG5pbXBvcnQgeyBBY3Rpb25CdXR0b24gfSBmcm9tICcuL3VpL2FjdGlvbi1idXR0b24nO1xuXG5pbnRlcmZhY2UgQXR0ZW5kYW5jZVZpZXdQcm9wcyB7XG4gIGF0dGVuZGFuY2VTZXNzaW9uczogQXR0ZW5kYW5jZVNlc3Npb25bXTtcbiAgc3R1ZGVudHM6IFN0dWRlbnRbXTtcbiAgcGFuY2hheWF0czogUGFuY2hheWF0W107XG4gIGRyYWZ0SWQ/OiBzdHJpbmc7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUpID0+IHZvaWQ7XG4gIG9uU2F2ZUF0dGVuZGFuY2U6IChzZXNzaW9uOiBBdHRlbmRhbmNlU2Vzc2lvbikgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEF0dGVuZGFuY2VWaWV3OiBSZWFjdC5GQzxBdHRlbmRhbmNlVmlld1Byb3BzPiA9ICh7XG4gIGF0dGVuZGFuY2VTZXNzaW9ucyxcbiAgc3R1ZGVudHMsXG4gIHBhbmNoYXlhdHMsXG4gIGRyYWZ0SWQsXG4gIG9uU2F2ZUF0dGVuZGFuY2UsXG59KSA9PiB7XG4gIC8vIFN0ZXAgMSAmIDIgc2VsZWN0aW9uc1xuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXRJZCwgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgIHBhbmNoYXlhdHNbMF0/LmlkIHx8ICcnXG4gICk7XG4gIGNvbnN0IFtzZWxlY3RlZFZpbGxhZ2VJZCwgc2V0U2VsZWN0ZWRWaWxsYWdlSWRdID0gdXNlU3RhdGU8c3RyaW5nPignYWxsJyk7XG5cbiAgLy8gU3luY2hyb25pemUgc2VsZWN0ZWRQYW5jaGF5YXRJZCBpZiBwYW5jaGF5YXRzIGFycmF5IGxvYWRzIG9yIHVwZGF0ZXNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocGFuY2hheWF0cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBleGlzdHMgPSBwYW5jaGF5YXRzLnNvbWUoKHApID0+IHAuaWQgPT09IHNlbGVjdGVkUGFuY2hheWF0SWQpO1xuICAgICAgaWYgKCFleGlzdHMpIHtcbiAgICAgICAgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZChwYW5jaGF5YXRzWzBdLmlkKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtwYW5jaGF5YXRzLCBzZWxlY3RlZFBhbmNoYXlhdElkXSk7XG4gIGNvbnN0IFtzZWxlY3RlZERheSwgc2V0U2VsZWN0ZWREYXldID0gdXNlU3RhdGU8bnVtYmVyPigxKTtcbiAgY29uc3QgW3Nlc3Npb25EYXRlLCBzZXRTZXNzaW9uRGF0ZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcyMDIzLTEwLTI0Jyk7XG4gIGNvbnN0IFtzZXNzaW9uVGl0bGUsIHNldFNlc3Npb25UaXRsZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdEYXkgMSBTcG9rZW4gRW5nbGlzaCAmIExpZmUgU2tpbGxzJyk7XG4gIGNvbnN0IFt0YXNrVG9waWMsIHNldFRhc2tUb3BpY10gPSB1c2VTdGF0ZTxzdHJpbmc+KCdXb3Jrc2hlZXQgJiBDb252ZXJzYXRpb25hbCBEcmlsbCcpO1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J21hcmsnIHwgJ2hpc3RvcnknPignbWFyaycpO1xuICBjb25zdCBbc2F2ZVN1Y2Nlc3NNc2csIHNldFNhdmVTdWNjZXNzTXNnXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2FjdGl2ZURyYWZ0U2Vzc2lvbklkLCBzZXRBY3RpdmVEcmFmdFNlc3Npb25JZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihkcmFmdElkIHx8IG51bGwpO1xuXG4gIC8vIEdldCBjdXJyZW50IHBhbmNoYXlhdCAmIGl0cyB2aWxsYWdlc1xuICBjb25zdCBjdXJyZW50UGFuY2hheWF0ID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXRJZCkgfHwgcGFuY2hheWF0c1swXTtcbiAgfSwgW3BhbmNoYXlhdHMsIHNlbGVjdGVkUGFuY2hheWF0SWRdKTtcblxuICBjb25zdCBhdmFpbGFibGVWaWxsYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBjdXJyZW50UGFuY2hheWF0Py52aWxsYWdlcyB8fCBbXTtcbiAgfSwgW2N1cnJlbnRQYW5jaGF5YXRdKTtcblxuICAvLyBXaGVuIHBhbmNoYXlhdCBjaGFuZ2VzLCBhdXRvLWFkanVzdCB2aWxsYWdlXG4gIGNvbnN0IGhhbmRsZVBhbmNoYXlhdENoYW5nZSA9IChwYW5jaGF5YXRJZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZChwYW5jaGF5YXRJZCk7XG4gICAgY29uc3QgcGFuY2ggPSBwYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IHBhbmNoYXlhdElkKTtcbiAgICBpZiAocGFuY2ggJiYgcGFuY2gudmlsbGFnZXMgJiYgcGFuY2gudmlsbGFnZXMubGVuZ3RoID4gMCkge1xuICAgICAgc2V0U2VsZWN0ZWRWaWxsYWdlSWQocGFuY2gudmlsbGFnZXNbMF0uaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTZWxlY3RlZFZpbGxhZ2VJZCgnYWxsJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEZpbHRlciBzdHVkZW50cyBiYXNlZCBvbiBTdGVwIDEgKFBhbmNoYXlhdCkgYW5kIFN0ZXAgMiAoVmlsbGFnZSlcbiAgY29uc3QgZmlsdGVyZWRTdHVkZW50cyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBzdHVkZW50cy5maWx0ZXIoKHMpID0+IHtcbiAgICAgIGNvbnN0IG1hdGNoUGFuY2hheWF0ID0gcy5wYW5jaGF5YXRJZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXRJZDtcbiAgICAgIGNvbnN0IG1hdGNoVmlsbGFnZSA9IHNlbGVjdGVkVmlsbGFnZUlkID09PSAnYWxsJyB8fCBzLnZpbGxhZ2VJZCA9PT0gc2VsZWN0ZWRWaWxsYWdlSWQ7XG4gICAgICByZXR1cm4gbWF0Y2hQYW5jaGF5YXQgJiYgbWF0Y2hWaWxsYWdlO1xuICAgIH0pO1xuICB9LCBbc3R1ZGVudHMsIHNlbGVjdGVkUGFuY2hheWF0SWQsIHNlbGVjdGVkVmlsbGFnZUlkXSk7XG5cbiAgLy8gU3R1ZGVudCBBdHRlbmRhbmNlICYgVGFzayByZWNvcmRzIG1hcCBzdGF0ZVxuICBjb25zdCBbcmVjb3Jkc01hcCwgc2V0UmVjb3Jkc01hcF0gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBBdHRlbmRhbmNlUmVjb3JkPj4oe30pO1xuXG4gIC8vIEluaXRpYWxpemUgcmVjb3JkcyB3aGVuIHN0dWRlbnRzIGxpc3Qgb3IgZHJhZnQgY2hhbmdlc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkcmFmdElkKSB7XG4gICAgICBjb25zdCBkcmFmdCA9IGF0dGVuZGFuY2VTZXNzaW9ucy5maW5kKChzKSA9PiBzLmlkID09PSBkcmFmdElkKTtcbiAgICAgIGlmIChkcmFmdCkge1xuICAgICAgICBpZiAoZHJhZnQucGFuY2hheWF0SWQpIHNldFNlbGVjdGVkUGFuY2hheWF0SWQoZHJhZnQucGFuY2hheWF0SWQpO1xuICAgICAgICBpZiAoZHJhZnQudmlsbGFnZUlkKSBzZXRTZWxlY3RlZFZpbGxhZ2VJZChkcmFmdC52aWxsYWdlSWQpO1xuICAgICAgICBpZiAoZHJhZnQuZGF5TnVtYmVyKSBzZXRTZWxlY3RlZERheShkcmFmdC5kYXlOdW1iZXIpO1xuICAgICAgICBpZiAoZHJhZnQuZGF0ZSkgc2V0U2Vzc2lvbkRhdGUoZHJhZnQuZGF0ZSk7XG4gICAgICAgIGlmIChkcmFmdC5zZXNzaW9uTmFtZSkgc2V0U2Vzc2lvblRpdGxlKGRyYWZ0LnNlc3Npb25OYW1lKTtcbiAgICAgICAgaWYgKGRyYWZ0LnRhc2tUb3BpYykgc2V0VGFza1RvcGljKGRyYWZ0LnRhc2tUb3BpYyk7XG5cbiAgICAgICAgY29uc3QgbmV3TWFwOiBSZWNvcmQ8c3RyaW5nLCBBdHRlbmRhbmNlUmVjb3JkPiA9IHt9O1xuICAgICAgICBkcmFmdC5yZWNvcmRzLmZvckVhY2goKHJlYykgPT4ge1xuICAgICAgICAgIG5ld01hcFtyZWMuc3R1ZGVudElkXSA9IHJlYztcbiAgICAgICAgfSk7XG4gICAgICAgIHNldFJlY29yZHNNYXAobmV3TWFwKTtcbiAgICAgICAgc2V0QWN0aXZlRHJhZnRTZXNzaW9uSWQoZHJhZnQuaWQpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRGVmYXVsdCBpbml0aWFsaXphdGlvbiBmb3IgY3VycmVudCBmaWx0ZXJlZCBzdHVkZW50c1xuICAgIHNldFJlY29yZHNNYXAoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWQ6IFJlY29yZDxzdHJpbmcsIEF0dGVuZGFuY2VSZWNvcmQ+ID0geyAuLi5wcmV2IH07XG4gICAgICBmaWx0ZXJlZFN0dWRlbnRzLmZvckVhY2goKHN0KSA9PiB7XG4gICAgICAgIGlmICghdXBkYXRlZFtzdC5pZF0pIHtcbiAgICAgICAgICB1cGRhdGVkW3N0LmlkXSA9IHtcbiAgICAgICAgICAgIHN0dWRlbnRJZDogc3QuaWQsXG4gICAgICAgICAgICBzdHVkZW50TmFtZTogc3QubmFtZSxcbiAgICAgICAgICAgIGNvZGU6IHN0LmNvZGUsXG4gICAgICAgICAgICBzdGFuZGFyZDogc3Quc3RhbmRhcmQsXG4gICAgICAgICAgICB2aWxsYWdlTmFtZTogc3QudmlsbGFnZU5hbWUsXG4gICAgICAgICAgICBzdGF0dXM6ICdQcmVzZW50JyxcbiAgICAgICAgICAgIHRhc2tTdGF0dXM6ICdDb21wbGV0ZWQnLFxuICAgICAgICAgICAgdGFza1RpdGxlOiB0YXNrVG9waWMsXG4gICAgICAgICAgICByZW1hcmtzOiAnJyxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICB9LCBbc2VsZWN0ZWRQYW5jaGF5YXRJZCwgc2VsZWN0ZWRWaWxsYWdlSWQsIGRyYWZ0SWQsIGZpbHRlcmVkU3R1ZGVudHMsIHRhc2tUb3BpYywgYXR0ZW5kYW5jZVNlc3Npb25zXSk7XG5cbiAgLy8gVG9nZ2xlIHNpbmdsZSBzdHVkZW50IGF0dGVuZGFuY2Ugc3RhdHVzIChQcmVzZW50IC8gQWJzZW50IC8gTGF0ZSlcbiAgY29uc3QgaGFuZGxlVG9nZ2xlQXR0ZW5kYW5jZSA9IChzdHVkZW50SWQ6IHN0cmluZywgc3RhdHVzOiAnUHJlc2VudCcgfCAnQWJzZW50JyB8ICdMYXRlJykgPT4ge1xuICAgIHNldFJlY29yZHNNYXAoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBwcmV2W3N0dWRlbnRJZF0gfHwge1xuICAgICAgICBzdHVkZW50SWQsXG4gICAgICAgIHN0dWRlbnROYW1lOiBzdHVkZW50cy5maW5kKChzKSA9PiBzLmlkID09PSBzdHVkZW50SWQpPy5uYW1lIHx8ICdTdHVkZW50JyxcbiAgICAgICAgY29kZTogc3R1ZGVudHMuZmluZCgocykgPT4gcy5pZCA9PT0gc3R1ZGVudElkKT8uY29kZSB8fCAnJyxcbiAgICAgICAgc3RhbmRhcmQ6IHN0dWRlbnRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHN0dWRlbnRJZCk/LnN0YW5kYXJkIHx8ICcnLFxuICAgICAgICB2aWxsYWdlTmFtZTogc3R1ZGVudHMuZmluZCgocykgPT4gcy5pZCA9PT0gc3R1ZGVudElkKT8udmlsbGFnZU5hbWUgfHwgJycsXG4gICAgICAgIHN0YXR1czogJ1ByZXNlbnQnLFxuICAgICAgICB0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyxcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIFtzdHVkZW50SWRdOiB7XG4gICAgICAgICAgLi4uY3VycmVudCxcbiAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgdGFza1N0YXR1czogc3RhdHVzID09PSAnQWJzZW50JyA/ICdOb3QgQ29tcGxldGVkJyA6IGN1cnJlbnQudGFza1N0YXR1cyB8fCAnQ29tcGxldGVkJyxcbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgfSk7XG4gIH07XG5cbiAgLy8gVG9nZ2xlIHNpbmdsZSBzdHVkZW50IHRhc2sgc3RhdHVzIChDb21wbGV0ZWQgLyBOb3QgQ29tcGxldGVkKVxuICBjb25zdCBoYW5kbGVUb2dnbGVUYXNrID0gKHN0dWRlbnRJZDogc3RyaW5nLCB0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyB8ICdOb3QgQ29tcGxldGVkJykgPT4ge1xuICAgIHNldFJlY29yZHNNYXAoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBwcmV2W3N0dWRlbnRJZF0gfHwge1xuICAgICAgICBzdHVkZW50SWQsXG4gICAgICAgIHN0dWRlbnROYW1lOiBzdHVkZW50cy5maW5kKChzKSA9PiBzLmlkID09PSBzdHVkZW50SWQpPy5uYW1lIHx8ICdTdHVkZW50JyxcbiAgICAgICAgY29kZTogc3R1ZGVudHMuZmluZCgocykgPT4gcy5pZCA9PT0gc3R1ZGVudElkKT8uY29kZSB8fCAnJyxcbiAgICAgICAgc3RhbmRhcmQ6IHN0dWRlbnRzLmZpbmQoKHMpID0+IHMuaWQgPT09IHN0dWRlbnRJZCk/LnN0YW5kYXJkIHx8ICcnLFxuICAgICAgICB2aWxsYWdlTmFtZTogc3R1ZGVudHMuZmluZCgocykgPT4gcy5pZCA9PT0gc3R1ZGVudElkKT8udmlsbGFnZU5hbWUgfHwgJycsXG4gICAgICAgIHN0YXR1czogJ1ByZXNlbnQnLFxuICAgICAgICB0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyxcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIFtzdHVkZW50SWRdOiB7XG4gICAgICAgICAgLi4uY3VycmVudCxcbiAgICAgICAgICB0YXNrU3RhdHVzLFxuICAgICAgICB9LFxuICAgICAgfTtcbiAgICB9KTtcbiAgfTtcblxuICAvLyBCYXRjaCBhY3Rpb25zXG4gIGNvbnN0IG1hcmtBbGxBdHRlbmRhbmNlID0gKHN0YXR1czogJ1ByZXNlbnQnIHwgJ0Fic2VudCcpID0+IHtcbiAgICBzZXRSZWNvcmRzTWFwKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCB1cGRhdGVkID0geyAuLi5wcmV2IH07XG4gICAgICBmaWx0ZXJlZFN0dWRlbnRzLmZvckVhY2goKHN0KSA9PiB7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nID0gdXBkYXRlZFtzdC5pZF0gfHwge1xuICAgICAgICAgIHN0dWRlbnRJZDogc3QuaWQsXG4gICAgICAgICAgc3R1ZGVudE5hbWU6IHN0Lm5hbWUsXG4gICAgICAgICAgY29kZTogc3QuY29kZSxcbiAgICAgICAgICBzdGFuZGFyZDogc3Quc3RhbmRhcmQsXG4gICAgICAgICAgdmlsbGFnZU5hbWU6IHN0LnZpbGxhZ2VOYW1lLFxuICAgICAgICAgIHN0YXR1czogJ1ByZXNlbnQnLFxuICAgICAgICAgIHRhc2tTdGF0dXM6ICdDb21wbGV0ZWQnLFxuICAgICAgICB9O1xuICAgICAgICB1cGRhdGVkW3N0LmlkXSA9IHtcbiAgICAgICAgICAuLi5leGlzdGluZyxcbiAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgdGFza1N0YXR1czogc3RhdHVzID09PSAnQWJzZW50JyA/ICdOb3QgQ29tcGxldGVkJyA6IGV4aXN0aW5nLnRhc2tTdGF0dXMgfHwgJ0NvbXBsZXRlZCcsXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IG1hcmtBbGxUYXNrcyA9ICh0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyB8ICdOb3QgQ29tcGxldGVkJykgPT4ge1xuICAgIHNldFJlY29yZHNNYXAoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLnByZXYgfTtcbiAgICAgIGZpbHRlcmVkU3R1ZGVudHMuZm9yRWFjaCgoc3QpID0+IHtcbiAgICAgICAgY29uc3QgZXhpc3RpbmcgPSB1cGRhdGVkW3N0LmlkXSB8fCB7XG4gICAgICAgICAgc3R1ZGVudElkOiBzdC5pZCxcbiAgICAgICAgICBzdHVkZW50TmFtZTogc3QubmFtZSxcbiAgICAgICAgICBjb2RlOiBzdC5jb2RlLFxuICAgICAgICAgIHN0YW5kYXJkOiBzdC5zdGFuZGFyZCxcbiAgICAgICAgICB2aWxsYWdlTmFtZTogc3QudmlsbGFnZU5hbWUsXG4gICAgICAgICAgc3RhdHVzOiAnUHJlc2VudCcsXG4gICAgICAgICAgdGFza1N0YXR1czogJ0NvbXBsZXRlZCcsXG4gICAgICAgIH07XG4gICAgICAgIHVwZGF0ZWRbc3QuaWRdID0ge1xuICAgICAgICAgIC4uLmV4aXN0aW5nLFxuICAgICAgICAgIHRhc2tTdGF0dXMsXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICB9O1xuXG4gIC8vIE1ldHJpYyBjb21wdXRhdGlvbnNcbiAgY29uc3QgY3VycmVudFJlY29yZHNMaXN0OiBBdHRlbmRhbmNlUmVjb3JkW10gPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZmlsdGVyZWRTdHVkZW50cy5tYXAoKHN0KSA9PiB7XG4gICAgICBjb25zdCByZWNvcmQgPSByZWNvcmRzTWFwW3N0LmlkXTtcbiAgICAgIGlmIChyZWNvcmQpIHJldHVybiByZWNvcmQ7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdHVkZW50SWQ6IHN0LmlkLFxuICAgICAgICBzdHVkZW50TmFtZTogc3QubmFtZSxcbiAgICAgICAgY29kZTogc3QuY29kZSxcbiAgICAgICAgc3RhbmRhcmQ6IHN0LnN0YW5kYXJkLFxuICAgICAgICB2aWxsYWdlTmFtZTogc3QudmlsbGFnZU5hbWUsXG4gICAgICAgIHN0YXR1czogJ1ByZXNlbnQnIGFzIGNvbnN0LFxuICAgICAgICB0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyBhcyBjb25zdCxcbiAgICAgICAgdGFza1RpdGxlOiB0YXNrVG9waWMsXG4gICAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgfTtcbiAgICB9KTtcbiAgfSwgW2ZpbHRlcmVkU3R1ZGVudHMsIHJlY29yZHNNYXAsIHRhc2tUb3BpY10pO1xuXG4gIGNvbnN0IHByZXNlbnRDb3VudCA9IHVzZU1lbW8oXG4gICAgKCkgPT4gY3VycmVudFJlY29yZHNMaXN0LmZpbHRlcigocikgPT4gci5zdGF0dXMgPT09ICdQcmVzZW50JyB8fCByLnN0YXR1cyA9PT0gJ0xhdGUnKS5sZW5ndGgsXG4gICAgW2N1cnJlbnRSZWNvcmRzTGlzdF1cbiAgKTtcbiAgY29uc3QgYWJzZW50Q291bnQgPSB1c2VNZW1vKFxuICAgICgpID0+IGN1cnJlbnRSZWNvcmRzTGlzdC5maWx0ZXIoKHIpID0+IHIuc3RhdHVzID09PSAnQWJzZW50JykubGVuZ3RoLFxuICAgIFtjdXJyZW50UmVjb3Jkc0xpc3RdXG4gICk7XG4gIGNvbnN0IHRhc2tzQ29tcGxldGVkQ291bnQgPSB1c2VNZW1vKFxuICAgICgpID0+IGN1cnJlbnRSZWNvcmRzTGlzdC5maWx0ZXIoKHIpID0+IHIudGFza1N0YXR1cyA9PT0gJ0NvbXBsZXRlZCcpLmxlbmd0aCxcbiAgICBbY3VycmVudFJlY29yZHNMaXN0XVxuICApO1xuXG4gIGNvbnN0IHNlbGVjdGVkVmlsbGFnZU5hbWUgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoc2VsZWN0ZWRWaWxsYWdlSWQgPT09ICdhbGwnKSByZXR1cm4gJ0FsbCBWaWxsYWdlcyc7XG4gICAgcmV0dXJuIGF2YWlsYWJsZVZpbGxhZ2VzLmZpbmQoKHYpID0+IHYuaWQgPT09IHNlbGVjdGVkVmlsbGFnZUlkKT8ubmFtZSB8fCAnVmlsbGFnZSc7XG4gIH0sIFtzZWxlY3RlZFZpbGxhZ2VJZCwgYXZhaWxhYmxlVmlsbGFnZXNdKTtcblxuICAvLyBTYXZlIC8gU3VibWl0IGhhbmRsZXJcbiAgY29uc3QgaGFuZGxlU2F2ZUF0dGVuZGFuY2VTZXNzaW9uID0gKGlzRmluYWxTdWJtaXQ6IGJvb2xlYW4pID0+IHtcbiAgICBpZiAoZmlsdGVyZWRTdHVkZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGFsZXJ0KCdObyBzdHVkZW50cyBmb3VuZCBmb3IgdGhpcyBQYW5jaGF5YXQgYW5kIFZpbGxhZ2UuIFBsZWFzZSBhZGQgc3R1ZGVudHMgZmlyc3QuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgc2Vzc2lvbklkVG9TYXZlID0gYWN0aXZlRHJhZnRTZXNzaW9uSWQgfHwgYGF0dC0ke0RhdGUubm93KCl9YDtcbiAgICBjb25zdCBuZXdTZXNzaW9uOiBBdHRlbmRhbmNlU2Vzc2lvbiA9IHtcbiAgICAgIGlkOiBzZXNzaW9uSWRUb1NhdmUsXG4gICAgICBzZXNzaW9uSWQ6IGBzZXMtZGF5JHtzZWxlY3RlZERheX1gLFxuICAgICAgc2Vzc2lvbk5hbWU6IHNlc3Npb25UaXRsZSB8fCBgRGF5ICR7c2VsZWN0ZWREYXl9IFNlc3Npb25gLFxuICAgICAgcGFuY2hheWF0SWQ6IHNlbGVjdGVkUGFuY2hheWF0SWQsXG4gICAgICBwYW5jaGF5YXROYW1lOiBjdXJyZW50UGFuY2hheWF0Py5uYW1lIHx8ICdQYW5jaGF5YXQnLFxuICAgICAgdmlsbGFnZUlkOiBzZWxlY3RlZFZpbGxhZ2VJZCxcbiAgICAgIHZpbGxhZ2VOYW1lOiBzZWxlY3RlZFZpbGxhZ2VOYW1lLFxuICAgICAgZGF0ZTogc2Vzc2lvbkRhdGUsXG4gICAgICBkYXk6IGBEYXkgJHtzZWxlY3RlZERheX1gLFxuICAgICAgZGF5TnVtYmVyOiBzZWxlY3RlZERheSxcbiAgICAgIHRhc2tUb3BpYyxcbiAgICAgIHRvdGFsQ291bnQ6IGZpbHRlcmVkU3R1ZGVudHMubGVuZ3RoLFxuICAgICAgcHJlc2VudENvdW50LFxuICAgICAgYWJzZW50Q291bnQsXG4gICAgICB0YXNrc0NvbXBsZXRlZENvdW50LFxuICAgICAgc3RhdHVzOiBpc0ZpbmFsU3VibWl0ID8gJ1N1Ym1pdHRlZCcgOiAnRHJhZnQnLFxuICAgICAgbGFzdFNhdmVkOiBpc0ZpbmFsU3VibWl0ID8gJ1N1Ym1pdHRlZCBqdXN0IG5vdycgOiAnU2F2ZWQganVzdCBub3cnLFxuICAgICAgcmVjb3JkczogY3VycmVudFJlY29yZHNMaXN0LFxuICAgIH07XG5cbiAgICBvblNhdmVBdHRlbmRhbmNlKG5ld1Nlc3Npb24pO1xuICAgIHNldEFjdGl2ZURyYWZ0U2Vzc2lvbklkKHNlc3Npb25JZFRvU2F2ZSk7XG4gICAgc2V0U2F2ZVN1Y2Nlc3NNc2coXG4gICAgICBpc0ZpbmFsU3VibWl0XG4gICAgICAgID8gYERheSAke3NlbGVjdGVkRGF5fSBBdHRlbmRhbmNlICYgVGFzayByZWNvcmRzIHN1Ym1pdHRlZCBzdWNjZXNzZnVsbHkgZm9yICR7Y3VycmVudFBhbmNoYXlhdD8ubmFtZSB8fCAnUGFuY2hheWF0J30gKCR7c2VsZWN0ZWRWaWxsYWdlTmFtZX0pIWBcbiAgICAgICAgOiBgRGF5ICR7c2VsZWN0ZWREYXl9IEF0dGVuZGFuY2UgRHJhZnQgc2F2ZWQgc3VjY2Vzc2Z1bGx5IWBcbiAgICApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U2F2ZVN1Y2Nlc3NNc2coJycpLCA0NTAwKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktNlwiPlxuICAgICAgey8qIDEuIENhcmRsZXNzIFBhZ2UgSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBBdHRlbmRhbmNlICZhbXA7IFRhc2sgRW50cnlcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIERheSB7c2VsZWN0ZWREYXl9XG4gICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgU3RlcCAxOiBTZWxlY3QgUGFuY2hheWF0ICZyYXJyOyBTdGVwIDI6IFNlbGVjdCBWaWxsYWdlICZyYXJyOyBTdGVwIDM6IE1hcmsgUHJlc2VudC9BYnNlbnQgJmFtcDsgVGFza3MuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNlbGYtc3RhcnQgc206c2VsZi1hdXRvXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ21hcmsnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gc2hhZG93LXRoZW1lLXhzICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ21hcmsnXG4gICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3ZlcjpiZy13aGl0ZS81J1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgTWFyayBBdHRlbmRhbmNlICZhbXA7IFRhc2tzXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2hpc3RvcnknKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQteGwgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gc2hhZG93LXRoZW1lLXhzICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2hpc3RvcnknXG4gICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3ZlcjpiZy13aGl0ZS81J1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgSGlzdG9yeSAoe2F0dGVuZGFuY2VTZXNzaW9ucy5sZW5ndGh9KVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7c2F2ZVN1Y2Nlc3NNc2cgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zdWNjZXNzLTIwMCBiZy1zdWNjZXNzLTUwIHAtNCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc3VjY2Vzcy02MDAgZGFyazpib3JkZXItc3VjY2Vzcy05MDAvNDAgZGFyazpiZy1zdWNjZXNzLTUwMC8xMCBkYXJrOnRleHQtc3VjY2Vzcy00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHNwYW4+e3NhdmVTdWNjZXNzTXNnfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNhdmVTdWNjZXNzTXNnKCcnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc3VjY2Vzcy02MDAgaG92ZXI6dGV4dC1zdWNjZXNzLTgwMCBkYXJrOnRleHQtc3VjY2Vzcy00MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5jbG9zZTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7YWN0aXZlVGFiID09PSAnbWFyaycgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgey8qIFNURVAgU0VMRUNUT1JTIEJBUiAtIENhcmRsZXNzIEZsYXQgU3R5bGluZyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBwYi0yIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgICAgICAgIHsvKiBTVEVQIDE6IFBBTkNIQVlBVCBTRUxFQ1RJT04gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYnJhbmQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDEuIFBhbmNoYXlhdFxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGFuY2hheWF0SWR9XG4gICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVQYW5jaGF5YXRDaGFuZ2UodmFsKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBhbmNoYXlhdFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAge3BhbmNoYXlhdHMubWFwKChwKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cC5uYW1lfSBQYW5jaGF5YXQgKHtwLmFjdGl2ZVN0dWRlbnRzfSBzdHVkZW50cylcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU1RFUCAyOiBWSUxMQUdFIFNFTEVDVElPTiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1icmFuZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgMi4gVmlsbGFnZSAvIENlbnRlclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVmlsbGFnZUlkfVxuICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRWaWxsYWdlSWQodmFsKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFZpbGxhZ2VcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFZpbGxhZ2VzICh7Y3VycmVudFBhbmNoYXlhdD8ubmFtZSB8fCAnQ2x1c3Rlcid9KTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVZpbGxhZ2VzLm1hcCgodikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17di5pZH0gdmFsdWU9e3YuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3YubmFtZX0gKHt2LnN0dWRlbnRDb3VudH0gc3R1ZGVudHMpXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNURVAgMzogU0VTU0lPTiBEQVRFICYgREFZICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYnJhbmQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDMuIERhdGUgJmFtcDsgRGF5XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZXNzaW9uRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZXNzaW9uRGF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhdHRlbmRhbmNlU2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IGFjdGl2ZURyYWZ0U2Vzc2lvbklkKT8uc3RhdHVzIHx8ICcnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zIHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjhcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtTdHJpbmcoc2VsZWN0ZWREYXkpfVxuICAgICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkRGF5KHBhcnNlSW50KHZhbCkgfHwgMSl9XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1snU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGF0dGVuZGFuY2VTZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gYWN0aXZlRHJhZnRTZXNzaW9uSWQpPy5zdGF0dXMgfHwgJycpfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtYnJhbmQtNTAwIGZvbnQtYm9sZCBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJEYXlcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNSwgNiwgNywgOCwgOSwgMTBdLm1hcCgoZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e2R9IHZhbHVlPXtTdHJpbmcoZCl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERheSB7ZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRWRpdCBMb2NrIE1lc3NhZ2VzICovfVxuICAgICAgICAgICAgeygoKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVNlc3Npb24gPSBhdHRlbmRhbmNlU2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IGFjdGl2ZURyYWZ0U2Vzc2lvbklkKTtcbiAgICAgICAgICAgICAgaWYgKGFjdGl2ZVNlc3Npb24gJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlU2Vzc2lvbi5zdGF0dXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgcC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zdWNjZXNzLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlRoaXMgYXR0ZW5kYW5jZSBoYXMgYmVlbiB7YWN0aXZlU2Vzc2lvbi5zdGF0dXMudG9Mb3dlckNhc2UoKX0gYW5kIGNhbm5vdCBiZSBlZGl0ZWQuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAoYWN0aXZlU2Vzc2lvbiAmJiBhY3RpdmVTZXNzaW9uLnN0YXR1cyA9PT0gJ0NvcnJlY3Rpb24gUmVxdWVzdGVkJykge1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQteGwgcC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1hbWJlci04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMHB4XSB0ZXh0LWFtYmVyLTYwMFwiPndhcm5pbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvcnJlY3Rpb24gUmVxdWVzdGVkOiB7YWN0aXZlU2Vzc2lvbi5jb3JyZWN0aW9uUmVhc29uIHx8ICdQbGVhc2UgcmV2aWV3IGFuZCByZXN1Ym1pdC4nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICB9KSgpfVxuXG4gICAgICAgICAgICB7LyogVGFzayAvIEFjdGl2aXR5IFRvcGljIHNldHVwICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgVG9kYXkmYXBvcztzIFRvcGljOlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiwgUGhvbmljcyBXb3Jrc2hlZXQgJiBTcGVha2luZyBQcmFjdGljZVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGFza1RvcGljfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUYXNrVG9waWMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zIHB5LTEuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRGF5IFF1aWNrIFNlbGVjdG9ycyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICB7WzEsIDIsIDMsIDQsIDUsIDZdLm1hcCgoZGF5KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17ZGF5fVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWREYXkoZGF5KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24gJHtcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZERheSA9PT0gZGF5XG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1icmFuZC01MDAgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIERheSB7ZGF5fVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogMi4gQ29tcGFjdCBNZXRyaWMgQ2FyZHMgKGNvdW50cyAmIHN0YXR1cyBvbmx5KSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlRvdGFsIEVucm9sbGVkPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57ZmlsdGVyZWRTdHVkZW50cy5sZW5ndGh9PC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNDAwIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAge2N1cnJlbnRQYW5jaGF5YXQ/Lm5hbWUgfHwgJ1BhbmNoYXlhdCd9ICZtaWRkb3Q7IHtzZWxlY3RlZFZpbGxhZ2VOYW1lfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc3VjY2Vzcy01MDBcIj5QcmVzZW50PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57cHJlc2VudENvdW50fTwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zdWNjZXNzLTUwMFwiPlxuICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFN0dWRlbnRzLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgICAgID8gYCR7TWF0aC5yb3VuZCgocHJlc2VudENvdW50IC8gZmlsdGVyZWRTdHVkZW50cy5sZW5ndGgpICogMTAwKX0lIEF0dGVuZGFuY2VgXG4gICAgICAgICAgICAgICAgICA6ICcwJSd9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1lcnJvci01MDBcIj5BYnNlbnQ8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPnthYnNlbnRDb3VudH08L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZXJyb3ItNTAwXCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkU3R1ZGVudHMubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgPyBgJHtNYXRoLnJvdW5kKChhYnNlbnRDb3VudCAvIGZpbHRlcmVkU3R1ZGVudHMubGVuZ3RoKSAqIDEwMCl9JSBBYnNlbnRgXG4gICAgICAgICAgICAgICAgICA6ICcwJSd9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC13YXJuaW5nLTUwMFwiPlRhc2tzIENvbXBsZXRlZDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3Rhc2tzQ29tcGxldGVkQ291bnR9PC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdhcm5pbmctNTAwXCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkU3R1ZGVudHMubGVuZ3RoID4gMFxuICAgICAgICAgICAgICAgICAgPyBgJHtNYXRoLnJvdW5kKCh0YXNrc0NvbXBsZXRlZENvdW50IC8gZmlsdGVyZWRTdHVkZW50cy5sZW5ndGgpICogMTAwKX0lIFRhc2tzIERvbmVgXG4gICAgICAgICAgICAgICAgICA6ICcwJSd9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIDMuIENhcmRsZXNzIEJhdGNoIEFjdGlvbiBUb29sYmFyIHdpdGggTHVjaWRlIEljb25zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBwdC0xXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkF0dGVuZGFuY2U6PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbWFya0FsbEF0dGVuZGFuY2UoJ1ByZXNlbnQnKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17WydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYXR0ZW5kYW5jZVNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBhY3RpdmVEcmFmdFNlc3Npb25JZCk/LnN0YXR1cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MtMjAwIGJnLXN1Y2Nlc3MtNTAgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc3VjY2Vzcy02MDAgaG92ZXI6Ymctc3VjY2Vzcy0xMDAgZGFyazpib3JkZXItc3VjY2Vzcy05MDAvNDAgZGFyazpiZy1zdWNjZXNzLTUwMC8xMCBkYXJrOnRleHQtc3VjY2Vzcy00MDAgdHJhbnNpdGlvbiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFsbCBQcmVzZW50PC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG1hcmtBbGxBdHRlbmRhbmNlKCdBYnNlbnQnKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17WydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYXR0ZW5kYW5jZVNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBhY3RpdmVEcmFmdFNlc3Npb25JZCk/LnN0YXR1cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCBiZy1lcnJvci01MCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1lcnJvci02MDAgaG92ZXI6YmctZXJyb3ItMTAwIGRhcms6Ym9yZGVyLWVycm9yLTkwMC80MCBkYXJrOmJnLWVycm9yLTUwMC8xMCBkYXJrOnRleHQtZXJyb3ItNDAwIHRyYW5zaXRpb24gZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFsbCBBYnNlbnQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+VGFza3M6PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbWFya0FsbFRhc2tzKCdDb21wbGV0ZWQnKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17WydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYXR0ZW5kYW5jZVNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBhY3RpdmVEcmFmdFNlc3Npb25JZCk/LnN0YXR1cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MtMjAwIGJnLXN1Y2Nlc3MtNTAgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc3VjY2Vzcy02MDAgaG92ZXI6Ymctc3VjY2Vzcy0xMDAgZGFyazpib3JkZXItc3VjY2Vzcy05MDAvNDAgZGFyazpiZy1zdWNjZXNzLTUwMC8xMCBkYXJrOnRleHQtc3VjY2Vzcy00MDAgdHJhbnNpdGlvbiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFsbCBUYXNrcyBEb25lPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG1hcmtBbGxUYXNrcygnTm90IENvbXBsZXRlZCcpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhdHRlbmRhbmNlU2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IGFjdGl2ZURyYWZ0U2Vzc2lvbklkKT8uc3RhdHVzIHx8ICcnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cmFuc2l0aW9uIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPlJlc2V0IFRhc2tzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIDQuIFN0dWRlbnQgQXR0ZW5kYW5jZSBSb3N0ZXIgKENhcmRsZXNzIGxpc3QpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMy41IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICBTdHVkZW50IFJvc3RlciAoe2ZpbHRlcmVkU3R1ZGVudHMubGVuZ3RofSBFbnJvbGxlZClcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsb3dlcmNhc2UgZm9udC1ub3JtYWxcIj5BdHRlbmRhbmNlICZhbXA7IFRhc2sgc3RhdHVzPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtmaWx0ZXJlZFN0dWRlbnRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIE5vIHN0dWRlbnRzIGZvdW5kIGluIHRoaXMgc2VsZWN0aW9uLlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLWdyYXktMTAwIGRhcms6ZGl2aWRlLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkU3R1ZGVudHMubWFwKChzdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgcmVjb3JkID0gcmVjb3Jkc01hcFtzdC5pZF0gfHwge1xuICAgICAgICAgICAgICAgICAgICBzdHVkZW50SWQ6IHN0LmlkLFxuICAgICAgICAgICAgICAgICAgICBzdHVkZW50TmFtZTogc3QubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgY29kZTogc3QuY29kZSxcbiAgICAgICAgICAgICAgICAgICAgc3RhbmRhcmQ6IHN0LnN0YW5kYXJkLFxuICAgICAgICAgICAgICAgICAgICB2aWxsYWdlTmFtZTogc3QudmlsbGFnZU5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogJ1ByZXNlbnQnLFxuICAgICAgICAgICAgICAgICAgICB0YXNrU3RhdHVzOiAnQ29tcGxldGVkJyxcbiAgICAgICAgICAgICAgICAgICAgdGFza1RpdGxlOiB0YXNrVG9waWMsXG4gICAgICAgICAgICAgICAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNQcmVzZW50ID0gcmVjb3JkLnN0YXR1cyA9PT0gJ1ByZXNlbnQnO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNBYnNlbnQgPSByZWNvcmQuc3RhdHVzID09PSAnQWJzZW50JztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzVGFza0NvbXBsZXRlZCA9IHJlY29yZC50YXNrU3RhdHVzID09PSAnQ29tcGxldGVkJztcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17c3QuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNBYnNlbnQgPyAnYmctZXJyb3ItNTAvMjAgZGFyazpiZy1lcnJvci05NTAvMTAnIDogJ2hvdmVyOmJnLWdyYXktNTAvODAgZGFyazpob3ZlcjpiZy13aGl0ZS9bMC4wMl0nXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogU3R1ZGVudCBJbmZvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgc2hyaW5rLTAgZGFyazpiZy1icmFuZC01MDAvMTAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzdC5hdmF0YXJMZXR0ZXIgfHwgc3QubmFtZS5jaGFyQXQoMCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57c3QubmFtZX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3QuY29kZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0ZCB7c3Quc3RhbmRhcmR9ICZtaWRkb3Q7IHtzdC52aWxsYWdlTmFtZX0gJm1pZGRvdDsgUGFyZW50OiB7c3QucGFyZW50TmFtZSB8fCAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQXR0ZW5kYW5jZSBUb2dnbGUgQnV0dG9ucyAmIFRhc2sgU3RhdHVzICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zIHNlbGYtc3RhcnQgc206c2VsZi1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVG9nZ2xlQXR0ZW5kYW5jZShzdC5pZCwgJ1ByZXNlbnQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17WydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYXR0ZW5kYW5jZVNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBhY3RpdmVEcmFmdFNlc3Npb25JZCk/LnN0YXR1cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmVzZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXN1Y2Nlc3MtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByZXNlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUb2dnbGVBdHRlbmRhbmNlKHN0LmlkLCAnQWJzZW50Jyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1snU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGF0dGVuZGFuY2VTZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gYWN0aXZlRHJhZnRTZXNzaW9uSWQpPy5zdGF0dXMgfHwgJycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWJzZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVycm9yLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBYnNlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItbCBib3JkZXItZ3JheS0yMDAgcGwtMyBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUb2dnbGVUYXNrKHN0LmlkLCAnQ29tcGxldGVkJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1snU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGF0dGVuZGFuY2VTZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gYWN0aXZlRHJhZnRTZXNzaW9uSWQpPy5zdGF0dXMgfHwgJycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzVGFza0NvbXBsZXRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1icmFuZC01MDAgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFzayBEb25lXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVG9nZ2xlVGFzayhzdC5pZCwgJ05vdCBDb21wbGV0ZWQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17WydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYXR0ZW5kYW5jZVNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBhY3RpdmVEcmFmdFNlc3Npb25JZCk/LnN0YXR1cyB8fCAnJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWlzVGFza0NvbXBsZXRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmF5LTIwMCB0ZXh0LWdyYXktODAwIGRhcms6YmctZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQUNUSU9OIEJVVFRPTlMgKFNBVkUgRFJBRlQgJiBTVUJNSVQpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB0LTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+RGF5IHtzZWxlY3RlZERheX06PC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgIHtwcmVzZW50Q291bnR9IFByZXNlbnQgJm1pZGRvdDsge2Fic2VudENvdW50fSBBYnNlbnQgJm1pZGRvdDsge3Rhc2tzQ29tcGxldGVkQ291bnR9IFRhc2tzIERvbmVcbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7IVsnU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGF0dGVuZGFuY2VTZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gYWN0aXZlRHJhZnRTZXNzaW9uSWQpPy5zdGF0dXMgfHwgJycpICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHctZnVsbCBzbTp3LWF1dG8ganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVBdHRlbmRhbmNlU2Vzc2lvbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgU2F2ZSBhcyBEcmFmdFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxBY3Rpb25CdXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmVBdHRlbmRhbmNlU2Vzc2lvbih0cnVlKX1cbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgU3VibWl0IEF0dGVuZGFuY2UgJmFtcDsgVGFza3NcbiAgICAgICAgICAgICAgICA8L0FjdGlvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIC8qIFNFU1NJT04gSElTVE9SWSBUQUIgKi9cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMy41IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBQYXN0IFJlY29yZGVkIEF0dGVuZGFuY2UgJmFtcDsgVGFzayBTZXNzaW9uc1xuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICB7YXR0ZW5kYW5jZVNlc3Npb25zLmxlbmd0aH0gU2Vzc2lvbnMgTG9nZ2VkXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0xMDAgYmctZ3JheS01MC81MCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlNlc3Npb24gJmFtcDsgRGF5PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlBhbmNoYXlhdCAmYW1wOyBWaWxsYWdlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPkRhdGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+QXR0ZW5kYW5jZTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5UYXNrcyBEb25lPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0xMDAgZGFyazpkaXZpZGUtZ3JheS04MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIHthdHRlbmRhbmNlU2Vzc2lvbnMubWFwKChzZXNzaW9uKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtzZXNzaW9uLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzgwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5kYXkgfHwgYERheSAke3Nlc3Npb24uZGF5TnVtYmVyfWB9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ub3JtYWwgdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uc2Vzc2lvbk5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3Nlc3Npb24ucGFuY2hheWF0TmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24udmlsbGFnZU5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+e3Nlc3Npb24uZGF0ZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdWNjZXNzLTUwMFwiPntzZXNzaW9uLnByZXNlbnRDb3VudCB8fCAwfTwvc3Bhbj4gL3snICd9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPntzZXNzaW9uLnRvdGFsQ291bnQgfHwgc2Vzc2lvbi5yZWNvcmRzLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSBmb250LWJvbGQgdGV4dC13YXJuaW5nLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnRhc2tzQ29tcGxldGVkQ291bnQgPz9cbiAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb24ucmVjb3Jkcy5maWx0ZXIoKHIpID0+IHIudGFza1N0YXR1cyA9PT0gJ0NvbXBsZXRlZCcpLmxlbmd0aH17JyAnfVxuICAgICAgICAgICAgICAgICAgICAgIC8ge3Nlc3Npb24ucmVjb3Jkcy5sZW5ndGh9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZVxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uLnN0YXR1cyA9PT0gJ1N1Ym1pdHRlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdzdWNjZXNzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2Vzc2lvbi5zdGF0dXMgPT09ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdlcnJvcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdwcmltYXJ5J1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlc3Npb24ucGFuY2hheWF0SWQpIHNldFNlbGVjdGVkUGFuY2hheWF0SWQoc2Vzc2lvbi5wYW5jaGF5YXRJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZXNzaW9uLnZpbGxhZ2VJZCkgc2V0U2VsZWN0ZWRWaWxsYWdlSWQoc2Vzc2lvbi52aWxsYWdlSWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2Vzc2lvbi5kYXlOdW1iZXIpIHNldFNlbGVjdGVkRGF5KHNlc3Npb24uZGF5TnVtYmVyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlc3Npb24uZGF0ZSkgc2V0U2Vzc2lvbkRhdGUoc2Vzc2lvbi5kYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlc3Npb24uc2Vzc2lvbk5hbWUpIHNldFNlc3Npb25UaXRsZShzZXNzaW9uLnNlc3Npb25OYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNlc3Npb24udGFza1RvcGljKSBzZXRUYXNrVG9waWMoc2Vzc2lvbi50YXNrVG9waWMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1hcDogUmVjb3JkPHN0cmluZywgQXR0ZW5kYW5jZVJlY29yZD4gPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2Vzc2lvbi5yZWNvcmRzLmZvckVhY2goKHIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXBbci5zdHVkZW50SWRdID0gcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlY29yZHNNYXAobWFwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlRHJhZnRTZXNzaW9uSWQoc2Vzc2lvbi5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYignbWFyaycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYnJhbmQtNTAwIGhvdmVyOnRleHQtYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnN0YXR1cyA9PT0gJ0RyYWZ0JyB8fCBzZXNzaW9uLnN0YXR1cyA9PT0gJ0NvcnJlY3Rpb24gUmVxdWVzdGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdDb250aW51ZSBFbnRyeSDihpInXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1ZpZXcgLyBFZGl0IOKGkid9XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9BdHRlbmRhbmNlVmlldy50c3gifQ==