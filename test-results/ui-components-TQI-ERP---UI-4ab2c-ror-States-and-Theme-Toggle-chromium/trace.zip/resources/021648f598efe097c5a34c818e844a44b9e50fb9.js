import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PanchayatsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Plus,
  Search,
  MapPin,
  Home,
  GraduationCap,
  Users,
  X,
  ChevronRight
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import Badge from "/src/components/ui/badge.tsx";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "/src/components/ui/table.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const PanchayatsView = ({
  panchayats,
  onSelectPanchayat,
  onAddPanchayat,
  onNavigate
}) => {
  _s();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({
    name: "",
    block: "Harur Block",
    status: "On Track",
    villages: ""
  });
  const totalVillages = useMemo(() => panchayats.reduce((s, p) => s + (p.villagesCount || p.villages.length), 0), [panchayats]);
  const totalStudents = useMemo(() => panchayats.reduce((s, p) => s + p.activeStudents, 0), [panchayats]);
  const totalVols = useMemo(() => panchayats.reduce((s, p) => s + p.volunteersCount, 0), [panchayats]);
  const filtered = useMemo(
    () => panchayats.filter((p) => {
      const q = search.toLowerCase();
      const matchSearch = !search || p.name.toLowerCase().includes(q) || p.villages.some((v) => v.name.toLowerCase().includes(q));
      const matchStatus = statusFilter === "All" || p.status === statusFilter;
      return matchSearch && matchStatus;
    }),
    [panchayats, search, statusFilter]
  );
  const handleSave = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    onAddPanchayat({
      name: form.name.trim(),
      cluster: `Dharmapuri (${form.block})`,
      status: form.status,
      initialVillages: form.villages.split(",").map((v) => v.trim()).filter(Boolean)
    });
    setForm({ name: "", block: "Harur Block", status: "On Track", villages: "" });
    setShowAdd(false);
  };
  const getStatusBadge = (status) => {
    switch (status) {
      case "On Track":
        return /* @__PURE__ */ jsxDEV(Badge, { color: "success", size: "sm", children: "On Track" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 86,
          columnNumber: 16
        }, this);
      case "Correction Required":
        return /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: "Correction Required" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 88,
          columnNumber: 16
        }, this);
      case "Action Needed":
        return /* @__PURE__ */ jsxDEV(Badge, { color: "error", size: "sm", children: "Action Needed" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 90,
          columnNumber: 16
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: status }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 92,
          columnNumber: 16
        }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Panchayats & Village Clusters" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 102,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            panchayats.length,
            " Panchayats"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 105,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 101,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: [
          panchayats.length,
          " panchayat hubs · ",
          totalVillages,
          " active villages · ",
          totalStudents,
          " enrolled students"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 109,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 100,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setShowAdd(true),
          className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-sm font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition shrink-0",
          children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 119,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Add Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 120,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 114,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Panchayats" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 128,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(MapPin, { className: "h-4 w-4 text-brand-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 129,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: panchayats.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 131,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Villages" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 136,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Home, { className: "h-4 w-4 text-success-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 137,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: totalVillages }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 134,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Students" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 144,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(GraduationCap, { className: "h-4 w-4 text-theme-purple-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 145,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 143,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: totalStudents }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 147,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Volunteers" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 152,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4 text-warning-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 153,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 151,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: totalVols }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 155,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 125,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search panchayats or villages...",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 163,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0", children: [
        ["All", "On Track", "Correction Required", "Action Needed"].map(
          (s) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setStatusFilter(s),
              className: `rounded-lg px-3 py-1.5 text-xs font-medium transition ${statusFilter === s ? "bg-brand-500 text-white shadow-theme-xs" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700 dark:hover:bg-gray-700"}`,
              children: s
            },
            s,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 174,
              columnNumber: 11
            },
            this
          )
        ),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400 dark:text-gray-500 ml-auto sm:ml-2", children: [
          filtered.length,
          " of ",
          panchayats.length
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 187,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 172,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-16 text-center", children: [
      /* @__PURE__ */ jsxDEV(MapPin, { className: "mx-auto h-12 w-12 text-gray-300 dark:text-gray-600" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "mt-3 text-base font-semibold text-gray-800 dark:text-white", children: "No panchayats found" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 197,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: search ? "Try adjusting your search query." : "Add your first panchayat to get started." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 198,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "w-[300px]", children: "Panchayat" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 207,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 208,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Villages" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 209,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Students" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 210,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Volunteers" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 211,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 212,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 206,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 205,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: filtered.map(
        (p) => /* @__PURE__ */ jsxDEV(TableRow, { className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors", children: [
          /* @__PURE__ */ jsxDEV(TableCell, { children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onSelectPanchayat(p.id),
                className: "text-sm font-semibold text-gray-900 hover:text-brand-500 dark:text-white dark:hover:text-brand-400 text-left transition-colors cursor-pointer",
                children: p.name
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                lineNumber: 219,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400 dark:text-gray-500 mt-0.5", children: [
              p.villages.slice(0, 3).map((v) => v.name).join(", "),
              p.villages.length > 3 && ` +${p.villages.length - 3} more`
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 226,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 218,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: getStatusBadge(p.status) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 231,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-600 dark:text-gray-300 font-medium", children: p.villagesCount || p.villages.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 234,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-600 dark:text-gray-300 font-medium", children: p.activeStudents }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 237,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-600 dark:text-gray-300 font-medium", children: p.volunteersCount }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 240,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onNavigate("students", p.id),
                className: "rounded-lg px-2.5 py-1 text-xs font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-white transition",
                children: "Students"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                lineNumber: 245,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onSelectPanchayat(p.id),
                className: "inline-flex items-center gap-1 rounded-lg bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-500 hover:bg-brand-100 dark:bg-brand-500/10 dark:text-brand-400 dark:hover:bg-brand-500/20 transition",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Open" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                    lineNumber: 257,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                    lineNumber: 258,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                lineNumber: 252,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 244,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 243,
            columnNumber: 19
          }, this)
        ] }, p.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 217,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 215,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 204,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 203,
      columnNumber: 7
    }, this),
    showAdd && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900 dark:text-white", children: "Add New Panchayat" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 274,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowAdd(false),
            className: "inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-white transition",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 282,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 277,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 273,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSave, className: "mt-5 space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", htmlFor: "pan-name", children: "Panchayat Name *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 288,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "pan-name",
              type: "text",
              required: true,
              placeholder: "e.g. Vedakkattamaduvu",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value }),
              className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 291,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 287,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", htmlFor: "pan-block", children: "Block" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 303,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "pan-block",
              type: "text",
              value: form.block,
              onChange: (e) => setForm({ ...form, block: e.target.value }),
              className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 306,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 302,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", htmlFor: "pan-status", children: "Operational Status" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 316,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: form.status,
              onValueChange: (val) => setForm({ ...form, status: val }),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-10 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Status" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                  lineNumber: 324,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                  lineNumber: 323,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "On Track", children: "On Track" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                    lineNumber: 327,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Correction Required", children: "Correction Required" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                    lineNumber: 328,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Action Needed", children: "Action Needed" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                    lineNumber: 329,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
                  lineNumber: 326,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 319,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 315,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", htmlFor: "pan-villages", children: "Initial Villages (comma separated)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
            lineNumber: 335,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "pan-villages",
              type: "text",
              placeholder: "e.g. Ammapettai, Pudur, Kottai",
              value: form.villages,
              onChange: (e) => setForm({ ...form, villages: e.target.value }),
              className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 338,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 334,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowAdd(false),
              className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 349,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
              children: "Save Panchayat"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
              lineNumber: 356,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
          lineNumber: 348,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
        lineNumber: 286,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 272,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
      lineNumber: 271,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
};
_s(PanchayatsView, "V6hdu5ZiD2GtlRUX3u7CBdgYj6E=");
_c = PanchayatsView;
var _c;
$RefreshReg$(_c, "PanchayatsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZlOztBQXJGZixTQUFnQkEsVUFBVUMsZUFBZTtBQUN6QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBRUFDO0FBQUFBLE9BQ0s7QUFFUCxPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLE9BQU9DLGFBQWFDLFdBQVdDLFVBQVVDLGlCQUFpQjtBQUNuRTtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFlQSxhQUFNQyxpQkFBZ0RBLENBQUM7QUFBQSxFQUM1REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBZ0I1QixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDNkIsY0FBY0MsZUFBZSxJQUFJOUIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQytCLFNBQVNDLFVBQVUsSUFBY2hDLFNBQVMsS0FBSztBQUV0RCxRQUFNLENBQUNpQyxNQUFNQyxPQUFPLElBQUlsQyxTQUFTO0FBQUEsSUFDL0JtQyxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBRUQsUUFBTUMsZ0JBQWlCdEMsUUFBUSxNQUFNcUIsV0FBV2tCLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUQsS0FBS0MsRUFBRUMsaUJBQWlCRCxFQUFFSixTQUFTTSxTQUFTLENBQUMsR0FBRyxDQUFDdEIsVUFBVSxDQUFDO0FBQzdILFFBQU11QixnQkFBaUI1QyxRQUFRLE1BQU1xQixXQUFXa0IsT0FBTyxDQUFDQyxHQUFHQyxNQUFNRCxJQUFJQyxFQUFFSSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUN4QixVQUFVLENBQUM7QUFDdkcsUUFBTXlCLFlBQWlCOUMsUUFBUSxNQUFNcUIsV0FBV2tCLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUQsSUFBSUMsRUFBRU0saUJBQWlCLENBQUMsR0FBRyxDQUFDMUIsVUFBVSxDQUFDO0FBRXhHLFFBQU0yQixXQUFXaEQ7QUFBQUEsSUFBUSxNQUN2QnFCLFdBQVc0QixPQUFPLENBQUNSLE1BQU07QUFDdkIsWUFBTVMsSUFBSXhCLE9BQU95QixZQUFZO0FBQzdCLFlBQU1DLGNBQWMsQ0FBQzFCLFVBQ25CZSxFQUFFUCxLQUFLaUIsWUFBWSxFQUFFRSxTQUFTSCxDQUFDLEtBQy9CVCxFQUFFSixTQUFTaUIsS0FBSyxDQUFDQyxNQUFNQSxFQUFFckIsS0FBS2lCLFlBQVksRUFBRUUsU0FBU0gsQ0FBQyxDQUFDO0FBQ3pELFlBQU1NLGNBQWM1QixpQkFBaUIsU0FBU2EsRUFBRUwsV0FBV1I7QUFDM0QsYUFBT3dCLGVBQWVJO0FBQUFBLElBQ3hCLENBQUM7QUFBQSxJQUNELENBQUNuQyxZQUFZSyxRQUFRRSxZQUFZO0FBQUEsRUFDbkM7QUFFQSxRQUFNNkIsYUFBYUEsQ0FBQ0MsTUFBdUI7QUFDekNBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDM0IsS0FBS0UsS0FBSzBCLEtBQUssRUFBRztBQUN2QnJDLG1CQUFlO0FBQUEsTUFDYlcsTUFBTUYsS0FBS0UsS0FBSzBCLEtBQUs7QUFBQSxNQUNyQkMsU0FBUyxlQUFlN0IsS0FBS0csS0FBSztBQUFBLE1BQ2xDQyxRQUFRSixLQUFLSTtBQUFBQSxNQUNiMEIsaUJBQWlCOUIsS0FBS0ssU0FBUzBCLE1BQU0sR0FBRyxFQUFFQyxJQUFJLENBQUNULE1BQU1BLEVBQUVLLEtBQUssQ0FBQyxFQUFFWCxPQUFPZ0IsT0FBTztBQUFBLElBQy9FLENBQUM7QUFDRGhDLFlBQVEsRUFBRUMsTUFBTSxJQUFJQyxPQUFPLGVBQWVDLFFBQVEsWUFBWUMsVUFBVSxHQUFHLENBQUM7QUFDNUVOLGVBQVcsS0FBSztBQUFBLEVBQ2xCO0FBRUEsUUFBTW1DLGlCQUFpQkEsQ0FBQzlCLFdBQW1CO0FBQ3pDLFlBQVFBLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFDSCxlQUFPLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBSyx3QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLE1BQ2xELEtBQUs7QUFDSCxlQUFPLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBSyxtQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLE1BQzdELEtBQUs7QUFDSCxlQUFPLHVCQUFDLFNBQU0sT0FBTSxTQUFRLE1BQUssTUFBSyw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLE1BQ3JEO0FBQ0UsZUFBTyx1QkFBQyxTQUFNLE9BQU0sU0FBUSxNQUFLLE1BQU1BLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDhFQUE2RSw2Q0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QmY7QUFBQUEsdUJBQVdzQjtBQUFBQSxZQUFPO0FBQUEsZUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQ1Z0QjtBQUFBQSxxQkFBV3NCO0FBQUFBLFVBQU87QUFBQSxVQUEwQkw7QUFBQUEsVUFBYztBQUFBLFVBQTJCTTtBQUFBQSxVQUFjO0FBQUEsYUFEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1iLFdBQVcsSUFBSTtBQUFBLFVBQzlCLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsWUFDekIsdUJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxRQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxtRkFBa0YsMEJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRHO0FBQUEsVUFDNUcsdUJBQUMsVUFBTyxXQUFVLDRCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLGFBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlEQUF5RFYscUJBQVdzQixVQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsV0FMNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLHdCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRztBQUFBLFVBQzFHLHVCQUFDLFFBQUssV0FBVSw4QkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxhQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5REFBeURMLDJCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNGO0FBQUEsV0FMeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLHdCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRztBQUFBLFVBQzFHLHVCQUFDLGlCQUFjLFdBQVUsbUNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseURBQXlETSwyQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRjtBQUFBLFdBTHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG9IQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1GQUFrRiwwQkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEc7QUFBQSxVQUM1Ryx1QkFBQyxTQUFNLFdBQVUsOEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsYUFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseURBQXlERSx1QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRjtBQUFBLFdBTHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLCtCQUFDLFVBQU8sV0FBVSwwRkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RztBQUFBLFFBQ3hHO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxhQUFZO0FBQUEsWUFDWixPQUFPcEI7QUFBQUEsWUFDUCxVQUFVLENBQUNnQyxNQUFNL0IsVUFBVStCLEVBQUVTLE9BQU9DLEtBQUs7QUFBQSxZQUN6QyxXQUFVO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUttVDtBQUFBLFdBUHJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNYO0FBQUEsU0FBQyxPQUFPLFlBQVksdUJBQXVCLGVBQWUsRUFBWUo7QUFBQUEsVUFBSSxDQUFDeEIsTUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTVgsZ0JBQWdCVyxDQUFDO0FBQUEsY0FDaEMsV0FBVyx5REFDVFosaUJBQWlCWSxJQUNiLDRDQUNBLGlKQUFpSjtBQUFBLGNBR3RKQTtBQUFBQTtBQUFBQSxZQVRJQTtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFFBQ0Q7QUFBQSxRQUNELHVCQUFDLFVBQUssV0FBVSw0REFDYlE7QUFBQUEsbUJBQVNMO0FBQUFBLFVBQU87QUFBQSxVQUFLdEIsV0FBV3NCO0FBQUFBLGFBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsSUFHQ0ssU0FBU0wsV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSw2QkFBQyxVQUFPLFdBQVUsd0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0U7QUFBQSxNQUN0RSx1QkFBQyxRQUFHLFdBQVUsOERBQTZELG1DQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThGO0FBQUEsTUFDOUYsdUJBQUMsT0FBRSxXQUFVLGlEQUNWakIsbUJBQVMscUNBQXFDLDhDQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5SEFDYixpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsZUFDQyxpQ0FBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxVQUFRLE1BQUMsV0FBVSxhQUFZLHlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1EO0FBQUEsUUFDbkQsdUJBQUMsYUFBVSxVQUFRLE1BQUMsc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUMxQix1QkFBQyxhQUFVLFVBQVEsTUFBQyx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzVCLHVCQUFDLGFBQVUsVUFBUSxNQUFDLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsYUFBVSxVQUFRLE1BQUMsMEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUM5Qix1QkFBQyxhQUFVLFVBQVEsTUFBQyxXQUFVLGNBQWEsdUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxXQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLGFBQ0VzQixtQkFBU2dCO0FBQUFBLFFBQUksQ0FBQ3ZCLE1BQ2IsdUJBQUMsWUFBb0IsV0FBVSxvRUFDN0I7QUFBQSxpQ0FBQyxhQUNDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNbkIsa0JBQWtCbUIsRUFBRTRCLEVBQUU7QUFBQSxnQkFDckMsV0FBVTtBQUFBLGdCQUVUNUIsWUFBRVA7QUFBQUE7QUFBQUEsY0FMTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG1EQUNaTztBQUFBQSxnQkFBRUosU0FBU2lDLE1BQU0sR0FBRyxDQUFDLEVBQUVOLElBQUksQ0FBQ1QsTUFBTUEsRUFBRXJCLElBQUksRUFBRXFDLEtBQUssSUFBSTtBQUFBLGNBQ25EOUIsRUFBRUosU0FBU00sU0FBUyxLQUFLLEtBQUtGLEVBQUVKLFNBQVNNLFNBQVMsQ0FBQztBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFDQSx1QkFBQyxhQUNFdUIseUJBQWV6QixFQUFFTCxNQUFNLEtBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxnREFDbEJLLFlBQUVDLGlCQUFpQkQsRUFBRUosU0FBU00sVUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLGdEQUNsQkYsWUFBRUksa0JBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLGdEQUNsQkosWUFBRU0sbUJBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLGNBQ25CLGlDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXZCLFdBQVcsWUFBWWlCLEVBQUU0QixFQUFFO0FBQUEsZ0JBQzFDLFdBQVU7QUFBQSxnQkFBMEs7QUFBQTtBQUFBLGNBSHRMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU0vQyxrQkFBa0JtQixFQUFFNEIsRUFBRTtBQUFBLGdCQUNyQyxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQVU7QUFBQSxrQkFDVix1QkFBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUE7QUFBQTtBQUFBLGNBTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBNUNhNUIsRUFBRTRCLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2Q0E7QUFBQSxNQUNELEtBaERIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpREE7QUFBQSxTQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkRBLEtBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErREE7QUFBQSxJQUlEdkMsV0FDQyx1QkFBQyxTQUFJLFdBQVUsZ0hBQ2IsaUNBQUMsU0FBSSxXQUFVLGtLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1EQUFrRCxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNQyxXQUFXLEtBQUs7QUFBQSxZQUMvQixXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBO0FBQUEsVUFMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVMEIsWUFBWSxXQUFVLDBCQUNwQztBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLFNBQVEsWUFBVyxnQ0FBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixPQUFPekIsS0FBS0U7QUFBQUEsY0FDWixVQUFVLENBQUN3QixNQUFNekIsUUFBUSxFQUFFLEdBQUdELE1BQU1FLE1BQU13QixFQUFFUyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUMxRCxXQUFVO0FBQUE7QUFBQSxZQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU93UTtBQUFBLGFBWDFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnR0FBK0YsU0FBUSxhQUFZLHFCQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT3BDLEtBQUtHO0FBQUFBLGNBQ1osVUFBVSxDQUFDdUIsTUFBTXpCLFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxPQUFPdUIsRUFBRVMsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDM0QsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLd1E7QUFBQSxhQVQxUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLFNBQVEsY0FBYSxrQ0FBckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9wQyxLQUFLSTtBQUFBQSxjQUNaLGVBQWUsQ0FBQ29DLFFBQWF2QyxRQUFRLEVBQUUsR0FBR0QsTUFBTUksUUFBUW9DLElBQUksQ0FBQztBQUFBLGNBRTdEO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSxnQkFDdkIsaUNBQUMsZUFBWSxhQUFZLG1CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUM7QUFBQSxrQkFDckMsdUJBQUMsY0FBVyxPQUFNLHVCQUFzQixtQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQ7QUFBQSxrQkFDM0QsdUJBQUMsY0FBVyxPQUFNLGlCQUFnQiw2QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxxQkFIakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBO0FBQUE7QUFBQSxZQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnR0FBK0YsU0FBUSxnQkFBZSxrREFBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU94QyxLQUFLSztBQUFBQSxjQUNaLFVBQVUsQ0FBQ3FCLE1BQU16QixRQUFRLEVBQUUsR0FBR0QsTUFBTUssVUFBVXFCLEVBQUVTLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQzlELFdBQVU7QUFBQTtBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXdRO0FBQUEsYUFWMVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsK0VBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNckMsV0FBVyxLQUFLO0FBQUEsY0FDL0IsV0FBVTtBQUFBLGNBQXFNO0FBQUE7QUFBQSxZQUhqTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFrSDtBQUFBO0FBQUEsWUFGOUg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2RUE7QUFBQSxTQTNGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEZBLEtBN0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4RkE7QUFBQSxPQTVRSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOFFBO0FBRUo7QUFBRU4sR0E1VVdMLGdCQUE2QztBQUFBLEtBQTdDQTtBQUE2QyxJQUFBcUQ7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwiUGx1cyIsIlNlYXJjaCIsIk1hcFBpbiIsIkhvbWUiLCJHcmFkdWF0aW9uQ2FwIiwiVXNlcnMiLCJYIiwiQ2hldnJvblJpZ2h0IiwiQmFkZ2UiLCJUYWJsZSIsIlRhYmxlSGVhZGVyIiwiVGFibGVCb2R5IiwiVGFibGVSb3ciLCJUYWJsZUNlbGwiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIlBhbmNoYXlhdHNWaWV3IiwicGFuY2hheWF0cyIsIm9uU2VsZWN0UGFuY2hheWF0Iiwib25BZGRQYW5jaGF5YXQiLCJvbk5hdmlnYXRlIiwiX3MiLCJzZWFyY2giLCJzZXRTZWFyY2giLCJzdGF0dXNGaWx0ZXIiLCJzZXRTdGF0dXNGaWx0ZXIiLCJzaG93QWRkIiwic2V0U2hvd0FkZCIsImZvcm0iLCJzZXRGb3JtIiwibmFtZSIsImJsb2NrIiwic3RhdHVzIiwidmlsbGFnZXMiLCJ0b3RhbFZpbGxhZ2VzIiwicmVkdWNlIiwicyIsInAiLCJ2aWxsYWdlc0NvdW50IiwibGVuZ3RoIiwidG90YWxTdHVkZW50cyIsImFjdGl2ZVN0dWRlbnRzIiwidG90YWxWb2xzIiwidm9sdW50ZWVyc0NvdW50IiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJxIiwidG9Mb3dlckNhc2UiLCJtYXRjaFNlYXJjaCIsImluY2x1ZGVzIiwic29tZSIsInYiLCJtYXRjaFN0YXR1cyIsImhhbmRsZVNhdmUiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwiY2x1c3RlciIsImluaXRpYWxWaWxsYWdlcyIsInNwbGl0IiwibWFwIiwiQm9vbGVhbiIsImdldFN0YXR1c0JhZGdlIiwidGFyZ2V0IiwidmFsdWUiLCJpZCIsInNsaWNlIiwiam9pbiIsInZhbCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBhbmNoYXlhdHNWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFxyXG4gIFBsdXMsIFxyXG4gIFNlYXJjaCwgXHJcbiAgTWFwUGluLCBcclxuICBIb21lLCBcclxuICBHcmFkdWF0aW9uQ2FwLCBcclxuICBVc2VycywgXHJcbiAgWCxcclxuICBFeHRlcm5hbExpbmssXHJcbiAgQ2hldnJvblJpZ2h0XHJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuaW1wb3J0IHsgVGFiVHlwZSwgUGFuY2hheWF0IH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQgQmFkZ2UgZnJvbSAnLi91aS9iYWRnZSc7XHJcbmltcG9ydCB7IFRhYmxlLCBUYWJsZUhlYWRlciwgVGFibGVCb2R5LCBUYWJsZVJvdywgVGFibGVDZWxsIH0gZnJvbSAnLi91aS90YWJsZSc7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIFNlbGVjdENvbnRlbnQsXHJcbiAgU2VsZWN0SXRlbSxcclxuICBTZWxlY3RUcmlnZ2VyLFxyXG4gIFNlbGVjdFZhbHVlLFxyXG59IGZyb20gJy4vdWkvc2VsZWN0JztcclxuaW1wb3J0IHsgQWN0aW9uQnV0dG9uIH0gZnJvbSAnLi91aS9hY3Rpb24tYnV0dG9uJztcclxuXHJcbmludGVyZmFjZSBQYW5jaGF5YXRzVmlld1Byb3BzIHtcclxuICBwYW5jaGF5YXRzOiBQYW5jaGF5YXRbXTtcclxuICBvblNlbGVjdFBhbmNoYXlhdDogKHBhbmNoYXlhdElkOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgb25BZGRQYW5jaGF5YXQ6IChwOiB7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBjbHVzdGVyOiBzdHJpbmc7XHJcbiAgICBzdGF0dXM6ICdPbiBUcmFjaycgfCAnQ29ycmVjdGlvbiBSZXF1aXJlZCcgfCAnQWN0aW9uIE5lZWRlZCc7XHJcbiAgICBpbml0aWFsVmlsbGFnZXM6IHN0cmluZ1tdO1xyXG4gIH0pID0+IHZvaWQ7XHJcbiAgb25OYXZpZ2F0ZTogKHRhYjogVGFiVHlwZSwgdGFyZ2V0SWQ/OiBzdHJpbmcsIHNlY29uZGFyeVBhcmFtPzogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgUGFuY2hheWF0c1ZpZXc6IFJlYWN0LkZDPFBhbmNoYXlhdHNWaWV3UHJvcHM+ID0gKHtcclxuICBwYW5jaGF5YXRzLFxyXG4gIG9uU2VsZWN0UGFuY2hheWF0LFxyXG4gIG9uQWRkUGFuY2hheWF0LFxyXG4gIG9uTmF2aWdhdGUsXHJcbn0pID0+IHtcclxuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdICAgICAgICAgICAgID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZSgnQWxsJyk7XHJcbiAgY29uc3QgW3Nob3dBZGQsIHNldFNob3dBZGRdICAgICAgICAgICA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogJycsXHJcbiAgICBibG9jazogJ0hhcnVyIEJsb2NrJyxcclxuICAgIHN0YXR1czogJ09uIFRyYWNrJyBhcyAnT24gVHJhY2snIHwgJ0NvcnJlY3Rpb24gUmVxdWlyZWQnIHwgJ0FjdGlvbiBOZWVkZWQnLFxyXG4gICAgdmlsbGFnZXM6ICcnLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB0b3RhbFZpbGxhZ2VzICA9IHVzZU1lbW8oKCkgPT4gcGFuY2hheWF0cy5yZWR1Y2UoKHMsIHApID0+IHMgKyAocC52aWxsYWdlc0NvdW50IHx8IHAudmlsbGFnZXMubGVuZ3RoKSwgMCksIFtwYW5jaGF5YXRzXSk7XHJcbiAgY29uc3QgdG90YWxTdHVkZW50cyAgPSB1c2VNZW1vKCgpID0+IHBhbmNoYXlhdHMucmVkdWNlKChzLCBwKSA9PiBzICsgcC5hY3RpdmVTdHVkZW50cywgMCksIFtwYW5jaGF5YXRzXSk7XHJcbiAgY29uc3QgdG90YWxWb2xzICAgICAgPSB1c2VNZW1vKCgpID0+IHBhbmNoYXlhdHMucmVkdWNlKChzLCBwKSA9PiBzICsgcC52b2x1bnRlZXJzQ291bnQsIDApLCBbcGFuY2hheWF0c10pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZCA9IHVzZU1lbW8oKCkgPT5cclxuICAgIHBhbmNoYXlhdHMuZmlsdGVyKChwKSA9PiB7XHJcbiAgICAgIGNvbnN0IHEgPSBzZWFyY2gudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgbWF0Y2hTZWFyY2ggPSAhc2VhcmNoIHx8XHJcbiAgICAgICAgcC5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcclxuICAgICAgICBwLnZpbGxhZ2VzLnNvbWUoKHYpID0+IHYubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKTtcclxuICAgICAgY29uc3QgbWF0Y2hTdGF0dXMgPSBzdGF0dXNGaWx0ZXIgPT09ICdBbGwnIHx8IHAuc3RhdHVzID09PSBzdGF0dXNGaWx0ZXI7XHJcbiAgICAgIHJldHVybiBtYXRjaFNlYXJjaCAmJiBtYXRjaFN0YXR1cztcclxuICAgIH0pLFxyXG4gICAgW3BhbmNoYXlhdHMsIHNlYXJjaCwgc3RhdHVzRmlsdGVyXVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmUgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIWZvcm0ubmFtZS50cmltKCkpIHJldHVybjtcclxuICAgIG9uQWRkUGFuY2hheWF0KHtcclxuICAgICAgbmFtZTogZm9ybS5uYW1lLnRyaW0oKSxcclxuICAgICAgY2x1c3RlcjogYERoYXJtYXB1cmkgKCR7Zm9ybS5ibG9ja30pYCxcclxuICAgICAgc3RhdHVzOiBmb3JtLnN0YXR1cyxcclxuICAgICAgaW5pdGlhbFZpbGxhZ2VzOiBmb3JtLnZpbGxhZ2VzLnNwbGl0KCcsJykubWFwKCh2KSA9PiB2LnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pLFxyXG4gICAgfSk7XHJcbiAgICBzZXRGb3JtKHsgbmFtZTogJycsIGJsb2NrOiAnSGFydXIgQmxvY2snLCBzdGF0dXM6ICdPbiBUcmFjaycsIHZpbGxhZ2VzOiAnJyB9KTtcclxuICAgIHNldFNob3dBZGQoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1czogc3RyaW5nKSA9PiB7XHJcbiAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICBjYXNlICdPbiBUcmFjayc6XHJcbiAgICAgICAgcmV0dXJuIDxCYWRnZSBjb2xvcj1cInN1Y2Nlc3NcIiBzaXplPVwic21cIj5PbiBUcmFjazwvQmFkZ2U+O1xyXG4gICAgICBjYXNlICdDb3JyZWN0aW9uIFJlcXVpcmVkJzpcclxuICAgICAgICByZXR1cm4gPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPkNvcnJlY3Rpb24gUmVxdWlyZWQ8L0JhZGdlPjtcclxuICAgICAgY2FzZSAnQWN0aW9uIE5lZWRlZCc6XHJcbiAgICAgICAgcmV0dXJuIDxCYWRnZSBjb2xvcj1cImVycm9yXCIgc2l6ZT1cInNtXCI+QWN0aW9uIE5lZWRlZDwvQmFkZ2U+O1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiA8QmFkZ2UgY29sb3I9XCJsaWdodFwiIHNpemU9XCJzbVwiPntzdGF0dXN9PC9CYWRnZT47XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogMS4gQ2FyZGxlc3MgUGFnZSBIZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICBQYW5jaGF5YXRzICYgVmlsbGFnZSBDbHVzdGVyc1xyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAge3BhbmNoYXlhdHMubGVuZ3RofSBQYW5jaGF5YXRzXHJcbiAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICB7cGFuY2hheWF0cy5sZW5ndGh9IHBhbmNoYXlhdCBodWJzICZtaWRkb3Q7IHt0b3RhbFZpbGxhZ2VzfSBhY3RpdmUgdmlsbGFnZXMgJm1pZGRvdDsge3RvdGFsU3R1ZGVudHN9IGVucm9sbGVkIHN0dWRlbnRzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZCh0cnVlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gc2hyaW5rLTBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+QWRkIFBhbmNoYXlhdDwvc3Bhbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogMi4gQ29tcGFjdCBNZXRyaWMgQ2FyZHMgKGNvdW50cyAmIHN0YXR1cyBvbmx5KSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNCBzbTpwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+UGFuY2hheWF0czwvc3Bhbj5cclxuICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtYnJhbmQtNTAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPntwYW5jaGF5YXRzLmxlbmd0aH08L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNCBzbTpwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+VmlsbGFnZXM8L3NwYW4+XHJcbiAgICAgICAgICAgIDxIb21lIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1zdWNjZXNzLTUwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dG90YWxWaWxsYWdlc308L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNCBzbTpwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+U3R1ZGVudHM8L3NwYW4+XHJcbiAgICAgICAgICAgIDxHcmFkdWF0aW9uQ2FwIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC10aGVtZS1wdXJwbGUtNTAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPnt0b3RhbFN0dWRlbnRzfTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC00IHNtOnAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5Wb2x1bnRlZXJzPC9zcGFuPlxyXG4gICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXdhcm5pbmctNTAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPnt0b3RhbFZvbHN9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIDMuIENhcmRsZXNzIFNlYXJjaCAmIEZpbHRlciBCYXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctc21cIj5cclxuICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHBhbmNoYXlhdHMgb3IgdmlsbGFnZXMuLi5cIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcGwtMTAgcHItNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTgwMCBzaGFkb3ctdGhlbWUteHMgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHBiLTEgc206cGItMFwiPlxyXG4gICAgICAgICAgeyhbJ0FsbCcsICdPbiBUcmFjaycsICdDb3JyZWN0aW9uIFJlcXVpcmVkJywgJ0FjdGlvbiBOZWVkZWQnXSBhcyBjb25zdCkubWFwKChzKSA9PiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBrZXk9e3N9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RhdHVzRmlsdGVyKHMpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uICR7XHJcbiAgICAgICAgICAgICAgICBzdGF0dXNGaWx0ZXIgPT09IHNcclxuICAgICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCdcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtzfVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCBtbC1hdXRvIHNtOm1sLTJcIj5cclxuICAgICAgICAgICAge2ZpbHRlcmVkLmxlbmd0aH0gb2Yge3BhbmNoYXlhdHMubGVuZ3RofVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiA0LiBDYXJkbGVzcyBNb2Rlcm4gVGFibGUgKi99XHJcbiAgICAgIHtmaWx0ZXJlZC5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xNiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJteC1hdXRvIGgtMTIgdy0xMiB0ZXh0LWdyYXktMzAwIGRhcms6dGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPk5vIHBhbmNoYXlhdHMgZm91bmQ8L2gzPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgIHtzZWFyY2ggPyAnVHJ5IGFkanVzdGluZyB5b3VyIHNlYXJjaCBxdWVyeS4nIDogJ0FkZCB5b3VyIGZpcnN0IHBhbmNoYXlhdCB0byBnZXQgc3RhcnRlZC4nfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XHJcbiAgICAgICAgICA8VGFibGU+XHJcbiAgICAgICAgICAgIDxUYWJsZUhlYWRlcj5cclxuICAgICAgICAgICAgICA8VGFibGVSb3c+XHJcbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGlzSGVhZGVyIGNsYXNzTmFtZT1cInctWzMwMHB4XVwiPlBhbmNoYXlhdDwvVGFibGVDZWxsPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5TdGF0dXM8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+VmlsbGFnZXM8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+U3R1ZGVudHM8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+Vm9sdW50ZWVyczwvVGFibGVDZWxsPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlciBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+QWN0aW9uczwvVGFibGVDZWxsPlxyXG4gICAgICAgICAgICAgIDwvVGFibGVSb3c+XHJcbiAgICAgICAgICAgIDwvVGFibGVIZWFkZXI+XHJcbiAgICAgICAgICAgIDxUYWJsZUJvZHk+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFRhYmxlUm93IGtleT17cC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MC84MCBkYXJrOmhvdmVyOmJnLXdoaXRlL1swLjAyXSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3RQYW5jaGF5YXQocC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3AudmlsbGFnZXMuc2xpY2UoMCwgMykubWFwKCh2KSA9PiB2Lm5hbWUpLmpvaW4oJywgJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cC52aWxsYWdlcy5sZW5ndGggPiAzICYmIGAgKyR7cC52aWxsYWdlcy5sZW5ndGggLSAzfSBtb3JlYH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0JhZGdlKHAuc3RhdHVzKX1cclxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7cC52aWxsYWdlc0NvdW50IHx8IHAudmlsbGFnZXMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLmFjdGl2ZVN0dWRlbnRzfVxyXG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLnZvbHVudGVlcnNDb3VudH1cclxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ3N0dWRlbnRzJywgcC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN0dWRlbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0UGFuY2hheWF0KHAuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1sZyBiZy1icmFuZC01MCBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1icmFuZC01MDAgaG92ZXI6YmctYnJhbmQtMTAwIGRhcms6YmctYnJhbmQtNTAwLzEwIGRhcms6dGV4dC1icmFuZC00MDAgZGFyazpob3ZlcjpiZy1icmFuZC01MDAvMjAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk9wZW48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1RhYmxlQm9keT5cclxuICAgICAgICAgIDwvVGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQWRkIFBhbmNoYXlhdCBNb2RhbCAqL31cclxuICAgICAge3Nob3dBZGQgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3cteS1hdXRvIGJnLWdyYXktOTAwLzc1IHAtNCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3ctdGhlbWUteGwgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBhbmltYXRlLWluIGZhZGUtaW4tMCB6b29tLWluLTk1XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICBBZGQgTmV3IFBhbmNoYXlhdFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6aG92ZXI6YmctZ3JheS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlfSBjbGFzc05hbWU9XCJtdC01IHNwYWNlLXktNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiIGh0bWxGb3I9XCJwYW4tbmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICBQYW5jaGF5YXQgTmFtZSAqXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwicGFuLW5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBWZWRha2thdHRhbWFkdXZ1XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiIGh0bWxGb3I9XCJwYW4tYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgQmxvY2tcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJwYW4tYmxvY2tcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmJsb2NrfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBibG9jazogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiIGh0bWxGb3I9XCJwYW4tc3RhdHVzXCI+XHJcbiAgICAgICAgICAgICAgICAgIE9wZXJhdGlvbmFsIFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsOiBhbnkpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBzdGF0dXM6IHZhbCB9KX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC0xMCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJPbiBUcmFja1wiPk9uIFRyYWNrPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQ29ycmVjdGlvbiBSZXF1aXJlZFwiPkNvcnJlY3Rpb24gUmVxdWlyZWQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJBY3Rpb24gTmVlZGVkXCI+QWN0aW9uIE5lZWRlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIiBodG1sRm9yPVwicGFuLXZpbGxhZ2VzXCI+XHJcbiAgICAgICAgICAgICAgICAgIEluaXRpYWwgVmlsbGFnZXMgKGNvbW1hIHNlcGFyYXRlZClcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJwYW4tdmlsbGFnZXNcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBBbW1hcGV0dGFpLCBQdWR1ciwgS290dGFpXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0udmlsbGFnZXN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHZpbGxhZ2VzOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMi41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBQYW5jaGF5YXRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9QYW5jaGF5YXRzVmlldy50c3gifQ==