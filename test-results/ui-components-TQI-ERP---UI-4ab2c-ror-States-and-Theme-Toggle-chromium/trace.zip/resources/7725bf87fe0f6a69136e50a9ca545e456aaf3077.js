import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ErrorBoundary.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.handleReset = () => {
      this.setState({ hasError: false, error: null });
      window.location.reload();
    };
    this.state = {
      hasError: false,
      error: null
    };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("Uncaught error in component tree:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-50 flex items-center justify-center p-6 font-sans", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-md w-full bg-white rounded-md border border-slate-200 p-6 shadow-sm text-center space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 mx-auto rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[30px]", children: "warning" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 40,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 39,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-extrabold text-slate-900", children: "Something went wrong" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 42,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-600 leading-relaxed", children: "An unexpected render issue occurred. You can safely reset the current view to continue working." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 43,
          columnNumber: 13
        }, this),
        this.state.error && /* @__PURE__ */ jsxDEV("div", { className: "text-left bg-slate-100 p-3 rounded-md text-[11px] font-mono text-slate-700 max-h-32 overflow-y-auto", children: this.state.error.message }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: this.handleReset,
            className: "w-full py-2.5 px-4 bg-[#002869] hover:bg-[#0b3d91] text-white text-xs font-bold rounded-md transition-all shadow-xs cursor-pointer",
            children: "Reset & Reload Application"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
            lineNumber: 51,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
        lineNumber: 38,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this);
    }
    return this.props.children;
  }
}
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNjO0FBdkNkLE9BQU9BLFdBQXFDO0FBV3JDLGFBQU1DLHNCQUFzQkQsTUFBTUUsVUFBd0I7QUFBQSxFQUMvREMsWUFBWUMsT0FBYztBQUN4QixVQUFNQSxLQUFLO0FBZWIsU0FBUUMsY0FBY0EsTUFBTTtBQUMxQixXQUFLQyxTQUFTLEVBQUVDLFVBQVUsT0FBT0MsT0FBTyxLQUFLLENBQUM7QUFDOUNDLGFBQU9DLFNBQVNDLE9BQU87QUFBQSxJQUN6QjtBQWpCRSxTQUFLQyxRQUFRO0FBQUEsTUFDWEwsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBLEVBRUEsT0FBY0sseUJBQXlCTCxPQUFxQjtBQUMxRCxXQUFPLEVBQUVELFVBQVUsTUFBTUMsTUFBTTtBQUFBLEVBQ2pDO0FBQUEsRUFFT00sa0JBQWtCTixPQUFjTyxXQUFzQjtBQUMzREMsWUFBUVIsTUFBTSxxQ0FBcUNBLE9BQU9PLFNBQVM7QUFBQSxFQUNyRTtBQUFBLEVBT09FLFNBQVM7QUFDZCxRQUFJLEtBQUtMLE1BQU1MLFVBQVU7QUFDdkIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsMkVBQ2IsaUNBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1IQUNiLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MsdUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0QsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUseUNBQXdDLG9DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsT0FBRSxXQUFVLDBDQUF5QywrR0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQyxLQUFLSyxNQUFNSixTQUNWLHVCQUFDLFNBQUksV0FBVSx1R0FDWixlQUFLSSxNQUFNSixNQUFNVSxXQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLEtBQUtiO0FBQUFBLFlBQ2QsV0FBVTtBQUFBLFlBQW9JO0FBQUE7QUFBQSxVQUZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLElBRUo7QUFFQSxXQUFPLEtBQUtELE1BQU1lO0FBQUFBLEVBQ3BCO0FBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIkVycm9yQm91bmRhcnkiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInByb3BzIiwiaGFuZGxlUmVzZXQiLCJzZXRTdGF0ZSIsImhhc0Vycm9yIiwiZXJyb3IiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInJlbG9hZCIsInN0YXRlIiwiZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yIiwiY29tcG9uZW50RGlkQ2F0Y2giLCJlcnJvckluZm8iLCJjb25zb2xlIiwicmVuZGVyIiwibWVzc2FnZSIsImNoaWxkcmVuIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVycm9yQm91bmRhcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBSZWFjdE5vZGUsIEVycm9ySW5mbyB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0YXRlIHtcclxuICBoYXNFcnJvcjogYm9vbGVhbjtcclxuICBlcnJvcjogRXJyb3IgfCBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgRXJyb3JCb3VuZGFyeSBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDxQcm9wcywgU3RhdGU+IHtcclxuICBjb25zdHJ1Y3Rvcihwcm9wczogUHJvcHMpIHtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIGhhc0Vycm9yOiBmYWxzZSxcclxuICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3I6IEVycm9yKTogU3RhdGUge1xyXG4gICAgcmV0dXJuIHsgaGFzRXJyb3I6IHRydWUsIGVycm9yIH07XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3I6IEVycm9yLCBlcnJvckluZm86IEVycm9ySW5mbykge1xyXG4gICAgY29uc29sZS5lcnJvcignVW5jYXVnaHQgZXJyb3IgaW4gY29tcG9uZW50IHRyZWU6JywgZXJyb3IsIGVycm9ySW5mbyk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xyXG4gICAgdGhpcy5zZXRTdGF0ZSh7IGhhc0Vycm9yOiBmYWxzZSwgZXJyb3I6IG51bGwgfSk7XHJcbiAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgfTtcclxuXHJcbiAgcHVibGljIHJlbmRlcigpIHtcclxuICAgIGlmICh0aGlzLnN0YXRlLmhhc0Vycm9yKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02IGZvbnQtc2Fuc1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCB3LWZ1bGwgYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTYgc2hhZG93LXNtIHRleHQtY2VudGVyIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCBteC1hdXRvIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTUwIGJvcmRlciBib3JkZXItcm9zZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1yb3NlLTYwMFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMzBweF1cIj53YXJuaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5Tb21ldGhpbmcgd2VudCB3cm9uZzwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgQW4gdW5leHBlY3RlZCByZW5kZXIgaXNzdWUgb2NjdXJyZWQuIFlvdSBjYW4gc2FmZWx5IHJlc2V0IHRoZSBjdXJyZW50IHZpZXcgdG8gY29udGludWUgd29ya2luZy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICB7dGhpcy5zdGF0ZS5lcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgYmctc2xhdGUtMTAwIHAtMyByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTcwMCBtYXgtaC0zMiBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIHt0aGlzLnN0YXRlLmVycm9yLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLmhhbmRsZVJlc2V0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCBiZy1bIzAwMjg2OV0gaG92ZXI6YmctWyMwYjNkOTFdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUmVzZXQgJmFtcDsgUmVsb2FkIEFwcGxpY2F0aW9uXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHRoaXMucHJvcHMuY2hpbGRyZW47XHJcbiAgfVxyXG59XHJcblxyXG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvRXJyb3JCb3VuZGFyeS50c3gifQ==