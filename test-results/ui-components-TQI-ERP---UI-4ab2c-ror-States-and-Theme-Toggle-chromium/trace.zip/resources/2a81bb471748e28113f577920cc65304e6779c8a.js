import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import {
  Search,
  Bell,
  ChevronDown,
  LogOut,
  User as UserIcon,
  SlidersHorizontal,
  Sparkles
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { ModeToggle } from "/src/components/mode-toggle.tsx";
import Badge from "/src/components/ui/badge.tsx";
export const Header = ({
  userEmail = "admin@tqierp.org",
  userName = "Admin User",
  userRole = "Super Admin",
  clusters = [],
  selectedClusterId = "all",
  onSelectCluster,
  notifications = [],
  pendingApprovalsCount = 0,
  onNavigate,
  onLogout,
  onRoleChange,
  onToggleSidebar
}) => {
  _s();
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showClusterMenu, setShowClusterMenu] = useState(false);
  const notifRef = useRef(null);
  const profileRef = useRef(null);
  const clusterRef = useRef(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notifRef.current && !notifRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setShowProfileMenu(false);
      }
      if (clusterRef.current && !clusterRef.current.contains(event.target)) {
        setShowClusterMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setShowSearchModal((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);
  const activeCluster = clusters.find((c) => c.id === selectedClusterId);
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const quickSearchItems = [
    { label: "Academic Setup (8-Day Cycle)", tab: "academic-setup", category: "Curriculum" },
    { label: "Attendance & Homework Logs", tab: "attendance", category: "Operations" },
    { label: "Students Roster", tab: "students", category: "Roster" },
    { label: "Volunteers Directory", tab: "volunteers", category: "Roster" },
    { label: "Finance & OCR Bill Verification", tab: "finance", category: "Finance" },
    { label: "Approval Center", tab: "approvals", category: "Governance" },
    { label: "Module Library & PPTs", tab: "module-library", category: "Curriculum" },
    { label: "Panchayats & Villages", tab: "panchayats", category: "Operations" }
  ];
  const filteredSearch = quickSearchItems.filter(
    (item) => item.label.toLowerCase().includes(searchQuery.toLowerCase()) || item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );
  return /* @__PURE__ */ jsxDEV("header", { className: "sticky top-0 z-30 flex w-full h-20 items-center justify-between border-b border-gray-200 bg-white/95 px-4 backdrop-blur-md dark:border-gray-800 dark:bg-gray-900/95 sm:px-6 lg:px-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 md:gap-4", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: onToggleSidebar,
        className: "flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white transition-colors",
        "aria-label": "Toggle navigation",
        children: /* @__PURE__ */ jsxDEV(SlidersHorizontal, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 110,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 sm:gap-3.5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative", ref: notifRef, children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowNotifications(!showNotifications),
            className: "relative flex h-10 w-10 items-center justify-center rounded-xl border border-gray-200 bg-white text-gray-600 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/5 transition-colors",
            "aria-label": "View notifications",
            children: [
              /* @__PURE__ */ jsxDEV(Bell, { className: "h-4.5 w-4.5" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                lineNumber: 131,
                columnNumber: 13
              }, this),
              (unreadCount > 0 || pendingApprovalsCount > 0) && /* @__PURE__ */ jsxDEV("span", { className: "absolute top-2 right-2 flex h-2.5 w-2.5 rounded-full bg-error-500 ring-2 ring-white dark:ring-gray-900" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                lineNumber: 133,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 125,
            columnNumber: 11
          },
          this
        ),
        showNotifications && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 mt-2 w-[22rem] rounded-2xl border border-gray-200 bg-white p-4 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 z-50 animate-in fade-in-0 zoom-in-95", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800 dark:text-white", children: "Notifications" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 140,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
              unreadCount + pendingApprovalsCount,
              " new"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 141,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 139,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 max-h-72 space-y-1.5 overflow-y-auto custom-scrollbar", children: [
            pendingApprovalsCount > 0 && /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => {
                  onNavigate("approvals");
                  setShowNotifications(false);
                },
                className: "flex cursor-pointer items-start gap-3 rounded-xl p-3 bg-warning-50/50 hover:bg-warning-50 text-sm transition-colors dark:bg-warning-500/10 dark:hover:bg-warning-500/20",
                children: [
                  /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-4 w-4 mt-0.5 text-warning-500 shrink-0" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                    lineNumber: 151,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-gray-800 dark:text-white", children: [
                      pendingApprovalsCount,
                      " Pending Approvals"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                      lineNumber: 153,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Attendance and finance entries require verification." }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                      lineNumber: 154,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                    lineNumber: 152,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                lineNumber: 147,
                columnNumber: 15
              },
              this
            ),
            notifications.slice(0, 4).map(
              (n) => /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "rounded-xl p-3 text-sm hover:bg-gray-50 dark:hover:bg-white/5 transition-colors cursor-pointer",
                  onClick: () => {
                    if (n.actionTab) onNavigate(n.actionTab, n.targetId);
                    setShowNotifications(false);
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-gray-800 dark:text-white/90", children: n.title }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                      lineNumber: 167,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: n.message }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                      lineNumber: 168,
                      columnNumber: 21
                    }, this)
                  ]
                },
                n.id,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 159,
                  columnNumber: 15
                },
                this
              )
            ),
            notifications.length === 0 && pendingApprovalsCount === 0 && /* @__PURE__ */ jsxDEV("div", { className: "py-6 text-center text-sm text-gray-500 dark:text-gray-400", children: "All caught up! No new notifications." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 172,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 145,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
          lineNumber: 138,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ModeToggle, {}, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 182,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative", ref: profileRef, children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowProfileMenu(!showProfileMenu),
            className: "flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5 transition-colors border border-gray-200 dark:border-gray-800",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-left leading-tight", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "max-w-[140px] truncate text-xs font-bold text-gray-800 dark:text-white/90", children: userName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 192,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-brand-500 dark:text-brand-400 uppercase tracking-wider", children: userRole }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 195,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                lineNumber: 191,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-3.5 w-3.5 text-gray-400 shrink-0" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                lineNumber: 199,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 186,
            columnNumber: 11
          },
          this
        ),
        showProfileMenu && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 mt-2 w-64 rounded-2xl border border-gray-200 bg-white p-2 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 z-50 animate-in fade-in-0 zoom-in-95", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-3 py-2.5 border-b border-gray-100 dark:border-gray-800 mb-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 dark:text-white", children: userName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 205,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 truncate", children: userEmail }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 206,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: userRole }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 208,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 207,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 204,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                onNavigate("settings");
                setShowProfileMenu(false);
              },
              className: "flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV(UserIcon, { className: "h-4 w-4 text-gray-400" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 218,
                  columnNumber: 17
                }, this),
                "Account Settings"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 213,
              columnNumber: 15
            },
            this
          ),
          onLogout && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                onLogout();
                setShowProfileMenu(false);
              },
              className: "flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium text-error-600 hover:bg-error-50 dark:text-error-400 dark:hover:bg-error-500/10 transition-colors mt-1",
              children: [
                /* @__PURE__ */ jsxDEV(LogOut, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 227,
                  columnNumber: 19
                }, this),
                "Sign Out"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 222,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
          lineNumber: 203,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    showSearchModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-99999 flex items-start justify-center bg-gray-900/60 pt-20 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-xl rounded-2xl border border-gray-200 bg-white p-0 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center border-b border-gray-100 dark:border-gray-800 px-4 py-3.5", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-5 w-5 text-gray-400 shrink-0 mr-3" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
          lineNumber: 241,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            autoFocus: true,
            placeholder: "Jump to views, rosters, records...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "flex-1 bg-transparent text-sm outline-none placeholder:text-gray-400 text-gray-800 dark:text-white"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 242,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowSearchModal(false),
            className: "rounded-md border border-gray-200 bg-gray-50 px-2 py-0.5 text-xs font-semibold text-gray-500 hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400",
            children: "ESC"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
            lineNumber: 250,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 240,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-h-80 overflow-y-auto p-2 custom-scrollbar", children: [
        filteredSearch.map(
          (item) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                onNavigate(item.tab);
                setShowSearchModal(false);
              },
              className: "flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/5 transition-colors text-left",
              children: [
                /* @__PURE__ */ jsxDEV("span", { children: item.label }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 269,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400 dark:text-gray-500", children: item.category }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
                  lineNumber: 270,
                  columnNumber: 19
                }, this)
              ]
            },
            item.tab,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
              lineNumber: 260,
              columnNumber: 13
            },
            this
          )
        ),
        filteredSearch.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "py-8 text-center text-sm text-gray-500 dark:text-gray-400", children: "No results found." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
          lineNumber: 276,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
        lineNumber: 258,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
      lineNumber: 239,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
      lineNumber: 238,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx",
    lineNumber: 107,
    columnNumber: 5
  }, this);
};
_s(Header, "5DUlzgpfWxWUZHwZB7iBHCBt4Y4=");
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Header.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhVOztBQW5IVixTQUFnQkEsVUFBVUMsUUFBUUMsaUJBQWlCO0FBQ25EO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFHQUMsUUFBUUM7QUFBQUEsRUFHUkM7QUFBQUEsRUFDQUM7QUFBQUEsT0FHSztBQUVQLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxXQUFXO0FBaUJYLGFBQU1DLFNBQWdDQSxDQUFDO0FBQUEsRUFDNUNDLFlBQVk7QUFBQSxFQUNaQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUFBLEVBQ1hDLFdBQVc7QUFBQSxFQUNYQyxvQkFBb0I7QUFBQSxFQUNwQkM7QUFBQUEsRUFDQUMsZ0JBQWdCO0FBQUEsRUFDaEJDLHdCQUF3QjtBQUFBLEVBQ3hCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTVCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM2QixhQUFhQyxjQUFjLElBQUk5QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK0IsbUJBQW1CQyxvQkFBb0IsSUFBSWhDLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUNpQyxpQkFBaUJDLGtCQUFrQixJQUFJbEMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ21DLGlCQUFpQkMsa0JBQWtCLElBQUlwQyxTQUFTLEtBQUs7QUFFNUQsUUFBTXFDLFdBQVdwQyxPQUF1QixJQUFJO0FBQzVDLFFBQU1xQyxhQUFhckMsT0FBdUIsSUFBSTtBQUM5QyxRQUFNc0MsYUFBYXRDLE9BQXVCLElBQUk7QUFFOUNDLFlBQVUsTUFBTTtBQUNkLFVBQU1zQyxxQkFBcUJBLENBQUNDLFVBQXNCO0FBQ2hELFVBQUlKLFNBQVNLLFdBQVcsQ0FBQ0wsU0FBU0ssUUFBUUMsU0FBU0YsTUFBTUcsTUFBYyxHQUFHO0FBQ3hFWiw2QkFBcUIsS0FBSztBQUFBLE1BQzVCO0FBQ0EsVUFBSU0sV0FBV0ksV0FBVyxDQUFDSixXQUFXSSxRQUFRQyxTQUFTRixNQUFNRyxNQUFjLEdBQUc7QUFDNUVWLDJCQUFtQixLQUFLO0FBQUEsTUFDMUI7QUFDQSxVQUFJSyxXQUFXRyxXQUFXLENBQUNILFdBQVdHLFFBQVFDLFNBQVNGLE1BQU1HLE1BQWMsR0FBRztBQUM1RVIsMkJBQW1CLEtBQUs7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFDQVMsYUFBU0MsaUJBQWlCLGFBQWFOLGtCQUFrQjtBQUN6RCxXQUFPLE1BQU1LLFNBQVNFLG9CQUFvQixhQUFhUCxrQkFBa0I7QUFBQSxFQUMzRSxHQUFHLEVBQUU7QUFFTHRDLFlBQVUsTUFBTTtBQUNkLFVBQU04QyxnQkFBZ0JBLENBQUNDLE1BQXFCO0FBQzFDLFdBQUtBLEVBQUVDLFdBQVdELEVBQUVFLFlBQVlGLEVBQUVHLFFBQVEsS0FBSztBQUM3Q0gsVUFBRUksZUFBZTtBQUNqQnpCLDJCQUFtQixDQUFDMEIsU0FBUyxDQUFDQSxJQUFJO0FBQUEsTUFDcEM7QUFBQSxJQUNGO0FBQ0FDLFdBQU9ULGlCQUFpQixXQUFXRSxhQUFhO0FBQ2hELFdBQU8sTUFBTU8sT0FBT1Isb0JBQW9CLFdBQVdDLGFBQWE7QUFBQSxFQUNsRSxHQUFHLEVBQUU7QUFFTCxRQUFNUSxnQkFBZ0J2QyxTQUFTd0MsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxPQUFPekMsaUJBQWlCO0FBQ3JFLFFBQU0wQyxjQUFjeEMsY0FBY3lDLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDQSxFQUFFQyxNQUFNLEVBQUVDO0FBRTNELFFBQU1DLG1CQUFtQjtBQUFBLElBQ3ZCLEVBQUVDLE9BQU8sZ0NBQWdDQyxLQUFLLGtCQUE2QkMsVUFBVSxhQUFhO0FBQUEsSUFDbEcsRUFBRUYsT0FBTyw4QkFBOEJDLEtBQUssY0FBeUJDLFVBQVUsYUFBYTtBQUFBLElBQzVGLEVBQUVGLE9BQU8sbUJBQW1CQyxLQUFLLFlBQXVCQyxVQUFVLFNBQVM7QUFBQSxJQUMzRSxFQUFFRixPQUFPLHdCQUF3QkMsS0FBSyxjQUF5QkMsVUFBVSxTQUFTO0FBQUEsSUFDbEYsRUFBRUYsT0FBTyxtQ0FBbUNDLEtBQUssV0FBc0JDLFVBQVUsVUFBVTtBQUFBLElBQzNGLEVBQUVGLE9BQU8sbUJBQW1CQyxLQUFLLGFBQXdCQyxVQUFVLGFBQWE7QUFBQSxJQUNoRixFQUFFRixPQUFPLHlCQUF5QkMsS0FBSyxrQkFBNkJDLFVBQVUsYUFBYTtBQUFBLElBQzNGLEVBQUVGLE9BQU8seUJBQXlCQyxLQUFLLGNBQXlCQyxVQUFVLGFBQWE7QUFBQSxFQUFDO0FBRzFGLFFBQU1DLGlCQUFpQkosaUJBQWlCSjtBQUFBQSxJQUFPLENBQUFTLFNBQzdDQSxLQUFLSixNQUFNSyxZQUFZLEVBQUVDLFNBQVMzQyxZQUFZMEMsWUFBWSxDQUFDLEtBQzNERCxLQUFLRixTQUFTRyxZQUFZLEVBQUVDLFNBQVMzQyxZQUFZMEMsWUFBWSxDQUFDO0FBQUEsRUFDaEU7QUFFQSxTQUNFLHVCQUFDLFlBQU8sV0FBVSx1TEFFaEI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQVM5QztBQUFBQSxRQUNULFdBQVU7QUFBQSxRQUNWLGNBQVc7QUFBQSxRQUVYLGlDQUFDLHFCQUFrQixXQUFVLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQTtBQUFBLE1BTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsc0NBR2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsWUFBVyxLQUFLWSxVQUM3QjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1MLHFCQUFxQixDQUFDRCxpQkFBaUI7QUFBQSxZQUN0RCxXQUFVO0FBQUEsWUFDVixjQUFXO0FBQUEsWUFFWDtBQUFBLHFDQUFDLFFBQUssV0FBVSxpQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxlQUMzQjZCLGNBQWMsS0FBS3ZDLHdCQUF3QixNQUMzQyx1QkFBQyxVQUFLLFdBQVUsNEdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdIO0FBQUE7QUFBQTtBQUFBLFVBUjVIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsUUFFQ1UscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDhLQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHVEQUFzRCw2QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCNkI7QUFBQUEsNEJBQWN2QztBQUFBQSxjQUFzQjtBQUFBLGlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsOERBQ1pBO0FBQUFBLG9DQUF3QixLQUN2QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUFFQyw2QkFBVyxXQUFXO0FBQUdVLHVDQUFxQixLQUFLO0FBQUEsZ0JBQUc7QUFBQSxnQkFDdkUsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBUyxXQUFVLDhDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RDtBQUFBLGtCQUM5RCx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsU0FBSSxXQUFVLCtDQUErQ1g7QUFBQUE7QUFBQUEsc0JBQXNCO0FBQUEseUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNHO0FBQUEsb0JBQ3RHLHVCQUFDLFNBQUksV0FBVSw0Q0FBMkMsb0VBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThHO0FBQUEsdUJBRmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQTtBQUFBO0FBQUEsY0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBRURELGNBQWNxRCxNQUFNLEdBQUcsQ0FBQyxFQUFFQztBQUFBQSxjQUFJLENBQUNaLE1BQzlCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU07QUFDYix3QkFBSUEsRUFBRWEsVUFBV3JELFlBQVd3QyxFQUFFYSxXQUFXYixFQUFFYyxRQUFRO0FBQ25ENUMseUNBQXFCLEtBQUs7QUFBQSxrQkFDNUI7QUFBQSxrQkFFQTtBQUFBLDJDQUFDLFNBQUksV0FBVSxnREFBZ0Q4QixZQUFFZSxTQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLG9CQUN2RSx1QkFBQyxTQUFJLFdBQVUsNENBQTRDZixZQUFFZ0IsV0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUU7QUFBQTtBQUFBO0FBQUEsZ0JBUmhFaEIsRUFBRUg7QUFBQUEsZ0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsWUFDRDtBQUFBLFlBQ0F2QyxjQUFjNEMsV0FBVyxLQUFLM0MsMEJBQTBCLEtBQ3ZELHVCQUFDLFNBQUksV0FBVSw2REFBMkQsb0RBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStCQTtBQUFBLGFBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxXQXJESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsTUFHQSx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUdYLHVCQUFDLFNBQUksV0FBVSxZQUFXLEtBQUtpQixZQUM3QjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1KLG1CQUFtQixDQUFDRCxlQUFlO0FBQUEsWUFDbEQsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkVBQ2JsQixzQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHlGQUNiQyxzQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsZUFBWSxXQUFVLHdDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBO0FBQUE7QUFBQSxVQWI3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLFFBRUNpQixtQkFDQyx1QkFBQyxTQUFJLFdBQVUseUtBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsdURBQXVEbEIsc0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsT0FBRSxXQUFVLHFEQUFxREQsdUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsWUFDNUUsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QkUsc0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFBRU0sMkJBQVcsVUFBVTtBQUFHWSxtQ0FBbUIsS0FBSztBQUFBLGNBQUc7QUFBQSxjQUNwRSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUw3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBQ0NYLFlBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUFFQSx5QkFBUztBQUFHVyxtQ0FBbUIsS0FBSztBQUFBLGNBQUc7QUFBQSxjQUN4RCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFdBOUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnREE7QUFBQSxTQWhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUhBO0FBQUEsSUFHQ1AsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLG1HQUNiLGlDQUFDLFNBQUksV0FBVSx5SkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBLCtCQUFDLFVBQU8sV0FBVSx5Q0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTDtBQUFBLFlBQ0EsYUFBWTtBQUFBLFlBQ1osT0FBT0U7QUFBQUEsWUFDUCxVQUFVLENBQUNvQixNQUFNbkIsZUFBZW1CLEVBQUVMLE9BQU9tQyxLQUFLO0FBQUEsWUFDOUMsV0FBVTtBQUFBO0FBQUEsVUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNZ0g7QUFBQSxRQUVoSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNbkQsbUJBQW1CLEtBQUs7QUFBQSxZQUN2QyxXQUFVO0FBQUEsWUFBeUs7QUFBQTtBQUFBLFVBSHJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNaeUM7QUFBQUEsdUJBQWVLO0FBQUFBLFVBQUksQ0FBQ0osU0FDbkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUNiaEQsMkJBQVdnRCxLQUFLSCxHQUFHO0FBQ25CdkMsbUNBQW1CLEtBQUs7QUFBQSxjQUMxQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFNMEMsZUFBS0osU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLGdCQUNsQix1QkFBQyxVQUFLLFdBQVUsNENBQ2JJLGVBQUtGLFlBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBO0FBQUE7QUFBQSxZQVhLRSxLQUFLSDtBQUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLFFBQ0Q7QUFBQSxRQUNBRSxlQUFlTCxXQUFXLEtBQ3pCLHVCQUFDLFNBQUksV0FBVSw2REFBMkQsaUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0Q0E7QUFBQSxPQS9LSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUxBO0FBRUo7QUFBRXRDLEdBMVBXYixRQUE2QjtBQUFBLEtBQTdCQTtBQUE2QixJQUFBbUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJTZWFyY2giLCJCZWxsIiwiQ2hldnJvbkRvd24iLCJMb2dPdXQiLCJVc2VyIiwiVXNlckljb24iLCJTbGlkZXJzSG9yaXpvbnRhbCIsIlNwYXJrbGVzIiwiTW9kZVRvZ2dsZSIsIkJhZGdlIiwiSGVhZGVyIiwidXNlckVtYWlsIiwidXNlck5hbWUiLCJ1c2VyUm9sZSIsImNsdXN0ZXJzIiwic2VsZWN0ZWRDbHVzdGVySWQiLCJvblNlbGVjdENsdXN0ZXIiLCJub3RpZmljYXRpb25zIiwicGVuZGluZ0FwcHJvdmFsc0NvdW50Iiwib25OYXZpZ2F0ZSIsIm9uTG9nb3V0Iiwib25Sb2xlQ2hhbmdlIiwib25Ub2dnbGVTaWRlYmFyIiwiX3MiLCJzaG93U2VhcmNoTW9kYWwiLCJzZXRTaG93U2VhcmNoTW9kYWwiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5Iiwic2hvd05vdGlmaWNhdGlvbnMiLCJzZXRTaG93Tm90aWZpY2F0aW9ucyIsInNob3dQcm9maWxlTWVudSIsInNldFNob3dQcm9maWxlTWVudSIsInNob3dDbHVzdGVyTWVudSIsInNldFNob3dDbHVzdGVyTWVudSIsIm5vdGlmUmVmIiwicHJvZmlsZVJlZiIsImNsdXN0ZXJSZWYiLCJoYW5kbGVDbGlja091dHNpZGUiLCJldmVudCIsImN1cnJlbnQiLCJjb250YWlucyIsInRhcmdldCIsImRvY3VtZW50IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJoYW5kbGVLZXlEb3duIiwiZSIsIm1ldGFLZXkiLCJjdHJsS2V5Iiwia2V5IiwicHJldmVudERlZmF1bHQiLCJwcmV2Iiwid2luZG93IiwiYWN0aXZlQ2x1c3RlciIsImZpbmQiLCJjIiwiaWQiLCJ1bnJlYWRDb3VudCIsImZpbHRlciIsIm4iLCJpc1JlYWQiLCJsZW5ndGgiLCJxdWlja1NlYXJjaEl0ZW1zIiwibGFiZWwiLCJ0YWIiLCJjYXRlZ29yeSIsImZpbHRlcmVkU2VhcmNoIiwiaXRlbSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJzbGljZSIsIm1hcCIsImFjdGlvblRhYiIsInRhcmdldElkIiwidGl0bGUiLCJtZXNzYWdlIiwidmFsdWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU2VhcmNoLCBcbiAgQmVsbCwgXG4gIENoZXZyb25Eb3duLCBcbiAgTG9nT3V0LCBcbiAgTWFwUGluLCBcbiAgU2hpZWxkLCBcbiAgVXNlciBhcyBVc2VySWNvbiwgXG4gIENoZWNrLCBcbiAgQ29tbWFuZCxcbiAgU2xpZGVyc0hvcml6b250YWwsXG4gIFNwYXJrbGVzLFxuICBTdW4sXG4gIE1vb25cbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IENsdXN0ZXIsIE5vdGlmaWNhdGlvbkl0ZW0sIFVzZXJSb2xlLCBUYWJUeXBlIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgTW9kZVRvZ2dsZSB9IGZyb20gJy4vbW9kZS10b2dnbGUnO1xuaW1wb3J0IEJhZGdlIGZyb20gJy4vdWkvYmFkZ2UnO1xuXG5pbnRlcmZhY2UgSGVhZGVyUHJvcHMge1xuICB1c2VyRW1haWw/OiBzdHJpbmc7XG4gIHVzZXJOYW1lPzogc3RyaW5nO1xuICB1c2VyUm9sZT86IFVzZXJSb2xlO1xuICBjbHVzdGVyczogQ2x1c3RlcltdO1xuICBzZWxlY3RlZENsdXN0ZXJJZDogc3RyaW5nO1xuICBvblNlbGVjdENsdXN0ZXI6IChjbHVzdGVySWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgbm90aWZpY2F0aW9uczogTm90aWZpY2F0aW9uSXRlbVtdO1xuICBwZW5kaW5nQXBwcm92YWxzQ291bnQ/OiBudW1iZXI7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkxvZ291dD86ICgpID0+IHZvaWQ7XG4gIG9uUm9sZUNoYW5nZT86IChyb2xlOiBVc2VyUm9sZSkgPT4gdm9pZDtcbiAgb25Ub2dnbGVTaWRlYmFyPzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEhlYWRlcjogUmVhY3QuRkM8SGVhZGVyUHJvcHM+ID0gKHtcbiAgdXNlckVtYWlsID0gJ2FkbWluQHRxaWVycC5vcmcnLFxuICB1c2VyTmFtZSA9ICdBZG1pbiBVc2VyJyxcbiAgdXNlclJvbGUgPSAnU3VwZXIgQWRtaW4nLFxuICBjbHVzdGVycyA9IFtdLFxuICBzZWxlY3RlZENsdXN0ZXJJZCA9ICdhbGwnLFxuICBvblNlbGVjdENsdXN0ZXIsXG4gIG5vdGlmaWNhdGlvbnMgPSBbXSxcbiAgcGVuZGluZ0FwcHJvdmFsc0NvdW50ID0gMCxcbiAgb25OYXZpZ2F0ZSxcbiAgb25Mb2dvdXQsXG4gIG9uUm9sZUNoYW5nZSxcbiAgb25Ub2dnbGVTaWRlYmFyLFxufSkgPT4ge1xuICBjb25zdCBbc2hvd1NlYXJjaE1vZGFsLCBzZXRTaG93U2VhcmNoTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Nob3dOb3RpZmljYXRpb25zLCBzZXRTaG93Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93UHJvZmlsZU1lbnUsIHNldFNob3dQcm9maWxlTWVudV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93Q2x1c3Rlck1lbnUsIHNldFNob3dDbHVzdGVyTWVudV0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3Qgbm90aWZSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBwcm9maWxlUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgY2x1c3RlclJlZiA9IHVzZVJlZjxIVE1MRGl2RWxlbWVudD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVDbGlja091dHNpZGUgPSAoZXZlbnQ6IE1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGlmIChub3RpZlJlZi5jdXJyZW50ICYmICFub3RpZlJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCBhcyBOb2RlKSkge1xuICAgICAgICBzZXRTaG93Tm90aWZpY2F0aW9ucyhmYWxzZSk7XG4gICAgICB9XG4gICAgICBpZiAocHJvZmlsZVJlZi5jdXJyZW50ICYmICFwcm9maWxlUmVmLmN1cnJlbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0IGFzIE5vZGUpKSB7XG4gICAgICAgIHNldFNob3dQcm9maWxlTWVudShmYWxzZSk7XG4gICAgICB9XG4gICAgICBpZiAoY2x1c3RlclJlZi5jdXJyZW50ICYmICFjbHVzdGVyUmVmLmN1cnJlbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0IGFzIE5vZGUpKSB7XG4gICAgICAgIHNldFNob3dDbHVzdGVyTWVudShmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBoYW5kbGVDbGlja091dHNpZGUpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVLZXlEb3duID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmICgoZS5tZXRhS2V5IHx8IGUuY3RybEtleSkgJiYgZS5rZXkgPT09ICdrJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldFNob3dTZWFyY2hNb2RhbCgocHJldikgPT4gIXByZXYpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGFjdGl2ZUNsdXN0ZXIgPSBjbHVzdGVycy5maW5kKChjKSA9PiBjLmlkID09PSBzZWxlY3RlZENsdXN0ZXJJZCk7XG4gIGNvbnN0IHVucmVhZENvdW50ID0gbm90aWZpY2F0aW9ucy5maWx0ZXIoKG4pID0+ICFuLmlzUmVhZCkubGVuZ3RoO1xuXG4gIGNvbnN0IHF1aWNrU2VhcmNoSXRlbXMgPSBbXG4gICAgeyBsYWJlbDogJ0FjYWRlbWljIFNldHVwICg4LURheSBDeWNsZSknLCB0YWI6ICdhY2FkZW1pYy1zZXR1cCcgYXMgVGFiVHlwZSwgY2F0ZWdvcnk6ICdDdXJyaWN1bHVtJyB9LFxuICAgIHsgbGFiZWw6ICdBdHRlbmRhbmNlICYgSG9tZXdvcmsgTG9ncycsIHRhYjogJ2F0dGVuZGFuY2UnIGFzIFRhYlR5cGUsIGNhdGVnb3J5OiAnT3BlcmF0aW9ucycgfSxcbiAgICB7IGxhYmVsOiAnU3R1ZGVudHMgUm9zdGVyJywgdGFiOiAnc3R1ZGVudHMnIGFzIFRhYlR5cGUsIGNhdGVnb3J5OiAnUm9zdGVyJyB9LFxuICAgIHsgbGFiZWw6ICdWb2x1bnRlZXJzIERpcmVjdG9yeScsIHRhYjogJ3ZvbHVudGVlcnMnIGFzIFRhYlR5cGUsIGNhdGVnb3J5OiAnUm9zdGVyJyB9LFxuICAgIHsgbGFiZWw6ICdGaW5hbmNlICYgT0NSIEJpbGwgVmVyaWZpY2F0aW9uJywgdGFiOiAnZmluYW5jZScgYXMgVGFiVHlwZSwgY2F0ZWdvcnk6ICdGaW5hbmNlJyB9LFxuICAgIHsgbGFiZWw6ICdBcHByb3ZhbCBDZW50ZXInLCB0YWI6ICdhcHByb3ZhbHMnIGFzIFRhYlR5cGUsIGNhdGVnb3J5OiAnR292ZXJuYW5jZScgfSxcbiAgICB7IGxhYmVsOiAnTW9kdWxlIExpYnJhcnkgJiBQUFRzJywgdGFiOiAnbW9kdWxlLWxpYnJhcnknIGFzIFRhYlR5cGUsIGNhdGVnb3J5OiAnQ3VycmljdWx1bScgfSxcbiAgICB7IGxhYmVsOiAnUGFuY2hheWF0cyAmIFZpbGxhZ2VzJywgdGFiOiAncGFuY2hheWF0cycgYXMgVGFiVHlwZSwgY2F0ZWdvcnk6ICdPcGVyYXRpb25zJyB9LFxuICBdO1xuXG4gIGNvbnN0IGZpbHRlcmVkU2VhcmNoID0gcXVpY2tTZWFyY2hJdGVtcy5maWx0ZXIoaXRlbSA9PiBcbiAgICBpdGVtLmxhYmVsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICBpdGVtLmNhdGVnb3J5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSlcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIHotMzAgZmxleCB3LWZ1bGwgaC0yMCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZS85NSBweC00IGJhY2tkcm9wLWJsdXItbWQgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMC85NSBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgIHsvKiBMZWZ0OiBNb2JpbGUgVG9nZ2xlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtZDpnYXAtNFwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25Ub2dnbGVTaWRlYmFyfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgYXJpYS1sYWJlbD1cIlRvZ2dsZSBuYXZpZ2F0aW9uXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxTbGlkZXJzSG9yaXpvbnRhbCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJpZ2h0IENvbnRyb2xzOiBCZWxsLCBNb2RlLCBQcm9maWxlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzbTpnYXAtMy41XCI+XG5cbiAgICAgICAgey8qIE5vdGlmaWNhdGlvbnMgRHJvcGRvd24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIiByZWY9e25vdGlmUmVmfT5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dOb3RpZmljYXRpb25zKCFzaG93Tm90aWZpY2F0aW9ucyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS02MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJWaWV3IG5vdGlmaWNhdGlvbnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cImgtNC41IHctNC41XCIgLz5cbiAgICAgICAgICAgIHsodW5yZWFkQ291bnQgPiAwIHx8IHBlbmRpbmdBcHByb3ZhbHNDb3VudCA+IDApICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMiBmbGV4IGgtMi41IHctMi41IHJvdW5kZWQtZnVsbCBiZy1lcnJvci01MDAgcmluZy0yIHJpbmctd2hpdGUgZGFyazpyaW5nLWdyYXktOTAwXCIgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7c2hvd05vdGlmaWNhdGlvbnMgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0wIG10LTIgdy1bMjJyZW1dIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC00IHNoYWRvdy10aGVtZS14bCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIHotNTAgYW5pbWF0ZS1pbiBmYWRlLWluLTAgem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPk5vdGlmaWNhdGlvbnM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwicHJpbWFyeVwiIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICAgICAge3VucmVhZENvdW50ICsgcGVuZGluZ0FwcHJvdmFsc0NvdW50fSBuZXdcbiAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIG1heC1oLTcyIHNwYWNlLXktMS41IG92ZXJmbG93LXktYXV0byBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHNDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IG9uTmF2aWdhdGUoJ2FwcHJvdmFscycpOyBzZXRTaG93Tm90aWZpY2F0aW9ucyhmYWxzZSk7IH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggY3Vyc29yLXBvaW50ZXIgaXRlbXMtc3RhcnQgZ2FwLTMgcm91bmRlZC14bCBwLTMgYmctd2FybmluZy01MC81MCBob3ZlcjpiZy13YXJuaW5nLTUwIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnMgZGFyazpiZy13YXJuaW5nLTUwMC8xMCBkYXJrOmhvdmVyOmJnLXdhcm5pbmctNTAwLzIwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cImgtNCB3LTQgbXQtMC41IHRleHQtd2FybmluZy01MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPntwZW5kaW5nQXBwcm92YWxzQ291bnR9IFBlbmRpbmcgQXBwcm92YWxzPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+QXR0ZW5kYW5jZSBhbmQgZmluYW5jZSBlbnRyaWVzIHJlcXVpcmUgdmVyaWZpY2F0aW9uLjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge25vdGlmaWNhdGlvbnMuc2xpY2UoMCwgNCkubWFwKChuKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17bi5pZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBwLTMgdGV4dC1zbSBob3ZlcjpiZy1ncmF5LTUwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobi5hY3Rpb25UYWIpIG9uTmF2aWdhdGUobi5hY3Rpb25UYWIsIG4udGFyZ2V0SWQpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dOb3RpZmljYXRpb25zKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZS85MFwiPntuLnRpdGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57bi5tZXNzYWdlfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAge25vdGlmaWNhdGlvbnMubGVuZ3RoID09PSAwICYmIHBlbmRpbmdBcHByb3ZhbHNDb3VudCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBBbGwgY2F1Z2h0IHVwISBObyBuZXcgbm90aWZpY2F0aW9ucy5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRoZW1lIE1vZGUgVG9nZ2xlIChMaWdodCAvIERhcmspICovfVxuICAgICAgICA8TW9kZVRvZ2dsZSAvPlxuXG4gICAgICAgIHsvKiBVc2VyIFByb2ZpbGUgTWVudSAoQ2xlYW4gV2l0aG91dCBBRCBpbml0aWFscykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIiByZWY9e3Byb2ZpbGVSZWZ9PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Byb2ZpbGVNZW51KCFzaG93UHJvZmlsZU1lbnUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbi1jb2xvcnMgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHRleHQtbGVmdCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1heC13LVsxNDBweF0gdHJ1bmNhdGUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgICAgICB7dXNlck5hbWV9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtYnJhbmQtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIHt1c2VyUm9sZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1ncmF5LTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7c2hvd1Byb2ZpbGVNZW51ICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMCBtdC0yIHctNjQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTIgc2hhZG93LXRoZW1lLXhsIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgei01MCBhbmltYXRlLWluIGZhZGUtaW4tMCB6b29tLWluLTk1XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtMyBweS0yLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57dXNlck5hbWV9PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdHJ1bmNhdGVcIj57dXNlckVtYWlsfTwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cInByaW1hcnlcIiBzaXplPVwic21cIj5cbiAgICAgICAgICAgICAgICAgICAge3VzZXJSb2xlfVxuICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IG9uTmF2aWdhdGUoJ3NldHRpbmdzJyk7IHNldFNob3dQcm9maWxlTWVudShmYWxzZSk7IH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0yLjUgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFVzZXJJY29uIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgQWNjb3VudCBTZXR0aW5nc1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAge29uTG9nb3V0ICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgb25Mb2dvdXQoKTsgc2V0U2hvd1Byb2ZpbGVNZW51KGZhbHNlKTsgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtMi41IHJvdW5kZWQtbGcgcHgtMyBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1lcnJvci02MDAgaG92ZXI6YmctZXJyb3ItNTAgZGFyazp0ZXh0LWVycm9yLTQwMCBkYXJrOmhvdmVyOmJnLWVycm9yLTUwMC8xMCB0cmFuc2l0aW9uLWNvbG9ycyBtdC0xXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgU2lnbiBPdXRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBHbG9iYWwgQ29tbWFuZCBTZWFyY2ggTW9kYWwgKi99XG4gICAgICB7c2hvd1NlYXJjaE1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotOTk5OTkgZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWNlbnRlciBiZy1ncmF5LTkwMC82MCBwdC0yMCBwLTQgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhsIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC0wIHNoYWRvdy10aGVtZS14bCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHB4LTQgcHktMy41XCI+XG4gICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWdyYXktNDAwIHNocmluay0wIG1yLTNcIiAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJKdW1wIHRvIHZpZXdzLCByb3N0ZXJzLCByZWNvcmRzLi4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXRyYW5zcGFyZW50IHRleHQtc20gb3V0bGluZS1ub25lIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1NlYXJjaE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MCBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBFU0NcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtODAgb3ZlcmZsb3cteS1hdXRvIHAtMiBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFNlYXJjaC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0udGFifVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGUoaXRlbS50YWIpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2VhcmNoTW9kYWwoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC14bCBweC0zLjUgcHktMi41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IHRyYW5zaXRpb24tY29sb3JzIHRleHQtbGVmdFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5jYXRlZ29yeX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFNlYXJjaC5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICBObyByZXN1bHRzIGZvdW5kLlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2hlYWRlcj5cbiAgKTtcbn07XG5cbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9IZWFkZXIudHN4In0=