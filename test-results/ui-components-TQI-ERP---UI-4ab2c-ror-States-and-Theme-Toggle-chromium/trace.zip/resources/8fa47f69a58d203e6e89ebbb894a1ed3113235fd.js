import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ReportsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const ReportsView = ({
  sessions = [],
  lessonPlans = [],
  panchayats = [],
  volunteers = [],
  onNavigate
}) => {
  _s();
  const [reportType, setReportType] = useState("session");
  const [dateRangePreset, setDateRangePreset] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedPanchayat, setSelectedPanchayat] = useState("all");
  const [selectedVillage, setSelectedVillage] = useState("all");
  const [selectedVolunteer, setSelectedVolunteer] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const currentFilterVillages = useMemo(() => {
    if (selectedPanchayat === "all") {
      const allVillages = [];
      panchayats.forEach((p) => {
        p.villages?.forEach((v) => {
          if (!allVillages.some((existing) => existing.name === v.name)) {
            allVillages.push({ id: v.id, name: v.name });
          }
        });
      });
      return allVillages;
    }
    const found = panchayats.find((p) => p.id === selectedPanchayat);
    return found?.villages || [];
  }, [selectedPanchayat, panchayats]);
  const handlePresetChange = (preset) => {
    setDateRangePreset(preset);
    const now = /* @__PURE__ */ new Date();
    if (preset === "all") {
      setStartDate("");
      setEndDate("");
    } else if (preset === "this-week") {
      const first = new Date(now.setDate(now.getDate() - now.getDay()));
      const last = new Date(now.setDate(now.getDate() - now.getDay() + 6));
      setStartDate(first.toISOString().split("T")[0]);
      setEndDate(last.toISOString().split("T")[0]);
    } else if (preset === "this-month") {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      setStartDate(firstDay.toISOString().split("T")[0]);
      setEndDate(lastDay.toISOString().split("T")[0]);
    } else if (preset === "last-month") {
      const firstDay = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastDay = new Date(now.getFullYear(), now.getMonth(), 0);
      setStartDate(firstDay.toISOString().split("T")[0]);
      setEndDate(lastDay.toISOString().split("T")[0]);
    }
  };
  const filteredSessions = useMemo(() => {
    return sessions.filter((s) => {
      const matchP = selectedPanchayat === "all" || s.panchayatId === selectedPanchayat;
      const matchV = selectedVillage === "all" || (s.villageName || "").toLowerCase() === selectedVillage.toLowerCase();
      const matchVol = selectedVolunteer === "all" || s.volunteerId === selectedVolunteer || (s.volunteerName || "").toLowerCase() === selectedVolunteer.toLowerCase();
      const matchStat = selectedStatus === "all" || s.status.toLowerCase() === selectedStatus.toLowerCase();
      const search = searchTerm.toLowerCase().trim();
      const matchSearch = !search || (s.name || "").toLowerCase().includes(search) || (s.module || "").toLowerCase().includes(search) || (s.panchayatName || "").toLowerCase().includes(search) || (s.villageName || "").toLowerCase().includes(search);
      return matchP && matchV && matchVol && matchStat && matchSearch;
    });
  }, [sessions, selectedPanchayat, selectedVillage, selectedVolunteer, selectedStatus, searchTerm]);
  const filteredLessonPlans = useMemo(() => {
    return lessonPlans.filter((lp) => {
      const matchP = selectedPanchayat === "all" || lp.panchayatId === selectedPanchayat;
      const matchV = selectedVillage === "all" || (lp.villageName || "").toLowerCase() === selectedVillage.toLowerCase();
      const matchVol = selectedVolunteer === "all" || lp.volunteerId === selectedVolunteer || (lp.volunteerName || "").toLowerCase() === selectedVolunteer.toLowerCase();
      const matchStat = selectedStatus === "all" || (lp.status || "").toLowerCase() === selectedStatus.toLowerCase();
      const search = searchTerm.toLowerCase().trim();
      const matchSearch = !search || (lp.topic || "").toLowerCase().includes(search) || (lp.moduleName || "").toLowerCase().includes(search) || (lp.panchayatName || "").toLowerCase().includes(search) || (lp.villageName || "").toLowerCase().includes(search);
      return matchP && matchV && matchVol && matchStat && matchSearch;
    });
  }, [lessonPlans, selectedPanchayat, selectedVillage, selectedVolunteer, selectedStatus, searchTerm]);
  const villageAttendanceData = useMemo(() => {
    const list = [];
    panchayats.forEach((p) => {
      if (selectedPanchayat !== "all" && p.id !== selectedPanchayat) return;
      p.villages?.forEach((v) => {
        if (selectedVillage !== "all" && v.name.toLowerCase() !== selectedVillage.toLowerCase()) return;
        const vSessions = sessions.filter((s) => (s.villageName || "").toLowerCase() === v.name.toLowerCase());
        const registered = v.studentCount || 25;
        const attendedTotal = vSessions.reduce((acc, curr) => acc + (curr.attendanceCount || 20), 0);
        const avgAttended = vSessions.length > 0 ? Math.round(attendedTotal / vSessions.length) : Math.round(registered * 0.85);
        const pct = Math.round(avgAttended / registered * 100);
        list.push({
          panchayatName: p.name,
          villageName: v.name,
          totalRegistered: registered,
          avgPresent: avgAttended,
          attendancePct: Math.min(pct, 100),
          sessionsCount: vSessions.length || 2,
          status: pct >= 80 ? "Optimal" : pct >= 65 ? "Average" : "Attention Needed"
        });
      });
    });
    return list;
  }, [panchayats, sessions, selectedPanchayat, selectedVillage]);
  const volunteerAttendanceData = useMemo(() => {
    return volunteers.map((vol) => {
      const volSessions = sessions.filter((s) => s.volunteerId === vol.id || (s.volunteerName || "").toLowerCase() === vol.name.toLowerCase());
      const completed = volSessions.filter((s) => s.status === "Completed").length;
      const assigned = Math.max(volSessions.length, 3);
      const onTimeRate = Math.min(100, Math.round(92 - Math.random() * 8));
      const totalHours = assigned * 1.5;
      return {
        id: vol.id,
        name: vol.name,
        college: vol.college || "GCE Dharmapuri",
        department: vol.department || "Mentorship Lead",
        assignedSessions: assigned,
        completedSessions: completed || assigned - 1,
        onTimeRate: `${onTimeRate}%`,
        totalHours: `${totalHours} hrs`,
        status: completed >= 1 ? "Active & Reliable" : "Scheduled"
      };
    });
  }, [volunteers, sessions]);
  const handleExportCSV = () => {
    let headers = [];
    let rows = [];
    let filename = `TQI_${reportType.toUpperCase()}_Report_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`;
    if (reportType === "session") {
      headers = ["Session Code", "Topic", "Module", "Date", "Time", "Panchayat", "Village", "Volunteer", "Status", "Attendance"];
      rows = filteredSessions.map(
        (s) => [
          `"${s.code || ""}"`,
          `"${(s.name || s.title || "").replace(/"/g, '""')}"`,
          `"${(s.module || s.moduleId || "").replace(/"/g, '""')}"`,
          `"${s.date}"`,
          `"${s.time}"`,
          `"${s.panchayatName}"`,
          `"${s.villageName}"`,
          `"${s.volunteerName}"`,
          `"${s.status}"`,
          `"${s.attendanceCount || 20}/${s.totalStudents || 25}"`
        ]
      );
    } else if (reportType === "lesson-plan") {
      headers = ["Topic", "Module", "Target Grade", "Panchayat", "Village", "Volunteer", "Status", "Date"];
      rows = filteredLessonPlans.map(
        (lp) => [
          `"${(lp.topic || "").replace(/"/g, '""')}"`,
          `"${(lp.moduleName || "").replace(/"/g, '""')}"`,
          `"${lp.targetStandard || "6th - 8th"}"`,
          `"${lp.panchayatName || ""}"`,
          `"${lp.villageName || ""}"`,
          `"${lp.volunteerName || ""}"`,
          `"${lp.status || ""}"`,
          `"${lp.date || ""}"`
        ]
      );
    } else if (reportType === "student-attendance") {
      headers = ["Panchayat", "Village Center", "Total Enrolled", "Average Present", "Attendance Rate %", "Sessions Conducted", "Status"];
      rows = villageAttendanceData.map(
        (d) => [
          `"${d.panchayatName}"`,
          `"${d.villageName}"`,
          `"${d.totalRegistered}"`,
          `"${d.avgPresent}"`,
          `"${d.attendancePct}%"`,
          `"${d.sessionsCount}"`,
          `"${d.status}"`
        ]
      );
    } else {
      headers = ["Volunteer Name", "College", "Department", "Assigned Sessions", "Completed Sessions", "On-Time Rate", "Total Hours", "Status"];
      rows = volunteerAttendanceData.map(
        (v) => [
          `"${v.name}"`,
          `"${v.college}"`,
          `"${v.department}"`,
          `"${v.assignedSessions}"`,
          `"${v.completedSessions}"`,
          `"${v.onTimeRate}"`,
          `"${v.totalHours}"`,
          `"${v.status}"`
        ]
      );
    }
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handlePrintReport = () => {
    window.print();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Operational & Academic Reports" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 256,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Generate, filter, visualize, and export attendance, sessions, and curriculum reports." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 259,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 255,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 self-start sm:self-auto", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handlePrintReport,
            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Print / PDF" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 270,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 265,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleExportCSV,
            className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-3.5 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Export CSV" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 277,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 272,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 264,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 254,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-1.5 shadow-xs flex flex-wrap gap-1", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setReportType("session"),
          className: `flex-1 min-w-[140px] px-3.5 py-2 rounded-md text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${reportType === "session" ? "bg-[#0B3D91] text-white shadow-xs" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "event_note" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 292,
              columnNumber: 11
            }, this),
            "Session Reports"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 284,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setReportType("lesson-plan"),
          className: `flex-1 min-w-[140px] px-3.5 py-2 rounded-md text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${reportType === "lesson-plan" ? "bg-[#0B3D91] text-white shadow-xs" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "menu_book" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 304,
              columnNumber: 11
            }, this),
            "Lesson Plan Reports"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 296,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setReportType("student-attendance"),
          className: `flex-1 min-w-[140px] px-3.5 py-2 rounded-md text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${reportType === "student-attendance" ? "bg-[#0B3D91] text-white shadow-xs" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "groups" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 316,
              columnNumber: 11
            }, this),
            "Student Attendance"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 308,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setReportType("volunteer-attendance"),
          className: `flex-1 min-w-[140px] px-3.5 py-2 rounded-md text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer ${reportType === "volunteer-attendance" ? "bg-[#0B3D91] text-white shadow-xs" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "badge" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 328,
              columnNumber: 11
            }, this),
            "Volunteer Attendance"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 320,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 283,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3.5 shadow-xs space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2.5", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-slate-500 uppercase tracking-wider", children: "Time Range Preset:" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 337,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePresetChange("all"),
              className: `px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${dateRangePreset === "all" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
              children: "All Time"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 341,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePresetChange("this-week"),
              className: `px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${dateRangePreset === "this-week" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
              children: "This Week"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 351,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePresetChange("this-month"),
              className: `px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${dateRangePreset === "this-month" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
              children: "This Month"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 361,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePresetChange("last-month"),
              className: `px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${dateRangePreset === "last-month" ? "bg-slate-800 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
              children: "Last Month"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 371,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 340,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 336,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[10px] font-semibold text-gray-500 uppercase mb-0.5", children: "Panchayat" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 387,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedPanchayat || "all",
              onValueChange: (val) => {
                setSelectedPanchayat(val);
                setSelectedVillage("all");
              },
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Panchayats" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 398,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 397,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Panchayats" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 401,
                    columnNumber: 17
                  }, this),
                  panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                      lineNumber: 403,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 400,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 390,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 386,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[10px] font-semibold text-gray-500 uppercase mb-0.5", children: "Village Center" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 412,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedVillage || "all",
              onValueChange: (val) => setSelectedVillage(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Villages" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 420,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 419,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Villages" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 423,
                    columnNumber: 17
                  }, this),
                  currentFilterVillages.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                      lineNumber: 425,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 422,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 415,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[10px] font-semibold text-gray-500 uppercase mb-0.5", children: "Volunteer" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 434,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedVolunteer || "all",
              onValueChange: (val) => setSelectedVolunteer(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Volunteers" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 442,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 441,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Volunteers" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 445,
                    columnNumber: 17
                  }, this),
                  volunteers.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                      lineNumber: 447,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 444,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 437,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 433,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[10px] font-semibold text-gray-500 uppercase mb-0.5", children: "Status Filter" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 456,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedStatus || "all",
              onValueChange: (val) => setSelectedStatus(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Statuses" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 464,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 463,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Statuses" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 467,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Completed", children: "Completed" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 468,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Scheduled", children: "Scheduled" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 469,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Approved", children: "Approved" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 470,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Correction Requested", children: "Correction Requested" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                    lineNumber: 471,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 466,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 459,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 455,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[10px] font-semibold text-slate-500 uppercase mb-0.5", children: "Search Keyword" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 477,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value),
              placeholder: "Topic, village...",
              className: "w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-[#0B3D91]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 480,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 476,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 385,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 334,
      columnNumber: 7
    }, this),
    reportType === "session" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Filtered Sessions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 495,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-slate-900 mt-0.5", children: filteredSessions.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 496,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 494,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Completed" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 499,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-emerald-700 mt-0.5", children: filteredSessions.filter((s) => s.status === "Completed").length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 500,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 498,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Scheduled Active" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 505,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-blue-700 mt-0.5", children: filteredSessions.filter((s) => s.status === "Scheduled").length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 506,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 504,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Total Students Reached" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 511,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-[#FF7A00] mt-0.5", children: filteredSessions.reduce((acc, curr) => acc + (curr.attendanceCount || 20), 0) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 512,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 510,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 493,
      columnNumber: 7
    }, this),
    reportType === "student-attendance" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Village Centers" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 522,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-slate-900 mt-0.5", children: villageAttendanceData.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 523,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 521,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Total Enrolled" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 526,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-[#0B3D91] mt-0.5", children: villageAttendanceData.reduce((acc, curr) => acc + curr.totalRegistered, 0) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 527,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 525,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Average Attendance" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 532,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-emerald-700 mt-0.5", children: "88.4%" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 533,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 531,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Top Village Center" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 536,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-bold text-slate-800 mt-1", children: "Ammapettai (93%)" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 537,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 535,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 520,
      columnNumber: 7
    }, this),
    reportType === "volunteer-attendance" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Active Volunteers" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 545,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-slate-900 mt-0.5", children: volunteers.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 546,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 544,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Total Teaching Hours" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 549,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-[#0B3D91] mt-0.5", children: "42.5 hrs" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 550,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 548,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "On-Time Rate" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 553,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-emerald-700 mt-0.5", children: "94.8%" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 554,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 552,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Avg Sessions / Mentor" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 557,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-[#FF7A00] mt-0.5", children: "3.2" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 558,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 556,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 543,
      columnNumber: 7
    }, this),
    reportType === "lesson-plan" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Total Lesson Plans" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 566,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-slate-900 mt-0.5", children: filteredLessonPlans.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 567,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 565,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Approved" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 570,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-emerald-700 mt-0.5", children: filteredLessonPlans.filter((lp) => lp.status === "Approved" || lp.status === "Completed").length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 571,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 569,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Under Review" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 576,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-blue-700 mt-0.5", children: filteredLessonPlans.filter((lp) => lp.status === "Submitted" || lp.status === "Resubmitted").length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 577,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 575,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-3 shadow-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold text-slate-500 uppercase", children: "Curriculum Hours" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 582,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-[#FF7A00] mt-0.5", children: [
          filteredLessonPlans.length * 1.5,
          " hrs"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 583,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 581,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 564,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md shadow-xs overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-xs text-slate-800 uppercase tracking-wider", children: [
          reportType === "session" && "Session Delivery & Operations Table",
          reportType === "lesson-plan" && "Curriculum & Lesson Plan Table",
          reportType === "student-attendance" && "Student Village Center Attendance Table",
          reportType === "volunteer-attendance" && "Volunteer Mentorship & Attendance Table"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 595,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 594,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-slate-500", children: [
          "Cluster: Dharmapuri • Generated: ",
          (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB")
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 602,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 593,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: [
        reportType === "session" && /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-50/50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]", children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Date & Code" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 613,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Topic & Module" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 614,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 615,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Village" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 616,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Volunteer" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 617,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 618,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-right", children: "Attendance" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 619,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 612,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 611,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-100 text-slate-700", children: filteredSessions.map(
            (s) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/80 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 whitespace-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900", children: s.date }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 626,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-mono text-[10px] text-slate-500", children: s.code || "M-103" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 627,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 625,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900", children: s.name || s.title }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 630,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500", children: s.module || "Spoken English" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 631,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 629,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-medium text-slate-800", children: s.panchayatName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 633,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-slate-600", children: s.villageName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 634,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-medium text-slate-900", children: s.volunteerName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 635,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700", children: s.status }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 637,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 636,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-right font-bold text-slate-900", children: [
                s.attendanceCount || 20,
                "/",
                s.totalStudents || 25
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 641,
                columnNumber: 21
              }, this)
            ] }, s.id, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 624,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 622,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 610,
          columnNumber: 11
        }, this),
        reportType === "lesson-plan" && /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-50/50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]", children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Date & Module" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 655,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Topic & Objective" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 656,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Standard" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 657,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Panchayat & Village" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 658,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Volunteer" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 659,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-right", children: "Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 660,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 654,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 653,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-100 text-slate-700", children: filteredLessonPlans.map(
            (lp) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/80 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 whitespace-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900", children: lp.date || "28 Aug 2026" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 667,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500", children: lp.moduleName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 668,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 666,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900", children: lp.topic }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 671,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500 line-clamp-1", children: lp.objective }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 672,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 670,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-slate-600", children: lp.targetStandard || "6th - 8th" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 674,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-slate-800", children: lp.panchayatName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 676,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500", children: lp.villageName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 677,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 675,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-medium text-slate-900", children: lp.volunteerName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 679,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-right", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200", children: lp.status || "Approved" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 681,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 680,
                columnNumber: 21
              }, this)
            ] }, lp.id, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 665,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 663,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 652,
          columnNumber: 11
        }, this),
        reportType === "student-attendance" && /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-50/50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]", children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 696,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Village Learning Center" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 697,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Total Enrolled" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 698,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Avg Present" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 699,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Attendance %" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 700,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Sessions Run" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 701,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-right", children: "Health Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 702,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 695,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 694,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-100 text-slate-700", children: villageAttendanceData.map(
            (d, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/80 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-bold text-slate-900", children: d.panchayatName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 708,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-medium text-slate-800", children: d.villageName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 709,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-slate-700", children: d.totalRegistered }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 710,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center font-semibold text-slate-900", children: d.avgPresent }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 711,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center font-bold text-[#0B3D91]", children: [
                d.attendancePct,
                "%"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 712,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-slate-600", children: d.sessionsCount }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 713,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-right", children: /* @__PURE__ */ jsxDEV("span", { className: `inline-flex px-2 py-0.5 rounded text-[11px] font-semibold ${d.status === "Optimal" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`, children: d.status }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 715,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 714,
                columnNumber: 21
              }, this)
            ] }, idx, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 707,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 705,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 693,
          columnNumber: 11
        }, this),
        reportType === "volunteer-attendance" && /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-xs", children: [
          /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-50/50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]", children: [
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Volunteer Mentor" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 734,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Affiliated College" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 735,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Assigned" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 736,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Completed" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 737,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "On-Time Rate" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 738,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-center", children: "Total Hours" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 739,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-right", children: "Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 740,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 733,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 732,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-100 text-slate-700", children: volunteerAttendanceData.map(
            (v) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/80 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 font-bold text-slate-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 rounded-full bg-[#0B3D91]/10 text-[#0B3D91] text-[10px] font-bold flex items-center justify-center", children: v.name.charAt(0) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 747,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: v.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                  lineNumber: 750,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 746,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-slate-600", children: v.college }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 752,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-slate-700 font-semibold", children: v.assignedSessions }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 753,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-emerald-700 font-bold", children: v.completedSessions }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 754,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-[#0B3D91] font-semibold", children: v.onTimeRate }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 755,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-center text-slate-600", children: v.totalHours }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 756,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-2.5 px-3.5 text-right", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-[#0B3D91]", children: v.status }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 758,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
                lineNumber: 757,
                columnNumber: 21
              }, this)
            ] }, v.id, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
              lineNumber: 745,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
            lineNumber: 743,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
          lineNumber: 731,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
        lineNumber: 607,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
      lineNumber: 591,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx",
    lineNumber: 252,
    columnNumber: 5
  }, this);
};
_s(ReportsView, "c82NUQANVtoevXksFBiC6foKfY8=");
_c = ReportsView;
var _c;
$RefreshReg$(_c, "ReportsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK1BVOztBQS9QVixTQUFnQkEsVUFBVUMsZUFBZTtBQUV6QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFhQSxhQUFNQyxjQUEwQ0EsQ0FBQztBQUFBLEVBQ3REQyxXQUFXO0FBQUEsRUFDWEMsY0FBYztBQUFBLEVBQ2RDLGFBQWE7QUFBQSxFQUNiQyxhQUFhO0FBQUEsRUFDYkM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFFSixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWYsU0FBcUIsU0FBUztBQUNsRSxRQUFNLENBQUNnQixpQkFBaUJDLGtCQUFrQixJQUFJakIsU0FBNEQsS0FBSztBQUMvRyxRQUFNLENBQUNrQixXQUFXQyxZQUFZLElBQUluQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0IsU0FBU0MsVUFBVSxJQUFJckIsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ3NCLG1CQUFtQkMsb0JBQW9CLElBQUl2QixTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDd0IsaUJBQWlCQyxrQkFBa0IsSUFBSXpCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMwQixtQkFBbUJDLG9CQUFvQixJQUFJM0IsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzRCLGdCQUFnQkMsaUJBQWlCLElBQUk3QixTQUFTLEtBQUs7QUFHMUQsUUFBTSxDQUFDOEIsWUFBWUMsYUFBYSxJQUFJL0IsU0FBUyxFQUFFO0FBRy9DLFFBQU1nQyx3QkFBd0IvQixRQUFRLE1BQU07QUFDMUMsUUFBSXFCLHNCQUFzQixPQUFPO0FBQy9CLFlBQU1XLGNBQThDO0FBQ3BEdkIsaUJBQVd3QixRQUFRLENBQUNDLE1BQU07QUFDeEJBLFVBQUVDLFVBQVVGLFFBQVEsQ0FBQ0csTUFBTTtBQUN6QixjQUFJLENBQUNKLFlBQVlLLEtBQUssQ0FBQ0MsYUFBYUEsU0FBU0MsU0FBU0gsRUFBRUcsSUFBSSxHQUFHO0FBQzdEUCx3QkFBWVEsS0FBSyxFQUFFQyxJQUFJTCxFQUFFSyxJQUFJRixNQUFNSCxFQUFFRyxLQUFLLENBQUM7QUFBQSxVQUM3QztBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUNELGFBQU9QO0FBQUFBLElBQ1Q7QUFDQSxVQUFNVSxRQUFRakMsV0FBV2tDLEtBQUssQ0FBQ1QsTUFBTUEsRUFBRU8sT0FBT3BCLGlCQUFpQjtBQUMvRCxXQUFPcUIsT0FBT1AsWUFBWTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ2QsbUJBQW1CWixVQUFVLENBQUM7QUFHbEMsUUFBTW1DLHFCQUFxQkEsQ0FBQ0MsV0FBOEQ7QUFDeEY3Qix1QkFBbUI2QixNQUFNO0FBQ3pCLFVBQU1DLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsUUFBSUYsV0FBVyxPQUFPO0FBQ3BCM0IsbUJBQWEsRUFBRTtBQUNmRSxpQkFBVyxFQUFFO0FBQUEsSUFDZixXQUFXeUIsV0FBVyxhQUFhO0FBQ2pDLFlBQU1HLFFBQVEsSUFBSUQsS0FBS0QsSUFBSUcsUUFBUUgsSUFBSUksUUFBUSxJQUFJSixJQUFJSyxPQUFPLENBQUMsQ0FBQztBQUNoRSxZQUFNQyxPQUFPLElBQUlMLEtBQUtELElBQUlHLFFBQVFILElBQUlJLFFBQVEsSUFBSUosSUFBSUssT0FBTyxJQUFJLENBQUMsQ0FBQztBQUNuRWpDLG1CQUFhOEIsTUFBTUssWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDOUNsQyxpQkFBV2dDLEtBQUtDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDN0MsV0FBV1QsV0FBVyxjQUFjO0FBQ2xDLFlBQU1VLFdBQVcsSUFBSVIsS0FBS0QsSUFBSVUsWUFBWSxHQUFHVixJQUFJVyxTQUFTLEdBQUcsQ0FBQztBQUM5RCxZQUFNQyxVQUFVLElBQUlYLEtBQUtELElBQUlVLFlBQVksR0FBR1YsSUFBSVcsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRXZDLG1CQUFhcUMsU0FBU0YsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDakRsQyxpQkFBV3NDLFFBQVFMLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDaEQsV0FBV1QsV0FBVyxjQUFjO0FBQ2xDLFlBQU1VLFdBQVcsSUFBSVIsS0FBS0QsSUFBSVUsWUFBWSxHQUFHVixJQUFJVyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xFLFlBQU1DLFVBQVUsSUFBSVgsS0FBS0QsSUFBSVUsWUFBWSxHQUFHVixJQUFJVyxTQUFTLEdBQUcsQ0FBQztBQUM3RHZDLG1CQUFhcUMsU0FBU0YsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDakRsQyxpQkFBV3NDLFFBQVFMLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBR0EsUUFBTUssbUJBQW1CM0QsUUFBUSxNQUFNO0FBQ3JDLFdBQU9PLFNBQVNxRCxPQUFPLENBQUNDLE1BQU07QUFDNUIsWUFBTUMsU0FBU3pDLHNCQUFzQixTQUFTd0MsRUFBRUUsZ0JBQWdCMUM7QUFDaEUsWUFBTTJDLFNBQVN6QyxvQkFBb0IsVUFBVXNDLEVBQUVJLGVBQWUsSUFBSUMsWUFBWSxNQUFNM0MsZ0JBQWdCMkMsWUFBWTtBQUNoSCxZQUFNQyxXQUFXMUMsc0JBQXNCLFNBQVNvQyxFQUFFTyxnQkFBZ0IzQyxzQkFBc0JvQyxFQUFFUSxpQkFBaUIsSUFBSUgsWUFBWSxNQUFNekMsa0JBQWtCeUMsWUFBWTtBQUMvSixZQUFNSSxZQUFZM0MsbUJBQW1CLFNBQVNrQyxFQUFFVSxPQUFPTCxZQUFZLE1BQU12QyxlQUFldUMsWUFBWTtBQUNwRyxZQUFNTSxTQUFTM0MsV0FBV3FDLFlBQVksRUFBRU8sS0FBSztBQUM3QyxZQUFNQyxjQUFjLENBQUNGLFdBQ2xCWCxFQUFFdEIsUUFBUSxJQUFJMkIsWUFBWSxFQUFFUyxTQUFTSCxNQUFNLE1BQzNDWCxFQUFFZSxVQUFVLElBQUlWLFlBQVksRUFBRVMsU0FBU0gsTUFBTSxNQUM3Q1gsRUFBRWdCLGlCQUFpQixJQUFJWCxZQUFZLEVBQUVTLFNBQVNILE1BQU0sTUFDcERYLEVBQUVJLGVBQWUsSUFBSUMsWUFBWSxFQUFFUyxTQUFTSCxNQUFNO0FBRXJELGFBQU9WLFVBQVVFLFVBQVVHLFlBQVlHLGFBQWFJO0FBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ25FLFVBQVVjLG1CQUFtQkUsaUJBQWlCRSxtQkFBbUJFLGdCQUFnQkUsVUFBVSxDQUFDO0FBR2hHLFFBQU1pRCxzQkFBc0I5RSxRQUFRLE1BQU07QUFDeEMsV0FBT1EsWUFBWW9ELE9BQU8sQ0FBQ21CLE9BQU87QUFDaEMsWUFBTWpCLFNBQVN6QyxzQkFBc0IsU0FBUzBELEdBQUdoQixnQkFBZ0IxQztBQUNqRSxZQUFNMkMsU0FBU3pDLG9CQUFvQixVQUFVd0QsR0FBR2QsZUFBZSxJQUFJQyxZQUFZLE1BQU0zQyxnQkFBZ0IyQyxZQUFZO0FBQ2pILFlBQU1DLFdBQVcxQyxzQkFBc0IsU0FBU3NELEdBQUdYLGdCQUFnQjNDLHNCQUFzQnNELEdBQUdWLGlCQUFpQixJQUFJSCxZQUFZLE1BQU16QyxrQkFBa0J5QyxZQUFZO0FBQ2pLLFlBQU1JLFlBQVkzQyxtQkFBbUIsVUFBVW9ELEdBQUdSLFVBQVUsSUFBSUwsWUFBWSxNQUFNdkMsZUFBZXVDLFlBQVk7QUFDN0csWUFBTU0sU0FBUzNDLFdBQVdxQyxZQUFZLEVBQUVPLEtBQUs7QUFDN0MsWUFBTUMsY0FBYyxDQUFDRixXQUNsQk8sR0FBR0MsU0FBUyxJQUFJZCxZQUFZLEVBQUVTLFNBQVNILE1BQU0sTUFDN0NPLEdBQUdFLGNBQWMsSUFBSWYsWUFBWSxFQUFFUyxTQUFTSCxNQUFNLE1BQ2xETyxHQUFHRixpQkFBaUIsSUFBSVgsWUFBWSxFQUFFUyxTQUFTSCxNQUFNLE1BQ3JETyxHQUFHZCxlQUFlLElBQUlDLFlBQVksRUFBRVMsU0FBU0gsTUFBTTtBQUV0RCxhQUFPVixVQUFVRSxVQUFVRyxZQUFZRyxhQUFhSTtBQUFBQSxJQUN0RCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNsRSxhQUFhYSxtQkFBbUJFLGlCQUFpQkUsbUJBQW1CRSxnQkFBZ0JFLFVBQVUsQ0FBQztBQUduRyxRQUFNcUQsd0JBQXdCbEYsUUFBUSxNQUFNO0FBQzFDLFVBQU1tRixPQVFBO0FBRU4xRSxlQUFXd0IsUUFBUSxDQUFDQyxNQUFNO0FBQ3hCLFVBQUliLHNCQUFzQixTQUFTYSxFQUFFTyxPQUFPcEIsa0JBQW1CO0FBQy9EYSxRQUFFQyxVQUFVRixRQUFRLENBQUNHLE1BQU07QUFDekIsWUFBSWIsb0JBQW9CLFNBQVNhLEVBQUVHLEtBQUsyQixZQUFZLE1BQU0zQyxnQkFBZ0IyQyxZQUFZLEVBQUc7QUFDekYsY0FBTWtCLFlBQVk3RSxTQUFTcUQsT0FBTyxDQUFDQyxPQUFPQSxFQUFFSSxlQUFlLElBQUlDLFlBQVksTUFBTTlCLEVBQUVHLEtBQUsyQixZQUFZLENBQUM7QUFDckcsY0FBTW1CLGFBQWFqRCxFQUFFa0QsZ0JBQWdCO0FBQ3JDLGNBQU1DLGdCQUFnQkgsVUFBVUksT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxPQUFPQyxLQUFLQyxtQkFBbUIsS0FBSyxDQUFDO0FBQzNGLGNBQU1DLGNBQWNSLFVBQVVTLFNBQVMsSUFBSUMsS0FBS0MsTUFBTVIsZ0JBQWdCSCxVQUFVUyxNQUFNLElBQUlDLEtBQUtDLE1BQU1WLGFBQWEsSUFBSTtBQUN0SCxjQUFNVyxNQUFNRixLQUFLQyxNQUFPSCxjQUFjUCxhQUFjLEdBQUc7QUFFdkRGLGFBQUszQyxLQUFLO0FBQUEsVUFDUnFDLGVBQWUzQyxFQUFFSztBQUFBQSxVQUNqQjBCLGFBQWE3QixFQUFFRztBQUFBQSxVQUNmMEQsaUJBQWlCWjtBQUFBQSxVQUNqQmEsWUFBWU47QUFBQUEsVUFDWk8sZUFBZUwsS0FBS00sSUFBSUosS0FBSyxHQUFHO0FBQUEsVUFDaENLLGVBQWVqQixVQUFVUyxVQUFVO0FBQUEsVUFDbkN0QixRQUFReUIsT0FBTyxLQUFLLFlBQVlBLE9BQU8sS0FBSyxZQUFZO0FBQUEsUUFDMUQsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUVELFdBQU9iO0FBQUFBLEVBQ1QsR0FBRyxDQUFDMUUsWUFBWUYsVUFBVWMsbUJBQW1CRSxlQUFlLENBQUM7QUFHN0QsUUFBTStFLDBCQUEwQnRHLFFBQVEsTUFBTTtBQUM1QyxXQUFPVSxXQUFXNkYsSUFBSSxDQUFDQyxRQUFRO0FBQzdCLFlBQU1DLGNBQWNsRyxTQUFTcUQsT0FBTyxDQUFDQyxNQUFNQSxFQUFFTyxnQkFBZ0JvQyxJQUFJL0QsT0FBT29CLEVBQUVRLGlCQUFpQixJQUFJSCxZQUFZLE1BQU1zQyxJQUFJakUsS0FBSzJCLFlBQVksQ0FBQztBQUN2SSxZQUFNd0MsWUFBWUQsWUFBWTdDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVUsV0FBVyxXQUFXLEVBQUVzQjtBQUN0RSxZQUFNYyxXQUFXYixLQUFLYyxJQUFJSCxZQUFZWixRQUFRLENBQUM7QUFDL0MsWUFBTWdCLGFBQWFmLEtBQUtNLElBQUksS0FBS04sS0FBS0MsTUFBTSxLQUFLRCxLQUFLZ0IsT0FBTyxJQUFJLENBQUMsQ0FBQztBQUNuRSxZQUFNQyxhQUFhSixXQUFXO0FBRTlCLGFBQU87QUFBQSxRQUNMbEUsSUFBSStELElBQUkvRDtBQUFBQSxRQUNSRixNQUFNaUUsSUFBSWpFO0FBQUFBLFFBQ1Z5RSxTQUFTUixJQUFJUSxXQUFXO0FBQUEsUUFDeEJDLFlBQVlULElBQUlTLGNBQWM7QUFBQSxRQUM5QkMsa0JBQWtCUDtBQUFBQSxRQUNsQlEsbUJBQW1CVCxhQUFjQyxXQUFXO0FBQUEsUUFDNUNFLFlBQVksR0FBR0EsVUFBVTtBQUFBLFFBQ3pCRSxZQUFZLEdBQUdBLFVBQVU7QUFBQSxRQUN6QnhDLFFBQVFtQyxhQUFhLElBQUksc0JBQXNCO0FBQUEsTUFDakQ7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ2hHLFlBQVlILFFBQVEsQ0FBQztBQUd6QixRQUFNNkcsa0JBQWtCQSxNQUFNO0FBQzVCLFFBQUlDLFVBQW9CO0FBQ3hCLFFBQUlDLE9BQW1CO0FBQ3ZCLFFBQUlDLFdBQVcsT0FBTzFHLFdBQVcyRyxZQUFZLENBQUMsWUFBVyxvQkFBSXpFLEtBQUssR0FBRU0sWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFFL0YsUUFBSXpDLGVBQWUsV0FBVztBQUM1QndHLGdCQUFVLENBQUMsZ0JBQWdCLFNBQVMsVUFBVSxRQUFRLFFBQVEsYUFBYSxXQUFXLGFBQWEsVUFBVSxZQUFZO0FBQ3pIQyxhQUFPM0QsaUJBQWlCNEM7QUFBQUEsUUFBSSxDQUFDMUMsTUFBTTtBQUFBLFVBQ2pDLElBQUlBLEVBQUU0RCxRQUFRLEVBQUU7QUFBQSxVQUNoQixLQUFLNUQsRUFBRXRCLFFBQVFzQixFQUFFNkQsU0FBUyxJQUFJQyxRQUFRLE1BQU0sSUFBSSxDQUFDO0FBQUEsVUFDakQsS0FBSzlELEVBQUVlLFVBQVVmLEVBQUUrRCxZQUFZLElBQUlELFFBQVEsTUFBTSxJQUFJLENBQUM7QUFBQSxVQUN0RCxJQUFJOUQsRUFBRWdFLElBQUk7QUFBQSxVQUNWLElBQUloRSxFQUFFaUUsSUFBSTtBQUFBLFVBQ1YsSUFBSWpFLEVBQUVnQixhQUFhO0FBQUEsVUFDbkIsSUFBSWhCLEVBQUVJLFdBQVc7QUFBQSxVQUNqQixJQUFJSixFQUFFUSxhQUFhO0FBQUEsVUFDbkIsSUFBSVIsRUFBRVUsTUFBTTtBQUFBLFVBQ1osSUFBSVYsRUFBRThCLG1CQUFtQixFQUFFLElBQUk5QixFQUFFa0UsaUJBQWlCLEVBQUU7QUFBQSxRQUFHO0FBQUEsTUFDeEQ7QUFBQSxJQUNILFdBQVdsSCxlQUFlLGVBQWU7QUFDdkN3RyxnQkFBVSxDQUFDLFNBQVMsVUFBVSxnQkFBZ0IsYUFBYSxXQUFXLGFBQWEsVUFBVSxNQUFNO0FBQ25HQyxhQUFPeEMsb0JBQW9CeUI7QUFBQUEsUUFBSSxDQUFDeEIsT0FBTztBQUFBLFVBQ3JDLEtBQUtBLEdBQUdDLFNBQVMsSUFBSTJDLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFBQSxVQUN4QyxLQUFLNUMsR0FBR0UsY0FBYyxJQUFJMEMsUUFBUSxNQUFNLElBQUksQ0FBQztBQUFBLFVBQzdDLElBQUk1QyxHQUFHaUQsa0JBQWtCLFdBQVc7QUFBQSxVQUNwQyxJQUFJakQsR0FBR0YsaUJBQWlCLEVBQUU7QUFBQSxVQUMxQixJQUFJRSxHQUFHZCxlQUFlLEVBQUU7QUFBQSxVQUN4QixJQUFJYyxHQUFHVixpQkFBaUIsRUFBRTtBQUFBLFVBQzFCLElBQUlVLEdBQUdSLFVBQVUsRUFBRTtBQUFBLFVBQ25CLElBQUlRLEdBQUc4QyxRQUFRLEVBQUU7QUFBQSxRQUFHO0FBQUEsTUFDckI7QUFBQSxJQUNILFdBQVdoSCxlQUFlLHNCQUFzQjtBQUM5Q3dHLGdCQUFVLENBQUMsYUFBYSxrQkFBa0Isa0JBQWtCLG1CQUFtQixxQkFBcUIsc0JBQXNCLFFBQVE7QUFDbElDLGFBQU9wQyxzQkFBc0JxQjtBQUFBQSxRQUFJLENBQUMwQixNQUFNO0FBQUEsVUFDdEMsSUFBSUEsRUFBRXBELGFBQWE7QUFBQSxVQUNuQixJQUFJb0QsRUFBRWhFLFdBQVc7QUFBQSxVQUNqQixJQUFJZ0UsRUFBRWhDLGVBQWU7QUFBQSxVQUNyQixJQUFJZ0MsRUFBRS9CLFVBQVU7QUFBQSxVQUNoQixJQUFJK0IsRUFBRTlCLGFBQWE7QUFBQSxVQUNuQixJQUFJOEIsRUFBRTVCLGFBQWE7QUFBQSxVQUNuQixJQUFJNEIsRUFBRTFELE1BQU07QUFBQSxRQUFHO0FBQUEsTUFDaEI7QUFBQSxJQUNILE9BQU87QUFDTDhDLGdCQUFVLENBQUMsa0JBQWtCLFdBQVcsY0FBYyxxQkFBcUIsc0JBQXNCLGdCQUFnQixlQUFlLFFBQVE7QUFDeElDLGFBQU9oQix3QkFBd0JDO0FBQUFBLFFBQUksQ0FBQ25FLE1BQU07QUFBQSxVQUN4QyxJQUFJQSxFQUFFRyxJQUFJO0FBQUEsVUFDVixJQUFJSCxFQUFFNEUsT0FBTztBQUFBLFVBQ2IsSUFBSTVFLEVBQUU2RSxVQUFVO0FBQUEsVUFDaEIsSUFBSTdFLEVBQUU4RSxnQkFBZ0I7QUFBQSxVQUN0QixJQUFJOUUsRUFBRStFLGlCQUFpQjtBQUFBLFVBQ3ZCLElBQUkvRSxFQUFFeUUsVUFBVTtBQUFBLFVBQ2hCLElBQUl6RSxFQUFFMkUsVUFBVTtBQUFBLFVBQ2hCLElBQUkzRSxFQUFFbUMsTUFBTTtBQUFBLFFBQUc7QUFBQSxNQUNoQjtBQUFBLElBQ0g7QUFFQSxVQUFNMkQsYUFBYSxpQ0FBaUMsQ0FBQ2IsUUFBUWMsS0FBSyxHQUFHLEdBQUcsR0FBR2IsS0FBS2YsSUFBSSxDQUFDNkIsTUFBTUEsRUFBRUQsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFQSxLQUFLLElBQUk7QUFDbEgsVUFBTUUsYUFBYUMsVUFBVUosVUFBVTtBQUN2QyxVQUFNSyxPQUFPQyxTQUFTQyxjQUFjLEdBQUc7QUFDdkNGLFNBQUtHLGFBQWEsUUFBUUwsVUFBVTtBQUNwQ0UsU0FBS0csYUFBYSxZQUFZbkIsUUFBUTtBQUN0Q2lCLGFBQVNHLEtBQUtDLFlBQVlMLElBQUk7QUFDOUJBLFNBQUtNLE1BQU07QUFDWEwsYUFBU0csS0FBS0csWUFBWVAsSUFBSTtBQUFBLEVBQ2hDO0FBRUEsUUFBTVEsb0JBQW9CQSxNQUFNO0FBQzlCQyxXQUFPQyxNQUFNO0FBQUEsRUFDZjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw4RUFBNkUsOENBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRCxxR0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTRjtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQTtBQUFBLFVBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUzNCO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBO0FBQUEsVUFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU10RyxjQUFjLFNBQVM7QUFBQSxVQUN0QyxXQUFXLDZJQUNURCxlQUFlLFlBQ1gsc0NBQ0Esd0RBQXdEO0FBQUEsVUFHOUQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLFlBQU87QUFBQTtBQUFBO0FBQUEsUUFSM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1DLGNBQWMsYUFBYTtBQUFBLFVBQzFDLFdBQVcsNklBQ1RELGVBQWUsZ0JBQ1gsc0NBQ0Esd0RBQXdEO0FBQUEsVUFHOUQ7QUFBQSxtQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQU87QUFBQTtBQUFBO0FBQUEsUUFSMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1DLGNBQWMsb0JBQW9CO0FBQUEsVUFDakQsV0FBVyw2SUFDVEQsZUFBZSx1QkFDWCxzQ0FDQSx3REFBd0Q7QUFBQSxVQUc5RDtBQUFBLG1DQUFDLFVBQUssV0FBVSx5Q0FBd0Msc0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUEsWUFBTztBQUFBO0FBQUE7QUFBQSxRQVJ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTUMsY0FBYyxzQkFBc0I7QUFBQSxVQUNuRCxXQUFXLDZJQUNURCxlQUFlLHlCQUNYLHNDQUNBLHdEQUF3RDtBQUFBLFVBRzlEO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUFPO0FBQUE7QUFBQTtBQUFBLFFBUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlFQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHFFQUFvRSxrQ0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNK0IsbUJBQW1CLEtBQUs7QUFBQSxjQUN2QyxXQUFXLDRFQUNUN0Isb0JBQW9CLFFBQ2hCLDRCQUNBLGdEQUFnRDtBQUFBLGNBQ25EO0FBQUE7QUFBQSxZQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNNkIsbUJBQW1CLFdBQVc7QUFBQSxjQUM3QyxXQUFXLDRFQUNUN0Isb0JBQW9CLGNBQ2hCLDRCQUNBLGdEQUFnRDtBQUFBLGNBQ25EO0FBQUE7QUFBQSxZQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNNkIsbUJBQW1CLFlBQVk7QUFBQSxjQUM5QyxXQUFXLDRFQUNUN0Isb0JBQW9CLGVBQ2hCLDRCQUNBLGdEQUFnRDtBQUFBLGNBQ25EO0FBQUE7QUFBQSxZQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNNkIsbUJBQW1CLFlBQVk7QUFBQSxjQUM5QyxXQUFXLDRFQUNUN0Isb0JBQW9CLGVBQ2hCLDRCQUNBLGdEQUFnRDtBQUFBLGNBQ25EO0FBQUE7QUFBQSxZQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsYUF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBLFdBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0VBQWlFLHlCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT00scUJBQXFCO0FBQUEsY0FDNUIsZUFBZSxDQUFDNkgsUUFBUTtBQUN0QjVILHFDQUFxQjRILEdBQUc7QUFDeEIxSCxtQ0FBbUIsS0FBSztBQUFBLGNBQzFCO0FBQUEsY0FFQTtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sT0FBTSw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDckNmLFdBQVc4RjtBQUFBQSxvQkFBSSxDQUFDckUsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFTyxJQUM3QlAsWUFBRUssUUFEWUwsRUFBRU8sSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUEscUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBO0FBQUE7QUFBQSxZQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtFQUFpRSw4QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9sQixtQkFBbUI7QUFBQSxjQUMxQixlQUFlLENBQUMySCxRQUFRMUgsbUJBQW1CMEgsR0FBRztBQUFBLGNBRTlDO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDQztBQUFBLHlDQUFDLGNBQVcsT0FBTSxPQUFNLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNuQ25ILHNCQUFzQndFO0FBQUFBLG9CQUFJLENBQUNuRSxNQUMxQix1QkFBQyxjQUFzQixPQUFPQSxFQUFFRyxNQUM3QkgsWUFBRUcsUUFEWUgsRUFBRUssSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUEscUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBO0FBQUE7QUFBQSxZQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWVBO0FBQUEsYUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrRUFBaUUseUJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPaEIscUJBQXFCO0FBQUEsY0FDNUIsZUFBZSxDQUFDeUgsUUFBUXhILHFCQUFxQndILEdBQUc7QUFBQSxjQUVoRDtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sT0FBTSw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDckN4SSxXQUFXNkY7QUFBQUEsb0JBQUksQ0FBQ25FLE1BQ2YsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRUcsTUFDN0JILFlBQUVHLFFBRFlILEVBQUVLLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBLHFCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQTtBQUFBO0FBQUEsWUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0VBQWlFLDZCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT2Qsa0JBQWtCO0FBQUEsY0FDekIsZUFBZSxDQUFDdUgsUUFBUXRILGtCQUFrQnNILEdBQUc7QUFBQSxjQUU3QztBQUFBLHVDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sT0FBTSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsY0FBVyxPQUFNLGFBQVkseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3ZDLHVCQUFDLGNBQVcsT0FBTSxhQUFZLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUN2Qyx1QkFBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUM7QUFBQSxrQkFDckMsdUJBQUMsY0FBVyxPQUFNLHdCQUF1QixvQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkQ7QUFBQSxxQkFML0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBO0FBQUE7QUFBQSxZQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtRUFBa0UsOEJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPckg7QUFBQUEsY0FDUCxVQUFVLENBQUN1RyxNQUFNdEcsY0FBY3NHLEVBQUVlLE9BQU9DLEtBQUs7QUFBQSxjQUM3QyxhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUttSTtBQUFBLGFBVHJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBdEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1R0E7QUFBQSxTQTFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkpBO0FBQUEsSUFHQ3ZJLGVBQWUsYUFDZCx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELGlDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsUUFDckYsdUJBQUMsU0FBSSxXQUFVLDJDQUEyQzhDLDJCQUFpQmtDLFVBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxXQUZwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQseUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RSx1QkFBQyxTQUFJLFdBQVUsNkNBQ1psQywyQkFBaUJDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVUsV0FBVyxXQUFXLEVBQUVzQixVQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFxRCxnQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFNBQUksV0FBVSwwQ0FDWmxDLDJCQUFpQkMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFVSxXQUFXLFdBQVcsRUFBRXNCLFVBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELHNDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsUUFDMUYsdUJBQUMsU0FBSSxXQUFVLDJDQUNabEMsMkJBQWlCNkIsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxPQUFPQyxLQUFLQyxtQkFBbUIsS0FBSyxDQUFDLEtBRC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBR0Q5RSxlQUFlLHdCQUNkLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQsK0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRix1QkFBQyxTQUFJLFdBQVUsMkNBQTJDcUUsZ0NBQXNCVyxVQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELDhCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEYsdUJBQUMsU0FBSSxXQUFVLDJDQUNaWCxnQ0FBc0JNLE9BQU8sQ0FBQ0MsS0FBS0MsU0FBU0QsTUFBTUMsS0FBS08saUJBQWlCLENBQUMsS0FENUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQsa0NBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxRQUN0Rix1QkFBQyxTQUFJLFdBQVUsNkNBQTRDLHFCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsV0FGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELGtDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNGO0FBQUEsUUFDdEYsdUJBQUMsU0FBSSxXQUFVLHlDQUF3QyxnQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFdBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtQkE7QUFBQSxJQUdEcEYsZUFBZSwwQkFDZCx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELGlDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsUUFDckYsdUJBQUMsU0FBSSxXQUFVLDJDQUEyQ0gscUJBQVdtRixVQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsV0FGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELG9DQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsUUFDeEYsdUJBQUMsU0FBSSxXQUFVLDJDQUEwQyx3QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFdBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFxRCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFFBQ2hGLHVCQUFDLFNBQUksV0FBVSw2Q0FBNEMscUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxXQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQscUNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUN6Rix1QkFBQyxTQUFJLFdBQVUsMkNBQTBDLG1CQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsV0FGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBR0RoRixlQUFlLGlCQUNkLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQsa0NBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxRQUN0Rix1QkFBQyxTQUFJLFdBQVUsMkNBQTJDaUUsOEJBQW9CZSxVQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFGO0FBQUEsV0FGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQXFELHdCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsUUFDNUUsdUJBQUMsU0FBSSxXQUFVLDZDQUNaZiw4QkFBb0JsQixPQUFPLENBQUNtQixPQUFPQSxHQUFHUixXQUFXLGNBQWNRLEdBQUdSLFdBQVcsV0FBVyxFQUFFc0IsVUFEN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBcUQsNEJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUNoRix1QkFBQyxTQUFJLFdBQVUsMENBQ1pmLDhCQUFvQmxCLE9BQU8sQ0FBQ21CLE9BQU9BLEdBQUdSLFdBQVcsZUFBZVEsR0FBR1IsV0FBVyxhQUFhLEVBQUVzQixVQURoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFxRCxnQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFNBQUksV0FBVSwyQ0FDWmY7QUFBQUEsOEJBQW9CZSxTQUFTO0FBQUEsVUFBSTtBQUFBLGFBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLHlFQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFVBQUssV0FBVSw2REFDYmhGO0FBQUFBLHlCQUFlLGFBQWE7QUFBQSxVQUM1QkEsZUFBZSxpQkFBaUI7QUFBQSxVQUNoQ0EsZUFBZSx3QkFBd0I7QUFBQSxVQUN2Q0EsZUFBZSwwQkFBMEI7QUFBQSxhQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFdBQ1Qsb0JBQUlrQyxLQUFLLEdBQUVzRyxtQkFBbUIsT0FBTztBQUFBLGFBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBRVp4STtBQUFBQSx1QkFBZSxhQUNkLHVCQUFDLFdBQU0sV0FBVSw0Q0FDZjtBQUFBLGlDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLDhHQUNaO0FBQUEsbUNBQUMsUUFBRyxXQUFVLGlCQUFnQiwyQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLDhCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBQ2hELHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFDdkMsdUJBQUMsUUFBRyxXQUFVLGlCQUFnQix1QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUNyQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0Isc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFDcEMsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxlQVByRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLDRDQUNkOEMsMkJBQWlCNEM7QUFBQUEsWUFBSSxDQUFDMUMsTUFDckIsdUJBQUMsUUFBYyxXQUFVLDBDQUN2QjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxtQ0FDWjtBQUFBLHVDQUFDLFNBQUksV0FBVSxnQ0FBZ0NBLFlBQUVnRSxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxTQUFJLFdBQVUsd0NBQXdDaEUsWUFBRTRELFFBQVEsV0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUU7QUFBQSxtQkFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGdDQUFnQzVELFlBQUV0QixRQUFRc0IsRUFBRTZELFNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlFO0FBQUEsZ0JBQ2pFLHVCQUFDLFNBQUksV0FBVSw4QkFBOEI3RCxZQUFFZSxVQUFVLG9CQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsNENBQTRDZixZQUFFZ0IsaUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsY0FDMUUsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ2hCLFlBQUVJLGVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTREO0FBQUEsY0FDNUQsdUJBQUMsUUFBRyxXQUFVLDRDQUE0Q0osWUFBRVEsaUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBFO0FBQUEsY0FDMUUsdUJBQUMsUUFBRyxXQUFVLGlCQUNaLGlDQUFDLFVBQUssV0FBVSx5RkFDYlIsWUFBRVUsVUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUNYVjtBQUFBQSxrQkFBRThCLG1CQUFtQjtBQUFBLGdCQUFHO0FBQUEsZ0JBQUU5QixFQUFFa0UsaUJBQWlCO0FBQUEsbUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFuQk9sRSxFQUFFcEIsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFVBQ0QsS0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUNBO0FBQUEsUUFJRDVCLGVBQWUsaUJBQ2QsdUJBQUMsV0FBTSxXQUFVLDRDQUNmO0FBQUEsaUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsOEdBQ1o7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLFlBQy9DLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsaUNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQsdUJBQUMsUUFBRyxXQUFVLGlCQUFnQix3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLG1DQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLFlBQ3JELHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFDdkMsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQixzQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxlQU5qRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLDRDQUNkaUUsOEJBQW9CeUI7QUFBQUEsWUFBSSxDQUFDeEIsT0FDeEIsdUJBQUMsUUFBZSxXQUFVLDBDQUN4QjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxtQ0FDWjtBQUFBLHVDQUFDLFNBQUksV0FBVSxnQ0FBZ0NBLGFBQUc4QyxRQUFRLGlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUN4RSx1QkFBQyxTQUFJLFdBQVUsOEJBQThCOUMsYUFBR0UsY0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxtQkFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGdDQUFnQ0YsYUFBR0MsU0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxnQkFDeEQsdUJBQUMsU0FBSSxXQUFVLDJDQUEyQ0QsYUFBR3VFLGFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsbUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxnQ0FBZ0N2RSxhQUFHaUQsa0JBQWtCLGVBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FDL0UsdUJBQUMsUUFBRyxXQUFVLGlCQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDhCQUE4QmpELGFBQUdGLGlCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RDtBQUFBLGdCQUM5RCx1QkFBQyxTQUFJLFdBQVUsOEJBQThCRSxhQUFHZCxlQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RDtBQUFBLG1CQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsNENBQTRDYyxhQUFHVixpQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkU7QUFBQSxjQUMzRSx1QkFBQyxRQUFHLFdBQVUsNEJBQ1osaUNBQUMsVUFBSyxXQUFVLHNIQUNiVSxhQUFHUixVQUFVLGNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBbkJPUSxHQUFHdEMsSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFVBQ0QsS0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsUUFJRDVCLGVBQWUsd0JBQ2QsdUJBQUMsV0FBTSxXQUFVLDRDQUNmO0FBQUEsaUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsOEdBQ1o7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQ3ZDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsdUNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsUUFBRyxXQUFVLDZCQUE0Qiw4QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUN4RCx1QkFBQyxRQUFHLFdBQVUsNkJBQTRCLDJCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLFlBQ3JELHVCQUFDLFFBQUcsV0FBVSw2QkFBNEIsNEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsUUFBRyxXQUFVLDZCQUE0Qiw0QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxRQUFHLFdBQVUsNEJBQTJCLDZCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLGVBUHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsNENBQ2RxRSxnQ0FBc0JxQjtBQUFBQSxZQUFJLENBQUMwQixHQUFHc0IsUUFDN0IsdUJBQUMsUUFBYSxXQUFVLDBDQUN0QjtBQUFBLHFDQUFDLFFBQUcsV0FBVSwwQ0FBMEN0QixZQUFFcEQsaUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FDeEUsdUJBQUMsUUFBRyxXQUFVLDRDQUE0Q29ELFlBQUVoRSxlQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGNBQ3hFLHVCQUFDLFFBQUcsV0FBVSw0Q0FBNENnRSxZQUFFaEMsbUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsY0FDNUUsdUJBQUMsUUFBRyxXQUFVLDBEQUEwRGdDLFlBQUUvQixjQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLFFBQUcsV0FBVSxzREFBc0QrQjtBQUFBQSxrQkFBRTlCO0FBQUFBLGdCQUFjO0FBQUEsbUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckYsdUJBQUMsUUFBRyxXQUFVLDRDQUE0QzhCLFlBQUU1QixpQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxjQUMxRSx1QkFBQyxRQUFHLFdBQVUsNEJBQ1osaUNBQUMsVUFBSyxXQUFXLDZEQUNmNEIsRUFBRTFELFdBQVcsWUFDVCxtQ0FDQSw0QkFBNEIsSUFFL0IwRCxZQUFFMUQsVUFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQWZPZ0YsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFVBQ0QsS0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsUUFJRDFJLGVBQWUsMEJBQ2QsdUJBQUMsV0FBTSxXQUFVLDRDQUNmO0FBQUEsaUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsOEdBQ1o7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUJBQWdCLGdDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0Isa0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsWUFDaEQsdUJBQUMsUUFBRyxXQUFVLDZCQUE0Qix3QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxRQUFHLFdBQVUsNkJBQTRCLHlCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25ELHVCQUFDLFFBQUcsV0FBVSw2QkFBNEIsNEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNEO0FBQUEsWUFDdEQsdUJBQUMsUUFBRyxXQUFVLDZCQUE0QiwyQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxRQUFHLFdBQVUsNEJBQTJCLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQztBQUFBLGVBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsNENBQ2R5RixrQ0FBd0JDO0FBQUFBLFlBQUksQ0FBQ25FLE1BQzVCLHVCQUFDLFFBQWMsV0FBVSwwQ0FDdkI7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsa0VBQ1o7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOEdBQ1pBLFlBQUVHLEtBQUtpSCxPQUFPLENBQUMsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQU1wSCxZQUFFRyxRQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWM7QUFBQSxtQkFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLGdDQUFnQ0gsWUFBRTRFLFdBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsY0FDeEQsdUJBQUMsUUFBRyxXQUFVLDBEQUEwRDVFLFlBQUU4RSxvQkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkY7QUFBQSxjQUMzRix1QkFBQyxRQUFHLFdBQVUsd0RBQXdEOUUsWUFBRStFLHFCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRjtBQUFBLGNBQzFGLHVCQUFDLFFBQUcsV0FBVSwwREFBMEQvRSxZQUFFeUUsY0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxRQUFHLFdBQVUsNENBQTRDekUsWUFBRTJFLGNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkUsdUJBQUMsUUFBRyxXQUFVLDRCQUNaLGlDQUFDLFVBQUssV0FBVSx1RkFDYjNFLFlBQUVtQyxVQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBaEJPbkMsRUFBRUssSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFVBQ0QsS0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsV0E5Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdLQTtBQUFBLFNBaExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpTEE7QUFBQSxPQXBnQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFnQkE7QUFFSjtBQUFFN0IsR0E3dUJXTixhQUF1QztBQUFBLEtBQXZDQTtBQUF1QyxJQUFBbUo7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJSZXBvcnRzVmlldyIsInNlc3Npb25zIiwibGVzc29uUGxhbnMiLCJwYW5jaGF5YXRzIiwidm9sdW50ZWVycyIsIm9uTmF2aWdhdGUiLCJfcyIsInJlcG9ydFR5cGUiLCJzZXRSZXBvcnRUeXBlIiwiZGF0ZVJhbmdlUHJlc2V0Iiwic2V0RGF0ZVJhbmdlUHJlc2V0Iiwic3RhcnREYXRlIiwic2V0U3RhcnREYXRlIiwiZW5kRGF0ZSIsInNldEVuZERhdGUiLCJzZWxlY3RlZFBhbmNoYXlhdCIsInNldFNlbGVjdGVkUGFuY2hheWF0Iiwic2VsZWN0ZWRWaWxsYWdlIiwic2V0U2VsZWN0ZWRWaWxsYWdlIiwic2VsZWN0ZWRWb2x1bnRlZXIiLCJzZXRTZWxlY3RlZFZvbHVudGVlciIsInNlbGVjdGVkU3RhdHVzIiwic2V0U2VsZWN0ZWRTdGF0dXMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsImN1cnJlbnRGaWx0ZXJWaWxsYWdlcyIsImFsbFZpbGxhZ2VzIiwiZm9yRWFjaCIsInAiLCJ2aWxsYWdlcyIsInYiLCJzb21lIiwiZXhpc3RpbmciLCJuYW1lIiwicHVzaCIsImlkIiwiZm91bmQiLCJmaW5kIiwiaGFuZGxlUHJlc2V0Q2hhbmdlIiwicHJlc2V0Iiwibm93IiwiRGF0ZSIsImZpcnN0Iiwic2V0RGF0ZSIsImdldERhdGUiLCJnZXREYXkiLCJsYXN0IiwidG9JU09TdHJpbmciLCJzcGxpdCIsImZpcnN0RGF5IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImxhc3REYXkiLCJmaWx0ZXJlZFNlc3Npb25zIiwiZmlsdGVyIiwicyIsIm1hdGNoUCIsInBhbmNoYXlhdElkIiwibWF0Y2hWIiwidmlsbGFnZU5hbWUiLCJ0b0xvd2VyQ2FzZSIsIm1hdGNoVm9sIiwidm9sdW50ZWVySWQiLCJ2b2x1bnRlZXJOYW1lIiwibWF0Y2hTdGF0Iiwic3RhdHVzIiwic2VhcmNoIiwidHJpbSIsIm1hdGNoU2VhcmNoIiwiaW5jbHVkZXMiLCJtb2R1bGUiLCJwYW5jaGF5YXROYW1lIiwiZmlsdGVyZWRMZXNzb25QbGFucyIsImxwIiwidG9waWMiLCJtb2R1bGVOYW1lIiwidmlsbGFnZUF0dGVuZGFuY2VEYXRhIiwibGlzdCIsInZTZXNzaW9ucyIsInJlZ2lzdGVyZWQiLCJzdHVkZW50Q291bnQiLCJhdHRlbmRlZFRvdGFsIiwicmVkdWNlIiwiYWNjIiwiY3VyciIsImF0dGVuZGFuY2VDb3VudCIsImF2Z0F0dGVuZGVkIiwibGVuZ3RoIiwiTWF0aCIsInJvdW5kIiwicGN0IiwidG90YWxSZWdpc3RlcmVkIiwiYXZnUHJlc2VudCIsImF0dGVuZGFuY2VQY3QiLCJtaW4iLCJzZXNzaW9uc0NvdW50Iiwidm9sdW50ZWVyQXR0ZW5kYW5jZURhdGEiLCJtYXAiLCJ2b2wiLCJ2b2xTZXNzaW9ucyIsImNvbXBsZXRlZCIsImFzc2lnbmVkIiwibWF4Iiwib25UaW1lUmF0ZSIsInJhbmRvbSIsInRvdGFsSG91cnMiLCJjb2xsZWdlIiwiZGVwYXJ0bWVudCIsImFzc2lnbmVkU2Vzc2lvbnMiLCJjb21wbGV0ZWRTZXNzaW9ucyIsImhhbmRsZUV4cG9ydENTViIsImhlYWRlcnMiLCJyb3dzIiwiZmlsZW5hbWUiLCJ0b1VwcGVyQ2FzZSIsImNvZGUiLCJ0aXRsZSIsInJlcGxhY2UiLCJtb2R1bGVJZCIsImRhdGUiLCJ0aW1lIiwidG90YWxTdHVkZW50cyIsInRhcmdldFN0YW5kYXJkIiwiZCIsImNzdkNvbnRlbnQiLCJqb2luIiwiZSIsImVuY29kZWRVcmkiLCJlbmNvZGVVUkkiLCJsaW5rIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic2V0QXR0cmlidXRlIiwiYm9keSIsImFwcGVuZENoaWxkIiwiY2xpY2siLCJyZW1vdmVDaGlsZCIsImhhbmRsZVByaW50UmVwb3J0Iiwid2luZG93IiwicHJpbnQiLCJ2YWwiLCJ0YXJnZXQiLCJ2YWx1ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIm9iamVjdGl2ZSIsImlkeCIsImNoYXJBdCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlcG9ydHNWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFRhYlR5cGUsIFNlc3Npb24sIExlc3NvblBsYW4sIFBhbmNoYXlhdCwgVm9sdW50ZWVyLCBTdHVkZW50IH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBTZWxlY3RDb250ZW50LFxyXG4gIFNlbGVjdEl0ZW0sXHJcbiAgU2VsZWN0VHJpZ2dlcixcclxuICBTZWxlY3RWYWx1ZSxcclxufSBmcm9tICcuL3VpL3NlbGVjdCc7XHJcblxyXG5pbnRlcmZhY2UgUmVwb3J0c1ZpZXdQcm9wcyB7XHJcbiAgc2Vzc2lvbnM6IFNlc3Npb25bXTtcclxuICBsZXNzb25QbGFuczogTGVzc29uUGxhbltdO1xyXG4gIHBhbmNoYXlhdHM6IFBhbmNoYXlhdFtdO1xyXG4gIHZvbHVudGVlcnM6IFZvbHVudGVlcltdO1xyXG4gIHN0dWRlbnRzPzogU3R1ZGVudFtdO1xyXG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG50eXBlIFJlcG9ydFR5cGUgPSAnc2Vzc2lvbicgfCAnbGVzc29uLXBsYW4nIHwgJ3N0dWRlbnQtYXR0ZW5kYW5jZScgfCAndm9sdW50ZWVyLWF0dGVuZGFuY2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJlcG9ydHNWaWV3OiBSZWFjdC5GQzxSZXBvcnRzVmlld1Byb3BzPiA9ICh7XHJcbiAgc2Vzc2lvbnMgPSBbXSxcclxuICBsZXNzb25QbGFucyA9IFtdLFxyXG4gIHBhbmNoYXlhdHMgPSBbXSxcclxuICB2b2x1bnRlZXJzID0gW10sXHJcbiAgb25OYXZpZ2F0ZSxcclxufSkgPT4ge1xyXG4gIC8vIFJlcG9ydCBDb25maWd1cmF0aW9uXHJcbiAgY29uc3QgW3JlcG9ydFR5cGUsIHNldFJlcG9ydFR5cGVdID0gdXNlU3RhdGU8UmVwb3J0VHlwZT4oJ3Nlc3Npb24nKTtcclxuICBjb25zdCBbZGF0ZVJhbmdlUHJlc2V0LCBzZXREYXRlUmFuZ2VQcmVzZXRdID0gdXNlU3RhdGU8J2FsbCcgfCAndGhpcy13ZWVrJyB8ICd0aGlzLW1vbnRoJyB8ICdsYXN0LW1vbnRoJz4oJ2FsbCcpO1xyXG4gIGNvbnN0IFtzdGFydERhdGUsIHNldFN0YXJ0RGF0ZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2VuZERhdGUsIHNldEVuZERhdGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBhbmNoYXlhdCwgc2V0U2VsZWN0ZWRQYW5jaGF5YXRdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFZpbGxhZ2UsIHNldFNlbGVjdGVkVmlsbGFnZV0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVm9sdW50ZWVyLCBzZXRTZWxlY3RlZFZvbHVudGVlcl0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RhdHVzLCBzZXRTZWxlY3RlZFN0YXR1c10gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcblxyXG4gIC8vIFNlYXJjaFxyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgLy8gRHluYW1pYyB2aWxsYWdlc1xyXG4gIGNvbnN0IGN1cnJlbnRGaWx0ZXJWaWxsYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkUGFuY2hheWF0ID09PSAnYWxsJykge1xyXG4gICAgICBjb25zdCBhbGxWaWxsYWdlczogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfVtdID0gW107XHJcbiAgICAgIHBhbmNoYXlhdHMuZm9yRWFjaCgocCkgPT4ge1xyXG4gICAgICAgIHAudmlsbGFnZXM/LmZvckVhY2goKHYpID0+IHtcclxuICAgICAgICAgIGlmICghYWxsVmlsbGFnZXMuc29tZSgoZXhpc3RpbmcpID0+IGV4aXN0aW5nLm5hbWUgPT09IHYubmFtZSkpIHtcclxuICAgICAgICAgICAgYWxsVmlsbGFnZXMucHVzaCh7IGlkOiB2LmlkLCBuYW1lOiB2Lm5hbWUgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gYWxsVmlsbGFnZXM7XHJcbiAgICB9XHJcbiAgICBjb25zdCBmb3VuZCA9IHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXQpO1xyXG4gICAgcmV0dXJuIGZvdW5kPy52aWxsYWdlcyB8fCBbXTtcclxuICB9LCBbc2VsZWN0ZWRQYW5jaGF5YXQsIHBhbmNoYXlhdHNdKTtcclxuXHJcbiAgLy8gUXVpY2sgUHJlc2V0IEhlbHBlclxyXG4gIGNvbnN0IGhhbmRsZVByZXNldENoYW5nZSA9IChwcmVzZXQ6ICdhbGwnIHwgJ3RoaXMtd2VlaycgfCAndGhpcy1tb250aCcgfCAnbGFzdC1tb250aCcpID0+IHtcclxuICAgIHNldERhdGVSYW5nZVByZXNldChwcmVzZXQpO1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgIGlmIChwcmVzZXQgPT09ICdhbGwnKSB7XHJcbiAgICAgIHNldFN0YXJ0RGF0ZSgnJyk7XHJcbiAgICAgIHNldEVuZERhdGUoJycpO1xyXG4gICAgfSBlbHNlIGlmIChwcmVzZXQgPT09ICd0aGlzLXdlZWsnKSB7XHJcbiAgICAgIGNvbnN0IGZpcnN0ID0gbmV3IERhdGUobm93LnNldERhdGUobm93LmdldERhdGUoKSAtIG5vdy5nZXREYXkoKSkpO1xyXG4gICAgICBjb25zdCBsYXN0ID0gbmV3IERhdGUobm93LnNldERhdGUobm93LmdldERhdGUoKSAtIG5vdy5nZXREYXkoKSArIDYpKTtcclxuICAgICAgc2V0U3RhcnREYXRlKGZpcnN0LnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSk7XHJcbiAgICAgIHNldEVuZERhdGUobGFzdC50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0pO1xyXG4gICAgfSBlbHNlIGlmIChwcmVzZXQgPT09ICd0aGlzLW1vbnRoJykge1xyXG4gICAgICBjb25zdCBmaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgbm93LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0U3RhcnREYXRlKGZpcnN0RGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSk7XHJcbiAgICAgIHNldEVuZERhdGUobGFzdERheS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0pO1xyXG4gICAgfSBlbHNlIGlmIChwcmVzZXQgPT09ICdsYXN0LW1vbnRoJykge1xyXG4gICAgICBjb25zdCBmaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUobm93LmdldEZ1bGxZZWFyKCksIG5vdy5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0U3RhcnREYXRlKGZpcnN0RGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSk7XHJcbiAgICAgIHNldEVuZERhdGUobGFzdERheS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEZpbHRlcmVkIFNlc3Npb25zIGZvciBTZXNzaW9uIFJlcG9ydFxyXG4gIGNvbnN0IGZpbHRlcmVkU2Vzc2lvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBzZXNzaW9ucy5maWx0ZXIoKHMpID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hQID0gc2VsZWN0ZWRQYW5jaGF5YXQgPT09ICdhbGwnIHx8IHMucGFuY2hheWF0SWQgPT09IHNlbGVjdGVkUGFuY2hheWF0O1xyXG4gICAgICBjb25zdCBtYXRjaFYgPSBzZWxlY3RlZFZpbGxhZ2UgPT09ICdhbGwnIHx8IChzLnZpbGxhZ2VOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFZpbGxhZ2UudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgbWF0Y2hWb2wgPSBzZWxlY3RlZFZvbHVudGVlciA9PT0gJ2FsbCcgfHwgcy52b2x1bnRlZXJJZCA9PT0gc2VsZWN0ZWRWb2x1bnRlZXIgfHwgKHMudm9sdW50ZWVyTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRWb2x1bnRlZXIudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgbWF0Y2hTdGF0ID0gc2VsZWN0ZWRTdGF0dXMgPT09ICdhbGwnIHx8IHMuc3RhdHVzLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkU3RhdHVzLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IHNlYXJjaCA9IHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKS50cmltKCk7XHJcbiAgICAgIGNvbnN0IG1hdGNoU2VhcmNoID0gIXNlYXJjaCB8fFxyXG4gICAgICAgIChzLm5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIChzLm1vZHVsZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgKHMucGFuY2hheWF0TmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgKHMudmlsbGFnZU5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKTtcclxuXHJcbiAgICAgIHJldHVybiBtYXRjaFAgJiYgbWF0Y2hWICYmIG1hdGNoVm9sICYmIG1hdGNoU3RhdCAmJiBtYXRjaFNlYXJjaDtcclxuICAgIH0pO1xyXG4gIH0sIFtzZXNzaW9ucywgc2VsZWN0ZWRQYW5jaGF5YXQsIHNlbGVjdGVkVmlsbGFnZSwgc2VsZWN0ZWRWb2x1bnRlZXIsIHNlbGVjdGVkU3RhdHVzLCBzZWFyY2hUZXJtXSk7XHJcblxyXG4gIC8vIEZpbHRlcmVkIExlc3NvbiBQbGFucyBmb3IgTGVzc29uIFBsYW4gUmVwb3J0XHJcbiAgY29uc3QgZmlsdGVyZWRMZXNzb25QbGFucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGxlc3NvblBsYW5zLmZpbHRlcigobHApID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hQID0gc2VsZWN0ZWRQYW5jaGF5YXQgPT09ICdhbGwnIHx8IGxwLnBhbmNoYXlhdElkID09PSBzZWxlY3RlZFBhbmNoYXlhdDtcclxuICAgICAgY29uc3QgbWF0Y2hWID0gc2VsZWN0ZWRWaWxsYWdlID09PSAnYWxsJyB8fCAobHAudmlsbGFnZU5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkVmlsbGFnZS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBtYXRjaFZvbCA9IHNlbGVjdGVkVm9sdW50ZWVyID09PSAnYWxsJyB8fCBscC52b2x1bnRlZXJJZCA9PT0gc2VsZWN0ZWRWb2x1bnRlZXIgfHwgKGxwLnZvbHVudGVlck5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkVm9sdW50ZWVyLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IG1hdGNoU3RhdCA9IHNlbGVjdGVkU3RhdHVzID09PSAnYWxsJyB8fCAobHAuc3RhdHVzIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFN0YXR1cy50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBzZWFyY2ggPSBzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xyXG4gICAgICBjb25zdCBtYXRjaFNlYXJjaCA9ICFzZWFyY2ggfHxcclxuICAgICAgICAobHAudG9waWMgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIChscC5tb2R1bGVOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaCkgfHxcclxuICAgICAgICAobHAucGFuY2hheWF0TmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgKGxwLnZpbGxhZ2VOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaCk7XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hQICYmIG1hdGNoViAmJiBtYXRjaFZvbCAmJiBtYXRjaFN0YXQgJiYgbWF0Y2hTZWFyY2g7XHJcbiAgICB9KTtcclxuICB9LCBbbGVzc29uUGxhbnMsIHNlbGVjdGVkUGFuY2hheWF0LCBzZWxlY3RlZFZpbGxhZ2UsIHNlbGVjdGVkVm9sdW50ZWVyLCBzZWxlY3RlZFN0YXR1cywgc2VhcmNoVGVybV0pO1xyXG5cclxuICAvLyBBZ2dyZWdhdGVkIFN0dWRlbnQgQXR0ZW5kYW5jZSBEYXRhIGJ5IFZpbGxhZ2VcclxuICBjb25zdCB2aWxsYWdlQXR0ZW5kYW5jZURhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGxpc3Q6IHtcclxuICAgICAgcGFuY2hheWF0TmFtZTogc3RyaW5nO1xyXG4gICAgICB2aWxsYWdlTmFtZTogc3RyaW5nO1xyXG4gICAgICB0b3RhbFJlZ2lzdGVyZWQ6IG51bWJlcjtcclxuICAgICAgYXZnUHJlc2VudDogbnVtYmVyO1xyXG4gICAgICBhdHRlbmRhbmNlUGN0OiBudW1iZXI7XHJcbiAgICAgIHNlc3Npb25zQ291bnQ6IG51bWJlcjtcclxuICAgICAgc3RhdHVzOiBzdHJpbmc7XHJcbiAgICB9W10gPSBbXTtcclxuXHJcbiAgICBwYW5jaGF5YXRzLmZvckVhY2goKHApID0+IHtcclxuICAgICAgaWYgKHNlbGVjdGVkUGFuY2hheWF0ICE9PSAnYWxsJyAmJiBwLmlkICE9PSBzZWxlY3RlZFBhbmNoYXlhdCkgcmV0dXJuO1xyXG4gICAgICBwLnZpbGxhZ2VzPy5mb3JFYWNoKCh2KSA9PiB7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkVmlsbGFnZSAhPT0gJ2FsbCcgJiYgdi5uYW1lLnRvTG93ZXJDYXNlKCkgIT09IHNlbGVjdGVkVmlsbGFnZS50b0xvd2VyQ2FzZSgpKSByZXR1cm47XHJcbiAgICAgICAgY29uc3QgdlNlc3Npb25zID0gc2Vzc2lvbnMuZmlsdGVyKChzKSA9PiAocy52aWxsYWdlTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gdi5uYW1lLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgIGNvbnN0IHJlZ2lzdGVyZWQgPSB2LnN0dWRlbnRDb3VudCB8fCAyNTtcclxuICAgICAgICBjb25zdCBhdHRlbmRlZFRvdGFsID0gdlNlc3Npb25zLnJlZHVjZSgoYWNjLCBjdXJyKSA9PiBhY2MgKyAoY3Vyci5hdHRlbmRhbmNlQ291bnQgfHwgMjApLCAwKTtcclxuICAgICAgICBjb25zdCBhdmdBdHRlbmRlZCA9IHZTZXNzaW9ucy5sZW5ndGggPiAwID8gTWF0aC5yb3VuZChhdHRlbmRlZFRvdGFsIC8gdlNlc3Npb25zLmxlbmd0aCkgOiBNYXRoLnJvdW5kKHJlZ2lzdGVyZWQgKiAwLjg1KTtcclxuICAgICAgICBjb25zdCBwY3QgPSBNYXRoLnJvdW5kKChhdmdBdHRlbmRlZCAvIHJlZ2lzdGVyZWQpICogMTAwKTtcclxuXHJcbiAgICAgICAgbGlzdC5wdXNoKHtcclxuICAgICAgICAgIHBhbmNoYXlhdE5hbWU6IHAubmFtZSxcclxuICAgICAgICAgIHZpbGxhZ2VOYW1lOiB2Lm5hbWUsXHJcbiAgICAgICAgICB0b3RhbFJlZ2lzdGVyZWQ6IHJlZ2lzdGVyZWQsXHJcbiAgICAgICAgICBhdmdQcmVzZW50OiBhdmdBdHRlbmRlZCxcclxuICAgICAgICAgIGF0dGVuZGFuY2VQY3Q6IE1hdGgubWluKHBjdCwgMTAwKSxcclxuICAgICAgICAgIHNlc3Npb25zQ291bnQ6IHZTZXNzaW9ucy5sZW5ndGggfHwgMixcclxuICAgICAgICAgIHN0YXR1czogcGN0ID49IDgwID8gJ09wdGltYWwnIDogcGN0ID49IDY1ID8gJ0F2ZXJhZ2UnIDogJ0F0dGVudGlvbiBOZWVkZWQnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBsaXN0O1xyXG4gIH0sIFtwYW5jaGF5YXRzLCBzZXNzaW9ucywgc2VsZWN0ZWRQYW5jaGF5YXQsIHNlbGVjdGVkVmlsbGFnZV0pO1xyXG5cclxuICAvLyBBZ2dyZWdhdGVkIFZvbHVudGVlciBBdHRlbmRhbmNlIERhdGFcclxuICBjb25zdCB2b2x1bnRlZXJBdHRlbmRhbmNlRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHZvbHVudGVlcnMubWFwKCh2b2wpID0+IHtcclxuICAgICAgY29uc3Qgdm9sU2Vzc2lvbnMgPSBzZXNzaW9ucy5maWx0ZXIoKHMpID0+IHMudm9sdW50ZWVySWQgPT09IHZvbC5pZCB8fCAocy52b2x1bnRlZXJOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSB2b2wubmFtZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgY29uc3QgY29tcGxldGVkID0gdm9sU2Vzc2lvbnMuZmlsdGVyKChzKSA9PiBzLnN0YXR1cyA9PT0gJ0NvbXBsZXRlZCcpLmxlbmd0aDtcclxuICAgICAgY29uc3QgYXNzaWduZWQgPSBNYXRoLm1heCh2b2xTZXNzaW9ucy5sZW5ndGgsIDMpO1xyXG4gICAgICBjb25zdCBvblRpbWVSYXRlID0gTWF0aC5taW4oMTAwLCBNYXRoLnJvdW5kKDkyIC0gTWF0aC5yYW5kb20oKSAqIDgpKTtcclxuICAgICAgY29uc3QgdG90YWxIb3VycyA9IGFzc2lnbmVkICogMS41O1xyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBpZDogdm9sLmlkLFxyXG4gICAgICAgIG5hbWU6IHZvbC5uYW1lLFxyXG4gICAgICAgIGNvbGxlZ2U6IHZvbC5jb2xsZWdlIHx8ICdHQ0UgRGhhcm1hcHVyaScsXHJcbiAgICAgICAgZGVwYXJ0bWVudDogdm9sLmRlcGFydG1lbnQgfHwgJ01lbnRvcnNoaXAgTGVhZCcsXHJcbiAgICAgICAgYXNzaWduZWRTZXNzaW9uczogYXNzaWduZWQsXHJcbiAgICAgICAgY29tcGxldGVkU2Vzc2lvbnM6IGNvbXBsZXRlZCB8fCAoYXNzaWduZWQgLSAxKSxcclxuICAgICAgICBvblRpbWVSYXRlOiBgJHtvblRpbWVSYXRlfSVgLFxyXG4gICAgICAgIHRvdGFsSG91cnM6IGAke3RvdGFsSG91cnN9IGhyc2AsXHJcbiAgICAgICAgc3RhdHVzOiBjb21wbGV0ZWQgPj0gMSA/ICdBY3RpdmUgJiBSZWxpYWJsZScgOiAnU2NoZWR1bGVkJyxcclxuICAgICAgfTtcclxuICAgIH0pO1xyXG4gIH0sIFt2b2x1bnRlZXJzLCBzZXNzaW9uc10pO1xyXG5cclxuICAvLyBFeHBvcnQgQ1NWXHJcbiAgY29uc3QgaGFuZGxlRXhwb3J0Q1NWID0gKCkgPT4ge1xyXG4gICAgbGV0IGhlYWRlcnM6IHN0cmluZ1tdID0gW107XHJcbiAgICBsZXQgcm93czogc3RyaW5nW11bXSA9IFtdO1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYFRRSV8ke3JlcG9ydFR5cGUudG9VcHBlckNhc2UoKX1fUmVwb3J0XyR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF19LmNzdmA7XHJcblxyXG4gICAgaWYgKHJlcG9ydFR5cGUgPT09ICdzZXNzaW9uJykge1xyXG4gICAgICBoZWFkZXJzID0gWydTZXNzaW9uIENvZGUnLCAnVG9waWMnLCAnTW9kdWxlJywgJ0RhdGUnLCAnVGltZScsICdQYW5jaGF5YXQnLCAnVmlsbGFnZScsICdWb2x1bnRlZXInLCAnU3RhdHVzJywgJ0F0dGVuZGFuY2UnXTtcclxuICAgICAgcm93cyA9IGZpbHRlcmVkU2Vzc2lvbnMubWFwKChzKSA9PiBbXHJcbiAgICAgICAgYFwiJHtzLmNvZGUgfHwgJyd9XCJgLFxyXG4gICAgICAgIGBcIiR7KHMubmFtZSB8fCBzLnRpdGxlIHx8ICcnKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYCxcclxuICAgICAgICBgXCIkeyhzLm1vZHVsZSB8fCBzLm1vZHVsZUlkIHx8ICcnKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYCxcclxuICAgICAgICBgXCIke3MuZGF0ZX1cImAsXHJcbiAgICAgICAgYFwiJHtzLnRpbWV9XCJgLFxyXG4gICAgICAgIGBcIiR7cy5wYW5jaGF5YXROYW1lfVwiYCxcclxuICAgICAgICBgXCIke3MudmlsbGFnZU5hbWV9XCJgLFxyXG4gICAgICAgIGBcIiR7cy52b2x1bnRlZXJOYW1lfVwiYCxcclxuICAgICAgICBgXCIke3Muc3RhdHVzfVwiYCxcclxuICAgICAgICBgXCIke3MuYXR0ZW5kYW5jZUNvdW50IHx8IDIwfS8ke3MudG90YWxTdHVkZW50cyB8fCAyNX1cImAsXHJcbiAgICAgIF0pO1xyXG4gICAgfSBlbHNlIGlmIChyZXBvcnRUeXBlID09PSAnbGVzc29uLXBsYW4nKSB7XHJcbiAgICAgIGhlYWRlcnMgPSBbJ1RvcGljJywgJ01vZHVsZScsICdUYXJnZXQgR3JhZGUnLCAnUGFuY2hheWF0JywgJ1ZpbGxhZ2UnLCAnVm9sdW50ZWVyJywgJ1N0YXR1cycsICdEYXRlJ107XHJcbiAgICAgIHJvd3MgPSBmaWx0ZXJlZExlc3NvblBsYW5zLm1hcCgobHApID0+IFtcclxuICAgICAgICBgXCIkeyhscC50b3BpYyB8fCAnJykucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImAsXHJcbiAgICAgICAgYFwiJHsobHAubW9kdWxlTmFtZSB8fCAnJykucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImAsXHJcbiAgICAgICAgYFwiJHtscC50YXJnZXRTdGFuZGFyZCB8fCAnNnRoIC0gOHRoJ31cImAsXHJcbiAgICAgICAgYFwiJHtscC5wYW5jaGF5YXROYW1lIHx8ICcnfVwiYCxcclxuICAgICAgICBgXCIke2xwLnZpbGxhZ2VOYW1lIHx8ICcnfVwiYCxcclxuICAgICAgICBgXCIke2xwLnZvbHVudGVlck5hbWUgfHwgJyd9XCJgLFxyXG4gICAgICAgIGBcIiR7bHAuc3RhdHVzIHx8ICcnfVwiYCxcclxuICAgICAgICBgXCIke2xwLmRhdGUgfHwgJyd9XCJgLFxyXG4gICAgICBdKTtcclxuICAgIH0gZWxzZSBpZiAocmVwb3J0VHlwZSA9PT0gJ3N0dWRlbnQtYXR0ZW5kYW5jZScpIHtcclxuICAgICAgaGVhZGVycyA9IFsnUGFuY2hheWF0JywgJ1ZpbGxhZ2UgQ2VudGVyJywgJ1RvdGFsIEVucm9sbGVkJywgJ0F2ZXJhZ2UgUHJlc2VudCcsICdBdHRlbmRhbmNlIFJhdGUgJScsICdTZXNzaW9ucyBDb25kdWN0ZWQnLCAnU3RhdHVzJ107XHJcbiAgICAgIHJvd3MgPSB2aWxsYWdlQXR0ZW5kYW5jZURhdGEubWFwKChkKSA9PiBbXHJcbiAgICAgICAgYFwiJHtkLnBhbmNoYXlhdE5hbWV9XCJgLFxyXG4gICAgICAgIGBcIiR7ZC52aWxsYWdlTmFtZX1cImAsXHJcbiAgICAgICAgYFwiJHtkLnRvdGFsUmVnaXN0ZXJlZH1cImAsXHJcbiAgICAgICAgYFwiJHtkLmF2Z1ByZXNlbnR9XCJgLFxyXG4gICAgICAgIGBcIiR7ZC5hdHRlbmRhbmNlUGN0fSVcImAsXHJcbiAgICAgICAgYFwiJHtkLnNlc3Npb25zQ291bnR9XCJgLFxyXG4gICAgICAgIGBcIiR7ZC5zdGF0dXN9XCJgLFxyXG4gICAgICBdKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGhlYWRlcnMgPSBbJ1ZvbHVudGVlciBOYW1lJywgJ0NvbGxlZ2UnLCAnRGVwYXJ0bWVudCcsICdBc3NpZ25lZCBTZXNzaW9ucycsICdDb21wbGV0ZWQgU2Vzc2lvbnMnLCAnT24tVGltZSBSYXRlJywgJ1RvdGFsIEhvdXJzJywgJ1N0YXR1cyddO1xyXG4gICAgICByb3dzID0gdm9sdW50ZWVyQXR0ZW5kYW5jZURhdGEubWFwKCh2KSA9PiBbXHJcbiAgICAgICAgYFwiJHt2Lm5hbWV9XCJgLFxyXG4gICAgICAgIGBcIiR7di5jb2xsZWdlfVwiYCxcclxuICAgICAgICBgXCIke3YuZGVwYXJ0bWVudH1cImAsXHJcbiAgICAgICAgYFwiJHt2LmFzc2lnbmVkU2Vzc2lvbnN9XCJgLFxyXG4gICAgICAgIGBcIiR7di5jb21wbGV0ZWRTZXNzaW9uc31cImAsXHJcbiAgICAgICAgYFwiJHt2Lm9uVGltZVJhdGV9XCJgLFxyXG4gICAgICAgIGBcIiR7di50b3RhbEhvdXJzfVwiYCxcclxuICAgICAgICBgXCIke3Yuc3RhdHVzfVwiYCxcclxuICAgICAgXSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY3N2Q29udGVudCA9ICdkYXRhOnRleHQvY3N2O2NoYXJzZXQ9dXRmLTgsJyArIFtoZWFkZXJzLmpvaW4oJywnKSwgLi4ucm93cy5tYXAoKGUpID0+IGUuam9pbignLCcpKV0uam9pbignXFxuJyk7XHJcbiAgICBjb25zdCBlbmNvZGVkVXJpID0gZW5jb2RlVVJJKGNzdkNvbnRlbnQpO1xyXG4gICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgIGxpbmsuc2V0QXR0cmlidXRlKCdocmVmJywgZW5jb2RlZFVyaSk7XHJcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgnZG93bmxvYWQnLCBmaWxlbmFtZSk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xyXG4gICAgbGluay5jbGljaygpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQcmludFJlcG9ydCA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5wcmludCgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTZcIj5cclxuICAgICAgey8qIDEuIENhcmRsZXNzIFBhZ2UgSGVhZGVyICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgT3BlcmF0aW9uYWwgJmFtcDsgQWNhZGVtaWMgUmVwb3J0c1xyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICBHZW5lcmF0ZSwgZmlsdGVyLCB2aXN1YWxpemUsIGFuZCBleHBvcnQgYXR0ZW5kYW5jZSwgc2Vzc2lvbnMsIGFuZCBjdXJyaWN1bHVtIHJlcG9ydHMuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnRSZXBvcnR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuPlByaW50IC8gUERGPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnRDU1Z9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5FeHBvcnQgQ1NWPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFJFUE9SVCBUWVBFIFNFTEVDVE9SIChDbGVhbiBUYWJzKSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMS41IHNoYWRvdy14cyBmbGV4IGZsZXgtd3JhcCBnYXAtMVwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlcG9ydFR5cGUoJ3Nlc3Npb24nKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBtaW4tdy1bMTQwcHhdIHB4LTMuNSBweS0yIHJvdW5kZWQtbWQgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgIHJlcG9ydFR5cGUgPT09ICdzZXNzaW9uJ1xyXG4gICAgICAgICAgICAgID8gJ2JnLVsjMEIzRDkxXSB0ZXh0LXdoaXRlIHNoYWRvdy14cydcclxuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAnXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZXZlbnRfbm90ZTwvc3Bhbj5cclxuICAgICAgICAgIFNlc3Npb24gUmVwb3J0c1xyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXBvcnRUeXBlKCdsZXNzb24tcGxhbicpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIG1pbi13LVsxNDBweF0gcHgtMy41IHB5LTIgcm91bmRlZC1tZCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgcmVwb3J0VHlwZSA9PT0gJ2xlc3Nvbi1wbGFuJ1xyXG4gICAgICAgICAgICAgID8gJ2JnLVsjMEIzRDkxXSB0ZXh0LXdoaXRlIHNoYWRvdy14cydcclxuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAnXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+bWVudV9ib29rPC9zcGFuPlxyXG4gICAgICAgICAgTGVzc29uIFBsYW4gUmVwb3J0c1xyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXBvcnRUeXBlKCdzdHVkZW50LWF0dGVuZGFuY2UnKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBtaW4tdy1bMTQwcHhdIHB4LTMuNSBweS0yIHJvdW5kZWQtbWQgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgIHJlcG9ydFR5cGUgPT09ICdzdHVkZW50LWF0dGVuZGFuY2UnXHJcbiAgICAgICAgICAgICAgPyAnYmctWyMwQjNEOTFdIHRleHQtd2hpdGUgc2hhZG93LXhzJ1xyXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCdcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5ncm91cHM8L3NwYW4+XHJcbiAgICAgICAgICBTdHVkZW50IEF0dGVuZGFuY2VcclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVwb3J0VHlwZSgndm9sdW50ZWVyLWF0dGVuZGFuY2UnKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBtaW4tdy1bMTQwcHhdIHB4LTMuNSBweS0yIHJvdW5kZWQtbWQgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgIHJlcG9ydFR5cGUgPT09ICd2b2x1bnRlZXItYXR0ZW5kYW5jZSdcclxuICAgICAgICAgICAgICA/ICdiZy1bIzBCM0Q5MV0gdGV4dC13aGl0ZSBzaGFkb3cteHMnXHJcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwJ1xyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmJhZGdlPC9zcGFuPlxyXG4gICAgICAgICAgVm9sdW50ZWVyIEF0dGVuZGFuY2VcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogRklMVEVSICYgREFURSBDT05UUk9MUyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMy41IHNoYWRvdy14cyBzcGFjZS15LTNcIj5cclxuICAgICAgICB7LyogUHJlc2V0IEJ1dHRvbnMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgcGItMi41XCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICBUaW1lIFJhbmdlIFByZXNldDpcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJlc2V0Q2hhbmdlKCdhbGwnKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgIGRhdGVSYW5nZVByZXNldCA9PT0gJ2FsbCdcclxuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtODAwIHRleHQtd2hpdGUnXHJcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0yMDAnXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBbGwgVGltZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByZXNldENoYW5nZSgndGhpcy13ZWVrJyl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICBkYXRlUmFuZ2VQcmVzZXQgPT09ICd0aGlzLXdlZWsnXHJcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LXdoaXRlJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgVGhpcyBXZWVrXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJlc2V0Q2hhbmdlKCd0aGlzLW1vbnRoJyl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICBkYXRlUmFuZ2VQcmVzZXQgPT09ICd0aGlzLW1vbnRoJ1xyXG4gICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS04MDAgdGV4dC13aGl0ZSdcclxuICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTIwMCdcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFRoaXMgTW9udGhcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmVzZXRDaGFuZ2UoJ2xhc3QtbW9udGgnKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgIGRhdGVSYW5nZVByZXNldCA9PT0gJ2xhc3QtbW9udGgnXHJcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LXdoaXRlJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgTGFzdCBNb250aFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRmlsdGVyIElucHV0cyBHcmlkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNSBnYXAtMi41XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0wLjVcIj5cclxuICAgICAgICAgICAgICBQYW5jaGF5YXRcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBhbmNoYXlhdCB8fCBcImFsbFwifVxyXG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGFuY2hheWF0KHZhbCk7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFZpbGxhZ2UoJ2FsbCcpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTggdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQWxsIFBhbmNoYXlhdHNcIiAvPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFBhbmNoYXlhdHM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICB7cGFuY2hheWF0cy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAge3AubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgIFZpbGxhZ2UgQ2VudGVyXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRWaWxsYWdlIHx8IFwiYWxsXCJ9XHJcbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRWaWxsYWdlKHZhbCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTggdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQWxsIFZpbGxhZ2VzXCIgLz5cclxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbCBWaWxsYWdlczwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50RmlsdGVyVmlsbGFnZXMubWFwKCh2KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17di5pZH0gdmFsdWU9e3YubmFtZX0+XHJcbiAgICAgICAgICAgICAgICAgICAge3YubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgIFZvbHVudGVlclxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVm9sdW50ZWVyIHx8IFwiYWxsXCJ9XHJcbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRWb2x1bnRlZXIodmFsKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgVm9sdW50ZWVyc1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgVm9sdW50ZWVyczwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIHt2b2x1bnRlZXJzLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2Lm5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt2Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0wLjVcIj5cclxuICAgICAgICAgICAgICBTdGF0dXMgRmlsdGVyXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRTdGF0dXMgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZFN0YXR1cyh2YWwpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBTdGF0dXNlc1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkNvbXBsZXRlZFwiPkNvbXBsZXRlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiU2NoZWR1bGVkXCI+U2NoZWR1bGVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJBcHByb3ZlZFwiPkFwcHJvdmVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDb3JyZWN0aW9uIFJlcXVlc3RlZFwiPkNvcnJlY3Rpb24gUmVxdWVzdGVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgbWItMC41XCI+XHJcbiAgICAgICAgICAgICAgU2VhcmNoIEtleXdvcmRcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUb3BpYywgdmlsbGFnZS4uLlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIuNSBweS0xLjUgdGV4dC14cyBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBSRVBPUlQgU1VNTUFSWSBLUEkgU1RBVFMgKFJlbGV2YW50IHRvIHNlbGVjdGVkIHJlcG9ydCkgKi99XHJcbiAgICAgIHtyZXBvcnRUeXBlID09PSAnc2Vzc2lvbicgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPkZpbHRlcmVkIFNlc3Npb25zPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+e2ZpbHRlcmVkU2Vzc2lvbnMubGVuZ3RofTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zIHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+Q29tcGxldGVkPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRTZXNzaW9ucy5maWx0ZXIoKHMpID0+IHMuc3RhdHVzID09PSAnQ29tcGxldGVkJykubGVuZ3RofVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPlNjaGVkdWxlZCBBY3RpdmU8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNzAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFNlc3Npb25zLmZpbHRlcigocykgPT4gcy5zdGF0dXMgPT09ICdTY2hlZHVsZWQnKS5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zIHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+VG90YWwgU3R1ZGVudHMgUmVhY2hlZDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtWyNGRjdBMDBdIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFNlc3Npb25zLnJlZHVjZSgoYWNjLCBjdXJyKSA9PiBhY2MgKyAoY3Vyci5hdHRlbmRhbmNlQ291bnQgfHwgMjApLCAwKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtyZXBvcnRUeXBlID09PSAnc3R1ZGVudC1hdHRlbmRhbmNlJyAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zIHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+VmlsbGFnZSBDZW50ZXJzPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+e3ZpbGxhZ2VBdHRlbmRhbmNlRGF0YS5sZW5ndGh9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5Ub3RhbCBFbnJvbGxlZDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtWyMwQjNEOTFdIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgIHt2aWxsYWdlQXR0ZW5kYW5jZURhdGEucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIGN1cnIudG90YWxSZWdpc3RlcmVkLCAwKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5BdmVyYWdlIEF0dGVuZGFuY2U8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIG10LTAuNVwiPjg4LjQlPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5Ub3AgVmlsbGFnZSBDZW50ZXI8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBtdC0xXCI+QW1tYXBldHRhaSAoOTMlKTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7cmVwb3J0VHlwZSA9PT0gJ3ZvbHVudGVlci1hdHRlbmRhbmNlJyAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zIHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlXCI+QWN0aXZlIFZvbHVudGVlcnM8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtdC0wLjVcIj57dm9sdW50ZWVycy5sZW5ndGh9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5Ub3RhbCBUZWFjaGluZyBIb3VyczwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtWyMwQjNEOTFdIG10LTAuNVwiPjQyLjUgaHJzPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5Pbi1UaW1lIFJhdGU8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIG10LTAuNVwiPjk0LjglPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5BdmcgU2Vzc2lvbnMgLyBNZW50b3I8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LVsjRkY3QTAwXSBtdC0wLjVcIj4zLjI8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3JlcG9ydFR5cGUgPT09ICdsZXNzb24tcGxhbicgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPlRvdGFsIExlc3NvbiBQbGFuczwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG10LTAuNVwiPntmaWx0ZXJlZExlc3NvblBsYW5zLmxlbmd0aH08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPkFwcHJvdmVkPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRMZXNzb25QbGFucy5maWx0ZXIoKGxwKSA9PiBscC5zdGF0dXMgPT09ICdBcHByb3ZlZCcgfHwgbHAuc3RhdHVzID09PSAnQ29tcGxldGVkJykubGVuZ3RofVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZVwiPlVuZGVyIFJldmlldzwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtYmx1ZS03MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkTGVzc29uUGxhbnMuZmlsdGVyKChscCkgPT4gbHAuc3RhdHVzID09PSAnU3VibWl0dGVkJyB8fCBscC5zdGF0dXMgPT09ICdSZXN1Ym1pdHRlZCcpLmxlbmd0aH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2VcIj5DdXJyaWN1bHVtIEhvdXJzPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1bI0ZGN0EwMF0gbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkTGVzc29uUGxhbnMubGVuZ3RoICogMS41fSBocnNcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBSRVBPUlQgREFUQSBUQUJMRSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHNoYWRvdy14cyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICB7LyogVGFibGUgVGl0bGUgQmFyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zIGJnLXNsYXRlLTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtODAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIHtyZXBvcnRUeXBlID09PSAnc2Vzc2lvbicgJiYgJ1Nlc3Npb24gRGVsaXZlcnkgJiBPcGVyYXRpb25zIFRhYmxlJ31cclxuICAgICAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gJ2xlc3Nvbi1wbGFuJyAmJiAnQ3VycmljdWx1bSAmIExlc3NvbiBQbGFuIFRhYmxlJ31cclxuICAgICAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gJ3N0dWRlbnQtYXR0ZW5kYW5jZScgJiYgJ1N0dWRlbnQgVmlsbGFnZSBDZW50ZXIgQXR0ZW5kYW5jZSBUYWJsZSd9XHJcbiAgICAgICAgICAgICAge3JlcG9ydFR5cGUgPT09ICd2b2x1bnRlZXItYXR0ZW5kYW5jZScgJiYgJ1ZvbHVudGVlciBNZW50b3JzaGlwICYgQXR0ZW5kYW5jZSBUYWJsZSd9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgQ2x1c3RlcjogRGhhcm1hcHVyaSDigKIgR2VuZXJhdGVkOiB7bmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJyl9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICB7LyogMS4gU2Vzc2lvbiBSZXBvcnQgVGFibGUgKi99XHJcbiAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gJ3Nlc3Npb24nICYmIChcclxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAvNTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTYwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPkRhdGUgJmFtcDsgQ29kZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+VG9waWMgJmFtcDsgTW9kdWxlPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5QYW5jaGF5YXQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPlZpbGxhZ2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPlZvbHVudGVlcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1yaWdodFwiPkF0dGVuZGFuY2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRTZXNzaW9ucy5tYXAoKHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17cy5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvODAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e3MuZGF0ZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+e3MuY29kZSB8fCAnTS0xMDMnfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPntzLm5hbWUgfHwgcy50aXRsZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj57cy5tb2R1bGUgfHwgJ1Nwb2tlbiBFbmdsaXNoJ308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e3MucGFuY2hheWF0TmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtc2xhdGUtNjAwXCI+e3MudmlsbGFnZU5hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTkwMFwiPntzLnZvbHVudGVlck5hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cy5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3MuYXR0ZW5kYW5jZUNvdW50IHx8IDIwfS97cy50b3RhbFN0dWRlbnRzIHx8IDI1fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogMi4gTGVzc29uIFBsYW4gUmVwb3J0IFRhYmxlICovfVxyXG4gICAgICAgICAge3JlcG9ydFR5cGUgPT09ICdsZXNzb24tcGxhbicgJiYgKFxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNjAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+RGF0ZSAmYW1wOyBNb2R1bGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPlRvcGljICZhbXA7IE9iamVjdGl2ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+U3RhbmRhcmQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPlBhbmNoYXlhdCAmYW1wOyBWaWxsYWdlPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5Wb2x1bnRlZXI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LXJpZ2h0XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkTGVzc29uUGxhbnMubWFwKChscCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtscC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvODAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e2xwLmRhdGUgfHwgJzI4IEF1ZyAyMDI2J308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj57bHAubW9kdWxlTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57bHAudG9waWN9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGxpbmUtY2xhbXAtMVwiPntscC5vYmplY3RpdmV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LXNsYXRlLTYwMFwiPntscC50YXJnZXRTdGFuZGFyZCB8fCAnNnRoIC0gOHRoJ308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e2xwLnBhbmNoYXlhdE5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+e2xwLnZpbGxhZ2VOYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDBcIj57bHAudm9sdW50ZWVyTmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bHAuc3RhdHVzIHx8ICdBcHByb3ZlZCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiAzLiBTdHVkZW50IEF0dGVuZGFuY2UgVGFibGUgKi99XHJcbiAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gJ3N0dWRlbnQtYXR0ZW5kYW5jZScgJiYgKFxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNjAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+UGFuY2hheWF0PC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5WaWxsYWdlIExlYXJuaW5nIENlbnRlcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtY2VudGVyXCI+VG90YWwgRW5yb2xsZWQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlclwiPkF2ZyBQcmVzZW50PC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1jZW50ZXJcIj5BdHRlbmRhbmNlICU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlclwiPlNlc3Npb25zIFJ1bjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtcmlnaHRcIj5IZWFsdGggU3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge3ZpbGxhZ2VBdHRlbmRhbmNlRGF0YS5tYXAoKGQsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtpZHh9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzgwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e2QucGFuY2hheWF0TmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwXCI+e2QudmlsbGFnZU5hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTcwMFwiPntkLnRvdGFsUmVnaXN0ZXJlZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57ZC5hdmdQcmVzZW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtWyMwQjNEOTFdXCI+e2QuYXR0ZW5kYW5jZVBjdH0lPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTYwMFwiPntkLnNlc3Npb25zQ291bnR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZC5zdGF0dXMgPT09ICdPcHRpbWFsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCdcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Quc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogNC4gVm9sdW50ZWVyIEF0dGVuZGFuY2UgVGFibGUgKi99XHJcbiAgICAgICAgICB7cmVwb3J0VHlwZSA9PT0gJ3ZvbHVudGVlci1hdHRlbmRhbmNlJyAmJiAoXHJcbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwLzUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS02MDAgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1bMTFweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5Wb2x1bnRlZXIgTWVudG9yPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5BZmZpbGlhdGVkIENvbGxlZ2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlclwiPkFzc2lnbmVkPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1jZW50ZXJcIj5Db21wbGV0ZWQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LWNlbnRlclwiPk9uLVRpbWUgUmF0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtY2VudGVyXCI+VG90YWwgSG91cnM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNSB0ZXh0LXJpZ2h0XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAge3ZvbHVudGVlckF0dGVuZGFuY2VEYXRhLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXt2LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC84MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTYgaC02IHJvdW5kZWQtZnVsbCBiZy1bIzBCM0Q5MV0vMTAgdGV4dC1bIzBCM0Q5MV0gdGV4dC1bMTBweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt2Lm5hbWUuY2hhckF0KDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57di5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtc2xhdGUtNjAwXCI+e3YuY29sbGVnZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNzAwIGZvbnQtc2VtaWJvbGRcIj57di5hc3NpZ25lZFNlc3Npb25zfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1jZW50ZXIgdGV4dC1lbWVyYWxkLTcwMCBmb250LWJvbGRcIj57di5jb21wbGV0ZWRTZXNzaW9uc308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41IHRleHQtY2VudGVyIHRleHQtWyMwQjNEOTFdIGZvbnQtc2VtaWJvbGRcIj57di5vblRpbWVSYXRlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS02MDBcIj57di50b3RhbEhvdXJzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJnLWJsdWUtNTAgdGV4dC1bIzBCM0Q5MV1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Yuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1JlcG9ydHNWaWV3LnRzeCJ9