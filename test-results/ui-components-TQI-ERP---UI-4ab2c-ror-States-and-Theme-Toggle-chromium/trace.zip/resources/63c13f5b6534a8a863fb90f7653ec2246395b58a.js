import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\NewFinanceModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { BillScannerModal } from "/src/components/BillScannerModal.tsx";
import {
  X,
  Save,
  Send,
  Plus,
  Trash2,
  Upload,
  Camera,
  Car,
  Utensils,
  BookOpen,
  Sparkles,
  FileSpreadsheet,
  CheckCircle2,
  ReceiptIndianRupee
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const NewFinanceModal = ({
  isOpen,
  onClose,
  clusterName = "Dharmapuri",
  collegeName = "K.S.Rangasamy college of Technology",
  spocName = "Narendhar",
  financerName = "TQI Finance Team",
  initialDraft = null,
  onSubmitFinance,
  onSaveDraftPackage
}) => {
  _s();
  const [sessionDay, setSessionDay] = useState(initialDraft?.sessionDay || "Day 1");
  const [sessionDate, setSessionDate] = useState(initialDraft?.sessionDate || "2026-08-20");
  const [activeTab, setActiveTab] = useState("Travel");
  const [scannerTarget, setScannerTarget] = useState(null);
  const [routes, setRoutes] = useState(
    initialDraft?.routes || [
      {
        id: "route-1",
        from: "",
        to: "",
        volunteers: 0,
        perPerson: 0,
        remarks: "",
        bill: null
      }
    ]
  );
  const [food, setFood] = useState(
    initialDraft?.food || {
      breakfast: { amount: 0, remarks: "", bill: null },
      lunch: { amount: 0, remarks: "", bill: null },
      dinner: { amount: 0, remarks: "", bill: null },
      refreshments: { amount: 0, remarks: "", bill: null }
    }
  );
  const [stationery, setStationery] = useState(
    initialDraft?.stationery || {
      amount: 0,
      remarks: "",
      bill: null
    }
  );
  const [otherItems, setOtherItems] = useState(
    initialDraft?.otherItems || [
      {
        id: "other-1",
        description: "",
        amount: 0,
        remarks: "",
        bill: null
      }
    ]
  );
  useEffect(() => {
    if (initialDraft) {
      if (initialDraft.sessionDay) setSessionDay(initialDraft.sessionDay);
      if (initialDraft.sessionDate) setSessionDate(initialDraft.sessionDate);
      if (initialDraft.routes) setRoutes(initialDraft.routes);
      if (initialDraft.food) setFood(initialDraft.food);
      if (initialDraft.stationery) setStationery(initialDraft.stationery);
      if (initialDraft.otherItems) setOtherItems(initialDraft.otherItems);
    } else {
      setSessionDay("Day 1");
      setRoutes(
        [
          {
            id: "route-1",
            from: "",
            to: "",
            volunteers: 0,
            perPerson: 0,
            remarks: "",
            bill: null
          }
        ]
      );
      setFood({
        breakfast: { amount: 0, remarks: "", bill: null },
        lunch: { amount: 0, remarks: "", bill: null },
        dinner: { amount: 0, remarks: "", bill: null },
        refreshments: { amount: 0, remarks: "", bill: null }
      });
      setStationery({
        amount: 0,
        remarks: "",
        bill: null
      });
      setOtherItems(
        [
          {
            id: "other-1",
            description: "",
            amount: 0,
            remarks: "",
            bill: null
          }
        ]
      );
    }
  }, [initialDraft, isOpen]);
  const travelTotal = useMemo(() => {
    return routes.reduce((sum, r) => sum + (r.volunteers || 0) * (r.perPerson || 0), 0);
  }, [routes]);
  const foodTotal = useMemo(() => {
    return (food.breakfast.amount || 0) + (food.lunch.amount || 0) + (food.dinner.amount || 0) + (food.refreshments.amount || 0);
  }, [food]);
  const stationeryTotal = useMemo(() => {
    return stationery.amount || 0;
  }, [stationery]);
  const otherTotal = useMemo(() => {
    return otherItems.reduce((sum, item) => sum + (item.amount || 0), 0);
  }, [otherItems]);
  const grandTotal = travelTotal + foodTotal + stationeryTotal + otherTotal;
  const handleAddRoute = () => {
    const newRoute = {
      id: `route-${Date.now()}`,
      from: "",
      to: "",
      volunteers: 0,
      perPerson: 0,
      remarks: "",
      bill: null
    };
    setRoutes((prev) => [...prev, newRoute]);
  };
  const handleUpdateRoute = (id, field, value) => {
    setRoutes(
      (prev) => prev.map((r) => r.id === id ? { ...r, [field]: value } : r)
    );
  };
  const handleRemoveRoute = (id) => {
    if (routes.length <= 1) {
      setRoutes(
        [
          {
            id: `route-${Date.now()}`,
            from: "",
            to: "",
            volunteers: 0,
            perPerson: 0,
            remarks: "",
            bill: null
          }
        ]
      );
      return;
    }
    setRoutes((prev) => prev.filter((r) => r.id !== id));
  };
  const handleAddOther = () => {
    const newItem = {
      id: `other-${Date.now()}`,
      description: "",
      amount: 0,
      remarks: "",
      bill: null
    };
    setOtherItems((prev) => [...prev, newItem]);
  };
  const handleUpdateOther = (id, field, value) => {
    setOtherItems(
      (prev) => prev.map((item) => item.id === id ? { ...item, [field]: value } : item)
    );
  };
  const handleRemoveOther = (id) => {
    if (otherItems.length <= 1) {
      setOtherItems(
        [
          {
            id: `other-${Date.now()}`,
            description: "",
            amount: 0,
            remarks: "",
            bill: null
          }
        ]
      );
      return;
    }
    setOtherItems((prev) => prev.filter((item) => item.id !== id));
  };
  const handleDirectFileUpload = (e, type, id, foodKey, currentAmount) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          const attachment = {
            url: reader.result,
            fileName: file.name,
            detectedAmount: currentAmount || 0,
            isVerified: true
          };
          attachBillToTarget(type, attachment, id, foodKey);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  const attachBillToTarget = (type, bill, id, foodKey) => {
    if (type === "travel" && id) {
      setRoutes(
        (prev) => prev.map((r) => {
          if (r.id === id) {
            let updated = { ...r, bill };
            if (bill.origin && (!r.from || r.from === "")) {
              updated.from = bill.origin;
            }
            if (bill.destination && (!r.to || r.to === "")) {
              updated.to = bill.destination;
            }
            if (bill.detectedAmount && bill.detectedAmount > 0) {
              if (updated.volunteers > 0) {
                updated.perPerson = Math.round(bill.detectedAmount / updated.volunteers);
              } else {
                updated.volunteers = 1;
                updated.perPerson = bill.detectedAmount;
              }
            }
            if (!updated.remarks && (bill.origin || bill.destination)) {
              updated.remarks = `Ticket Route: ${bill.origin || "Origin"} to ${bill.destination || "Destination"}`;
            }
            return updated;
          }
          return r;
        })
      );
    } else if (type === "food" && foodKey) {
      setFood((prev) => ({
        ...prev,
        [foodKey]: {
          ...prev[foodKey],
          bill,
          amount: prev[foodKey].amount === 0 && bill.detectedAmount ? bill.detectedAmount : prev[foodKey].amount
        }
      }));
    } else if (type === "stationery") {
      setStationery((prev) => ({
        ...prev,
        bill,
        amount: prev.amount === 0 && bill.detectedAmount ? bill.detectedAmount : prev.amount
      }));
    } else if (type === "other" && id) {
      setOtherItems(
        (prev) => prev.map((item) => {
          if (item.id === id) {
            return {
              ...item,
              bill,
              amount: item.amount === 0 && bill.detectedAmount ? bill.detectedAmount : item.amount
            };
          }
          return item;
        })
      );
    }
  };
  const handleSubmit = (isDraft) => {
    const entries = [];
    const draftId = initialDraft?.id || `draft-${sessionDay.toLowerCase().replace(/\s+/g, "")}-${Date.now()}`;
    routes.forEach((r) => {
      const amt = (r.volunteers || 0) * (r.perPerson || 0);
      if (amt > 0 || r.from || r.to) {
        entries.push({
          date: sessionDate,
          description: `Travel: ${r.from || "Origin"} → ${r.to || "Destination"} (${r.volunteers} vols × ₹${r.perPerson})`,
          category: "Travel",
          amount: amt,
          panchayatId: "dharmapuri-main",
          panchayatName: clusterName,
          villageName: r.to || "Cluster Center",
          status: isDraft ? "Draft" : "Approved",
          billUrl: r.bill?.url,
          remarks: r.remarks || `${r.volunteers} Volunteers travel reimbursement`,
          count: r.volunteers,
          countAmount: `${r.volunteers}×${r.perPerson}`,
          sessionDay,
          draftId: isDraft ? draftId : void 0
        });
      }
    });
    if (food.breakfast.amount > 0) {
      entries.push({
        date: sessionDate,
        description: `Food: Breakfast (${sessionDay})`,
        category: "Food",
        amount: food.breakfast.amount,
        panchayatId: "dharmapuri-main",
        panchayatName: clusterName,
        villageName: "Cluster Center",
        status: isDraft ? "Draft" : "Approved",
        billUrl: food.breakfast.bill?.url,
        remarks: food.breakfast.remarks || "Volunteer breakfast",
        sessionDay,
        draftId: isDraft ? draftId : void 0
      });
    }
    if (food.lunch.amount > 0) {
      entries.push({
        date: sessionDate,
        description: `Food: Lunch (${sessionDay})`,
        category: "Food",
        amount: food.lunch.amount,
        panchayatId: "dharmapuri-main",
        panchayatName: clusterName,
        villageName: "Cluster Center",
        status: isDraft ? "Draft" : "Approved",
        billUrl: food.lunch.bill?.url,
        remarks: food.lunch.remarks || "Volunteer lunch meals",
        sessionDay,
        draftId: isDraft ? draftId : void 0
      });
    }
    if (food.dinner.amount > 0) {
      entries.push({
        date: sessionDate,
        description: `Food: Dinner (${sessionDay})`,
        category: "Food",
        amount: food.dinner.amount,
        panchayatId: "dharmapuri-main",
        panchayatName: clusterName,
        villageName: "Cluster Center",
        status: isDraft ? "Draft" : "Approved",
        billUrl: food.dinner.bill?.url,
        remarks: food.dinner.remarks || "Volunteer dinner",
        sessionDay,
        draftId: isDraft ? draftId : void 0
      });
    }
    if (food.refreshments.amount > 0) {
      entries.push({
        date: sessionDate,
        description: `Food: Refreshments & Tea (${sessionDay})`,
        category: "Food",
        amount: food.refreshments.amount,
        panchayatId: "dharmapuri-main",
        panchayatName: clusterName,
        villageName: "Cluster Center",
        status: isDraft ? "Draft" : "Approved",
        billUrl: food.refreshments.bill?.url,
        remarks: food.refreshments.remarks || "Snacks and tea",
        sessionDay,
        draftId: isDraft ? draftId : void 0
      });
    }
    if (stationery.amount > 0) {
      entries.push({
        date: sessionDate,
        description: `Stationery: Materials & Notebooks (${sessionDay})`,
        category: "Materials",
        amount: stationery.amount,
        panchayatId: "dharmapuri-main",
        panchayatName: clusterName,
        villageName: "Cluster Center",
        status: isDraft ? "Draft" : "Approved",
        billUrl: stationery.bill?.url,
        remarks: stationery.remarks || "Classroom student stationery kits",
        sessionDay,
        draftId: isDraft ? draftId : void 0
      });
    }
    otherItems.forEach((item) => {
      if (item.amount > 0 || item.description) {
        entries.push({
          date: sessionDate,
          description: `Other: ${item.description || "Miscellaneous Expense"}`,
          category: "Other",
          amount: item.amount || 0,
          panchayatId: "dharmapuri-main",
          panchayatName: clusterName,
          villageName: "Cluster Center",
          status: isDraft ? "Draft" : "Approved",
          billUrl: item.bill?.url,
          remarks: item.remarks || item.description,
          sessionDay,
          draftId: isDraft ? draftId : void 0
        });
      }
    });
    if (entries.length === 0) {
      alert("Please fill at least one expense entry before saving.");
      return;
    }
    if (onSaveDraftPackage) {
      const draftPackage = {
        id: draftId,
        title: `${sessionDay} - Travel & Expenses Sheet`,
        sessionDay,
        sessionDate,
        clusterName,
        collegeName,
        spocName,
        financerName,
        status: isDraft ? "Draft" : "Approved",
        lastSaved: "Just now",
        totalAmount: grandTotal,
        routes,
        food,
        stationery,
        otherItems
      };
      onSaveDraftPackage(draftPackage);
    }
    onSubmitFinance(entries, isDraft);
    onClose();
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-0 sm:p-4 md:p-6 bg-gray-900/75 backdrop-blur-sm animate-in fade-in-0 duration-200", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full h-full sm:h-auto sm:max-h-[94vh] sm:max-w-4xl flex flex-col rounded-none sm:rounded-2xl border-0 sm:border border-gray-200 bg-white shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 sm:px-6 py-3.5 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 flex items-center justify-between shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 items-center justify-center rounded-xl bg-brand-50 text-brand-500 dark:bg-brand-500/10 dark:text-brand-400 shrink-0", children: /* @__PURE__ */ jsxDEV(ReceiptIndianRupee, { className: "h-5 w-5" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 548,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 547,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900 dark:text-white leading-tight", children: "New Finance Entry" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 551,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: [
              clusterName,
              " · ",
              sessionDay
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 554,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 550,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 546,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onClose,
            className: "flex h-9 w-9 items-center justify-center rounded-xl text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 565,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 560,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 545,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 sm:px-6 py-3 bg-gray-50/70 dark:bg-white/[0.02] border-b border-gray-100 dark:border-gray-800 grid grid-cols-2 gap-3 shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Session Day *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 572,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Select, { value: sessionDay, onValueChange: (val) => setSessionDay(val), children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-10 sm:h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Day" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 577,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 576,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: [
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 1", children: "Day 1" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 580,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 2", children: "Day 2" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 581,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 3", children: "Day 3" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 582,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 4", children: "Day 4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 583,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 5", children: "Day 5" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 584,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 6", children: "Day 6" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 585,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 7", children: "Day 7" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 586,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Day 8", children: "Day 8" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 587,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 579,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 575,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 571,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Session Date *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 593,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: sessionDate,
              onChange: (e) => setSessionDate(e.target.value),
              className: "w-full h-10 sm:h-9 px-3 bg-white dark:bg-gray-800 border border-gray-300 rounded-xl text-xs font-medium text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 596,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 592,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 570,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-3 sm:px-6 overflow-x-auto no-scrollbar gap-1.5 py-2.5 shrink-0", children: [
        { id: "Travel", label: "Travel", icon: Car, total: travelTotal },
        { id: "Food", label: "Food", icon: Utensils, total: foodTotal },
        { id: "Stationery", label: "Stationery", icon: BookOpen, total: stationeryTotal },
        { id: "Other", label: "Other", icon: Sparkles, total: otherTotal },
        { id: "Preview", label: "Preview Sheet", icon: FileSpreadsheet, total: 0 }
      ].map((tab) => {
        const isActive = activeTab === tab.id;
        const TabIcon = tab.icon;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveTab(tab.id),
            className: `py-2 px-3 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${isActive ? "bg-brand-500 text-white shadow-theme-xs" : "bg-gray-100/70 text-gray-700 hover:bg-gray-100 dark:bg-white/5 dark:text-gray-300 dark:hover:bg-white/10"}`,
            children: [
              /* @__PURE__ */ jsxDEV(TabIcon, { className: "h-4 w-4 shrink-0" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 629,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: tab.label }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 630,
                columnNumber: 19
              }, this),
              tab.total > 0 && tab.id !== "Preview" && /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `text-[10.5px] font-mono font-bold px-1.5 py-0.2 rounded-md ${isActive ? "bg-white/20 text-white" : "bg-brand-500 text-white"}`,
                  children: [
                    "₹",
                    tab.total.toLocaleString()
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 632,
                  columnNumber: 19
                },
                this
              )
            ]
          },
          tab.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 620,
            columnNumber: 17
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 606,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-gray-50/50 dark:bg-gray-950/30 custom-scrollbar", children: [
        activeTab === "Travel" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Volunteer Travel Routes" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 652,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: "Add all bus, train, or fuel trips taken for this session." }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 653,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 651,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: handleAddRoute,
                className: "flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-600 dark:bg-brand-500/10 dark:text-brand-400 text-xs font-semibold rounded-xl border border-brand-200 dark:border-brand-500/20 transition cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV(Plus, { className: "h-3.5 w-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 660,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Add Route" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 661,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 655,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 650,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3.5", children: routes.map((route, idx) => {
            const rowTotal = (route.volunteers || 0) * (route.perPerson || 0);
            return /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "p-4 sm:p-5 border border-gray-200 dark:border-gray-800 rounded-2xl bg-white dark:bg-gray-900 shadow-theme-xs space-y-3",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-gray-700 dark:text-gray-300", children: [
                      "Route #",
                      idx + 1
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 675,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono font-bold text-brand-500 bg-brand-50 dark:bg-brand-500/10 px-2 py-0.5 rounded-lg", children: [
                      "Total: ₹",
                      rowTotal.toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 678,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 674,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "From (Origin) *" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 686,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. KSR College",
                          value: route.from,
                          onChange: (e) => handleUpdateRoute(route.id, "from", e.target.value),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 689,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 685,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "To (Destination) *" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 699,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. Dharmapuri Village",
                          value: route.to,
                          onChange: (e) => handleUpdateRoute(route.id, "to", e.target.value),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 702,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 698,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 684,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2.5", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Volunteers Count" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 715,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          min: "0",
                          value: route.volunteers || "",
                          placeholder: "0",
                          onChange: (e) => handleUpdateRoute(
                            route.id,
                            "volunteers",
                            parseInt(e.target.value) || 0
                          ),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 718,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 714,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Cost Per Person (₹)" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 735,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          min: "0",
                          value: route.perPerson || "",
                          placeholder: "0",
                          onChange: (e) => handleUpdateRoute(
                            route.id,
                            "perPerson",
                            parseFloat(e.target.value) || 0
                          ),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 738,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 734,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 713,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Remarks / Ticket Details" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 757,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        placeholder: "e.g. Bus fare ticket #1284",
                        value: route.remarks,
                        onChange: (e) => handleUpdateRoute(route.id, "remarks", e.target.value),
                        className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 760,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 756,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 w-full sm:w-auto", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 dark:hover:bg-white/10 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-semibold transition cursor-pointer", children: [
                        /* @__PURE__ */ jsxDEV(Upload, { className: "h-3.5 w-3.5" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 773,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { children: "Upload Bill" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 774,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "file",
                            accept: "image/*,application/pdf",
                            className: "hidden",
                            onChange: (e) => handleDirectFileUpload(e, "travel", route.id, void 0, rowTotal)
                          },
                          void 0,
                          false,
                          {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 775,
                            columnNumber: 31
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 772,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => setScannerTarget({
                            type: "travel",
                            id: route.id,
                            label: `Travel: ${route.from || "Route"} to ${route.to || "Destination"}`,
                            expectedAmount: rowTotal
                          }),
                          className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold hover:bg-brand-600 transition shadow-theme-xs cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxDEV(Camera, { className: "h-3.5 w-3.5" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 797,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Scan OCR Bill" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 798,
                              columnNumber: 31
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 785,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 771,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full sm:w-auto gap-2", children: [
                      route.bill && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-400", children: [
                        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 805,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "truncate max-w-[120px]", children: route.bill.fileName }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 806,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleUpdateRoute(route.id, "bill", null),
                            className: "text-error-500 hover:bg-error-50 p-0.5 rounded ml-1 cursor-pointer",
                            children: /* @__PURE__ */ jsxDEV(X, { className: "h-3 w-3" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 812,
                              columnNumber: 35
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 807,
                            columnNumber: 33
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 804,
                        columnNumber: 27
                      }, this),
                      routes.length > 1 && /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => handleRemoveRoute(route.id),
                          className: "flex items-center gap-1 text-xs font-semibold text-error-600 dark:text-error-400 hover:bg-error-50 dark:hover:bg-error-500/10 px-2.5 py-1.5 rounded-xl transition cursor-pointer ml-auto",
                          children: [
                            /* @__PURE__ */ jsxDEV(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 823,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Remove" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 824,
                              columnNumber: 33
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 818,
                          columnNumber: 27
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 802,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 770,
                    columnNumber: 25
                  }, this)
                ]
              },
              route.id,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 670,
                columnNumber: 21
              },
              this
            );
          }) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 665,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 649,
          columnNumber: 13
        }, this),
        activeTab === "Food" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Volunteer & Team Meals" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 840,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: "Record food and refreshments provided during session execution." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 841,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 839,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
            { key: "breakfast", title: "Breakfast" },
            { key: "lunch", title: "Lunch" },
            { key: "dinner", title: "Dinner" },
            { key: "refreshments", title: "Refreshments & Tea" }
          ].map(({ key, title }) => {
            const mealItem = food[key];
            return /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "p-4 border border-gray-200 dark:border-gray-800 rounded-2xl bg-white dark:bg-gray-900 shadow-theme-xs space-y-3",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-1.5 border-b border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white", children: title }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 861,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono font-bold text-brand-500", children: [
                      "₹",
                      (mealItem.amount || 0).toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 862,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 860,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Amount (₹)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 868,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "number",
                        min: "0",
                        value: mealItem.amount || "",
                        placeholder: "0",
                        onChange: (e) => setFood((prev) => ({
                          ...prev,
                          [key]: {
                            ...prev[key],
                            amount: parseFloat(e.target.value) || 0
                          }
                        })),
                        className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 871,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 867,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Remarks / Details" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 890,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        placeholder: "e.g. 15 meal packets",
                        value: mealItem.remarks,
                        onChange: (e) => setFood((prev) => ({
                          ...prev,
                          [key]: { ...prev[key], remarks: e.target.value }
                        })),
                        className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 893,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 889,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 pt-1 border-t border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "flex-1 flex items-center justify-center gap-1.5 px-2.5 py-2 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-semibold cursor-pointer", children: [
                      /* @__PURE__ */ jsxDEV(Upload, { className: "h-3.5 w-3.5" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 909,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Upload" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 910,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "file",
                          accept: "image/*,application/pdf",
                          className: "hidden",
                          onChange: (e) => handleDirectFileUpload(e, "food", void 0, key, mealItem.amount)
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 911,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 908,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => setScannerTarget({
                          type: "food",
                          foodKey: key,
                          label: `Food: ${title}`,
                          expectedAmount: mealItem.amount
                        }),
                        className: "flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold hover:bg-brand-600 transition shadow-theme-xs cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxDEV(Camera, { className: "h-3.5 w-3.5" }, void 0, false, {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 933,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { children: "Scan Bill" }, void 0, false, {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 934,
                            columnNumber: 29
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 921,
                        columnNumber: 27
                      },
                      this
                    ),
                    mealItem.bill && /* @__PURE__ */ jsxDEV("div", { className: "w-full flex items-center justify-between px-2 py-1 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-xl text-[11px] font-semibold text-emerald-700 dark:text-emerald-400", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 truncate", children: [
                        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5 shrink-0" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 940,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: mealItem.bill.fileName }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 941,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 939,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => setFood((prev) => ({
                            ...prev,
                            [key]: { ...prev[key], bill: null }
                          })),
                          className: "text-error-500 hover:bg-error-50 p-0.5 rounded cursor-pointer shrink-0 ml-1",
                          children: /* @__PURE__ */ jsxDEV(X, { className: "h-3 w-3" }, void 0, false, {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 953,
                            columnNumber: 33
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 943,
                          columnNumber: 31
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 938,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 907,
                    columnNumber: 25
                  }, this)
                ]
              },
              key,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 856,
                columnNumber: 21
              },
              this
            );
          }) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 844,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 838,
          columnNumber: 13
        }, this),
        activeTab === "Stationery" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Classroom Stationery" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 969,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: "Materials, pens, chart papers, activity worksheets, student notebooks." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 970,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 968,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-4 sm:p-5 border border-gray-200 dark:border-gray-800 rounded-2xl bg-white dark:bg-gray-900 shadow-theme-xs space-y-3.5 max-w-xl", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Amount (₹)" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 975,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  min: "0",
                  value: stationery.amount || "",
                  placeholder: "0",
                  onChange: (e) => setStationery((prev) => ({
                    ...prev,
                    amount: parseFloat(e.target.value) || 0
                  })),
                  className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-sm font-bold text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 978,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 974,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Remarks / Description" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 994,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "e.g. Chart papers, sketch pens, student activity sheets",
                  value: stationery.remarks,
                  onChange: (e) => setStationery((prev) => ({
                    ...prev,
                    remarks: e.target.value
                  })),
                  className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 997,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 993,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 pt-1 border-t border-gray-100 dark:border-gray-800", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-semibold cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(Upload, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1013,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Upload Bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1014,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "file",
                    accept: "image/*,application/pdf",
                    className: "hidden",
                    onChange: (e) => handleDirectFileUpload(e, "stationery", void 0, void 0, stationery.amount)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1015,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1012,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setScannerTarget({
                    type: "stationery",
                    label: "Stationery Items",
                    expectedAmount: stationery.amount
                  }),
                  className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold hover:bg-brand-600 transition shadow-theme-xs cursor-pointer",
                  children: [
                    /* @__PURE__ */ jsxDEV(Camera, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1036,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Scan Bill" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1037,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1025,
                  columnNumber: 21
                },
                this
              ),
              stationery.bill && /* @__PURE__ */ jsxDEV("div", { className: "w-full flex items-center justify-between px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-400", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 truncate", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5 shrink-0" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1043,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: stationery.bill.fileName }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1044,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1042,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setStationery((prev) => ({ ...prev, bill: null })),
                    className: "text-error-500 hover:bg-error-50 p-0.5 rounded cursor-pointer shrink-0 ml-1",
                    children: /* @__PURE__ */ jsxDEV(X, { className: "h-3 w-3" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1051,
                      columnNumber: 27
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1046,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1041,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1011,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 973,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 967,
          columnNumber: 13
        }, this),
        activeTab === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Other Expenses" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1065,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: "Banners, mic/sound rental, stage setups, or incidentals." }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1066,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1064,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: handleAddOther,
                className: "flex items-center gap-1.5 px-3 py-1.5 bg-brand-50 hover:bg-brand-100 text-brand-600 dark:bg-brand-500/10 dark:text-brand-400 text-xs font-semibold rounded-xl border border-brand-200 dark:border-brand-500/20 transition cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV(Plus, { className: "h-3.5 w-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1073,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Add Expense" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1074,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1068,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1063,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: otherItems.map(
            (item) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "p-4 sm:p-5 border border-gray-200 dark:border-gray-800 rounded-2xl bg-white dark:bg-gray-900 shadow-theme-xs space-y-3",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-2.5", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Description *" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 1086,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "text",
                          placeholder: "e.g. Flex Banner for Event",
                          value: item.description,
                          onChange: (e) => handleUpdateOther(item.id, "description", e.target.value),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1089,
                          columnNumber: 27
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1085,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1", children: "Amount (₹) *" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 1101,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          min: "0",
                          value: item.amount || "",
                          placeholder: "0",
                          onChange: (e) => handleUpdateOther(
                            item.id,
                            "amount",
                            parseFloat(e.target.value) || 0
                          ),
                          className: "w-full h-10 sm:h-9 px-3 bg-transparent border border-gray-300 rounded-xl text-xs font-bold text-gray-800 dark:text-white dark:border-gray-700 focus:outline-none focus:border-brand-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1104,
                          columnNumber: 27
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1100,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1084,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-gray-100 dark:border-gray-800", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2 w-full sm:w-auto", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 bg-gray-50 hover:bg-gray-100 dark:bg-white/5 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-semibold cursor-pointer", children: [
                        /* @__PURE__ */ jsxDEV(Upload, { className: "h-3.5 w-3.5" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1124,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { children: "Upload Bill" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1125,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "file",
                            accept: "image/*,application/pdf",
                            className: "hidden",
                            onChange: (e) => handleDirectFileUpload(e, "other", item.id, void 0, item.amount)
                          },
                          void 0,
                          false,
                          {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 1126,
                            columnNumber: 29
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 1123,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => setScannerTarget({
                            type: "other",
                            id: item.id,
                            label: `Other: ${item.description || "Expense"}`,
                            expectedAmount: item.amount
                          }),
                          className: "flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold hover:bg-brand-600 transition shadow-theme-xs cursor-pointer",
                          children: [
                            /* @__PURE__ */ jsxDEV(Camera, { className: "h-3.5 w-3.5" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 1148,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Scan Bill" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 1149,
                              columnNumber: 29
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1136,
                          columnNumber: 27
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1122,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between w-full sm:w-auto gap-2", children: [
                      item.bill && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-400", children: [
                        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1156,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "truncate max-w-[120px]", children: item.bill.fileName }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1157,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            type: "button",
                            onClick: () => handleUpdateOther(item.id, "bill", null),
                            className: "text-error-500 hover:bg-error-50 p-0.5 rounded cursor-pointer ml-1",
                            children: /* @__PURE__ */ jsxDEV(X, { className: "h-3 w-3" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 1163,
                              columnNumber: 33
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                            lineNumber: 1158,
                            columnNumber: 31
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                        lineNumber: 1155,
                        columnNumber: 23
                      }, this),
                      otherItems.length > 1 && /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => handleRemoveOther(item.id),
                          className: "flex items-center gap-1 text-xs font-semibold text-error-600 dark:text-error-400 hover:bg-error-50 dark:hover:bg-error-500/10 px-2.5 py-1.5 rounded-xl transition cursor-pointer ml-auto",
                          children: [
                            /* @__PURE__ */ jsxDEV(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 1174,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { children: "Remove" }, void 0, false, {
                              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                              lineNumber: 1175,
                              columnNumber: 31
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                          lineNumber: 1169,
                          columnNumber: 23
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1153,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1121,
                    columnNumber: 23
                  }, this)
                ]
              },
              item.id,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1080,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1078,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 1062,
          columnNumber: 13
        }, this),
        activeTab === "Preview" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "TQI Finance Voucher Summary" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1190,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: "Preview generated expense sheet before official submission." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1191,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1189,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "block md:hidden space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-2xl bg-brand-50/70 dark:bg-brand-500/10 border border-brand-200 dark:border-brand-500/20 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400 block", children: [
                  sessionDay,
                  " · ",
                  sessionDate
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1199,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-gray-900 dark:text-white", children: clusterName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1202,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1198,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-500 dark:text-gray-400 block", children: "Total Voucher" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1207,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-base font-bold text-brand-600 dark:text-brand-400", children: [
                  "₹",
                  grandTotal.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1208,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1206,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1197,
              columnNumber: 19
            }, this),
            routes.map((r, idx) => {
              const total = (r.volunteers || 0) * (r.perPerson || 0);
              return /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                      "#",
                      idx + 1
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1221,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-400", children: "Travel" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1222,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1220,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-brand-600 dark:text-brand-400", children: [
                    "₹",
                    total.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1226,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1219,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: [
                    r.from || "Origin",
                    " → ",
                    r.to || "Destination"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1232,
                    columnNumber: 27
                  }, this),
                  r.volunteers && r.perPerson ? /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400 mt-0.5", children: [
                    "Formula: ",
                    r.volunteers,
                    " vols × ₹",
                    r.perPerson
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1236,
                    columnNumber: 25
                  }, this) : null
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1231,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400 truncate max-w-[170px]", children: r.remarks || "Volunteer travel" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1243,
                    columnNumber: 27
                  }, this),
                  r.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1246,
                      columnNumber: 31
                    }, this),
                    " Attached"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1245,
                    columnNumber: 25
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1249,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1242,
                  columnNumber: 25
                }, this)
              ] }, r.id, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1218,
                columnNumber: 21
              }, this);
            }),
            food.breakfast.amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                    "#",
                    routes.length + 1
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1261,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1262,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1260,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.breakfast.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1266,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1259,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: [
                "Breakfast ",
                food.breakfast.remarks ? `(${food.breakfast.remarks})` : ""
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1270,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: "Breakfast meals" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1274,
                  columnNumber: 25
                }, this),
                food.breakfast.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1277,
                    columnNumber: 29
                  }, this),
                  " Attached"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1276,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1280,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1273,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1258,
              columnNumber: 17
            }, this),
            food.lunch.amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                    "#",
                    routes.length + 2
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1290,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1291,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1289,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.lunch.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1295,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1288,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: [
                "Lunch ",
                food.lunch.remarks ? `(${food.lunch.remarks})` : ""
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1299,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: "Lunch meals" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1303,
                  columnNumber: 25
                }, this),
                food.lunch.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1306,
                    columnNumber: 29
                  }, this),
                  " Attached"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1305,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1309,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1302,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1287,
              columnNumber: 17
            }, this),
            food.dinner.amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                    "#",
                    routes.length + 3
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1319,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1320,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1318,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.dinner.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1324,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1317,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: [
                "Dinner ",
                food.dinner.remarks ? `(${food.dinner.remarks})` : ""
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1328,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: "Dinner meals" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1332,
                  columnNumber: 25
                }, this),
                food.dinner.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1335,
                    columnNumber: 29
                  }, this),
                  " Attached"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1334,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1338,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1331,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1316,
              columnNumber: 17
            }, this),
            food.refreshments.amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                    "#",
                    routes.length + 4
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1348,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1349,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1347,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.refreshments.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1353,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1346,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: [
                "Refreshments & Tea ",
                food.refreshments.remarks ? `(${food.refreshments.remarks})` : ""
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1357,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: "Snacks & Tea" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1361,
                  columnNumber: 25
                }, this),
                food.refreshments.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1364,
                    columnNumber: 29
                  }, this),
                  " Attached"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1363,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1367,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1360,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1345,
              columnNumber: 17
            }, this),
            stationery.amount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                    "#",
                    routes.length + 5
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1378,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-blue-50 text-blue-700 dark:bg-blue-500/15 dark:text-blue-400", children: "Stationery" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1379,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1377,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  stationery.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1383,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1376,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: stationery.remarks || "Classroom Materials & Notebooks" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1387,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400", children: "Student kits" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1391,
                  columnNumber: 25
                }, this),
                stationery.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1394,
                    columnNumber: 29
                  }, this),
                  " Attached"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1393,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1397,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1390,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1375,
              columnNumber: 17
            }, this),
            otherItems.map((item, oIdx) => {
              if (!item.amount && !item.description) return null;
              return /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs space-y-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400", children: [
                      "#",
                      routes.length + 6 + oIdx
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1410,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-md text-[10.5px] font-bold bg-purple-50 text-purple-700 dark:bg-purple-500/15 dark:text-purple-400", children: "Other" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1411,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1409,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-gray-900 dark:text-white", children: [
                    "₹",
                    item.amount.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1415,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1408,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-900 dark:text-white", children: item.description || "Miscellaneous" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1419,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-gray-100 dark:border-gray-800 text-[11px]", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 dark:text-gray-400 truncate max-w-[170px]", children: item.remarks || "Other expense" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1423,
                    columnNumber: 27
                  }, this),
                  item.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3 w-3" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1426,
                      columnNumber: 31
                    }, this),
                    " Attached"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1425,
                    columnNumber: 25
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-[10.5px]", children: "No bill" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1429,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1422,
                  columnNumber: 25
                }, this)
              ] }, item.id, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1407,
                columnNumber: 21
              }, this);
            })
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1195,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "hidden md:block overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-theme-xs", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left text-xs border-collapse", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 dark:bg-white/[0.02] border-b border-gray-200 dark:border-gray-800 font-semibold text-gray-600 dark:text-gray-300", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "p-3 w-12 text-center", children: "#" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1443,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Category" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1444,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Description" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1445,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-center", children: "Count" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1446,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-center", children: "Formula" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1447,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-right", children: "Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1448,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-center", children: "Bill" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1449,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1442,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1441,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-100 dark:divide-gray-800", children: [
              routes.map((r, idx) => {
                const total = (r.volunteers || 0) * (r.perPerson || 0);
                return /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: idx + 1 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1458,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-brand-500", children: "Travel" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1459,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: [
                    r.from || "Origin",
                    " → ",
                    r.to || "Destination"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1460,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center font-mono text-gray-600 dark:text-gray-400", children: r.volunteers || "—" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1463,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center font-mono text-gray-600 dark:text-gray-400", children: r.volunteers && r.perPerson ? `${r.volunteers}×₹${r.perPerson}` : "—" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1464,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                    "₹",
                    total.toLocaleString()
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1467,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: r.bill ? /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold text-[11px]", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                      lineNumber: 1473,
                      columnNumber: 37
                    }, this),
                    " Attached"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1472,
                    columnNumber: 31
                  }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 text-xs", children: "—" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1476,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                    lineNumber: 1470,
                    columnNumber: 31
                  }, this)
                ] }, r.id, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1457,
                  columnNumber: 27
                }, this);
              }),
              food.breakfast.amount > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: routes.length + 1 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1486,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-warning-600", children: "Food" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1487,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: [
                  "Breakfast ",
                  food.breakfast.remarks ? `(${food.breakfast.remarks})` : ""
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1488,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1489,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1490,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.breakfast.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1491,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: food.breakfast.bill ? /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-600 font-semibold text-[11px]", children: "Attached" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1495,
                  columnNumber: 54
                }, this) : "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1494,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1485,
                columnNumber: 23
              }, this),
              food.lunch.amount > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: routes.length + 2 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1501,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-warning-600", children: "Food" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1502,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: [
                  "Lunch ",
                  food.lunch.remarks ? `(${food.lunch.remarks})` : ""
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1503,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1504,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1505,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.lunch.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1506,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: food.lunch.bill ? /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-600 font-semibold text-[11px]", children: "Attached" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1510,
                  columnNumber: 50
                }, this) : "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1509,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1500,
                columnNumber: 23
              }, this),
              food.dinner.amount > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: routes.length + 3 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1516,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-warning-600", children: "Food" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1517,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: "Dinner" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1518,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1519,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1520,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.dinner.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1521,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: food.dinner.bill ? /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-600 font-semibold text-[11px]", children: "Attached" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1525,
                  columnNumber: 51
                }, this) : "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1524,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1515,
                columnNumber: 23
              }, this),
              food.refreshments.amount > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: routes.length + 4 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1531,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-warning-600", children: "Food" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1532,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: "Refreshments & Tea" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1533,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1534,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1535,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  food.refreshments.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1536,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: food.refreshments.bill ? /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-600 font-semibold text-[11px]", children: "Attached" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1540,
                  columnNumber: 57
                }, this) : "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1539,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1530,
                columnNumber: 23
              }, this),
              stationery.amount > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50/60 dark:hover:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: routes.length + 5 }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1548,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-semibold text-brand-500", children: "Stationery" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1549,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-gray-800 dark:text-gray-200", children: stationery.remarks || "Classroom Materials" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1550,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1551,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center text-gray-400 font-mono", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1552,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono font-bold text-gray-900 dark:text-white", children: [
                  "₹",
                  stationery.amount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1553,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-center", children: stationery.bill ? /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-600 font-semibold text-[11px]", children: "Attached" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1557,
                  columnNumber: 50
                }, this) : "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1556,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1547,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("tr", { className: "bg-brand-50/70 dark:bg-brand-500/10 font-bold text-gray-900 dark:text-white", children: [
                /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-3 text-right text-xs", children: [
                  "Grand Total (",
                  sessionDay,
                  ")"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1564,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-right font-mono text-sm text-brand-600 dark:text-brand-400", children: [
                  "₹",
                  grandTotal.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1567,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-3" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1570,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                lineNumber: 1563,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1452,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1440,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1439,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1438,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 1188,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 646,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-4 sm:px-6 py-3 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-white w-full sm:w-auto justify-between sm:justify-start", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 dark:text-gray-400", children: "Grand Total:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1583,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-base sm:text-lg font-bold text-brand-500 bg-brand-50 dark:bg-brand-500/15 px-2.5 py-1 rounded-xl", children: [
            "₹",
            grandTotal.toLocaleString()
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
            lineNumber: 1584,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 1582,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:flex items-center gap-2 w-full sm:w-auto", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleSubmit(true),
              className: "w-full sm:w-auto px-4 py-2.5 sm:py-2 border border-brand-500/40 text-brand-600 bg-brand-50/50 hover:bg-brand-50 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 dark:border-brand-500/30 dark:bg-brand-500/10 dark:text-brand-400 dark:hover:bg-brand-500/20 transition-colors cursor-pointer shadow-theme-xs",
              children: [
                /* @__PURE__ */ jsxDEV(Save, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1595,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Save Draft" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1596,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1590,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleSubmit(false),
              className: "w-full sm:w-auto px-4 py-2.5 sm:py-2 bg-brand-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-brand-600 transition shadow-theme-xs cursor-pointer",
              children: [
                /* @__PURE__ */ jsxDEV(Send, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1603,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Submit Finance" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
                  lineNumber: 1604,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
              lineNumber: 1598,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
          lineNumber: 1589,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 1581,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
      lineNumber: 543,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
      lineNumber: 542,
      columnNumber: 7
    }, this),
    scannerTarget && /* @__PURE__ */ jsxDEV(
      BillScannerModal,
      {
        isOpen: true,
        onClose: () => setScannerTarget(null),
        expectedAmount: scannerTarget.expectedAmount,
        categoryLabel: scannerTarget.label,
        onAttachBill: (bill) => {
          attachBillToTarget(
            scannerTarget.type,
            bill,
            scannerTarget.id,
            scannerTarget.foodKey
          );
        }
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
        lineNumber: 1613,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx",
    lineNumber: 541,
    columnNumber: 5
  }, this);
};
_s(NewFinanceModal, "lV2VnTtL5JATgNNjeAkrTVYFVv8=");
_c = NewFinanceModal;
var _c;
$RefreshReg$(_c, "NewFinanceModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NewFinanceModal.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNGhCSSxtQkFPWSxjQVBaOztBQTVoQkosU0FBZ0JBLFVBQVVDLFNBQVNDLGlCQUFpQjtBQUNwRCxTQUFTQyx3QkFBd0M7QUFFakQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUdLO0FBRVA7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBdUNBLGFBQU1DLGtCQUFrREEsQ0FBQztBQUFBLEVBQzlEQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxjQUFjO0FBQUEsRUFDZEMsY0FBYztBQUFBLEVBQ2RDLFdBQVc7QUFBQSxFQUNYQyxlQUFlO0FBQUEsRUFDZkMsZUFBZTtBQUFBLEVBQ2ZDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBRUosUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUluQyxTQUFpQjhCLGNBQWNJLGNBQWMsT0FBTztBQUN4RixRQUFNLENBQUNFLGFBQWFDLGNBQWMsSUFBSXJDLFNBQWlCOEIsY0FBY00sZUFBZSxZQUFZO0FBQ2hHLFFBQU0sQ0FBQ0UsV0FBV0MsWUFBWSxJQUFJdkMsU0FBaUUsUUFBUTtBQUczRyxRQUFNLENBQUN3QyxlQUFlQyxnQkFBZ0IsSUFBSXpDLFNBTWhDLElBQUk7QUFHZCxRQUFNLENBQUMwQyxRQUFRQyxTQUFTLElBQUkzQztBQUFBQSxJQUMxQjhCLGNBQWNZLFVBQVU7QUFBQSxNQUN0QjtBQUFBLFFBQ0VFLElBQUk7QUFBQSxRQUNKQyxNQUFNO0FBQUEsUUFDTkMsSUFBSTtBQUFBLFFBQ0pDLFlBQVk7QUFBQSxRQUNaQyxXQUFXO0FBQUEsUUFDWEMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFBQztBQUFBLEVBRUw7QUFHQSxRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSXBEO0FBQUFBLElBQ3RCOEIsY0FBY3FCLFFBQVE7QUFBQSxNQUNwQkUsV0FBVyxFQUFFQyxRQUFRLEdBQUdMLFNBQVMsSUFBSUMsTUFBTSxLQUFLO0FBQUEsTUFDaERLLE9BQU8sRUFBRUQsUUFBUSxHQUFHTCxTQUFTLElBQUlDLE1BQU0sS0FBSztBQUFBLE1BQzVDTSxRQUFRLEVBQUVGLFFBQVEsR0FBR0wsU0FBUyxJQUFJQyxNQUFNLEtBQUs7QUFBQSxNQUM3Q08sY0FBYyxFQUFFSCxRQUFRLEdBQUdMLFNBQVMsSUFBSUMsTUFBTSxLQUFLO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBR0EsUUFBTSxDQUFDUSxZQUFZQyxhQUFhLElBQUkzRDtBQUFBQSxJQUtsQzhCLGNBQWM0QixjQUFjO0FBQUEsTUFDMUJKLFFBQVE7QUFBQSxNQUNSTCxTQUFTO0FBQUEsTUFDVEMsTUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBR0EsUUFBTSxDQUFDVSxZQUFZQyxhQUFhLElBQUk3RDtBQUFBQSxJQUNsQzhCLGNBQWM4QixjQUFjO0FBQUEsTUFDMUI7QUFBQSxRQUNFaEIsSUFBSTtBQUFBLFFBQ0prQixhQUFhO0FBQUEsUUFDYlIsUUFBUTtBQUFBLFFBQ1JMLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQUM7QUFBQSxFQUVMO0FBR0FoRCxZQUFVLE1BQU07QUFDZCxRQUFJNEIsY0FBYztBQUNoQixVQUFJQSxhQUFhSSxXQUFZQyxlQUFjTCxhQUFhSSxVQUFVO0FBQ2xFLFVBQUlKLGFBQWFNLFlBQWFDLGdCQUFlUCxhQUFhTSxXQUFXO0FBQ3JFLFVBQUlOLGFBQWFZLE9BQVFDLFdBQVViLGFBQWFZLE1BQU07QUFDdEQsVUFBSVosYUFBYXFCLEtBQU1DLFNBQVF0QixhQUFhcUIsSUFBSTtBQUNoRCxVQUFJckIsYUFBYTRCLFdBQVlDLGVBQWM3QixhQUFhNEIsVUFBVTtBQUNsRSxVQUFJNUIsYUFBYThCLFdBQVlDLGVBQWMvQixhQUFhOEIsVUFBVTtBQUFBLElBQ3BFLE9BQU87QUFDTHpCLG9CQUFjLE9BQU87QUFDckJRO0FBQUFBLFFBQVU7QUFBQSxVQUNSO0FBQUEsWUFDRUMsSUFBSTtBQUFBLFlBQ0pDLE1BQU07QUFBQSxZQUNOQyxJQUFJO0FBQUEsWUFDSkMsWUFBWTtBQUFBLFlBQ1pDLFdBQVc7QUFBQSxZQUNYQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1I7QUFBQSxRQUFDO0FBQUEsTUFDRjtBQUNERSxjQUFRO0FBQUEsUUFDTkMsV0FBVyxFQUFFQyxRQUFRLEdBQUdMLFNBQVMsSUFBSUMsTUFBTSxLQUFLO0FBQUEsUUFDaERLLE9BQU8sRUFBRUQsUUFBUSxHQUFHTCxTQUFTLElBQUlDLE1BQU0sS0FBSztBQUFBLFFBQzVDTSxRQUFRLEVBQUVGLFFBQVEsR0FBR0wsU0FBUyxJQUFJQyxNQUFNLEtBQUs7QUFBQSxRQUM3Q08sY0FBYyxFQUFFSCxRQUFRLEdBQUdMLFNBQVMsSUFBSUMsTUFBTSxLQUFLO0FBQUEsTUFDckQsQ0FBQztBQUNEUyxvQkFBYztBQUFBLFFBQ1pMLFFBQVE7QUFBQSxRQUNSTCxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEVztBQUFBQSxRQUFjO0FBQUEsVUFDWjtBQUFBLFlBQ0VqQixJQUFJO0FBQUEsWUFDSmtCLGFBQWE7QUFBQSxZQUNiUixRQUFRO0FBQUEsWUFDUkwsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSO0FBQUEsUUFBQztBQUFBLE1BQ0Y7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUNwQixjQUFjTixNQUFNLENBQUM7QUFHekIsUUFBTXVDLGNBQWM5RCxRQUFRLE1BQU07QUFDaEMsV0FBT3lDLE9BQU9zQixPQUFPLENBQUNDLEtBQUtDLE1BQU1ELE9BQU9DLEVBQUVuQixjQUFjLE1BQU1tQixFQUFFbEIsYUFBYSxJQUFJLENBQUM7QUFBQSxFQUNwRixHQUFHLENBQUNOLE1BQU0sQ0FBQztBQUVYLFFBQU15QixZQUFZbEUsUUFBUSxNQUFNO0FBQzlCLFlBQ0drRCxLQUFLRSxVQUFVQyxVQUFVLE1BQ3pCSCxLQUFLSSxNQUFNRCxVQUFVLE1BQ3JCSCxLQUFLSyxPQUFPRixVQUFVLE1BQ3RCSCxLQUFLTSxhQUFhSCxVQUFVO0FBQUEsRUFFakMsR0FBRyxDQUFDSCxJQUFJLENBQUM7QUFFVCxRQUFNaUIsa0JBQWtCbkUsUUFBUSxNQUFNO0FBQ3BDLFdBQU95RCxXQUFXSixVQUFVO0FBQUEsRUFDOUIsR0FBRyxDQUFDSSxVQUFVLENBQUM7QUFFZixRQUFNVyxhQUFhcEUsUUFBUSxNQUFNO0FBQy9CLFdBQU8yRCxXQUFXSSxPQUFPLENBQUNDLEtBQUtLLFNBQVNMLE9BQU9LLEtBQUtoQixVQUFVLElBQUksQ0FBQztBQUFBLEVBQ3JFLEdBQUcsQ0FBQ00sVUFBVSxDQUFDO0FBRWYsUUFBTVcsYUFBYVIsY0FBY0ksWUFBWUMsa0JBQWtCQztBQUcvRCxRQUFNRyxpQkFBaUJBLE1BQU07QUFDM0IsVUFBTUMsV0FBc0I7QUFBQSxNQUMxQjdCLElBQUksU0FBUzhCLEtBQUtDLElBQUksQ0FBQztBQUFBLE1BQ3ZCOUIsTUFBTTtBQUFBLE1BQ05DLElBQUk7QUFBQSxNQUNKQyxZQUFZO0FBQUEsTUFDWkMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxNQUFNO0FBQUEsSUFDUjtBQUNBUCxjQUFVLENBQUNpQyxTQUFTLENBQUMsR0FBR0EsTUFBTUgsUUFBUSxDQUFDO0FBQUEsRUFDekM7QUFFQSxRQUFNSSxvQkFBb0JBLENBQUNqQyxJQUFZa0MsT0FBd0JDLFVBQWU7QUFDNUVwQztBQUFBQSxNQUFVLENBQUNpQyxTQUNUQSxLQUFLSSxJQUFJLENBQUNkLE1BQU9BLEVBQUV0QixPQUFPQSxLQUFLLEVBQUUsR0FBR3NCLEdBQUcsQ0FBQ1ksS0FBSyxHQUFHQyxNQUFNLElBQUliLENBQUU7QUFBQSxJQUM5RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNZSxvQkFBb0JBLENBQUNyQyxPQUFlO0FBQ3hDLFFBQUlGLE9BQU93QyxVQUFVLEdBQUc7QUFDdEJ2QztBQUFBQSxRQUFVO0FBQUEsVUFDUjtBQUFBLFlBQ0VDLElBQUksU0FBUzhCLEtBQUtDLElBQUksQ0FBQztBQUFBLFlBQ3ZCOUIsTUFBTTtBQUFBLFlBQ05DLElBQUk7QUFBQSxZQUNKQyxZQUFZO0FBQUEsWUFDWkMsV0FBVztBQUFBLFlBQ1hDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDUjtBQUFBLFFBQUM7QUFBQSxNQUNGO0FBQ0Q7QUFBQSxJQUNGO0FBQ0FQLGNBQVUsQ0FBQ2lDLFNBQVNBLEtBQUtPLE9BQU8sQ0FBQ2pCLE1BQU1BLEVBQUV0QixPQUFPQSxFQUFFLENBQUM7QUFBQSxFQUNyRDtBQUdBLFFBQU13QyxpQkFBaUJBLE1BQU07QUFDM0IsVUFBTUMsVUFBcUI7QUFBQSxNQUN6QnpDLElBQUksU0FBUzhCLEtBQUtDLElBQUksQ0FBQztBQUFBLE1BQ3ZCYixhQUFhO0FBQUEsTUFDYlIsUUFBUTtBQUFBLE1BQ1JMLFNBQVM7QUFBQSxNQUNUQyxNQUFNO0FBQUEsSUFDUjtBQUNBVyxrQkFBYyxDQUFDZSxTQUFTLENBQUMsR0FBR0EsTUFBTVMsT0FBTyxDQUFDO0FBQUEsRUFDNUM7QUFFQSxRQUFNQyxvQkFBb0JBLENBQUMxQyxJQUFZa0MsT0FBd0JDLFVBQWU7QUFDNUVsQjtBQUFBQSxNQUFjLENBQUNlLFNBQ2JBLEtBQUtJLElBQUksQ0FBQ1YsU0FBVUEsS0FBSzFCLE9BQU9BLEtBQUssRUFBRSxHQUFHMEIsTUFBTSxDQUFDUSxLQUFLLEdBQUdDLE1BQU0sSUFBSVQsSUFBSztBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUVBLFFBQU1pQixvQkFBb0JBLENBQUMzQyxPQUFlO0FBQ3hDLFFBQUlnQixXQUFXc0IsVUFBVSxHQUFHO0FBQzFCckI7QUFBQUEsUUFBYztBQUFBLFVBQ1o7QUFBQSxZQUNFakIsSUFBSSxTQUFTOEIsS0FBS0MsSUFBSSxDQUFDO0FBQUEsWUFDdkJiLGFBQWE7QUFBQSxZQUNiUixRQUFRO0FBQUEsWUFDUkwsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSO0FBQUEsUUFBQztBQUFBLE1BQ0Y7QUFDRDtBQUFBLElBQ0Y7QUFDQVcsa0JBQWMsQ0FBQ2UsU0FBU0EsS0FBS08sT0FBTyxDQUFDYixTQUFTQSxLQUFLMUIsT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDL0Q7QUFHQSxRQUFNNEMseUJBQXlCQSxDQUM3QkMsR0FDQUMsTUFDQTlDLElBQ0ErQyxTQUNBQyxrQkFDRztBQUNILFVBQU1DLE9BQU9KLEVBQUVLLE9BQU9DLFFBQVEsQ0FBQztBQUMvQixRQUFJRixNQUFNO0FBQ1IsWUFBTUcsU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxhQUFPRSxTQUFTLE1BQU07QUFDcEIsWUFBSUYsT0FBT0csUUFBUTtBQUNqQixnQkFBTUMsYUFBNkI7QUFBQSxZQUNqQ0MsS0FBS0wsT0FBT0c7QUFBQUEsWUFDWkcsVUFBVVQsS0FBS1U7QUFBQUEsWUFDZkMsZ0JBQWdCWixpQkFBaUI7QUFBQSxZQUNqQ2EsWUFBWTtBQUFBLFVBQ2Q7QUFDQUMsNkJBQW1CaEIsTUFBTVUsWUFBWXhELElBQUkrQyxPQUFPO0FBQUEsUUFDbEQ7QUFBQSxNQUNGO0FBQ0FLLGFBQU9XLGNBQWNkLElBQUk7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNYSxxQkFBcUJBLENBQ3pCaEIsTUFDQXhDLE1BQ0FOLElBQ0ErQyxZQUNHO0FBQ0gsUUFBSUQsU0FBUyxZQUFZOUMsSUFBSTtBQUMzQkQ7QUFBQUEsUUFBVSxDQUFDaUMsU0FDVEEsS0FBS0ksSUFBSSxDQUFDZCxNQUFNO0FBQ2QsY0FBSUEsRUFBRXRCLE9BQU9BLElBQUk7QUFDZixnQkFBSWdFLFVBQVUsRUFBRSxHQUFHMUMsR0FBR2hCLEtBQUs7QUFDM0IsZ0JBQUlBLEtBQUsyRCxXQUFXLENBQUMzQyxFQUFFckIsUUFBUXFCLEVBQUVyQixTQUFTLEtBQUs7QUFDN0MrRCxzQkFBUS9ELE9BQU9LLEtBQUsyRDtBQUFBQSxZQUN0QjtBQUNBLGdCQUFJM0QsS0FBSzRELGdCQUFnQixDQUFDNUMsRUFBRXBCLE1BQU1vQixFQUFFcEIsT0FBTyxLQUFLO0FBQzlDOEQsc0JBQVE5RCxLQUFLSSxLQUFLNEQ7QUFBQUEsWUFDcEI7QUFDQSxnQkFBSTVELEtBQUtzRCxrQkFBa0J0RCxLQUFLc0QsaUJBQWlCLEdBQUc7QUFDbEQsa0JBQUlJLFFBQVE3RCxhQUFhLEdBQUc7QUFDMUI2RCx3QkFBUTVELFlBQVkrRCxLQUFLQyxNQUFNOUQsS0FBS3NELGlCQUFpQkksUUFBUTdELFVBQVU7QUFBQSxjQUN6RSxPQUFPO0FBQ0w2RCx3QkFBUTdELGFBQWE7QUFDckI2RCx3QkFBUTVELFlBQVlFLEtBQUtzRDtBQUFBQSxjQUMzQjtBQUFBLFlBQ0Y7QUFDQSxnQkFBSSxDQUFDSSxRQUFRM0QsWUFBWUMsS0FBSzJELFVBQVUzRCxLQUFLNEQsY0FBYztBQUN6REYsc0JBQVEzRCxVQUFVLGlCQUFpQkMsS0FBSzJELFVBQVUsUUFBUSxPQUFPM0QsS0FBSzRELGVBQWUsYUFBYTtBQUFBLFlBQ3BHO0FBQ0EsbUJBQU9GO0FBQUFBLFVBQ1Q7QUFDQSxpQkFBTzFDO0FBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFdBQVd3QixTQUFTLFVBQVVDLFNBQVM7QUFDckN2QyxjQUFRLENBQUN3QixVQUFVO0FBQUEsUUFDakIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDZSxPQUFPLEdBQUc7QUFBQSxVQUNULEdBQUdmLEtBQUtlLE9BQU87QUFBQSxVQUNmekM7QUFBQUEsVUFDQUksUUFBUXNCLEtBQUtlLE9BQU8sRUFBRXJDLFdBQVcsS0FBS0osS0FBS3NELGlCQUFpQnRELEtBQUtzRCxpQkFBaUI1QixLQUFLZSxPQUFPLEVBQUVyQztBQUFBQSxRQUNsRztBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0osV0FBV29DLFNBQVMsY0FBYztBQUNoQy9CLG9CQUFjLENBQUNpQixVQUFVO0FBQUEsUUFDdkIsR0FBR0E7QUFBQUEsUUFDSDFCO0FBQUFBLFFBQ0FJLFFBQVFzQixLQUFLdEIsV0FBVyxLQUFLSixLQUFLc0QsaUJBQWlCdEQsS0FBS3NELGlCQUFpQjVCLEtBQUt0QjtBQUFBQSxNQUNoRixFQUFFO0FBQUEsSUFDSixXQUFXb0MsU0FBUyxXQUFXOUMsSUFBSTtBQUNqQ2lCO0FBQUFBLFFBQWMsQ0FBQ2UsU0FDYkEsS0FBS0ksSUFBSSxDQUFDVixTQUFTO0FBQ2pCLGNBQUlBLEtBQUsxQixPQUFPQSxJQUFJO0FBQ2xCLG1CQUFPO0FBQUEsY0FDTCxHQUFHMEI7QUFBQUEsY0FDSHBCO0FBQUFBLGNBQ0FJLFFBQVFnQixLQUFLaEIsV0FBVyxLQUFLSixLQUFLc0QsaUJBQWlCdEQsS0FBS3NELGlCQUFpQmxDLEtBQUtoQjtBQUFBQSxZQUNoRjtBQUFBLFVBQ0Y7QUFDQSxpQkFBT2dCO0FBQUFBLFFBQ1QsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdBLFFBQU0yQyxlQUFlQSxDQUFDQyxZQUFxQjtBQUN6QyxVQUFNQyxVQUFzQztBQUM1QyxVQUFNQyxVQUFVdEYsY0FBY2MsTUFBTSxTQUFTVixXQUFXbUYsWUFBWSxFQUFFQyxRQUFRLFFBQVEsRUFBRSxDQUFDLElBQUk1QyxLQUFLQyxJQUFJLENBQUM7QUFHdkdqQyxXQUFPNkUsUUFBUSxDQUFDckQsTUFBTTtBQUNwQixZQUFNc0QsT0FBT3RELEVBQUVuQixjQUFjLE1BQU1tQixFQUFFbEIsYUFBYTtBQUNsRCxVQUFJd0UsTUFBTSxLQUFLdEQsRUFBRXJCLFFBQVFxQixFQUFFcEIsSUFBSTtBQUM3QnFFLGdCQUFRTSxLQUFLO0FBQUEsVUFDWEMsTUFBTXRGO0FBQUFBLFVBQ04wQixhQUFhLFdBQVdJLEVBQUVyQixRQUFRLFFBQVEsTUFBTXFCLEVBQUVwQixNQUFNLGFBQWEsS0FBS29CLEVBQUVuQixVQUFVLFlBQVltQixFQUFFbEIsU0FBUztBQUFBLFVBQzdHMkUsVUFBVTtBQUFBLFVBQ1ZyRSxRQUFRa0U7QUFBQUEsVUFDUkksYUFBYTtBQUFBLFVBQ2JDLGVBQWVuRztBQUFBQSxVQUNmb0csYUFBYTVELEVBQUVwQixNQUFNO0FBQUEsVUFDckJpRixRQUFRYixVQUFVLFVBQVU7QUFBQSxVQUM1QmMsU0FBUzlELEVBQUVoQixNQUFNbUQ7QUFBQUEsVUFDakJwRCxTQUFTaUIsRUFBRWpCLFdBQVcsR0FBR2lCLEVBQUVuQixVQUFVO0FBQUEsVUFDckNrRixPQUFPL0QsRUFBRW5CO0FBQUFBLFVBQ1RtRixhQUFhLEdBQUdoRSxFQUFFbkIsVUFBVSxJQUFJbUIsRUFBRWxCLFNBQVM7QUFBQSxVQUMzQ2Q7QUFBQUEsVUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLFFBQy9CLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBR0QsUUFBSWhGLEtBQUtFLFVBQVVDLFNBQVMsR0FBRztBQUM3QjZELGNBQVFNLEtBQUs7QUFBQSxRQUNYQyxNQUFNdEY7QUFBQUEsUUFDTjBCLGFBQWEsb0JBQW9CNUIsVUFBVTtBQUFBLFFBQzNDeUYsVUFBVTtBQUFBLFFBQ1ZyRSxRQUFRSCxLQUFLRSxVQUFVQztBQUFBQSxRQUN2QnNFLGFBQWE7QUFBQSxRQUNiQyxlQUFlbkc7QUFBQUEsUUFDZm9HLGFBQWE7QUFBQSxRQUNiQyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QmMsU0FBUzdFLEtBQUtFLFVBQVVILE1BQU1tRDtBQUFBQSxRQUM5QnBELFNBQVNFLEtBQUtFLFVBQVVKLFdBQVc7QUFBQSxRQUNuQ2Y7QUFBQUEsUUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSWhGLEtBQUtJLE1BQU1ELFNBQVMsR0FBRztBQUN6QjZELGNBQVFNLEtBQUs7QUFBQSxRQUNYQyxNQUFNdEY7QUFBQUEsUUFDTjBCLGFBQWEsZ0JBQWdCNUIsVUFBVTtBQUFBLFFBQ3ZDeUYsVUFBVTtBQUFBLFFBQ1ZyRSxRQUFRSCxLQUFLSSxNQUFNRDtBQUFBQSxRQUNuQnNFLGFBQWE7QUFBQSxRQUNiQyxlQUFlbkc7QUFBQUEsUUFDZm9HLGFBQWE7QUFBQSxRQUNiQyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QmMsU0FBUzdFLEtBQUtJLE1BQU1MLE1BQU1tRDtBQUFBQSxRQUMxQnBELFNBQVNFLEtBQUtJLE1BQU1OLFdBQVc7QUFBQSxRQUMvQmY7QUFBQUEsUUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSWhGLEtBQUtLLE9BQU9GLFNBQVMsR0FBRztBQUMxQjZELGNBQVFNLEtBQUs7QUFBQSxRQUNYQyxNQUFNdEY7QUFBQUEsUUFDTjBCLGFBQWEsaUJBQWlCNUIsVUFBVTtBQUFBLFFBQ3hDeUYsVUFBVTtBQUFBLFFBQ1ZyRSxRQUFRSCxLQUFLSyxPQUFPRjtBQUFBQSxRQUNwQnNFLGFBQWE7QUFBQSxRQUNiQyxlQUFlbkc7QUFBQUEsUUFDZm9HLGFBQWE7QUFBQSxRQUNiQyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QmMsU0FBUzdFLEtBQUtLLE9BQU9OLE1BQU1tRDtBQUFBQSxRQUMzQnBELFNBQVNFLEtBQUtLLE9BQU9QLFdBQVc7QUFBQSxRQUNoQ2Y7QUFBQUEsUUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSWhGLEtBQUtNLGFBQWFILFNBQVMsR0FBRztBQUNoQzZELGNBQVFNLEtBQUs7QUFBQSxRQUNYQyxNQUFNdEY7QUFBQUEsUUFDTjBCLGFBQWEsNkJBQTZCNUIsVUFBVTtBQUFBLFFBQ3BEeUYsVUFBVTtBQUFBLFFBQ1ZyRSxRQUFRSCxLQUFLTSxhQUFhSDtBQUFBQSxRQUMxQnNFLGFBQWE7QUFBQSxRQUNiQyxlQUFlbkc7QUFBQUEsUUFDZm9HLGFBQWE7QUFBQSxRQUNiQyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QmMsU0FBUzdFLEtBQUtNLGFBQWFQLE1BQU1tRDtBQUFBQSxRQUNqQ3BELFNBQVNFLEtBQUtNLGFBQWFSLFdBQVc7QUFBQSxRQUN0Q2Y7QUFBQUEsUUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBR0EsUUFBSXpFLFdBQVdKLFNBQVMsR0FBRztBQUN6QjZELGNBQVFNLEtBQUs7QUFBQSxRQUNYQyxNQUFNdEY7QUFBQUEsUUFDTjBCLGFBQWEsc0NBQXNDNUIsVUFBVTtBQUFBLFFBQzdEeUYsVUFBVTtBQUFBLFFBQ1ZyRSxRQUFRSSxXQUFXSjtBQUFBQSxRQUNuQnNFLGFBQWE7QUFBQSxRQUNiQyxlQUFlbkc7QUFBQUEsUUFDZm9HLGFBQWE7QUFBQSxRQUNiQyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QmMsU0FBU3RFLFdBQVdSLE1BQU1tRDtBQUFBQSxRQUMxQnBELFNBQVNTLFdBQVdULFdBQVc7QUFBQSxRQUMvQmY7QUFBQUEsUUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBR0F2RSxlQUFXMkQsUUFBUSxDQUFDakQsU0FBUztBQUMzQixVQUFJQSxLQUFLaEIsU0FBUyxLQUFLZ0IsS0FBS1IsYUFBYTtBQUN2Q3FELGdCQUFRTSxLQUFLO0FBQUEsVUFDWEMsTUFBTXRGO0FBQUFBLFVBQ04wQixhQUFhLFVBQVVRLEtBQUtSLGVBQWUsdUJBQXVCO0FBQUEsVUFDbEU2RCxVQUFVO0FBQUEsVUFDVnJFLFFBQVFnQixLQUFLaEIsVUFBVTtBQUFBLFVBQ3ZCc0UsYUFBYTtBQUFBLFVBQ2JDLGVBQWVuRztBQUFBQSxVQUNmb0csYUFBYTtBQUFBLFVBQ2JDLFFBQVFiLFVBQVUsVUFBVTtBQUFBLFVBQzVCYyxTQUFTMUQsS0FBS3BCLE1BQU1tRDtBQUFBQSxVQUNwQnBELFNBQVNxQixLQUFLckIsV0FBV3FCLEtBQUtSO0FBQUFBLFVBQzlCNUI7QUFBQUEsVUFDQWtGLFNBQVNGLFVBQVVFLFVBQVVlO0FBQUFBLFFBQy9CLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBRUQsUUFBSWhCLFFBQVFqQyxXQUFXLEdBQUc7QUFDeEJrRCxZQUFNLHVEQUF1RDtBQUM3RDtBQUFBLElBQ0Y7QUFFQSxRQUFJcEcsb0JBQW9CO0FBQ3RCLFlBQU1xRyxlQUE2QjtBQUFBLFFBQ2pDekYsSUFBSXdFO0FBQUFBLFFBQ0prQixPQUFPLEdBQUdwRyxVQUFVO0FBQUEsUUFDcEJBO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FWO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FrRyxRQUFRYixVQUFVLFVBQVU7QUFBQSxRQUM1QnFCLFdBQVc7QUFBQSxRQUNYQyxhQUFhakU7QUFBQUEsUUFDYjdCO0FBQUFBLFFBQ0FTO0FBQUFBLFFBQ0FPO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0Y7QUFDQTVCLHlCQUFtQnFHLFlBQVk7QUFBQSxJQUNqQztBQUVBdEcsb0JBQWdCb0YsU0FBU0QsT0FBTztBQUNoQ3pGLFlBQVE7QUFBQSxFQUNWO0FBRUEsTUFBSSxDQUFDRCxPQUFRLFFBQU87QUFFcEIsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxnSkFDYixpQ0FBQyxTQUFJLFdBQVUsNk5BRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMElBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0lBQ2IsaUNBQUMsc0JBQW1CLFdBQVUsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxtRUFBaUUsaUNBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxnREFDVkU7QUFBQUE7QUFBQUEsY0FBWTtBQUFBLGNBQVdRO0FBQUFBLGlCQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTVDtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUE7QUFBQSxVQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxzSUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0dBQWdHLDZCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLE9BQU9TLFlBQVksZUFBZSxDQUFDdUcsUUFBUXRHLGNBQWNzRyxHQUFHLEdBQ2xFO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSx1QkFDdkIsaUNBQUMsZUFBWSxhQUFZLGdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxpQkFDQztBQUFBLHFDQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGNBQy9CLHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBLGlCQVJqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrR0FBZ0csOEJBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPckc7QUFBQUEsY0FDUCxVQUFVLENBQUNxRCxNQUFNcEQsZUFBZW9ELEVBQUVLLE9BQU9mLEtBQUs7QUFBQSxjQUM5QyxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlrTjtBQUFBLGFBUnBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxrSkFFWDtBQUFBLFFBQ0UsRUFBRW5DLElBQUksVUFBVThGLE9BQU8sVUFBVUMsTUFBTWhJLEtBQUtpSSxPQUFPN0UsWUFBWTtBQUFBLFFBQy9ELEVBQUVuQixJQUFJLFFBQVE4RixPQUFPLFFBQVFDLE1BQU0vSCxVQUFVZ0ksT0FBT3pFLFVBQVU7QUFBQSxRQUM5RCxFQUFFdkIsSUFBSSxjQUFjOEYsT0FBTyxjQUFjQyxNQUFNOUgsVUFBVStILE9BQU94RSxnQkFBZ0I7QUFBQSxRQUNoRixFQUFFeEIsSUFBSSxTQUFTOEYsT0FBTyxTQUFTQyxNQUFNN0gsVUFBVThILE9BQU92RSxXQUFXO0FBQUEsUUFDakUsRUFBRXpCLElBQUksV0FBVzhGLE9BQU8saUJBQWlCQyxNQUFNNUgsaUJBQWlCNkgsT0FBTyxFQUFFO0FBQUEsTUFBQyxFQUU1RTVELElBQUksQ0FBQzZELFFBQVE7QUFDYixjQUFNQyxXQUFXeEcsY0FBY3VHLElBQUlqRztBQUNuQyxjQUFNbUcsVUFBVUYsSUFBSUY7QUFFcEIsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBUyxNQUFNcEcsYUFBYXNHLElBQUlqRyxFQUFTO0FBQUEsWUFDekMsV0FBVyx3SEFDVGtHLFdBQ0ksNENBQ0EsMEdBQTBHO0FBQUEsWUFHaEg7QUFBQSxxQ0FBQyxXQUFRLFdBQVUsc0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FDckMsdUJBQUMsVUFBTUQsY0FBSUgsU0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBLGNBQ2hCRyxJQUFJRCxRQUFRLEtBQUtDLElBQUlqRyxPQUFPLGFBQzNCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsOERBQ1RrRyxXQUFXLDJCQUEyQix5QkFBeUI7QUFBQSxrQkFDOUQ7QUFBQTtBQUFBLG9CQUVERCxJQUFJRCxNQUFNSSxlQUFlO0FBQUE7QUFBQTtBQUFBLGdCQUw3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBO0FBQUE7QUFBQSxVQWpCR0gsSUFBSWpHO0FBQUFBLFVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9CQTtBQUFBLE1BRUosQ0FBQyxLQXBDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsa0dBRVpOO0FBQUFBLHNCQUFjLFlBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLG1EQUFrRCx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUY7QUFBQSxjQUN2Rix1QkFBQyxPQUFFLFdBQVUsZ0RBQStDLHlFQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxSDtBQUFBLGlCQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTa0M7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQTtBQUFBO0FBQUEsY0FOakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNaOUIsaUJBQU9zQyxJQUFJLENBQUNpRSxPQUFPQyxRQUFRO0FBQzFCLGtCQUFNQyxZQUFZRixNQUFNbEcsY0FBYyxNQUFNa0csTUFBTWpHLGFBQWE7QUFFL0QsbUJBQ0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsc0RBQW9EO0FBQUE7QUFBQSxzQkFDMURrRyxNQUFNO0FBQUEseUJBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsc0dBQW9HO0FBQUE7QUFBQSxzQkFDekdDLFNBQVNILGVBQWU7QUFBQSx5QkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwyQ0FBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGtHQUFnRywrQkFBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxhQUFZO0FBQUEsMEJBQ1osT0FBT0MsTUFBTXBHO0FBQUFBLDBCQUNiLFVBQVUsQ0FBQzRDLE1BQU1aLGtCQUFrQm9FLE1BQU1yRyxJQUFJLFFBQVE2QyxFQUFFSyxPQUFPZixLQUFLO0FBQUEsMEJBQ25FLFdBQVU7QUFBQTtBQUFBLHdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLMkw7QUFBQSx5QkFUN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFXQTtBQUFBLG9CQUVBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsa0dBQWdHLGtDQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLGFBQVk7QUFBQSwwQkFDWixPQUFPa0UsTUFBTW5HO0FBQUFBLDBCQUNiLFVBQVUsQ0FBQzJDLE1BQU1aLGtCQUFrQm9FLE1BQU1yRyxJQUFJLE1BQU02QyxFQUFFSyxPQUFPZixLQUFLO0FBQUEsMEJBQ2pFLFdBQVU7QUFBQTtBQUFBLHdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLMkw7QUFBQSx5QkFUN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFXQTtBQUFBLHVCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTBCQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJDQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsa0dBQWdHLGdDQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLEtBQUk7QUFBQSwwQkFDSixPQUFPa0UsTUFBTWxHLGNBQWM7QUFBQSwwQkFDM0IsYUFBWTtBQUFBLDBCQUNaLFVBQVUsQ0FBQzBDLE1BQ1RaO0FBQUFBLDRCQUNFb0UsTUFBTXJHO0FBQUFBLDRCQUNOO0FBQUEsNEJBQ0F3RyxTQUFTM0QsRUFBRUssT0FBT2YsS0FBSyxLQUFLO0FBQUEsMEJBQzlCO0FBQUEsMEJBRUYsV0FBVTtBQUFBO0FBQUEsd0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVkyTDtBQUFBLHlCQWhCN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFrQkE7QUFBQSxvQkFFQSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGtHQUFnRyxtQ0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxLQUFJO0FBQUEsMEJBQ0osT0FBT2tFLE1BQU1qRyxhQUFhO0FBQUEsMEJBQzFCLGFBQVk7QUFBQSwwQkFDWixVQUFVLENBQUN5QyxNQUNUWjtBQUFBQSw0QkFDRW9FLE1BQU1yRztBQUFBQSw0QkFDTjtBQUFBLDRCQUNBeUcsV0FBVzVELEVBQUVLLE9BQU9mLEtBQUssS0FBSztBQUFBLDBCQUNoQztBQUFBLDBCQUVGLFdBQVU7QUFBQTtBQUFBLHdCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFZMkw7QUFBQSx5QkFoQjdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBa0JBO0FBQUEsdUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBd0NBO0FBQUEsa0JBR0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrR0FBZ0csd0NBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsYUFBWTtBQUFBLHdCQUNaLE9BQU9rRSxNQUFNaEc7QUFBQUEsd0JBQ2IsVUFBVSxDQUFDd0MsTUFBTVosa0JBQWtCb0UsTUFBTXJHLElBQUksV0FBVzZDLEVBQUVLLE9BQU9mLEtBQUs7QUFBQSx3QkFDdEUsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUsyTDtBQUFBLHVCQVQ3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLHdHQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLHNSQUNmO0FBQUEsK0NBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErQjtBQUFBLHdCQUMvQix1QkFBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlCO0FBQUEsd0JBQ2pCO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxRQUFPO0FBQUEsNEJBQ1AsV0FBVTtBQUFBLDRCQUNWLFVBQVUsQ0FBQ1UsTUFDVEQsdUJBQXVCQyxHQUFHLFVBQVV3RCxNQUFNckcsSUFBSXVGLFFBQVdnQixRQUFRO0FBQUE7QUFBQSwwQkFMckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1HO0FBQUEsMkJBVEw7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFXQTtBQUFBLHNCQUVBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxTQUFTLE1BQ1AxRyxpQkFBaUI7QUFBQSw0QkFDZmlELE1BQU07QUFBQSw0QkFDTjlDLElBQUlxRyxNQUFNckc7QUFBQUEsNEJBQ1Y4RixPQUFPLFdBQVdPLE1BQU1wRyxRQUFRLE9BQU8sT0FBT29HLE1BQU1uRyxNQUFNLGFBQWE7QUFBQSw0QkFDdkV3RyxnQkFBZ0JIO0FBQUFBLDBCQUNsQixDQUFDO0FBQUEsMEJBRUgsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUErQjtBQUFBLDRCQUMvQix1QkFBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQW1CO0FBQUE7QUFBQTtBQUFBLHdCQWJyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBY0E7QUFBQSx5QkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE2QkE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ1pGO0FBQUFBLDRCQUFNL0YsUUFDTCx1QkFBQyxTQUFJLFdBQVUsMk1BQ2I7QUFBQSwrQ0FBQyxnQkFBYSxXQUFVLGlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCK0YsZ0JBQU0vRixLQUFLb0QsWUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBOEQ7QUFBQSx3QkFDOUQ7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLFNBQVMsTUFBTXpCLGtCQUFrQm9FLE1BQU1yRyxJQUFJLFFBQVEsSUFBSTtBQUFBLDRCQUN2RCxXQUFVO0FBQUEsNEJBRVYsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBc0I7QUFBQTtBQUFBLDBCQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUE7QUFBQSwyQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVVBO0FBQUEsc0JBR0RGLE9BQU93QyxTQUFTLEtBQ2Y7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLFNBQVMsTUFBTUQsa0JBQWtCZ0UsTUFBTXJHLEVBQUU7QUFBQSwwQkFDekMsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUErQjtBQUFBLDRCQUMvQix1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQVk7QUFBQTtBQUFBO0FBQUEsd0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU9BO0FBQUEseUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeUJBO0FBQUEsdUJBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMERBO0FBQUE7QUFBQTtBQUFBLGNBN0pLcUcsTUFBTXJHO0FBQUFBLGNBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQStKQTtBQUFBLFVBRUosQ0FBQyxLQXRLSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVLQTtBQUFBLGFBdkxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3TEE7QUFBQSxRQUlETixjQUFjLFVBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1EQUFrRCxzQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUN0Rix1QkFBQyxPQUFFLFdBQVUsZ0RBQStDLCtFQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEySDtBQUFBLGVBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FFWDtBQUFBLFlBQ0UsRUFBRWlILEtBQUssYUFBYWpCLE9BQU8sWUFBWTtBQUFBLFlBQ3ZDLEVBQUVpQixLQUFLLFNBQVNqQixPQUFPLFFBQVE7QUFBQSxZQUMvQixFQUFFaUIsS0FBSyxVQUFVakIsT0FBTyxTQUFTO0FBQUEsWUFDakMsRUFBRWlCLEtBQUssZ0JBQWdCakIsT0FBTyxxQkFBcUI7QUFBQSxVQUFDLEVBRXREdEQsSUFBSSxDQUFDLEVBQUV1RSxLQUFLakIsTUFBTSxNQUFNO0FBQ3hCLGtCQUFNa0IsV0FBV3JHLEtBQUtvRyxHQUFHO0FBRXpCLG1CQUNFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLG1EQUFtRGpCLG1CQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLG9CQUN2RSx1QkFBQyxVQUFLLFdBQVUsOENBQTRDO0FBQUE7QUFBQSx1QkFDdkRrQixTQUFTbEcsVUFBVSxHQUFHMEYsZUFBZTtBQUFBLHlCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsa0dBQWdHLDBCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLEtBQUk7QUFBQSx3QkFDSixPQUFPUSxTQUFTbEcsVUFBVTtBQUFBLHdCQUMxQixhQUFZO0FBQUEsd0JBQ1osVUFBVSxDQUFDbUMsTUFDVHJDLFFBQVEsQ0FBQ3dCLFVBQVU7QUFBQSwwQkFDakIsR0FBR0E7QUFBQUEsMEJBQ0gsQ0FBQzJFLEdBQUcsR0FBRztBQUFBLDRCQUNMLEdBQUczRSxLQUFLMkUsR0FBRztBQUFBLDRCQUNYakcsUUFBUStGLFdBQVc1RCxFQUFFSyxPQUFPZixLQUFLLEtBQUs7QUFBQSwwQkFDeEM7QUFBQSx3QkFDRixFQUFFO0FBQUEsd0JBRUosV0FBVTtBQUFBO0FBQUEsc0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWMyTDtBQUFBLHVCQWxCN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFvQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGtHQUFnRyxpQ0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxhQUFZO0FBQUEsd0JBQ1osT0FBT3lFLFNBQVN2RztBQUFBQSx3QkFDaEIsVUFBVSxDQUFDd0MsTUFDVHJDLFFBQVEsQ0FBQ3dCLFVBQVU7QUFBQSwwQkFDakIsR0FBR0E7QUFBQUEsMEJBQ0gsQ0FBQzJFLEdBQUcsR0FBRyxFQUFFLEdBQUczRSxLQUFLMkUsR0FBRyxHQUFHdEcsU0FBU3dDLEVBQUVLLE9BQU9mLE1BQU07QUFBQSx3QkFDakQsRUFBRTtBQUFBLHdCQUVKLFdBQVU7QUFBQTtBQUFBLHNCQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFVMkw7QUFBQSx1QkFkN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFnQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsNkxBQ2Y7QUFBQSw2Q0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUEsc0JBQy9CLHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBWTtBQUFBLHNCQUNaO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxRQUFPO0FBQUEsMEJBQ1AsV0FBVTtBQUFBLDBCQUNWLFVBQVUsQ0FBQ1UsTUFDVEQsdUJBQXVCQyxHQUFHLFFBQVEwQyxRQUFXb0IsS0FBS0MsU0FBU2xHLE1BQU07QUFBQTtBQUFBLHdCQUxyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTUc7QUFBQSx5QkFUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFNBQVMsTUFDUGIsaUJBQWlCO0FBQUEsMEJBQ2ZpRCxNQUFNO0FBQUEsMEJBQ05DLFNBQVM0RDtBQUFBQSwwQkFDVGIsT0FBTyxTQUFTSixLQUFLO0FBQUEsMEJBQ3JCZ0IsZ0JBQWdCRSxTQUFTbEc7QUFBQUEsd0JBQzNCLENBQUM7QUFBQSx3QkFFSCxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQStCO0FBQUEsMEJBQy9CLHVCQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBZTtBQUFBO0FBQUE7QUFBQSxzQkFiakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWNBO0FBQUEsb0JBRUNrRyxTQUFTdEcsUUFDUix1QkFBQyxTQUFJLFdBQVUsNE5BQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwrQ0FBQyxnQkFBYSxXQUFVLDBCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4QztBQUFBLHdCQUM5Qyx1QkFBQyxVQUFLLFdBQVUsWUFBWXNHLG1CQUFTdEcsS0FBS29ELFlBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW1EO0FBQUEsMkJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsU0FBUyxNQUNQbEQsUUFBUSxDQUFDd0IsVUFBVTtBQUFBLDRCQUNqQixHQUFHQTtBQUFBQSw0QkFDSCxDQUFDMkUsR0FBRyxHQUFHLEVBQUUsR0FBRzNFLEtBQUsyRSxHQUFHLEdBQUdyRyxNQUFNLEtBQUs7QUFBQSwwQkFDcEMsRUFBRTtBQUFBLDBCQUVKLFdBQVU7QUFBQSwwQkFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFzQjtBQUFBO0FBQUEsd0JBVnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLHlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLHVCQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtEQTtBQUFBO0FBQUE7QUFBQSxjQXBHS3FHO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNHQTtBQUFBLFVBRUosQ0FBQyxLQXBISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFIQTtBQUFBLGFBM0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0SEE7QUFBQSxRQUlEakgsY0FBYyxnQkFDYix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbURBQWtELG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRjtBQUFBLFlBQ3BGLHVCQUFDLE9BQUUsV0FBVSxnREFBK0Msc0ZBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtJO0FBQUEsZUFGcEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHFJQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrR0FBZ0csMEJBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxLQUFJO0FBQUEsa0JBQ0osT0FBT29CLFdBQVdKLFVBQVU7QUFBQSxrQkFDNUIsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ21DLE1BQ1Q5QixjQUFjLENBQUNpQixVQUFVO0FBQUEsb0JBQ3ZCLEdBQUdBO0FBQUFBLG9CQUNIdEIsUUFBUStGLFdBQVc1RCxFQUFFSyxPQUFPZixLQUFLLEtBQUs7QUFBQSxrQkFDeEMsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQTtBQUFBLGdCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdxTTtBQUFBLGlCQWZ2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrR0FBZ0cscUNBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osT0FBT3JCLFdBQVdUO0FBQUFBLGtCQUNsQixVQUFVLENBQUN3QyxNQUNUOUIsY0FBYyxDQUFDaUIsVUFBVTtBQUFBLG9CQUN2QixHQUFHQTtBQUFBQSxvQkFDSDNCLFNBQVN3QyxFQUFFSyxPQUFPZjtBQUFBQSxrQkFDcEIsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQTtBQUFBLGdCQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVUyTDtBQUFBLGlCQWQ3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBNQUNmO0FBQUEsdUNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUMvQix1QkFBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ2pCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxRQUFPO0FBQUEsb0JBQ1AsV0FBVTtBQUFBLG9CQUNWLFVBQVUsQ0FBQ1UsTUFDVEQsdUJBQXVCQyxHQUFHLGNBQWMwQyxRQUFXQSxRQUFXekUsV0FBV0osTUFBTTtBQUFBO0FBQUEsa0JBTG5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNRztBQUFBLG1CQVRMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQ1BiLGlCQUFpQjtBQUFBLG9CQUNmaUQsTUFBTTtBQUFBLG9CQUNOZ0QsT0FBTztBQUFBLG9CQUNQWSxnQkFBZ0I1RixXQUFXSjtBQUFBQSxrQkFDN0IsQ0FBQztBQUFBLGtCQUVILFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQSxvQkFDL0IsdUJBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFlO0FBQUE7QUFBQTtBQUFBLGdCQVpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBRUNJLFdBQVdSLFFBQ1YsdUJBQUMsU0FBSSxXQUFVLDBOQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEseUNBQUMsZ0JBQWEsV0FBVSwwQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFDOUMsdUJBQUMsVUFBSyxXQUFVLFlBQVlRLHFCQUFXUixLQUFLb0QsWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxxQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU0zQyxjQUFjLENBQUNpQixVQUFVLEVBQUUsR0FBR0EsTUFBTTFCLE1BQU0sS0FBSyxFQUFFO0FBQUEsb0JBQ2hFLFdBQVU7QUFBQSxvQkFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzQjtBQUFBO0FBQUEsa0JBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0Q0E7QUFBQSxlQWxGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1GQTtBQUFBLGFBekZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwRkE7QUFBQSxRQUlEWixjQUFjLFdBQ2IsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLG1EQUFrRCw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEU7QUFBQSxjQUM5RSx1QkFBQyxPQUFFLFdBQVUsZ0RBQStDLHdFQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvSDtBQUFBLGlCQUZ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTOEM7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlCO0FBQUE7QUFBQTtBQUFBLGNBTm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDWnhCLHFCQUFXb0I7QUFBQUEsWUFBSSxDQUFDVixTQUNmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsMkNBQUMsU0FDQztBQUFBLDZDQUFDLFdBQU0sV0FBVSxrR0FBZ0csNkJBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsYUFBWTtBQUFBLDBCQUNaLE9BQU9BLEtBQUtSO0FBQUFBLDBCQUNaLFVBQVUsQ0FBQzJCLE1BQ1RILGtCQUFrQmhCLEtBQUsxQixJQUFJLGVBQWU2QyxFQUFFSyxPQUFPZixLQUFLO0FBQUEsMEJBRTFELFdBQVU7QUFBQTtBQUFBLHdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFPMkw7QUFBQSx5QkFYN0w7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFhQTtBQUFBLG9CQUVBLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsa0dBQWdHLDRCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLEtBQUk7QUFBQSwwQkFDSixPQUFPVCxLQUFLaEIsVUFBVTtBQUFBLDBCQUN0QixhQUFZO0FBQUEsMEJBQ1osVUFBVSxDQUFDbUMsTUFDVEg7QUFBQUEsNEJBQ0VoQixLQUFLMUI7QUFBQUEsNEJBQ0w7QUFBQSw0QkFDQXlHLFdBQVc1RCxFQUFFSyxPQUFPZixLQUFLLEtBQUs7QUFBQSwwQkFDaEM7QUFBQSwwQkFFRixXQUFVO0FBQUE7QUFBQSx3QkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBWXFNO0FBQUEseUJBaEJ2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWtCQTtBQUFBLHVCQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1DQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSx3R0FDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSx3TUFDZjtBQUFBLCtDQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0I7QUFBQSx3QkFDL0IsdUJBQUMsVUFBSywyQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQjtBQUFBLHdCQUNqQjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0wsUUFBTztBQUFBLDRCQUNQLFdBQVU7QUFBQSw0QkFDVixVQUFVLENBQUNVLE1BQ1RELHVCQUF1QkMsR0FBRyxTQUFTbkIsS0FBSzFCLElBQUl1RixRQUFXN0QsS0FBS2hCLE1BQU07QUFBQTtBQUFBLDBCQUx0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUc7QUFBQSwyQkFUTDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVdBO0FBQUEsc0JBRUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLFNBQVMsTUFDUGIsaUJBQWlCO0FBQUEsNEJBQ2ZpRCxNQUFNO0FBQUEsNEJBQ045QyxJQUFJMEIsS0FBSzFCO0FBQUFBLDRCQUNUOEYsT0FBTyxVQUFVcEUsS0FBS1IsZUFBZSxTQUFTO0FBQUEsNEJBQzlDd0YsZ0JBQWdCaEYsS0FBS2hCO0FBQUFBLDBCQUN2QixDQUFDO0FBQUEsMEJBRUgsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUErQjtBQUFBLDRCQUMvQix1QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWU7QUFBQTtBQUFBO0FBQUEsd0JBYmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFjQTtBQUFBLHlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTZCQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDWmdCO0FBQUFBLDJCQUFLcEIsUUFDSix1QkFBQyxTQUFJLFdBQVUsMk1BQ2I7QUFBQSwrQ0FBQyxnQkFBYSxXQUFVLGlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxQztBQUFBLHdCQUNyQyx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCb0IsZUFBS3BCLEtBQUtvRCxZQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2RDtBQUFBLHdCQUM3RDtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0wsU0FBUyxNQUFNaEIsa0JBQWtCaEIsS0FBSzFCLElBQUksUUFBUSxJQUFJO0FBQUEsNEJBQ3RELFdBQVU7QUFBQSw0QkFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFzQjtBQUFBO0FBQUEsMEJBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFNQTtBQUFBLDJCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBVUE7QUFBQSxzQkFHRGdCLFdBQVdzQixTQUFTLEtBQ25CO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxTQUFTLE1BQU1LLGtCQUFrQmpCLEtBQUsxQixFQUFFO0FBQUEsMEJBQ3hDLFdBQVU7QUFBQSwwQkFFVjtBQUFBLG1EQUFDLFVBQU8sV0FBVSxpQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBK0I7QUFBQSw0QkFDL0IsdUJBQUMsVUFBSyxzQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFZO0FBQUE7QUFBQTtBQUFBLHdCQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFPQTtBQUFBLHlCQXZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlCQTtBQUFBLHVCQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTBEQTtBQUFBO0FBQUE7QUFBQSxjQWxHSzBCLEtBQUsxQjtBQUFBQSxjQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvR0E7QUFBQSxVQUNELEtBdkdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0dBO0FBQUEsYUF4SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlIQTtBQUFBLFFBSUROLGNBQWMsYUFDYix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbURBQWtELDJDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRjtBQUFBLFlBQzNGLHVCQUFDLE9BQUUsV0FBVSxnREFBK0MsMkVBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVIO0FBQUEsZUFGekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDZCQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBJQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFVBQUssV0FBVSwyRkFDYko7QUFBQUE7QUFBQUEsa0JBQVc7QUFBQSxrQkFBV0U7QUFBQUEscUJBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsbURBQ2JWLHlCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxzREFBcUQsNkJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtGO0FBQUEsZ0JBQ2xGLHVCQUFDLFVBQUssV0FBVSxvRUFBa0U7QUFBQTtBQUFBLGtCQUM5RTZDLFdBQVd5RSxlQUFlO0FBQUEscUJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBR0N0RyxPQUFPc0MsSUFBSSxDQUFDZCxHQUFHZ0YsUUFBUTtBQUN0QixvQkFBTU4sU0FBUzFFLEVBQUVuQixjQUFjLE1BQU1tQixFQUFFbEIsYUFBYTtBQUNwRCxxQkFDRSx1QkFBQyxTQUFlLFdBQVUscUhBQ3hCO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsc0JBQUVrRyxNQUFNO0FBQUEseUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdFO0FBQUEsb0JBQ2hFLHVCQUFDLFVBQUssV0FBVSxtSUFBaUksc0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGtFQUFnRTtBQUFBO0FBQUEsb0JBQzVFTixNQUFNSSxlQUFlO0FBQUEsdUJBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSxtREFDVjlFO0FBQUFBLHNCQUFFckIsUUFBUTtBQUFBLG9CQUFTO0FBQUEsb0JBQUlxQixFQUFFcEIsTUFBTTtBQUFBLHVCQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0NvQixFQUFFbkIsY0FBY21CLEVBQUVsQixZQUNqQix1QkFBQyxPQUFFLFdBQVUsdURBQXFEO0FBQUE7QUFBQSxvQkFDdERrQixFQUFFbkI7QUFBQUEsb0JBQVc7QUFBQSxvQkFBVW1CLEVBQUVsQjtBQUFBQSx1QkFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxJQUNFO0FBQUEscUJBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSwyREFBMkRrQixZQUFFakIsV0FBVyxzQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkc7QUFBQSxrQkFDMUdpQixFQUFFaEIsT0FDRCx1QkFBQyxVQUFLLFdBQVUsbUdBQ2Q7QUFBQSwyQ0FBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQUc7QUFBQSx1QkFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsdUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEscUJBUHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFqQ1FnQixFQUFFdEIsSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtDQTtBQUFBLFlBRUosQ0FBQztBQUFBLFlBR0FPLEtBQUtFLFVBQVVDLFNBQVMsS0FDdkIsdUJBQUMsU0FBSSxXQUFVLHFIQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsb0JBQUVaLE9BQU93QyxTQUFTO0FBQUEsdUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEsa0JBQzFFLHVCQUFDLFVBQUssV0FBVSxtSUFBaUksb0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsa0JBQ3ZFL0IsS0FBS0UsVUFBVUMsT0FBTzBGLGVBQWU7QUFBQSxxQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFBaUQ7QUFBQTtBQUFBLGdCQUNqRDdGLEtBQUtFLFVBQVVKLFVBQVUsSUFBSUUsS0FBS0UsVUFBVUosT0FBTyxNQUFNO0FBQUEsbUJBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvQ0FBbUMsK0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtFO0FBQUEsZ0JBQ2pFRSxLQUFLRSxVQUFVSCxPQUNkLHVCQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLHlDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFBRztBQUFBLHFCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxtQkFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBR0RDLEtBQUtJLE1BQU1ELFNBQVMsS0FDbkIsdUJBQUMsU0FBSSxXQUFVLHFIQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsb0JBQUVaLE9BQU93QyxTQUFTO0FBQUEsdUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEsa0JBQzFFLHVCQUFDLFVBQUssV0FBVSxtSUFBaUksb0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsa0JBQ3ZFL0IsS0FBS0ksTUFBTUQsT0FBTzBGLGVBQWU7QUFBQSxxQkFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFBaUQ7QUFBQTtBQUFBLGdCQUNyRDdGLEtBQUtJLE1BQU1OLFVBQVUsSUFBSUUsS0FBS0ksTUFBTU4sT0FBTyxNQUFNO0FBQUEsbUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvQ0FBbUMsMkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThEO0FBQUEsZ0JBQzdERSxLQUFLSSxNQUFNTCxPQUNWLHVCQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLHlDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFBRztBQUFBLHFCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxtQkFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBR0RDLEtBQUtLLE9BQU9GLFNBQVMsS0FDcEIsdUJBQUMsU0FBSSxXQUFVLHFIQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsb0JBQUVaLE9BQU93QyxTQUFTO0FBQUEsdUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEsa0JBQzFFLHVCQUFDLFVBQUssV0FBVSxtSUFBaUksb0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsa0JBQ3ZFL0IsS0FBS0ssT0FBT0YsT0FBTzBGLGVBQWU7QUFBQSxxQkFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFBaUQ7QUFBQTtBQUFBLGdCQUNwRDdGLEtBQUtLLE9BQU9QLFVBQVUsSUFBSUUsS0FBS0ssT0FBT1AsT0FBTyxNQUFNO0FBQUEsbUJBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvQ0FBbUMsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsZ0JBQzlERSxLQUFLSyxPQUFPTixPQUNYLHVCQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLHlDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFBRztBQUFBLHFCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLElBRUEsdUJBQUMsVUFBSyxXQUFVLCtCQUE4Qix1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxtQkFQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBR0RDLEtBQUtNLGFBQWFILFNBQVMsS0FDMUIsdUJBQUMsU0FBSSxXQUFVLHFIQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsb0JBQUVaLE9BQU93QyxTQUFTO0FBQUEsdUJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEsa0JBQzFFLHVCQUFDLFVBQUssV0FBVSxtSUFBaUksb0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZEQUEyRDtBQUFBO0FBQUEsa0JBQ3ZFL0IsS0FBS00sYUFBYUgsT0FBTzBGLGVBQWU7QUFBQSxxQkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFBaUQ7QUFBQTtBQUFBLGdCQUN4QzdGLEtBQUtNLGFBQWFSLFVBQVUsSUFBSUUsS0FBS00sYUFBYVIsT0FBTyxNQUFNO0FBQUEsbUJBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvQ0FBbUMsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsZ0JBQzlERSxLQUFLTSxhQUFhUCxPQUNqQix1QkFBQyxVQUFLLFdBQVUsbUdBQ2Q7QUFBQSx5Q0FBQyxnQkFBYSxXQUFVLGFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQUc7QUFBQSxxQkFEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsdUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFEO0FBQUEsbUJBUHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUlEUSxXQUFXSixTQUFTLEtBQ25CLHVCQUFDLFNBQUksV0FBVSxxSEFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLG9CQUFFWixPQUFPd0MsU0FBUztBQUFBLHVCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRTtBQUFBLGtCQUMxRSx1QkFBQyxVQUFLLFdBQVUsK0hBQTZILDBCQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSw2REFBMkQ7QUFBQTtBQUFBLGtCQUN2RXhCLFdBQVdKLE9BQU8wRixlQUFlO0FBQUEscUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsbURBQ1Z0RixxQkFBV1QsV0FBVyxxQ0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNHQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLG9DQUFtQyw0QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0Q7QUFBQSxnQkFDOURTLFdBQVdSLE9BQ1YsdUJBQUMsVUFBSyxXQUFVLG1HQUNkO0FBQUEseUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUFHO0FBQUEscUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLHVCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLG1CQVB6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFJRFUsV0FBV29CLElBQUksQ0FBQ1YsTUFBTW1GLFNBQVM7QUFDOUIsa0JBQUksQ0FBQ25GLEtBQUtoQixVQUFVLENBQUNnQixLQUFLUixZQUFhLFFBQU87QUFDOUMscUJBQ0UsdUJBQUMsU0FBa0IsV0FBVSxxSEFDM0I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxzQkFBRXBCLE9BQU93QyxTQUFTLElBQUl1RTtBQUFBQSx5QkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUY7QUFBQSxvQkFDakYsdUJBQUMsVUFBSyxXQUFVLHVJQUFxSSxxQkFBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsNkRBQTJEO0FBQUE7QUFBQSxvQkFDdkVuRixLQUFLaEIsT0FBTzBGLGVBQWU7QUFBQSx1QkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsbURBQ1YxRSxlQUFLUixlQUFlLG1CQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNHQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLDJEQUEyRFEsZUFBS3JCLFdBQVcsbUJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJHO0FBQUEsa0JBQzFHcUIsS0FBS3BCLE9BQ0osdUJBQUMsVUFBSyxXQUFVLG1HQUNkO0FBQUEsMkNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLG9CQUFHO0FBQUEsdUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsK0JBQThCLHVCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLHFCQVB6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBeEJRb0IsS0FBSzFCLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkE7QUFBQSxZQUVKLENBQUM7QUFBQSxlQS9PSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdQQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHFJQUNiLGlDQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsNENBQ2Y7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0lBQ2YsaUNBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSx3QkFBdUIsaUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FDdEMsdUJBQUMsUUFBRyxXQUFVLE9BQU0sd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRCO0FBQUEsY0FDNUIsdUJBQUMsUUFBRyxXQUFVLE9BQU0sMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsUUFBRyxXQUFVLG1CQUFrQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQyx1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQ3ZDLHVCQUFDLFFBQUcsV0FBVSxrQkFBaUIscUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsUUFBRyxXQUFVLG1CQUFrQixvQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxpQkFQdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNBLHVCQUFDLFdBQU0sV0FBVSxpREFFZEY7QUFBQUEscUJBQU9zQyxJQUFJLENBQUNkLEdBQUdnRixRQUFRO0FBQ3RCLHNCQUFNTixTQUFTMUUsRUFBRW5CLGNBQWMsTUFBTW1CLEVBQUVsQixhQUFhO0FBQ3BELHVCQUNFLHVCQUFDLFFBQWMsV0FBVSxrREFDdkI7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsMkNBQTJDa0csZ0JBQU0sS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUU7QUFBQSxrQkFDakUsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQyxzQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsUUFBRyxXQUFVLHdDQUNYaEY7QUFBQUEsc0JBQUVyQixRQUFRO0FBQUEsb0JBQVM7QUFBQSxvQkFBSXFCLEVBQUVwQixNQUFNO0FBQUEsdUJBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsOERBQThEb0IsWUFBRW5CLGNBQWMsT0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0c7QUFBQSxrQkFDaEcsdUJBQUMsUUFBRyxXQUFVLDhEQUNYbUIsWUFBRW5CLGNBQWNtQixFQUFFbEIsWUFBWSxHQUFHa0IsRUFBRW5CLFVBQVUsS0FBS21CLEVBQUVsQixTQUFTLEtBQUssT0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxvRUFBa0U7QUFBQTtBQUFBLG9CQUM1RTRGLE1BQU1JLGVBQWU7QUFBQSx1QkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQkFDWDlFLFlBQUVoQixPQUNELHVCQUFDLFVBQUssV0FBVSxtR0FDZDtBQUFBLDJDQUFDLGdCQUFhLFdBQVUsaUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFDO0FBQUEsb0JBQUc7QUFBQSx1QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDLEtBTjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkFyQk9nQixFQUFFdEIsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBLGNBRUosQ0FBQztBQUFBLGNBR0FPLEtBQUtFLFVBQVVDLFNBQVMsS0FDdkIsdUJBQUMsUUFBRyxXQUFVLGtEQUNaO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDJDQUEyQ1osaUJBQU93QyxTQUFTLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFLHVCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsb0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLFFBQUcsV0FBVSx3Q0FBdUM7QUFBQTtBQUFBLGtCQUFXL0IsS0FBS0UsVUFBVUosVUFBVSxJQUFJRSxLQUFLRSxVQUFVSixPQUFPLE1BQU07QUFBQSxxQkFBekg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEg7QUFBQSxnQkFDNUgsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLG9FQUFrRTtBQUFBO0FBQUEsa0JBQzVFRSxLQUFLRSxVQUFVQyxPQUFPMEYsZUFBZTtBQUFBLHFCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1CQUNYN0YsZUFBS0UsVUFBVUgsT0FBTyx1QkFBQyxVQUFLLFdBQVUsOENBQTZDLHdCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRSxJQUFVLE9BRHhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FFREMsS0FBS0ksTUFBTUQsU0FBUyxLQUNuQix1QkFBQyxRQUFHLFdBQVUsa0RBQ1o7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsMkNBQTJDWixpQkFBT3dDLFNBQVMsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0UsdUJBQUMsUUFBRyxXQUFVLHNDQUFxQyxvQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsUUFBRyxXQUFVLHdDQUF1QztBQUFBO0FBQUEsa0JBQU8vQixLQUFLSSxNQUFNTixVQUFVLElBQUlFLEtBQUtJLE1BQU1OLE9BQU8sTUFBTTtBQUFBLHFCQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSDtBQUFBLGdCQUNoSCx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxRQUFHLFdBQVUsb0VBQWtFO0FBQUE7QUFBQSxrQkFDNUVFLEtBQUtJLE1BQU1ELE9BQU8wRixlQUFlO0FBQUEscUJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUJBQ1g3RixlQUFLSSxNQUFNTCxPQUFPLHVCQUFDLFVBQUssV0FBVSw4Q0FBNkMsd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFLElBQVUsT0FEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUVEQyxLQUFLSyxPQUFPRixTQUFTLEtBQ3BCLHVCQUFDLFFBQUcsV0FBVSxrREFDWjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwyQ0FBMkNaLGlCQUFPd0MsU0FBUyxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRTtBQUFBLGdCQUMzRSx1QkFBQyxRQUFHLFdBQVUsc0NBQXFDLG9CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHNCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGdCQUMzRCx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxRQUFHLFdBQVUsb0VBQWtFO0FBQUE7QUFBQSxrQkFDNUUvQixLQUFLSyxPQUFPRixPQUFPMEYsZUFBZTtBQUFBLHFCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1CQUNYN0YsZUFBS0ssT0FBT04sT0FBTyx1QkFBQyxVQUFLLFdBQVUsOENBQTZDLHdCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRSxJQUFVLE9BRHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FFREMsS0FBS00sYUFBYUgsU0FBUyxLQUMxQix1QkFBQyxRQUFHLFdBQVUsa0RBQ1o7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsMkNBQTJDWixpQkFBT3dDLFNBQVMsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0UsdUJBQUMsUUFBRyxXQUFVLHNDQUFxQyxvQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsUUFBRyxXQUFVLHdDQUF1QyxrQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxnQkFDdkUsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLG9FQUFrRTtBQUFBO0FBQUEsa0JBQzVFL0IsS0FBS00sYUFBYUgsT0FBTzBGLGVBQWU7QUFBQSxxQkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQkFDWDdGLGVBQUtNLGFBQWFQLE9BQU8sdUJBQUMsVUFBSyxXQUFVLDhDQUE2Qyx3QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUUsSUFBVSxPQUQzRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBSURRLFdBQVdKLFNBQVMsS0FDbkIsdUJBQUMsUUFBRyxXQUFVLGtEQUNaO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDJDQUEyQ1osaUJBQU93QyxTQUFTLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJFO0FBQUEsZ0JBQzNFLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsMEJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsZ0JBQzNELHVCQUFDLFFBQUcsV0FBVSx3Q0FBd0N4QixxQkFBV1QsV0FBVyx5QkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0c7QUFBQSxnQkFDbEcsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsUUFBRyxXQUFVLG9FQUFrRTtBQUFBO0FBQUEsa0JBQzVFUyxXQUFXSixPQUFPMEYsZUFBZTtBQUFBLHFCQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1CQUNYdEYscUJBQVdSLE9BQU8sdUJBQUMsVUFBSyxXQUFVLDhDQUE2Qyx3QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUUsSUFBVSxPQURwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBSUYsdUJBQUMsUUFBRyxXQUFVLCtFQUNaO0FBQUEsdUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSwwQkFBd0I7QUFBQTtBQUFBLGtCQUNsQ2hCO0FBQUFBLGtCQUFXO0FBQUEscUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsdUVBQXFFO0FBQUE7QUFBQSxrQkFDL0VxQyxXQUFXeUUsZUFBZTtBQUFBLHFCQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0I7QUFBQSxtQkFQdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQXZIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdIQTtBQUFBLGVBcElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUlBLEtBdElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUlBLEtBeElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUlBO0FBQUEsYUFuWUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9ZQTtBQUFBLFdBbDZCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbzZCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG1LQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZIQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDRDQUEyQyw0QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxVQUFLLFdBQVUsbUhBQWlIO0FBQUE7QUFBQSxZQUM3SHpFLFdBQVd5RSxlQUFlO0FBQUEsZUFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNL0IsYUFBYSxJQUFJO0FBQUEsY0FDaEMsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxRQUFLLFdBQVUsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQzdCLHVCQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0I7QUFBQTtBQUFBO0FBQUEsWUFObEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1BLGFBQWEsS0FBSztBQUFBLGNBQ2pDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsUUFBSyxXQUFVLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUM3Qix1QkFBQyxVQUFLLDhCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9CO0FBQUE7QUFBQTtBQUFBLFlBTnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFdBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxTQXhpQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlpQ0EsS0ExaUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyaUNBO0FBQUEsSUFHQ3pFLGlCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRO0FBQUEsUUFDUixTQUFTLE1BQU1DLGlCQUFpQixJQUFJO0FBQUEsUUFDcEMsZ0JBQWdCRCxjQUFjOEc7QUFBQUEsUUFDOUIsZUFBZTlHLGNBQWNrRztBQUFBQSxRQUM3QixjQUFjLENBQUN4RixTQUFTO0FBQ3RCd0Q7QUFBQUEsWUFDRWxFLGNBQWNrRDtBQUFBQSxZQUNkeEM7QUFBQUEsWUFDQVYsY0FBY0k7QUFBQUEsWUFDZEosY0FBY21EO0FBQUFBLFVBQ2hCO0FBQUEsUUFDRjtBQUFBO0FBQUEsTUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFZSTtBQUFBLE9BNWpDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK2pDQTtBQUVKO0FBQUUxRCxHQTFoRFdWLGlCQUErQztBQUFBLEtBQS9DQTtBQUErQyxJQUFBbUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlRWZmZWN0IiwiQmlsbFNjYW5uZXJNb2RhbCIsIlgiLCJTYXZlIiwiU2VuZCIsIlBsdXMiLCJUcmFzaDIiLCJVcGxvYWQiLCJDYW1lcmEiLCJDYXIiLCJVdGVuc2lscyIsIkJvb2tPcGVuIiwiU3BhcmtsZXMiLCJGaWxlU3ByZWFkc2hlZXQiLCJDaGVja0NpcmNsZTIiLCJSZWNlaXB0SW5kaWFuUnVwZWUiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIk5ld0ZpbmFuY2VNb2RhbCIsImlzT3BlbiIsIm9uQ2xvc2UiLCJjbHVzdGVyTmFtZSIsImNvbGxlZ2VOYW1lIiwic3BvY05hbWUiLCJmaW5hbmNlck5hbWUiLCJpbml0aWFsRHJhZnQiLCJvblN1Ym1pdEZpbmFuY2UiLCJvblNhdmVEcmFmdFBhY2thZ2UiLCJfcyIsInNlc3Npb25EYXkiLCJzZXRTZXNzaW9uRGF5Iiwic2Vzc2lvbkRhdGUiLCJzZXRTZXNzaW9uRGF0ZSIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInNjYW5uZXJUYXJnZXQiLCJzZXRTY2FubmVyVGFyZ2V0Iiwicm91dGVzIiwic2V0Um91dGVzIiwiaWQiLCJmcm9tIiwidG8iLCJ2b2x1bnRlZXJzIiwicGVyUGVyc29uIiwicmVtYXJrcyIsImJpbGwiLCJmb29kIiwic2V0Rm9vZCIsImJyZWFrZmFzdCIsImFtb3VudCIsImx1bmNoIiwiZGlubmVyIiwicmVmcmVzaG1lbnRzIiwic3RhdGlvbmVyeSIsInNldFN0YXRpb25lcnkiLCJvdGhlckl0ZW1zIiwic2V0T3RoZXJJdGVtcyIsImRlc2NyaXB0aW9uIiwidHJhdmVsVG90YWwiLCJyZWR1Y2UiLCJzdW0iLCJyIiwiZm9vZFRvdGFsIiwic3RhdGlvbmVyeVRvdGFsIiwib3RoZXJUb3RhbCIsIml0ZW0iLCJncmFuZFRvdGFsIiwiaGFuZGxlQWRkUm91dGUiLCJuZXdSb3V0ZSIsIkRhdGUiLCJub3ciLCJwcmV2IiwiaGFuZGxlVXBkYXRlUm91dGUiLCJmaWVsZCIsInZhbHVlIiwibWFwIiwiaGFuZGxlUmVtb3ZlUm91dGUiLCJsZW5ndGgiLCJmaWx0ZXIiLCJoYW5kbGVBZGRPdGhlciIsIm5ld0l0ZW0iLCJoYW5kbGVVcGRhdGVPdGhlciIsImhhbmRsZVJlbW92ZU90aGVyIiwiaGFuZGxlRGlyZWN0RmlsZVVwbG9hZCIsImUiLCJ0eXBlIiwiZm9vZEtleSIsImN1cnJlbnRBbW91bnQiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJyZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwicmVzdWx0IiwiYXR0YWNobWVudCIsInVybCIsImZpbGVOYW1lIiwibmFtZSIsImRldGVjdGVkQW1vdW50IiwiaXNWZXJpZmllZCIsImF0dGFjaEJpbGxUb1RhcmdldCIsInJlYWRBc0RhdGFVUkwiLCJ1cGRhdGVkIiwib3JpZ2luIiwiZGVzdGluYXRpb24iLCJNYXRoIiwicm91bmQiLCJoYW5kbGVTdWJtaXQiLCJpc0RyYWZ0IiwiZW50cmllcyIsImRyYWZ0SWQiLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2UiLCJmb3JFYWNoIiwiYW10IiwicHVzaCIsImRhdGUiLCJjYXRlZ29yeSIsInBhbmNoYXlhdElkIiwicGFuY2hheWF0TmFtZSIsInZpbGxhZ2VOYW1lIiwic3RhdHVzIiwiYmlsbFVybCIsImNvdW50IiwiY291bnRBbW91bnQiLCJ1bmRlZmluZWQiLCJhbGVydCIsImRyYWZ0UGFja2FnZSIsInRpdGxlIiwibGFzdFNhdmVkIiwidG90YWxBbW91bnQiLCJ2YWwiLCJsYWJlbCIsImljb24iLCJ0b3RhbCIsInRhYiIsImlzQWN0aXZlIiwiVGFiSWNvbiIsInRvTG9jYWxlU3RyaW5nIiwicm91dGUiLCJpZHgiLCJyb3dUb3RhbCIsInBhcnNlSW50IiwicGFyc2VGbG9hdCIsImV4cGVjdGVkQW1vdW50Iiwia2V5IiwibWVhbEl0ZW0iLCJvSWR4IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTmV3RmluYW5jZU1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJpbGxTY2FubmVyTW9kYWwsIEJpbGxBdHRhY2htZW50IH0gZnJvbSAnLi9CaWxsU2Nhbm5lck1vZGFsJztcbmltcG9ydCB7IEZpbmFuY2VFbnRyeSwgRmluYW5jZURyYWZ0IH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgWCxcbiAgU2F2ZSxcbiAgU2VuZCxcbiAgUGx1cyxcbiAgVHJhc2gyLFxuICBVcGxvYWQsXG4gIENhbWVyYSxcbiAgQ2FyLFxuICBVdGVuc2lscyxcbiAgQm9va09wZW4sXG4gIFNwYXJrbGVzLFxuICBGaWxlU3ByZWFkc2hlZXQsXG4gIENoZWNrQ2lyY2xlMixcbiAgUmVjZWlwdEluZGlhblJ1cGVlLFxuICBDYWxlbmRhcixcbiAgQnVpbGRpbmcyLFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQWN0aW9uQnV0dG9uIH0gZnJvbSAnLi91aS9hY3Rpb24tYnV0dG9uJztcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJy4vdWkvc2VsZWN0JztcblxuaW50ZXJmYWNlIFJvdXRlSXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIGZyb206IHN0cmluZztcbiAgdG86IHN0cmluZztcbiAgdm9sdW50ZWVyczogbnVtYmVyO1xuICBwZXJQZXJzb246IG51bWJlcjtcbiAgcmVtYXJrczogc3RyaW5nO1xuICBiaWxsOiBCaWxsQXR0YWNobWVudCB8IG51bGw7XG59XG5cbmludGVyZmFjZSBGb29kU3RhdGUge1xuICBicmVha2Zhc3Q6IHsgYW1vdW50OiBudW1iZXI7IHJlbWFya3M6IHN0cmluZzsgYmlsbDogQmlsbEF0dGFjaG1lbnQgfCBudWxsIH07XG4gIGx1bmNoOiB7IGFtb3VudDogbnVtYmVyOyByZW1hcmtzOiBzdHJpbmc7IGJpbGw6IEJpbGxBdHRhY2htZW50IHwgbnVsbCB9O1xuICBkaW5uZXI6IHsgYW1vdW50OiBudW1iZXI7IHJlbWFya3M6IHN0cmluZzsgYmlsbDogQmlsbEF0dGFjaG1lbnQgfCBudWxsIH07XG4gIHJlZnJlc2htZW50czogeyBhbW91bnQ6IG51bWJlcjsgcmVtYXJrczogc3RyaW5nOyBiaWxsOiBCaWxsQXR0YWNobWVudCB8IG51bGwgfTtcbn1cblxuaW50ZXJmYWNlIE90aGVySXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIGFtb3VudDogbnVtYmVyO1xuICByZW1hcmtzOiBzdHJpbmc7XG4gIGJpbGw6IEJpbGxBdHRhY2htZW50IHwgbnVsbDtcbn1cblxuaW50ZXJmYWNlIE5ld0ZpbmFuY2VNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBjbHVzdGVyTmFtZT86IHN0cmluZztcbiAgY29sbGVnZU5hbWU/OiBzdHJpbmc7XG4gIHNwb2NOYW1lPzogc3RyaW5nO1xuICBmaW5hbmNlck5hbWU/OiBzdHJpbmc7XG4gIGluaXRpYWxEcmFmdD86IEZpbmFuY2VEcmFmdCB8IG51bGw7XG4gIG9uU3VibWl0RmluYW5jZTogKGVudHJpZXM6IE9taXQ8RmluYW5jZUVudHJ5LCAnaWQnPltdLCBpc0RyYWZ0OiBib29sZWFuKSA9PiB2b2lkO1xuICBvblNhdmVEcmFmdFBhY2thZ2U/OiAoZHJhZnQ6IEZpbmFuY2VEcmFmdCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IE5ld0ZpbmFuY2VNb2RhbDogUmVhY3QuRkM8TmV3RmluYW5jZU1vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBjbHVzdGVyTmFtZSA9ICdEaGFybWFwdXJpJyxcbiAgY29sbGVnZU5hbWUgPSAnSy5TLlJhbmdhc2FteSBjb2xsZWdlIG9mIFRlY2hub2xvZ3knLFxuICBzcG9jTmFtZSA9ICdOYXJlbmRoYXInLFxuICBmaW5hbmNlck5hbWUgPSAnVFFJIEZpbmFuY2UgVGVhbScsXG4gIGluaXRpYWxEcmFmdCA9IG51bGwsXG4gIG9uU3VibWl0RmluYW5jZSxcbiAgb25TYXZlRHJhZnRQYWNrYWdlLFxufSkgPT4ge1xuICAvLyBNb2RhbCBzdGF0ZVxuICBjb25zdCBbc2Vzc2lvbkRheSwgc2V0U2Vzc2lvbkRheV0gPSB1c2VTdGF0ZTxzdHJpbmc+KGluaXRpYWxEcmFmdD8uc2Vzc2lvbkRheSB8fCAnRGF5IDEnKTtcbiAgY29uc3QgW3Nlc3Npb25EYXRlLCBzZXRTZXNzaW9uRGF0ZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KGluaXRpYWxEcmFmdD8uc2Vzc2lvbkRhdGUgfHwgJzIwMjYtMDgtMjAnKTtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPCdUcmF2ZWwnIHwgJ0Zvb2QnIHwgJ1N0YXRpb25lcnknIHwgJ090aGVyJyB8ICdQcmV2aWV3Jz4oJ1RyYXZlbCcpO1xuXG4gIC8vIFNjYW5uZXIgdGFyZ2V0IHN0YXRlXG4gIGNvbnN0IFtzY2FubmVyVGFyZ2V0LCBzZXRTY2FubmVyVGFyZ2V0XSA9IHVzZVN0YXRlPHtcbiAgICB0eXBlOiAndHJhdmVsJyB8ICdmb29kJyB8ICdzdGF0aW9uZXJ5JyB8ICdvdGhlcic7XG4gICAgaWQ/OiBzdHJpbmc7XG4gICAgZm9vZEtleT86IGtleW9mIEZvb2RTdGF0ZTtcbiAgICBsYWJlbDogc3RyaW5nO1xuICAgIGV4cGVjdGVkQW1vdW50OiBudW1iZXI7XG4gIH0gfCBudWxsPihudWxsKTtcblxuICAvLyAxLiBUcmF2ZWwgU3RhdGVcbiAgY29uc3QgW3JvdXRlcywgc2V0Um91dGVzXSA9IHVzZVN0YXRlPFJvdXRlSXRlbVtdPihcbiAgICBpbml0aWFsRHJhZnQ/LnJvdXRlcyB8fCBbXG4gICAgICB7XG4gICAgICAgIGlkOiAncm91dGUtMScsXG4gICAgICAgIGZyb206ICcnLFxuICAgICAgICB0bzogJycsXG4gICAgICAgIHZvbHVudGVlcnM6IDAsXG4gICAgICAgIHBlclBlcnNvbjogMCxcbiAgICAgICAgcmVtYXJrczogJycsXG4gICAgICAgIGJpbGw6IG51bGwsXG4gICAgICB9LFxuICAgIF1cbiAgKTtcblxuICAvLyAyLiBGb29kIFN0YXRlXG4gIGNvbnN0IFtmb29kLCBzZXRGb29kXSA9IHVzZVN0YXRlPEZvb2RTdGF0ZT4oXG4gICAgaW5pdGlhbERyYWZ0Py5mb29kIHx8IHtcbiAgICAgIGJyZWFrZmFzdDogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICBsdW5jaDogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICBkaW5uZXI6IHsgYW1vdW50OiAwLCByZW1hcmtzOiAnJywgYmlsbDogbnVsbCB9LFxuICAgICAgcmVmcmVzaG1lbnRzOiB7IGFtb3VudDogMCwgcmVtYXJrczogJycsIGJpbGw6IG51bGwgfSxcbiAgICB9XG4gICk7XG5cbiAgLy8gMy4gU3RhdGlvbmVyeSBTdGF0ZVxuICBjb25zdCBbc3RhdGlvbmVyeSwgc2V0U3RhdGlvbmVyeV0gPSB1c2VTdGF0ZTx7XG4gICAgYW1vdW50OiBudW1iZXI7XG4gICAgcmVtYXJrczogc3RyaW5nO1xuICAgIGJpbGw6IEJpbGxBdHRhY2htZW50IHwgbnVsbDtcbiAgfT4oXG4gICAgaW5pdGlhbERyYWZ0Py5zdGF0aW9uZXJ5IHx8IHtcbiAgICAgIGFtb3VudDogMCxcbiAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgYmlsbDogbnVsbCxcbiAgICB9XG4gICk7XG5cbiAgLy8gNC4gT3RoZXIgU3RhdGVcbiAgY29uc3QgW290aGVySXRlbXMsIHNldE90aGVySXRlbXNdID0gdXNlU3RhdGU8T3RoZXJJdGVtW10+KFxuICAgIGluaXRpYWxEcmFmdD8ub3RoZXJJdGVtcyB8fCBbXG4gICAgICB7XG4gICAgICAgIGlkOiAnb3RoZXItMScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgYW1vdW50OiAwLFxuICAgICAgICByZW1hcmtzOiAnJyxcbiAgICAgICAgYmlsbDogbnVsbCxcbiAgICAgIH0sXG4gICAgXVxuICApO1xuXG4gIC8vIFVwZGF0ZSB3aGVuZXZlciBpbml0aWFsRHJhZnQgcHJvcCBjaGFuZ2VzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGluaXRpYWxEcmFmdCkge1xuICAgICAgaWYgKGluaXRpYWxEcmFmdC5zZXNzaW9uRGF5KSBzZXRTZXNzaW9uRGF5KGluaXRpYWxEcmFmdC5zZXNzaW9uRGF5KTtcbiAgICAgIGlmIChpbml0aWFsRHJhZnQuc2Vzc2lvbkRhdGUpIHNldFNlc3Npb25EYXRlKGluaXRpYWxEcmFmdC5zZXNzaW9uRGF0ZSk7XG4gICAgICBpZiAoaW5pdGlhbERyYWZ0LnJvdXRlcykgc2V0Um91dGVzKGluaXRpYWxEcmFmdC5yb3V0ZXMpO1xuICAgICAgaWYgKGluaXRpYWxEcmFmdC5mb29kKSBzZXRGb29kKGluaXRpYWxEcmFmdC5mb29kKTtcbiAgICAgIGlmIChpbml0aWFsRHJhZnQuc3RhdGlvbmVyeSkgc2V0U3RhdGlvbmVyeShpbml0aWFsRHJhZnQuc3RhdGlvbmVyeSk7XG4gICAgICBpZiAoaW5pdGlhbERyYWZ0Lm90aGVySXRlbXMpIHNldE90aGVySXRlbXMoaW5pdGlhbERyYWZ0Lm90aGVySXRlbXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTZXNzaW9uRGF5KCdEYXkgMScpO1xuICAgICAgc2V0Um91dGVzKFtcbiAgICAgICAge1xuICAgICAgICAgIGlkOiAncm91dGUtMScsXG4gICAgICAgICAgZnJvbTogJycsXG4gICAgICAgICAgdG86ICcnLFxuICAgICAgICAgIHZvbHVudGVlcnM6IDAsXG4gICAgICAgICAgcGVyUGVyc29uOiAwLFxuICAgICAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgICAgIGJpbGw6IG51bGwsXG4gICAgICAgIH0sXG4gICAgICBdKTtcbiAgICAgIHNldEZvb2Qoe1xuICAgICAgICBicmVha2Zhc3Q6IHsgYW1vdW50OiAwLCByZW1hcmtzOiAnJywgYmlsbDogbnVsbCB9LFxuICAgICAgICBsdW5jaDogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICAgIGRpbm5lcjogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICAgIHJlZnJlc2htZW50czogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICB9KTtcbiAgICAgIHNldFN0YXRpb25lcnkoe1xuICAgICAgICBhbW91bnQ6IDAsXG4gICAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgICBiaWxsOiBudWxsLFxuICAgICAgfSk7XG4gICAgICBzZXRPdGhlckl0ZW1zKFtcbiAgICAgICAge1xuICAgICAgICAgIGlkOiAnb3RoZXItMScsXG4gICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgIGFtb3VudDogMCxcbiAgICAgICAgICByZW1hcmtzOiAnJyxcbiAgICAgICAgICBiaWxsOiBudWxsLFxuICAgICAgICB9LFxuICAgICAgXSk7XG4gICAgfVxuICB9LCBbaW5pdGlhbERyYWZ0LCBpc09wZW5dKTtcblxuICAvLyBDYWxjdWxhdGlvbnNcbiAgY29uc3QgdHJhdmVsVG90YWwgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gcm91dGVzLnJlZHVjZSgoc3VtLCByKSA9PiBzdW0gKyAoci52b2x1bnRlZXJzIHx8IDApICogKHIucGVyUGVyc29uIHx8IDApLCAwKTtcbiAgfSwgW3JvdXRlc10pO1xuXG4gIGNvbnN0IGZvb2RUb3RhbCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICAoZm9vZC5icmVha2Zhc3QuYW1vdW50IHx8IDApICtcbiAgICAgIChmb29kLmx1bmNoLmFtb3VudCB8fCAwKSArXG4gICAgICAoZm9vZC5kaW5uZXIuYW1vdW50IHx8IDApICtcbiAgICAgIChmb29kLnJlZnJlc2htZW50cy5hbW91bnQgfHwgMClcbiAgICApO1xuICB9LCBbZm9vZF0pO1xuXG4gIGNvbnN0IHN0YXRpb25lcnlUb3RhbCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBzdGF0aW9uZXJ5LmFtb3VudCB8fCAwO1xuICB9LCBbc3RhdGlvbmVyeV0pO1xuXG4gIGNvbnN0IG90aGVyVG90YWwgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gb3RoZXJJdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgKGl0ZW0uYW1vdW50IHx8IDApLCAwKTtcbiAgfSwgW290aGVySXRlbXNdKTtcblxuICBjb25zdCBncmFuZFRvdGFsID0gdHJhdmVsVG90YWwgKyBmb29kVG90YWwgKyBzdGF0aW9uZXJ5VG90YWwgKyBvdGhlclRvdGFsO1xuXG4gIC8vIFRyYXZlbCBSb3V0ZSBBY3Rpb25zXG4gIGNvbnN0IGhhbmRsZUFkZFJvdXRlID0gKCkgPT4ge1xuICAgIGNvbnN0IG5ld1JvdXRlOiBSb3V0ZUl0ZW0gPSB7XG4gICAgICBpZDogYHJvdXRlLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgZnJvbTogJycsXG4gICAgICB0bzogJycsXG4gICAgICB2b2x1bnRlZXJzOiAwLFxuICAgICAgcGVyUGVyc29uOiAwLFxuICAgICAgcmVtYXJrczogJycsXG4gICAgICBiaWxsOiBudWxsLFxuICAgIH07XG4gICAgc2V0Um91dGVzKChwcmV2KSA9PiBbLi4ucHJldiwgbmV3Um91dGVdKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVVcGRhdGVSb3V0ZSA9IChpZDogc3RyaW5nLCBmaWVsZDoga2V5b2YgUm91dGVJdGVtLCB2YWx1ZTogYW55KSA9PiB7XG4gICAgc2V0Um91dGVzKChwcmV2KSA9PlxuICAgICAgcHJldi5tYXAoKHIpID0+IChyLmlkID09PSBpZCA/IHsgLi4uciwgW2ZpZWxkXTogdmFsdWUgfSA6IHIpKVxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVtb3ZlUm91dGUgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGlmIChyb3V0ZXMubGVuZ3RoIDw9IDEpIHtcbiAgICAgIHNldFJvdXRlcyhbXG4gICAgICAgIHtcbiAgICAgICAgICBpZDogYHJvdXRlLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIGZyb206ICcnLFxuICAgICAgICAgIHRvOiAnJyxcbiAgICAgICAgICB2b2x1bnRlZXJzOiAwLFxuICAgICAgICAgIHBlclBlcnNvbjogMCxcbiAgICAgICAgICByZW1hcmtzOiAnJyxcbiAgICAgICAgICBiaWxsOiBudWxsLFxuICAgICAgICB9LFxuICAgICAgXSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldFJvdXRlcygocHJldikgPT4gcHJldi5maWx0ZXIoKHIpID0+IHIuaWQgIT09IGlkKSk7XG4gIH07XG5cbiAgLy8gT3RoZXIgSXRlbSBBY3Rpb25zXG4gIGNvbnN0IGhhbmRsZUFkZE90aGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IG5ld0l0ZW06IE90aGVySXRlbSA9IHtcbiAgICAgIGlkOiBgb3RoZXItJHtEYXRlLm5vdygpfWAsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICBhbW91bnQ6IDAsXG4gICAgICByZW1hcmtzOiAnJyxcbiAgICAgIGJpbGw6IG51bGwsXG4gICAgfTtcbiAgICBzZXRPdGhlckl0ZW1zKChwcmV2KSA9PiBbLi4ucHJldiwgbmV3SXRlbV0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU90aGVyID0gKGlkOiBzdHJpbmcsIGZpZWxkOiBrZXlvZiBPdGhlckl0ZW0sIHZhbHVlOiBhbnkpID0+IHtcbiAgICBzZXRPdGhlckl0ZW1zKChwcmV2KSA9PlxuICAgICAgcHJldi5tYXAoKGl0ZW0pID0+IChpdGVtLmlkID09PSBpZCA/IHsgLi4uaXRlbSwgW2ZpZWxkXTogdmFsdWUgfSA6IGl0ZW0pKVxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVtb3ZlT3RoZXIgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGlmIChvdGhlckl0ZW1zLmxlbmd0aCA8PSAxKSB7XG4gICAgICBzZXRPdGhlckl0ZW1zKFtcbiAgICAgICAge1xuICAgICAgICAgIGlkOiBgb3RoZXItJHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgICAgIGFtb3VudDogMCxcbiAgICAgICAgICByZW1hcmtzOiAnJyxcbiAgICAgICAgICBiaWxsOiBudWxsLFxuICAgICAgICB9LFxuICAgICAgXSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldE90aGVySXRlbXMoKHByZXYpID0+IHByZXYuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBpZCkpO1xuICB9O1xuXG4gIC8vIEZpbGUgVXBsb2FkIERpcmVjdCBIYW5kbGVyXG4gIGNvbnN0IGhhbmRsZURpcmVjdEZpbGVVcGxvYWQgPSAoXG4gICAgZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4sXG4gICAgdHlwZTogJ3RyYXZlbCcgfCAnZm9vZCcgfCAnc3RhdGlvbmVyeScgfCAnb3RoZXInLFxuICAgIGlkPzogc3RyaW5nLFxuICAgIGZvb2RLZXk/OiBrZXlvZiBGb29kU3RhdGUsXG4gICAgY3VycmVudEFtb3VudD86IG51bWJlclxuICApID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoZmlsZSkge1xuICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChyZWFkZXIucmVzdWx0KSB7XG4gICAgICAgICAgY29uc3QgYXR0YWNobWVudDogQmlsbEF0dGFjaG1lbnQgPSB7XG4gICAgICAgICAgICB1cmw6IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nLFxuICAgICAgICAgICAgZmlsZU5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgIGRldGVjdGVkQW1vdW50OiBjdXJyZW50QW1vdW50IHx8IDAsXG4gICAgICAgICAgICBpc1ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgYXR0YWNoQmlsbFRvVGFyZ2V0KHR5cGUsIGF0dGFjaG1lbnQsIGlkLCBmb29kS2V5KTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xuICAgIH1cbiAgfTtcblxuICAvLyBBdHRhY2ggYmlsbCBsb2dpYyB3aXRoIFNtYXJ0IFJvdXRlICYgQW1vdW50IEF1dG8tV3JpdGVyXG4gIGNvbnN0IGF0dGFjaEJpbGxUb1RhcmdldCA9IChcbiAgICB0eXBlOiAndHJhdmVsJyB8ICdmb29kJyB8ICdzdGF0aW9uZXJ5JyB8ICdvdGhlcicsXG4gICAgYmlsbDogQmlsbEF0dGFjaG1lbnQsXG4gICAgaWQ/OiBzdHJpbmcsXG4gICAgZm9vZEtleT86IGtleW9mIEZvb2RTdGF0ZVxuICApID0+IHtcbiAgICBpZiAodHlwZSA9PT0gJ3RyYXZlbCcgJiYgaWQpIHtcbiAgICAgIHNldFJvdXRlcygocHJldikgPT5cbiAgICAgICAgcHJldi5tYXAoKHIpID0+IHtcbiAgICAgICAgICBpZiAoci5pZCA9PT0gaWQpIHtcbiAgICAgICAgICAgIGxldCB1cGRhdGVkID0geyAuLi5yLCBiaWxsIH07XG4gICAgICAgICAgICBpZiAoYmlsbC5vcmlnaW4gJiYgKCFyLmZyb20gfHwgci5mcm9tID09PSAnJykpIHtcbiAgICAgICAgICAgICAgdXBkYXRlZC5mcm9tID0gYmlsbC5vcmlnaW47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYmlsbC5kZXN0aW5hdGlvbiAmJiAoIXIudG8gfHwgci50byA9PT0gJycpKSB7XG4gICAgICAgICAgICAgIHVwZGF0ZWQudG8gPSBiaWxsLmRlc3RpbmF0aW9uO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGJpbGwuZGV0ZWN0ZWRBbW91bnQgJiYgYmlsbC5kZXRlY3RlZEFtb3VudCA+IDApIHtcbiAgICAgICAgICAgICAgaWYgKHVwZGF0ZWQudm9sdW50ZWVycyA+IDApIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVkLnBlclBlcnNvbiA9IE1hdGgucm91bmQoYmlsbC5kZXRlY3RlZEFtb3VudCAvIHVwZGF0ZWQudm9sdW50ZWVycyk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlZC52b2x1bnRlZXJzID0gMTtcbiAgICAgICAgICAgICAgICB1cGRhdGVkLnBlclBlcnNvbiA9IGJpbGwuZGV0ZWN0ZWRBbW91bnQ7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghdXBkYXRlZC5yZW1hcmtzICYmIChiaWxsLm9yaWdpbiB8fCBiaWxsLmRlc3RpbmF0aW9uKSkge1xuICAgICAgICAgICAgICB1cGRhdGVkLnJlbWFya3MgPSBgVGlja2V0IFJvdXRlOiAke2JpbGwub3JpZ2luIHx8ICdPcmlnaW4nfSB0byAke2JpbGwuZGVzdGluYXRpb24gfHwgJ0Rlc3RpbmF0aW9uJ31gO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiByO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdmb29kJyAmJiBmb29kS2V5KSB7XG4gICAgICBzZXRGb29kKChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBbZm9vZEtleV06IHtcbiAgICAgICAgICAuLi5wcmV2W2Zvb2RLZXldLFxuICAgICAgICAgIGJpbGwsXG4gICAgICAgICAgYW1vdW50OiBwcmV2W2Zvb2RLZXldLmFtb3VudCA9PT0gMCAmJiBiaWxsLmRldGVjdGVkQW1vdW50ID8gYmlsbC5kZXRlY3RlZEFtb3VudCA6IHByZXZbZm9vZEtleV0uYW1vdW50LFxuICAgICAgICB9LFxuICAgICAgfSkpO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ3N0YXRpb25lcnknKSB7XG4gICAgICBzZXRTdGF0aW9uZXJ5KChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBiaWxsLFxuICAgICAgICBhbW91bnQ6IHByZXYuYW1vdW50ID09PSAwICYmIGJpbGwuZGV0ZWN0ZWRBbW91bnQgPyBiaWxsLmRldGVjdGVkQW1vdW50IDogcHJldi5hbW91bnQsXG4gICAgICB9KSk7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnb3RoZXInICYmIGlkKSB7XG4gICAgICBzZXRPdGhlckl0ZW1zKChwcmV2KSA9PlxuICAgICAgICBwcmV2Lm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgIGlmIChpdGVtLmlkID09PSBpZCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgICAgYmlsbCxcbiAgICAgICAgICAgICAgYW1vdW50OiBpdGVtLmFtb3VudCA9PT0gMCAmJiBiaWxsLmRldGVjdGVkQW1vdW50ID8gYmlsbC5kZXRlY3RlZEFtb3VudCA6IGl0ZW0uYW1vdW50LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cbiAgfTtcblxuICAvLyBTdWJtaXQgTG9naWNcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGlzRHJhZnQ6IGJvb2xlYW4pID0+IHtcbiAgICBjb25zdCBlbnRyaWVzOiBPbWl0PEZpbmFuY2VFbnRyeSwgJ2lkJz5bXSA9IFtdO1xuICAgIGNvbnN0IGRyYWZ0SWQgPSBpbml0aWFsRHJhZnQ/LmlkIHx8IGBkcmFmdC0ke3Nlc3Npb25EYXkudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9cXHMrL2csICcnKX0tJHtEYXRlLm5vdygpfWA7XG5cbiAgICAvLyAxLiBUcmF2ZWwgRW50cmllc1xuICAgIHJvdXRlcy5mb3JFYWNoKChyKSA9PiB7XG4gICAgICBjb25zdCBhbXQgPSAoci52b2x1bnRlZXJzIHx8IDApICogKHIucGVyUGVyc29uIHx8IDApO1xuICAgICAgaWYgKGFtdCA+IDAgfHwgci5mcm9tIHx8IHIudG8pIHtcbiAgICAgICAgZW50cmllcy5wdXNoKHtcbiAgICAgICAgICBkYXRlOiBzZXNzaW9uRGF0ZSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYFRyYXZlbDogJHtyLmZyb20gfHwgJ09yaWdpbid9IOKGkiAke3IudG8gfHwgJ0Rlc3RpbmF0aW9uJ30gKCR7ci52b2x1bnRlZXJzfSB2b2xzIMOXIOKCuSR7ci5wZXJQZXJzb259KWAsXG4gICAgICAgICAgY2F0ZWdvcnk6ICdUcmF2ZWwnLFxuICAgICAgICAgIGFtb3VudDogYW10LFxuICAgICAgICAgIHBhbmNoYXlhdElkOiAnZGhhcm1hcHVyaS1tYWluJyxcbiAgICAgICAgICBwYW5jaGF5YXROYW1lOiBjbHVzdGVyTmFtZSxcbiAgICAgICAgICB2aWxsYWdlTmFtZTogci50byB8fCAnQ2x1c3RlciBDZW50ZXInLFxuICAgICAgICAgIHN0YXR1czogaXNEcmFmdCA/ICdEcmFmdCcgOiAnQXBwcm92ZWQnLFxuICAgICAgICAgIGJpbGxVcmw6IHIuYmlsbD8udXJsLFxuICAgICAgICAgIHJlbWFya3M6IHIucmVtYXJrcyB8fCBgJHtyLnZvbHVudGVlcnN9IFZvbHVudGVlcnMgdHJhdmVsIHJlaW1idXJzZW1lbnRgLFxuICAgICAgICAgIGNvdW50OiByLnZvbHVudGVlcnMsXG4gICAgICAgICAgY291bnRBbW91bnQ6IGAke3Iudm9sdW50ZWVyc33DlyR7ci5wZXJQZXJzb259YCxcbiAgICAgICAgICBzZXNzaW9uRGF5OiBzZXNzaW9uRGF5LFxuICAgICAgICAgIGRyYWZ0SWQ6IGlzRHJhZnQgPyBkcmFmdElkIDogdW5kZWZpbmVkLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIDIuIEZvb2QgRW50cmllc1xuICAgIGlmIChmb29kLmJyZWFrZmFzdC5hbW91bnQgPiAwKSB7XG4gICAgICBlbnRyaWVzLnB1c2goe1xuICAgICAgICBkYXRlOiBzZXNzaW9uRGF0ZSxcbiAgICAgICAgZGVzY3JpcHRpb246IGBGb29kOiBCcmVha2Zhc3QgKCR7c2Vzc2lvbkRheX0pYCxcbiAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgYW1vdW50OiBmb29kLmJyZWFrZmFzdC5hbW91bnQsXG4gICAgICAgIHBhbmNoYXlhdElkOiAnZGhhcm1hcHVyaS1tYWluJyxcbiAgICAgICAgcGFuY2hheWF0TmFtZTogY2x1c3Rlck5hbWUsXG4gICAgICAgIHZpbGxhZ2VOYW1lOiAnQ2x1c3RlciBDZW50ZXInLFxuICAgICAgICBzdGF0dXM6IGlzRHJhZnQgPyAnRHJhZnQnIDogJ0FwcHJvdmVkJyxcbiAgICAgICAgYmlsbFVybDogZm9vZC5icmVha2Zhc3QuYmlsbD8udXJsLFxuICAgICAgICByZW1hcmtzOiBmb29kLmJyZWFrZmFzdC5yZW1hcmtzIHx8ICdWb2x1bnRlZXIgYnJlYWtmYXN0JyxcbiAgICAgICAgc2Vzc2lvbkRheTogc2Vzc2lvbkRheSxcbiAgICAgICAgZHJhZnRJZDogaXNEcmFmdCA/IGRyYWZ0SWQgOiB1bmRlZmluZWQsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGZvb2QubHVuY2guYW1vdW50ID4gMCkge1xuICAgICAgZW50cmllcy5wdXNoKHtcbiAgICAgICAgZGF0ZTogc2Vzc2lvbkRhdGUsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBgRm9vZDogTHVuY2ggKCR7c2Vzc2lvbkRheX0pYCxcbiAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgYW1vdW50OiBmb29kLmx1bmNoLmFtb3VudCxcbiAgICAgICAgcGFuY2hheWF0SWQ6ICdkaGFybWFwdXJpLW1haW4nLFxuICAgICAgICBwYW5jaGF5YXROYW1lOiBjbHVzdGVyTmFtZSxcbiAgICAgICAgdmlsbGFnZU5hbWU6ICdDbHVzdGVyIENlbnRlcicsXG4gICAgICAgIHN0YXR1czogaXNEcmFmdCA/ICdEcmFmdCcgOiAnQXBwcm92ZWQnLFxuICAgICAgICBiaWxsVXJsOiBmb29kLmx1bmNoLmJpbGw/LnVybCxcbiAgICAgICAgcmVtYXJrczogZm9vZC5sdW5jaC5yZW1hcmtzIHx8ICdWb2x1bnRlZXIgbHVuY2ggbWVhbHMnLFxuICAgICAgICBzZXNzaW9uRGF5OiBzZXNzaW9uRGF5LFxuICAgICAgICBkcmFmdElkOiBpc0RyYWZ0ID8gZHJhZnRJZCA6IHVuZGVmaW5lZCxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoZm9vZC5kaW5uZXIuYW1vdW50ID4gMCkge1xuICAgICAgZW50cmllcy5wdXNoKHtcbiAgICAgICAgZGF0ZTogc2Vzc2lvbkRhdGUsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBgRm9vZDogRGlubmVyICgke3Nlc3Npb25EYXl9KWAsXG4gICAgICAgIGNhdGVnb3J5OiAnRm9vZCcsXG4gICAgICAgIGFtb3VudDogZm9vZC5kaW5uZXIuYW1vdW50LFxuICAgICAgICBwYW5jaGF5YXRJZDogJ2RoYXJtYXB1cmktbWFpbicsXG4gICAgICAgIHBhbmNoYXlhdE5hbWU6IGNsdXN0ZXJOYW1lLFxuICAgICAgICB2aWxsYWdlTmFtZTogJ0NsdXN0ZXIgQ2VudGVyJyxcbiAgICAgICAgc3RhdHVzOiBpc0RyYWZ0ID8gJ0RyYWZ0JyA6ICdBcHByb3ZlZCcsXG4gICAgICAgIGJpbGxVcmw6IGZvb2QuZGlubmVyLmJpbGw/LnVybCxcbiAgICAgICAgcmVtYXJrczogZm9vZC5kaW5uZXIucmVtYXJrcyB8fCAnVm9sdW50ZWVyIGRpbm5lcicsXG4gICAgICAgIHNlc3Npb25EYXk6IHNlc3Npb25EYXksXG4gICAgICAgIGRyYWZ0SWQ6IGlzRHJhZnQgPyBkcmFmdElkIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChmb29kLnJlZnJlc2htZW50cy5hbW91bnQgPiAwKSB7XG4gICAgICBlbnRyaWVzLnB1c2goe1xuICAgICAgICBkYXRlOiBzZXNzaW9uRGF0ZSxcbiAgICAgICAgZGVzY3JpcHRpb246IGBGb29kOiBSZWZyZXNobWVudHMgJiBUZWEgKCR7c2Vzc2lvbkRheX0pYCxcbiAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgYW1vdW50OiBmb29kLnJlZnJlc2htZW50cy5hbW91bnQsXG4gICAgICAgIHBhbmNoYXlhdElkOiAnZGhhcm1hcHVyaS1tYWluJyxcbiAgICAgICAgcGFuY2hheWF0TmFtZTogY2x1c3Rlck5hbWUsXG4gICAgICAgIHZpbGxhZ2VOYW1lOiAnQ2x1c3RlciBDZW50ZXInLFxuICAgICAgICBzdGF0dXM6IGlzRHJhZnQgPyAnRHJhZnQnIDogJ0FwcHJvdmVkJyxcbiAgICAgICAgYmlsbFVybDogZm9vZC5yZWZyZXNobWVudHMuYmlsbD8udXJsLFxuICAgICAgICByZW1hcmtzOiBmb29kLnJlZnJlc2htZW50cy5yZW1hcmtzIHx8ICdTbmFja3MgYW5kIHRlYScsXG4gICAgICAgIHNlc3Npb25EYXk6IHNlc3Npb25EYXksXG4gICAgICAgIGRyYWZ0SWQ6IGlzRHJhZnQgPyBkcmFmdElkIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gMy4gU3RhdGlvbmVyeVxuICAgIGlmIChzdGF0aW9uZXJ5LmFtb3VudCA+IDApIHtcbiAgICAgIGVudHJpZXMucHVzaCh7XG4gICAgICAgIGRhdGU6IHNlc3Npb25EYXRlLFxuICAgICAgICBkZXNjcmlwdGlvbjogYFN0YXRpb25lcnk6IE1hdGVyaWFscyAmIE5vdGVib29rcyAoJHtzZXNzaW9uRGF5fSlgLFxuICAgICAgICBjYXRlZ29yeTogJ01hdGVyaWFscycsXG4gICAgICAgIGFtb3VudDogc3RhdGlvbmVyeS5hbW91bnQsXG4gICAgICAgIHBhbmNoYXlhdElkOiAnZGhhcm1hcHVyaS1tYWluJyxcbiAgICAgICAgcGFuY2hheWF0TmFtZTogY2x1c3Rlck5hbWUsXG4gICAgICAgIHZpbGxhZ2VOYW1lOiAnQ2x1c3RlciBDZW50ZXInLFxuICAgICAgICBzdGF0dXM6IGlzRHJhZnQgPyAnRHJhZnQnIDogJ0FwcHJvdmVkJyxcbiAgICAgICAgYmlsbFVybDogc3RhdGlvbmVyeS5iaWxsPy51cmwsXG4gICAgICAgIHJlbWFya3M6IHN0YXRpb25lcnkucmVtYXJrcyB8fCAnQ2xhc3Nyb29tIHN0dWRlbnQgc3RhdGlvbmVyeSBraXRzJyxcbiAgICAgICAgc2Vzc2lvbkRheTogc2Vzc2lvbkRheSxcbiAgICAgICAgZHJhZnRJZDogaXNEcmFmdCA/IGRyYWZ0SWQgOiB1bmRlZmluZWQsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyA0LiBPdGhlciBJdGVtc1xuICAgIG90aGVySXRlbXMuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgICAgaWYgKGl0ZW0uYW1vdW50ID4gMCB8fCBpdGVtLmRlc2NyaXB0aW9uKSB7XG4gICAgICAgIGVudHJpZXMucHVzaCh7XG4gICAgICAgICAgZGF0ZTogc2Vzc2lvbkRhdGUsXG4gICAgICAgICAgZGVzY3JpcHRpb246IGBPdGhlcjogJHtpdGVtLmRlc2NyaXB0aW9uIHx8ICdNaXNjZWxsYW5lb3VzIEV4cGVuc2UnfWAsXG4gICAgICAgICAgY2F0ZWdvcnk6ICdPdGhlcicsXG4gICAgICAgICAgYW1vdW50OiBpdGVtLmFtb3VudCB8fCAwLFxuICAgICAgICAgIHBhbmNoYXlhdElkOiAnZGhhcm1hcHVyaS1tYWluJyxcbiAgICAgICAgICBwYW5jaGF5YXROYW1lOiBjbHVzdGVyTmFtZSxcbiAgICAgICAgICB2aWxsYWdlTmFtZTogJ0NsdXN0ZXIgQ2VudGVyJyxcbiAgICAgICAgICBzdGF0dXM6IGlzRHJhZnQgPyAnRHJhZnQnIDogJ0FwcHJvdmVkJyxcbiAgICAgICAgICBiaWxsVXJsOiBpdGVtLmJpbGw/LnVybCxcbiAgICAgICAgICByZW1hcmtzOiBpdGVtLnJlbWFya3MgfHwgaXRlbS5kZXNjcmlwdGlvbixcbiAgICAgICAgICBzZXNzaW9uRGF5OiBzZXNzaW9uRGF5LFxuICAgICAgICAgIGRyYWZ0SWQ6IGlzRHJhZnQgPyBkcmFmdElkIDogdW5kZWZpbmVkLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmIChlbnRyaWVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYWxlcnQoJ1BsZWFzZSBmaWxsIGF0IGxlYXN0IG9uZSBleHBlbnNlIGVudHJ5IGJlZm9yZSBzYXZpbmcuJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKG9uU2F2ZURyYWZ0UGFja2FnZSkge1xuICAgICAgY29uc3QgZHJhZnRQYWNrYWdlOiBGaW5hbmNlRHJhZnQgPSB7XG4gICAgICAgIGlkOiBkcmFmdElkLFxuICAgICAgICB0aXRsZTogYCR7c2Vzc2lvbkRheX0gLSBUcmF2ZWwgJiBFeHBlbnNlcyBTaGVldGAsXG4gICAgICAgIHNlc3Npb25EYXksXG4gICAgICAgIHNlc3Npb25EYXRlLFxuICAgICAgICBjbHVzdGVyTmFtZSxcbiAgICAgICAgY29sbGVnZU5hbWUsXG4gICAgICAgIHNwb2NOYW1lLFxuICAgICAgICBmaW5hbmNlck5hbWUsXG4gICAgICAgIHN0YXR1czogaXNEcmFmdCA/ICdEcmFmdCcgOiAnQXBwcm92ZWQnLFxuICAgICAgICBsYXN0U2F2ZWQ6ICdKdXN0IG5vdycsXG4gICAgICAgIHRvdGFsQW1vdW50OiBncmFuZFRvdGFsLFxuICAgICAgICByb3V0ZXMsXG4gICAgICAgIGZvb2QsXG4gICAgICAgIHN0YXRpb25lcnksXG4gICAgICAgIG90aGVySXRlbXMsXG4gICAgICB9O1xuICAgICAgb25TYXZlRHJhZnRQYWNrYWdlKGRyYWZ0UGFja2FnZSk7XG4gICAgfVxuXG4gICAgb25TdWJtaXRGaW5hbmNlKGVudHJpZXMsIGlzRHJhZnQpO1xuICAgIG9uQ2xvc2UoKTtcbiAgfTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTAgc206cC00IG1kOnAtNiBiZy1ncmF5LTkwMC83NSBiYWNrZHJvcC1ibHVyLXNtIGFuaW1hdGUtaW4gZmFkZS1pbi0wIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLWZ1bGwgc206aC1hdXRvIHNtOm1heC1oLVs5NHZoXSBzbTptYXgtdy00eGwgZmxleCBmbGV4LWNvbCByb3VuZGVkLW5vbmUgc206cm91bmRlZC0yeGwgYm9yZGVyLTAgc206Ym9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctdGhlbWUteGwgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICB7LyogVG9wIE1vZGFsIEhlYWRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgc206cHgtNiBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNocmluay0wXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOSB3LTkgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgZGFyazpiZy1icmFuZC01MDAvMTAgZGFyazp0ZXh0LWJyYW5kLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgIDxSZWNlaXB0SW5kaWFuUnVwZWUgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgIE5ldyBGaW5hbmNlIEVudHJ5XG4gICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAge2NsdXN0ZXJOYW1lfSAmbWlkZG90OyB7c2Vzc2lvbkRheX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNlc3Npb24gRGF5ICYgRGF0ZSBTZWxlY3RvciBSb3cgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHNtOnB4LTYgcHktMyBiZy1ncmF5LTUwLzcwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBncmlkIGdyaWQtY29scy0yIGdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgIFNlc3Npb24gRGF5ICpcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPFNlbGVjdCB2YWx1ZT17c2Vzc2lvbkRheX0gb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2Vzc2lvbkRheSh2YWwpfT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTEwIHNtOmgtOSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGF5XCIgLz5cbiAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSAxXCI+RGF5IDE8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSAyXCI+RGF5IDI8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSAzXCI+RGF5IDM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSA0XCI+RGF5IDQ8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSA1XCI+RGF5IDU8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSA2XCI+RGF5IDY8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSA3XCI+RGF5IDc8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRheSA4XCI+RGF5IDg8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgIFNlc3Npb24gRGF0ZSAqXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2Vzc2lvbkRhdGV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZXNzaW9uRGF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDYXRlZ29yeSBUYWJzIFBpbGwgQmFyIChNb2JpbGUgSG9yaXpvbnRhbCBTd2lwZSkgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIHB4LTMgc206cHgtNiBvdmVyZmxvdy14LWF1dG8gbm8tc2Nyb2xsYmFyIGdhcC0xLjUgcHktMi41IHNocmluay0wXCI+XG4gICAgICAgICAgICB7KFxuICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgeyBpZDogJ1RyYXZlbCcsIGxhYmVsOiAnVHJhdmVsJywgaWNvbjogQ2FyLCB0b3RhbDogdHJhdmVsVG90YWwgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnRm9vZCcsIGxhYmVsOiAnRm9vZCcsIGljb246IFV0ZW5zaWxzLCB0b3RhbDogZm9vZFRvdGFsIH0sXG4gICAgICAgICAgICAgICAgeyBpZDogJ1N0YXRpb25lcnknLCBsYWJlbDogJ1N0YXRpb25lcnknLCBpY29uOiBCb29rT3BlbiwgdG90YWw6IHN0YXRpb25lcnlUb3RhbCB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdPdGhlcicsIGxhYmVsOiAnT3RoZXInLCBpY29uOiBTcGFya2xlcywgdG90YWw6IG90aGVyVG90YWwgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnUHJldmlldycsIGxhYmVsOiAnUHJldmlldyBTaGVldCcsIGljb246IEZpbGVTcHJlYWRzaGVldCwgdG90YWw6IDAgfSxcbiAgICAgICAgICAgICAgXSBhcyBjb25zdFxuICAgICAgICAgICAgKS5tYXAoKHRhYikgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZVRhYiA9PT0gdGFiLmlkO1xuICAgICAgICAgICAgICBjb25zdCBUYWJJY29uID0gdGFiLmljb247XG5cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIuaWQgYXMgYW55KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtMyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHdoaXRlc3BhY2Utbm93cmFwICR7XG4gICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWdyYXktMTAwLzcwIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDAgZGFyazpiZy13aGl0ZS81IGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzEwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRhYkljb24gY2xhc3NOYW1lPVwiaC00IHctNCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57dGFiLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHt0YWIudG90YWwgPiAwICYmIHRhYi5pZCAhPT0gJ1ByZXZpZXcnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMC41cHhdIGZvbnQtbW9ubyBmb250LWJvbGQgcHgtMS41IHB5LTAuMiByb3VuZGVkLW1kICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/ICdiZy13aGl0ZS8yMCB0ZXh0LXdoaXRlJyA6ICdiZy1icmFuZC01MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIOKCuXt0YWIudG90YWwudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1vZGFsIFRhYiBDb250ZW50IEFyZWEgd2l0aCBTbW9vdGggU2Nyb2xsICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTQgc206cC02IHNwYWNlLXktNCBiZy1ncmF5LTUwLzUwIGRhcms6YmctZ3JheS05NTAvMzAgY3VzdG9tLXNjcm9sbGJhclwiPlxuICAgICAgICAgICAgey8qIDEuIFRSQVZFTCBUQUIgKi99XG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnVHJhdmVsJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlZvbHVudGVlciBUcmF2ZWwgUm91dGVzPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5BZGQgYWxsIGJ1cywgdHJhaW4sIG9yIGZ1ZWwgdHJpcHMgdGFrZW4gZm9yIHRoaXMgc2Vzc2lvbi48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZFJvdXRlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLWJyYW5kLTUwIGhvdmVyOmJnLWJyYW5kLTEwMCB0ZXh0LWJyYW5kLTYwMCBkYXJrOmJnLWJyYW5kLTUwMC8xMCBkYXJrOnRleHQtYnJhbmQtNDAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtMjAwIGRhcms6Ym9yZGVyLWJyYW5kLTUwMC8yMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BZGQgUm91dGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zLjVcIj5cbiAgICAgICAgICAgICAgICAgIHtyb3V0ZXMubWFwKChyb3V0ZSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJvd1RvdGFsID0gKHJvdXRlLnZvbHVudGVlcnMgfHwgMCkgKiAocm91dGUucGVyUGVyc29uIHx8IDApO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtyb3V0ZS5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCBzbTpwLTUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCByb3VuZGVkLTJ4bCBiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIHNoYWRvdy10aGVtZS14cyBzcGFjZS15LTNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUm91dGUgI3tpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTUwMCBiZy1icmFuZC01MCBkYXJrOmJnLWJyYW5kLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWw6IOKCuXtyb3dUb3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9yaWdpbiAmIERlc3RpbmF0aW9uICgyLWNvbCBvciBzdGFja2VkIG9uIHNtYWxsIG1vYmlsZSkgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGcm9tIChPcmlnaW4pICpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEtTUiBDb2xsZWdlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3V0ZS5mcm9tfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVVcGRhdGVSb3V0ZShyb3V0ZS5pZCwgJ2Zyb20nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBzbTpoLTkgcHgtMyBiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG8gKERlc3RpbmF0aW9uKSAqXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBEaGFybWFwdXJpIFZpbGxhZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JvdXRlLnRvfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVVcGRhdGVSb3V0ZShyb3V0ZS5pZCwgJ3RvJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpib3JkZXItZ3JheS03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBWb2x1bnRlZXJzICYgUGVyIFBlcnNvbiBDb3N0ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVm9sdW50ZWVycyBDb3VudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JvdXRlLnZvbHVudGVlcnMgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVSb3V0ZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3V0ZS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAndm9sdW50ZWVycycsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VJbnQoZS50YXJnZXQudmFsdWUpIHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpib3JkZXItZ3JheS03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvc3QgUGVyIFBlcnNvbiAo4oK5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JvdXRlLnBlclBlcnNvbiB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZVJvdXRlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdwZXJQZXJzb24nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpib3JkZXItZ3JheS03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZW1hcmtzICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW1hcmtzIC8gVGlja2V0IERldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBCdXMgZmFyZSB0aWNrZXQgIzEyODRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyb3V0ZS5yZW1hcmtzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlVXBkYXRlUm91dGUocm91dGUuaWQsICdyZW1hcmtzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHNtOmgtOSBweC0zIGJnLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQmlsbCBBY3Rpb25zICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBzbTp3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleC0xIHNtOmZsZXgtbm9uZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIGRhcms6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOmJnLXdoaXRlLzEwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5VcGxvYWQgQmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLyosYXBwbGljYXRpb24vcGRmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURpcmVjdEZpbGVVcGxvYWQoZSwgJ3RyYXZlbCcsIHJvdXRlLmlkLCB1bmRlZmluZWQsIHJvd1RvdGFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNjYW5uZXJUYXJnZXQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0cmF2ZWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiByb3V0ZS5pZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYFRyYXZlbDogJHtyb3V0ZS5mcm9tIHx8ICdSb3V0ZSd9IHRvICR7cm91dGUudG8gfHwgJ0Rlc3RpbmF0aW9uJ31gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkQW1vdW50OiByb3dUb3RhbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBzbTpmbGV4LW5vbmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBweC0zLjUgcHktMiBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBzaGFkb3ctdGhlbWUteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2NhbiBPQ1IgQmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIHNtOnctYXV0byBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyb3V0ZS5iaWxsICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvMzAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWF4LXctWzEyMHB4XVwiPntyb3V0ZS5iaWxsLmZpbGVOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZVJvdXRlKHJvdXRlLmlkLCAnYmlsbCcsIG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZXJyb3ItNTAwIGhvdmVyOmJnLWVycm9yLTUwIHAtMC41IHJvdW5kZWQgbWwtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JvdXRlcy5sZW5ndGggPiAxICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZVJvdXRlKHJvdXRlLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZXJyb3ItNjAwIGRhcms6dGV4dC1lcnJvci00MDAgaG92ZXI6YmctZXJyb3ItNTAgZGFyazpob3ZlcjpiZy1lcnJvci01MDAvMTAgcHgtMi41IHB5LTEuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgbWwtYXV0b1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SZW1vdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIDIuIEZPT0QgVEFCICovfVxuICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ0Zvb2QnICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+Vm9sdW50ZWVyICYgVGVhbSBNZWFsczwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlJlY29yZCBmb29kIGFuZCByZWZyZXNobWVudHMgcHJvdmlkZWQgZHVyaW5nIHNlc3Npb24gZXhlY3V0aW9uLjwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgeyhcbiAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiAnYnJlYWtmYXN0JywgdGl0bGU6ICdCcmVha2Zhc3QnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdsdW5jaCcsIHRpdGxlOiAnTHVuY2gnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgeyBrZXk6ICdkaW5uZXInLCB0aXRsZTogJ0Rpbm5lcicgfSxcbiAgICAgICAgICAgICAgICAgICAgICB7IGtleTogJ3JlZnJlc2htZW50cycsIHRpdGxlOiAnUmVmcmVzaG1lbnRzICYgVGVhJyB9LFxuICAgICAgICAgICAgICAgICAgICBdIGFzIGNvbnN0XG4gICAgICAgICAgICAgICAgICApLm1hcCgoeyBrZXksIHRpdGxlIH0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbWVhbEl0ZW0gPSBmb29kW2tleV07XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktM1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dGl0bGV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYnJhbmQtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5eyhtZWFsSXRlbS5hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50ICjigrkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttZWFsSXRlbS5hbW91bnQgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb29kKChwcmV2KSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBba2V5XToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXZba2V5XSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQteHMgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpib3JkZXItZ3JheS03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVtYXJrcyAvIERldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiAxNSBtZWFsIHBhY2tldHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttZWFsSXRlbS5yZW1hcmtzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvb2QoKHByZXYpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtrZXldOiB7IC4uLnByZXZba2V5XSwgcmVtYXJrczogZS50YXJnZXQudmFsdWUgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBzbTpoLTkgcHgtMyBiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMSBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0yIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgZGFyazpiZy13aGl0ZS81IHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKixhcHBsaWNhdGlvbi9wZGZcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGlyZWN0RmlsZVVwbG9hZChlLCAnZm9vZCcsIHVuZGVmaW5lZCwga2V5LCBtZWFsSXRlbS5hbW91bnQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNjYW5uZXJUYXJnZXQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnZm9vZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvb2RLZXk6IGtleSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGBGb29kOiAke3RpdGxlfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkQW1vdW50OiBtZWFsSXRlbS5hbW91bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gc2hhZG93LXRoZW1lLXhzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNjYW4gQmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge21lYWxJdGVtLmJpbGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yIHB5LTEgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzMwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAvNDAgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPnttZWFsSXRlbS5iaWxsLmZpbGVOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb29kKChwcmV2KSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtrZXldOiB7IC4uLnByZXZba2V5XSwgYmlsbDogbnVsbCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZXJyb3ItNTAwIGhvdmVyOmJnLWVycm9yLTUwIHAtMC41IHJvdW5kZWQgY3Vyc29yLXBvaW50ZXIgc2hyaW5rLTAgbWwtMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiAzLiBTVEFUSU9ORVJZIFRBQiAqL31cbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdTdGF0aW9uZXJ5JyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPkNsYXNzcm9vbSBTdGF0aW9uZXJ5PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+TWF0ZXJpYWxzLCBwZW5zLCBjaGFydCBwYXBlcnMsIGFjdGl2aXR5IHdvcmtzaGVldHMsIHN0dWRlbnQgbm90ZWJvb2tzLjwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHNtOnAtNSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHJvdW5kZWQtMnhsIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMy41IG1heC13LXhsXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEFtb3VudCAo4oK5KVxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdGlvbmVyeS5hbW91bnQgfHwgJyd9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTdGF0aW9uZXJ5KChwcmV2KSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgc206aC05IHB4LTMgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFJlbWFya3MgLyBEZXNjcmlwdGlvblxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIENoYXJ0IHBhcGVycywgc2tldGNoIHBlbnMsIHN0dWRlbnQgYWN0aXZpdHkgc2hlZXRzXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdGlvbmVyeS5yZW1hcmtzfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFN0YXRpb25lcnkoKHByZXYpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlbWFya3M6IGUudGFyZ2V0LnZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHNtOmgtOSBweC0zIGJnLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0xIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleC0xIHNtOmZsZXgtbm9uZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHB4LTMuNSBweS0yIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgZGFyazpiZy13aGl0ZS81IHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkIEJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLGFwcGxpY2F0aW9uL3BkZlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEaXJlY3RGaWxlVXBsb2FkKGUsICdzdGF0aW9uZXJ5JywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHN0YXRpb25lcnkuYW1vdW50KVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTY2FubmVyVGFyZ2V0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3N0YXRpb25lcnknLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ1N0YXRpb25lcnkgSXRlbXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBleHBlY3RlZEFtb3VudDogc3RhdGlvbmVyeS5hbW91bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgc206ZmxleC1ub25lIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgcHgtMy41IHB5LTIgYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gc2hhZG93LXRoZW1lLXhzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNjYW4gQmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAge3N0YXRpb25lcnkuYmlsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTIuNSBweS0xIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC8zMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwLzQwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e3N0YXRpb25lcnkuYmlsbC5maWxlTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0YXRpb25lcnkoKHByZXYpID0+ICh7IC4uLnByZXYsIGJpbGw6IG51bGwgfSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWVycm9yLTUwMCBob3ZlcjpiZy1lcnJvci01MCBwLTAuNSByb3VuZGVkIGN1cnNvci1wb2ludGVyIHNocmluay0wIG1sLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIDQuIE9USEVSIFRBQiAqL31cbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdPdGhlcicgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5PdGhlciBFeHBlbnNlczwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+QmFubmVycywgbWljL3NvdW5kIHJlbnRhbCwgc3RhZ2Ugc2V0dXBzLCBvciBpbmNpZGVudGFscy48L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZE90aGVyfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLWJyYW5kLTUwIGhvdmVyOmJnLWJyYW5kLTEwMCB0ZXh0LWJyYW5kLTYwMCBkYXJrOmJnLWJyYW5kLTUwMC8xMCBkYXJrOnRleHQtYnJhbmQtNDAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtMjAwIGRhcms6Ym9yZGVyLWJyYW5kLTUwMC8yMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BZGQgRXhwZW5zZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIHtvdGhlckl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCBzbTpwLTUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCByb3VuZGVkLTJ4bCBiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIHNoYWRvdy10aGVtZS14cyBzcGFjZS15LTNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb24gKlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEZsZXggQmFubmVyIGZvciBFdmVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlT3RoZXIoaXRlbS5pZCwgJ2Rlc2NyaXB0aW9uJywgZS50YXJnZXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHNtOmgtOSBweC0zIGJnLXRyYW5zcGFyZW50IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFtb3VudCAo4oK5KSAqXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLmFtb3VudCB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZU90aGVyKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnYW1vdW50JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSkgfHwgMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBzbTpoLTkgcHgtMyBiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpib3JkZXItZ3JheS03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1icmFuZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcHQtMSBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yIHctZnVsbCBzbTp3LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXgtMSBzbTpmbGV4LW5vbmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmJnLXdoaXRlLzUgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5VcGxvYWQgQmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLyosYXBwbGljYXRpb24vcGRmXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURpcmVjdEZpbGVVcGxvYWQoZSwgJ290aGVyJywgaXRlbS5pZCwgdW5kZWZpbmVkLCBpdGVtLmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2Nhbm5lclRhcmdldCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICdvdGhlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBpdGVtLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogYE90aGVyOiAke2l0ZW0uZGVzY3JpcHRpb24gfHwgJ0V4cGVuc2UnfWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cGVjdGVkQW1vdW50OiBpdGVtLmFtb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBzbTpmbGV4LW5vbmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBweC0zLjUgcHktMiBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBzaGFkb3ctdGhlbWUteHMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2NhbiBCaWxsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGwgc206dy1hdXRvIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmJpbGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvMzAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBtYXgtdy1bMTIwcHhdXCI+e2l0ZW0uYmlsbC5maWxlTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVPdGhlcihpdGVtLmlkLCAnYmlsbCcsIG51bGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWVycm9yLTUwMCBob3ZlcjpiZy1lcnJvci01MCBwLTAuNSByb3VuZGVkIGN1cnNvci1wb2ludGVyIG1sLTFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvdGhlckl0ZW1zLmxlbmd0aCA+IDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlT3RoZXIoaXRlbS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1lcnJvci02MDAgZGFyazp0ZXh0LWVycm9yLTQwMCBob3ZlcjpiZy1lcnJvci01MCBkYXJrOmhvdmVyOmJnLWVycm9yLTUwMC8xMCBweC0yLjUgcHktMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBtbC1hdXRvXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlbW92ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiA1LiBGT1JNQVQgUFJFVklFVyBUQUIgKi99XG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnUHJldmlldycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5UUUkgRmluYW5jZSBWb3VjaGVyIFN1bW1hcnk8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5QcmV2aWV3IGdlbmVyYXRlZCBleHBlbnNlIHNoZWV0IGJlZm9yZSBvZmZpY2lhbCBzdWJtaXNzaW9uLjwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBNT0JJTEUgUFJFVklFVyBTVU1NQVJZIENBUkRTIChWaXNpYmxlIG9uIG1vYmlsZSBzY3JlZW5zIDwgNzY4cHgpICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvY2sgbWQ6aGlkZGVuIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgey8qIFNlc3Npb24gT3ZlcnZpZXcgQmFubmVyICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctYnJhbmQtNTAvNzAgZGFyazpiZy1icmFuZC01MDAvMTAgYm9yZGVyIGJvcmRlci1icmFuZC0yMDAgZGFyazpib3JkZXItYnJhbmQtNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWJyYW5kLTQwMCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb25EYXl9ICZtaWRkb3Q7IHtzZXNzaW9uRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjbHVzdGVyTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBibG9ja1wiPlRvdGFsIFZvdWNoZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2dyYW5kVG90YWwudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBUcmF2ZWwgSXRlbSBDYXJkcyAqL31cbiAgICAgICAgICAgICAgICAgIHtyb3V0ZXMubWFwKChyLCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWwgPSAoci52b2x1bnRlZXJzIHx8IDApICogKHIucGVyUGVyc29uIHx8IDApO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyLmlkfSBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj4je2lkeCArIDF9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0yIHB5LTAuNSByb3VuZGVkLW1kIHRleHQtWzEwLjVweF0gZm9udC1ib2xkIGJnLWJyYW5kLTUwIHRleHQtYnJhbmQtNjAwIGRhcms6YmctYnJhbmQtNTAwLzE1IGRhcms6dGV4dC1icmFuZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYXZlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTYwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyLmZyb20gfHwgJ09yaWdpbid9IOKGkiB7ci50byB8fCAnRGVzdGluYXRpb24nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtyLnZvbHVudGVlcnMgJiYgci5wZXJQZXJzb24gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGb3JtdWxhOiB7ci52b2x1bnRlZXJzfSB2b2xzIMOXIOKCuXtyLnBlclBlcnNvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTEuNSBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdHJ1bmNhdGUgbWF4LXctWzE3MHB4XVwiPntyLnJlbWFya3MgfHwgJ1ZvbHVudGVlciB0cmF2ZWwnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3IuYmlsbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz4gQXR0YWNoZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LVsxMC41cHhdXCI+Tm8gYmlsbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBGb29kIEl0ZW0gQ2FyZHMgKi99XG4gICAgICAgICAgICAgICAgICB7Zm9vZC5icmVha2Zhc3QuYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIHNoYWRvdy10aGVtZS14cyBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LWdyYXktNDAwXCI+I3tyb3V0ZXMubGVuZ3RoICsgMX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0yIHB5LTAuNSByb3VuZGVkLW1kIHRleHQtWzEwLjVweF0gZm9udC1ib2xkIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIGRhcms6YmctYW1iZXItNTAwLzE1IGRhcms6dGV4dC1hbWJlci00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGb29kXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtmb29kLmJyZWFrZmFzdC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQnJlYWtmYXN0IHtmb29kLmJyZWFrZmFzdC5yZW1hcmtzID8gYCgke2Zvb2QuYnJlYWtmYXN0LnJlbWFya3N9KWAgOiAnJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMS41IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5CcmVha2Zhc3QgbWVhbHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5icmVha2Zhc3QuYmlsbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPiBBdHRhY2hlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtWzEwLjVweF1cIj5ObyBiaWxsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7Zm9vZC5sdW5jaC5hbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj4je3JvdXRlcy5sZW5ndGggKyAyfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci01MDAvMTUgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvb2RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvb2QubHVuY2guYW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEx1bmNoIHtmb29kLmx1bmNoLnJlbWFya3MgPyBgKCR7Zm9vZC5sdW5jaC5yZW1hcmtzfSlgIDogJyd9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTEuNSBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+THVuY2ggbWVhbHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5sdW5jaC5iaWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+IEF0dGFjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1bMTAuNXB4XVwiPk5vIGJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHtmb29kLmRpbm5lci5hbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj4je3JvdXRlcy5sZW5ndGggKyAzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci01MDAvMTUgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvb2RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvb2QuZGlubmVyLmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBEaW5uZXIge2Zvb2QuZGlubmVyLnJlbWFya3MgPyBgKCR7Zm9vZC5kaW5uZXIucmVtYXJrc30pYCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0xLjUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkRpbm5lciBtZWFsczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb29kLmRpbm5lci5iaWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+IEF0dGFjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1bMTAuNXB4XVwiPk5vIGJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHtmb29kLnJlZnJlc2htZW50cy5hbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj4je3JvdXRlcy5sZW5ndGggKyA0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgZGFyazpiZy1hbWJlci01MDAvMTUgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvb2RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvb2QucmVmcmVzaG1lbnRzLmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBSZWZyZXNobWVudHMgJiBUZWEge2Zvb2QucmVmcmVzaG1lbnRzLnJlbWFya3MgPyBgKCR7Zm9vZC5yZWZyZXNobWVudHMucmVtYXJrc30pYCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0xLjUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlNuYWNrcyAmIFRlYTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb29kLnJlZnJlc2htZW50cy5iaWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+IEF0dGFjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1bMTAuNXB4XVwiPk5vIGJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBTdGF0aW9uZXJ5IEl0ZW0gQ2FyZCAqL31cbiAgICAgICAgICAgICAgICAgIHtzdGF0aW9uZXJ5LmFtb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBzaGFkb3ctdGhlbWUteHMgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1ncmF5LTQwMFwiPiN7cm91dGVzLmxlbmd0aCArIDV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgcHgtMiBweS0wLjUgcm91bmRlZC1tZCB0ZXh0LVsxMC41cHhdIGZvbnQtYm9sZCBiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgZGFyazpiZy1ibHVlLTUwMC8xNSBkYXJrOnRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdGF0aW9uZXJ5XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtzdGF0aW9uZXJ5LmFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdGlvbmVyeS5yZW1hcmtzIHx8ICdDbGFzc3Jvb20gTWF0ZXJpYWxzICYgTm90ZWJvb2tzJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMS41IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5TdHVkZW50IGtpdHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdGlvbmVyeS5iaWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+IEF0dGFjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1bMTAuNXB4XVwiPk5vIGJpbGw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBPdGhlciBJdGVtIENhcmRzICovfVxuICAgICAgICAgICAgICAgICAge290aGVySXRlbXMubWFwKChpdGVtLCBvSWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaXRlbS5hbW91bnQgJiYgIWl0ZW0uZGVzY3JpcHRpb24pIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLmlkfSBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2hhZG93LXRoZW1lLXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj4je3JvdXRlcy5sZW5ndGggKyA2ICsgb0lkeH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctcHVycGxlLTUwIHRleHQtcHVycGxlLTcwMCBkYXJrOmJnLXB1cnBsZS01MDAvMTUgZGFyazp0ZXh0LXB1cnBsZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE90aGVyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0uYW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVzY3JpcHRpb24gfHwgJ01pc2NlbGxhbmVvdXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtMS41IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBtYXgtdy1bMTcwcHhdXCI+e2l0ZW0ucmVtYXJrcyB8fCAnT3RoZXIgZXhwZW5zZSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iaWxsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LXNlbWlib2xkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPiBBdHRhY2hlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtWzEwLjVweF1cIj5ObyBiaWxsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBERVNLVE9QIFBSRVZJRVcgVEFCTEUgKFZpc2libGUgb24gZGVza3RvcCA+PSA3NjhweCkgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6YmxvY2sgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDAgYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCBzaGFkb3ctdGhlbWUteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHMgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgZGFyazpiZy13aGl0ZS9bMC4wMl0gYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB3LTEyIHRleHQtY2VudGVyXCI+IzwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTNcIj5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTNcIj5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5Db3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5Gb3JtdWxhPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXJpZ2h0XCI+VG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyXCI+QmlsbDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTEwMCBkYXJrOmRpdmlkZS1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRyYXZlbCBSb3V0ZXMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICB7cm91dGVzLm1hcCgociwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsID0gKHIudm9sdW50ZWVycyB8fCAwKSAqIChyLnBlclBlcnNvbiB8fCAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtyLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzYwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+e2lkeCArIDF9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPlRyYXZlbDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyLmZyb20gfHwgJ09yaWdpbid9IOKGkiB7ci50byB8fCAnRGVzdGluYXRpb24nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXIgZm9udC1tb25vIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3Iudm9sdW50ZWVycyB8fCAn4oCUJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciBmb250LW1vbm8gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Iudm9sdW50ZWVycyAmJiByLnBlclBlcnNvbiA/IGAke3Iudm9sdW50ZWVyc33Dl+KCuSR7ci5wZXJQZXJzb259YCA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IuYmlsbCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IEF0dGFjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC14c1wiPuKAlDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9vZCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb29kLmJyZWFrZmFzdC5hbW91bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTAvNjAgZGFyazpob3ZlcjpiZy13aGl0ZS9bMC4wMl1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+e3JvdXRlcy5sZW5ndGggKyAxfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyBmb250LXNlbWlib2xkIHRleHQtd2FybmluZy02MDBcIj5Gb29kPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMjAwXCI+QnJlYWtmYXN0IHtmb29kLmJyZWFrZmFzdC5yZW1hcmtzID8gYCgke2Zvb2QuYnJlYWtmYXN0LnJlbWFya3N9KWAgOiAnJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBmb250LW1vbm9cIj7igJQ8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBmb250LW1vbm9cIj7igJQ8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7Zm9vZC5icmVha2Zhc3QuYW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5icmVha2Zhc3QuYmlsbCA/IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgZm9udC1zZW1pYm9sZCB0ZXh0LVsxMXB4XVwiPkF0dGFjaGVkPC9zcGFuPiA6ICfigJQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvb2QubHVuY2guYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzYwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPntyb3V0ZXMubGVuZ3RoICsgMn08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1zZW1pYm9sZCB0ZXh0LXdhcm5pbmctNjAwXCI+Rm9vZDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPkx1bmNoIHtmb29kLmx1bmNoLnJlbWFya3MgPyBgKCR7Zm9vZC5sdW5jaC5yZW1hcmtzfSlgIDogJyd9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+4oCUPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+4oCUPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtcmlnaHQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvb2QubHVuY2guYW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5sdW5jaC5iaWxsID8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBmb250LXNlbWlib2xkIHRleHQtWzExcHhdXCI+QXR0YWNoZWQ8L3NwYW4+IDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5kaW5uZXIuYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzYwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPntyb3V0ZXMubGVuZ3RoICsgM308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1zZW1pYm9sZCB0ZXh0LXdhcm5pbmctNjAwXCI+Rm9vZDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPkRpbm5lcjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtmb29kLmRpbm5lci5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb29kLmRpbm5lci5iaWxsID8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBmb250LXNlbWlib2xkIHRleHQtWzExcHhdXCI+QXR0YWNoZWQ8L3NwYW4+IDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9vZC5yZWZyZXNobWVudHMuYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzYwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPntyb3V0ZXMubGVuZ3RoICsgNH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1zZW1pYm9sZCB0ZXh0LXdhcm5pbmctNjAwXCI+Rm9vZDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPlJlZnJlc2htZW50cyAmIFRlYTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPuKAlDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtmb29kLnJlZnJlc2htZW50cy5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb29kLnJlZnJlc2htZW50cy5iaWxsID8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBmb250LXNlbWlib2xkIHRleHQtWzExcHhdXCI+QXR0YWNoZWQ8L3NwYW4+IDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0aW9uZXJ5ICovfVxuICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRpb25lcnkuYW1vdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzYwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbW9ub1wiPntyb3V0ZXMubGVuZ3RoICsgNX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPlN0YXRpb25lcnk8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0yMDBcIj57c3RhdGlvbmVyeS5yZW1hcmtzIHx8ICdDbGFzc3Jvb20gTWF0ZXJpYWxzJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBmb250LW1vbm9cIj7igJQ8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBmb250LW1vbm9cIj7igJQ8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7c3RhdGlvbmVyeS5hbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0aW9uZXJ5LmJpbGwgPyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTFweF1cIj5BdHRhY2hlZDwvc3Bhbj4gOiAn4oCUJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEdyYW5kIFRvdGFsIFN0cmlwICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLWJyYW5kLTUwLzcwIGRhcms6YmctYnJhbmQtNTAwLzEwIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17NX0gY2xhc3NOYW1lPVwicC0zIHRleHQtcmlnaHQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYW5kIFRvdGFsICh7c2Vzc2lvbkRheX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1yaWdodCBmb250LW1vbm8gdGV4dC1zbSB0ZXh0LWJyYW5kLTYwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2dyYW5kVG90YWwudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPjwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEdyYW5kIFRvdGFsIFN0cmlwICYgTW9iaWxlIFN0aWNreSBCb3R0b20gQWN0aW9ucyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgc206cHgtNiBweS0zIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzaHJpbmstMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktYmV0d2VlbiBzbTpqdXN0aWZ5LXN0YXJ0XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5HcmFuZCBUb3RhbDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWJhc2Ugc206dGV4dC1sZyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgYmctYnJhbmQtNTAgZGFyazpiZy1icmFuZC01MDAvMTUgcHgtMi41IHB5LTEgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAgICAgIOKCuXtncmFuZFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIHNtOnctYXV0b1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtNCBweS0yLjUgc206cHktMiBib3JkZXIgYm9yZGVyLWJyYW5kLTUwMC80MCB0ZXh0LWJyYW5kLTYwMCBiZy1icmFuZC01MC81MCBob3ZlcjpiZy1icmFuZC01MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGRhcms6Ym9yZGVyLWJyYW5kLTUwMC8zMCBkYXJrOmJnLWJyYW5kLTUwMC8xMCBkYXJrOnRleHQtYnJhbmQtNDAwIGRhcms6aG92ZXI6YmctYnJhbmQtNTAwLzIwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIHNoYWRvdy10aGVtZS14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2F2ZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U2F2ZSBEcmFmdDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdWJtaXQoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtNCBweS0yLjUgc206cHktMiBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uIHNoYWRvdy10aGVtZS14cyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U3VibWl0IEZpbmFuY2U8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBCaWxsIENhbWVyYSBTY2FubmVyIE1vZGFsICovfVxuICAgICAge3NjYW5uZXJUYXJnZXQgJiYgKFxuICAgICAgICA8QmlsbFNjYW5uZXJNb2RhbFxuICAgICAgICAgIGlzT3Blbj17dHJ1ZX1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTY2FubmVyVGFyZ2V0KG51bGwpfVxuICAgICAgICAgIGV4cGVjdGVkQW1vdW50PXtzY2FubmVyVGFyZ2V0LmV4cGVjdGVkQW1vdW50fVxuICAgICAgICAgIGNhdGVnb3J5TGFiZWw9e3NjYW5uZXJUYXJnZXQubGFiZWx9XG4gICAgICAgICAgb25BdHRhY2hCaWxsPXsoYmlsbCkgPT4ge1xuICAgICAgICAgICAgYXR0YWNoQmlsbFRvVGFyZ2V0KFxuICAgICAgICAgICAgICBzY2FubmVyVGFyZ2V0LnR5cGUsXG4gICAgICAgICAgICAgIGJpbGwsXG4gICAgICAgICAgICAgIHNjYW5uZXJUYXJnZXQuaWQsXG4gICAgICAgICAgICAgIHNjYW5uZXJUYXJnZXQuZm9vZEtleVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8Lz5cbiAgKTtcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTmV3RmluYW5jZU1vZGFsLnRzeCJ9