import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PanchayatDetailView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
function villageStudentsOf(panchayatId, villageName, all) {
  return all.filter(
    (s) => (s.panchayatId === panchayatId || s.panchayatName.toLowerCase().includes(panchayatId.toLowerCase())) && s.villageName.toLowerCase() === villageName.toLowerCase()
  );
}
const STATUS_BADGE = {
  "On Track": "badge-success",
  "Correction Required": "badge-warning",
  "Action Needed": "badge-error"
};
export const PanchayatDetailView = ({
  panchayat,
  students,
  onBack,
  onNavigate,
  onAddVillage
}) => {
  _s();
  const [showAdd, setShowAdd] = useState(false);
  const [newVillage, setNewVillage] = useState("");
  const [search, setSearch] = useState("");
  const panStudents = students.filter(
    (s) => s.panchayatId === panchayat.id || s.panchayatName.toLowerCase() === panchayat.name.toLowerCase()
  );
  const boys = panStudents.filter((s) => s.gender === "male").length;
  const girls = panStudents.filter((s) => s.gender === "female").length;
  const filtered = panchayat.villages.filter(
    (v) => v.name.toLowerCase().includes(search.toLowerCase())
  );
  const handleSave = (e) => {
    e.preventDefault();
    if (!newVillage.trim()) return;
    onAddVillage(panchayat.id, newVillage.trim());
    setNewVillage("");
    setShowAdd(false);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "page-container space-y-5", children: [
    /* @__PURE__ */ jsxDEV("nav", { className: "breadcrumb", children: [
      /* @__PURE__ */ jsxDEV("button", { onClick: onBack, children: "Panchayats" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 14 }, children: "chevron_right" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "current", children: panchayat.name }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card p-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "page-title mb-0", children: panchayat.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 70,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `badge ${STATUS_BADGE[panchayat.status] || "badge-neutral"}`, children: panchayat.status }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 71,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 69,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "page-subtitle", children: [
            panchayat.cluster,
            " · ",
            panchayat.villages.length,
            " villages · ",
            panStudents.length,
            " students"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 75,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 68,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 self-start", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => onNavigate("attendance", panchayat.id), className: "btn btn-secondary btn-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 15 }, children: "how_to_reg" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 81,
              columnNumber: 15
            }, this),
            "Attendance"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowAdd(true), className: "btn btn-primary btn-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 15 }, children: "add" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 85,
              columnNumber: 15
            }, this),
            "Add village"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 84,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 79,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t", style: { borderColor: "var(--color-border)" }, children: [
        { label: "Villages", value: panchayat.villages.length },
        { label: "Students", value: panStudents.length },
        { label: "Girls", value: girls },
        { label: "Boys", value: boys }
      ].map(
        (s) => /* @__PURE__ */ jsxDEV("div", { className: "stat-item", style: { cursor: "default" }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "stat-label", children: s.label }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 99,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "stat-value", children: s.value }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 100,
            columnNumber: 15
          }, this)
        ] }, s.label, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "card overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "flex items-center justify-between px-4 py-3 border-b",
          style: { borderColor: "var(--color-border)" },
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold", style: { color: "var(--color-text)" }, children: "Village learning centers" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 112,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "material-symbols-outlined absolute top-1/2 -translate-y-1/2",
                    style: { left: 8, fontSize: 15, color: "var(--color-text-muted)", pointerEvents: "none" },
                    children: "search"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 117,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Filter...",
                    value: search,
                    onChange: (e) => setSearch(e.target.value),
                    className: "field-input",
                    style: { paddingLeft: 28, width: 160, height: 30, fontSize: "0.75rem" }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 123,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 116,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowAdd(true), className: "btn btn-secondary btn-sm", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 15 }, children: "add" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                  lineNumber: 133,
                  columnNumber: 15
                }, this),
                "Add"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 132,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 115,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 108,
          columnNumber: 9
        },
        this
      ),
      filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "empty-state", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "empty-state-icon", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 20 }, children: "holiday_village" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 142,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 141,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "empty-state-title", children: "No village centers found" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 144,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "empty-state-body", children: search ? "Try a different search term." : "Add a village to this panchayat." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 145,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "divide-y", style: { borderColor: "var(--color-border)" }, children: filtered.map((v, idx) => {
        const vs = villageStudentsOf(panchayat.id, v.name, panStudents);
        const vBoys = vs.filter((s) => s.gender === "male").length;
        const vGirls = vs.filter((s) => s.gender === "female").length;
        const count = vs.length || v.studentCount;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => onNavigate("students", panchayat.id, v.name),
            className: "flex items-center justify-between gap-4 px-4 py-3 cursor-pointer",
            style: { background: "transparent" },
            onMouseEnter: (e) => e.currentTarget.style.background = "var(--color-surface)",
            onMouseLeave: (e) => e.currentTarget.style.background = "transparent",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "text-xs font-semibold w-6 text-center shrink-0",
                    style: { color: "var(--color-text-muted)" },
                    children: idx + 1
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 167,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold", style: { color: "var(--color-text)" }, children: v.name }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 174,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs", style: { color: "var(--color-text-muted)" }, children: [
                    vBoys,
                    " boys · ",
                    vGirls,
                    " girls"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 177,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                  lineNumber: 173,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 166,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "badge badge-brand", children: [
                  count,
                  " students"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                  lineNumber: 183,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: "material-symbols-outlined",
                    style: { fontSize: 16, color: "var(--color-text-muted)" },
                    children: "chevron_right"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                    lineNumber: 184,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 182,
                columnNumber: 19
              }, this)
            ]
          },
          v.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 158,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
      lineNumber: 107,
      columnNumber: 7
    }, this),
    showAdd && /* @__PURE__ */ jsxDEV("div", { className: "modal-overlay", onClick: () => setShowAdd(false), children: /* @__PURE__ */ jsxDEV("div", { className: "modal", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "modal-header", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "modal-title", children: [
          "Add village to ",
          panchayat.name
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 203,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowAdd(false), className: "btn btn-ghost btn-icon", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", style: { fontSize: 18 }, children: "close" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 205,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 204,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 202,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSave, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "modal-body space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "field-label", htmlFor: "vil-name", children: "Village name *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 211,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                id: "vil-name",
                type: "text",
                required: true,
                placeholder: "e.g., Ammapettai",
                value: newVillage,
                onChange: (e) => setNewVillage(e.target.value),
                className: "field-input",
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 212,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 210,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "field-label", children: "Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
              lineNumber: 224,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                disabled: true,
                value: panchayat.name,
                className: "field-input",
                style: { background: "var(--color-surface)", color: "var(--color-text-secondary)" }
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
                lineNumber: 225,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 223,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 209,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "modal-footer", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowAdd(false), className: "btn btn-ghost", children: "Cancel" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 235,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary", children: "Save village" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
            lineNumber: 236,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
          lineNumber: 234,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
        lineNumber: 208,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
      lineNumber: 201,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
      lineNumber: 200,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
};
_s(PanchayatDetailView, "zlVfkMb3ZohyLwNUPBv4IrXu6JU=");
_c = PanchayatDetailView;
var _c;
$RefreshReg$(_c, "PanchayatDetailView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/PanchayatDetailView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRROztBQTNEUixTQUFnQkEsZ0JBQWdCO0FBV2hDLFNBQVNDLGtCQUFrQkMsYUFBcUJDLGFBQXFCQyxLQUFnQjtBQUNuRixTQUFPQSxJQUFJQztBQUFBQSxJQUNULENBQUNDLE9BQ0VBLEVBQUVKLGdCQUFnQkEsZUFDakJJLEVBQUVDLGNBQWNDLFlBQVksRUFBRUMsU0FBU1AsWUFBWU0sWUFBWSxDQUFDLE1BQ2xFRixFQUFFSCxZQUFZSyxZQUFZLE1BQU1MLFlBQVlLLFlBQVk7QUFBQSxFQUM1RDtBQUNGO0FBRUEsTUFBTUUsZUFBdUM7QUFBQSxFQUMzQyxZQUF1QjtBQUFBLEVBQ3ZCLHVCQUF1QjtBQUFBLEVBQ3ZCLGlCQUF1QjtBQUN6QjtBQUVPLGFBQU1DLHNCQUEwREEsQ0FBQztBQUFBLEVBQ3RFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFRbkIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ29CLFlBQVlDLGFBQWEsSUFBSXJCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzQixRQUFRQyxTQUFTLElBQVV2QixTQUFTLEVBQUU7QUFFN0MsUUFBTXdCLGNBQWdCWCxTQUFTUjtBQUFBQSxJQUM3QixDQUFDQyxNQUFNQSxFQUFFSixnQkFBZ0JVLFVBQVVhLE1BQU1uQixFQUFFQyxjQUFjQyxZQUFZLE1BQU1JLFVBQVVjLEtBQUtsQixZQUFZO0FBQUEsRUFDeEc7QUFDQSxRQUFNbUIsT0FBUUgsWUFBWW5CLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRXNCLFdBQVcsTUFBTSxFQUFFQztBQUM3RCxRQUFNQyxRQUFRTixZQUFZbkIsT0FBTyxDQUFDQyxNQUFNQSxFQUFFc0IsV0FBVyxRQUFRLEVBQUVDO0FBRS9ELFFBQU1FLFdBQVduQixVQUFVb0IsU0FBUzNCO0FBQUFBLElBQU8sQ0FBQzRCLE1BQzFDQSxFQUFFUCxLQUFLbEIsWUFBWSxFQUFFQyxTQUFTYSxPQUFPZCxZQUFZLENBQUM7QUFBQSxFQUNwRDtBQUVBLFFBQU0wQixhQUFhQSxDQUFDQyxNQUF1QjtBQUN6Q0EsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUNoQixXQUFXaUIsS0FBSyxFQUFHO0FBQ3hCckIsaUJBQWFKLFVBQVVhLElBQUlMLFdBQVdpQixLQUFLLENBQUM7QUFDNUNoQixrQkFBYyxFQUFFO0FBQ2hCRixlQUFXLEtBQUs7QUFBQSxFQUNsQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxZQUFPLFNBQVNMLFFBQVEsMEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUNuQyx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRXdCLFVBQVUsR0FBRyxHQUFHLDZCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGO0FBQUEsTUFDbEYsdUJBQUMsVUFBSyxXQUFVLFdBQVcxQixvQkFBVWMsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwQztBQUFBLFNBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1CQUFtQmQsb0JBQVVjLFFBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsWUFDaEQsdUJBQUMsVUFBSyxXQUFXLFNBQVNoQixhQUFhRSxVQUFVMkIsTUFBTSxLQUFLLGVBQWUsSUFDeEUzQixvQkFBVTJCLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGlCQUNWM0I7QUFBQUEsc0JBQVU0QjtBQUFBQSxZQUFRO0FBQUEsWUFBSTVCLFVBQVVvQixTQUFTSDtBQUFBQSxZQUFPO0FBQUEsWUFBYUwsWUFBWUs7QUFBQUEsWUFBTztBQUFBLGVBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsaUNBQUMsWUFBTyxTQUFTLE1BQU1kLFdBQVcsY0FBY0gsVUFBVWEsRUFBRSxHQUFHLFdBQVUsNEJBQ3ZFO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDZCQUE0QixPQUFPLEVBQUVhLFVBQVUsR0FBRyxHQUFHLDBCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQU87QUFBQSxlQUR4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTW5CLFdBQVcsSUFBSSxHQUFHLFdBQVUsMEJBQ2pEO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDZCQUE0QixPQUFPLEVBQUVtQixVQUFVLEdBQUcsR0FBRyxtQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUFPO0FBQUEsZUFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDREQUEyRCxPQUFPLEVBQUVHLGFBQWEsc0JBQXNCLEdBQ25IO0FBQUEsUUFDQyxFQUFFQyxPQUFPLFlBQVlDLE9BQU8vQixVQUFVb0IsU0FBU0gsT0FBTztBQUFBLFFBQ3RELEVBQUVhLE9BQU8sWUFBWUMsT0FBT25CLFlBQVlLLE9BQU87QUFBQSxRQUMvQyxFQUFFYSxPQUFPLFNBQVNDLE9BQU9iLE1BQU07QUFBQSxRQUMvQixFQUFFWSxPQUFPLFFBQVFDLE9BQU9oQixLQUFLO0FBQUEsTUFBQyxFQUM5QmlCO0FBQUFBLFFBQUksQ0FBQ3RDLE1BQ0wsdUJBQUMsU0FBa0IsV0FBVSxhQUFZLE9BQU8sRUFBRXVDLFFBQVEsVUFBVSxHQUNsRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxjQUFjdkMsWUFBRW9DLFNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFDO0FBQUEsVUFDckMsdUJBQUMsU0FBSSxXQUFVLGNBQWNwQyxZQUFFcUMsU0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxhQUY3QnJDLEVBQUVvQyxPQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsT0FBTyxFQUFFRCxhQUFhLHNCQUFzQjtBQUFBLFVBRTVDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3QixPQUFPLEVBQUVLLE9BQU8sb0JBQW9CLEdBQUcsd0NBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8sRUFBRUMsTUFBTSxHQUFHVCxVQUFVLElBQUlRLE9BQU8sMkJBQTJCRSxlQUFlLE9BQU87QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osT0FBTzFCO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQ2EsTUFBTVosVUFBVVksRUFBRWMsT0FBT04sS0FBSztBQUFBLG9CQUN6QyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxFQUFFTyxhQUFhLElBQUlDLE9BQU8sS0FBS0MsUUFBUSxJQUFJZCxVQUFVLFVBQVU7QUFBQTtBQUFBLGtCQU54RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTBFO0FBQUEsbUJBYjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUNBLHVCQUFDLFlBQU8sU0FBUyxNQUFNbkIsV0FBVyxJQUFJLEdBQUcsV0FBVSw0QkFDakQ7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRW1CLFVBQVUsR0FBRyxHQUFHLG1CQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUFPO0FBQUEsbUJBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQTtBQUFBO0FBQUEsUUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BNkJBO0FBQUEsTUFFQ1AsU0FBU0YsV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRVMsVUFBVSxHQUFHLEdBQUcsK0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0YsS0FEdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQW9CLHdDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsU0FBSSxXQUFVLG9CQUNaaEIsbUJBQVMsaUNBQWlDLHNDQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxZQUFXLE9BQU8sRUFBRW1CLGFBQWEsc0JBQXNCLEdBQ25FVixtQkFBU2EsSUFBSSxDQUFDWCxHQUFHb0IsUUFBUTtBQUN4QixjQUFNQyxLQUFTckQsa0JBQWtCVyxVQUFVYSxJQUFJUSxFQUFFUCxNQUFNRixXQUFXO0FBQ2xFLGNBQU0rQixRQUFTRCxHQUFHakQsT0FBTyxDQUFDQyxNQUFNQSxFQUFFc0IsV0FBVyxNQUFNLEVBQUVDO0FBQ3JELGNBQU0yQixTQUFTRixHQUFHakQsT0FBTyxDQUFDQyxNQUFNQSxFQUFFc0IsV0FBVyxRQUFRLEVBQUVDO0FBQ3ZELGNBQU00QixRQUFTSCxHQUFHekIsVUFBVUksRUFBRXlCO0FBRTlCLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsTUFBTTNDLFdBQVcsWUFBWUgsVUFBVWEsSUFBSVEsRUFBRVAsSUFBSTtBQUFBLFlBQzFELFdBQVU7QUFBQSxZQUNWLE9BQU8sRUFBRWlDLFlBQVksY0FBYztBQUFBLFlBQ25DLGNBQWMsQ0FBQXhCLE1BQUtBLEVBQUV5QixjQUFjQyxNQUFNRixhQUFhO0FBQUEsWUFDdEQsY0FBYyxDQUFBeEIsTUFBS0EsRUFBRXlCLGNBQWNDLE1BQU1GLGFBQWE7QUFBQSxZQUV0RDtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLEVBQUViLE9BQU8sMEJBQTBCO0FBQUEsb0JBRXpDTyxnQkFBTTtBQUFBO0FBQUEsa0JBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSx5QkFBd0IsT0FBTyxFQUFFUCxPQUFPLG9CQUFvQixHQUN4RWIsWUFBRVAsUUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQVUsT0FBTyxFQUFFb0IsT0FBTywwQkFBMEIsR0FDaEVTO0FBQUFBO0FBQUFBLG9CQUFNO0FBQUEsb0JBQVNDO0FBQUFBLG9CQUFPO0FBQUEsdUJBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHFCQUFxQkM7QUFBQUE7QUFBQUEsa0JBQU07QUFBQSxxQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8sRUFBRW5CLFVBQVUsSUFBSVEsT0FBTywwQkFBMEI7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQTtBQUFBO0FBQUEsVUEvQktiLEVBQUVSO0FBQUFBLFVBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlDQTtBQUFBLE1BRUosQ0FBQyxLQTNDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBO0FBQUEsU0F2Rko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlGQTtBQUFBLElBR0NQLFdBQ0MsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQixTQUFTLE1BQU1DLFdBQVcsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsU0FBUSxTQUFTLENBQUNnQixNQUFNQSxFQUFFMkIsZ0JBQWdCLEdBQ3ZEO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLFVBQWdCbEQsVUFBVWM7QUFBQUEsYUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQzdELHVCQUFDLFlBQU8sU0FBUyxNQUFNUCxXQUFXLEtBQUssR0FBRyxXQUFVLDBCQUNsRCxpQ0FBQyxVQUFLLFdBQVUsNkJBQTRCLE9BQU8sRUFBRW1CLFVBQVUsR0FBRyxHQUFHLHFCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFLEtBRDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVVKLFlBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGVBQWMsU0FBUSxZQUFXLDhCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPZDtBQUFBQSxnQkFDUCxVQUFVLENBQUNlLE1BQU1kLGNBQWNjLEVBQUVjLE9BQU9OLEtBQUs7QUFBQSxnQkFDN0MsV0FBVTtBQUFBLGdCQUNWLFdBQVM7QUFBQTtBQUFBLGNBUlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUVc7QUFBQSxlQVZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZUFBYyx5QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxZQUN4QztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLE9BQU8vQixVQUFVYztBQUFBQSxnQkFDakIsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRWlDLFlBQVksd0JBQXdCYixPQUFPLDhCQUE4QjtBQUFBO0FBQUEsY0FMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3NGO0FBQUEsZUFQeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTNCLFdBQVcsS0FBSyxHQUFHLFdBQVUsaUJBQWdCLHNCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsbUJBQWtCLDRCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBRmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxTQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NBLEtBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0E7QUFBQSxPQXZMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUxBO0FBRUo7QUFBRUYsR0F6TldOLHFCQUF1RDtBQUFBLEtBQXZEQTtBQUF1RCxJQUFBb0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ2aWxsYWdlU3R1ZGVudHNPZiIsInBhbmNoYXlhdElkIiwidmlsbGFnZU5hbWUiLCJhbGwiLCJmaWx0ZXIiLCJzIiwicGFuY2hheWF0TmFtZSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJTVEFUVVNfQkFER0UiLCJQYW5jaGF5YXREZXRhaWxWaWV3IiwicGFuY2hheWF0Iiwic3R1ZGVudHMiLCJvbkJhY2siLCJvbk5hdmlnYXRlIiwib25BZGRWaWxsYWdlIiwiX3MiLCJzaG93QWRkIiwic2V0U2hvd0FkZCIsIm5ld1ZpbGxhZ2UiLCJzZXROZXdWaWxsYWdlIiwic2VhcmNoIiwic2V0U2VhcmNoIiwicGFuU3R1ZGVudHMiLCJpZCIsIm5hbWUiLCJib3lzIiwiZ2VuZGVyIiwibGVuZ3RoIiwiZ2lybHMiLCJmaWx0ZXJlZCIsInZpbGxhZ2VzIiwidiIsImhhbmRsZVNhdmUiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwiZm9udFNpemUiLCJzdGF0dXMiLCJjbHVzdGVyIiwiYm9yZGVyQ29sb3IiLCJsYWJlbCIsInZhbHVlIiwibWFwIiwiY3Vyc29yIiwiY29sb3IiLCJsZWZ0IiwicG9pbnRlckV2ZW50cyIsInRhcmdldCIsInBhZGRpbmdMZWZ0Iiwid2lkdGgiLCJoZWlnaHQiLCJpZHgiLCJ2cyIsInZCb3lzIiwidkdpcmxzIiwiY291bnQiLCJzdHVkZW50Q291bnQiLCJiYWNrZ3JvdW5kIiwiY3VycmVudFRhcmdldCIsInN0eWxlIiwic3RvcFByb3BhZ2F0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGFuY2hheWF0RGV0YWlsVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBUYWJUeXBlLCBQYW5jaGF5YXQsIFN0dWRlbnQgfSBmcm9tICcuLi90eXBlcyc7XHJcblxyXG5pbnRlcmZhY2UgUGFuY2hheWF0RGV0YWlsVmlld1Byb3BzIHtcclxuICBwYW5jaGF5YXQ6IFBhbmNoYXlhdDtcclxuICBzdHVkZW50czogU3R1ZGVudFtdO1xyXG4gIG9uQmFjazogKCkgPT4gdm9pZDtcclxuICBvbk5hdmlnYXRlOiAodGFiOiBUYWJUeXBlLCB0YXJnZXRJZD86IHN0cmluZywgc2Vjb25kYXJ5UGFyYW0/OiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgb25BZGRWaWxsYWdlOiAocGFuY2hheWF0SWQ6IHN0cmluZywgdmlsbGFnZU5hbWU6IHN0cmluZykgPT4gdm9pZDtcclxufVxyXG5cclxuZnVuY3Rpb24gdmlsbGFnZVN0dWRlbnRzT2YocGFuY2hheWF0SWQ6IHN0cmluZywgdmlsbGFnZU5hbWU6IHN0cmluZywgYWxsOiBTdHVkZW50W10pIHtcclxuICByZXR1cm4gYWxsLmZpbHRlcihcclxuICAgIChzKSA9PlxyXG4gICAgICAocy5wYW5jaGF5YXRJZCA9PT0gcGFuY2hheWF0SWQgfHxcclxuICAgICAgICBzLnBhbmNoYXlhdE5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhwYW5jaGF5YXRJZC50b0xvd2VyQ2FzZSgpKSkgJiZcclxuICAgICAgcy52aWxsYWdlTmFtZS50b0xvd2VyQ2FzZSgpID09PSB2aWxsYWdlTmFtZS50b0xvd2VyQ2FzZSgpXHJcbiAgKTtcclxufVxyXG5cclxuY29uc3QgU1RBVFVTX0JBREdFOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xyXG4gICdPbiBUcmFjayc6ICAgICAgICAgICAgJ2JhZGdlLXN1Y2Nlc3MnLFxyXG4gICdDb3JyZWN0aW9uIFJlcXVpcmVkJzogJ2JhZGdlLXdhcm5pbmcnLFxyXG4gICdBY3Rpb24gTmVlZGVkJzogICAgICAgJ2JhZGdlLWVycm9yJyxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBQYW5jaGF5YXREZXRhaWxWaWV3OiBSZWFjdC5GQzxQYW5jaGF5YXREZXRhaWxWaWV3UHJvcHM+ID0gKHtcclxuICBwYW5jaGF5YXQsXHJcbiAgc3R1ZGVudHMsXHJcbiAgb25CYWNrLFxyXG4gIG9uTmF2aWdhdGUsXHJcbiAgb25BZGRWaWxsYWdlLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW3Nob3dBZGQsIHNldFNob3dBZGRdICAgICA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbmV3VmlsbGFnZSwgc2V0TmV3VmlsbGFnZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSAgICAgICA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgY29uc3QgcGFuU3R1ZGVudHMgICA9IHN0dWRlbnRzLmZpbHRlcihcclxuICAgIChzKSA9PiBzLnBhbmNoYXlhdElkID09PSBwYW5jaGF5YXQuaWQgfHwgcy5wYW5jaGF5YXROYW1lLnRvTG93ZXJDYXNlKCkgPT09IHBhbmNoYXlhdC5uYW1lLnRvTG93ZXJDYXNlKClcclxuICApO1xyXG4gIGNvbnN0IGJveXMgID0gcGFuU3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLmdlbmRlciA9PT0gJ21hbGUnKS5sZW5ndGg7XHJcbiAgY29uc3QgZ2lybHMgPSBwYW5TdHVkZW50cy5maWx0ZXIoKHMpID0+IHMuZ2VuZGVyID09PSAnZmVtYWxlJykubGVuZ3RoO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZCA9IHBhbmNoYXlhdC52aWxsYWdlcy5maWx0ZXIoKHYpID0+XHJcbiAgICB2Lm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2gudG9Mb3dlckNhc2UoKSlcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKCFuZXdWaWxsYWdlLnRyaW0oKSkgcmV0dXJuO1xyXG4gICAgb25BZGRWaWxsYWdlKHBhbmNoYXlhdC5pZCwgbmV3VmlsbGFnZS50cmltKCkpO1xyXG4gICAgc2V0TmV3VmlsbGFnZSgnJyk7XHJcbiAgICBzZXRTaG93QWRkKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWNvbnRhaW5lciBzcGFjZS15LTVcIj5cclxuICAgICAgey8qIEJyZWFkY3J1bWIgKi99XHJcbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYlwiPlxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17b25CYWNrfT5QYW5jaGF5YXRzPC9idXR0b24+XHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxNCB9fT5jaGV2cm9uX3JpZ2h0PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImN1cnJlbnRcIj57cGFuY2hheWF0Lm5hbWV9PC9zcGFuPlxyXG4gICAgICA8L25hdj5cclxuXHJcbiAgICAgIHsvKiBQYWdlIGhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHAtNVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMVwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJwYWdlLXRpdGxlIG1iLTBcIj57cGFuY2hheWF0Lm5hbWV9PC9oMT5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BiYWRnZSAke1NUQVRVU19CQURHRVtwYW5jaGF5YXQuc3RhdHVzXSB8fCAnYmFkZ2UtbmV1dHJhbCd9YH0+XHJcbiAgICAgICAgICAgICAgICB7cGFuY2hheWF0LnN0YXR1c31cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwYWdlLXN1YnRpdGxlXCI+XHJcbiAgICAgICAgICAgICAge3BhbmNoYXlhdC5jbHVzdGVyfSDCtyB7cGFuY2hheWF0LnZpbGxhZ2VzLmxlbmd0aH0gdmlsbGFnZXMgwrcge3BhblN0dWRlbnRzLmxlbmd0aH0gc3R1ZGVudHNcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgc2VsZi1zdGFydFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2F0dGVuZGFuY2UnLCBwYW5jaGF5YXQuaWQpfSBjbGFzc05hbWU9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkXCIgc3R5bGU9e3sgZm9udFNpemU6IDE1IH19Pmhvd190b19yZWc8L3NwYW4+XHJcbiAgICAgICAgICAgICAgQXR0ZW5kYW5jZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkKHRydWUpfSBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZFwiIHN0eWxlPXt7IGZvbnRTaXplOiAxNSB9fT5hZGQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgQWRkIHZpbGxhZ2VcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zIG10LTQgcHQtNCBib3JkZXItdFwiIHN0eWxlPXt7IGJvcmRlckNvbG9yOiAndmFyKC0tY29sb3ItYm9yZGVyKScgfX0+XHJcbiAgICAgICAgICB7W1xyXG4gICAgICAgICAgICB7IGxhYmVsOiAnVmlsbGFnZXMnLCB2YWx1ZTogcGFuY2hheWF0LnZpbGxhZ2VzLmxlbmd0aCB9LFxyXG4gICAgICAgICAgICB7IGxhYmVsOiAnU3R1ZGVudHMnLCB2YWx1ZTogcGFuU3R1ZGVudHMubGVuZ3RoIH0sXHJcbiAgICAgICAgICAgIHsgbGFiZWw6ICdHaXJscycsIHZhbHVlOiBnaXJscyB9LFxyXG4gICAgICAgICAgICB7IGxhYmVsOiAnQm95cycsIHZhbHVlOiBib3lzIH0sXHJcbiAgICAgICAgICBdLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17cy5sYWJlbH0gY2xhc3NOYW1lPVwic3RhdC1pdGVtXCIgc3R5bGU9e3sgY3Vyc29yOiAnZGVmYXVsdCcgfX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LWxhYmVsXCI+e3MubGFiZWx9PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LXZhbHVlXCI+e3MudmFsdWV9PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFZpbGxhZ2VzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyBib3JkZXItYlwiXHJcbiAgICAgICAgICBzdHlsZT17eyBib3JkZXJDb2xvcjogJ3ZhcigtLWNvbG9yLWJvcmRlciknIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1jb2xvci10ZXh0KScgfX0+XHJcbiAgICAgICAgICAgIFZpbGxhZ2UgbGVhcm5pbmcgY2VudGVyc1xyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgYWJzb2x1dGUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGxlZnQ6IDgsIGZvbnRTaXplOiAxNSwgY29sb3I6ICd2YXIoLS1jb2xvci10ZXh0LW11dGVkKScsIHBvaW50ZXJFdmVudHM6ICdub25lJyB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHNlYXJjaFxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmlsdGVyLi4uXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmaWVsZC1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nTGVmdDogMjgsIHdpZHRoOiAxNjAsIGhlaWdodDogMzAsIGZvbnRTaXplOiAnMC43NXJlbScgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkKHRydWUpfSBjbGFzc05hbWU9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkXCIgc3R5bGU9e3sgZm9udFNpemU6IDE1IH19PmFkZDwvc3Bhbj5cclxuICAgICAgICAgICAgICBBZGRcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2ZpbHRlcmVkLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wdHktc3RhdGVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZS1pY29uXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZFwiIHN0eWxlPXt7IGZvbnRTaXplOiAyMCB9fT5ob2xpZGF5X3ZpbGxhZ2U8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlLXRpdGxlXCI+Tm8gdmlsbGFnZSBjZW50ZXJzIGZvdW5kPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZW1wdHktc3RhdGUtYm9keVwiPlxyXG4gICAgICAgICAgICAgIHtzZWFyY2ggPyAnVHJ5IGEgZGlmZmVyZW50IHNlYXJjaCB0ZXJtLicgOiAnQWRkIGEgdmlsbGFnZSB0byB0aGlzIHBhbmNoYXlhdC4nfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15XCIgc3R5bGU9e3sgYm9yZGVyQ29sb3I6ICd2YXIoLS1jb2xvci1ib3JkZXIpJyB9fT5cclxuICAgICAgICAgICAge2ZpbHRlcmVkLm1hcCgodiwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgdnMgICAgID0gdmlsbGFnZVN0dWRlbnRzT2YocGFuY2hheWF0LmlkLCB2Lm5hbWUsIHBhblN0dWRlbnRzKTtcclxuICAgICAgICAgICAgICBjb25zdCB2Qm95cyAgPSB2cy5maWx0ZXIoKHMpID0+IHMuZ2VuZGVyID09PSAnbWFsZScpLmxlbmd0aDtcclxuICAgICAgICAgICAgICBjb25zdCB2R2lybHMgPSB2cy5maWx0ZXIoKHMpID0+IHMuZ2VuZGVyID09PSAnZmVtYWxlJykubGVuZ3RoO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGNvdW50ICA9IHZzLmxlbmd0aCB8fCB2LnN0dWRlbnRDb3VudDtcclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAga2V5PXt2LmlkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdzdHVkZW50cycsIHBhbmNoYXlhdC5pZCwgdi5uYW1lKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB4LTQgcHktMyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd0cmFuc3BhcmVudCcgfX1cclxuICAgICAgICAgICAgICAgICAgb25Nb3VzZUVudGVyPXtlID0+IGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kID0gJ3ZhcigtLWNvbG9yLXN1cmZhY2UpJ31cclxuICAgICAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXtlID0+IGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kID0gJ3RyYW5zcGFyZW50J31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdy02IHRleHQtY2VudGVyIHNocmluay0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tY29sb3ItdGV4dC1tdXRlZCknIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2lkeCArIDF9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tY29sb3ItdGV4dCknIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWNvbG9yLXRleHQtbXV0ZWQpJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3ZCb3lzfSBib3lzIMK3IHt2R2lybHN9IGdpcmxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiYWRnZSBiYWRnZS1icmFuZFwiPntjb3VudH0gc3R1ZGVudHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IDE2LCBjb2xvcjogJ3ZhcigtLWNvbG9yLXRleHQtbXV0ZWQpJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIGNoZXZyb25fcmlnaHRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBZGQgdmlsbGFnZSBtb2RhbCAqL31cclxuICAgICAge3Nob3dBZGQgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtb3ZlcmxheVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGQoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWxcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibW9kYWwtaGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibW9kYWwtdGl0bGVcIj5BZGQgdmlsbGFnZSB0byB7cGFuY2hheWF0Lm5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZChmYWxzZSl9IGNsYXNzTmFtZT1cImJ0biBidG4tZ2hvc3QgYnRuLWljb25cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWRcIiBzdHlsZT17eyBmb250U2l6ZTogMTggfX0+Y2xvc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1ib2R5IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZpZWxkLWxhYmVsXCIgaHRtbEZvcj1cInZpbC1uYW1lXCI+VmlsbGFnZSBuYW1lICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInZpbC1uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIEFtbWFwZXR0YWlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdWaWxsYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3VmlsbGFnZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmllbGQtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmllbGQtbGFiZWxcIj5QYW5jaGF5YXQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFuY2hheWF0Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmllbGQtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1jb2xvci1zdXJmYWNlKScsIGNvbG9yOiAndmFyKC0tY29sb3ItdGV4dC1zZWNvbmRhcnkpJyB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtb2RhbC1mb290ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGQoZmFsc2UpfSBjbGFzc05hbWU9XCJidG4gYnRuLWdob3N0XCI+Q2FuY2VsPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIj5TYXZlIHZpbGxhZ2U8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUGFuY2hheWF0RGV0YWlsVmlldy50c3gifQ==