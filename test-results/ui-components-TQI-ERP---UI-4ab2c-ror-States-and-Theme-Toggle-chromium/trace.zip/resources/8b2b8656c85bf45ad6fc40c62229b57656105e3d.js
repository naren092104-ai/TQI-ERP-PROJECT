import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\ui\\select.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport1_react);
import * as SelectPrimitive from "/node_modules/.vite/deps/@radix-ui_react-select.js?v=8975830d";
import { Check, ChevronDown, ChevronUp } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { cn } from "/src/lib/utils.ts";
const Select = SelectPrimitive.Root;
const SelectGroup = SelectPrimitive.Group;
const SelectValue = SelectPrimitive.Value;
const SelectTrigger = React.forwardRef(
  _c = ({ className, children, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Trigger,
    {
      ref,
      className: cn(
        "flex h-9 w-full items-center justify-between rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-800 shadow-theme-xs ring-offset-white placeholder:text-gray-400 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 disabled:cursor-not-allowed disabled:opacity-50 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:ring-offset-gray-950 dark:placeholder:text-gray-500 [&>span]:line-clamp-1",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxDEV(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4 opacity-50 ml-1.5 shrink-0" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 24,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 23,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 14,
      columnNumber: 1
    },
    this
  )
);
_c2 = SelectTrigger;
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;
const SelectScrollUpButton = React.forwardRef(
  _c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.ScrollUpButton,
    {
      ref,
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(ChevronUp, { className: "h-4 w-4" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
        lineNumber: 42,
        columnNumber: 5
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 34,
      columnNumber: 1
    },
    this
  )
);
_c4 = SelectScrollUpButton;
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;
const SelectScrollDownButton = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.ScrollDownButton,
    {
      ref,
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "h-4 w-4" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
        lineNumber: 59,
        columnNumber: 5
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 51,
      columnNumber: 1
    },
    this
  )
);
_c6 = SelectScrollDownButton;
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;
const SelectContent = React.forwardRef(
  _c7 = ({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ jsxDEV(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Content,
    {
      ref,
      className: cn(
        "relative z-[999999] max-h-96 min-w-[8rem] overflow-hidden rounded-xl border border-gray-200 bg-white text-gray-800 shadow-theme-lg dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      ),
      position,
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(SelectScrollUpButton, {}, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 81,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          SelectPrimitive.Viewport,
          {
            className: cn(
              "p-1.5",
              position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
            ),
            children
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
            lineNumber: 82,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(SelectScrollDownButton, {}, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 91,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  ) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
    lineNumber: 69,
    columnNumber: 1
  }, this)
);
_c8 = SelectContent;
SelectContent.displayName = SelectPrimitive.Content.displayName;
const SelectLabel = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Label,
    {
      ref,
      className: cn("px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 101,
      columnNumber: 1
    },
    this
  )
);
_c0 = SelectLabel;
SelectLabel.displayName = SelectPrimitive.Label.displayName;
const SelectItem = React.forwardRef(
  _c1 = ({ className, children, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Item,
    {
      ref,
      className: cn(
        "relative flex w-full cursor-pointer select-none items-center rounded-lg py-1.5 pl-8 pr-2.5 text-xs font-medium outline-none focus:bg-gray-100 dark:focus:bg-gray-800 focus:text-gray-900 dark:focus:text-white data-[disabled]:pointer-events-none data-[disabled]:opacity-50 text-gray-700 dark:text-gray-200 transition-colors",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsxDEV(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsxDEV(Check, { className: "h-3.5 w-3.5 text-brand-500" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 123,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 122,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 121,
          columnNumber: 5
        }, this),
        /* @__PURE__ */ jsxDEV(SelectPrimitive.ItemText, { children }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
          lineNumber: 127,
          columnNumber: 5
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 113,
      columnNumber: 1
    },
    this
  )
);
_c10 = SelectItem;
SelectItem.displayName = SelectPrimitive.Item.displayName;
const SelectSeparator = React.forwardRef(
  _c11 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    SelectPrimitive.Separator,
    {
      ref,
      className: cn("-mx-1 my-1 h-px bg-gray-100 dark:bg-gray-800", className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx",
      lineNumber: 136,
      columnNumber: 1
    },
    this
  )
);
_c12 = SelectSeparator;
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;
export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton
};
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12;
$RefreshReg$(_c, "SelectTrigger$React.forwardRef");
$RefreshReg$(_c2, "SelectTrigger");
$RefreshReg$(_c3, "SelectScrollUpButton$React.forwardRef");
$RefreshReg$(_c4, "SelectScrollUpButton");
$RefreshReg$(_c5, "SelectScrollDownButton$React.forwardRef");
$RefreshReg$(_c6, "SelectScrollDownButton");
$RefreshReg$(_c7, "SelectContent$React.forwardRef");
$RefreshReg$(_c8, "SelectContent");
$RefreshReg$(_c9, "SelectLabel$React.forwardRef");
$RefreshReg$(_c0, "SelectLabel");
$RefreshReg$(_c1, "SelectItem$React.forwardRef");
$RefreshReg$(_c10, "SelectItem");
$RefreshReg$(_c11, "SelectSeparator$React.forwardRef");
$RefreshReg$(_c12, "SelectSeparator");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/select.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNO0FBdkJOLFlBQVlBLFdBQVc7QUFDdkIsWUFBWUMscUJBQXFCO0FBQ2pDLFNBQVNDLE9BQU9DLGFBQWFDLGlCQUFpQjtBQUM5QyxTQUFTQyxVQUFVO0FBRW5CLE1BQU1DLFNBQVNMLGdCQUFnQk07QUFDL0IsTUFBTUMsY0FBY1AsZ0JBQWdCUTtBQUNwQyxNQUFNQyxjQUFjVCxnQkFBZ0JVO0FBRXBDLE1BQU1DLGdCQUFnQlosTUFBTWE7QUFBQUEsRUFHM0JDLEtBQUNBLENBQUMsRUFBRUMsV0FBV0MsVUFBVSxHQUFHQyxNQUFNLEdBQUdDLFFBQ3BDO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdiO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBVTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJRTtBQUFBQSxNQUVIRDtBQUFBQTtBQUFBQSxRQUNELHVCQUFDLGdCQUFnQixNQUFoQixFQUFxQixTQUFPLE1BQzNCLGlDQUFDLGVBQVksV0FBVSx3Q0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRCxLQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBO0FBQUEsSUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZQTtBQUNEO0FBQUVHLE1BakJHUDtBQWtCTkEsY0FBY1EsY0FBY25CLGdCQUFnQm9CLFFBQVFEO0FBRXBELE1BQU1FLHVCQUF1QnRCLE1BQU1hO0FBQUFBLEVBR2xDVSxNQUFDQSxDQUFDLEVBQUVSLFdBQVcsR0FBR0UsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUMsZ0JBQWdCO0FBQUEsSUFBaEI7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXYjtBQUFBQSxRQUNUO0FBQUEsUUFDQVU7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUU7QUFBQUEsTUFFSixpQ0FBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBO0FBQUEsSUFSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0E7QUFDRDtBQUFFTyxNQWRHRjtBQWVOQSxxQkFBcUJGLGNBQWNuQixnQkFBZ0J3QixlQUFlTDtBQUVsRSxNQUFNTSx5QkFBeUIxQixNQUFNYTtBQUFBQSxFQUdwQ2MsTUFBQ0EsQ0FBQyxFQUFFWixXQUFXLEdBQUdFLE1BQU0sR0FBR0MsUUFDMUI7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV2I7QUFBQUEsUUFDVDtBQUFBLFFBQ0FVO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlFO0FBQUFBLE1BRUosaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQTtBQUFBLElBUmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBO0FBQ0Q7QUFBRVcsTUFkR0Y7QUFlTkEsdUJBQXVCTixjQUNyQm5CLGdCQUFnQjRCLGlCQUFpQlQ7QUFFbkMsTUFBTVUsZ0JBQWdCOUIsTUFBTWE7QUFBQUEsRUFHM0JrQixNQUFDQSxDQUFDLEVBQUVoQixXQUFXQyxVQUFVZ0IsV0FBVyxVQUFVLEdBQUdmLE1BQU0sR0FBR0MsUUFDekQsdUJBQUMsZ0JBQWdCLFFBQWhCLEVBQ0M7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV2I7QUFBQUEsUUFDVDtBQUFBLFFBQ0EyQixhQUFhLFlBQ1g7QUFBQSxRQUNGakI7QUFBQUEsTUFDRjtBQUFBLE1BQ0E7QUFBQSxNQUNBLEdBQUlFO0FBQUFBLE1BRUo7QUFBQSwrQkFBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFDckI7QUFBQSxVQUFDLGdCQUFnQjtBQUFBLFVBQWhCO0FBQUEsWUFDQyxXQUFXWjtBQUFBQSxjQUNUO0FBQUEsY0FDQTJCLGFBQWEsWUFDWDtBQUFBLFlBQ0o7QUFBQSxZQUVDaEI7QUFBQUE7QUFBQUEsVUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFFBQ0EsdUJBQUMsNEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBO0FBQUE7QUFBQSxJQXJCekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFDRDtBQUFFaUIsTUE3QkdIO0FBOEJOQSxjQUFjVixjQUFjbkIsZ0JBQWdCaUMsUUFBUWQ7QUFFcEQsTUFBTWUsY0FBY25DLE1BQU1hO0FBQUFBLEVBR3pCdUIsTUFBQ0EsQ0FBQyxFQUFFckIsV0FBVyxHQUFHRSxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdiLEdBQUcsbUdBQW1HVSxTQUFTO0FBQUEsTUFDMUgsR0FBSUU7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUVvQixNQVRHRjtBQVVOQSxZQUFZZixjQUFjbkIsZ0JBQWdCcUMsTUFBTWxCO0FBRWhELE1BQU1tQixhQUFhdkMsTUFBTWE7QUFBQUEsRUFHeEIyQixNQUFDQSxDQUFDLEVBQUV6QixXQUFXQyxVQUFVLEdBQUdDLE1BQU0sR0FBR0MsUUFDcEM7QUFBQSxJQUFDLGdCQUFnQjtBQUFBLElBQWhCO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBV2I7QUFBQUEsUUFDVDtBQUFBLFFBQ0FVO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlFO0FBQUFBLE1BRUo7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZ0VBQ2QsaUNBQUMsZ0JBQWdCLGVBQWhCLEVBQ0MsaUNBQUMsU0FBTSxXQUFVLGdDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsZ0JBQWdCLFVBQWhCLEVBQTBCRCxZQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUE7QUFBQTtBQUFBLElBZHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWVBO0FBQ0Q7QUFBRXlCLE9BcEJHRjtBQXFCTkEsV0FBV25CLGNBQWNuQixnQkFBZ0J5QyxLQUFLdEI7QUFFOUMsTUFBTXVCLGtCQUFrQjNDLE1BQU1hO0FBQUFBLEVBRzdCK0IsT0FBQ0EsQ0FBQyxFQUFFN0IsV0FBVyxHQUFHRSxNQUFNLEdBQUdDLFFBQzFCO0FBQUEsSUFBQyxnQkFBZ0I7QUFBQSxJQUFoQjtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdiLEdBQUcsZ0RBQWdEVSxTQUFTO0FBQUEsTUFDdkUsR0FBSUU7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUU0QixPQVRHRjtBQVVOQSxnQkFBZ0J2QixjQUFjbkIsZ0JBQWdCNkMsVUFBVTFCO0FBRXhEO0FBQUEsRUFDRWQ7QUFBQUEsRUFDQUU7QUFBQUEsRUFDQUU7QUFBQUEsRUFDQUU7QUFBQUEsRUFDQWtCO0FBQUFBLEVBQ0FLO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FJO0FBQUFBLEVBQ0FyQjtBQUFBQSxFQUNBSTtBQUFBQTtBQUNBLElBQUFaLElBQUFLLEtBQUFJLEtBQUFDLEtBQUFHLEtBQUFDLEtBQUFHLEtBQUFFLEtBQUFHLEtBQUFDLEtBQUFHLEtBQUFDLE1BQUFHLE1BQUFDO0FBQUEsYUFBQS9CLElBQUE7QUFBQSxhQUFBSyxLQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFHLE1BQUE7QUFBQSxhQUFBQyxNQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTZWxlY3RQcmltaXRpdmUiLCJDaGVjayIsIkNoZXZyb25Eb3duIiwiQ2hldnJvblVwIiwiY24iLCJTZWxlY3QiLCJSb290IiwiU2VsZWN0R3JvdXAiLCJHcm91cCIsIlNlbGVjdFZhbHVlIiwiVmFsdWUiLCJTZWxlY3RUcmlnZ2VyIiwiZm9yd2FyZFJlZiIsIl9jIiwiY2xhc3NOYW1lIiwiY2hpbGRyZW4iLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiVHJpZ2dlciIsIlNlbGVjdFNjcm9sbFVwQnV0dG9uIiwiX2MzIiwiX2M0IiwiU2Nyb2xsVXBCdXR0b24iLCJTZWxlY3RTY3JvbGxEb3duQnV0dG9uIiwiX2M1IiwiX2M2IiwiU2Nyb2xsRG93bkJ1dHRvbiIsIlNlbGVjdENvbnRlbnQiLCJfYzciLCJwb3NpdGlvbiIsIl9jOCIsIkNvbnRlbnQiLCJTZWxlY3RMYWJlbCIsIl9jOSIsIl9jMCIsIkxhYmVsIiwiU2VsZWN0SXRlbSIsIl9jMSIsIl9jMTAiLCJJdGVtIiwiU2VsZWN0U2VwYXJhdG9yIiwiX2MxMSIsIl9jMTIiLCJTZXBhcmF0b3IiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic2VsZWN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCAqIGFzIFNlbGVjdFByaW1pdGl2ZSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXNlbGVjdFwiO1xuaW1wb3J0IHsgQ2hlY2ssIENoZXZyb25Eb3duLCBDaGV2cm9uVXAgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCIuLi8uLi9saWIvdXRpbHNcIjtcblxuY29uc3QgU2VsZWN0ID0gU2VsZWN0UHJpbWl0aXZlLlJvb3Q7XG5jb25zdCBTZWxlY3RHcm91cCA9IFNlbGVjdFByaW1pdGl2ZS5Hcm91cDtcbmNvbnN0IFNlbGVjdFZhbHVlID0gU2VsZWN0UHJpbWl0aXZlLlZhbHVlO1xuXG5jb25zdCBTZWxlY3RUcmlnZ2VyID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuQ29tcG9uZW50UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuVHJpZ2dlcj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlRyaWdnZXI+XG4+KCh7IGNsYXNzTmFtZSwgY2hpbGRyZW4sIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlRyaWdnZXJcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJmbGV4IGgtOSB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtMyBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyByaW5nLW9mZnNldC13aGl0ZSBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLWJyYW5kLTUwMCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnJpbmctb2Zmc2V0LWdyYXktOTUwIGRhcms6cGxhY2Vob2xkZXI6dGV4dC1ncmF5LTUwMCBbJj5zcGFuXTpsaW5lLWNsYW1wLTFcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICA+XG4gICAge2NoaWxkcmVufVxuICAgIDxTZWxlY3RQcmltaXRpdmUuSWNvbiBhc0NoaWxkPlxuICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cImgtNCB3LTQgb3BhY2l0eS01MCBtbC0xLjUgc2hyaW5rLTBcIiAvPlxuICAgIDwvU2VsZWN0UHJpbWl0aXZlLkljb24+XG4gIDwvU2VsZWN0UHJpbWl0aXZlLlRyaWdnZXI+XG4pKTtcblNlbGVjdFRyaWdnZXIuZGlzcGxheU5hbWUgPSBTZWxlY3RQcmltaXRpdmUuVHJpZ2dlci5kaXNwbGF5TmFtZTtcblxuY29uc3QgU2VsZWN0U2Nyb2xsVXBCdXR0b24gPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5Db21wb25lbnRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNjcm9sbFVwQnV0dG9uPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbFVwQnV0dG9uXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiZmxleCBjdXJzb3ItZGVmYXVsdCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMVwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gID5cbiAgICA8Q2hldnJvblVwIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICA8L1NlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEJ1dHRvbj5cbikpO1xuU2VsZWN0U2Nyb2xsVXBCdXR0b24uZGlzcGxheU5hbWUgPSBTZWxlY3RQcmltaXRpdmUuU2Nyb2xsVXBCdXR0b24uZGlzcGxheU5hbWU7XG5cbmNvbnN0IFNlbGVjdFNjcm9sbERvd25CdXR0b24gPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5Db21wb25lbnRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxEb3duQnV0dG9uPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBTZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkJ1dHRvbj5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxEb3duQnV0dG9uXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiZmxleCBjdXJzb3ItZGVmYXVsdCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMVwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gID5cbiAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gIDwvU2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25CdXR0b24+XG4pKTtcblNlbGVjdFNjcm9sbERvd25CdXR0b24uZGlzcGxheU5hbWUgPVxuICBTZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkJ1dHRvbi5kaXNwbGF5TmFtZTtcblxuY29uc3QgU2VsZWN0Q29udGVudCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkNvbXBvbmVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkNvbnRlbnQ+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5Db250ZW50PlxuPigoeyBjbGFzc05hbWUsIGNoaWxkcmVuLCBwb3NpdGlvbiA9IFwicG9wcGVyXCIsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLlBvcnRhbD5cbiAgICA8U2VsZWN0UHJpbWl0aXZlLkNvbnRlbnRcbiAgICAgIHJlZj17cmVmfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyZWxhdGl2ZSB6LVs5OTk5OTldIG1heC1oLTk2IG1pbi13LVs4cmVtXSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLWxnIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktMjAwIGRhdGEtW3N0YXRlPW9wZW5dOmFuaW1hdGUtaW4gZGF0YS1bc3RhdGU9Y2xvc2VkXTphbmltYXRlLW91dCBkYXRhLVtzdGF0ZT1jbG9zZWRdOmZhZGUtb3V0LTAgZGF0YS1bc3RhdGU9b3Blbl06ZmFkZS1pbi0wIGRhdGEtW3N0YXRlPWNsb3NlZF06em9vbS1vdXQtOTUgZGF0YS1bc3RhdGU9b3Blbl06em9vbS1pbi05NSBkYXRhLVtzaWRlPWJvdHRvbV06c2xpZGUtaW4tZnJvbS10b3AtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMlwiLFxuICAgICAgICBwb3NpdGlvbiA9PT0gXCJwb3BwZXJcIiAmJlxuICAgICAgICAgIFwiZGF0YS1bc2lkZT1ib3R0b21dOnRyYW5zbGF0ZS15LTEgZGF0YS1bc2lkZT1sZWZ0XTotdHJhbnNsYXRlLXgtMSBkYXRhLVtzaWRlPXJpZ2h0XTp0cmFuc2xhdGUteC0xIGRhdGEtW3NpZGU9dG9wXTotdHJhbnNsYXRlLXktMVwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICBwb3NpdGlvbj17cG9zaXRpb259XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPFNlbGVjdFNjcm9sbFVwQnV0dG9uIC8+XG4gICAgICA8U2VsZWN0UHJpbWl0aXZlLlZpZXdwb3J0XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJwLTEuNVwiLFxuICAgICAgICAgIHBvc2l0aW9uID09PSBcInBvcHBlclwiICYmXG4gICAgICAgICAgICBcImgtW3ZhcigtLXJhZGl4LXNlbGVjdC10cmlnZ2VyLWhlaWdodCldIHctZnVsbCBtaW4tdy1bdmFyKC0tcmFkaXgtc2VsZWN0LXRyaWdnZXItd2lkdGgpXVwiXG4gICAgICAgICl9XG4gICAgICA+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvU2VsZWN0UHJpbWl0aXZlLlZpZXdwb3J0PlxuICAgICAgPFNlbGVjdFNjcm9sbERvd25CdXR0b24gLz5cbiAgICA8L1NlbGVjdFByaW1pdGl2ZS5Db250ZW50PlxuICA8L1NlbGVjdFByaW1pdGl2ZS5Qb3J0YWw+XG4pKTtcblNlbGVjdENvbnRlbnQuZGlzcGxheU5hbWUgPSBTZWxlY3RQcmltaXRpdmUuQ29udGVudC5kaXNwbGF5TmFtZTtcblxuY29uc3QgU2VsZWN0TGFiZWwgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5Db21wb25lbnRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5MYWJlbD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkxhYmVsPlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U2VsZWN0UHJpbWl0aXZlLkxhYmVsXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcInB4LTIuNSBweS0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZGFyazp0ZXh0LWdyYXktNTAwXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSk7XG5TZWxlY3RMYWJlbC5kaXNwbGF5TmFtZSA9IFNlbGVjdFByaW1pdGl2ZS5MYWJlbC5kaXNwbGF5TmFtZTtcblxuY29uc3QgU2VsZWN0SXRlbSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkNvbXBvbmVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLkl0ZW0+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5JdGVtPlxuPigoeyBjbGFzc05hbWUsIGNoaWxkcmVuLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPFNlbGVjdFByaW1pdGl2ZS5JdGVtXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwicmVsYXRpdmUgZmxleCB3LWZ1bGwgY3Vyc29yLXBvaW50ZXIgc2VsZWN0LW5vbmUgaXRlbXMtY2VudGVyIHJvdW5kZWQtbGcgcHktMS41IHBsLTggcHItMi41IHRleHQteHMgZm9udC1tZWRpdW0gb3V0bGluZS1ub25lIGZvY3VzOmJnLWdyYXktMTAwIGRhcms6Zm9jdXM6YmctZ3JheS04MDAgZm9jdXM6dGV4dC1ncmF5LTkwMCBkYXJrOmZvY3VzOnRleHQtd2hpdGUgZGF0YS1bZGlzYWJsZWRdOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1bZGlzYWJsZWRdOm9wYWNpdHktNTAgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgIGNsYXNzTmFtZVxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICA+XG4gICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0yIGZsZXggaC0zLjUgdy0zLjUgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICA8U2VsZWN0UHJpbWl0aXZlLkl0ZW1JbmRpY2F0b3I+XG4gICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWJyYW5kLTUwMFwiIC8+XG4gICAgICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtSW5kaWNhdG9yPlxuICAgIDwvc3Bhbj5cblxuICAgIDxTZWxlY3RQcmltaXRpdmUuSXRlbVRleHQ+e2NoaWxkcmVufTwvU2VsZWN0UHJpbWl0aXZlLkl0ZW1UZXh0PlxuICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtPlxuKSk7XG5TZWxlY3RJdGVtLmRpc3BsYXlOYW1lID0gU2VsZWN0UHJpbWl0aXZlLkl0ZW0uZGlzcGxheU5hbWU7XG5cbmNvbnN0IFNlbGVjdFNlcGFyYXRvciA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkNvbXBvbmVudFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNlcGFyYXRvcj4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNlcGFyYXRvcj5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPFNlbGVjdFByaW1pdGl2ZS5TZXBhcmF0b3JcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwiLW14LTEgbXktMSBoLXB4IGJnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDBcIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKTtcblNlbGVjdFNlcGFyYXRvci5kaXNwbGF5TmFtZSA9IFNlbGVjdFByaW1pdGl2ZS5TZXBhcmF0b3IuZGlzcGxheU5hbWU7XG5cbmV4cG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0R3JvdXAsXG4gIFNlbGVjdFZhbHVlLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RMYWJlbCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0U2VwYXJhdG9yLFxuICBTZWxlY3RTY3JvbGxVcEJ1dHRvbixcbiAgU2VsZWN0U2Nyb2xsRG93bkJ1dHRvbixcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvc2VsZWN0LnRzeCJ9