import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SessionsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { Badge } from "/src/components/ui/badge.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Search, X, Calendar, Lock, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const SessionsView = ({
  sessions = [],
  panchayats = [],
  volunteers = [],
  onNavigate,
  onAddSession,
  onUpdateSession,
  onDeleteSession,
  onRequestDateChange,
  canManageSchedule = false,
  userRole = "Super Admin"
}) => {
  _s();
  const isClusterAdmin = userRole === "Cluster Admin";
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPanchayat, setSelectedPanchayat] = useState("all");
  const [selectedVillage, setSelectedVillage] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedModule, setSelectedModule] = useState("all");
  const [selectedVolunteer, setSelectedVolunteer] = useState("all");
  const [filterDate, setFilterDate] = useState("");
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [activeSessionDetail, setActiveSessionDetail] = useState(null);
  const [sessionToDelete, setSessionToDelete] = useState(null);
  const [dateChangeSession, setDateChangeSession] = useState(null);
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [dateChangeNewDate, setDateChangeNewDate] = useState("");
  const [dateDrafts, setDateDrafts] = useState({});
  useEffect(() => {
    setDateDrafts((current) => {
      const next = { ...current };
      sessions.forEach((session) => {
        if (!(session.id in next)) next[session.id] = session.date || "";
      });
      return next;
    });
  }, [sessions]);
  const [formData, setFormData] = useState({
    id: "",
    code: "",
    name: "",
    moduleId: "M-103",
    module: "Spoken English",
    day: "Saturday",
    date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    time: "10:00 AM",
    endTime: "11:30 AM",
    panchayatId: panchayats[0]?.id || "vedakkattamaduvu",
    panchayatName: panchayats[0]?.name || "Vedakkattamaduvu",
    villageName: panchayats[0]?.villages[0]?.name || "Ammapettai",
    volunteerId: volunteers[0]?.id || "vol-1",
    volunteerName: volunteers[0]?.name || "Bala",
    sessionType: "Academic",
    description: "",
    status: "Scheduled"
  });
  const [formErrors, setFormErrors] = useState({});
  const currentFilterVillages = useMemo(() => {
    if (selectedPanchayat === "all") {
      const allVillages = [];
      panchayats.forEach((p) => {
        p.villages?.forEach((v) => {
          if (!allVillages.some((existing) => existing.name === v.name)) {
            allVillages.push({ id: v.id, name: v.name });
          }
        });
      });
      return allVillages;
    }
    const found = panchayats.find((p) => p.id === selectedPanchayat);
    return found?.villages || [];
  }, [selectedPanchayat, panchayats]);
  const modalVillages = useMemo(() => {
    const found = panchayats.find((p) => p.id === formData.panchayatId);
    return found?.villages || [];
  }, [formData.panchayatId, panchayats]);
  const getSessionTitle = (s) => {
    if (!s) return "Untitled Session";
    return s.name || s.title || s.code || "Untitled Session";
  };
  const getSessionModule = (s) => {
    if (!s) return "General";
    return s.module || s.moduleId || "General Module";
  };
  const getSessionVolunteer = (s) => {
    if (!s || !s.volunteerName || s.volunteerName === "Unassigned") return "Unassigned";
    return s.volunteerName;
  };
  const filteredSessions = useMemo(
    () => {
      return sessions.filter((s) => {
        const title = getSessionTitle(s).toLowerCase();
        const mod = getSessionModule(s).toLowerCase();
        const vill = (s.villageName || "").toLowerCase();
        const vol = (s.volunteerName || "").toLowerCase();
        const pan = (s.panchayatName || "").toLowerCase();
        const search = searchTerm.toLowerCase().trim();
        const matchSearch = !search || title.includes(search) || mod.includes(search) || vill.includes(search) || vol.includes(search) || pan.includes(search) || (s.code || "").toLowerCase().includes(search);
        const matchPanchayat = selectedPanchayat === "all" || s.panchayatId === selectedPanchayat;
        const matchVillage = selectedVillage === "all" || (s.villageName || "").toLowerCase() === selectedVillage.toLowerCase();
        const matchStatus = selectedStatus === "all" || s.status.toLowerCase() === selectedStatus.toLowerCase() || selectedStatus === "Needs Attention" && (s.status === "Needs Attention" || s.status === "Action Req.");
        const matchModule = selectedModule === "all" || mod.includes(selectedModule.toLowerCase()) || s.moduleId === selectedModule;
        const matchVolunteer = selectedVolunteer === "all" || s.volunteerId === selectedVolunteer || (s.volunteerName || "").toLowerCase() === selectedVolunteer.toLowerCase();
        const matchDate = !filterDate || s.date === filterDate;
        return matchSearch && matchPanchayat && matchVillage && matchStatus && matchModule && matchVolunteer && matchDate;
      });
    },
    [
      sessions,
      searchTerm,
      selectedPanchayat,
      selectedVillage,
      selectedStatus,
      selectedModule,
      selectedVolunteer,
      filterDate
    ]
  );
  const upcomingCount = sessions.filter(
    (s) => s.status === "Scheduled" || s.status === "In Progress"
  ).length;
  const scheduledCount = sessions.filter((s) => s.status === "Scheduled").length;
  const completedCount = sessions.filter((s) => s.status === "Completed").length;
  const needsAttentionCount = sessions.filter(
    (s) => s.status === "Needs Attention" || s.status === "Action Req." || s.volunteerName === "Unassigned"
  ).length;
  const nextSession = useMemo(() => {
    const scheduled = sessions.filter((s) => s.status === "Scheduled");
    if (scheduled.length > 0) return scheduled[0];
    return sessions[0] || null;
  }, [sessions]);
  const handleClearFilters = () => {
    setSearchTerm("");
    setSelectedPanchayat("all");
    setSelectedVillage("all");
    setSelectedStatus("all");
    setSelectedModule("all");
    setSelectedVolunteer("all");
    setFilterDate("");
  };
  const handleOpenNewModal = () => {
    setIsEditMode(false);
    setFormErrors({});
    const defaultP = panchayats[0];
    setFormData({
      id: "",
      code: `M-${Math.floor(100 + Math.random() * 900)}`,
      name: "",
      moduleId: "M-103",
      module: "Spoken English",
      day: "Saturday",
      date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      time: "10:00 AM",
      endTime: "11:30 AM",
      panchayatId: defaultP?.id || "vedakkattamaduvu",
      panchayatName: defaultP?.name || "Vedakkattamaduvu",
      villageName: defaultP?.villages[0]?.name || "Ammapettai",
      volunteerId: volunteers[0]?.id || "vol-1",
      volunteerName: volunteers[0]?.name || "Bala",
      sessionType: "Academic",
      description: "",
      status: "Scheduled"
    });
    setIsNewModalOpen(true);
  };
  const handleOpenEditModal = (session) => {
    setIsEditMode(true);
    setFormErrors({});
    setFormData({
      id: session.id,
      code: session.code || `M-103`,
      name: session.name || session.title || "",
      moduleId: session.moduleId || "M-103",
      module: session.module || "Spoken English",
      day: session.day || "Saturday",
      date: session.date || "",
      time: session.time || "10:00 AM",
      endTime: session.endTime || "11:30 AM",
      panchayatId: session.panchayatId || panchayats[0]?.id || "",
      panchayatName: session.panchayatName || panchayats[0]?.name || "",
      villageName: session.villageName || "",
      volunteerId: session.volunteerId || "",
      volunteerName: session.volunteerName || "Unassigned",
      sessionType: session.sessionType || "Academic",
      description: session.description || "",
      status: session.status || "Scheduled"
    });
    setIsNewModalOpen(true);
  };
  const handlePanchayatSelectChange = (pId) => {
    const found = panchayats.find((p) => p.id === pId);
    if (found) {
      setFormData((prev) => ({
        ...prev,
        panchayatId: found.id,
        panchayatName: found.name,
        villageName: found.villages[0]?.name || "Main Center"
      }));
    }
  };
  const handleVolunteerSelectChange = (vId) => {
    if (vId === "unassigned") {
      setFormData((prev) => ({
        ...prev,
        volunteerId: "",
        volunteerName: "Unassigned"
      }));
      return;
    }
    const found = volunteers.find((v) => v.id === vId);
    if (found) {
      setFormData((prev) => ({
        ...prev,
        volunteerId: found.id,
        volunteerName: found.name
      }));
    }
  };
  const handleFormSubmit = (asDraft = false) => {
    const errors = {};
    if (!formData.name.trim()) {
      errors.name = "Session topic is required.";
    }
    if (!formData.villageName.trim()) {
      errors.villageName = "Please select a village.";
    }
    if (!formData.volunteerName.trim() || formData.volunteerName === "Unassigned") {
      if (!asDraft) {
        errors.volunteer = "Please select a volunteer.";
      }
    }
    if (!formData.date.trim()) {
      errors.date = "Please select a valid date.";
    }
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    const finalStatus = asDraft ? "Draft" : formData.status || "Scheduled";
    if (isEditMode && formData.id) {
      onUpdateSession(formData.id, {
        name: formData.name.trim(),
        title: formData.name.trim(),
        code: formData.code,
        moduleId: formData.moduleId,
        module: formData.module,
        day: formData.day,
        date: formData.date,
        time: formData.time,
        endTime: formData.endTime,
        panchayatId: formData.panchayatId,
        panchayatName: formData.panchayatName,
        villageName: formData.villageName,
        volunteerId: formData.volunteerId,
        volunteerName: formData.volunteerName,
        sessionType: formData.sessionType,
        description: formData.description,
        status: finalStatus
      });
      if (activeSessionDetail?.id === formData.id) {
        setActiveSessionDetail((prev) => prev ? { ...prev, ...formData, status: finalStatus } : null);
      }
    } else {
      const newSession = {
        code: formData.code || `M-${Math.floor(100 + Math.random() * 900)}`,
        name: formData.name.trim(),
        title: formData.name.trim(),
        moduleId: formData.moduleId,
        module: formData.module,
        day: formData.day,
        date: formData.date,
        time: formData.time,
        endTime: formData.endTime,
        panchayatId: formData.panchayatId,
        panchayatName: formData.panchayatName,
        villageName: formData.villageName,
        volunteerId: formData.volunteerId,
        volunteerName: formData.volunteerName,
        sessionType: formData.sessionType,
        description: formData.description || "Weekly student holistic development learning session.",
        status: finalStatus,
        spoc: formData.volunteerName,
        financer: "Cluster Fund"
      };
      onAddSession(newSession);
    }
    setIsNewModalOpen(false);
  };
  const handleExportCSV = () => {
    if (filteredSessions.length === 0) {
      alert("No session data available to export.");
      return;
    }
    const headers = [
      "Session Code",
      "Topic",
      "Module",
      "Date",
      "Time",
      "Day",
      "Panchayat",
      "Village",
      "Assigned Volunteer",
      "Status",
      "Session Type"
    ];
    const rows = filteredSessions.map(
      (s) => [
        `"${s.code || ""}"`,
        `"${(s.name || s.title || "").replace(/"/g, '""')}"`,
        `"${(s.module || s.moduleId || "").replace(/"/g, '""')}"`,
        `"${s.date}"`,
        `"${s.time}"`,
        `"${s.day || ""}"`,
        `"${s.panchayatName}"`,
        `"${s.villageName}"`,
        `"${s.volunteerName}"`,
        `"${s.status}"`,
        `"${s.sessionType || "Academic"}"`
      ]
    );
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute(
      "download",
      `TQI_Sessions_Dharmapuri_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const renderStatusBadge = (status) => {
    switch (status) {
      case "Scheduled":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 443,
            columnNumber: 13
          }, this),
          "Scheduled"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 442,
          columnNumber: 11
        }, this);
      case "In Progress":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 450,
            columnNumber: 13
          }, this),
          "In Progress"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 449,
          columnNumber: 11
        }, this);
      case "Completed":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 457,
            columnNumber: 13
          }, this),
          "Completed"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 456,
          columnNumber: 11
        }, this);
      case "Needs Attention":
      case "Action Req.":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-rose-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 465,
            columnNumber: 13
          }, this),
          "Needs Attention"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 464,
          columnNumber: 11
        }, this);
      case "Cancelled":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-slate-400" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 472,
            columnNumber: 13
          }, this),
          "Cancelled"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 471,
          columnNumber: 11
        }, this);
      case "Draft":
      default:
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-slate-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 480,
            columnNumber: 13
          }, this),
          "Draft"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 479,
          columnNumber: 11
        }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Learning Sessions" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 493,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            filteredSessions.length,
            " Total"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 496,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 492,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Plan, coordinate, and track village learning modules and attendance across clusters." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 500,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 491,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleExportCSV,
            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Export CSV" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 511,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 506,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleOpenNewModal,
            className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-3.5 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Add Session" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 518,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 513,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 505,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 490,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Upcoming" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 526,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: upcomingCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 527,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 525,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-brand-500", children: "Scheduled" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 530,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: scheduledCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 531,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 529,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-success-500", children: "Completed" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 534,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: completedCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 535,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 533,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-error-500", children: "Needs Attention" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 538,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: needsAttentionCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 539,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 537,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 524,
      columnNumber: 7
    }, this),
    nextSession && /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold uppercase tracking-wider text-brand-500 bg-brand-50 dark:bg-brand-500/10 px-2 py-0.5 rounded-lg", children: "Next Session" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 549,
            columnNumber: 17
          }, this),
          renderStatusBadge(nextSession.status)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 548,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: [
          getSessionTitle(nextSession),
          nextSession.code && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-mono text-xs font-normal text-gray-400", children: [
            "(",
            nextSession.code,
            ")"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 557,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 554,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500 dark:text-gray-400 font-medium", children: [
          /* @__PURE__ */ jsxDEV("span", { children: [
            nextSession.date,
            " · ",
            nextSession.time
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 563,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Panchayat: ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-800 dark:text-gray-200", children: nextSession.panchayatName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 564,
              columnNumber: 34
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 564,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Village: ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-800 dark:text-gray-200", children: nextSession.villageName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 565,
              columnNumber: 32
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 565,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Volunteer: ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-brand-500", children: getSessionVolunteer(nextSession) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 566,
              columnNumber: 34
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 566,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 562,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 547,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 shrink-0", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setActiveSessionDetail(nextSession),
            className: "rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 571,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("lesson-plan", nextSession.lessonPlanId || nextSession.id),
            className: "rounded-xl border border-brand-200 bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-600 hover:bg-brand-100 dark:border-brand-900/40 dark:bg-brand-500/10 dark:text-brand-400 transition",
            children: "Lesson Plan"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 578,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("attendance", nextSession.id),
            className: "rounded-xl bg-brand-500 px-3 py-1.5 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: "Attendance"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 585,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 570,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 546,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 545,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 602,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: searchTerm,
              onChange: (e) => setSearchTerm(e.target.value),
              placeholder: "Search session, module, village or volunteer...",
              className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-8 py-2 text-xs text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 603,
              columnNumber: 13
            },
            this
          ),
          searchTerm && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setSearchTerm(""),
              className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",
              children: /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 616,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 611,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 601,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedPanchayat || "all",
            onValueChange: (val) => {
              setSelectedPanchayat(val);
              setSelectedVillage("all");
            },
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Panchayats" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 631,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 630,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Panchayats" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 634,
                  columnNumber: 17
                }, this),
                panchayats.map(
                  (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 636,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 633,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 623,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 622,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedVillage || "all",
            onValueChange: (val) => setSelectedVillage(val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Villages" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 651,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 650,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Villages" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 654,
                  columnNumber: 17
                }, this),
                currentFilterVillages.map(
                  (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 656,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 653,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 646,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 645,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedStatus || "all",
              onValueChange: (val) => setSelectedStatus(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Statuses" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 672,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 671,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Statuses" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 675,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Scheduled", children: "Scheduled" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 676,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "In Progress", children: "In Progress" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 677,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Completed", children: "Completed" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 678,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Needs Attention", children: "Needs Attention" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 679,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Draft", children: "Draft" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 680,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Cancelled", children: "Cancelled" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 681,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 674,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 667,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 666,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowMoreFilters(!showMoreFilters),
              className: `rounded-xl border px-3 py-2 text-xs font-semibold transition shadow-theme-xs flex items-center gap-1 shrink-0 ${showMoreFilters || selectedModule !== "all" || selectedVolunteer !== "all" || filterDate ? "border-brand-500 bg-brand-50 text-brand-600 dark:bg-brand-500/10 dark:text-brand-400" : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[15px]", children: "tune" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 695,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Filter" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 696,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 686,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 665,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 599,
        columnNumber: 9
      }, this),
      showMoreFilters && /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 dark:border-gray-800 grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1", children: "Module" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 705,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedModule,
              onValueChange: (val) => setSelectedModule(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Modules" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 713,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 712,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Modules" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 716,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Spoken English", children: "Spoken English" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 717,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Basic Math", children: "Basic Math" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 718,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Life Skills", children: "Life Skills" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 719,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Digital Literacy", children: "Digital Literacy" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 720,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Science", children: "Science" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 721,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Financial Literacy", children: "Financial Literacy" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 722,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 715,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 708,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 704,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1", children: "Volunteer" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 728,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedVolunteer,
              onValueChange: (val) => setSelectedVolunteer(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Volunteers" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 736,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 735,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Volunteers" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 739,
                    columnNumber: 19
                  }, this),
                  volunteers.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 741,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 738,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 731,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 727,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1", children: "Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 750,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: filterDate,
              onChange: (e) => setFilterDate(e.target.value),
              className: "w-full rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs text-gray-800 shadow-theme-xs focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 753,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 749,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-end pt-5", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleClearFilters,
            className: "rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-xs font-semibold text-gray-600 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: "Clear Filters"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 762,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 761,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 703,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 598,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-white/[0.02] dark:text-gray-400", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Date & Time" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 780,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Session Topic & Module" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 781,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Panchayat & Village" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 782,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Volunteer" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 783,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 784,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5 text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 785,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 779,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 778,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-100 dark:divide-gray-800 text-xs", children: filteredSessions.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 6, className: "py-12 text-center text-gray-400", children: "No sessions match your filter criteria." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 791,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 790,
        columnNumber: 15
      }, this) : filteredSessions.map(
        (session) => /* @__PURE__ */ jsxDEV(
          "tr",
          {
            className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors group",
            children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 whitespace-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-gray-900 dark:text-white", children: session.date }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 803,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-400 mt-0.5", children: session.time }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 804,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 802,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-gray-900 dark:text-white group-hover:text-brand-500 transition-colors", children: getSessionTitle(session) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 811,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-400 mt-0.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-gray-500 dark:text-gray-300", children: session.code || session.moduleId || "M-103" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 815,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    " · ",
                    getSessionModule(session)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 818,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 814,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 810,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-gray-800 dark:text-gray-200", children: session.panchayatName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 824,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-400", children: session.villageName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 825,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 823,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: session.volunteerName && session.volunteerName !== "Unassigned" ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 rounded-full bg-brand-50 text-brand-500 text-[10px] font-bold flex items-center justify-center dark:bg-brand-500/10 dark:text-brand-400", children: session.volunteerName.charAt(0) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 832,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-900 dark:text-white", children: session.volunteerName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 835,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 831,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: "Unassigned" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 838,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 829,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(
                Badge,
                {
                  color: session.status === "Completed" ? "success" : session.status === "In Progress" ? "warning" : session.status === "Needs Attention" ? "error" : "primary",
                  size: "sm",
                  children: session.status
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 846,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 845,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-right whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-end gap-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setActiveSessionDetail(session),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "View Session",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "visibility" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 871,
                      columnNumber: 27
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 865,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => onNavigate("lesson-plan", session.lessonPlanId || session.id),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "Lesson Plan",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "menu_book" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 879,
                      columnNumber: 27
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 873,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => onNavigate("attendance", session.id),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "Attendance",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "how_to_reg" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 887,
                      columnNumber: 27
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 881,
                    columnNumber: 25
                  },
                  this
                ),
                isClusterAdmin && onRequestDateChange && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      setDateChangeSession(session);
                      setDateChangeNewDate(session.date || "");
                      setDateChangeReason("");
                    },
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "Request Date Change",
                    children: /* @__PURE__ */ jsxDEV(Calendar, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 901,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 891,
                    columnNumber: 21
                  },
                  this
                ),
                ["Submitted", "Pending Review", "Approved", "Completed"].includes(session.status) ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    disabled: true,
                    className: "rounded-lg p-1.5 text-gray-300 dark:text-gray-600 cursor-not-allowed",
                    title: "Session submitted - editing disabled",
                    children: /* @__PURE__ */ jsxDEV(Lock, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 912,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 906,
                    columnNumber: 21
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleOpenEditModal(session),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "Edit",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 921,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 915,
                    columnNumber: 21
                  },
                  this
                ),
                onDeleteSession && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setSessionToDelete(session),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-error-50 hover:text-error-600 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition cursor-pointer",
                    title: "Delete",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 932,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 926,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 864,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 863,
                columnNumber: 21
              }, this)
            ]
          },
          session.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 797,
            columnNumber: 15
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 788,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 777,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 776,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 775,
      columnNumber: 7
    }, this),
    isNewModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-gray-900/70 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-2xl w-full max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50 rounded-t-xl", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-slate-900", children: isEditMode ? "Edit Session" : "Create New Session" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 952,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Fill in the details to schedule learning activity in your cluster." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 955,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 951,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsNewModalOpen(false),
            className: "text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-100 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 963,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 959,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 950,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 overflow-y-auto space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Session Topic ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 973,
                columnNumber: 35
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 972,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: formData.name,
                onChange: (e) => {
                  setFormData({ ...formData, name: e.target.value });
                  if (formErrors.name) setFormErrors({ ...formErrors, name: "" });
                },
                placeholder: "e.g. Spoken English — Module 3",
                className: `w-full px-3 py-2 border rounded-md text-xs focus:outline-none focus:border-[#0B3D91] ${formErrors.name ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 975,
                columnNumber: 19
              },
              this
            ),
            formErrors.name && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 988,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 971,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Curriculum Module" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 992,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.module,
                onValueChange: (mod) => {
                  let modId = "M-103";
                  if (mod === "Basic Math") modId = "M-301";
                  if (mod === "Life Skills") modId = "M-102";
                  if (mod === "Digital Literacy") modId = "D-004";
                  if (mod === "Science") modId = "S-201";
                  if (mod === "Financial Literacy") modId = "F-101";
                  setFormData({ ...formData, module: mod, moduleId: modId });
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Module" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1008,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1007,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Spoken English", children: "Spoken English (M-103)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1011,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Basic Math", children: "Basic Math (M-301)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1012,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Life Skills", children: "Life Skills (M-102)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1013,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Digital Literacy", children: "Digital Literacy (D-004)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1014,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Science", children: "Science (S-201)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1015,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Financial Literacy", children: "Financial Literacy (F-101)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1016,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1010,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 995,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 991,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 970,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Date ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1026,
                columnNumber: 26
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1025,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: formData.date,
                onChange: (e) => {
                  setFormData({ ...formData, date: e.target.value });
                  if (formErrors.date) setFormErrors({ ...formErrors, date: "" });
                },
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1028,
                columnNumber: 19
              },
              this
            ),
            formErrors.date && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.date }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1038,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1024,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Day of Week" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1043,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.day,
                onValueChange: (val) => setFormData({ ...formData, day: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Day" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1051,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1050,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Saturday", children: "Saturday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1054,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Sunday", children: "Sunday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1055,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Monday", children: "Monday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1056,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Tuesday", children: "Tuesday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1057,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Wednesday", children: "Wednesday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1058,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Thursday", children: "Thursday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1059,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Friday", children: "Friday" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1060,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1053,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1046,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1042,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Time Slot" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1066,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "e.g. 10:00 AM - 12:30 PM",
                value: formData.time,
                onChange: (e) => setFormData({ ...formData, time: e.target.value }),
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1069,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1065,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1023,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Panchayat Cluster Hub ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1083,
                columnNumber: 43
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1082,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.panchayatId,
                onValueChange: (val) => handlePanchayatSelectChange(val),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1090,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1089,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1094,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1092,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1085,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1081,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Village / Learning Center ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1104,
                columnNumber: 47
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1103,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.villageName,
                onValueChange: (val) => {
                  setFormData({ ...formData, villageName: val });
                  if (formErrors.villageName) setFormErrors({ ...formErrors, villageName: "" });
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: `w-full h-9 text-xs ${formErrors.villageName ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`, children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Village Center" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1116,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1113,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: modalVillages.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1120,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1118,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1106,
                columnNumber: 19
              },
              this
            ),
            formErrors.villageName && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.villageName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1127,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1102,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1080,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Assigned Volunteer ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1136,
                columnNumber: 40
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1135,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.volunteerId || (formData.volunteerName === "Unassigned" ? "unassigned" : ""),
                onValueChange: (val) => {
                  handleVolunteerSelectChange(val);
                  if (formErrors.volunteer) setFormErrors({ ...formErrors, volunteer: "" });
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: `w-full h-9 text-xs ${formErrors.volunteer ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`, children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Volunteer" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1148,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1145,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "unassigned", children: "-- Unassigned (Needs Attention) --" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1151,
                      columnNumber: 23
                    }, this),
                    volunteers.map(
                      (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.id, children: [
                        v.name,
                        " (",
                        v.department?.split(" ")[0] || "Mentor",
                        ")"
                      ] }, v.id, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                        lineNumber: 1153,
                        columnNumber: 21
                      }, this)
                    )
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1150,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1138,
                columnNumber: 19
              },
              this
            ),
            formErrors.volunteer && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.volunteer }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1160,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1134,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Session Type" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1165,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.sessionType,
                onValueChange: (val) => setFormData({
                  ...formData,
                  sessionType: val
                }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Session Type" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1178,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1177,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Academic", children: "Academic Core" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1181,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Life Skills", children: "Life Skills & Habits" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1182,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Assessment", children: "Assessment & Review" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1183,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Orientation", children: "Orientation & Games" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1184,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1180,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1168,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1164,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Initial Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1190,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.status,
                onValueChange: (val) => setFormData({ ...formData, status: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Status" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1200,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1199,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Scheduled", children: "Scheduled" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1203,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "In Progress", children: "In Progress" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1204,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Completed", children: "Completed" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1205,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Needs Attention", children: "Needs Attention" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1206,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Draft", children: "Draft" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                      lineNumber: 1207,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                    lineNumber: 1202,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1193,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1189,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1133,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Description / Lesson Objective Note" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1215,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 2,
              value: formData.description,
              onChange: (e) => setFormData({ ...formData, description: e.target.value }),
              placeholder: "Outline key learning goals, expected activity or required kit...",
              className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1218,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1214,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 968,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between rounded-b-xl", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setIsNewModalOpen(false),
            className: "px-3.5 py-1.5 border border-slate-300 text-slate-700 hover:bg-white text-xs font-semibold rounded-md transition-colors cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1230,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleFormSubmit(true),
              className: "px-3.5 py-1.5 border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer",
              children: "Save Draft"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1239,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleFormSubmit(false),
              className: "px-4 py-1.5 bg-[#0B3D91] hover:bg-[#082a66] text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: isEditMode ? "Update Session" : "Create Session"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1246,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1238,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1229,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 948,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 947,
      columnNumber: 7
    }, this),
    activeSessionDetail && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-gray-900/70 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-3xl w-full max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-slate-200 bg-slate-50/70 rounded-t-xl flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono font-bold bg-[#0B3D91]/10 text-[#0B3D91] px-2 py-0.5 rounded", children: activeSessionDetail.code || "M-103" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1267,
              columnNumber: 19
            }, this),
            renderStatusBadge(activeSessionDetail.status)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1266,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-slate-900", children: getSessionTitle(activeSessionDetail) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1272,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: [
            "Module: ",
            getSessionModule(activeSessionDetail),
            " • ",
            activeSessionDetail.sessionType || "Academic Session"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1275,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1265,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveSessionDetail(null),
            className: "text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-200 transition-colors",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1284,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1280,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1264,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto space-y-5 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-md p-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2", children: "Session Delivery Workflow" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1292,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[11px] font-medium text-slate-600 overflow-x-auto pb-1 gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 shrink-0 text-emerald-700 font-bold", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-emerald-600", children: "check_circle" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1297,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "1. Created" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1298,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1296,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-300", children: "→" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1300,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 shrink-0 text-emerald-700 font-bold", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-emerald-600", children: "check_circle" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1302,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "2. Scheduled" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1303,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1301,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-300", children: "→" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1305,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-1 shrink-0 ${activeSessionDetail.status === "Completed" || activeSessionDetail.status === "In Progress" ? "text-emerald-700 font-bold" : "text-slate-500"}`, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: activeSessionDetail.status === "Completed" ? "check_circle" : "pending" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1307,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "3. Conduct" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1310,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1306,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-300", children: "→" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1312,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-1 shrink-0 ${activeSessionDetail.status === "Completed" ? "text-emerald-700 font-bold" : "text-slate-500"}`, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: activeSessionDetail.status === "Completed" ? "check_circle" : "fact_check" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1314,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "4. Attendance" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1317,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1313,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-300", children: "→" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1319,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-1 shrink-0 ${activeSessionDetail.status === "Completed" ? "text-emerald-700 font-bold" : "text-slate-500"}`, children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: activeSessionDetail.status === "Completed" ? "check_circle" : "photo_camera" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1321,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "5. Completed" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1324,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1320,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1295,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1291,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white border border-slate-200 rounded-md p-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-400 block", children: "Schedule Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1332,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 text-xs mt-0.5 block", children: [
              activeSessionDetail.date,
              " (",
              activeSessionDetail.day || "Sat",
              ")"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1335,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1331,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-400 block", children: "Time Window" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1341,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 text-xs mt-0.5 block", children: [
              activeSessionDetail.time,
              " - ",
              activeSessionDetail.endTime || "11:30 AM"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1344,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1340,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-400 block", children: "Panchayat & Village" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1350,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 text-xs mt-0.5 block", children: activeSessionDetail.panchayatName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1353,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 text-[11px]", children: activeSessionDetail.villageName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1356,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1349,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-400 block", children: "Assigned Volunteer" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1362,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#0B3D91] text-xs mt-0.5 block", children: getSessionVolunteer(activeSessionDetail) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1365,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1361,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1330,
          columnNumber: 15
        }, this),
        activeSessionDetail.description && /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-md p-3.5 space-y-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-500 tracking-wider", children: "Session Description" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1374,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700 leading-relaxed", children: activeSessionDetail.description }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1377,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1373,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border border-slate-200 rounded-md p-3.5 bg-white space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-[#0B3D91]", children: "menu_book" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 1389,
                  columnNumber: 23
                }, this),
                "Lesson Plan"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1388,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded", children: "Linked" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1394,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1387,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-500", children: "Step-by-step 90-minute curriculum with worksheets and group drills." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1398,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveSessionDetail(null);
                  onNavigate("lesson-plan", activeSessionDetail.lessonPlanId || activeSessionDetail.id);
                },
                className: "w-full py-1.5 text-center text-xs font-semibold text-[#0B3D91] bg-blue-50 hover:bg-blue-100 rounded transition-colors cursor-pointer",
                children: "Open Lesson Plan >"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1401,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1386,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border border-slate-200 rounded-md p-3.5 bg-white space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-[#FF7A00]", children: "how_to_reg" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 1416,
                  columnNumber: 23
                }, this),
                "Attendance"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1415,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded", children: [
                activeSessionDetail.attendanceCount || 0,
                "/",
                activeSessionDetail.totalStudents || 25,
                " Students"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1421,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1414,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-500", children: "Mark student presence, task completion, and behavioral remarks." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1425,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveSessionDetail(null);
                  onNavigate("attendance", activeSessionDetail.id);
                },
                className: "w-full py-1.5 text-center text-xs font-semibold text-[#FF7A00] bg-orange-50 hover:bg-orange-100 rounded transition-colors cursor-pointer",
                children: "Mark Attendance >"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1428,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1413,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border border-slate-200 rounded-md p-3.5 bg-white space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-800 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-emerald-600", children: "photo_library" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                  lineNumber: 1443,
                  columnNumber: 23
                }, this),
                "Field Photos"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1442,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded", children: [
                activeSessionDetail.photos?.length || 1,
                " Media"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1448,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1441,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-500", children: "Activity documentation and classroom verification media." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1452,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setActiveSessionDetail(null);
                  onNavigate("session-photos", activeSessionDetail.id);
                },
                className: "w-full py-1.5 text-center text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded transition-colors cursor-pointer",
                children: "Upload / View Photos >"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
                lineNumber: 1455,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1440,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1384,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1289,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2 rounded-b-xl", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveSessionDetail(null),
            className: "px-4 py-1.5 border border-slate-300 text-slate-700 hover:bg-white text-xs font-semibold rounded-md transition-colors cursor-pointer",
            children: "Back to Sessions"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1470,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          activeSessionDetail.status !== "Completed" && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                onUpdateSession(activeSessionDetail.id, { status: "Completed" });
                setActiveSessionDetail((prev) => prev ? { ...prev, status: "Completed" } : null);
              },
              className: "px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: "Mark as Completed"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1479,
              columnNumber: 15
            },
            this
          ),
          activeSessionDetail.status !== "Completed" && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                const s = activeSessionDetail;
                setActiveSessionDetail(null);
                handleOpenEditModal(s);
              },
              className: "px-3.5 py-1.5 bg-[#0B3D91] hover:bg-[#082a66] text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: "Edit Session"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1491,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1477,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1469,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1262,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1261,
      columnNumber: 7
    }, this),
    sessionToDelete && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-gray-900/70 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-md w-full p-5 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[22px]", children: "delete_forever" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1513,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1512,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-900", children: "Delete Learning Session" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1516,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-600 mt-1", children: [
          'Are you sure you want to remove "',
          getSessionTitle(sessionToDelete),
          '" from the timetable? This action cannot be undone.'
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1517,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1515,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setSessionToDelete(null),
            className: "px-3.5 py-1.5 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-50",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1522,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              if (onDeleteSession) onDeleteSession(sessionToDelete.id);
              setSessionToDelete(null);
            },
            className: "px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-md shadow-xs",
            children: "Confirm Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1528,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1521,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1511,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1510,
      columnNumber: 7
    }, this),
    dateChangeSession && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-gray-900/70 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-md w-full p-5 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Calendar, { className: "h-5 w-5" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1547,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1546,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-900", children: "Request Date Change" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1550,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-600 mt-1", children: [
          'Submit a date change request for "',
          getSessionTitle(dateChangeSession),
          '".'
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1551,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1549,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Current Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1557,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              readOnly: true,
              value: dateChangeSession.date,
              className: "w-full px-3 py-2 border border-slate-200 bg-slate-50 rounded-md text-xs text-slate-500"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1558,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1556,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "New Date" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1566,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              value: dateChangeNewDate,
              onChange: (e) => setDateChangeNewDate(e.target.value),
              className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1567,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1565,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Reason for change" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1575,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 3,
              value: dateChangeReason,
              onChange: (e) => setDateChangeReason(e.target.value),
              placeholder: "Explain why the date needs to be changed...",
              className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
              lineNumber: 1576,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
          lineNumber: 1574,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1555,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setDateChangeSession(null),
            className: "px-3.5 py-1.5 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-50 cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1586,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: async () => {
              if (onRequestDateChange && dateChangeNewDate && dateChangeReason) {
                await onRequestDateChange(
                  dateChangeSession.id,
                  dateChangeSession.date || "",
                  dateChangeNewDate,
                  dateChangeReason
                );
                setDateChangeSession(null);
              } else {
                alert("Please provide a new date and a reason.");
              }
            },
            className: "px-4 py-1.5 bg-[#0B3D91] hover:bg-[#082a66] text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer",
            children: "Submit Request"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
            lineNumber: 1593,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
        lineNumber: 1585,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1545,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
      lineNumber: 1544,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx",
    lineNumber: 488,
    columnNumber: 5
  }, this);
};
_s(SessionsView, "C7Qsn3HYWA9tIEFGPPNl3kFqDhI=");
_c = SessionsView;
var _c;
$RefreshReg$(_c, "SessionsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMGJZOztBQTFiWixTQUFnQkEsV0FBV0MsVUFBVUMsZUFBZTtBQUVwRCxTQUFTQyxhQUFhO0FBQ3RCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLFFBQVFDLEdBQUdDLFVBQVVDLE1BQU1DLGNBQWM7QUFlM0MsYUFBTUMsZUFBNENBLENBQUM7QUFBQSxFQUN4REMsV0FBVztBQUFBLEVBQ1hDLGFBQWE7QUFBQSxFQUNiQyxhQUFhO0FBQUEsRUFDYkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsb0JBQW9CO0FBQUEsRUFDcEJDLFdBQVc7QUFDYixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNQyxpQkFBaUJGLGFBQWE7QUFFcEMsUUFBTSxDQUFDRyxZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsbUJBQW1CQyxvQkFBb0IsSUFBSTdCLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUM4QixpQkFBaUJDLGtCQUFrQixJQUFJL0IsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2dDLGdCQUFnQkMsaUJBQWlCLElBQUlqQyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDa0MsZ0JBQWdCQyxpQkFBaUIsSUFBSW5DLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUNvQyxtQkFBbUJDLG9CQUFvQixJQUFJckMsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ3NDLFlBQVlDLGFBQWEsSUFBSXZDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN3QyxpQkFBaUJDLGtCQUFrQixJQUFJekMsU0FBUyxLQUFLO0FBRzVELFFBQU0sQ0FBQzBDLGdCQUFnQkMsaUJBQWlCLElBQUkzQyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDNEMsWUFBWUMsYUFBYSxJQUFJN0MsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzhDLHFCQUFxQkMsc0JBQXNCLElBQUkvQyxTQUF5QixJQUFJO0FBQ25GLFFBQU0sQ0FBQ2dELGlCQUFpQkMsa0JBQWtCLElBQUlqRCxTQUF5QixJQUFJO0FBQzNFLFFBQU0sQ0FBQ2tELG1CQUFtQkMsb0JBQW9CLElBQUluRCxTQUF5QixJQUFJO0FBQy9FLFFBQU0sQ0FBQ29ELGtCQUFrQkMsbUJBQW1CLElBQUlyRCxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDc0QsbUJBQW1CQyxvQkFBb0IsSUFBSXZELFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUN3RCxZQUFZQyxhQUFhLElBQUl6RCxTQUFpQyxDQUFDLENBQUM7QUFFdkVELFlBQVUsTUFBTTtBQUNkMEQsa0JBQWMsQ0FBQ0MsWUFBWTtBQUN6QixZQUFNQyxPQUFPLEVBQUUsR0FBR0QsUUFBUTtBQUMxQjVDLGVBQVM4QyxRQUFRLENBQUNDLFlBQVk7QUFDNUIsWUFBSSxFQUFFQSxRQUFRQyxNQUFNSCxNQUFPQSxNQUFLRSxRQUFRQyxFQUFFLElBQUlELFFBQVFFLFFBQVE7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsYUFBT0o7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUM3QyxRQUFRLENBQUM7QUFHYixRQUFNLENBQUNrRCxVQUFVQyxXQUFXLElBQUlqRSxTQUFTO0FBQUEsSUFDdkM4RCxJQUFJO0FBQUEsSUFDSkksTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLElBQ1JDLEtBQUs7QUFBQSxJQUNMUCxPQUFNLG9CQUFJUSxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQzNDQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLGFBQWE3RCxXQUFXLENBQUMsR0FBRytDLE1BQU07QUFBQSxJQUNsQ2UsZUFBZTlELFdBQVcsQ0FBQyxHQUFHb0QsUUFBUTtBQUFBLElBQ3RDVyxhQUFhL0QsV0FBVyxDQUFDLEdBQUdnRSxTQUFTLENBQUMsR0FBR1osUUFBUTtBQUFBLElBQ2pEYSxhQUFhaEUsV0FBVyxDQUFDLEdBQUc4QyxNQUFNO0FBQUEsSUFDbENtQixlQUFlakUsV0FBVyxDQUFDLEdBQUdtRCxRQUFRO0FBQUEsSUFDdENlLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJdEYsU0FBaUMsQ0FBQyxDQUFDO0FBR3ZFLFFBQU11Rix3QkFBd0J0RixRQUFRLE1BQU07QUFDMUMsUUFBSTJCLHNCQUFzQixPQUFPO0FBQy9CLFlBQU00RCxjQUE4QztBQUNwRHpFLGlCQUFXNkMsUUFBUSxDQUFDNkIsTUFBTTtBQUN4QkEsVUFBRVYsVUFBVW5CLFFBQVEsQ0FBQzhCLE1BQU07QUFDekIsY0FBSSxDQUFDRixZQUFZRyxLQUFLLENBQUNDLGFBQWFBLFNBQVN6QixTQUFTdUIsRUFBRXZCLElBQUksR0FBRztBQUM3RHFCLHdCQUFZSyxLQUFLLEVBQUUvQixJQUFJNEIsRUFBRTVCLElBQUlLLE1BQU11QixFQUFFdkIsS0FBSyxDQUFDO0FBQUEsVUFDN0M7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILENBQUM7QUFDRCxhQUFPcUI7QUFBQUEsSUFDVDtBQUNBLFVBQU1NLFFBQVEvRSxXQUFXZ0YsS0FBSyxDQUFDTixNQUFNQSxFQUFFM0IsT0FBT2xDLGlCQUFpQjtBQUMvRCxXQUFPa0UsT0FBT2YsWUFBWTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ25ELG1CQUFtQmIsVUFBVSxDQUFDO0FBR2xDLFFBQU1pRixnQkFBZ0IvRixRQUFRLE1BQU07QUFDbEMsVUFBTTZGLFFBQVEvRSxXQUFXZ0YsS0FBSyxDQUFDTixNQUFNQSxFQUFFM0IsT0FBT0UsU0FBU1ksV0FBVztBQUNsRSxXQUFPa0IsT0FBT2YsWUFBWTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ2YsU0FBU1ksYUFBYTdELFVBQVUsQ0FBQztBQUdyQyxRQUFNa0Ysa0JBQWtCQSxDQUFDQyxNQUF3QjtBQUMvQyxRQUFJLENBQUNBLEVBQUcsUUFBTztBQUNmLFdBQU9BLEVBQUUvQixRQUFRK0IsRUFBRUMsU0FBU0QsRUFBRWhDLFFBQVE7QUFBQSxFQUN4QztBQUVBLFFBQU1rQyxtQkFBbUJBLENBQUNGLE1BQXdCO0FBQ2hELFFBQUksQ0FBQ0EsRUFBRyxRQUFPO0FBQ2YsV0FBT0EsRUFBRTdCLFVBQVU2QixFQUFFOUIsWUFBWTtBQUFBLEVBQ25DO0FBRUEsUUFBTWlDLHNCQUFzQkEsQ0FBQ0gsTUFBd0I7QUFDbkQsUUFBSSxDQUFDQSxLQUFLLENBQUNBLEVBQUVqQixpQkFBaUJpQixFQUFFakIsa0JBQWtCLGFBQWMsUUFBTztBQUN2RSxXQUFPaUIsRUFBRWpCO0FBQUFBLEVBQ1g7QUFHQSxRQUFNcUIsbUJBQW1Cckc7QUFBQUEsSUFBUSxNQUFNO0FBQ3JDLGFBQU9hLFNBQVN5RixPQUFPLENBQUNMLE1BQU07QUFDNUIsY0FBTUMsUUFBUUYsZ0JBQWdCQyxDQUFDLEVBQUVNLFlBQVk7QUFDN0MsY0FBTUMsTUFBTUwsaUJBQWlCRixDQUFDLEVBQUVNLFlBQVk7QUFDNUMsY0FBTUUsUUFBUVIsRUFBRXBCLGVBQWUsSUFBSTBCLFlBQVk7QUFDL0MsY0FBTUcsT0FBT1QsRUFBRWpCLGlCQUFpQixJQUFJdUIsWUFBWTtBQUNoRCxjQUFNSSxPQUFPVixFQUFFckIsaUJBQWlCLElBQUkyQixZQUFZO0FBQ2hELGNBQU1LLFNBQVNuRixXQUFXOEUsWUFBWSxFQUFFTSxLQUFLO0FBRTdDLGNBQU1DLGNBQ0osQ0FBQ0YsVUFDRFYsTUFBTWEsU0FBU0gsTUFBTSxLQUNyQkosSUFBSU8sU0FBU0gsTUFBTSxLQUNuQkgsS0FBS00sU0FBU0gsTUFBTSxLQUNwQkYsSUFBSUssU0FBU0gsTUFBTSxLQUNuQkQsSUFBSUksU0FBU0gsTUFBTSxNQUNsQlgsRUFBRWhDLFFBQVEsSUFBSXNDLFlBQVksRUFBRVEsU0FBU0gsTUFBTTtBQUU5QyxjQUFNSSxpQkFDSnJGLHNCQUFzQixTQUFTc0UsRUFBRXRCLGdCQUFnQmhEO0FBRW5ELGNBQU1zRixlQUNKcEYsb0JBQW9CLFVBQ25Cb0UsRUFBRXBCLGVBQWUsSUFBSTBCLFlBQVksTUFBTTFFLGdCQUFnQjBFLFlBQVk7QUFFdEUsY0FBTVcsY0FDSm5GLG1CQUFtQixTQUNuQmtFLEVBQUVkLE9BQU9vQixZQUFZLE1BQU14RSxlQUFld0UsWUFBWSxLQUNyRHhFLG1CQUFtQixzQkFBc0JrRSxFQUFFZCxXQUFXLHFCQUFxQmMsRUFBRWQsV0FBVztBQUUzRixjQUFNZ0MsY0FDSmxGLG1CQUFtQixTQUNuQnVFLElBQUlPLFNBQVM5RSxlQUFlc0UsWUFBWSxDQUFDLEtBQ3pDTixFQUFFOUIsYUFBYWxDO0FBRWpCLGNBQU1tRixpQkFDSmpGLHNCQUFzQixTQUN0QjhELEVBQUVsQixnQkFBZ0I1QyxzQkFDakI4RCxFQUFFakIsaUJBQWlCLElBQUl1QixZQUFZLE1BQU1wRSxrQkFBa0JvRSxZQUFZO0FBRTFFLGNBQU1jLFlBQVksQ0FBQ2hGLGNBQWM0RCxFQUFFbkMsU0FBU3pCO0FBRTVDLGVBQ0V5RSxlQUNBRSxrQkFDQUMsZ0JBQ0FDLGVBQ0FDLGVBQ0FDLGtCQUNBQztBQUFBQSxNQUVKLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFBRztBQUFBLE1BQ0R4RztBQUFBQSxNQUNBWTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBRTtBQUFBQSxJQUFVO0FBQUEsRUFDWDtBQUdELFFBQU1pRixnQkFBZ0J6RyxTQUFTeUY7QUFBQUEsSUFDN0IsQ0FBQ0wsTUFBTUEsRUFBRWQsV0FBVyxlQUFlYyxFQUFFZCxXQUFXO0FBQUEsRUFDbEQsRUFBRW9DO0FBQ0YsUUFBTUMsaUJBQWlCM0csU0FBU3lGLE9BQU8sQ0FBQ0wsTUFBTUEsRUFBRWQsV0FBVyxXQUFXLEVBQUVvQztBQUN4RSxRQUFNRSxpQkFBaUI1RyxTQUFTeUYsT0FBTyxDQUFDTCxNQUFNQSxFQUFFZCxXQUFXLFdBQVcsRUFBRW9DO0FBQ3hFLFFBQU1HLHNCQUFzQjdHLFNBQVN5RjtBQUFBQSxJQUNuQyxDQUFDTCxNQUFNQSxFQUFFZCxXQUFXLHFCQUFxQmMsRUFBRWQsV0FBVyxpQkFBaUJjLEVBQUVqQixrQkFBa0I7QUFBQSxFQUM3RixFQUFFdUM7QUFHRixRQUFNSSxjQUFjM0gsUUFBUSxNQUFNO0FBQ2hDLFVBQU00SCxZQUFZL0csU0FBU3lGLE9BQU8sQ0FBQ0wsTUFBTUEsRUFBRWQsV0FBVyxXQUFXO0FBQ2pFLFFBQUl5QyxVQUFVTCxTQUFTLEVBQUcsUUFBT0ssVUFBVSxDQUFDO0FBQzVDLFdBQU8vRyxTQUFTLENBQUMsS0FBSztBQUFBLEVBQ3hCLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBR2IsUUFBTWdILHFCQUFxQkEsTUFBTTtBQUMvQm5HLGtCQUFjLEVBQUU7QUFDaEJFLHlCQUFxQixLQUFLO0FBQzFCRSx1QkFBbUIsS0FBSztBQUN4QkUsc0JBQWtCLEtBQUs7QUFDdkJFLHNCQUFrQixLQUFLO0FBQ3ZCRSx5QkFBcUIsS0FBSztBQUMxQkUsa0JBQWMsRUFBRTtBQUFBLEVBQ2xCO0FBR0EsUUFBTXdGLHFCQUFxQkEsTUFBTTtBQUMvQmxGLGtCQUFjLEtBQUs7QUFDbkJ5QyxrQkFBYyxDQUFDLENBQUM7QUFDaEIsVUFBTTBDLFdBQVdqSCxXQUFXLENBQUM7QUFDN0JrRCxnQkFBWTtBQUFBLE1BQ1ZILElBQUk7QUFBQSxNQUNKSSxNQUFNLEtBQUsrRCxLQUFLQyxNQUFNLE1BQU1ELEtBQUtFLE9BQU8sSUFBSSxHQUFHLENBQUM7QUFBQSxNQUNoRGhFLE1BQU07QUFBQSxNQUNOQyxVQUFVO0FBQUEsTUFDVkMsUUFBUTtBQUFBLE1BQ1JDLEtBQUs7QUFBQSxNQUNMUCxPQUFNLG9CQUFJUSxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQzNDQyxNQUFNO0FBQUEsTUFDTkMsU0FBUztBQUFBLE1BQ1RDLGFBQWFvRCxVQUFVbEUsTUFBTTtBQUFBLE1BQzdCZSxlQUFlbUQsVUFBVTdELFFBQVE7QUFBQSxNQUNqQ1csYUFBYWtELFVBQVVqRCxTQUFTLENBQUMsR0FBR1osUUFBUTtBQUFBLE1BQzVDYSxhQUFhaEUsV0FBVyxDQUFDLEdBQUc4QyxNQUFNO0FBQUEsTUFDbENtQixlQUFlakUsV0FBVyxDQUFDLEdBQUdtRCxRQUFRO0FBQUEsTUFDdENlLGFBQWE7QUFBQSxNQUNiQyxhQUFhO0FBQUEsTUFDYkMsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUNEekMsc0JBQWtCLElBQUk7QUFBQSxFQUN4QjtBQUdBLFFBQU15RixzQkFBc0JBLENBQUN2RSxZQUFxQjtBQUNoRGhCLGtCQUFjLElBQUk7QUFDbEJ5QyxrQkFBYyxDQUFDLENBQUM7QUFDaEJyQixnQkFBWTtBQUFBLE1BQ1ZILElBQUlELFFBQVFDO0FBQUFBLE1BQ1pJLE1BQU1MLFFBQVFLLFFBQVE7QUFBQSxNQUN0QkMsTUFBTU4sUUFBUU0sUUFBUU4sUUFBUXNDLFNBQVM7QUFBQSxNQUN2Qy9CLFVBQVVQLFFBQVFPLFlBQVk7QUFBQSxNQUM5QkMsUUFBUVIsUUFBUVEsVUFBVTtBQUFBLE1BQzFCQyxLQUFLVCxRQUFRUyxPQUFPO0FBQUEsTUFDcEJQLE1BQU1GLFFBQVFFLFFBQVE7QUFBQSxNQUN0QlcsTUFBTWIsUUFBUWEsUUFBUTtBQUFBLE1BQ3RCQyxTQUFTZCxRQUFRYyxXQUFXO0FBQUEsTUFDNUJDLGFBQWFmLFFBQVFlLGVBQWdCN0QsV0FBVyxDQUFDLEdBQUcrQyxNQUFNO0FBQUEsTUFDMURlLGVBQWVoQixRQUFRZ0IsaUJBQWtCOUQsV0FBVyxDQUFDLEdBQUdvRCxRQUFRO0FBQUEsTUFDaEVXLGFBQWFqQixRQUFRaUIsZUFBZTtBQUFBLE1BQ3BDRSxhQUFhbkIsUUFBUW1CLGVBQWU7QUFBQSxNQUNwQ0MsZUFBZXBCLFFBQVFvQixpQkFBaUI7QUFBQSxNQUN4Q0MsYUFBYXJCLFFBQVFxQixlQUFlO0FBQUEsTUFDcENDLGFBQWF0QixRQUFRc0IsZUFBZTtBQUFBLE1BQ3BDQyxRQUFRdkIsUUFBUXVCLFVBQVU7QUFBQSxJQUM1QixDQUFDO0FBQ0R6QyxzQkFBa0IsSUFBSTtBQUFBLEVBQ3hCO0FBR0EsUUFBTTBGLDhCQUE4QkEsQ0FBQ0MsUUFBZ0I7QUFDbkQsVUFBTXhDLFFBQVEvRSxXQUFXZ0YsS0FBSyxDQUFDTixNQUFNQSxFQUFFM0IsT0FBT3dFLEdBQUc7QUFDakQsUUFBSXhDLE9BQU87QUFDVDdCLGtCQUFZLENBQUNzRSxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDNELGFBQWFrQixNQUFNaEM7QUFBQUEsUUFDbkJlLGVBQWVpQixNQUFNM0I7QUFBQUEsUUFDckJXLGFBQWFnQixNQUFNZixTQUFTLENBQUMsR0FBR1osUUFBUTtBQUFBLE1BQzFDLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUVBLFFBQU1xRSw4QkFBOEJBLENBQUNDLFFBQWdCO0FBQ25ELFFBQUlBLFFBQVEsY0FBYztBQUN4QnhFLGtCQUFZLENBQUNzRSxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSHZELGFBQWE7QUFBQSxRQUNiQyxlQUFlO0FBQUEsTUFDakIsRUFBRTtBQUNGO0FBQUEsSUFDRjtBQUNBLFVBQU1hLFFBQVE5RSxXQUFXK0UsS0FBSyxDQUFDTCxNQUFNQSxFQUFFNUIsT0FBTzJFLEdBQUc7QUFDakQsUUFBSTNDLE9BQU87QUFDVDdCLGtCQUFZLENBQUNzRSxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSHZELGFBQWFjLE1BQU1oQztBQUFBQSxRQUNuQm1CLGVBQWVhLE1BQU0zQjtBQUFBQSxNQUN2QixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFHQSxRQUFNdUUsbUJBQW1CQSxDQUFDQyxVQUFVLFVBQVU7QUFDNUMsVUFBTUMsU0FBaUMsQ0FBQztBQUV4QyxRQUFJLENBQUM1RSxTQUFTRyxLQUFLMkMsS0FBSyxHQUFHO0FBQ3pCOEIsYUFBT3pFLE9BQU87QUFBQSxJQUNoQjtBQUNBLFFBQUksQ0FBQ0gsU0FBU2MsWUFBWWdDLEtBQUssR0FBRztBQUNoQzhCLGFBQU85RCxjQUFjO0FBQUEsSUFDdkI7QUFDQSxRQUFJLENBQUNkLFNBQVNpQixjQUFjNkIsS0FBSyxLQUFLOUMsU0FBU2lCLGtCQUFrQixjQUFjO0FBQzdFLFVBQUksQ0FBQzBELFNBQVM7QUFDWkMsZUFBT0MsWUFBWTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQzdFLFNBQVNELEtBQUsrQyxLQUFLLEdBQUc7QUFDekI4QixhQUFPN0UsT0FBTztBQUFBLElBQ2hCO0FBRUEsUUFBSStFLE9BQU9DLEtBQUtILE1BQU0sRUFBRXBCLFNBQVMsR0FBRztBQUNsQ2xDLG9CQUFjc0QsTUFBTTtBQUNwQjtBQUFBLElBQ0Y7QUFFQSxVQUFNSSxjQUFpQ0wsVUFDbkMsVUFDQTNFLFNBQVNvQixVQUFVO0FBRXZCLFFBQUl4QyxjQUFjb0IsU0FBU0YsSUFBSTtBQUM3QjNDLHNCQUFnQjZDLFNBQVNGLElBQUk7QUFBQSxRQUMzQkssTUFBTUgsU0FBU0csS0FBSzJDLEtBQUs7QUFBQSxRQUN6QlgsT0FBT25DLFNBQVNHLEtBQUsyQyxLQUFLO0FBQUEsUUFDMUI1QyxNQUFNRixTQUFTRTtBQUFBQSxRQUNmRSxVQUFVSixTQUFTSTtBQUFBQSxRQUNuQkMsUUFBUUwsU0FBU0s7QUFBQUEsUUFDakJDLEtBQUtOLFNBQVNNO0FBQUFBLFFBQ2RQLE1BQU1DLFNBQVNEO0FBQUFBLFFBQ2ZXLE1BQU1WLFNBQVNVO0FBQUFBLFFBQ2ZDLFNBQVNYLFNBQVNXO0FBQUFBLFFBQ2xCQyxhQUFhWixTQUFTWTtBQUFBQSxRQUN0QkMsZUFBZWIsU0FBU2E7QUFBQUEsUUFDeEJDLGFBQWFkLFNBQVNjO0FBQUFBLFFBQ3RCRSxhQUFhaEIsU0FBU2dCO0FBQUFBLFFBQ3RCQyxlQUFlakIsU0FBU2lCO0FBQUFBLFFBQ3hCQyxhQUFhbEIsU0FBU2tCO0FBQUFBLFFBQ3RCQyxhQUFhbkIsU0FBU21CO0FBQUFBLFFBQ3RCQyxRQUFRNEQ7QUFBQUEsTUFDVixDQUFDO0FBQ0QsVUFBSWxHLHFCQUFxQmdCLE9BQU9FLFNBQVNGLElBQUk7QUFDM0NmLCtCQUF1QixDQUFDd0YsU0FBVUEsT0FBTyxFQUFFLEdBQUdBLE1BQU0sR0FBR3ZFLFVBQVVvQixRQUFRNEQsWUFBWSxJQUFJLElBQUs7QUFBQSxNQUNoRztBQUFBLElBQ0YsT0FBTztBQUNMLFlBQU1DLGFBQWtDO0FBQUEsUUFDdEMvRSxNQUFNRixTQUFTRSxRQUFRLEtBQUsrRCxLQUFLQyxNQUFNLE1BQU1ELEtBQUtFLE9BQU8sSUFBSSxHQUFHLENBQUM7QUFBQSxRQUNqRWhFLE1BQU1ILFNBQVNHLEtBQUsyQyxLQUFLO0FBQUEsUUFDekJYLE9BQU9uQyxTQUFTRyxLQUFLMkMsS0FBSztBQUFBLFFBQzFCMUMsVUFBVUosU0FBU0k7QUFBQUEsUUFDbkJDLFFBQVFMLFNBQVNLO0FBQUFBLFFBQ2pCQyxLQUFLTixTQUFTTTtBQUFBQSxRQUNkUCxNQUFNQyxTQUFTRDtBQUFBQSxRQUNmVyxNQUFNVixTQUFTVTtBQUFBQSxRQUNmQyxTQUFTWCxTQUFTVztBQUFBQSxRQUNsQkMsYUFBYVosU0FBU1k7QUFBQUEsUUFDdEJDLGVBQWViLFNBQVNhO0FBQUFBLFFBQ3hCQyxhQUFhZCxTQUFTYztBQUFBQSxRQUN0QkUsYUFBYWhCLFNBQVNnQjtBQUFBQSxRQUN0QkMsZUFBZWpCLFNBQVNpQjtBQUFBQSxRQUN4QkMsYUFBYWxCLFNBQVNrQjtBQUFBQSxRQUN0QkMsYUFBYW5CLFNBQVNtQixlQUFlO0FBQUEsUUFDckNDLFFBQVE0RDtBQUFBQSxRQUNSRSxNQUFNbEYsU0FBU2lCO0FBQUFBLFFBQ2ZrRSxVQUFVO0FBQUEsTUFDWjtBQUNBakksbUJBQWErSCxVQUFVO0FBQUEsSUFDekI7QUFFQXRHLHNCQUFrQixLQUFLO0FBQUEsRUFDekI7QUFHQSxRQUFNeUcsa0JBQWtCQSxNQUFNO0FBQzVCLFFBQUk5QyxpQkFBaUJrQixXQUFXLEdBQUc7QUFDakM2QixZQUFNLHNDQUFzQztBQUM1QztBQUFBLElBQ0Y7QUFDQSxVQUFNQyxVQUFVO0FBQUEsTUFDZDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFjO0FBR2hCLFVBQU1DLE9BQU9qRCxpQkFBaUJrRDtBQUFBQSxNQUFJLENBQUN0RCxNQUFNO0FBQUEsUUFDdkMsSUFBSUEsRUFBRWhDLFFBQVEsRUFBRTtBQUFBLFFBQ2hCLEtBQUtnQyxFQUFFL0IsUUFBUStCLEVBQUVDLFNBQVMsSUFBSXNELFFBQVEsTUFBTSxJQUFJLENBQUM7QUFBQSxRQUNqRCxLQUFLdkQsRUFBRTdCLFVBQVU2QixFQUFFOUIsWUFBWSxJQUFJcUYsUUFBUSxNQUFNLElBQUksQ0FBQztBQUFBLFFBQ3RELElBQUl2RCxFQUFFbkMsSUFBSTtBQUFBLFFBQ1YsSUFBSW1DLEVBQUV4QixJQUFJO0FBQUEsUUFDVixJQUFJd0IsRUFBRTVCLE9BQU8sRUFBRTtBQUFBLFFBQ2YsSUFBSTRCLEVBQUVyQixhQUFhO0FBQUEsUUFDbkIsSUFBSXFCLEVBQUVwQixXQUFXO0FBQUEsUUFDakIsSUFBSW9CLEVBQUVqQixhQUFhO0FBQUEsUUFDbkIsSUFBSWlCLEVBQUVkLE1BQU07QUFBQSxRQUNaLElBQUljLEVBQUVoQixlQUFlLFVBQVU7QUFBQSxNQUFHO0FBQUEsSUFDbkM7QUFFRCxVQUFNd0UsYUFDSixpQ0FDQSxDQUFDSixRQUFRSyxLQUFLLEdBQUcsR0FBRyxHQUFHSixLQUFLQyxJQUFJLENBQUNJLE1BQU1BLEVBQUVELEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRUEsS0FBSyxJQUFJO0FBQ2hFLFVBQU1FLGFBQWFDLFVBQVVKLFVBQVU7QUFDdkMsVUFBTUssT0FBT0MsU0FBU0MsY0FBYyxHQUFHO0FBQ3ZDRixTQUFLRyxhQUFhLFFBQVFMLFVBQVU7QUFDcENFLFNBQUtHO0FBQUFBLE1BQ0g7QUFBQSxNQUNBLDRCQUEyQixvQkFBSTNGLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFBQSxJQUNuRTtBQUNBdUYsYUFBU0csS0FBS0MsWUFBWUwsSUFBSTtBQUM5QkEsU0FBS00sTUFBTTtBQUNYTCxhQUFTRyxLQUFLRyxZQUFZUCxJQUFJO0FBQUEsRUFDaEM7QUFHQSxRQUFNUSxvQkFBb0JBLENBQUNuRixXQUFtQjtBQUM1QyxZQUFRQSxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxVQUFLLFdBQVUscUlBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFBTztBQUFBLGFBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0UsdUJBQUMsVUFBSyxXQUFVLHdJQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHlEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQU87QUFBQSxhQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxNQUVKLEtBQUs7QUFDSCxlQUNFLHVCQUFDLFVBQUssV0FBVSw4SUFDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSw2Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUFPO0FBQUEsYUFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFFSixLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQ0gsZUFDRSx1QkFBQyxVQUFLLFdBQVUscUlBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFBTztBQUFBLGFBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0UsdUJBQUMsVUFBSyxXQUFVLHlJQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQU87QUFBQSxhQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxNQUVKLEtBQUs7QUFBQSxNQUNMO0FBQ0UsZUFDRSx1QkFBQyxVQUFLLFdBQVUseUlBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMkNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFBTztBQUFBLGFBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLElBRU47QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDhFQUE2RSxpQ0FBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QmtCO0FBQUFBLDZCQUFpQmtCO0FBQUFBLFlBQU87QUFBQSxlQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxpREFBZ0Qsb0dBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUzRCO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBO0FBQUEsVUFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTckI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUE7QUFBQSxVQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1GQUFrRix3QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RztBQUFBLFFBQ3pHLHVCQUFDLFNBQUksV0FBVSx5REFBeURSLDJCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNGO0FBQUEsV0FGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUVBQWdFLHlCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsUUFDeEYsdUJBQUMsU0FBSSxXQUFVLHlEQUF5REUsNEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxXQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtRUFBa0UseUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUMxRix1QkFBQyxTQUFJLFdBQVUseURBQXlEQyw0QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFdBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGlFQUFnRSwrQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RjtBQUFBLFFBQzlGLHVCQUFDLFNBQUksV0FBVSx5REFBeURDLGlDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsV0FGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBR0NDLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLDZHQUNiLGlDQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHlIQUF3SCw0QkFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0MyQyxrQkFBa0IzQyxZQUFZeEMsTUFBTTtBQUFBLGFBSnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUNYYTtBQUFBQSwwQkFBZ0IyQixXQUFXO0FBQUEsVUFDM0JBLFlBQVkxRCxRQUNYLHVCQUFDLFVBQUssV0FBVSxvREFBbUQ7QUFBQTtBQUFBLFlBQy9EMEQsWUFBWTFEO0FBQUFBLFlBQUs7QUFBQSxlQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxvR0FDYjtBQUFBLGlDQUFDLFVBQU0wRDtBQUFBQSx3QkFBWTdEO0FBQUFBLFlBQUs7QUFBQSxZQUFXNkQsWUFBWWxEO0FBQUFBLGVBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBVyx1QkFBQyxZQUFPLFdBQVUsb0NBQW9Da0Qsc0JBQVkvQyxpQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0Y7QUFBQSxlQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRztBQUFBLFVBQzFHLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQVMsdUJBQUMsWUFBTyxXQUFVLG9DQUFvQytDLHNCQUFZOUMsZUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxlQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRztBQUFBLFVBQ3RHLHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQVcsdUJBQUMsWUFBTyxXQUFVLGtCQUFrQnVCLDhCQUFvQnVCLFdBQVcsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUU7QUFBQSxlQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRjtBQUFBLGFBSmpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU03RSx1QkFBdUI2RSxXQUFXO0FBQUEsWUFDakQsV0FBVTtBQUFBLFlBQWlNO0FBQUE7QUFBQSxVQUg3TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTTNHLFdBQVcsZUFBZTJHLFlBQVk0QyxnQkFBZ0I1QyxZQUFZOUQsRUFBRTtBQUFBLFlBQ25GLFdBQVU7QUFBQSxZQUFpTTtBQUFBO0FBQUEsVUFIN007QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU03QyxXQUFXLGNBQWMyRyxZQUFZOUQsRUFBRTtBQUFBLFlBQ3RELFdBQVU7QUFBQSxZQUFvSDtBQUFBO0FBQUEsVUFIaEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsU0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStDQSxLQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaURBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx3REFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsaUNBQUMsVUFBTyxXQUFVLDBGQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RztBQUFBLFVBQ3hHO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPcEM7QUFBQUEsY0FDUCxVQUFVLENBQUNrSSxNQUFNakksY0FBY2lJLEVBQUVhLE9BQU9DLEtBQUs7QUFBQSxjQUM3QyxhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUsrTztBQUFBLFVBRTlPaEosY0FDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNQyxjQUFjLEVBQUU7QUFBQSxjQUMvQixXQUFVO0FBQUEsY0FFVixpQ0FBQyxLQUFFLFdBQVUsaUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEI7QUFBQTtBQUFBLFlBTDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT0MscUJBQXFCO0FBQUEsWUFDNUIsZUFBZSxDQUFDK0ksUUFBUTtBQUN0QjlJLG1DQUFxQjhJLEdBQUc7QUFDeEI1SSxpQ0FBbUIsS0FBSztBQUFBLFlBQzFCO0FBQUEsWUFFQTtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDQztBQUFBLHVDQUFDLGNBQVcsT0FBTSxPQUFNLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUNyQ2hCLFdBQVd5STtBQUFBQSxrQkFBSSxDQUFDL0QsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFM0IsSUFDN0IyQixZQUFFdEIsUUFEWXNCLEVBQUUzQixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQSxtQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPaEMsbUJBQW1CO0FBQUEsWUFDMUIsZUFBZSxDQUFDNkksUUFBUTVJLG1CQUFtQjRJLEdBQUc7QUFBQSxZQUU5QztBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDQztBQUFBLHVDQUFDLGNBQVcsT0FBTSxPQUFNLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLGdCQUNuQ3BGLHNCQUFzQmlFO0FBQUFBLGtCQUFJLENBQUM5RCxNQUMxQix1QkFBQyxjQUFzQixPQUFPQSxFQUFFdkIsTUFDN0J1QixZQUFFdkIsUUFEWXVCLEVBQUU1QixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQSxtQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU85QixrQkFBa0I7QUFBQSxjQUN6QixlQUFlLENBQUMySSxRQUFRMUksa0JBQWtCMEksR0FBRztBQUFBLGNBRTdDO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDQztBQUFBLHlDQUFDLGNBQVcsT0FBTSxPQUFNLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNwQyx1QkFBQyxjQUFXLE9BQU0sYUFBWSx5QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUM7QUFBQSxrQkFDdkMsdUJBQUMsY0FBVyxPQUFNLGVBQWMsMkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQzNDLHVCQUFDLGNBQVcsT0FBTSxhQUFZLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUN2Qyx1QkFBQyxjQUFXLE9BQU0sbUJBQWtCLCtCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRDtBQUFBLGtCQUNuRCx1QkFBQyxjQUFXLE9BQU0sU0FBUSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQSxrQkFDL0IsdUJBQUMsY0FBVyxPQUFNLGFBQVkseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEscUJBUHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQTtBQUFBO0FBQUEsWUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1sSSxtQkFBbUIsQ0FBQ0QsZUFBZTtBQUFBLGNBQ2xELFdBQVcsaUhBQ1RBLG1CQUFtQk4sbUJBQW1CLFNBQVNFLHNCQUFzQixTQUFTRSxhQUMxRSx5RkFDQSxrSEFBa0g7QUFBQSxjQUd4SDtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTREO0FBQUEsZ0JBQzVELHVCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBWTtBQUFBO0FBQUE7QUFBQSxZQVZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsYUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlDQTtBQUFBLFdBbkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvR0E7QUFBQSxNQUdDRSxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsd0hBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1GQUFrRixzQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9OO0FBQUFBLGNBQ1AsZUFBZSxDQUFDeUksUUFBUXhJLGtCQUFrQndJLEdBQUc7QUFBQSxjQUU3QztBQUFBLHVDQUFDLGlCQUFjLFdBQVUsc0JBQ3ZCLGlDQUFDLGVBQVksYUFBWSxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNDO0FBQUEseUNBQUMsY0FBVyxPQUFNLE9BQU0sMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUEsa0JBQ25DLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsOEJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLGNBQVcsT0FBTSxjQUFhLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QztBQUFBLGtCQUN6Qyx1QkFBQyxjQUFXLE9BQU0sZUFBYywyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQSxrQkFDM0MsdUJBQUMsY0FBVyxPQUFNLG9CQUFtQixnQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUQ7QUFBQSxrQkFDckQsdUJBQUMsY0FBVyxPQUFNLFdBQVUsdUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUEsa0JBQ25DLHVCQUFDLGNBQVcsT0FBTSxzQkFBcUIsa0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlEO0FBQUEscUJBUDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQTtBQUFBO0FBQUEsWUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQkE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1GQUFrRix5QkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU92STtBQUFBQSxjQUNQLGVBQWUsQ0FBQ3VJLFFBQVF0SSxxQkFBcUJzSSxHQUFHO0FBQUEsY0FFaEQ7QUFBQSx1Q0FBQyxpQkFBYyxXQUFVLHNCQUN2QixpQ0FBQyxlQUFZLGFBQVksb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDQztBQUFBLHlDQUFDLGNBQVcsT0FBTSxPQUFNLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUNyQzNKLFdBQVd3STtBQUFBQSxvQkFBSSxDQUFDOUQsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFdkIsTUFDN0J1QixZQUFFdkIsUUFEWXVCLEVBQUU1QixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQSxxQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUE7QUFBQTtBQUFBLFlBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1GQUFrRixvQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU94QjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3NILE1BQU1ySCxjQUFjcUgsRUFBRWEsT0FBT0MsS0FBSztBQUFBLGNBQzdDLFdBQVU7QUFBQTtBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWlOO0FBQUEsYUFSbk47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVM1QztBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFpTDtBQUFBO0FBQUEsVUFIN0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUVBO0FBQUEsU0E1S0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThLQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlIQUNiLGlDQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsb0NBQ2Y7QUFBQSw2QkFBQyxXQUFNLFdBQVUsd0tBQ2YsaUNBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxlQUFjLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJDO0FBQUEsUUFDM0MsdUJBQUMsUUFBRyxXQUFVLGVBQWMsc0NBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RCx1QkFBQyxRQUFHLFdBQVUsZUFBYyxtQ0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFFBQUcsV0FBVSxlQUFjLHlCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsUUFBRyxXQUFVLGVBQWMsc0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxRQUFHLFdBQVUsMEJBQXlCLHVCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FOaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxXQUFNLFdBQVUseURBQ2R4QiwyQkFBaUJrQixXQUFXLElBQzNCLHVCQUFDLFFBQ0MsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSxtQ0FBa0MsdURBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQSxJQUVBbEIsaUJBQWlCa0Q7QUFBQUEsUUFBSSxDQUFDM0YsWUFDcEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUdWO0FBQUEscUNBQUMsUUFBRyxXQUFVLGlDQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJDQUEyQ0Esa0JBQVFFLFFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVFO0FBQUEsZ0JBQ3ZFLHVCQUFDLFNBQUksV0FBVSxvQ0FDWkYsa0JBQVFhLFFBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUdBLHVCQUFDLFFBQUcsV0FBVSxlQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHdGQUNadUIsMEJBQWdCcEMsT0FBTyxLQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLDhDQUNiQSxrQkFBUUssUUFBUUwsUUFBUU8sWUFBWSxXQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQVdnQyxpQkFBaUJ2QyxPQUFPO0FBQUEsdUJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEscUJBSjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FHQSx1QkFBQyxRQUFHLFdBQVUsZUFDWjtBQUFBLHVDQUFDLFNBQUksV0FBVSxrREFBa0RBLGtCQUFRZ0IsaUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVGO0FBQUEsZ0JBQ3ZGLHVCQUFDLFNBQUksV0FBVSw2QkFBNkJoQixrQkFBUWlCLGVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsbUJBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUdBLHVCQUFDLFFBQUcsV0FBVSxlQUNYakIsa0JBQVFvQixpQkFBaUJwQixRQUFRb0Isa0JBQWtCLGVBQ2xELHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxtSkFDWnBCLGtCQUFRb0IsY0FBYzJGLE9BQU8sQ0FBQyxLQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDZDQUE2Qy9HLGtCQUFRb0IsaUJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1GO0FBQUEsbUJBSnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0EsSUFFQSx1QkFBQyxTQUFNLE9BQU0sU0FBUSxNQUFLLE1BQUssMEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FHQSx1QkFBQyxRQUFHLFdBQVUsaUNBQ1o7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRXBCLFFBQVF1QixXQUFXLGNBQ2YsWUFDQXZCLFFBQVF1QixXQUFXLGdCQUNuQixZQUNBdkIsUUFBUXVCLFdBQVcsb0JBQ25CLFVBQ0E7QUFBQSxrQkFFTixNQUFLO0FBQUEsa0JBRUp2QixrQkFBUXVCO0FBQUFBO0FBQUFBLGdCQVpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBR0EsdUJBQUMsUUFBRyxXQUFVLDRDQUNaLGlDQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU1yQyx1QkFBdUJjLE9BQU87QUFBQSxvQkFDN0MsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBO0FBQUEsa0JBTnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU01QyxXQUFXLGVBQWU0QyxRQUFRMkcsZ0JBQWdCM0csUUFBUUMsRUFBRTtBQUFBLG9CQUMzRSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MseUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlFO0FBQUE7QUFBQSxrQkFObkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTTdDLFdBQVcsY0FBYzRDLFFBQVFDLEVBQUU7QUFBQSxvQkFDbEQsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBO0FBQUEsa0JBTnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLGdCQUVDckMsa0JBQWtCSix1QkFDakI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTTtBQUNiOEIsMkNBQXFCVSxPQUFPO0FBQzVCTiwyQ0FBcUJNLFFBQVFFLFFBQVEsRUFBRTtBQUN2Q1YsMENBQW9CLEVBQUU7QUFBQSxvQkFDeEI7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBO0FBQUEsa0JBVi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQTtBQUFBLGdCQUdELENBQUMsYUFBYSxrQkFBa0IsWUFBWSxXQUFXLEVBQUUyRCxTQUFTbkQsUUFBUXVCLE1BQU0sSUFDL0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUI7QUFBQTtBQUFBLGtCQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0EsSUFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNZ0Qsb0JBQW9CdkUsT0FBTztBQUFBLG9CQUMxQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTREO0FBQUE7QUFBQSxrQkFOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBR0R6QyxtQkFDQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNNkIsbUJBQW1CWSxPQUFPO0FBQUEsb0JBQ3pDLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUE7QUFBQSxrQkFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsbUJBckVKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUVBLEtBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUVBO0FBQUE7QUFBQTtBQUFBLFVBMUlLQSxRQUFRQztBQUFBQSxVQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE0SUE7QUFBQSxNQUNELEtBdEpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3SkE7QUFBQSxTQW5LRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0tBLEtBcktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzS0EsS0F2S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdLQTtBQUFBLElBR0NwQixrQkFDQyx1QkFBQyxTQUFJLFdBQVUsdUhBQ2IsaUNBQUMsU0FBSSxXQUFVLHdKQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVHQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxzQ0FDWEUsdUJBQWEsaUJBQWlCLHdCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLGtGQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1ELGtCQUFrQixLQUFLO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQTtBQUFBLFVBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUNuRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPcUIsU0FBU0c7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQ3lGLE1BQU07QUFDZjNGLDhCQUFZLEVBQUUsR0FBR0QsVUFBVUcsTUFBTXlGLEVBQUVhLE9BQU9DLE1BQU0sQ0FBQztBQUNqRCxzQkFBSXJGLFdBQVdsQixLQUFNbUIsZUFBYyxFQUFFLEdBQUdELFlBQVlsQixNQUFNLEdBQUcsQ0FBQztBQUFBLGdCQUNoRTtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixXQUFXLHdGQUNUa0IsV0FBV2xCLE9BQU8sa0NBQWtDLGtCQUFrQjtBQUFBO0FBQUEsY0FUMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUs7QUFBQSxZQUVKa0IsV0FBV2xCLFFBQ1YsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ2tCLHFCQUFXbEIsUUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxlQWpCbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELGlDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9ILFNBQVNLO0FBQUFBLGdCQUNoQixlQUFlLENBQUNvQyxRQUFRO0FBQ3RCLHNCQUFJb0UsUUFBUTtBQUNaLHNCQUFJcEUsUUFBUSxhQUFjb0UsU0FBUTtBQUNsQyxzQkFBSXBFLFFBQVEsY0FBZW9FLFNBQVE7QUFDbkMsc0JBQUlwRSxRQUFRLG1CQUFvQm9FLFNBQVE7QUFDeEMsc0JBQUlwRSxRQUFRLFVBQVdvRSxTQUFRO0FBQy9CLHNCQUFJcEUsUUFBUSxxQkFBc0JvRSxTQUFRO0FBQzFDNUcsOEJBQVksRUFBRSxHQUFHRCxVQUFVSyxRQUFRb0MsS0FBS3JDLFVBQVV5RyxNQUFNLENBQUM7QUFBQSxnQkFDM0Q7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsdUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxtQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLGtCQUFpQixzQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsY0FBVyxPQUFNLGNBQWEsa0NBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlEO0FBQUEsb0JBQ2pELHVCQUFDLGNBQVcsT0FBTSxlQUFjLG1DQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRDtBQUFBLG9CQUNuRCx1QkFBQyxjQUFXLE9BQU0sb0JBQW1CLHdDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLG9CQUM3RCx1QkFBQyxjQUFXLE9BQU0sV0FBVSwrQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsY0FBVyxPQUFNLHNCQUFxQiwwQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSx1QkFObkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBO0FBQUE7QUFBQSxjQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1QkE7QUFBQSxlQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLGFBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrREE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUM1RCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPN0csU0FBU0Q7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzZGLE1BQU07QUFDZjNGLDhCQUFZLEVBQUUsR0FBR0QsVUFBVUQsTUFBTTZGLEVBQUVhLE9BQU9DLE1BQU0sQ0FBQztBQUNqRCxzQkFBSXJGLFdBQVd0QixLQUFNdUIsZUFBYyxFQUFFLEdBQUdELFlBQVl0QixNQUFNLEdBQUcsQ0FBQztBQUFBLGdCQUNoRTtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT21IO0FBQUEsWUFFbEhzQixXQUFXdEIsUUFDVix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDc0IscUJBQVd0QixRQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLGVBZG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCwyQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPQyxTQUFTTTtBQUFBQSxnQkFDaEIsZUFBZSxDQUFDcUcsUUFBUTFHLFlBQVksRUFBRSxHQUFHRCxVQUFVTSxLQUFLcUcsSUFBSSxDQUFDO0FBQUEsZ0JBRTdEO0FBQUEseUNBQUMsaUJBQWMsV0FBVSx1Q0FDdkIsaUNBQUMsZUFBWSxhQUFZLGdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSwyQ0FBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcUM7QUFBQSxvQkFDckMsdUJBQUMsY0FBVyxPQUFNLFVBQVMsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLGNBQVcsT0FBTSxVQUFTLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBLG9CQUNqQyx1QkFBQyxjQUFXLE9BQU0sV0FBVSx1QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUM7QUFBQSxvQkFDbkMsdUJBQUMsY0FBVyxPQUFNLGFBQVkseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQ3ZDLHVCQUFDLGNBQVcsT0FBTSxZQUFXLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBLG9CQUNyQyx1QkFBQyxjQUFXLE9BQU0sVUFBUyxzQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQSx1QkFQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBO0FBQUE7QUFBQSxjQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx5QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU8zRyxTQUFTVTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDa0YsTUFBTTNGLFlBQVksRUFBRSxHQUFHRCxVQUFVVSxNQUFNa0YsRUFBRWEsT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBQ2xFLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS21IO0FBQUEsZUFUckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzREE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUMzQyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8xRyxTQUFTWTtBQUFBQSxnQkFDaEIsZUFBZSxDQUFDK0YsUUFBUXRDLDRCQUE0QnNDLEdBQUc7QUFBQSxnQkFFdkQ7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLHVDQUN2QixpQ0FBQyxlQUFZLGFBQVksc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDRTVKLHFCQUFXeUk7QUFBQUEsb0JBQUksQ0FBQy9ELE1BQ2YsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRTNCLElBQzdCMkIsWUFBRXRCLFFBRFlzQixFQUFFM0IsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUN2Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9FLFNBQVNjO0FBQUFBLGdCQUNoQixlQUFlLENBQUM2RixRQUFRO0FBQ3RCMUcsOEJBQVksRUFBRSxHQUFHRCxVQUFVYyxhQUFhNkYsSUFBSSxDQUFDO0FBQzdDLHNCQUFJdEYsV0FBV1AsWUFBYVEsZUFBYyxFQUFFLEdBQUdELFlBQVlQLGFBQWEsR0FBRyxDQUFDO0FBQUEsZ0JBQzlFO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxpQkFBYyxXQUFXLHNCQUN4Qk8sV0FBV1AsY0FBYyxrQ0FBa0Msa0JBQWtCLElBRTdFLGlDQUFDLGVBQVksYUFBWSwyQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0QsS0FIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFa0Isd0JBQWN3RDtBQUFBQSxvQkFBSSxDQUFDOUQsTUFDbEIsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRXZCLE1BQzdCdUIsWUFBRXZCLFFBRFl1QixFQUFFNUIsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFtQkE7QUFBQSxZQUNDdUIsV0FBV1AsZUFDVix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDTyxxQkFBV1AsZUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxlQXpCMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxhQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRDtBQUFBO0FBQUEsY0FDOUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxpQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPZCxTQUFTZ0IsZ0JBQWdCaEIsU0FBU2lCLGtCQUFrQixlQUFlLGVBQWU7QUFBQSxnQkFDekYsZUFBZSxDQUFDMEYsUUFBUTtBQUN0Qm5DLDhDQUE0Qm1DLEdBQUc7QUFDL0Isc0JBQUl0RixXQUFXd0QsVUFBV3ZELGVBQWMsRUFBRSxHQUFHRCxZQUFZd0QsV0FBVyxHQUFHLENBQUM7QUFBQSxnQkFDMUU7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLGlCQUFjLFdBQVcsc0JBQ3hCeEQsV0FBV3dELFlBQVksa0NBQWtDLGtCQUFrQixJQUUzRSxpQ0FBQyxlQUFZLGFBQVksc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDLEtBSDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDQztBQUFBLDJDQUFDLGNBQVcsT0FBTSxjQUFhLGtEQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLG9CQUNoRTdILFdBQVd3STtBQUFBQSxzQkFBSSxDQUFDOUQsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFNUIsSUFDN0I0QjtBQUFBQSwwQkFBRXZCO0FBQUFBLHdCQUFLO0FBQUEsd0JBQUd1QixFQUFFb0YsWUFBWXJHLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLHdCQUFTO0FBQUEsMkJBRHBDaUIsRUFBRTVCLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBLHVCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQTtBQUFBO0FBQUEsY0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsWUFDQ3VCLFdBQVd3RCxhQUNWLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0N4RCxxQkFBV3dELGFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsZUExQnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCw0QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPN0UsU0FBU2tCO0FBQUFBLGdCQUNoQixlQUFlLENBQUN5RixRQUNkMUcsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIa0IsYUFBYXlGO0FBQUFBLGdCQUNmLENBQUM7QUFBQSxnQkFHSDtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsdUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLFlBQVcsNkJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBDO0FBQUEsb0JBQzFDLHVCQUFDLGNBQVcsT0FBTSxlQUFjLG9DQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RDtBQUFBLG9CQUN4RCx1QkFBQyxjQUFXLE9BQU0sY0FBYSxtQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0Q7QUFBQSxvQkFDdEQsdUJBQUMsY0FBVyxPQUFNLGVBQWMsbUNBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVEO0FBQUEsdUJBSnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQTtBQUFBO0FBQUEsY0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBa0JBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELDhCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8zRyxTQUFTb0I7QUFBQUEsZ0JBQ2hCLGVBQWUsQ0FBQ3VGLFFBQ2QxRyxZQUFZLEVBQUUsR0FBR0QsVUFBVW9CLFFBQVF1RixJQUF5QixDQUFDO0FBQUEsZ0JBRy9EO0FBQUEseUNBQUMsaUJBQWMsV0FBVSx1Q0FDdkIsaUNBQUMsZUFBWSxhQUFZLFlBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDQztBQUFBLDJDQUFDLGNBQVcsT0FBTSxhQUFZLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1QztBQUFBLG9CQUN2Qyx1QkFBQyxjQUFXLE9BQU0sZUFBYywyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsY0FBVyxPQUFNLGFBQVkseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVDO0FBQUEsb0JBQ3ZDLHVCQUFDLGNBQVcsT0FBTSxtQkFBa0IsK0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1EO0FBQUEsb0JBQ25ELHVCQUFDLGNBQVcsT0FBTSxTQUFRLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLHVCQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQTtBQUFBLGNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZ0JBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEVBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCxtREFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxjQUNOLE9BQU8zRyxTQUFTbUI7QUFBQUEsY0FDaEIsVUFBVSxDQUFDeUUsTUFBTTNGLFlBQVksRUFBRSxHQUFHRCxVQUFVbUIsYUFBYXlFLEVBQUVhLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQ3pFLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS21IO0FBQUEsYUFUckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FqUUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtRQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGtHQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTS9ILGtCQUFrQixLQUFLO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBQXVJO0FBQUE7QUFBQSxVQUhuSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTStGLGlCQUFpQixJQUFJO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBQW9KO0FBQUE7QUFBQSxZQUhoSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUEsaUJBQWlCLEtBQUs7QUFBQSxjQUNyQyxXQUFVO0FBQUEsY0FFVDlGLHVCQUFhLG1CQUFtQjtBQUFBO0FBQUEsWUFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQWxURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbVRBLEtBcFRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxVEE7QUFBQSxJQUlERSx1QkFDQyx1QkFBQyxTQUFJLFdBQVUsdUhBQ2IsaUNBQUMsU0FBSSxXQUFVLHdKQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBHQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzRkFDYkEsOEJBQW9Cb0IsUUFBUSxXQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQ3FHLGtCQUFrQnpILG9CQUFvQnNDLE1BQU07QUFBQSxlQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQ1hhLDBCQUFnQm5ELG1CQUFtQixLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxZQUMzQnNELGlCQUFpQnRELG1CQUFtQjtBQUFBLFlBQUU7QUFBQSxZQUFJQSxvQkFBb0JvQyxlQUFlO0FBQUEsZUFEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNbkMsdUJBQXVCLElBQUk7QUFBQSxZQUMxQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0VBQXFFLHlDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsMERBQXlELDRCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLFVBQUssMEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0I7QUFBQSxpQkFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGtCQUFpQixpQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNsQyx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsMERBQXlELDRCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRjtBQUFBLGNBQ3JGLHVCQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxpQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGtCQUFpQixpQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUNsQyx1QkFBQyxTQUFJLFdBQVcsb0NBQW9DRCxvQkFBb0JzQyxXQUFXLGVBQWV0QyxvQkFBb0JzQyxXQUFXLGdCQUFnQiwrQkFBK0IsZ0JBQWdCLElBQzlMO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlDQUNidEMsOEJBQW9Cc0MsV0FBVyxjQUFjLGlCQUFpQixhQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsaUJBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxrQkFBaUIsaUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFDbEMsdUJBQUMsU0FBSSxXQUFXLG9DQUFvQ3RDLG9CQUFvQnNDLFdBQVcsY0FBYywrQkFBK0IsZ0JBQWdCLElBQzlJO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlDQUNidEMsOEJBQW9Cc0MsV0FBVyxjQUFjLGlCQUFpQixnQkFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGlCQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsa0JBQWlCLGlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQ2xDLHVCQUFDLFNBQUksV0FBVyxvQ0FBb0N0QyxvQkFBb0JzQyxXQUFXLGNBQWMsK0JBQStCLGdCQUFnQixJQUM5STtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FDYnRDLDhCQUFvQnNDLFdBQVcsY0FBYyxpQkFBaUIsa0JBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxpQkFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsYUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9DQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0REFBMkQsNkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxpREFDYnRDO0FBQUFBLGtDQUFvQmlCO0FBQUFBLGNBQUs7QUFBQSxjQUFHakIsb0JBQW9Cd0IsT0FBTztBQUFBLGNBQU07QUFBQSxpQkFEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0REFBMkQsMkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxpREFDYnhCO0FBQUFBLGtDQUFvQjRCO0FBQUFBLGNBQUs7QUFBQSxjQUFJNUIsb0JBQW9CNkIsV0FBVztBQUFBLGlCQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDREQUEyRCxtQ0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGlEQUNiN0IsOEJBQW9CK0IsaUJBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9CLDhCQUFvQmdDLGVBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNERBQTJELGtDQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsaURBQ2J1Qiw4QkFBb0J2RCxtQkFBbUIsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxRQUdDQSxvQkFBb0JxQyxlQUNuQix1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUVBQW9FLG1DQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZyQyw4QkFBb0JxQyxlQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxzREFDZDtBQUFBLHVDQUFDLFVBQUssV0FBVSx3REFBdUQseUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFBTztBQUFBLG1CQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSxrRkFBaUYsc0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG1GQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNicEMseUNBQXVCLElBQUk7QUFDM0I5Qiw2QkFBVyxlQUFlNkIsb0JBQW9CMEgsZ0JBQWdCMUgsb0JBQW9CZ0IsRUFBRTtBQUFBLGdCQUN0RjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBc0k7QUFBQTtBQUFBLGNBTGxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxzREFDZDtBQUFBLHVDQUFDLFVBQUssV0FBVSx3REFBdUQsMEJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFBTztBQUFBLG1CQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSwrRUFDYmhCO0FBQUFBLG9DQUFvQmlJLG1CQUFtQjtBQUFBLGdCQUFFO0FBQUEsZ0JBQUVqSSxvQkFBb0JrSSxpQkFBaUI7QUFBQSxnQkFBRztBQUFBLG1CQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwrRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYmpJLHlDQUF1QixJQUFJO0FBQzNCOUIsNkJBQVcsY0FBYzZCLG9CQUFvQmdCLEVBQUU7QUFBQSxnQkFDakQ7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQTBJO0FBQUE7QUFBQSxjQUx0SjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsc0RBQ2Q7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsMERBQXlELDZCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQU87QUFBQSxtQkFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsK0VBQ2JoQjtBQUFBQSxvQ0FBb0JtSSxRQUFRekQsVUFBVTtBQUFBLGdCQUFFO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHdFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiekUseUNBQXVCLElBQUk7QUFDM0I5Qiw2QkFBVyxrQkFBa0I2QixvQkFBb0JnQixFQUFFO0FBQUEsZ0JBQ3JEO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUE4STtBQUFBO0FBQUEsY0FMMUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLGFBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpRkE7QUFBQSxXQWhMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUxBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNZix1QkFBdUIsSUFBSTtBQUFBLFlBQzFDLFdBQVU7QUFBQSxZQUFxSTtBQUFBO0FBQUEsVUFGako7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWkQ7QUFBQUEsOEJBQW9Cc0MsV0FBVyxlQUM5QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JqRSxnQ0FBZ0IyQixvQkFBb0JnQixJQUFJLEVBQUVzQixRQUFRLFlBQVksQ0FBQztBQUMvRHJDLHVDQUF1QixDQUFDd0YsU0FBVUEsT0FBTyxFQUFFLEdBQUdBLE1BQU1uRCxRQUFRLFlBQVksSUFBSSxJQUFLO0FBQUEsY0FDbkY7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUEwSTtBQUFBO0FBQUEsWUFMdEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUdEdEMsb0JBQW9Cc0MsV0FBVyxlQUM5QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2Isc0JBQU1jLElBQUlwRDtBQUNWQyx1Q0FBdUIsSUFBSTtBQUMzQnFGLG9DQUFvQmxDLENBQUM7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQXNJO0FBQUE7QUFBQSxZQU5sSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxXQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0FqUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtQQSxLQW5QRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb1BBO0FBQUEsSUFJRGxELG1CQUNDLHVCQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0ZBQ2IsaUNBQUMsVUFBSyxXQUFVLHlDQUF3Qyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRSxLQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsc0NBQXFDLHVDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsVUFDRmlELGdCQUFnQmpELGVBQWU7QUFBQSxVQUFFO0FBQUEsYUFEMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLG1CQUFtQixJQUFJO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBQXlHO0FBQUE7QUFBQSxVQUZySDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiLGtCQUFJN0IsZ0JBQWlCQSxpQkFBZ0I0QixnQkFBZ0JjLEVBQUU7QUFDdkRiLGlDQUFtQixJQUFJO0FBQUEsWUFDekI7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUFpRztBQUFBO0FBQUEsVUFMN0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkJBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxJQUlEQyxxQkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2IsaUNBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsbUNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxVQUNEK0MsZ0JBQWdCL0MsaUJBQWlCO0FBQUEsVUFBRTtBQUFBLGFBRDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbURBQWtELDRCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsT0FBT0Esa0JBQWtCYTtBQUFBQSxjQUN6QixXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlvRztBQUFBLGFBTnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0Qsd0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9UO0FBQUFBLGNBQ1AsVUFBVSxDQUFDc0csTUFBTXJHLHFCQUFxQnFHLEVBQUVhLE9BQU9DLEtBQUs7QUFBQSxjQUNwRCxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUltSDtBQUFBLGFBTnJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsaUNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxjQUNOLE9BQU90SDtBQUFBQSxjQUNQLFVBQVUsQ0FBQ3dHLE1BQU12RyxvQkFBb0J1RyxFQUFFYSxPQUFPQyxLQUFLO0FBQUEsY0FDbkQsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLbUg7QUFBQSxhQVBySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNdkgscUJBQXFCLElBQUk7QUFBQSxZQUN4QyxXQUFVO0FBQUEsWUFBd0g7QUFBQTtBQUFBLFVBSHBJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxZQUFZO0FBQ25CLGtCQUFJOUIsdUJBQXVCaUMscUJBQXFCRixrQkFBa0I7QUFDaEUsc0JBQU0vQjtBQUFBQSxrQkFDSjZCLGtCQUFrQlk7QUFBQUEsa0JBQ2xCWixrQkFBa0JhLFFBQVE7QUFBQSxrQkFDMUJUO0FBQUFBLGtCQUNBRjtBQUFBQSxnQkFDRjtBQUNBRCxxQ0FBcUIsSUFBSTtBQUFBLGNBQzNCLE9BQU87QUFDTGtHLHNCQUFNLHlDQUF5QztBQUFBLGNBQ2pEO0FBQUEsWUFDRjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQWtIO0FBQUE7QUFBQSxVQWY5SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrQkE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsU0FuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9FQSxLQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsT0F0bUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3bUNBO0FBRUo7QUFBRTdILEdBdmpEV1gsY0FBeUM7QUFBQSxLQUF6Q0E7QUFBeUMsSUFBQXFLO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsIkJhZGdlIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJTZWFyY2giLCJYIiwiQ2FsZW5kYXIiLCJMb2NrIiwiVHJhc2gyIiwiU2Vzc2lvbnNWaWV3Iiwic2Vzc2lvbnMiLCJwYW5jaGF5YXRzIiwidm9sdW50ZWVycyIsIm9uTmF2aWdhdGUiLCJvbkFkZFNlc3Npb24iLCJvblVwZGF0ZVNlc3Npb24iLCJvbkRlbGV0ZVNlc3Npb24iLCJvblJlcXVlc3REYXRlQ2hhbmdlIiwiY2FuTWFuYWdlU2NoZWR1bGUiLCJ1c2VyUm9sZSIsIl9zIiwiaXNDbHVzdGVyQWRtaW4iLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNlbGVjdGVkUGFuY2hheWF0Iiwic2V0U2VsZWN0ZWRQYW5jaGF5YXQiLCJzZWxlY3RlZFZpbGxhZ2UiLCJzZXRTZWxlY3RlZFZpbGxhZ2UiLCJzZWxlY3RlZFN0YXR1cyIsInNldFNlbGVjdGVkU3RhdHVzIiwic2VsZWN0ZWRNb2R1bGUiLCJzZXRTZWxlY3RlZE1vZHVsZSIsInNlbGVjdGVkVm9sdW50ZWVyIiwic2V0U2VsZWN0ZWRWb2x1bnRlZXIiLCJmaWx0ZXJEYXRlIiwic2V0RmlsdGVyRGF0ZSIsInNob3dNb3JlRmlsdGVycyIsInNldFNob3dNb3JlRmlsdGVycyIsImlzTmV3TW9kYWxPcGVuIiwic2V0SXNOZXdNb2RhbE9wZW4iLCJpc0VkaXRNb2RlIiwic2V0SXNFZGl0TW9kZSIsImFjdGl2ZVNlc3Npb25EZXRhaWwiLCJzZXRBY3RpdmVTZXNzaW9uRGV0YWlsIiwic2Vzc2lvblRvRGVsZXRlIiwic2V0U2Vzc2lvblRvRGVsZXRlIiwiZGF0ZUNoYW5nZVNlc3Npb24iLCJzZXREYXRlQ2hhbmdlU2Vzc2lvbiIsImRhdGVDaGFuZ2VSZWFzb24iLCJzZXREYXRlQ2hhbmdlUmVhc29uIiwiZGF0ZUNoYW5nZU5ld0RhdGUiLCJzZXREYXRlQ2hhbmdlTmV3RGF0ZSIsImRhdGVEcmFmdHMiLCJzZXREYXRlRHJhZnRzIiwiY3VycmVudCIsIm5leHQiLCJmb3JFYWNoIiwic2Vzc2lvbiIsImlkIiwiZGF0ZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJjb2RlIiwibmFtZSIsIm1vZHVsZUlkIiwibW9kdWxlIiwiZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJ0aW1lIiwiZW5kVGltZSIsInBhbmNoYXlhdElkIiwicGFuY2hheWF0TmFtZSIsInZpbGxhZ2VOYW1lIiwidmlsbGFnZXMiLCJ2b2x1bnRlZXJJZCIsInZvbHVudGVlck5hbWUiLCJzZXNzaW9uVHlwZSIsImRlc2NyaXB0aW9uIiwic3RhdHVzIiwiZm9ybUVycm9ycyIsInNldEZvcm1FcnJvcnMiLCJjdXJyZW50RmlsdGVyVmlsbGFnZXMiLCJhbGxWaWxsYWdlcyIsInAiLCJ2Iiwic29tZSIsImV4aXN0aW5nIiwicHVzaCIsImZvdW5kIiwiZmluZCIsIm1vZGFsVmlsbGFnZXMiLCJnZXRTZXNzaW9uVGl0bGUiLCJzIiwidGl0bGUiLCJnZXRTZXNzaW9uTW9kdWxlIiwiZ2V0U2Vzc2lvblZvbHVudGVlciIsImZpbHRlcmVkU2Vzc2lvbnMiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsIm1vZCIsInZpbGwiLCJ2b2wiLCJwYW4iLCJzZWFyY2giLCJ0cmltIiwibWF0Y2hTZWFyY2giLCJpbmNsdWRlcyIsIm1hdGNoUGFuY2hheWF0IiwibWF0Y2hWaWxsYWdlIiwibWF0Y2hTdGF0dXMiLCJtYXRjaE1vZHVsZSIsIm1hdGNoVm9sdW50ZWVyIiwibWF0Y2hEYXRlIiwidXBjb21pbmdDb3VudCIsImxlbmd0aCIsInNjaGVkdWxlZENvdW50IiwiY29tcGxldGVkQ291bnQiLCJuZWVkc0F0dGVudGlvbkNvdW50IiwibmV4dFNlc3Npb24iLCJzY2hlZHVsZWQiLCJoYW5kbGVDbGVhckZpbHRlcnMiLCJoYW5kbGVPcGVuTmV3TW9kYWwiLCJkZWZhdWx0UCIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsImhhbmRsZU9wZW5FZGl0TW9kYWwiLCJoYW5kbGVQYW5jaGF5YXRTZWxlY3RDaGFuZ2UiLCJwSWQiLCJwcmV2IiwiaGFuZGxlVm9sdW50ZWVyU2VsZWN0Q2hhbmdlIiwidklkIiwiaGFuZGxlRm9ybVN1Ym1pdCIsImFzRHJhZnQiLCJlcnJvcnMiLCJ2b2x1bnRlZXIiLCJPYmplY3QiLCJrZXlzIiwiZmluYWxTdGF0dXMiLCJuZXdTZXNzaW9uIiwic3BvYyIsImZpbmFuY2VyIiwiaGFuZGxlRXhwb3J0Q1NWIiwiYWxlcnQiLCJoZWFkZXJzIiwicm93cyIsIm1hcCIsInJlcGxhY2UiLCJjc3ZDb250ZW50Iiwiam9pbiIsImUiLCJlbmNvZGVkVXJpIiwiZW5jb2RlVVJJIiwibGluayIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsInNldEF0dHJpYnV0ZSIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImNsaWNrIiwicmVtb3ZlQ2hpbGQiLCJyZW5kZXJTdGF0dXNCYWRnZSIsImxlc3NvblBsYW5JZCIsInRhcmdldCIsInZhbHVlIiwidmFsIiwiY2hhckF0IiwibW9kSWQiLCJkZXBhcnRtZW50IiwiYXR0ZW5kYW5jZUNvdW50IiwidG90YWxTdHVkZW50cyIsInBob3RvcyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlc3Npb25zVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFRhYlR5cGUsIFNlc3Npb24sIFBhbmNoYXlhdCwgVm9sdW50ZWVyIH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJy4vdWkvYmFkZ2UnO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBTZWxlY3RDb250ZW50LFxyXG4gIFNlbGVjdEl0ZW0sXHJcbiAgU2VsZWN0VHJpZ2dlcixcclxuICBTZWxlY3RWYWx1ZSxcclxufSBmcm9tICcuL3VpL3NlbGVjdCc7XHJcbmltcG9ydCB7IEFjdGlvbkJ1dHRvbiB9IGZyb20gJy4vdWkvYWN0aW9uLWJ1dHRvbic7XHJcbmltcG9ydCB7IFNlYXJjaCwgWCwgQ2FsZW5kYXIsIExvY2ssIFRyYXNoMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcblxyXG5pbnRlcmZhY2UgU2Vzc2lvbnNWaWV3UHJvcHMge1xyXG4gIHNlc3Npb25zOiBTZXNzaW9uW107XHJcbiAgcGFuY2hheWF0czogUGFuY2hheWF0W107XHJcbiAgdm9sdW50ZWVyczogVm9sdW50ZWVyW107XHJcbiAgb25OYXZpZ2F0ZTogKHRhYjogVGFiVHlwZSwgdGFyZ2V0SWQ/OiBzdHJpbmcsIHNlY29uZGFyeVBhcmFtPzogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIG9uQWRkU2Vzc2lvbjogKG5ld1Nlc3Npb246IE9taXQ8U2Vzc2lvbiwgJ2lkJz4pID0+IHZvaWQ7XHJcbiAgb25VcGRhdGVTZXNzaW9uOiAoaWQ6IHN0cmluZywgdXBkYXRlZDogUGFydGlhbDxTZXNzaW9uPikgPT4gdm9pZDtcclxuICBvbkRlbGV0ZVNlc3Npb24/OiAoaWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWQ7XHJcbiAgb25SZXF1ZXN0RGF0ZUNoYW5nZT86IChzZXNzaW9uSWQ6IHN0cmluZywgb3JpZ2luYWxEYXRlOiBzdHJpbmcsIG5ld0RhdGU6IHN0cmluZywgcmVhc29uOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XHJcbiAgY2FuTWFuYWdlU2NoZWR1bGU/OiBib29sZWFuO1xyXG4gIHVzZXJSb2xlPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgU2Vzc2lvbnNWaWV3OiBSZWFjdC5GQzxTZXNzaW9uc1ZpZXdQcm9wcz4gPSAoe1xyXG4gIHNlc3Npb25zID0gW10sXHJcbiAgcGFuY2hheWF0cyA9IFtdLFxyXG4gIHZvbHVudGVlcnMgPSBbXSxcclxuICBvbk5hdmlnYXRlLFxyXG4gIG9uQWRkU2Vzc2lvbixcclxuICBvblVwZGF0ZVNlc3Npb24sXHJcbiAgb25EZWxldGVTZXNzaW9uLFxyXG4gIG9uUmVxdWVzdERhdGVDaGFuZ2UsXHJcbiAgY2FuTWFuYWdlU2NoZWR1bGUgPSBmYWxzZSxcclxuICB1c2VyUm9sZSA9ICdTdXBlciBBZG1pbicsXHJcbn0pID0+IHtcclxuICBjb25zdCBpc0NsdXN0ZXJBZG1pbiA9IHVzZXJSb2xlID09PSAnQ2x1c3RlciBBZG1pbic7XHJcbiAgLy8gU2VhcmNoICYgRmlsdGVyIFN0YXRlXHJcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBhbmNoYXlhdCwgc2V0U2VsZWN0ZWRQYW5jaGF5YXRdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFZpbGxhZ2UsIHNldFNlbGVjdGVkVmlsbGFnZV0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RhdHVzLCBzZXRTZWxlY3RlZFN0YXR1c10gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTW9kdWxlLCBzZXRTZWxlY3RlZE1vZHVsZV0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVm9sdW50ZWVyLCBzZXRTZWxlY3RlZFZvbHVudGVlcl0gPSB1c2VTdGF0ZSgnYWxsJyk7XHJcbiAgY29uc3QgW2ZpbHRlckRhdGUsIHNldEZpbHRlckRhdGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzaG93TW9yZUZpbHRlcnMsIHNldFNob3dNb3JlRmlsdGVyc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIE1vZGFscyAvIERyYXdlcnNcclxuICBjb25zdCBbaXNOZXdNb2RhbE9wZW4sIHNldElzTmV3TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNFZGl0TW9kZSwgc2V0SXNFZGl0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVNlc3Npb25EZXRhaWwsIHNldEFjdGl2ZVNlc3Npb25EZXRhaWxdID0gdXNlU3RhdGU8U2Vzc2lvbiB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtzZXNzaW9uVG9EZWxldGUsIHNldFNlc3Npb25Ub0RlbGV0ZV0gPSB1c2VTdGF0ZTxTZXNzaW9uIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2RhdGVDaGFuZ2VTZXNzaW9uLCBzZXREYXRlQ2hhbmdlU2Vzc2lvbl0gPSB1c2VTdGF0ZTxTZXNzaW9uIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2RhdGVDaGFuZ2VSZWFzb24sIHNldERhdGVDaGFuZ2VSZWFzb25dID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtkYXRlQ2hhbmdlTmV3RGF0ZSwgc2V0RGF0ZUNoYW5nZU5ld0RhdGVdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtkYXRlRHJhZnRzLCBzZXREYXRlRHJhZnRzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldERhdGVEcmFmdHMoKGN1cnJlbnQpID0+IHtcclxuICAgICAgY29uc3QgbmV4dCA9IHsgLi4uY3VycmVudCB9O1xyXG4gICAgICBzZXNzaW9ucy5mb3JFYWNoKChzZXNzaW9uKSA9PiB7XHJcbiAgICAgICAgaWYgKCEoc2Vzc2lvbi5pZCBpbiBuZXh0KSkgbmV4dFtzZXNzaW9uLmlkXSA9IHNlc3Npb24uZGF0ZSB8fCAnJztcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiBuZXh0O1xyXG4gICAgfSk7XHJcbiAgfSwgW3Nlc3Npb25zXSk7XHJcblxyXG4gIC8vIEZvcm0gU3RhdGUgZm9yIENyZWF0ZSAvIEVkaXQgU2Vzc2lvblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgaWQ6ICcnLFxyXG4gICAgY29kZTogJycsXHJcbiAgICBuYW1lOiAnJyxcclxuICAgIG1vZHVsZUlkOiAnTS0xMDMnLFxyXG4gICAgbW9kdWxlOiAnU3Bva2VuIEVuZ2xpc2gnLFxyXG4gICAgZGF5OiAnU2F0dXJkYXknLFxyXG4gICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXHJcbiAgICB0aW1lOiAnMTA6MDAgQU0nLFxyXG4gICAgZW5kVGltZTogJzExOjMwIEFNJyxcclxuICAgIHBhbmNoYXlhdElkOiBwYW5jaGF5YXRzWzBdPy5pZCB8fCAndmVkYWtrYXR0YW1hZHV2dScsXHJcbiAgICBwYW5jaGF5YXROYW1lOiBwYW5jaGF5YXRzWzBdPy5uYW1lIHx8ICdWZWRha2thdHRhbWFkdXZ1JyxcclxuICAgIHZpbGxhZ2VOYW1lOiBwYW5jaGF5YXRzWzBdPy52aWxsYWdlc1swXT8ubmFtZSB8fCAnQW1tYXBldHRhaScsXHJcbiAgICB2b2x1bnRlZXJJZDogdm9sdW50ZWVyc1swXT8uaWQgfHwgJ3ZvbC0xJyxcclxuICAgIHZvbHVudGVlck5hbWU6IHZvbHVudGVlcnNbMF0/Lm5hbWUgfHwgJ0JhbGEnLFxyXG4gICAgc2Vzc2lvblR5cGU6ICdBY2FkZW1pYycgYXMgJ0FjYWRlbWljJyB8ICdMaWZlIFNraWxscycgfCAnQXNzZXNzbWVudCcgfCAnT3JpZW50YXRpb24nLFxyXG4gICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgc3RhdHVzOiAnU2NoZWR1bGVkJyBhcyBTZXNzaW9uWydzdGF0dXMnXSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2Zvcm1FcnJvcnMsIHNldEZvcm1FcnJvcnNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgc3RyaW5nPj4oe30pO1xyXG5cclxuICAvLyBEeW5hbWljIGxpc3Qgb2YgdmlsbGFnZXMgYmFzZWQgb24gc2VsZWN0ZWQgcGFuY2hheWF0IGluIGZpbHRlclxyXG4gIGNvbnN0IGN1cnJlbnRGaWx0ZXJWaWxsYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkUGFuY2hheWF0ID09PSAnYWxsJykge1xyXG4gICAgICBjb25zdCBhbGxWaWxsYWdlczogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfVtdID0gW107XHJcbiAgICAgIHBhbmNoYXlhdHMuZm9yRWFjaCgocCkgPT4ge1xyXG4gICAgICAgIHAudmlsbGFnZXM/LmZvckVhY2goKHYpID0+IHtcclxuICAgICAgICAgIGlmICghYWxsVmlsbGFnZXMuc29tZSgoZXhpc3RpbmcpID0+IGV4aXN0aW5nLm5hbWUgPT09IHYubmFtZSkpIHtcclxuICAgICAgICAgICAgYWxsVmlsbGFnZXMucHVzaCh7IGlkOiB2LmlkLCBuYW1lOiB2Lm5hbWUgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gYWxsVmlsbGFnZXM7XHJcbiAgICB9XHJcbiAgICBjb25zdCBmb3VuZCA9IHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXQpO1xyXG4gICAgcmV0dXJuIGZvdW5kPy52aWxsYWdlcyB8fCBbXTtcclxuICB9LCBbc2VsZWN0ZWRQYW5jaGF5YXQsIHBhbmNoYXlhdHNdKTtcclxuXHJcbiAgLy8gRHluYW1pYyBsaXN0IG9mIHZpbGxhZ2VzIGJhc2VkIG9uIHNlbGVjdGVkIHBhbmNoYXlhdCBpbiBtb2RhbCBmb3JtXHJcbiAgY29uc3QgbW9kYWxWaWxsYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZm91bmQgPSBwYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IGZvcm1EYXRhLnBhbmNoYXlhdElkKTtcclxuICAgIHJldHVybiBmb3VuZD8udmlsbGFnZXMgfHwgW107XHJcbiAgfSwgW2Zvcm1EYXRhLnBhbmNoYXlhdElkLCBwYW5jaGF5YXRzXSk7XHJcblxyXG4gIC8vIEhlbHBlciB0ZXh0IGV4dHJhY3RvcnNcclxuICBjb25zdCBnZXRTZXNzaW9uVGl0bGUgPSAocz86IFNlc3Npb24pOiBzdHJpbmcgPT4ge1xyXG4gICAgaWYgKCFzKSByZXR1cm4gJ1VudGl0bGVkIFNlc3Npb24nO1xyXG4gICAgcmV0dXJuIHMubmFtZSB8fCBzLnRpdGxlIHx8IHMuY29kZSB8fCAnVW50aXRsZWQgU2Vzc2lvbic7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0U2Vzc2lvbk1vZHVsZSA9IChzPzogU2Vzc2lvbik6IHN0cmluZyA9PiB7XHJcbiAgICBpZiAoIXMpIHJldHVybiAnR2VuZXJhbCc7XHJcbiAgICByZXR1cm4gcy5tb2R1bGUgfHwgcy5tb2R1bGVJZCB8fCAnR2VuZXJhbCBNb2R1bGUnO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFNlc3Npb25Wb2x1bnRlZXIgPSAocz86IFNlc3Npb24pOiBzdHJpbmcgPT4ge1xyXG4gICAgaWYgKCFzIHx8ICFzLnZvbHVudGVlck5hbWUgfHwgcy52b2x1bnRlZXJOYW1lID09PSAnVW5hc3NpZ25lZCcpIHJldHVybiAnVW5hc3NpZ25lZCc7XHJcbiAgICByZXR1cm4gcy52b2x1bnRlZXJOYW1lO1xyXG4gIH07XHJcblxyXG4gIC8vIEZpbHRlcmVkIFNlc3Npb25zXHJcbiAgY29uc3QgZmlsdGVyZWRTZXNzaW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHNlc3Npb25zLmZpbHRlcigocykgPT4ge1xyXG4gICAgICBjb25zdCB0aXRsZSA9IGdldFNlc3Npb25UaXRsZShzKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBtb2QgPSBnZXRTZXNzaW9uTW9kdWxlKHMpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IHZpbGwgPSAocy52aWxsYWdlTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3Qgdm9sID0gKHMudm9sdW50ZWVyTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3QgcGFuID0gKHMucGFuY2hheWF0TmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3Qgc2VhcmNoID0gc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoU2VhcmNoID1cclxuICAgICAgICAhc2VhcmNoIHx8XHJcbiAgICAgICAgdGl0bGUuaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIG1vZC5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgdmlsbC5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgdm9sLmluY2x1ZGVzKHNlYXJjaCkgfHxcclxuICAgICAgICBwYW4uaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIChzLmNvZGUgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoUGFuY2hheWF0ID1cclxuICAgICAgICBzZWxlY3RlZFBhbmNoYXlhdCA9PT0gJ2FsbCcgfHwgcy5wYW5jaGF5YXRJZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXQ7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaFZpbGxhZ2UgPVxyXG4gICAgICAgIHNlbGVjdGVkVmlsbGFnZSA9PT0gJ2FsbCcgfHxcclxuICAgICAgICAocy52aWxsYWdlTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRWaWxsYWdlLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICBjb25zdCBtYXRjaFN0YXR1cyA9XHJcbiAgICAgICAgc2VsZWN0ZWRTdGF0dXMgPT09ICdhbGwnIHx8XHJcbiAgICAgICAgcy5zdGF0dXMudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRTdGF0dXMudG9Mb3dlckNhc2UoKSB8fFxyXG4gICAgICAgIChzZWxlY3RlZFN0YXR1cyA9PT0gJ05lZWRzIEF0dGVudGlvbicgJiYgKHMuc3RhdHVzID09PSAnTmVlZHMgQXR0ZW50aW9uJyB8fCBzLnN0YXR1cyA9PT0gJ0FjdGlvbiBSZXEuJykpO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hNb2R1bGUgPVxyXG4gICAgICAgIHNlbGVjdGVkTW9kdWxlID09PSAnYWxsJyB8fFxyXG4gICAgICAgIG1vZC5pbmNsdWRlcyhzZWxlY3RlZE1vZHVsZS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgIHMubW9kdWxlSWQgPT09IHNlbGVjdGVkTW9kdWxlO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hWb2x1bnRlZXIgPVxyXG4gICAgICAgIHNlbGVjdGVkVm9sdW50ZWVyID09PSAnYWxsJyB8fFxyXG4gICAgICAgIHMudm9sdW50ZWVySWQgPT09IHNlbGVjdGVkVm9sdW50ZWVyIHx8XHJcbiAgICAgICAgKHMudm9sdW50ZWVyTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRWb2x1bnRlZXIudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoRGF0ZSA9ICFmaWx0ZXJEYXRlIHx8IHMuZGF0ZSA9PT0gZmlsdGVyRGF0ZTtcclxuXHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgbWF0Y2hTZWFyY2ggJiZcclxuICAgICAgICBtYXRjaFBhbmNoYXlhdCAmJlxyXG4gICAgICAgIG1hdGNoVmlsbGFnZSAmJlxyXG4gICAgICAgIG1hdGNoU3RhdHVzICYmXHJcbiAgICAgICAgbWF0Y2hNb2R1bGUgJiZcclxuICAgICAgICBtYXRjaFZvbHVudGVlciAmJlxyXG4gICAgICAgIG1hdGNoRGF0ZVxyXG4gICAgICApO1xyXG4gICAgfSk7XHJcbiAgfSwgW1xyXG4gICAgc2Vzc2lvbnMsXHJcbiAgICBzZWFyY2hUZXJtLFxyXG4gICAgc2VsZWN0ZWRQYW5jaGF5YXQsXHJcbiAgICBzZWxlY3RlZFZpbGxhZ2UsXHJcbiAgICBzZWxlY3RlZFN0YXR1cyxcclxuICAgIHNlbGVjdGVkTW9kdWxlLFxyXG4gICAgc2VsZWN0ZWRWb2x1bnRlZXIsXHJcbiAgICBmaWx0ZXJEYXRlLFxyXG4gIF0pO1xyXG5cclxuICAvLyBRdWljayBTdW1tYXJ5IENvdW50c1xyXG4gIGNvbnN0IHVwY29taW5nQ291bnQgPSBzZXNzaW9ucy5maWx0ZXIoXHJcbiAgICAocykgPT4gcy5zdGF0dXMgPT09ICdTY2hlZHVsZWQnIHx8IHMuc3RhdHVzID09PSAnSW4gUHJvZ3Jlc3MnXHJcbiAgKS5sZW5ndGg7XHJcbiAgY29uc3Qgc2NoZWR1bGVkQ291bnQgPSBzZXNzaW9ucy5maWx0ZXIoKHMpID0+IHMuc3RhdHVzID09PSAnU2NoZWR1bGVkJykubGVuZ3RoO1xyXG4gIGNvbnN0IGNvbXBsZXRlZENvdW50ID0gc2Vzc2lvbnMuZmlsdGVyKChzKSA9PiBzLnN0YXR1cyA9PT0gJ0NvbXBsZXRlZCcpLmxlbmd0aDtcclxuICBjb25zdCBuZWVkc0F0dGVudGlvbkNvdW50ID0gc2Vzc2lvbnMuZmlsdGVyKFxyXG4gICAgKHMpID0+IHMuc3RhdHVzID09PSAnTmVlZHMgQXR0ZW50aW9uJyB8fCBzLnN0YXR1cyA9PT0gJ0FjdGlvbiBSZXEuJyB8fCBzLnZvbHVudGVlck5hbWUgPT09ICdVbmFzc2lnbmVkJ1xyXG4gICkubGVuZ3RoO1xyXG5cclxuICAvLyBOZXh0IFNlc3Npb24gc3BvdGxpZ2h0IGl0ZW1cclxuICBjb25zdCBuZXh0U2Vzc2lvbiA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3Qgc2NoZWR1bGVkID0gc2Vzc2lvbnMuZmlsdGVyKChzKSA9PiBzLnN0YXR1cyA9PT0gJ1NjaGVkdWxlZCcpO1xyXG4gICAgaWYgKHNjaGVkdWxlZC5sZW5ndGggPiAwKSByZXR1cm4gc2NoZWR1bGVkWzBdO1xyXG4gICAgcmV0dXJuIHNlc3Npb25zWzBdIHx8IG51bGw7XHJcbiAgfSwgW3Nlc3Npb25zXSk7XHJcblxyXG4gIC8vIENsZWFyIGFsbCBmaWx0ZXJzXHJcbiAgY29uc3QgaGFuZGxlQ2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGVybSgnJyk7XHJcbiAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdCgnYWxsJyk7XHJcbiAgICBzZXRTZWxlY3RlZFZpbGxhZ2UoJ2FsbCcpO1xyXG4gICAgc2V0U2VsZWN0ZWRTdGF0dXMoJ2FsbCcpO1xyXG4gICAgc2V0U2VsZWN0ZWRNb2R1bGUoJ2FsbCcpO1xyXG4gICAgc2V0U2VsZWN0ZWRWb2x1bnRlZXIoJ2FsbCcpO1xyXG4gICAgc2V0RmlsdGVyRGF0ZSgnJyk7XHJcbiAgfTtcclxuXHJcbiAgLy8gT3BlbiBDcmVhdGUgTW9kYWxcclxuICBjb25zdCBoYW5kbGVPcGVuTmV3TW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0VkaXRNb2RlKGZhbHNlKTtcclxuICAgIHNldEZvcm1FcnJvcnMoe30pO1xyXG4gICAgY29uc3QgZGVmYXVsdFAgPSBwYW5jaGF5YXRzWzBdO1xyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBpZDogJycsXHJcbiAgICAgIGNvZGU6IGBNLSR7TWF0aC5mbG9vcigxMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwKX1gLFxyXG4gICAgICBuYW1lOiAnJyxcclxuICAgICAgbW9kdWxlSWQ6ICdNLTEwMycsXHJcbiAgICAgIG1vZHVsZTogJ1Nwb2tlbiBFbmdsaXNoJyxcclxuICAgICAgZGF5OiAnU2F0dXJkYXknLFxyXG4gICAgICBkYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcclxuICAgICAgdGltZTogJzEwOjAwIEFNJyxcclxuICAgICAgZW5kVGltZTogJzExOjMwIEFNJyxcclxuICAgICAgcGFuY2hheWF0SWQ6IGRlZmF1bHRQPy5pZCB8fCAndmVkYWtrYXR0YW1hZHV2dScsXHJcbiAgICAgIHBhbmNoYXlhdE5hbWU6IGRlZmF1bHRQPy5uYW1lIHx8ICdWZWRha2thdHRhbWFkdXZ1JyxcclxuICAgICAgdmlsbGFnZU5hbWU6IGRlZmF1bHRQPy52aWxsYWdlc1swXT8ubmFtZSB8fCAnQW1tYXBldHRhaScsXHJcbiAgICAgIHZvbHVudGVlcklkOiB2b2x1bnRlZXJzWzBdPy5pZCB8fCAndm9sLTEnLFxyXG4gICAgICB2b2x1bnRlZXJOYW1lOiB2b2x1bnRlZXJzWzBdPy5uYW1lIHx8ICdCYWxhJyxcclxuICAgICAgc2Vzc2lvblR5cGU6ICdBY2FkZW1pYycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgc3RhdHVzOiAnU2NoZWR1bGVkJyxcclxuICAgIH0pO1xyXG4gICAgc2V0SXNOZXdNb2RhbE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gT3BlbiBFZGl0IE1vZGFsXHJcbiAgY29uc3QgaGFuZGxlT3BlbkVkaXRNb2RhbCA9IChzZXNzaW9uOiBTZXNzaW9uKSA9PiB7XHJcbiAgICBzZXRJc0VkaXRNb2RlKHRydWUpO1xyXG4gICAgc2V0Rm9ybUVycm9ycyh7fSk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIGlkOiBzZXNzaW9uLmlkLFxyXG4gICAgICBjb2RlOiBzZXNzaW9uLmNvZGUgfHwgYE0tMTAzYCxcclxuICAgICAgbmFtZTogc2Vzc2lvbi5uYW1lIHx8IHNlc3Npb24udGl0bGUgfHwgJycsXHJcbiAgICAgIG1vZHVsZUlkOiBzZXNzaW9uLm1vZHVsZUlkIHx8ICdNLTEwMycsXHJcbiAgICAgIG1vZHVsZTogc2Vzc2lvbi5tb2R1bGUgfHwgJ1Nwb2tlbiBFbmdsaXNoJyxcclxuICAgICAgZGF5OiBzZXNzaW9uLmRheSB8fCAnU2F0dXJkYXknLFxyXG4gICAgICBkYXRlOiBzZXNzaW9uLmRhdGUgfHwgJycsXHJcbiAgICAgIHRpbWU6IHNlc3Npb24udGltZSB8fCAnMTA6MDAgQU0nLFxyXG4gICAgICBlbmRUaW1lOiBzZXNzaW9uLmVuZFRpbWUgfHwgJzExOjMwIEFNJyxcclxuICAgICAgcGFuY2hheWF0SWQ6IHNlc3Npb24ucGFuY2hheWF0SWQgfHwgKHBhbmNoYXlhdHNbMF0/LmlkIHx8ICcnKSxcclxuICAgICAgcGFuY2hheWF0TmFtZTogc2Vzc2lvbi5wYW5jaGF5YXROYW1lIHx8IChwYW5jaGF5YXRzWzBdPy5uYW1lIHx8ICcnKSxcclxuICAgICAgdmlsbGFnZU5hbWU6IHNlc3Npb24udmlsbGFnZU5hbWUgfHwgJycsXHJcbiAgICAgIHZvbHVudGVlcklkOiBzZXNzaW9uLnZvbHVudGVlcklkIHx8ICcnLFxyXG4gICAgICB2b2x1bnRlZXJOYW1lOiBzZXNzaW9uLnZvbHVudGVlck5hbWUgfHwgJ1VuYXNzaWduZWQnLFxyXG4gICAgICBzZXNzaW9uVHlwZTogc2Vzc2lvbi5zZXNzaW9uVHlwZSB8fCAnQWNhZGVtaWMnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogc2Vzc2lvbi5kZXNjcmlwdGlvbiB8fCAnJyxcclxuICAgICAgc3RhdHVzOiBzZXNzaW9uLnN0YXR1cyB8fCAnU2NoZWR1bGVkJyxcclxuICAgIH0pO1xyXG4gICAgc2V0SXNOZXdNb2RhbE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIEZvcm0gQ2hhbmdlXHJcbiAgY29uc3QgaGFuZGxlUGFuY2hheWF0U2VsZWN0Q2hhbmdlID0gKHBJZDogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBmb3VuZCA9IHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gcElkKTtcclxuICAgIGlmIChmb3VuZCkge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHBhbmNoYXlhdElkOiBmb3VuZC5pZCxcclxuICAgICAgICBwYW5jaGF5YXROYW1lOiBmb3VuZC5uYW1lLFxyXG4gICAgICAgIHZpbGxhZ2VOYW1lOiBmb3VuZC52aWxsYWdlc1swXT8ubmFtZSB8fCAnTWFpbiBDZW50ZXInLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVm9sdW50ZWVyU2VsZWN0Q2hhbmdlID0gKHZJZDogc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAodklkID09PSAndW5hc3NpZ25lZCcpIHtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB2b2x1bnRlZXJJZDogJycsXHJcbiAgICAgICAgdm9sdW50ZWVyTmFtZTogJ1VuYXNzaWduZWQnLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGZvdW5kID0gdm9sdW50ZWVycy5maW5kKCh2KSA9PiB2LmlkID09PSB2SWQpO1xyXG4gICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdm9sdW50ZWVySWQ6IGZvdW5kLmlkLFxyXG4gICAgICAgIHZvbHVudGVlck5hbWU6IGZvdW5kLm5hbWUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBWYWxpZGF0ZSAmIFN1Ym1pdFxyXG4gIGNvbnN0IGhhbmRsZUZvcm1TdWJtaXQgPSAoYXNEcmFmdCA9IGZhbHNlKSA9PiB7XHJcbiAgICBjb25zdCBlcnJvcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcclxuXHJcbiAgICBpZiAoIWZvcm1EYXRhLm5hbWUudHJpbSgpKSB7XHJcbiAgICAgIGVycm9ycy5uYW1lID0gJ1Nlc3Npb24gdG9waWMgaXMgcmVxdWlyZWQuJztcclxuICAgIH1cclxuICAgIGlmICghZm9ybURhdGEudmlsbGFnZU5hbWUudHJpbSgpKSB7XHJcbiAgICAgIGVycm9ycy52aWxsYWdlTmFtZSA9ICdQbGVhc2Ugc2VsZWN0IGEgdmlsbGFnZS4nO1xyXG4gICAgfVxyXG4gICAgaWYgKCFmb3JtRGF0YS52b2x1bnRlZXJOYW1lLnRyaW0oKSB8fCBmb3JtRGF0YS52b2x1bnRlZXJOYW1lID09PSAnVW5hc3NpZ25lZCcpIHtcclxuICAgICAgaWYgKCFhc0RyYWZ0KSB7XHJcbiAgICAgICAgZXJyb3JzLnZvbHVudGVlciA9ICdQbGVhc2Ugc2VsZWN0IGEgdm9sdW50ZWVyLic7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICghZm9ybURhdGEuZGF0ZS50cmltKCkpIHtcclxuICAgICAgZXJyb3JzLmRhdGUgPSAnUGxlYXNlIHNlbGVjdCBhIHZhbGlkIGRhdGUuJztcclxuICAgIH1cclxuXHJcbiAgICBpZiAoT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHNldEZvcm1FcnJvcnMoZXJyb3JzKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGZpbmFsU3RhdHVzOiBTZXNzaW9uWydzdGF0dXMnXSA9IGFzRHJhZnRcclxuICAgICAgPyAnRHJhZnQnXHJcbiAgICAgIDogZm9ybURhdGEuc3RhdHVzIHx8ICdTY2hlZHVsZWQnO1xyXG5cclxuICAgIGlmIChpc0VkaXRNb2RlICYmIGZvcm1EYXRhLmlkKSB7XHJcbiAgICAgIG9uVXBkYXRlU2Vzc2lvbihmb3JtRGF0YS5pZCwge1xyXG4gICAgICAgIG5hbWU6IGZvcm1EYXRhLm5hbWUudHJpbSgpLFxyXG4gICAgICAgIHRpdGxlOiBmb3JtRGF0YS5uYW1lLnRyaW0oKSxcclxuICAgICAgICBjb2RlOiBmb3JtRGF0YS5jb2RlLFxyXG4gICAgICAgIG1vZHVsZUlkOiBmb3JtRGF0YS5tb2R1bGVJZCxcclxuICAgICAgICBtb2R1bGU6IGZvcm1EYXRhLm1vZHVsZSxcclxuICAgICAgICBkYXk6IGZvcm1EYXRhLmRheSxcclxuICAgICAgICBkYXRlOiBmb3JtRGF0YS5kYXRlLFxyXG4gICAgICAgIHRpbWU6IGZvcm1EYXRhLnRpbWUsXHJcbiAgICAgICAgZW5kVGltZTogZm9ybURhdGEuZW5kVGltZSxcclxuICAgICAgICBwYW5jaGF5YXRJZDogZm9ybURhdGEucGFuY2hheWF0SWQsXHJcbiAgICAgICAgcGFuY2hheWF0TmFtZTogZm9ybURhdGEucGFuY2hheWF0TmFtZSxcclxuICAgICAgICB2aWxsYWdlTmFtZTogZm9ybURhdGEudmlsbGFnZU5hbWUsXHJcbiAgICAgICAgdm9sdW50ZWVySWQ6IGZvcm1EYXRhLnZvbHVudGVlcklkLFxyXG4gICAgICAgIHZvbHVudGVlck5hbWU6IGZvcm1EYXRhLnZvbHVudGVlck5hbWUsXHJcbiAgICAgICAgc2Vzc2lvblR5cGU6IGZvcm1EYXRhLnNlc3Npb25UeXBlLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBmb3JtRGF0YS5kZXNjcmlwdGlvbixcclxuICAgICAgICBzdGF0dXM6IGZpbmFsU3RhdHVzLFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKGFjdGl2ZVNlc3Npb25EZXRhaWw/LmlkID09PSBmb3JtRGF0YS5pZCkge1xyXG4gICAgICAgIHNldEFjdGl2ZVNlc3Npb25EZXRhaWwoKHByZXYpID0+IChwcmV2ID8geyAuLi5wcmV2LCAuLi5mb3JtRGF0YSwgc3RhdHVzOiBmaW5hbFN0YXR1cyB9IDogbnVsbCkpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBuZXdTZXNzaW9uOiBPbWl0PFNlc3Npb24sICdpZCc+ID0ge1xyXG4gICAgICAgIGNvZGU6IGZvcm1EYXRhLmNvZGUgfHwgYE0tJHtNYXRoLmZsb29yKDEwMCArIE1hdGgucmFuZG9tKCkgKiA5MDApfWAsXHJcbiAgICAgICAgbmFtZTogZm9ybURhdGEubmFtZS50cmltKCksXHJcbiAgICAgICAgdGl0bGU6IGZvcm1EYXRhLm5hbWUudHJpbSgpLFxyXG4gICAgICAgIG1vZHVsZUlkOiBmb3JtRGF0YS5tb2R1bGVJZCxcclxuICAgICAgICBtb2R1bGU6IGZvcm1EYXRhLm1vZHVsZSxcclxuICAgICAgICBkYXk6IGZvcm1EYXRhLmRheSxcclxuICAgICAgICBkYXRlOiBmb3JtRGF0YS5kYXRlLFxyXG4gICAgICAgIHRpbWU6IGZvcm1EYXRhLnRpbWUsXHJcbiAgICAgICAgZW5kVGltZTogZm9ybURhdGEuZW5kVGltZSxcclxuICAgICAgICBwYW5jaGF5YXRJZDogZm9ybURhdGEucGFuY2hheWF0SWQsXHJcbiAgICAgICAgcGFuY2hheWF0TmFtZTogZm9ybURhdGEucGFuY2hheWF0TmFtZSxcclxuICAgICAgICB2aWxsYWdlTmFtZTogZm9ybURhdGEudmlsbGFnZU5hbWUsXHJcbiAgICAgICAgdm9sdW50ZWVySWQ6IGZvcm1EYXRhLnZvbHVudGVlcklkLFxyXG4gICAgICAgIHZvbHVudGVlck5hbWU6IGZvcm1EYXRhLnZvbHVudGVlck5hbWUsXHJcbiAgICAgICAgc2Vzc2lvblR5cGU6IGZvcm1EYXRhLnNlc3Npb25UeXBlLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBmb3JtRGF0YS5kZXNjcmlwdGlvbiB8fCAnV2Vla2x5IHN0dWRlbnQgaG9saXN0aWMgZGV2ZWxvcG1lbnQgbGVhcm5pbmcgc2Vzc2lvbi4nLFxyXG4gICAgICAgIHN0YXR1czogZmluYWxTdGF0dXMsXHJcbiAgICAgICAgc3BvYzogZm9ybURhdGEudm9sdW50ZWVyTmFtZSxcclxuICAgICAgICBmaW5hbmNlcjogJ0NsdXN0ZXIgRnVuZCcsXHJcbiAgICAgIH07XHJcbiAgICAgIG9uQWRkU2Vzc2lvbihuZXdTZXNzaW9uKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc05ld01vZGFsT3BlbihmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ1NWIEV4cG9ydCBGdW5jdGlvblxyXG4gIGNvbnN0IGhhbmRsZUV4cG9ydENTViA9ICgpID0+IHtcclxuICAgIGlmIChmaWx0ZXJlZFNlc3Npb25zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhbGVydCgnTm8gc2Vzc2lvbiBkYXRhIGF2YWlsYWJsZSB0byBleHBvcnQuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IGhlYWRlcnMgPSBbXHJcbiAgICAgICdTZXNzaW9uIENvZGUnLFxyXG4gICAgICAnVG9waWMnLFxyXG4gICAgICAnTW9kdWxlJyxcclxuICAgICAgJ0RhdGUnLFxyXG4gICAgICAnVGltZScsXHJcbiAgICAgICdEYXknLFxyXG4gICAgICAnUGFuY2hheWF0JyxcclxuICAgICAgJ1ZpbGxhZ2UnLFxyXG4gICAgICAnQXNzaWduZWQgVm9sdW50ZWVyJyxcclxuICAgICAgJ1N0YXR1cycsXHJcbiAgICAgICdTZXNzaW9uIFR5cGUnLFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCByb3dzID0gZmlsdGVyZWRTZXNzaW9ucy5tYXAoKHMpID0+IFtcclxuICAgICAgYFwiJHtzLmNvZGUgfHwgJyd9XCJgLFxyXG4gICAgICBgXCIkeyhzLm5hbWUgfHwgcy50aXRsZSB8fCAnJykucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImAsXHJcbiAgICAgIGBcIiR7KHMubW9kdWxlIHx8IHMubW9kdWxlSWQgfHwgJycpLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgLFxyXG4gICAgICBgXCIke3MuZGF0ZX1cImAsXHJcbiAgICAgIGBcIiR7cy50aW1lfVwiYCxcclxuICAgICAgYFwiJHtzLmRheSB8fCAnJ31cImAsXHJcbiAgICAgIGBcIiR7cy5wYW5jaGF5YXROYW1lfVwiYCxcclxuICAgICAgYFwiJHtzLnZpbGxhZ2VOYW1lfVwiYCxcclxuICAgICAgYFwiJHtzLnZvbHVudGVlck5hbWV9XCJgLFxyXG4gICAgICBgXCIke3Muc3RhdHVzfVwiYCxcclxuICAgICAgYFwiJHtzLnNlc3Npb25UeXBlIHx8ICdBY2FkZW1pYyd9XCJgLFxyXG4gICAgXSk7XHJcblxyXG4gICAgY29uc3QgY3N2Q29udGVudCA9XHJcbiAgICAgICdkYXRhOnRleHQvY3N2O2NoYXJzZXQ9dXRmLTgsJyArXHJcbiAgICAgIFtoZWFkZXJzLmpvaW4oJywnKSwgLi4ucm93cy5tYXAoKGUpID0+IGUuam9pbignLCcpKV0uam9pbignXFxuJyk7XHJcbiAgICBjb25zdCBlbmNvZGVkVXJpID0gZW5jb2RlVVJJKGNzdkNvbnRlbnQpO1xyXG4gICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgIGxpbmsuc2V0QXR0cmlidXRlKCdocmVmJywgZW5jb2RlZFVyaSk7XHJcbiAgICBsaW5rLnNldEF0dHJpYnV0ZShcclxuICAgICAgJ2Rvd25sb2FkJyxcclxuICAgICAgYFRRSV9TZXNzaW9uc19EaGFybWFwdXJpXyR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF19LmNzdmBcclxuICAgICk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xyXG4gICAgbGluay5jbGljaygpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKTtcclxuICB9O1xyXG5cclxuICAvLyBSZW5kZXIgU3RhdHVzIEJhZGdlXHJcbiAgY29uc3QgcmVuZGVyU3RhdHVzQmFkZ2UgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbiAgICAgIGNhc2UgJ1NjaGVkdWxlZCc6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctYmx1ZS02MDBcIj48L3NwYW4+XHJcbiAgICAgICAgICAgIFNjaGVkdWxlZFxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgJ0luIFByb2dyZXNzJzpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1hbWJlci01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgSW4gUHJvZ3Jlc3NcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlICdDb21wbGV0ZWQnOlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNjAwXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICBDb21wbGV0ZWRcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlICdOZWVkcyBBdHRlbnRpb24nOlxyXG4gICAgICBjYXNlICdBY3Rpb24gUmVxLic6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1yb3NlLTUwIHRleHQtcm9zZS03MDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctcm9zZS02MDBcIj48L3NwYW4+XHJcbiAgICAgICAgICAgIE5lZWRzIEF0dGVudGlvblxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgJ0NhbmNlbGxlZCc6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTQwMFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgQ2FuY2VsbGVkXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgICAgY2FzZSAnRHJhZnQnOlxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS01MDBcIj48L3NwYW4+XHJcbiAgICAgICAgICAgIERyYWZ0XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiAxLiBDYXJkbGVzcyBQYWdlIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIExlYXJuaW5nIFNlc3Npb25zXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cInByaW1hcnlcIiBzaXplPVwic21cIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRTZXNzaW9ucy5sZW5ndGh9IFRvdGFsXHJcbiAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICBQbGFuLCBjb29yZGluYXRlLCBhbmQgdHJhY2sgdmlsbGFnZSBsZWFybmluZyBtb2R1bGVzIGFuZCBhdHRlbmRhbmNlIGFjcm9zcyBjbHVzdGVycy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0Q1NWfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5FeHBvcnQgQ1NWPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuTmV3TW9kYWx9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5BZGQgU2Vzc2lvbjwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiAyLiBDb21wYWN0IE1ldHJpYyBDYXJkcyAoY291bnRzICYgc3RhdHVzIG9ubHkpICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+VXBjb21pbmc8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dXBjb21pbmdDb3VudH08L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYnJhbmQtNTAwXCI+U2NoZWR1bGVkPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3NjaGVkdWxlZENvdW50fTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zdWNjZXNzLTUwMFwiPkNvbXBsZXRlZDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPntjb21wbGV0ZWRDb3VudH08L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZXJyb3ItNTAwXCI+TmVlZHMgQXR0ZW50aW9uPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e25lZWRzQXR0ZW50aW9uQ291bnR9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIE5FWFQgU0VTU0lPTiBTcG90bGlnaHQgU2VjdGlvbiAqL31cclxuICAgICAge25leHRTZXNzaW9uICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGxnOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYnJhbmQtNTAwIGJnLWJyYW5kLTUwIGRhcms6YmctYnJhbmQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgTmV4dCBTZXNzaW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICB7cmVuZGVyU3RhdHVzQmFkZ2UobmV4dFNlc3Npb24uc3RhdHVzKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAge2dldFNlc3Npb25UaXRsZShuZXh0U2Vzc2lvbil9XHJcbiAgICAgICAgICAgICAgICB7bmV4dFNlc3Npb24uY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgZm9udC1tb25vIHRleHQteHMgZm9udC1ub3JtYWwgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICh7bmV4dFNlc3Npb24uY29kZX0pXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAteC00IGdhcC15LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+e25leHRTZXNzaW9uLmRhdGV9ICZtaWRkb3Q7IHtuZXh0U2Vzc2lvbi50aW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlBhbmNoYXlhdDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPntuZXh0U2Vzc2lvbi5wYW5jaGF5YXROYW1lfTwvc3Ryb25nPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlZpbGxhZ2U6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0yMDBcIj57bmV4dFNlc3Npb24udmlsbGFnZU5hbWV9PC9zdHJvbmc+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+Vm9sdW50ZWVyOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYnJhbmQtNTAwXCI+e2dldFNlc3Npb25Wb2x1bnRlZXIobmV4dFNlc3Npb24pfTwvc3Ryb25nPjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZXNzaW9uRGV0YWlsKG5leHRTZXNzaW9uKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdsZXNzb24tcGxhbicsIG5leHRTZXNzaW9uLmxlc3NvblBsYW5JZCB8fCBuZXh0U2Vzc2lvbi5pZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtMjAwIGJnLWJyYW5kLTUwIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTYwMCBob3ZlcjpiZy1icmFuZC0xMDAgZGFyazpib3JkZXItYnJhbmQtOTAwLzQwIGRhcms6YmctYnJhbmQtNTAwLzEwIGRhcms6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgTGVzc29uIFBsYW5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2F0dGVuZGFuY2UnLCBuZXh0U2Vzc2lvbi5pZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEF0dGVuZGFuY2VcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiAzLiBDYXJkbGVzcyBTZWFyY2ggKyBGaWx0ZXIgUm93ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtM1wiPlxyXG4gICAgICAgICAgey8qIFNlYXJjaCBiYXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggc2Vzc2lvbiwgbW9kdWxlLCB2aWxsYWdlIG9yIHZvbHVudGVlci4uLlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwbC0xMCBwci04IHB5LTIgdGV4dC14cyB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge3NlYXJjaFRlcm0gJiYgKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoVGVybSgnJyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFBhbmNoYXlhdCBmaWx0ZXIgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGFuY2hheWF0IHx8IFwiYWxsXCJ9XHJcbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYW5jaGF5YXQodmFsKTtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkVmlsbGFnZSgnYWxsJyk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgUGFuY2hheWF0c1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgUGFuY2hheWF0czwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIHtwYW5jaGF5YXRzLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3AuaWR9IHZhbHVlPXtwLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICB7cC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFZpbGxhZ2UgZmlsdGVyICovfVxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFZpbGxhZ2UgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZFZpbGxhZ2UodmFsKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgVmlsbGFnZXNcIiAvPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFZpbGxhZ2VzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRGaWx0ZXJWaWxsYWdlcy5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFN0YXR1cyBGaWx0ZXIgKyBNb3JlIEZpbHRlcnMgVG9nZ2xlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFN0YXR1cyB8fCBcImFsbFwifVxyXG4gICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRTdGF0dXModmFsKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgU3RhdHVzZXNcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFN0YXR1c2VzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlNjaGVkdWxlZFwiPlNjaGVkdWxlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJJbiBQcm9ncmVzc1wiPkluIFByb2dyZXNzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkNvbXBsZXRlZFwiPkNvbXBsZXRlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJOZWVkcyBBdHRlbnRpb25cIj5OZWVkcyBBdHRlbnRpb248L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiRHJhZnRcIj5EcmFmdDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDYW5jZWxsZWRcIj5DYW5jZWxsZWQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb3JlRmlsdGVycyghc2hvd01vcmVGaWx0ZXJzKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIGJvcmRlciBweC0zIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gc2hhZG93LXRoZW1lLXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNocmluay0wICR7XHJcbiAgICAgICAgICAgICAgICBzaG93TW9yZUZpbHRlcnMgfHwgc2VsZWN0ZWRNb2R1bGUgIT09ICdhbGwnIHx8IHNlbGVjdGVkVm9sdW50ZWVyICE9PSAnYWxsJyB8fCBmaWx0ZXJEYXRlXHJcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1icmFuZC01MDAgYmctYnJhbmQtNTAgdGV4dC1icmFuZC02MDAgZGFyazpiZy1icmFuZC01MDAvMTAgZGFyazp0ZXh0LWJyYW5kLTQwMCdcclxuICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCdcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTVweF1cIj50dW5lPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkZpbHRlcjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFNlY29uZGFyeSBFeHBhbmRhYmxlIEZpbHRlcnMgKi99XHJcbiAgICAgICAge3Nob3dNb3JlRmlsdGVycyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTQgZ2FwLTMgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIE1vZHVsZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTW9kdWxlfVxyXG4gICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRNb2R1bGUodmFsKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC04IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQWxsIE1vZHVsZXNcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIE1vZHVsZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiU3Bva2VuIEVuZ2xpc2hcIj5TcG9rZW4gRW5nbGlzaDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJCYXNpYyBNYXRoXCI+QmFzaWMgTWF0aDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJMaWZlIFNraWxsc1wiPkxpZmUgU2tpbGxzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRpZ2l0YWwgTGl0ZXJhY3lcIj5EaWdpdGFsIExpdGVyYWN5PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlNjaWVuY2VcIj5TY2llbmNlPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZpbmFuY2lhbCBMaXRlcmFjeVwiPkZpbmFuY2lhbCBMaXRlcmFjeTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBWb2x1bnRlZXJcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFZvbHVudGVlcn1cclxuICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkVm9sdW50ZWVyKHZhbCl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBWb2x1bnRlZXJzXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbCBWb2x1bnRlZXJzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICB7dm9sdW50ZWVycy5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2Lm5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3YubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIERhdGVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlckRhdGV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZpbHRlckRhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zIHB5LTEuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQganVzdGlmeS1lbmQgcHQtNVwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2xlYXIgRmlsdGVyc1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIDQuIENhcmRsZXNzIFRhaWxBZG1pbiBTZXNzaW9uIFRhYmxlICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBiZy1ncmF5LTUwLzUwIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gZGFyazp0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+RGF0ZSAmYW1wOyBUaW1lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlNlc3Npb24gVG9waWMgJmFtcDsgTW9kdWxlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlBhbmNoYXlhdCAmYW1wOyBWaWxsYWdlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlZvbHVudGVlcjwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQtcmlnaHRcIj5BY3Rpb25zPC90aD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLWdyYXktMTAwIGRhcms6ZGl2aWRlLWdyYXktODAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICB7ZmlsdGVyZWRTZXNzaW9ucy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTm8gc2Vzc2lvbnMgbWF0Y2ggeW91ciBmaWx0ZXIgY3JpdGVyaWEuXHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZFNlc3Npb25zLm1hcCgoc2Vzc2lvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e3Nlc3Npb24uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MC84MCBkYXJrOmhvdmVyOmJnLXdoaXRlL1swLjAyXSB0cmFuc2l0aW9uLWNvbG9ycyBncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRGF0ZSAmIFRpbWUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPntzZXNzaW9uLmRhdGV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnRpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVG9waWMgJiBNb2R1bGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z2V0U2Vzc2lvblRpdGxlKHNlc3Npb24pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLmNvZGUgfHwgc2Vzc2lvbi5tb2R1bGVJZCB8fCAnTS0xMDMnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPiAmbWlkZG90OyB7Z2V0U2Vzc2lvbk1vZHVsZShzZXNzaW9uKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogUGFuY2hheWF0ICYgVmlsbGFnZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiPntzZXNzaW9uLnBhbmNoYXlhdE5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57c2Vzc2lvbi52aWxsYWdlTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVm9sdW50ZWVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24udm9sdW50ZWVyTmFtZSAmJiBzZXNzaW9uLnZvbHVudGVlck5hbWUgIT09ICdVbmFzc2lnbmVkJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiByb3VuZGVkLWZ1bGwgYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgdGV4dC1bMTBweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGRhcms6YmctYnJhbmQtNTAwLzEwIGRhcms6dGV4dC1icmFuZC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnZvbHVudGVlck5hbWUuY2hhckF0KDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3Nlc3Npb24udm9sdW50ZWVyTmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwibGlnaHRcIiBzaXplPVwic21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBVbmFzc2lnbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb24uc3RhdHVzID09PSAnQ29tcGxldGVkJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnc3VjY2VzcydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2Vzc2lvbi5zdGF0dXMgPT09ICdJbiBQcm9ncmVzcydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3dhcm5pbmcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlc3Npb24uc3RhdHVzID09PSAnTmVlZHMgQXR0ZW50aW9uJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnZXJyb3InXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdwcmltYXJ5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQtcmlnaHQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZXNzaW9uRGV0YWlsKHNlc3Npb24pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlZpZXcgU2Vzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+dmlzaWJpbGl0eTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdsZXNzb24tcGxhbicsIHNlc3Npb24ubGVzc29uUGxhbklkIHx8IHNlc3Npb24uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkxlc3NvbiBQbGFuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5tZW51X2Jvb2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnYXR0ZW5kYW5jZScsIHNlc3Npb24uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkF0dGVuZGFuY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmhvd190b19yZWc8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzQ2x1c3RlckFkbWluICYmIG9uUmVxdWVzdERhdGVDaGFuZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXREYXRlQ2hhbmdlU2Vzc2lvbihzZXNzaW9uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGF0ZUNoYW5nZU5ld0RhdGUoc2Vzc2lvbi5kYXRlIHx8ICcnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RGF0ZUNoYW5nZVJlYXNvbignJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOnRleHQtYnJhbmQtNDAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXF1ZXN0IERhdGUgQ2hhbmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7WydTdWJtaXR0ZWQnLCAnUGVuZGluZyBSZXZpZXcnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoc2Vzc2lvbi5zdGF0dXMpID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTMwMCBkYXJrOnRleHQtZ3JheS02MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU2Vzc2lvbiBzdWJtaXR0ZWQgLSBlZGl0aW5nIGRpc2FibGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5FZGl0TW9kYWwoc2Vzc2lvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMS41IHRleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS0xMDAgaG92ZXI6dGV4dC1icmFuZC01MDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5lZGl0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29uRGVsZXRlU2Vzc2lvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZXNzaW9uVG9EZWxldGUoc2Vzc2lvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMS41IHRleHQtZ3JheS00MDAgaG92ZXI6YmctZXJyb3ItNTAgaG92ZXI6dGV4dC1lcnJvci02MDAgZGFyazpob3ZlcjpiZy1lcnJvci01MDAvMTAgZGFyazpob3Zlcjp0ZXh0LWVycm9yLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIENSRUFURSAvIEVESVQgU0VTU0lPTiBNT0RBTCAoQ2xlYW4gRHJhd2VyIC8gTW9kYWwpICovfVxyXG4gICAgICB7aXNOZXdNb2RhbE9wZW4gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBiZy1ncmF5LTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBtYXgtdy0yeGwgdy1mdWxsIG1heC1oLVs5MnZoXSBmbGV4IGZsZXgtY29sIG15LWF1dG8gYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc2xhdGUtNTAvNTAgcm91bmRlZC10LXhsXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRNb2RlID8gJ0VkaXQgU2Vzc2lvbicgOiAnQ3JlYXRlIE5ldyBTZXNzaW9uJ31cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEZpbGwgaW4gdGhlIGRldGFpbHMgdG8gc2NoZWR1bGUgbGVhcm5pbmcgYWN0aXZpdHkgaW4geW91ciBjbHVzdGVyLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTmV3TW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHAtMSByb3VuZGVkLW1kIGhvdmVyOmJnLXNsYXRlLTEwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMHB4XVwiPmNsb3NlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBCb2R5IC8gRm9ybSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgey8qIFJvdyAxOiBUb3BpYyAmIE1vZHVsZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2Vzc2lvbiBUb3BpYyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybUVycm9ycy5uYW1lKSBzZXRGb3JtRXJyb3JzKHsgLi4uZm9ybUVycm9ycywgbmFtZTogJycgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU3Bva2VuIEVuZ2xpc2gg4oCUIE1vZHVsZSAzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1FcnJvcnMubmFtZSA/ICdib3JkZXItcm9zZS00MDAgYmctcm9zZS01MC8zMCcgOiAnYm9yZGVyLXNsYXRlLTMwMCdcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1FcnJvcnMubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+e2Zvcm1FcnJvcnMubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEN1cnJpY3VsdW0gTW9kdWxlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubW9kdWxlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyhtb2QpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGxldCBtb2RJZCA9ICdNLTEwMyc7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobW9kID09PSAnQmFzaWMgTWF0aCcpIG1vZElkID0gJ00tMzAxJztcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChtb2QgPT09ICdMaWZlIFNraWxscycpIG1vZElkID0gJ00tMTAyJztcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChtb2QgPT09ICdEaWdpdGFsIExpdGVyYWN5JykgbW9kSWQgPSAnRC0wMDQnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKG1vZCA9PT0gJ1NjaWVuY2UnKSBtb2RJZCA9ICdTLTIwMSc7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobW9kID09PSAnRmluYW5jaWFsIExpdGVyYWN5JykgbW9kSWQgPSAnRi0xMDEnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbW9kdWxlOiBtb2QsIG1vZHVsZUlkOiBtb2RJZCB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOSB0ZXh0LXhzIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlbGVjdCBNb2R1bGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiU3Bva2VuIEVuZ2xpc2hcIj5TcG9rZW4gRW5nbGlzaCAoTS0xMDMpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJCYXNpYyBNYXRoXCI+QmFzaWMgTWF0aCAoTS0zMDEpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJMaWZlIFNraWxsc1wiPkxpZmUgU2tpbGxzIChNLTEwMik8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkRpZ2l0YWwgTGl0ZXJhY3lcIj5EaWdpdGFsIExpdGVyYWN5IChELTAwNCk8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlNjaWVuY2VcIj5TY2llbmNlIChTLTIwMSk8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZpbmFuY2lhbCBMaXRlcmFjeVwiPkZpbmFuY2lhbCBMaXRlcmFjeSAoRi0xMDEpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJvdyAyOiBEYXRlLCBEYXkgJiBUaW1lICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtMy41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkYXRlOiBlLnRhcmdldC52YWx1ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3JtRXJyb3JzLmRhdGUpIHNldEZvcm1FcnJvcnMoeyAuLi5mb3JtRXJyb3JzLCBkYXRlOiAnJyB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1tZCB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1FcnJvcnMuZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+e2Zvcm1FcnJvcnMuZGF0ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBEYXkgb2YgV2Vla1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRheX1cclxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkYXk6IHZhbCB9KX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTkgdGV4dC14cyBib3JkZXItc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGF5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlNhdHVyZGF5XCI+U2F0dXJkYXk8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlN1bmRheVwiPlN1bmRheTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiTW9uZGF5XCI+TW9uZGF5PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJUdWVzZGF5XCI+VHVlc2RheTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiV2VkbmVzZGF5XCI+V2VkbmVzZGF5PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJUaHVyc2RheVwiPlRodXJzZGF5PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJGcmlkYXlcIj5GcmlkYXk8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRpbWUgU2xvdFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIDEwOjAwIEFNIC0gMTI6MzAgUE1cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdGltZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV1cIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb3cgMzogUGFuY2hheWF0ICYgVmlsbGFnZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFuY2hheWF0IENsdXN0ZXIgSHViIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhbmNoYXlhdElkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IGhhbmRsZVBhbmNoYXlhdFNlbGVjdENoYW5nZSh2YWwpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOSB0ZXh0LXhzIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQYW5jaGF5YXRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwYW5jaGF5YXRzLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3AuaWR9IHZhbHVlPXtwLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVmlsbGFnZSAvIExlYXJuaW5nIENlbnRlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS52aWxsYWdlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCB2aWxsYWdlTmFtZTogdmFsIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGZvcm1FcnJvcnMudmlsbGFnZU5hbWUpIHNldEZvcm1FcnJvcnMoeyAuLi5mb3JtRXJyb3JzLCB2aWxsYWdlTmFtZTogJycgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT17YHctZnVsbCBoLTkgdGV4dC14cyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybUVycm9ycy52aWxsYWdlTmFtZSA/ICdib3JkZXItcm9zZS00MDAgYmctcm9zZS01MC8zMCcgOiAnYm9yZGVyLXNsYXRlLTMwMCdcclxuICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVmlsbGFnZSBDZW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIHttb2RhbFZpbGxhZ2VzLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2Lm5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt2Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRXJyb3JzLnZpbGxhZ2VOYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj57Zm9ybUVycm9ycy52aWxsYWdlTmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJvdyA0OiBWb2x1bnRlZXIgJiBUeXBlICYgU3RhdHVzICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtMy41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBBc3NpZ25lZCBWb2x1bnRlZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudm9sdW50ZWVySWQgfHwgKGZvcm1EYXRhLnZvbHVudGVlck5hbWUgPT09ICdVbmFzc2lnbmVkJyA/ICd1bmFzc2lnbmVkJyA6ICcnKX1cclxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVWb2x1bnRlZXJTZWxlY3RDaGFuZ2UodmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3JtRXJyb3JzLnZvbHVudGVlcikgc2V0Rm9ybUVycm9ycyh7IC4uLmZvcm1FcnJvcnMsIHZvbHVudGVlcjogJycgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT17YHctZnVsbCBoLTkgdGV4dC14cyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybUVycm9ycy52b2x1bnRlZXIgPyAnYm9yZGVyLXJvc2UtNDAwIGJnLXJvc2UtNTAvMzAnIDogJ2JvcmRlci1zbGF0ZS0zMDAnXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFZvbHVudGVlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJ1bmFzc2lnbmVkXCI+LS0gVW5hc3NpZ25lZCAoTmVlZHMgQXR0ZW50aW9uKSAtLTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2b2x1bnRlZXJzLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2LmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7di5uYW1lfSAoe3YuZGVwYXJ0bWVudD8uc3BsaXQoJyAnKVswXSB8fCAnTWVudG9yJ30pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtmb3JtRXJyb3JzLnZvbHVudGVlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+e2Zvcm1FcnJvcnMudm9sdW50ZWVyfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlc3Npb24gVHlwZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnNlc3Npb25UeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uVHlwZTogdmFsIGFzICdBY2FkZW1pYycgfCAnTGlmZSBTa2lsbHMnIHwgJ0Fzc2Vzc21lbnQnIHwgJ09yaWVudGF0aW9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOSB0ZXh0LXhzIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlc3Npb24gVHlwZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJBY2FkZW1pY1wiPkFjYWRlbWljIENvcmU8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkxpZmUgU2tpbGxzXCI+TGlmZSBTa2lsbHMgJmFtcDsgSGFiaXRzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJBc3Nlc3NtZW50XCI+QXNzZXNzbWVudCAmYW1wOyBSZXZpZXc8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk9yaWVudGF0aW9uXCI+T3JpZW50YXRpb24gJmFtcDsgR2FtZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEluaXRpYWwgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBzdGF0dXM6IHZhbCBhcyBTZXNzaW9uWydzdGF0dXMnXSB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTkgdGV4dC14cyBib3JkZXItc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTdGF0dXNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiU2NoZWR1bGVkXCI+U2NoZWR1bGVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJJbiBQcm9ncmVzc1wiPkluIFByb2dyZXNzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDb21wbGV0ZWRcIj5Db21wbGV0ZWQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk5lZWRzIEF0dGVudGlvblwiPk5lZWRzIEF0dGVudGlvbjwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiRHJhZnRcIj5EcmFmdDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb3cgNTogRGVzY3JpcHRpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvbiAvIExlc3NvbiBPYmplY3RpdmUgTm90ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZGVzY3JpcHRpb246IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk91dGxpbmUga2V5IGxlYXJuaW5nIGdvYWxzLCBleHBlY3RlZCBhY3Rpdml0eSBvciByZXF1aXJlZCBraXQuLi5cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbWQgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMEIzRDkxXVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtYi14bFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNOZXdNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUZvcm1TdWJtaXQodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBEcmFmdFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVGb3JtU3VibWl0KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYmctWyMwQjNEOTFdIGhvdmVyOmJnLVsjMDgyYTY2XSB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRNb2RlID8gJ1VwZGF0ZSBTZXNzaW9uJyA6ICdDcmVhdGUgU2Vzc2lvbid9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBTRVNTSU9OIERFVEFJTCBNT0RBTCAvIERSQVdFUiAqL31cclxuICAgICAge2FjdGl2ZVNlc3Npb25EZXRhaWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBiZy1ncmF5LTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBtYXgtdy0zeGwgdy1mdWxsIG1heC1oLVs5MnZoXSBmbGV4IGZsZXgtY29sIG15LWF1dG8gYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgIHsvKiBEZXRhaWwgSGVhZGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwLzcwIHJvdW5kZWQtdC14bCBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIGZvbnQtYm9sZCBiZy1bIzBCM0Q5MV0vMTAgdGV4dC1bIzBCM0Q5MV0gcHgtMiBweS0wLjUgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLmNvZGUgfHwgJ00tMTAzJ31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB7cmVuZGVyU3RhdHVzQmFkZ2UoYWN0aXZlU2Vzc2lvbkRldGFpbC5zdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2dldFNlc3Npb25UaXRsZShhY3RpdmVTZXNzaW9uRGV0YWlsKX1cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIE1vZHVsZToge2dldFNlc3Npb25Nb2R1bGUoYWN0aXZlU2Vzc2lvbkRldGFpbCl9IOKAoiB7YWN0aXZlU2Vzc2lvbkRldGFpbC5zZXNzaW9uVHlwZSB8fCAnQWNhZGVtaWMgU2Vzc2lvbid9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVNlc3Npb25EZXRhaWwobnVsbCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBwLTEgcm91bmRlZC1tZCBob3ZlcjpiZy1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGV0YWlsIEJvZHkgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IG92ZXJmbG93LXktYXV0byBzcGFjZS15LTUgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIHsvKiBGaWVsZCBPcGVyYXRpb25zIFdvcmtmbG93IFN0ZXBzIEluZGljYXRvciAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zLjVcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlc3Npb24gRGVsaXZlcnkgV29ya2Zsb3dcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgb3ZlcmZsb3cteC1hdXRvIHBiLTEgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBzaHJpbmstMCB0ZXh0LWVtZXJhbGQtNzAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF0gdGV4dC1lbWVyYWxkLTYwMFwiPmNoZWNrX2NpcmNsZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj4xLiBDcmVhdGVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDBcIj7ihpI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgc2hyaW5rLTAgdGV4dC1lbWVyYWxkLTcwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdIHRleHQtZW1lcmFsZC02MDBcIj5jaGVja19jaXJjbGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Mi4gU2NoZWR1bGVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDBcIj7ihpI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgc2hyaW5rLTAgJHthY3RpdmVTZXNzaW9uRGV0YWlsLnN0YXR1cyA9PT0gJ0NvbXBsZXRlZCcgfHwgYWN0aXZlU2Vzc2lvbkRldGFpbC5zdGF0dXMgPT09ICdJbiBQcm9ncmVzcycgPyAndGV4dC1lbWVyYWxkLTcwMCBmb250LWJvbGQnIDogJ3RleHQtc2xhdGUtNTAwJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbkRldGFpbC5zdGF0dXMgPT09ICdDb21wbGV0ZWQnID8gJ2NoZWNrX2NpcmNsZScgOiAncGVuZGluZyd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjMuIENvbmR1Y3Q8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMFwiPuKGkjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBzaHJpbmstMCAke2FjdGl2ZVNlc3Npb25EZXRhaWwuc3RhdHVzID09PSAnQ29tcGxldGVkJyA/ICd0ZXh0LWVtZXJhbGQtNzAwIGZvbnQtYm9sZCcgOiAndGV4dC1zbGF0ZS01MDAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLnN0YXR1cyA9PT0gJ0NvbXBsZXRlZCcgPyAnY2hlY2tfY2lyY2xlJyA6ICdmYWN0X2NoZWNrJ31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+NC4gQXR0ZW5kYW5jZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwXCI+4oaSPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNocmluay0wICR7YWN0aXZlU2Vzc2lvbkRldGFpbC5zdGF0dXMgPT09ICdDb21wbGV0ZWQnID8gJ3RleHQtZW1lcmFsZC03MDAgZm9udC1ib2xkJyA6ICd0ZXh0LXNsYXRlLTUwMCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVNlc3Npb25EZXRhaWwuc3RhdHVzID09PSAnQ29tcGxldGVkJyA/ICdjaGVja19jaXJjbGUnIDogJ3Bob3RvX2NhbWVyYSd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjUuIENvbXBsZXRlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIENvcmUgSW5mb3JtYXRpb24gR3JpZCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTMgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICBTY2hlZHVsZSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRleHQteHMgbXQtMC41IGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVNlc3Npb25EZXRhaWwuZGF0ZX0gKHthY3RpdmVTZXNzaW9uRGV0YWlsLmRheSB8fCAnU2F0J30pXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNDAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGltZSBXaW5kb3dcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdGV4dC14cyBtdC0wLjUgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbkRldGFpbC50aW1lfSAtIHthY3RpdmVTZXNzaW9uRGV0YWlsLmVuZFRpbWUgfHwgJzExOjMwIEFNJ31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYW5jaGF5YXQgJmFtcDsgVmlsbGFnZVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCB0ZXh0LXhzIG10LTAuNSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLnBhbmNoYXlhdE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1bMTFweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbkRldGFpbC52aWxsYWdlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICBBc3NpZ25lZCBWb2x1bnRlZXJcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bIzBCM0Q5MV0gdGV4dC14cyBtdC0wLjUgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Z2V0U2Vzc2lvblZvbHVudGVlcihhY3RpdmVTZXNzaW9uRGV0YWlsKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEZXNjcmlwdGlvbiAqL31cclxuICAgICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbkRldGFpbC5kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zLjUgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2Vzc2lvbiBEZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogTGlua2VkIE1vZHVsZXM6IExlc3NvbiBQbGFuICsgQXR0ZW5kYW5jZSArIFBob3RvcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBMZXNzb24gUGxhbiBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMy41IGJnLXdoaXRlIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdIHRleHQtWyMwQjNEOTFdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lbnVfYm9va1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTGVzc29uIFBsYW5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIGJnLWVtZXJhbGQtNTAgcHgtMS41IHB5LTAuNSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMaW5rZWRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0ZXAtYnktc3RlcCA5MC1taW51dGUgY3VycmljdWx1bSB3aXRoIHdvcmtzaGVldHMgYW5kIGdyb3VwIGRyaWxscy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlU2Vzc2lvbkRldGFpbChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGUoJ2xlc3Nvbi1wbGFuJywgYWN0aXZlU2Vzc2lvbkRldGFpbC5sZXNzb25QbGFuSWQgfHwgYWN0aXZlU2Vzc2lvbkRldGFpbC5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMS41IHRleHQtY2VudGVyIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LVsjMEIzRDkxXSBiZy1ibHVlLTUwIGhvdmVyOmJnLWJsdWUtMTAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgT3BlbiBMZXNzb24gUGxhbiAmZ3Q7XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEF0dGVuZGFuY2UgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMuNSBiZy13aGl0ZSBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XSB0ZXh0LVsjRkY3QTAwXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBob3dfdG9fcmVnXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBdHRlbmRhbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgYmctc2xhdGUtMTAwIHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVNlc3Npb25EZXRhaWwuYXR0ZW5kYW5jZUNvdW50IHx8IDB9L3thY3RpdmVTZXNzaW9uRGV0YWlsLnRvdGFsU3R1ZGVudHMgfHwgMjV9IFN0dWRlbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBNYXJrIHN0dWRlbnQgcHJlc2VuY2UsIHRhc2sgY29tcGxldGlvbiwgYW5kIGJlaGF2aW9yYWwgcmVtYXJrcy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlU2Vzc2lvbkRldGFpbChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGUoJ2F0dGVuZGFuY2UnLCBhY3RpdmVTZXNzaW9uRGV0YWlsLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0xLjUgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyNGRjdBMDBdIGJnLW9yYW5nZS01MCBob3ZlcjpiZy1vcmFuZ2UtMTAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFyayBBdHRlbmRhbmNlICZndDtcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU2Vzc2lvbiBQaG90b3MgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMuNSBiZy13aGl0ZSBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XSB0ZXh0LWVtZXJhbGQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBob3RvX2xpYnJhcnlcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIEZpZWxkIFBob3Rvc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGJnLXNsYXRlLTEwMCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLnBob3Rvcz8ubGVuZ3RoIHx8IDF9IE1lZGlhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBBY3Rpdml0eSBkb2N1bWVudGF0aW9uIGFuZCBjbGFzc3Jvb20gdmVyaWZpY2F0aW9uIG1lZGlhLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVTZXNzaW9uRGV0YWlsKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZSgnc2Vzc2lvbi1waG90b3MnLCBhY3RpdmVTZXNzaW9uRGV0YWlsLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0xLjUgdGV4dC1jZW50ZXIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC03MDAgYmctZW1lcmFsZC01MCBob3ZlcjpiZy1lbWVyYWxkLTEwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFVwbG9hZCAvIFZpZXcgUGhvdG9zICZndDtcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRGV0YWlsIEZvb3RlciBBY3Rpb25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMy41IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLWIteGxcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZXNzaW9uRGV0YWlsKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEJhY2sgdG8gU2Vzc2lvbnNcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAge2FjdGl2ZVNlc3Npb25EZXRhaWwuc3RhdHVzICE9PSAnQ29tcGxldGVkJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBvblVwZGF0ZVNlc3Npb24oYWN0aXZlU2Vzc2lvbkRldGFpbC5pZCwgeyBzdGF0dXM6ICdDb21wbGV0ZWQnIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlU2Vzc2lvbkRldGFpbCgocHJldikgPT4gKHByZXYgPyB7IC4uLnByZXYsIHN0YXR1czogJ0NvbXBsZXRlZCcgfSA6IG51bGwpKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFyayBhcyBDb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHthY3RpdmVTZXNzaW9uRGV0YWlsLnN0YXR1cyAhPT0gJ0NvbXBsZXRlZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgcyA9IGFjdGl2ZVNlc3Npb25EZXRhaWw7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVTZXNzaW9uRGV0YWlsKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlT3BlbkVkaXRNb2RhbChzKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYmctWyMwQjNEOTFdIGhvdmVyOmJnLVsjMDgyYTY2XSB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFZGl0IFNlc3Npb25cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIERFTEVURSBDT05GSVJNQVRJT04gTU9EQUwgKi99XHJcbiAgICAgIHtzZXNzaW9uVG9EZWxldGUgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWdyYXktOTAwLzcwIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc20gbWF4LXctbWQgdy1mdWxsIHAtNSBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLXJvc2UtNTAgdGV4dC1yb3NlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjJweF1cIj5kZWxldGVfZm9yZXZlcjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5EZWxldGUgTGVhcm5pbmcgU2Vzc2lvbjwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcmVtb3ZlICZxdW90O3tnZXRTZXNzaW9uVGl0bGUoc2Vzc2lvblRvRGVsZXRlKX0mcXVvdDsgZnJvbSB0aGUgdGltZXRhYmxlPyBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlc3Npb25Ub0RlbGV0ZShudWxsKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbWQgaG92ZXI6Ymctc2xhdGUtNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKG9uRGVsZXRlU2Vzc2lvbikgb25EZWxldGVTZXNzaW9uKHNlc3Npb25Ub0RlbGV0ZS5pZCk7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlc3Npb25Ub0RlbGV0ZShudWxsKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlybSBEZWxldGVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBSRVFVRVNUIERBVEUgQ0hBTkdFIE1PREFMICovfVxyXG4gICAgICB7ZGF0ZUNoYW5nZVNlc3Npb24gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWdyYXktOTAwLzcwIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc20gbWF4LXctbWQgdy1mdWxsIHAtNSBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAgdGV4dC1ibHVlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5SZXF1ZXN0IERhdGUgQ2hhbmdlPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIFN1Ym1pdCBhIGRhdGUgY2hhbmdlIHJlcXVlc3QgZm9yICZxdW90O3tnZXRTZXNzaW9uVGl0bGUoZGF0ZUNoYW5nZVNlc3Npb24pfSZxdW90Oy5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5DdXJyZW50IERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGVDaGFuZ2VTZXNzaW9uLmRhdGV9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgcm91bmRlZC1tZCB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPk5ldyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlQ2hhbmdlTmV3RGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREYXRlQ2hhbmdlTmV3RGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1tZCB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlJlYXNvbiBmb3IgY2hhbmdlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZGF0ZUNoYW5nZVJlYXNvbn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREYXRlQ2hhbmdlUmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeHBsYWluIHdoeSB0aGUgZGF0ZSBuZWVkcyB0byBiZSBjaGFuZ2VkLi4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV1cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RGF0ZUNoYW5nZVNlc3Npb24obnVsbCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQtc2xhdGUtNzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIGhvdmVyOmJnLXNsYXRlLTUwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaWYgKG9uUmVxdWVzdERhdGVDaGFuZ2UgJiYgZGF0ZUNoYW5nZU5ld0RhdGUgJiYgZGF0ZUNoYW5nZVJlYXNvbikge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IG9uUmVxdWVzdERhdGVDaGFuZ2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRlQ2hhbmdlU2Vzc2lvbi5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGVDaGFuZ2VTZXNzaW9uLmRhdGUgfHwgJycsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRlQ2hhbmdlTmV3RGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGVDaGFuZ2VSZWFzb25cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldERhdGVDaGFuZ2VTZXNzaW9uKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KCdQbGVhc2UgcHJvdmlkZSBhIG5ldyBkYXRlIGFuZCBhIHJlYXNvbi4nKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMS41IGJnLVsjMEIzRDkxXSBob3ZlcjpiZy1bIzA4MmE2Nl0gdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFN1Ym1pdCBSZXF1ZXN0XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuXHJcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9TZXNzaW9uc1ZpZXcudHN4In0=