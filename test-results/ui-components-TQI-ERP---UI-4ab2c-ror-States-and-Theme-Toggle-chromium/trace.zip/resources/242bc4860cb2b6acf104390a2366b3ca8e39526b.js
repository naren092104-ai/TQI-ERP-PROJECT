import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ReportPreviewView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const ReportPreviewView = ({
  onBack
}) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-5xl mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onBack,
          className: "flex items-center gap-1.5 text-[13px] font-bold text-[#002869] hover:underline cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "arrow_back" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 20,
              columnNumber: 11
            }, this),
            "Back to Reports List"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 16,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => window.print(),
            className: "flex items-center gap-1.5 px-4 py-2 bg-[#002869] text-white rounded-md text-[13px] font-bold hover:bg-[#002869]/90 shadow-xs cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "print" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 29,
                columnNumber: 13
              }, this),
              "Print / Save PDF"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 25,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => alert("Editing report draft mode activated."),
            className: "flex items-center gap-1.5 px-4 py-2 border border-[#002869] text-[#002869] rounded-md text-[13px] font-bold hover:bg-[#f4f3fb] cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "edit_note" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 36,
                columnNumber: 13
              }, this),
              "Edit Report"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 32,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-[#c4c6d3]/80 p-6 md:p-10 shadow-sm space-y-8 print:border-none print:shadow-none print:p-0", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-center pb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-[12px] font-extrabold uppercase tracking-widest text-[#002869] mb-1", children: "TALENT QUEST FOR INDIA" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 46,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-[22px] md:text-[25px] font-bold text-[#002869] leading-tight", children: "Awareness and Skill Development Program" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 49,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[16px] font-bold text-[#fb7800] mt-1", children: "Academic Year (2023 - 2024) Activity Report" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 52,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-1.5 bg-[#002869] rounded-full w-full" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f4f3fb] border border-[#c4c6d3]/60 rounded-md p-5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "District" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "Dharmapuri" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 64,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Panchayat" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 67,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#002869]", children: "Vedakkattamaduvu" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 68,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 66,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Village / Center" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 71,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "Ammapettai" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Standard (Std)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 75,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "6th - 9th Std (28 Students)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 76,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 74,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Module Covered" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 79,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#fb7800]", children: "Spoken English & Digital Skills" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Duration Dates" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 83,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "Oct 15 - Oct 25, 2023" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 84,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 82,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Lead Volunteer" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 87,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "Bala Murugan (Coordinator)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 88,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-[#747783] uppercase block", children: "Cluster Admin" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 91,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#1a1b21]", children: "Priya Natarajan" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 92,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[16px] font-bold text-[#002869] border-b border-[#c4c6d3]/50 pb-1.5 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#002869]" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 99,
            columnNumber: 13
          }, this),
          "1. Introduction & Program Objectives"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[14px] text-[#1a1b21] leading-relaxed text-justify", children: "The Awareness and Skill Development Program was conducted at Ammapettai Village, Vedakkattamaduvu Panchayat, over a ten-day intensive learning sprint. The primary goal of the intervention is to bridge experiential learning gaps among rural government middle and high school students, equipping them with foundational digital literacy, fluent English conversational habits, and collaborative problem-solving mindset." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[16px] font-bold text-[#002869] border-b border-[#c4c6d3]/50 pb-1.5 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#002869]" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          "2. Skill Enhancement Activities Conducted"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 text-[13px]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f8fafc] p-3.5 rounded-md border border-[#c4c6d3]/50", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-[#002869] mb-1", children: "A. Phonics & Conversational Drills" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 119,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[#434652] leading-snug", children: "Daily 30-minute interactive speaking circles focusing on self-introduction, sentence framing, basic vocabulary cards, and role-playing daily life situations." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 122,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 118,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f8fafc] p-3.5 rounded-md border border-[#c4c6d3]/50", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-[#002869] mb-1", children: "B. Basic Computer & Typing Literacy" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 129,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[#434652] leading-snug", children: "Students practiced laptop touch typing using open-source educational software, learned directory navigation, and created simple document write-ups." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 132,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 128,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f8fafc] p-3.5 rounded-md border border-[#c4c6d3]/50", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-[#002869] mb-1", children: "C. Practical Math Logic & Puzzles" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 139,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[#434652] leading-snug", children: "Hands-on fraction blocks, geometric shape identification with origami sheets, and speed mental math puzzles to boost numerical confidence." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 142,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 138,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f8fafc] p-3.5 rounded-md border border-[#c4c6d3]/50", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-[#002869] mb-1", children: "D. Team Storytelling & Peer Reviews" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 149,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[#434652] leading-snug", children: "Students collaborated in groups of 4 to craft illustrated moral storybooks, presenting their stories aloud to the entire classroom." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 152,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 148,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[16px] font-bold text-[#002869] border-b border-[#c4c6d3]/50 pb-1.5 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#002869]" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 163,
            columnNumber: 13
          }, this),
          "3. Student Progress & Qualitative Observations"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto border border-[#c4c6d3]/60 rounded-md", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-[13px]", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-[#f4f3fb] border-b border-[#c4c6d3] text-[11px] font-bold text-[#434652] uppercase", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "p-3 pl-4", children: "Assessment Metric" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 170,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Baseline (Day 1)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 171,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Endline (Day 10)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 172,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-3 pr-4", children: "Remark / Outcome" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 173,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 169,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 168,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[#c4c6d3]/40", children: [
            /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pl-4 font-bold text-[#1a1b21]", children: "English Conversation" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 178,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-[#ba1a1a]", children: "Hesitant, 22% fluency" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 179,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-bold text-[#137333]", children: "78% Fluency & Eager" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 180,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pr-4 text-[#434652]", children: "High willingness to speak in public" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 181,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 177,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pl-4 font-bold text-[#1a1b21]", children: "Computer Operation" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 184,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-[#ba1a1a]", children: "14% could power/type" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 185,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-bold text-[#137333]", children: "92% Independent typing" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 186,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pr-4 text-[#434652]", children: "Understands keyboard & trackpad" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 187,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 183,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pl-4 font-bold text-[#1a1b21]", children: "Daily Attendance" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 190,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-[#434652]", children: "24 students present" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 191,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-bold text-[#137333]", children: "28 students (100%)" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 192,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 pr-4 text-[#434652]", children: "Zero dropouts during sprint" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 193,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 189,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 176,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 167,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 166,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-[16px] font-bold text-[#002869] border-b border-[#c4c6d3]/50 pb-1.5 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#002869]" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 203,
            columnNumber: 13
          }, this),
          "4. Session Photographs & Field Documentation"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 202,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md overflow-hidden border border-[#c4c6d3]/60 bg-[#f4f3fb]", children: [
            /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=400",
                alt: "Classroom",
                className: "w-full h-32 object-cover",
                referrerPolicy: "no-referrer"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 208,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "p-2 text-[11px] font-medium text-[#434652] leading-tight text-center", children: "Interactive classroom learning" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 214,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 207,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md overflow-hidden border border-[#c4c6d3]/60 bg-[#f4f3fb]", children: [
            /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: "https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=400",
                alt: "Spoken English",
                className: "w-full h-32 object-cover",
                referrerPolicy: "no-referrer"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 219,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "p-2 text-[11px] font-medium text-[#434652] leading-tight text-center", children: "Group phonics speaking drills" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 225,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 218,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md overflow-hidden border border-[#c4c6d3]/60 bg-[#f4f3fb]", children: [
            /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=400",
                alt: "Math Puzzles",
                className: "w-full h-32 object-cover",
                referrerPolicy: "no-referrer"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 230,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "p-2 text-[11px] font-medium text-[#434652] leading-tight text-center", children: "Hands-on geometry worksheets" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 236,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 229,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "rounded-md overflow-hidden border border-[#c4c6d3]/60 bg-[#f4f3fb]", children: [
            /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400",
                alt: "Reading Circle",
                className: "w-full h-32 object-cover",
                referrerPolicy: "no-referrer"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
                lineNumber: 241,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "p-2 text-[11px] font-medium text-[#434652] leading-tight text-center", children: "Storybook reading & peer review" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
              lineNumber: 247,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 240,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 206,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 201,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-6 border-t-2 border-[#002869] grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "h-14 flex items-end justify-center font-serif text-[#002869] italic text-[17px]", children: "Bala Murugan" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 257,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#434652] pt-1 font-bold text-[#1a1b21]", children: "Lead Volunteer Coordinator" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 260,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#747783]", children: "Ammapettai Center" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 263,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 256,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "h-14 flex items-end justify-center font-serif text-[#002869] italic text-[17px]", children: "Priya Natarajan" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 267,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#434652] pt-1 font-bold text-[#1a1b21]", children: "Cluster Administrator" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 270,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#747783]", children: "Dharmapuri Cluster" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 273,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 266,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "h-14 flex items-end justify-center font-serif text-[#002869] italic text-[17px]", children: "R. Soundararajan" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 277,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#434652] pt-1 font-bold text-[#1a1b21]", children: "Headmaster / Panchayat Representative" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 280,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#747783]", children: "Govt Middle School, Ammapettai" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
            lineNumber: 283,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
          lineNumber: 276,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
        lineNumber: 255,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
};
_c = ReportPreviewView;
var _c;
$RefreshReg$(_c, "ReportPreviewView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ReportPreviewView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJVO0FBWEgsYUFBTUEsb0JBQXNEQSxDQUFDO0FBQUEsRUFDbEVDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLCtCQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNBO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRTtBQUFBLFlBQU87QUFBQTtBQUFBO0FBQUEsUUFKM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLE9BQU9DLE1BQU07QUFBQSxZQUM1QixXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQUp0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMsTUFBTSxzQ0FBc0M7QUFBQSxZQUMzRCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FBd0MseUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlFO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGdJQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDRFQUEyRSxzQ0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUscUVBQW9FLHVEQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw2Q0FBNEMsMkRBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNENBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLE1BR3hELHVCQUFDLFNBQUksV0FBVSwySEFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0RBQXVELHdCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLFVBQUssV0FBVSw0QkFBMkIsMEJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsYUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdEQUF1RCx5QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRix1QkFBQyxVQUFLLFdBQVUsNEJBQTJCLGdDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSx3REFBdUQsZ0NBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQiwwQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0RBQXVELDhCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLFVBQUssV0FBVSw0QkFBMkIsMkNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsYUFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdEQUF1RCw4QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRix1QkFBQyxVQUFLLFdBQVUsNEJBQTJCLCtDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLGFBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFVBQUssV0FBVSx3REFBdUQsOEJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQixxQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxhQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0RBQXVELDhCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLFVBQUssV0FBVSw0QkFBMkIsMENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsYUFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdEQUF1RCw2QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxVQUNwRix1QkFBQyxVQUFLLFdBQVUsNEJBQTJCLCtCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9HQUNaO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHVDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQU87QUFBQSxhQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwyREFBMEQsK2FBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxvR0FDWjtBQUFBLGlDQUFDLFVBQUssV0FBVSx1Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUFPO0FBQUEsYUFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUNBQWdDLGtEQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLDZLQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUNBQWdDLG1EQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLG1LQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUNBQWdDLGlEQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLDBKQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsaUNBQWdDLG1EQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLG1KQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBLFdBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9HQUNaO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHVDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQU87QUFBQSxhQUQ3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5REFDYixpQ0FBQyxXQUFNLFdBQVUsZ0RBQ2Y7QUFBQSxpQ0FBQyxXQUFNLFdBQVUseUZBQ2YsaUNBQUMsUUFDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxZQUFXLGlDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQzFDLHVCQUFDLFFBQUcsV0FBVSxPQUFNLGdDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQ3BDLHVCQUFDLFFBQUcsV0FBVSxPQUFNLGdDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQ3BDLHVCQUFDLFFBQUcsV0FBVSxZQUFXLGdDQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLGVBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsZ0NBQ2Y7QUFBQSxtQ0FBQyxRQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLHFDQUFvQyxvQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxjQUN0RSx1QkFBQyxRQUFHLFdBQVUsc0JBQXFCLHFDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQ3hELHVCQUFDLFFBQUcsV0FBVSxnQ0FBK0IsbUNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsUUFBRyxXQUFVLDJCQUEwQixtREFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkU7QUFBQSxpQkFKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsUUFDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxxQ0FBb0Msa0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsUUFBRyxXQUFVLHNCQUFxQixvQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUN2RCx1QkFBQyxRQUFHLFdBQVUsZ0NBQStCLHNDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLFFBQUcsV0FBVSwyQkFBMEIsK0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsaUJBSjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUscUNBQW9DLGdDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLFFBQUcsV0FBVSxzQkFBcUIsbUNBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsY0FDdEQsdUJBQUMsUUFBRyxXQUFVLGdDQUErQixrQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxjQUMvRCx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCLDJDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGlCQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBLEtBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxXQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxvR0FDWjtBQUFBLGlDQUFDLFVBQUssV0FBVSx1Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUFPO0FBQUEsYUFEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osV0FBVTtBQUFBLGdCQUNWLGdCQUFlO0FBQUE7QUFBQSxjQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJOEI7QUFBQSxZQUU5Qix1QkFBQyxPQUFFLFdBQVUsd0VBQXVFLDhDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osV0FBVTtBQUFBLGdCQUNWLGdCQUFlO0FBQUE7QUFBQSxjQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJOEI7QUFBQSxZQUU5Qix1QkFBQyxPQUFFLFdBQVUsd0VBQXVFLDZDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osV0FBVTtBQUFBLGdCQUNWLGdCQUFlO0FBQUE7QUFBQSxjQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJOEI7QUFBQSxZQUU5Qix1QkFBQyxPQUFFLFdBQVUsd0VBQXVFLDRDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUk7QUFBQSxnQkFDSixLQUFJO0FBQUEsZ0JBQ0osV0FBVTtBQUFBLGdCQUNWLGdCQUFlO0FBQUE7QUFBQSxjQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJOEI7QUFBQSxZQUU5Qix1QkFBQyxPQUFFLFdBQVUsd0VBQXVFLCtDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFdBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtREE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUZBQWtGLDRCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQTBELDBDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsOEJBQTZCLGlDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBUGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSxtRkFBa0YsK0JBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyREFBMEQscUNBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFBNkIsa0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsYUFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1GQUFrRixnQ0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUEwRCxxREFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDhCQUE2Qiw4Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkU7QUFBQSxhQVA3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsU0FsUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1QQTtBQUFBLE9BalJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrUkE7QUFFSjtBQUFFQyxLQXhSV0w7QUFBbUQsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUmVwb3J0UHJldmlld1ZpZXciLCJvbkJhY2siLCJ3aW5kb3ciLCJwcmludCIsImFsZXJ0IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVwb3J0UHJldmlld1ZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFRhYlR5cGUgfSBmcm9tICcuLi90eXBlcyc7XHJcblxyXG5pbnRlcmZhY2UgUmVwb3J0UHJldmlld1ZpZXdQcm9wcyB7XHJcbiAgb25CYWNrOiAoKSA9PiB2b2lkO1xyXG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBSZXBvcnRQcmV2aWV3VmlldzogUmVhY3QuRkM8UmVwb3J0UHJldmlld1ZpZXdQcm9wcz4gPSAoe1xyXG4gIG9uQmFjayxcclxufSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy01eGwgbXgtYXV0b1wiPlxyXG4gICAgICB7LyogVG9wIEFjdGlvbiBCYXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17b25CYWNrfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+YXJyb3dfYmFjazwvc3Bhbj5cclxuICAgICAgICAgIEJhY2sgdG8gUmVwb3J0cyBMaXN0XHJcbiAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LnByaW50KCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTNweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjMDAyODY5XS85MCBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+cHJpbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgIFByaW50IC8gU2F2ZSBQREZcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBhbGVydCgnRWRpdGluZyByZXBvcnQgZHJhZnQgbW9kZSBhY3RpdmF0ZWQuJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIGJvcmRlciBib3JkZXItWyMwMDI4NjldIHRleHQtWyMwMDI4NjldIHJvdW5kZWQtbWQgdGV4dC1bMTNweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjZjRmM2ZiXSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF1cIj5lZGl0X25vdGU8L3NwYW4+XHJcbiAgICAgICAgICAgIEVkaXQgUmVwb3J0XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogT2ZmaWNpYWwgVFFJIEFjdGl2aXR5IFJlcG9ydCBEb2N1bWVudCAoTWF0Y2hpbmcgSW1hZ2UgMjMgJiBIVE1MIDIzKSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdLzgwIHAtNiBtZDpwLTEwIHNoYWRvdy1zbSBzcGFjZS15LTggcHJpbnQ6Ym9yZGVyLW5vbmUgcHJpbnQ6c2hhZG93LW5vbmUgcHJpbnQ6cC0wXCI+XHJcbiAgICAgICAgey8qIFRpdGxlICYgT3JnYW5pemF0aW9uIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHBiLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+XHJcbiAgICAgICAgICAgIFRBTEVOVCBRVUVTVCBGT1IgSU5ESUFcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIG1kOnRleHQtWzI1cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgIEF3YXJlbmVzcyBhbmQgU2tpbGwgRGV2ZWxvcG1lbnQgUHJvZ3JhbVxyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjZmI3ODAwXSBtdC0xXCI+XHJcbiAgICAgICAgICAgIEFjYWRlbWljIFllYXIgKDIwMjMgLSAyMDI0KSBBY3Rpdml0eSBSZXBvcnRcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEJsdWUgU2VwYXJhdG9yIExpbmUgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEuNSBiZy1bIzAwMjg2OV0gcm91bmRlZC1mdWxsIHctZnVsbFwiPjwvZGl2PlxyXG5cclxuICAgICAgICB7LyogTWV0YWRhdGEgRGV0YWlscyBUYWJsZSAvIEdyaWQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI2Y0ZjNmYl0gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10vNjAgcm91bmRlZC1tZCBwLTUgZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBtZDpncmlkLWNvbHMtNCBnYXAtNCB0ZXh0LVsxM3B4XVwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSBibG9ja1wiPkRpc3RyaWN0PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj5EaGFybWFwdXJpPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIGJsb2NrXCI+UGFuY2hheWF0PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj5WZWRha2thdHRhbWFkdXZ1PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIGJsb2NrXCI+VmlsbGFnZSAvIENlbnRlcjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMxYTFiMjFdXCI+QW1tYXBldHRhaTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSBibG9ja1wiPlN0YW5kYXJkIChTdGQpPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj42dGggLSA5dGggU3RkICgyOCBTdHVkZW50cyk8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNzQ3NzgzXSB1cHBlcmNhc2UgYmxvY2tcIj5Nb2R1bGUgQ292ZXJlZDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyNmYjc4MDBdXCI+U3Bva2VuIEVuZ2xpc2ggJmFtcDsgRGlnaXRhbCBTa2lsbHM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNzQ3NzgzXSB1cHBlcmNhc2UgYmxvY2tcIj5EdXJhdGlvbiBEYXRlczwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMxYTFiMjFdXCI+T2N0IDE1IC0gT2N0IDI1LCAyMDIzPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIGJsb2NrXCI+TGVhZCBWb2x1bnRlZXI8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjMWExYjIxXVwiPkJhbGEgTXVydWdhbiAoQ29vcmRpbmF0b3IpPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIGJsb2NrXCI+Q2x1c3RlciBBZG1pbjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMxYTFiMjFdXCI+UHJpeWEgTmF0YXJhamFuPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTZWN0aW9uIDE6IEludHJvZHVjdGlvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdLzUwIHBiLTEuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1bIzAwMjg2OV1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgIDEuIEludHJvZHVjdGlvbiAmYW1wOyBQcm9ncmFtIE9iamVjdGl2ZXNcclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxNHB4XSB0ZXh0LVsjMWExYjIxXSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1qdXN0aWZ5XCI+XHJcbiAgICAgICAgICAgIFRoZSBBd2FyZW5lc3MgYW5kIFNraWxsIERldmVsb3BtZW50IFByb2dyYW0gd2FzIGNvbmR1Y3RlZCBhdCBBbW1hcGV0dGFpIFZpbGxhZ2UsXHJcbiAgICAgICAgICAgIFZlZGFra2F0dGFtYWR1dnUgUGFuY2hheWF0LCBvdmVyIGEgdGVuLWRheSBpbnRlbnNpdmUgbGVhcm5pbmcgc3ByaW50LiBUaGUgcHJpbWFyeSBnb2FsIG9mXHJcbiAgICAgICAgICAgIHRoZSBpbnRlcnZlbnRpb24gaXMgdG8gYnJpZGdlIGV4cGVyaWVudGlhbCBsZWFybmluZyBnYXBzIGFtb25nIHJ1cmFsIGdvdmVybm1lbnQgbWlkZGxlXHJcbiAgICAgICAgICAgIGFuZCBoaWdoIHNjaG9vbCBzdHVkZW50cywgZXF1aXBwaW5nIHRoZW0gd2l0aCBmb3VuZGF0aW9uYWwgZGlnaXRhbCBsaXRlcmFjeSwgZmx1ZW50XHJcbiAgICAgICAgICAgIEVuZ2xpc2ggY29udmVyc2F0aW9uYWwgaGFiaXRzLCBhbmQgY29sbGFib3JhdGl2ZSBwcm9ibGVtLXNvbHZpbmcgbWluZHNldC5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFNlY3Rpb24gMjogU2tpbGwgRW5oYW5jZW1lbnQgQWN0aXZpdGllcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdLzUwIHBiLTEuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1bIzAwMjg2OV1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgIDIuIFNraWxsIEVuaGFuY2VtZW50IEFjdGl2aXRpZXMgQ29uZHVjdGVkXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zIHRleHQtWzEzcHhdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNmOGZhZmNdIHAtMy41IHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10vNTBcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEEuIFBob25pY3MgJmFtcDsgQ29udmVyc2F0aW9uYWwgRHJpbGxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsjNDM0NjUyXSBsZWFkaW5nLXNudWdcIj5cclxuICAgICAgICAgICAgICAgIERhaWx5IDMwLW1pbnV0ZSBpbnRlcmFjdGl2ZSBzcGVha2luZyBjaXJjbGVzIGZvY3VzaW5nIG9uIHNlbGYtaW50cm9kdWN0aW9uLCBzZW50ZW5jZVxyXG4gICAgICAgICAgICAgICAgZnJhbWluZywgYmFzaWMgdm9jYWJ1bGFyeSBjYXJkcywgYW5kIHJvbGUtcGxheWluZyBkYWlseSBsaWZlIHNpdHVhdGlvbnMuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNmOGZhZmNdIHAtMy41IHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10vNTBcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEIuIEJhc2ljIENvbXB1dGVyICZhbXA7IFR5cGluZyBMaXRlcmFjeVxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bIzQzNDY1Ml0gbGVhZGluZy1zbnVnXCI+XHJcbiAgICAgICAgICAgICAgICBTdHVkZW50cyBwcmFjdGljZWQgbGFwdG9wIHRvdWNoIHR5cGluZyB1c2luZyBvcGVuLXNvdXJjZSBlZHVjYXRpb25hbCBzb2Z0d2FyZSxcclxuICAgICAgICAgICAgICAgIGxlYXJuZWQgZGlyZWN0b3J5IG5hdmlnYXRpb24sIGFuZCBjcmVhdGVkIHNpbXBsZSBkb2N1bWVudCB3cml0ZS11cHMuXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNmOGZhZmNdIHAtMy41IHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10vNTBcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEMuIFByYWN0aWNhbCBNYXRoIExvZ2ljICZhbXA7IFB1enpsZXNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWyM0MzQ2NTJdIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgSGFuZHMtb24gZnJhY3Rpb24gYmxvY2tzLCBnZW9tZXRyaWMgc2hhcGUgaWRlbnRpZmljYXRpb24gd2l0aCBvcmlnYW1pIHNoZWV0cywgYW5kXHJcbiAgICAgICAgICAgICAgICBzcGVlZCBtZW50YWwgbWF0aCBwdXp6bGVzIHRvIGJvb3N0IG51bWVyaWNhbCBjb25maWRlbmNlLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjZjhmYWZjXSBwLTMuNSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdLzUwXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBELiBUZWFtIFN0b3J5dGVsbGluZyAmYW1wOyBQZWVyIFJldmlld3NcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWyM0MzQ2NTJdIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgU3R1ZGVudHMgY29sbGFib3JhdGVkIGluIGdyb3VwcyBvZiA0IHRvIGNyYWZ0IGlsbHVzdHJhdGVkIG1vcmFsIHN0b3J5Ym9va3MsIHByZXNlbnRpbmdcclxuICAgICAgICAgICAgICAgIHRoZWlyIHN0b3JpZXMgYWxvdWQgdG8gdGhlIGVudGlyZSBjbGFzc3Jvb20uXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU2VjdGlvbiAzOiBTdHVkZW50IEZlZWRiYWNrICYgT2JzZXJ2YXRpb25zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGJvcmRlci1iIGJvcmRlci1bI2M0YzZkM10vNTAgcGItMS41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLVsjMDAyODY5XVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgMy4gU3R1ZGVudCBQcm9ncmVzcyAmYW1wOyBRdWFsaXRhdGl2ZSBPYnNlcnZhdGlvbnNcclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS82MCByb3VuZGVkLW1kXCI+XHJcbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IGJvcmRlci1jb2xsYXBzZSB0ZXh0LVsxM3B4XVwiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1bI2Y0ZjNmYl0gYm9yZGVyLWIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgcGwtNFwiPkFzc2Vzc21lbnQgTWV0cmljPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtM1wiPkJhc2VsaW5lIChEYXkgMSk8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zXCI+RW5kbGluZSAoRGF5IDEwKTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgcHItNFwiPlJlbWFyayAvIE91dGNvbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtWyNjNGM2ZDNdLzQwXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgcGwtNCBmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj5FbmdsaXNoIENvbnZlcnNhdGlvbjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1bI2JhMWExYV1cIj5IZXNpdGFudCwgMjIlIGZsdWVuY3k8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCB0ZXh0LVsjMTM3MzMzXVwiPjc4JSBGbHVlbmN5ICZhbXA7IEVhZ2VyPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyBwci00IHRleHQtWyM0MzQ2NTJdXCI+SGlnaCB3aWxsaW5nbmVzcyB0byBzcGVhayBpbiBwdWJsaWM8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyBwbC00IGZvbnQtYm9sZCB0ZXh0LVsjMWExYjIxXVwiPkNvbXB1dGVyIE9wZXJhdGlvbjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC1bI2JhMWExYV1cIj4xNCUgY291bGQgcG93ZXIvdHlwZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgZm9udC1ib2xkIHRleHQtWyMxMzczMzNdXCI+OTIlIEluZGVwZW5kZW50IHR5cGluZzwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgcHItNCB0ZXh0LVsjNDM0NjUyXVwiPlVuZGVyc3RhbmRzIGtleWJvYXJkICZhbXA7IHRyYWNrcGFkPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgcGwtNCBmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj5EYWlseSBBdHRlbmRhbmNlPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LVsjNDM0NjUyXVwiPjI0IHN0dWRlbnRzIHByZXNlbnQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtYm9sZCB0ZXh0LVsjMTM3MzMzXVwiPjI4IHN0dWRlbnRzICgxMDAlKTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgcHItNCB0ZXh0LVsjNDM0NjUyXVwiPlplcm8gZHJvcG91dHMgZHVyaW5nIHNwcmludDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFNlY3Rpb24gNDogU2Vzc2lvbiBQaG90b2dyYXBocyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdLzUwIHBiLTEuNSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1bIzAwMjg2OV1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgIDQuIFNlc3Npb24gUGhvdG9ncmFwaHMgJmFtcDsgRmllbGQgRG9jdW1lbnRhdGlvblxyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdLzYwIGJnLVsjZjRmM2ZiXVwiPlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTA5MDYyNTIyMjQ2LTM3NTU5Nzc5MjdkNz9hdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJnc9NDAwXCJcclxuICAgICAgICAgICAgICAgIGFsdD1cIkNsYXNzcm9vbVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0zMiBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTIgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1bIzQzNDY1Ml0gbGVhZGluZy10aWdodCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgSW50ZXJhY3RpdmUgY2xhc3Nyb29tIGxlYXJuaW5nXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS82MCBiZy1bI2Y0ZjNmYl1cIj5cclxuICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICBzcmM9XCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU3Nzg5Njg1MTIzMS03MGVmMTg4ODE3NTQ/YXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCZ3PTQwMFwiXHJcbiAgICAgICAgICAgICAgICBhbHQ9XCJTcG9rZW4gRW5nbGlzaFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0zMiBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTIgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1bIzQzNDY1Ml0gbGVhZGluZy10aWdodCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgR3JvdXAgcGhvbmljcyBzcGVha2luZyBkcmlsbHNcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdLzYwIGJnLVsjZjRmM2ZiXVwiPlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIHNyYz1cImh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTAzNjc2MjYwNzI4LTFjMDBkYTA5NGEwYj9hdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJnc9NDAwXCJcclxuICAgICAgICAgICAgICAgIGFsdD1cIk1hdGggUHV6emxlc1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0zMiBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJwLTIgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1bIzQzNDY1Ml0gbGVhZGluZy10aWdodCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgSGFuZHMtb24gZ2VvbWV0cnkgd29ya3NoZWV0c1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1tZCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10vNjAgYmctWyNmNGYzZmJdXCI+XHJcbiAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE0OTc2MzM3NjIyNjUtOWQxNzlhOTkwYWE2P2F1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAmdz00MDBcIlxyXG4gICAgICAgICAgICAgICAgYWx0PVwiUmVhZGluZyBDaXJjbGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMzIgb2JqZWN0LWNvdmVyXCJcclxuICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicC0yIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtWyM0MzQ2NTJdIGxlYWRpbmctdGlnaHQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIFN0b3J5Ym9vayByZWFkaW5nICZhbXA7IHBlZXIgcmV2aWV3XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU2VjdGlvbiA1OiBWZXJpZmljYXRpb24gJiBTaWduYXR1cmVzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNiBib3JkZXItdC0yIGJvcmRlci1bIzAwMjg2OV0gZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNiB0ZXh0LWNlbnRlciB0ZXh0LVsxM3B4XVwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTE0IGZsZXggaXRlbXMtZW5kIGp1c3RpZnktY2VudGVyIGZvbnQtc2VyaWYgdGV4dC1bIzAwMjg2OV0gaXRhbGljIHRleHQtWzE3cHhdXCI+XHJcbiAgICAgICAgICAgICAgQmFsYSBNdXJ1Z2FuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1bIzQzNDY1Ml0gcHQtMSBmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj5cclxuICAgICAgICAgICAgICBMZWFkIFZvbHVudGVlciBDb29yZGluYXRvclxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzc0Nzc4M11cIj5BbW1hcGV0dGFpIENlbnRlcjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNCBmbGV4IGl0ZW1zLWVuZCBqdXN0aWZ5LWNlbnRlciBmb250LXNlcmlmIHRleHQtWyMwMDI4NjldIGl0YWxpYyB0ZXh0LVsxN3B4XVwiPlxyXG4gICAgICAgICAgICAgIFByaXlhIE5hdGFyYWphblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItWyM0MzQ2NTJdIHB0LTEgZm9udC1ib2xkIHRleHQtWyMxYTFiMjFdXCI+XHJcbiAgICAgICAgICAgICAgQ2x1c3RlciBBZG1pbmlzdHJhdG9yXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzQ3NzgzXVwiPkRoYXJtYXB1cmkgQ2x1c3Rlcjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xNCBmbGV4IGl0ZW1zLWVuZCBqdXN0aWZ5LWNlbnRlciBmb250LXNlcmlmIHRleHQtWyMwMDI4NjldIGl0YWxpYyB0ZXh0LVsxN3B4XVwiPlxyXG4gICAgICAgICAgICAgIFIuIFNvdW5kYXJhcmFqYW5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLVsjNDM0NjUyXSBwdC0xIGZvbnQtYm9sZCB0ZXh0LVsjMWExYjIxXVwiPlxyXG4gICAgICAgICAgICAgIEhlYWRtYXN0ZXIgLyBQYW5jaGF5YXQgUmVwcmVzZW50YXRpdmVcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyM3NDc3ODNdXCI+R292dCBNaWRkbGUgU2Nob29sLCBBbW1hcGV0dGFpPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9SZXBvcnRQcmV2aWV3Vmlldy50c3gifQ==