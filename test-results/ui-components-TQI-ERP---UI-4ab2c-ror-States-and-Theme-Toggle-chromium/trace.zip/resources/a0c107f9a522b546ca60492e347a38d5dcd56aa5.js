import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FinanceStatementView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=8975830d";
import { TqiLogo } from "/src/components/TqiLogo.tsx";
import { generateAndDownloadStatementPDF } from "/src/utils/pdfGenerator.ts";
import { checkImageClarity, extractRouteAndDetailsFromText } from "/src/utils/billParser.ts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const FinanceStatementView = ({
  onBack,
  onNavigate,
  entries = [],
  drafts = [],
  activeDraftId,
  clusterName = "Dharmapuri",
  collegeName = "K.S.Rangasamy college of Technology",
  spocName = "Narendhar",
  financerName = "TQI Finance Team",
  sessionDay = "Day 2",
  date = "2026-08-20",
  onSaveDraft,
  onDeleteDraft,
  onSubmitDraft,
  onAddFinanceEntry,
  onUpdateFinanceEntry,
  onDeleteFinanceEntry
}) => {
  _s();
  const [selectedViewKey, setSelectedViewKey] = useState(
    activeDraftId || (drafts.length > 0 ? drafts[0].id : "all-approved")
  );
  const [activeBillViewer, setActiveBillViewer] = useState(null);
  const [billZoom, setBillZoom] = useState(1);
  const [billRotate, setBillRotate] = useState(0);
  const [editingItem, setEditingItem] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newExpenseForm, setNewExpenseForm] = useState({
    category: "Travel",
    description: "",
    count: "",
    perPerson: "",
    totalAmount: "",
    remarks: "",
    billUrl: null,
    billFileName: ""
  });
  const [showEditMetaModal, setShowEditMetaModal] = useState(false);
  const [metaForm, setMetaForm] = useState({
    collegeName,
    clusterName,
    sessionName: "Day 2 - Travel & Refreshments Sheet",
    sessionDay,
    date,
    spocName,
    financerName
  });
  const [showFullStatementModal, setShowFullStatementModal] = useState(false);
  const [showAllBillsModal, setShowAllBillsModal] = useState(false);
  const [activeGalleryIndex, setActiveGalleryIndex] = useState(0);
  const [toastMessage, setToastMessage] = useState(null);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3e3);
  };
  const currentDraft = useMemo(() => {
    return drafts.find((d) => d.id === selectedViewKey) || null;
  }, [drafts, selectedViewKey]);
  const statementMeta = useMemo(() => {
    if (currentDraft) {
      return {
        collegeName: currentDraft.collegeName || collegeName,
        clusterName: currentDraft.clusterName || clusterName,
        sessionName: currentDraft.title,
        sessionDay: currentDraft.sessionDay || sessionDay,
        date: currentDraft.sessionDate || date,
        spocName: currentDraft.spocName || spocName,
        financerName: currentDraft.financerName || financerName,
        isDraft: true,
        status: currentDraft.status || "Draft"
      };
    }
    if (selectedViewKey === "all-approved") {
      return {
        collegeName,
        clusterName,
        sessionName: "Combined Cluster Finance Statement",
        sessionDay: "All Sessions",
        date,
        spocName,
        financerName,
        isDraft: false,
        status: "Approved"
      };
    }
    return {
      collegeName,
      clusterName,
      sessionName: `${selectedViewKey} Finance Statement`,
      sessionDay: selectedViewKey,
      date,
      spocName,
      financerName,
      isDraft: false,
      status: "Approved"
    };
  }, [currentDraft, selectedViewKey, collegeName, clusterName, sessionDay, date, spocName, financerName]);
  React.useEffect(() => {
    setMetaForm({
      collegeName: statementMeta.collegeName,
      clusterName: statementMeta.clusterName,
      sessionName: statementMeta.sessionName,
      sessionDay: statementMeta.sessionDay,
      date: statementMeta.date,
      spocName: statementMeta.spocName,
      financerName: statementMeta.financerName
    });
  }, [statementMeta, selectedViewKey]);
  const tableItems = useMemo(() => {
    if (currentDraft) {
      const items = [];
      let sNo = 1;
      if (currentDraft.routes) {
        currentDraft.routes.forEach((r, idx) => {
          const total = (r.volunteers || 0) * (r.perPerson || 0);
          items.push({
            id: r.id || `route-${idx}`,
            sNo: sNo++,
            category: "Travel",
            description: `${r.from || "Origin"} → ${r.to || "Destination"}`,
            count: r.volunteers ? String(r.volunteers) : "—",
            countAmount: r.volunteers && r.perPerson ? `${r.volunteers}×${r.perPerson}` : "—",
            total,
            billUrl: r.bill?.url || "https://images.unsplash.com/photo-1554415707-9e49fe74a6d0?w=600&auto=format&fit=crop&q=80",
            billFileName: r.bill?.fileName || "Travel_Tickets.jpg",
            remarks: r.remarks || "Bus / Auto transportation for volunteers",
            rawType: "route",
            rawId: r.id
          });
        });
      }
      if (currentDraft.food) {
        if (currentDraft.food.breakfast && (currentDraft.food.breakfast.amount > 0 || currentDraft.food.breakfast.remarks)) {
          items.push({
            id: "food-breakfast",
            sNo: sNo++,
            category: "Food",
            description: "Breakfast",
            count: "—",
            countAmount: "—",
            total: currentDraft.food.breakfast.amount || 0,
            billUrl: currentDraft.food.breakfast.bill?.url || "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80",
            billFileName: currentDraft.food.breakfast.bill?.fileName || "Breakfast_Bill.jpg",
            remarks: currentDraft.food.breakfast.remarks || "Tiffin & Tea for volunteers at Annapoorna hotel",
            rawType: "food",
            foodKey: "breakfast"
          });
        }
        if (currentDraft.food.lunch && (currentDraft.food.lunch.amount > 0 || currentDraft.food.lunch.remarks)) {
          items.push({
            id: "food-lunch",
            sNo: sNo++,
            category: "Food",
            description: "Lunch",
            count: "—",
            countAmount: "—",
            total: currentDraft.food.lunch.amount || 0,
            billUrl: currentDraft.food.lunch.bill?.url || "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80",
            billFileName: currentDraft.food.lunch.bill?.fileName || "Lunch_Receipt.jpg",
            remarks: currentDraft.food.lunch.remarks || "Meals packet allowance",
            rawType: "food",
            foodKey: "lunch"
          });
        }
        if (currentDraft.food.dinner && (currentDraft.food.dinner.amount > 0 || currentDraft.food.dinner.remarks)) {
          items.push({
            id: "food-dinner",
            sNo: sNo++,
            category: "Food",
            description: "Dinner",
            count: "—",
            countAmount: "—",
            total: currentDraft.food.dinner.amount || 0,
            billUrl: currentDraft.food.dinner.bill?.url || null,
            billFileName: currentDraft.food.dinner.bill?.fileName || "Dinner_Receipt.jpg",
            remarks: currentDraft.food.dinner.remarks || "Volunteer dinner",
            rawType: "food",
            foodKey: "dinner"
          });
        }
        if (currentDraft.food.refreshments && (currentDraft.food.refreshments.amount > 0 || currentDraft.food.refreshments.remarks)) {
          items.push({
            id: "food-refreshments",
            sNo: sNo++,
            category: "Food",
            description: "Refreshments & Tea",
            count: "—",
            countAmount: "—",
            total: currentDraft.food.refreshments.amount || 0,
            billUrl: currentDraft.food.refreshments.bill?.url || null,
            billFileName: currentDraft.food.refreshments.bill?.fileName || "Tea_Snacks_Bill.jpg",
            remarks: currentDraft.food.refreshments.remarks || "Tea and evening snacks",
            rawType: "food",
            foodKey: "refreshments"
          });
        }
      }
      if (currentDraft.stationery && (currentDraft.stationery.amount > 0 || currentDraft.stationery.remarks)) {
        items.push({
          id: "stationery-main",
          sNo: sNo++,
          category: "Stationery",
          description: "Materials & Notebooks",
          count: "—",
          countAmount: "—",
          total: currentDraft.stationery.amount || 0,
          billUrl: currentDraft.stationery.bill?.url || null,
          billFileName: currentDraft.stationery.bill?.fileName || "Stationery_Bill.jpg",
          remarks: currentDraft.stationery.remarks || "Chart papers, markers and activity kits",
          rawType: "stationery"
        });
      }
      if (currentDraft.otherItems) {
        currentDraft.otherItems.forEach((ot, idx) => {
          if (ot.amount > 0 || ot.description || ot.remarks) {
            items.push({
              id: ot.id || `other-${idx}`,
              sNo: sNo++,
              category: "Other",
              description: ot.description || "First Aid Kit & Water Cans",
              count: "—",
              countAmount: "—",
              total: ot.amount || 0,
              billUrl: ot.bill?.url || null,
              billFileName: ot.bill?.fileName || "Other_Expense_Slip.jpg",
              remarks: ot.remarks || "—",
              rawType: "other",
              rawId: ot.id
            });
          }
        });
      }
      return items;
    }
    const sourceEntries = selectedViewKey === "all-approved" ? entries.filter((e) => e.status === "Approved") : entries.filter((e) => e.sessionDay === selectedViewKey || e.status === "Approved");
    if (sourceEntries.length === 0) {
      return [
        {
          id: "mock-1",
          sNo: 1,
          category: "Travel",
          description: "KSR College → Salem / Ammapettai",
          count: "20",
          countAmount: "20×10",
          total: 200,
          billUrl: "https://images.unsplash.com/photo-1554415707-9e49fe74a6d0?w=600&auto=format&fit=crop&q=80",
          billFileName: "Bus_Pass_KSR.jpg",
          remarks: "Bus transportation for 20 volunteers",
          rawType: "entry"
        },
        {
          id: "mock-2",
          sNo: 2,
          category: "Food",
          description: "Breakfast",
          count: "—",
          countAmount: "—",
          total: 1e3,
          billUrl: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80",
          billFileName: "Annapoorna_Breakfast.jpg",
          remarks: "Tiffin & Tea for 20 volunteers at Annapoorna hotel",
          rawType: "entry"
        },
        {
          id: "mock-3",
          sNo: 3,
          category: "Food",
          description: "Lunch",
          count: "—",
          countAmount: "—",
          total: 500,
          billUrl: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80",
          billFileName: "Lunch_Packet_Slip.jpg",
          remarks: "Meals packet allowance",
          rawType: "entry"
        },
        {
          id: "mock-4",
          sNo: 4,
          category: "Other",
          description: "First Aid Kit & Water Cans",
          count: "—",
          countAmount: "—",
          total: 0,
          billUrl: null,
          billFileName: "",
          remarks: "—",
          rawType: "entry"
        }
      ];
    }
    return sourceEntries.map((e, idx) => ({
      id: e.id,
      sNo: idx + 1,
      category: e.category,
      description: e.description,
      count: e.count ? String(e.count) : "—",
      countAmount: e.countAmount || "—",
      total: e.amount,
      billUrl: e.billUrl || "https://images.unsplash.com/photo-1554415707-9e49fe74a6d0?w=600&auto=format&fit=crop&q=80",
      billFileName: "Receipt_Voucher.jpg",
      remarks: e.remarks || "—",
      rawType: "entry",
      rawId: e.id
    }));
  }, [currentDraft, selectedViewKey, entries]);
  const travelTotal = useMemo(() => {
    return tableItems.filter((i) => i.category === "Travel").reduce((sum, i) => sum + i.total, 0);
  }, [tableItems]);
  const foodTotal = useMemo(() => {
    return tableItems.filter((i) => i.category === "Food").reduce((sum, i) => sum + i.total, 0);
  }, [tableItems]);
  const stationeryTotal = useMemo(() => {
    return tableItems.filter((i) => i.category === "Stationery" || i.category === "Materials").reduce((sum, i) => sum + i.total, 0);
  }, [tableItems]);
  const otherTotal = useMemo(() => {
    return tableItems.filter((i) => i.category === "Other" || i.category === "Admin").reduce((sum, i) => sum + i.total, 0);
  }, [tableItems]);
  const grandTotal = travelTotal + foodTotal + stationeryTotal + otherTotal;
  const allAttachedBills = useMemo(() => {
    return tableItems.filter((item) => item.billUrl).map((item) => ({
      id: item.id || `bill-${item.sNo}`,
      url: item.billUrl,
      title: `${item.category}: ${item.description}`,
      category: item.category,
      amount: item.total,
      remarks: item.remarks,
      fileName: item.billFileName || `${item.category}_Receipt.jpg`
    }));
  }, [tableItems]);
  const handleSubmitStatement = () => {
    if (currentDraft && onSubmitDraft) {
      onSubmitDraft(currentDraft.id);
      showToast(`Finance Statement for "${statementMeta.sessionDay}" submitted for review!`);
    } else {
      showToast("Finance statement submitted to TQI Finance Team successfully!");
    }
  };
  const handleDeleteRow = (item) => {
    if (!confirm(`Are you sure you want to delete "${item.description}"?`)) return;
    if (currentDraft && onSaveDraft) {
      let updatedDraft = { ...currentDraft };
      if (item.rawType === "route" && item.rawId) {
        updatedDraft.routes = updatedDraft.routes.filter((r) => r.id !== item.rawId);
      } else if (item.rawType === "food" && item.foodKey) {
        updatedDraft.food = {
          ...updatedDraft.food,
          [item.foodKey]: { amount: 0, remarks: "", bill: null }
        };
      } else if (item.rawType === "stationery") {
        updatedDraft.stationery = { amount: 0, remarks: "", bill: null };
      } else if (item.rawType === "other" && item.rawId) {
        updatedDraft.otherItems = updatedDraft.otherItems.filter((ot) => ot.id !== item.rawId);
      }
      const newTravel = updatedDraft.routes.reduce((s, r) => s + (r.volunteers || 0) * (r.perPerson || 0), 0);
      const newFood = (updatedDraft.food.breakfast?.amount || 0) + (updatedDraft.food.lunch?.amount || 0) + (updatedDraft.food.dinner?.amount || 0) + (updatedDraft.food.refreshments?.amount || 0);
      const newStationery = updatedDraft.stationery?.amount || 0;
      const newOther = updatedDraft.otherItems.reduce((s, o) => s + (o.amount || 0), 0);
      updatedDraft.totalAmount = newTravel + newFood + newStationery + newOther;
      onSaveDraft(updatedDraft);
      showToast(`Deleted "${item.description}"`);
    } else if (item.rawType === "entry" && item.rawId && onDeleteFinanceEntry) {
      onDeleteFinanceEntry(item.rawId);
      showToast(`Deleted "${item.description}"`);
    } else {
      showToast(`Item removed from view.`);
    }
  };
  const handleSaveEditedRow = () => {
    if (!editingItem) return;
    if (currentDraft && onSaveDraft) {
      const updatedDraft = { ...currentDraft };
      if (editingItem.rawType === "route" && editingItem.rawId) {
        const vols = parseInt(editingItem.count) || 0;
        let perP = 0;
        if (editingItem.countAmount.includes("×")) {
          perP = parseFloat(editingItem.countAmount.split("×")[1]) || 0;
        } else if (vols > 0) {
          perP = editingItem.total / vols;
        }
        const parts = editingItem.description.split("→");
        const from = parts[0]?.trim() || "Origin";
        const to = parts[1]?.trim() || "Destination";
        updatedDraft.routes = updatedDraft.routes.map(
          (r) => r.id === editingItem.rawId ? {
            ...r,
            from,
            to,
            volunteers: vols,
            perPerson: perP,
            remarks: editingItem.remarks,
            bill: editingItem.billUrl ? {
              url: editingItem.billUrl,
              fileName: editingItem.billFileName || "Travel_Bill.jpg",
              detectedAmount: editingItem.total
            } : null
          } : r
        );
      } else if (editingItem.rawType === "food" && editingItem.foodKey) {
        updatedDraft.food = {
          ...updatedDraft.food,
          [editingItem.foodKey]: {
            amount: editingItem.total,
            remarks: editingItem.remarks,
            bill: editingItem.billUrl ? {
              url: editingItem.billUrl,
              fileName: editingItem.billFileName || "Food_Bill.jpg",
              detectedAmount: editingItem.total
            } : null
          }
        };
      } else if (editingItem.rawType === "stationery") {
        updatedDraft.stationery = {
          amount: editingItem.total,
          remarks: editingItem.remarks,
          bill: editingItem.billUrl ? {
            url: editingItem.billUrl,
            fileName: editingItem.billFileName || "Stationery_Bill.jpg",
            detectedAmount: editingItem.total
          } : null
        };
      } else if (editingItem.rawType === "other" && editingItem.rawId) {
        updatedDraft.otherItems = updatedDraft.otherItems.map(
          (ot) => ot.id === editingItem.rawId ? {
            ...ot,
            description: editingItem.description,
            amount: editingItem.total,
            remarks: editingItem.remarks,
            bill: editingItem.billUrl ? {
              url: editingItem.billUrl,
              fileName: editingItem.billFileName || "Other_Bill.jpg",
              detectedAmount: editingItem.total
            } : null
          } : ot
        );
      }
      const newTravel = updatedDraft.routes.reduce((s, r) => s + (r.volunteers || 0) * (r.perPerson || 0), 0);
      const newFood = (updatedDraft.food.breakfast?.amount || 0) + (updatedDraft.food.lunch?.amount || 0) + (updatedDraft.food.dinner?.amount || 0) + (updatedDraft.food.refreshments?.amount || 0);
      const newStationery = updatedDraft.stationery?.amount || 0;
      const newOther = updatedDraft.otherItems.reduce((s, o) => s + (o.amount || 0), 0);
      updatedDraft.totalAmount = newTravel + newFood + newStationery + newOther;
      onSaveDraft(updatedDraft);
      showToast(`Updated "${editingItem.description}"`);
    } else if (editingItem.rawType === "entry" && editingItem.rawId && onUpdateFinanceEntry) {
      onUpdateFinanceEntry(editingItem.rawId, {
        description: editingItem.description,
        category: editingItem.category,
        amount: editingItem.total,
        remarks: editingItem.remarks,
        billUrl: editingItem.billUrl || void 0,
        count: parseInt(editingItem.count) || void 0,
        countAmount: editingItem.countAmount || void 0
      });
      showToast(`Updated "${editingItem.description}"`);
    }
    setEditingItem(null);
  };
  const handleAddNewExpenseRow = () => {
    if (!newExpenseForm.description && !newExpenseForm.totalAmount) {
      alert("Please fill in description or amount");
      return;
    }
    const totalAmt = parseFloat(newExpenseForm.totalAmount) || 0;
    const vols = parseInt(newExpenseForm.count) || 0;
    const perP = parseFloat(newExpenseForm.perPerson) || 0;
    const finalAmount = totalAmt > 0 ? totalAmt : vols * perP;
    if (currentDraft && onSaveDraft) {
      const updatedDraft = { ...currentDraft };
      if (newExpenseForm.category === "Travel") {
        const parts = newExpenseForm.description.split("→");
        const from = parts[0]?.trim() || "Origin";
        const to = parts[1]?.trim() || "Destination";
        const newRoute = {
          id: `route-${Date.now()}`,
          from,
          to,
          volunteers: vols || 1,
          perPerson: perP || finalAmount,
          remarks: newExpenseForm.remarks,
          bill: newExpenseForm.billUrl ? {
            url: newExpenseForm.billUrl,
            fileName: newExpenseForm.billFileName || "Travel_Bill.jpg",
            detectedAmount: finalAmount,
            isVerified: true
          } : null
        };
        updatedDraft.routes = [...updatedDraft.routes, newRoute];
      } else if (newExpenseForm.category === "Food") {
        updatedDraft.food = {
          ...updatedDraft.food,
          refreshments: {
            amount: (updatedDraft.food.refreshments?.amount || 0) + finalAmount,
            remarks: newExpenseForm.remarks || newExpenseForm.description,
            bill: newExpenseForm.billUrl ? {
              url: newExpenseForm.billUrl,
              fileName: newExpenseForm.billFileName || "Food_Bill.jpg",
              detectedAmount: finalAmount,
              isVerified: true
            } : updatedDraft.food.refreshments?.bill || null
          }
        };
      } else if (newExpenseForm.category === "Stationery") {
        updatedDraft.stationery = {
          amount: (updatedDraft.stationery?.amount || 0) + finalAmount,
          remarks: newExpenseForm.remarks || newExpenseForm.description,
          bill: newExpenseForm.billUrl ? {
            url: newExpenseForm.billUrl,
            fileName: newExpenseForm.billFileName || "Stationery_Bill.jpg",
            detectedAmount: finalAmount,
            isVerified: true
          } : updatedDraft.stationery?.bill || null
        };
      } else {
        const newOther2 = {
          id: `other-${Date.now()}`,
          description: newExpenseForm.description || "Miscellaneous Expense",
          amount: finalAmount,
          remarks: newExpenseForm.remarks,
          bill: newExpenseForm.billUrl ? {
            url: newExpenseForm.billUrl,
            fileName: newExpenseForm.billFileName || "Other_Slip.jpg",
            detectedAmount: finalAmount,
            isVerified: true
          } : null
        };
        updatedDraft.otherItems = [...updatedDraft.otherItems, newOther2];
      }
      const newTravel = updatedDraft.routes.reduce((s, r) => s + (r.volunteers || 0) * (r.perPerson || 0), 0);
      const newFood = (updatedDraft.food.breakfast?.amount || 0) + (updatedDraft.food.lunch?.amount || 0) + (updatedDraft.food.dinner?.amount || 0) + (updatedDraft.food.refreshments?.amount || 0);
      const newStationery = updatedDraft.stationery?.amount || 0;
      const newOther = updatedDraft.otherItems.reduce((s, o) => s + (o.amount || 0), 0);
      updatedDraft.totalAmount = newTravel + newFood + newStationery + newOther;
      onSaveDraft(updatedDraft);
      showToast(`Added "${newExpenseForm.description}" to statement`);
    } else if (onAddFinanceEntry) {
      onAddFinanceEntry({
        date: statementMeta.date,
        description: newExpenseForm.description || "Expense Entry",
        category: newExpenseForm.category,
        amount: finalAmount,
        panchayatId: "dharmapuri-main",
        panchayatName: statementMeta.clusterName,
        villageName: "Cluster Center",
        status: "Draft",
        billUrl: newExpenseForm.billUrl || void 0,
        remarks: newExpenseForm.remarks,
        count: vols || void 0,
        countAmount: vols && perP ? `${vols}×${perP}` : void 0,
        sessionDay: statementMeta.sessionDay
      });
      showToast(`Added expense row`);
    }
    setShowAddModal(false);
    setNewExpenseForm({
      category: "Travel",
      description: "",
      count: "",
      perPerson: "",
      totalAmount: "",
      remarks: "",
      billUrl: null,
      billFileName: ""
    });
  };
  const handleSaveMetadata = () => {
    if (currentDraft && onSaveDraft) {
      const updatedDraft = {
        ...currentDraft,
        title: metaForm.sessionName,
        collegeName: metaForm.collegeName,
        clusterName: metaForm.clusterName,
        sessionDay: metaForm.sessionDay,
        sessionDate: metaForm.date,
        spocName: metaForm.spocName,
        financerName: metaForm.financerName
      };
      onSaveDraft(updatedDraft);
      showToast("Statement details updated");
    } else {
      showToast("Metadata updated for preview");
    }
    setShowEditMetaModal(false);
  };
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();
    const wsData = [
      ["TALENT QUEST FOR INDIA", "", "", "", "", "", "", ""],
      ["Academic year 2026-2027", "", "", "", "", "", "", ""],
      ["FINANCE REPORT", "", "", "", "", "", "", ""],
      [`${statementMeta.clusterName} Cluster`, "", "", "", "", "", "", ""],
      [],
      ["COLLEGE:", statementMeta.collegeName, "", "CLUSTER:", statementMeta.clusterName, "", "SESSION:", statementMeta.sessionName],
      ["DATE:", statementMeta.date, "", "SPOC:", statementMeta.spocName, "", "FINANCER:", statementMeta.financerName],
      ["DAY:", statementMeta.sessionDay, "", "STATUS:", statementMeta.status, "", "", ""],
      [],
      ["EXPENSE DETAILS", "", "", "", "", "", "", ""],
      ["S.No", "Category", "Description", "Count", "Count×Amount", "Total (INR)", "Bills Attached", "Remarks"]
    ];
    tableItems.forEach((item) => {
      wsData.push(
        [
          item.sNo,
          item.category,
          item.description,
          item.count,
          item.countAmount,
          item.total,
          item.billUrl ? "Yes (Receipt Attached)" : "None",
          item.remarks
        ]
      );
    });
    wsData.push([]);
    if (travelTotal > 0) {
      wsData.push(["", "", "", "", "Travel Total:", travelTotal, "", ""]);
    }
    if (foodTotal > 0) {
      wsData.push(["", "", "", "", "Food Total:", foodTotal, "", ""]);
    }
    if (stationeryTotal > 0) {
      wsData.push(["", "", "", "", "Stationery Total:", stationeryTotal, "", ""]);
    }
    if (otherTotal > 0) {
      wsData.push(["", "", "", "", "Other Expenses Total:", otherTotal, "", ""]);
    }
    wsData.push(["", "", "", "", "GRAND TOTAL (INR):", grandTotal, "", ""]);
    wsData.push([]);
    wsData.push(["Coordinator / SPOC Signature:", statementMeta.spocName, "", "", "Cluster Admin Signature:", statementMeta.financerName, "", ""]);
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws["!cols"] = [
      { wch: 8 },
      // S.No
      { wch: 14 },
      // Category
      { wch: 35 },
      // Description
      { wch: 10 },
      // Count
      { wch: 15 },
      // Count x Amount
      { wch: 14 },
      // Total
      { wch: 20 },
      // Bills
      { wch: 35 }
      // Remarks
    ];
    XLSX.utils.book_append_sheet(wb, ws, "Finance Statement");
    const cleanSession = statementMeta.sessionDay.replace(/[^a-zA-Z0-9]/g, "_");
    XLSX.writeFile(wb, `TQI_Finance_Statement_${cleanSession}.xlsx`);
    showToast("Excel (.xlsx) downloaded successfully!");
  };
  const handleExportWord = () => {
    const cleanSession = statementMeta.sessionDay.replace(/[^a-zA-Z0-9]/g, "_");
    const tableRowsHtml = tableItems.map(
      (item) => `
      <tr style="border-bottom: 1px solid #c4c6d3;">
        <td style="padding: 8px; text-align: center; border: 1px solid #dddddd;">${item.sNo}</td>
        <td style="padding: 8px; font-weight: bold; border: 1px solid #dddddd;">${item.category}</td>
        <td style="padding: 8px; border: 1px solid #dddddd;">${item.description}</td>
        <td style="padding: 8px; text-align: center; border: 1px solid #dddddd;">${item.count}</td>
        <td style="padding: 8px; text-align: center; border: 1px solid #dddddd;">${item.countAmount}</td>
        <td style="padding: 8px; text-align: right; font-weight: bold; border: 1px solid #dddddd;">Rs. ${item.total.toLocaleString()}</td>
        <td style="padding: 8px; text-align: center; border: 1px solid #dddddd;">${item.billUrl ? "Attached" : "None"}</td>
        <td style="padding: 8px; color: #555555; border: 1px solid #dddddd;">${item.remarks}</td>
      </tr>
    `
    ).join("");
    const wordContent = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <title>TQI Finance Statement</title>
        <style>
          body { font-family: 'Calibri', 'Arial', sans-serif; margin: 40px; color: #1a1b21; }
          .header-title { font-size: 22px; font-weight: bold; text-align: center; color: #002869; margin-bottom: 4px; }
          .header-sub { font-size: 14px; text-align: center; color: #555555; margin-bottom: 24px; font-weight: bold; }
          .meta-container { width: 100%; margin-bottom: 24px; font-size: 13px; }
          .meta-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          .meta-table td { padding: 6px 10px; border: none; }
          .meta-label { font-size: 11px; font-weight: bold; color: #666666; text-transform: uppercase; }
          .meta-val { font-size: 13px; font-weight: bold; color: #000000; }
          .data-table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
          .data-table th { background-color: #f0f4ff; color: #002869; padding: 10px 8px; font-weight: bold; border: 1px solid #cccccc; }
          .subtotal-row { background-color: #faf8ff; font-weight: bold; }
          .grand-total-row { background-color: #dae2ff; font-weight: bold; font-size: 14px; color: #001947; }
          .signatures { margin-top: 50px; width: 100%; }
        </style>
      </head>
      <body>
        <div class="header-title">Talent Quest for India</div>
        <div style="font-size: 15px; text-align: center; color: #434652; font-weight: bold; margin-bottom: 2px;">Academic year 2026-2027</div>
        <div style="font-size: 15px; text-align: center; color: #002869; font-weight: bold; text-transform: uppercase; margin-bottom: 2px;">Finance report</div>
        <div class="header-sub">${statementMeta.clusterName} Cluster</div>

        <table class="meta-table">
          <tr>
            <td width="50%">
              <div class="meta-label">COLLEGE</div>
              <div class="meta-val">${statementMeta.collegeName}</div>
            </td>
            <td width="50%">
              <div class="meta-label">DATE</div>
              <div class="meta-val">${statementMeta.date}</div>
            </td>
          </tr>
          <tr>
            <td>
              <div class="meta-label">CLUSTER</div>
              <div class="meta-val">${statementMeta.clusterName}</div>
            </td>
            <td>
              <div class="meta-label">SPOC</div>
              <div class="meta-val">${statementMeta.spocName}</div>
            </td>
          </tr>
          <tr>
            <td>
              <div class="meta-label">SESSION</div>
              <div class="meta-val">${statementMeta.sessionName} (${statementMeta.sessionDay})</div>
            </td>
            <td>
              <div class="meta-label">FINANCER</div>
              <div class="meta-val">${statementMeta.financerName}</div>
            </td>
          </tr>
        </table>

        <h3 style="font-size: 14px; text-transform: uppercase; color: #002869; margin-top: 20px; border-bottom: 2px solid #002869; padding-bottom: 4px;">Expense Details</h3>

        <table class="data-table">
          <thead>
            <tr>
              <th width="5%">S.No</th>
              <th width="12%">Category</th>
              <th width="30%">Description</th>
              <th width="8%">Count</th>
              <th width="12%">Count×Amount</th>
              <th width="12%">Total</th>
              <th width="8%">Bills</th>
              <th width="13%">Remarks</th>
            </tr>
          </thead>
          <tbody>
            ${tableRowsHtml}
            ${travelTotal > 0 ? `<tr class="subtotal-row"><td colspan="5" style="text-align: right; padding: 8px; border: 1px solid #dddddd;">Travel Total:</td><td style="text-align: right; padding: 8px; border: 1px solid #dddddd; color: #002869;">Rs. ${travelTotal.toLocaleString()}</td><td colspan="2" style="border: 1px solid #dddddd;"></td></tr>` : ""}
            ${foodTotal > 0 ? `<tr class="subtotal-row"><td colspan="5" style="text-align: right; padding: 8px; border: 1px solid #dddddd;">Food Total:</td><td style="text-align: right; padding: 8px; border: 1px solid #dddddd; color: #002869;">Rs. ${foodTotal.toLocaleString()}</td><td colspan="2" style="border: 1px solid #dddddd;"></td></tr>` : ""}
            ${stationeryTotal > 0 ? `<tr class="subtotal-row"><td colspan="5" style="text-align: right; padding: 8px; border: 1px solid #dddddd;">Stationery Total:</td><td style="text-align: right; padding: 8px; border: 1px solid #dddddd; color: #002869;">Rs. ${stationeryTotal.toLocaleString()}</td><td colspan="2" style="border: 1px solid #dddddd;"></td></tr>` : ""}
            ${otherTotal > 0 ? `<tr class="subtotal-row"><td colspan="5" style="text-align: right; padding: 8px; border: 1px solid #dddddd;">Other Expenses Total:</td><td style="text-align: right; padding: 8px; border: 1px solid #dddddd; color: #002869;">Rs. ${otherTotal.toLocaleString()}</td><td colspan="2" style="border: 1px solid #dddddd;"></td></tr>` : ""}
            <tr class="grand-total-row">
              <td colspan="5" style="text-align: right; padding: 10px; border: 1px solid #002869; font-size: 14px;">GRAND TOTAL:</td>
              <td style="text-align: right; padding: 10px; border: 1px solid #002869; font-size: 14px;">Rs. ${grandTotal.toLocaleString()}</td>
              <td colspan="2" style="border: 1px solid #002869;"></td>
            </tr>
          </tbody>
        </table>

        <table class="signatures" style="margin-top: 60px;">
          <tr>
            <td width="50%" style="text-align: center;">
              <div style="border-top: 1px solid #000000; width: 200px; margin: 0 auto; padding-top: 5px; font-weight: bold;">Coordinator</div>
              <div style="font-size: 11px; color: #555555;">SPOC: ${statementMeta.spocName}</div>
            </td>
            <td width="50%" style="text-align: center;">
              <div style="border-top: 1px solid #000000; width: 200px; margin: 0 auto; padding-top: 5px; font-weight: bold;">Cluster Admin</div>
              <div style="font-size: 11px; color: #555555;">${statementMeta.financerName}</div>
            </td>
          </tr>
        </table>
      </body>
      </html>
    `;
    const blob = new Blob(["\uFEFF", wordContent], {
      type: "application/msword;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `TQI_Finance_Statement_${cleanSession}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast("Word (.doc) document downloaded successfully!");
  };
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const handleExportPDF = async () => {
    setIsGeneratingPdf(true);
    showToast("Generating official TQI PDF Statement with attached bills...");
    try {
      await generateAndDownloadStatementPDF({
        elementId: "printable-tqi-statement-doc",
        meta: statementMeta,
        items: tableItems,
        travelTotal,
        foodTotal,
        stationeryTotal,
        otherTotal,
        grandTotal,
        attachedBills: allAttachedBills
      });
      showToast("PDF downloaded successfully!");
    } catch (err) {
      console.error("PDF export error:", err);
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };
  const handleUploadBillFile = async (e, isForNew) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async () => {
        if (reader.result) {
          const dataUrl = reader.result;
          const clarity = await checkImageClarity(dataUrl);
          if (!clarity.isClear && clarity.score < 25) {
            showToast("⚠️ Notice: Bill photo may be blurry or low quality.");
          }
          const extracted = extractRouteAndDetailsFromText("", file.name);
          if (isForNew) {
            setNewExpenseForm((prev) => ({
              ...prev,
              billUrl: dataUrl,
              billFileName: file.name,
              category: extracted.category || prev.category,
              description: extracted.origin && extracted.destination ? `Travel: ${extracted.origin} → ${extracted.destination}` : prev.description,
              totalAmount: extracted.amount ? String(extracted.amount) : prev.totalAmount,
              remarks: extracted.remarks || prev.remarks
            }));
          } else if (editingItem) {
            setEditingItem(
              (prev) => prev ? {
                ...prev,
                billUrl: dataUrl,
                billFileName: file.name,
                description: extracted.origin && extracted.destination ? `Travel: ${extracted.origin} → ${extracted.destination}` : prev.description,
                total: extracted.amount || prev.total
              } : null
            );
          }
          showToast(`Attached & verified: ${file.name}`);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6 pb-16", children: [
    toastMessage && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-[160] bg-[#001947] text-white px-4 py-2.5 rounded-md shadow-sm flex items-center gap-2 text-[13px] font-semibold border border-[#dae2ff]/40 animate-[slideUp_0.2s_ease-out]", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px] text-[#80d491]", children: "check_circle" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1091,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: toastMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1092,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1090,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-md border border-[#c4c6d3]/70 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 print:hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: onBack,
            className: "flex items-center gap-1.5 text-[13px] font-bold text-[#002869] hover:bg-[#dae2ff]/40 cursor-pointer bg-[#f4f3fb] px-3.5 py-2 rounded-md border border-[#c4c6d3]/60 transition-colors",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "arrow_back" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1103,
                columnNumber: 13
              }, this),
              "Back to Finance"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1099,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[12px] font-bold text-[#434652]", children: "Session Sheet:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1109,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedViewKey,
              onValueChange: (val) => setSelectedViewKey(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { id: "finance-session-sheet-select", className: "w-56 h-8 text-xs font-bold text-[#002869] border-[#c4c6d3] bg-[#faf8ff]", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Session Sheet" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1115,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1114,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  drafts.map(
                    (d) => /* @__PURE__ */ jsxDEV(SelectItem, { value: d.id, children: [
                      "[Draft] ",
                      d.title,
                      " (",
                      d.sessionDay,
                      ") - ₹",
                      d.totalAmount.toLocaleString()
                    ] }, d.id, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1119,
                      columnNumber: 17
                    }, this)
                  ),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all-approved", children: "Combined Approved Statement (Cluster)" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1123,
                    columnNumber: 17
                  }, this),
                  Array.from({ length: 8 }, (_, i) => `Day ${i + 1}`).map(
                    (day) => /* @__PURE__ */ jsxDEV(SelectItem, { value: day, children: [
                      day,
                      " Statement"
                    ] }, day, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1125,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1117,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1110,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1108,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1098,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleSubmitStatement,
            className: "flex items-center gap-1.5 px-3.5 py-2 bg-[#137333] text-white rounded-md text-[12.5px] font-bold hover:bg-[#137333]/90 shadow-xs transition-all cursor-pointer",
            title: "Submit this statement for cluster review and approval",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[17px]", children: "send" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1142,
                columnNumber: 13
              }, this),
              "Submit for Approval"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1137,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowFullStatementModal(true),
            className: "flex items-center gap-1.5 px-3 py-2 bg-[#002869] text-white rounded-md text-[12px] font-bold hover:bg-[#002869]/90 shadow-xs transition-all cursor-pointer",
            title: "Open clean preview statement with all attached bills",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[17px]", children: "visibility" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1152,
                columnNumber: 13
              }, this),
              "View Statement"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1147,
            columnNumber: 11
          },
          this
        ),
        allAttachedBills.length > 0 && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setActiveGalleryIndex(0);
              setShowAllBillsModal(true);
            },
            className: "flex items-center gap-1.5 px-3 py-2 bg-[#faf8ff] border border-[#002869]/30 text-[#002869] rounded-md text-[12px] font-bold hover:bg-[#dae2ff] transition-all cursor-pointer",
            title: "View all attached bill receipts in a gallery",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[17px]", children: "photo_library" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1166,
                columnNumber: 15
              }, this),
              "All Bills (",
              allAttachedBills.length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1158,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-[#f4f3fb] p-1 rounded-md border border-[#c4c6d3]", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleExportExcel,
              className: "flex items-center gap-1 px-2.5 py-1 text-[#137333] hover:bg-white rounded text-[11.5px] font-bold transition-all cursor-pointer",
              title: "Download Excel Sheet (.xlsx)",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "table_view" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1178,
                  columnNumber: 15
                }, this),
                "Excel"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1173,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleExportWord,
              className: "flex items-center gap-1 px-2.5 py-1 text-[#002869] hover:bg-white rounded text-[11.5px] font-bold transition-all cursor-pointer",
              title: "Download Microsoft Word Document (.doc)",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "description" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1187,
                  columnNumber: 15
                }, this),
                "Word"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1182,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleExportPDF,
              disabled: isGeneratingPdf,
              className: "flex items-center gap-1 px-2.5 py-1 text-[#592600] hover:bg-white rounded text-[11.5px] font-bold transition-all cursor-pointer disabled:opacity-50",
              title: "Export as Official TQI PDF Statement",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: isGeneratingPdf ? "hourglass_top" : "picture_as_pdf" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1197,
                  columnNumber: 15
                }, this),
                isGeneratingPdf ? "Generating..." : "PDF"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1191,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1172,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1135,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1097,
      columnNumber: 7
    }, this),
    statementMeta.isDraft && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#fff7f2] border border-[#ffdbc8] rounded-md p-3.5 flex items-center justify-between gap-3 text-[13px] print:hidden shadow-xs", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 text-[#592600]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-md bg-[#ffdbc8] text-[#592600] flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "description" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1211,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1210,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Official TQI Finance Sheet" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1215,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "bg-[#ffdbc8] text-[#592600] text-[10.5px] px-2 py-0.2 rounded font-extrabold", children: [
            "Status: ",
            statementMeta.status
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1216,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1214,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[11.5px] text-[#762900] mt-0.5", children: "Cluster audit statement preview. Click receipt buttons below to inspect verified bills." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1220,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1213,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1209,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1208,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { id: "printable-tqi-statement-doc", className: "bg-white rounded-md border border-[#c4c6d3]/80 shadow-sm p-6 sm:p-12 space-y-8 print:p-0 print:border-none print:shadow-none", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center text-center space-y-2.5 pb-4 border-b border-[#dae2ff]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TqiLogo, { size: 92, className: "mx-auto" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1237,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1236,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 pt-1", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-[22px] sm:text-[26px] font-extrabold text-[#000000] tracking-tight", children: "Talent Quest for India" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1241,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[14px] sm:text-[15px] font-bold text-[#434652]", children: "Academic year 2026-2027" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1244,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[14px] sm:text-[15px] font-extrabold text-[#002869] uppercase tracking-wider", children: "Finance report" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1247,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[13.5px] sm:text-[14.5px] font-bold text-[#592600]", children: [
            statementMeta.clusterName,
            " Cluster"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1250,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1240,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1234,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-[#faf8ff] rounded-md p-5 sm:p-6 border border-[#dae2ff]/80 text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3 border-b border-[#dae2ff] pb-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-extrabold text-[#002869] uppercase tracking-wider flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "info" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1260,
              columnNumber: 15
            }, this),
            "Session & Cluster Details"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1259,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: `text-[11px] font-extrabold px-2.5 py-0.5 rounded-full ${statementMeta.status === "Approved" ? "bg-[#e6f4ea] text-[#137333]" : "bg-[#ffdbc8] text-[#592600]"}`,
              children: [
                "Status: ",
                statementMeta.status
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1264,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1263,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1258,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-y-3.5 gap-x-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "COLLEGE:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1280,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#000000] text-[13.5px]", children: statementMeta.collegeName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1283,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1279,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "CLUSTER:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1289,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#002869] text-[13.5px]", children: statementMeta.clusterName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1292,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1288,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "SESSION:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1298,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000] text-[13px]", children: statementMeta.sessionName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1301,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1297,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1278,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "DATE:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1309,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000] text-[13px]", children: statementMeta.date }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1312,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1308,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "SPOC:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1318,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000] text-[13px]", children: statementMeta.spocName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1321,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1317,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11.5px] font-bold text-[#747783] uppercase tracking-wide w-24 shrink-0", children: "FINANCER:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1327,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000] text-[13px]", children: statementMeta.financerName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1330,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1326,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1307,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1277,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1257,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-[14px] font-bold text-[#000000] uppercase tracking-wider flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Expense Details" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1342,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-[#747783] lowercase font-normal", children: [
            "(",
            tableItems.length,
            " items logged)"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1343,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1341,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1340,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "block md:hidden space-y-3 print:hidden", children: [
          tableItems.map(
            (item) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "p-3.5 rounded-xl border border-[#c4c6d3] bg-[#faf8ff]/50 space-y-2",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-[#747783]", children: [
                        "#",
                        item.sNo
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1358,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#dae2ff] text-[#002869]", children: item.category }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1359,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1357,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-xs font-bold text-[#002869]", children: [
                      "₹",
                      item.total.toLocaleString()
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1363,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1356,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-[#1a1b21]", children: item.description }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1369,
                      columnNumber: 19
                    }, this),
                    item.count && item.countAmount && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#555555] mt-0.5 font-mono", children: [
                      "Formula: ",
                      item.count,
                      " × ",
                      item.countAmount
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1373,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1368,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-1.5 border-t border-[#c4c6d3]/60 text-[11px]", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#555555] truncate max-w-[170px]", children: item.remarks || "Expense item" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1380,
                      columnNumber: 19
                    }, this),
                    item.billUrl ? /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setBillZoom(1);
                          setBillRotate(0);
                          setActiveBillViewer({
                            url: item.billUrl,
                            title: item.category + ": " + item.description,
                            category: item.category,
                            amount: item.total,
                            fileName: item.billFileName || item.category + "_Bill.jpg",
                            itemId: item.id
                          });
                        },
                        className: "inline-flex items-center gap-1 px-2.5 py-1 bg-[#e6f4ea] text-[#137333] border border-[#137333]/30 rounded text-[11px] font-bold cursor-pointer",
                        children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "receipt_long" }, void 0, false, {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                            lineNumber: 1401,
                            columnNumber: 23
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { children: "View Bill" }, void 0, false, {
                            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                            lineNumber: 1402,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1385,
                        columnNumber: 17
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[10.5px]", children: "No receipt" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1405,
                      columnNumber: 17
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1379,
                    columnNumber: 17
                  }, this)
                ]
              },
              item.id,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1352,
                columnNumber: 13
              },
              this
            )
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 rounded-xl border border-[#dae2ff] bg-[#faf8ff] space-y-1.5 text-xs", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-bold text-[#002869] uppercase tracking-wider mb-2", children: "Category Subtotals" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1413,
              columnNumber: 15
            }, this),
            travelTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[#434652]", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Travel Total:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1416,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-bold text-[#002869]", children: [
                "₹",
                travelTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1417,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1415,
              columnNumber: 15
            }, this),
            foodTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[#434652]", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Food Total:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1422,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-bold text-[#002869]", children: [
                "₹",
                foodTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1423,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1421,
              columnNumber: 15
            }, this),
            stationeryTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[#434652]", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Stationery Total:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1428,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-bold text-[#002869]", children: [
                "₹",
                stationeryTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1429,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1427,
              columnNumber: 15
            }, this),
            otherTotal > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[#434652]", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Other Total:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1434,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-bold text-[#002869]", children: [
                "₹",
                otherTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1435,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1433,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between pt-2 border-t border-[#dae2ff] font-bold text-sm text-[#001947]", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Grand Total:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1439,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-base text-[#002869]", children: [
                "₹",
                grandTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1440,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1438,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1412,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1350,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hidden md:block border border-[#c4c6d3] overflow-x-auto rounded-md print:block", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left text-[12px] border-collapse min-w-[700px]", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-[#faf8ff] border-b border-[#c4c6d3] font-bold text-[#000000]", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] w-12 text-center", children: "S.No" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1450,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] w-24", children: "Category" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1451,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3]", children: "Description" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1452,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] text-center w-16", children: "Count" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1453,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] text-center w-24", children: "Count×Amount" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1454,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] text-right w-24", children: "Total" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1455,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5 border-r border-[#c4c6d3] text-center w-24", children: "Bills" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1456,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2.5", children: "Remarks" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1457,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1449,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1448,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[#c4c6d3]", children: [
            tableItems.map(
              (item) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-[#faf8ff]/80 transition-colors group", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] font-mono text-center", children: item.sNo }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1463,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#002869]", children: item.category }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1465,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1464,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] font-medium text-[#1a1b21]", children: item.description }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1467,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-center font-mono", children: item.count }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1470,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-center font-mono", children: item.countAmount }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1471,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono font-bold text-[#002869]", children: [
                  "₹",
                  item.total.toLocaleString()
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1472,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-center", children: item.billUrl ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setBillZoom(1);
                      setBillRotate(0);
                      setActiveBillViewer({
                        url: item.billUrl,
                        title: `${item.category}: ${item.description}`,
                        category: item.category,
                        amount: item.total,
                        fileName: item.billFileName || `${item.category}_Bill.jpg`,
                        itemId: item.id
                      });
                    },
                    className: "inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#e6f4ea] hover:bg-[#ceead6] text-[#137333] border border-[#137333]/30 rounded-md text-[11.5px] font-bold transition-all cursor-pointer shadow-2xs",
                    title: "Click to view full receipt / bill",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[15px]", children: "receipt_long" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1495,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "View" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1496,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1479,
                    columnNumber: 21
                  },
                  this
                ) : /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-medium", children: "—" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1499,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1477,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 text-[#555555] text-[11.5px]", children: item.remarks }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1503,
                  columnNumber: 21
                }, this)
              ] }, item.id, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1462,
                columnNumber: 17
              }, this)
            ),
            travelTotal > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#faf8ff] font-medium text-[12px]", children: [
              /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-2.5 border-r border-[#c4c6d3] text-right font-bold text-[#434652]", children: "Travel Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1510,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono font-bold text-[#002869]", children: [
                "₹",
                travelTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1513,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-2.5 bg-[#faf8ff]" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1516,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1509,
              columnNumber: 17
            }, this),
            foodTotal > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#faf8ff] font-medium text-[12px]", children: [
              /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-2.5 border-r border-[#c4c6d3] text-right font-bold text-[#434652]", children: "Food Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1522,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono font-bold text-[#002869]", children: [
                "₹",
                foodTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1525,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-2.5 bg-[#faf8ff]" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1528,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1521,
              columnNumber: 17
            }, this),
            stationeryTotal > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#faf8ff] font-medium text-[12px]", children: [
              /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-2.5 border-r border-[#c4c6d3] text-right font-bold text-[#434652]", children: "Stationery / Materials Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1534,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono font-bold text-[#002869]", children: [
                "₹",
                stationeryTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1537,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-2.5 bg-[#faf8ff]" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1540,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1533,
              columnNumber: 17
            }, this),
            otherTotal > 0 && /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#faf8ff] font-medium text-[12px]", children: [
              /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-2.5 border-r border-[#c4c6d3] text-right font-bold text-[#434652]", children: "Other Expenses Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1546,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono font-bold text-[#002869]", children: [
                "₹",
                otherTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1549,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-2.5 bg-[#faf8ff]" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1552,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1545,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#dae2ff] font-extrabold text-[#001947]", children: [
              /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-3 border-r border-[#c4c6d3] text-right text-[13.5px] tracking-wide", children: "Grand Total" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1558,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-3 border-r border-[#c4c6d3] text-right font-mono text-[15px]", children: [
                "₹",
                grandTotal.toLocaleString()
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1561,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-3 bg-[#dae2ff]" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1564,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1557,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1460,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1447,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1446,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1339,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-8 sm:pt-14 grid grid-cols-2 gap-12 text-center text-[12px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#000000] pt-2 font-bold text-[#000000]", children: "Coordinator" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1574,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-[#747783] mt-0.5", children: [
            "SPOC: ",
            statementMeta.spocName
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1577,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1573,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#000000] pt-2 font-bold text-[#000000]", children: "Cluster Admin" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1581,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-[#747783] mt-0.5", children: statementMeta.financerName }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1584,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1580,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1572,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2 text-[11px] text-[#747783] border-t border-[#dae2ff]/60", children: "Talent Quest for India — Official Finance Statement & Audit Document" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1589,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1231,
      columnNumber: 7
    }, this),
    activeBillViewer && /* @__PURE__ */ jsxDEV(
      "div",
      {
        onClick: () => setActiveBillViewer(null),
        className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-3 sm:p-6 cursor-pointer animate-[fadeIn_0.15s_ease-out]",
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: (e) => e.stopPropagation(),
            className: "bg-white rounded-md max-w-2xl w-full overflow-hidden shadow-sm flex flex-col max-h-[90vh] cursor-default border border-[#c4c6d3]",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#f4f3fb] border-b border-[#c4c6d3] flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-[15px] font-bold text-[#002869] flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px] text-[#137333]", children: "receipt" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1610,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: activeBillViewer.title }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1611,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1609,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11.5px] text-[#434652]", children: [
                    activeBillViewer.fileName || "Attached Receipt File",
                    " • Amount: ",
                    /* @__PURE__ */ jsxDEV("strong", { className: "text-[#002869]", children: [
                      "₹",
                      activeBillViewer.amount || 0
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1614,
                      columnNumber: 84
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1613,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1608,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setBillRotate((r) => (r + 90) % 360),
                      className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-md cursor-pointer transition-colors",
                      title: "Rotate Image",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "rotate_right" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1625,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1620,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setBillZoom((z) => Math.min(z + 0.25, 2.5)),
                      className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-md cursor-pointer transition-colors",
                      title: "Zoom In",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "zoom_in" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1633,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1628,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setBillZoom((z) => Math.max(z - 0.25, 0.5)),
                      className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-md cursor-pointer transition-colors",
                      title: "Zoom Out",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "zoom_out" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1641,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1636,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setActiveBillViewer(null),
                      className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-full cursor-pointer ml-1",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 1648,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1644,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1618,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1607,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#1a1b21] flex-1 overflow-auto flex items-center justify-center min-h-[340px] max-h-[60vh]", children: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  style: {
                    transform: `scale(${billZoom}) rotate(${billRotate}deg)`,
                    transition: "transform 0.2s ease-out"
                  },
                  className: "max-w-full",
                  children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: activeBillViewer.url,
                      alt: "Bill Receipt",
                      className: "max-h-[50vh] object-contain rounded-md shadow-sm mx-auto",
                      referrerPolicy: "no-referrer",
                      onError: (e) => {
                        e.target.style.display = "none";
                        const parent = e.target.parentElement;
                        if (parent && !parent.querySelector(".voucher-fallback")) {
                          const fallbackDiv = document.createElement("div");
                          fallbackDiv.className = "voucher-fallback bg-white text-[#1a1b21] p-6 rounded-md shadow-sm border border-[#c4c6d3] w-80 text-center font-mono space-y-2";
                          fallbackDiv.innerHTML = `
                        <div style="font-size: 16px; font-weight: bold; color: #002869;">TALENT QUEST FOR INDIA</div>
                        <div style="font-size: 11px; color: #666;">OFFICIAL EXPENSE VOUCHER</div>
                        <hr style="border: 0.5px dashed #aaa; margin: 8px 0;" />
                        <div style="font-size: 12px; text-align: left;"><strong>Item:</strong> ${activeBillViewer.title}</div>
                        <div style="font-size: 12px; text-align: left;"><strong>Amount:</strong> ₹${activeBillViewer.amount || 0}</div>
                        <div style="font-size: 12px; text-align: left;"><strong>Date:</strong> ${statementMeta.date}</div>
                        <div style="font-size: 12px; text-align: left;"><strong>Status:</strong> Verified Receipt Attached</div>
                        <hr style="border: 0.5px dashed #aaa; margin: 8px 0;" />
                        <div style="font-size: 10px; color: #2e7d32; font-weight: bold;">[DIGITALLY VERIFIED IN CLUSTER REGISTRY]</div>
                      `;
                          parent.appendChild(fallbackDiv);
                        }
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1662,
                      columnNumber: 17
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1655,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1654,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white border-t border-[#c4c6d3] flex flex-wrap items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "a",
                    {
                      href: activeBillViewer.url,
                      download: activeBillViewer.fileName || "TQI_Receipt.jpg",
                      target: "_blank",
                      rel: "noreferrer",
                      className: "px-3 py-1.5 bg-[#f4f3fb] border border-[#c4c6d3] text-[#002869] rounded-md text-[12px] font-bold hover:bg-[#dae2ff] flex items-center gap-1 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "download" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 1702,
                          columnNumber: 19
                        }, this),
                        "Download Receipt"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1695,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "a",
                    {
                      href: activeBillViewer.url,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "px-3 py-1.5 text-[#002869] text-[12px] font-bold hover:underline flex items-center gap-1",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "open_in_new" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 1712,
                          columnNumber: 19
                        }, this),
                        "Open in New Tab"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 1706,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1694,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setActiveBillViewer(null),
                    className: "px-4 py-1.5 bg-[#002869] text-white font-bold text-[12px] rounded-md hover:bg-[#002869]/90 cursor-pointer",
                    children: "Close Preview"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1717,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1693,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1602,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1598,
        columnNumber: 7
      },
      this
    ),
    editingItem && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 animate-[fadeIn_0.15s_ease-out]", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md max-w-lg w-full overflow-hidden shadow-sm border border-[#c4c6d3] space-y-4 p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#c4c6d3] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-[#002869] flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "edit" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1736,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Edit Expense Line Item" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1737,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1735,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setEditingItem(null),
            className: "p-1 text-[#747783] hover:text-[#1a1b21] rounded-full cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1743,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1739,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1734,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3.5 text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Category" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1749,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: editingItem.category,
              onValueChange: (val) => setEditingItem({
                ...editingItem,
                category: val
              }),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs font-semibold text-[#002869] border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Category" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1760,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1759,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Travel", children: "Travel" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1763,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Food", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1764,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Stationery", children: "Stationery" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1765,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Other", children: "Other" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1766,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1762,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1750,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1748,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Description / Route" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1772,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: editingItem.description,
              onChange: (e) => setEditingItem({
                ...editingItem,
                description: e.target.value
              }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none focus:border-[#002869]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1773,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1771,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Count (Volunteers / Items)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1788,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: editingItem.count,
                onChange: (e) => setEditingItem({
                  ...editingItem,
                  count: e.target.value
                }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none focus:border-[#002869]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1789,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1787,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Total Amount (₹) *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1803,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                value: editingItem.total,
                onChange: (e) => setEditingItem({
                  ...editingItem,
                  total: parseFloat(e.target.value) || 0
                }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md font-bold text-[#002869] outline-none focus:border-[#002869]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1804,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1802,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1786,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Remarks" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1820,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: editingItem.remarks,
              onChange: (e) => setEditingItem({
                ...editingItem,
                remarks: e.target.value
              }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none focus:border-[#002869]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1821,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1819,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Receipt / Bill Attachment" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1836,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "px-3 py-1.5 bg-[#f4f3fb] border border-[#c4c6d3] rounded-md text-[12px] font-bold text-[#002869] hover:bg-[#dae2ff] flex items-center gap-1 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "upload_file" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1839,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: editingItem.billUrl ? "Change Bill Photo" : "Upload Bill Photo" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1840,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "file",
                  accept: "image/*,application/pdf",
                  className: "hidden",
                  onChange: (e) => handleUploadBillFile(e, false)
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1841,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1838,
              columnNumber: 19
            }, this),
            editingItem.billUrl && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setEditingItem({
                  ...editingItem,
                  billUrl: null,
                  billFileName: ""
                }),
                className: "text-[#ba1a1a] hover:bg-[#ffdad6] px-2 py-1 rounded text-[11px] font-bold flex items-center gap-0.5 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "delete" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1860,
                    columnNumber: 23
                  }, this),
                  "Remove Bill"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1850,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1837,
            columnNumber: 17
          }, this),
          editingItem.billFileName && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#137333] font-semibold mt-1 block", children: [
            "✓ Attached: ",
            editingItem.billFileName
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1866,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1835,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1747,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-[#c4c6d3]", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setEditingItem(null),
            className: "px-4 py-2 bg-white border border-[#c4c6d3] rounded-md text-[12.5px] font-bold text-[#434652] hover:bg-[#f4f3fb] cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1874,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleSaveEditedRow,
            className: "px-5 py-2 bg-[#002869] text-white rounded-md text-[12.5px] font-bold hover:bg-[#002869]/90 cursor-pointer shadow-xs",
            children: "Save Changes"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1880,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1873,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1733,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1732,
      columnNumber: 7
    }, this),
    showAddModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 animate-[fadeIn_0.15s_ease-out]", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md max-w-lg w-full overflow-hidden shadow-sm border border-[#c4c6d3] space-y-4 p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#c4c6d3] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-[#002869] flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "add_circle" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1899,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Add Expense Line Item" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1900,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1898,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowAddModal(false),
            className: "p-1 text-[#747783] hover:text-[#1a1b21] rounded-full cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1906,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1902,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1897,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3.5 text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Category *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1912,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: newExpenseForm.category,
              onValueChange: (val) => setNewExpenseForm({
                ...newExpenseForm,
                category: val
              }),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs font-semibold text-[#002869] border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Category" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1923,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1922,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Travel", children: "Travel" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1926,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Food", children: "Food" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1927,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Stationery", children: "Stationery" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1928,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Other", children: "Other" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 1929,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 1925,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1913,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1911,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: newExpenseForm.category === "Travel" ? "Route (e.g. KSR College → Salem)" : "Description *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1935,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: newExpenseForm.category === "Travel" ? "Origin → Destination" : newExpenseForm.category === "Food" ? "Breakfast / Lunch / Tea allowance" : "Activity materials / Banner / Misc",
              value: newExpenseForm.description,
              onChange: (e) => setNewExpenseForm({
                ...newExpenseForm,
                description: e.target.value
              }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none focus:border-[#002869]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1938,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1934,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Count" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1960,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                placeholder: "e.g. 20",
                value: newExpenseForm.count,
                onChange: (e) => setNewExpenseForm({
                  ...newExpenseForm,
                  count: e.target.value
                }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1961,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1959,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Per Person (₹)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1977,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                placeholder: "e.g. 10",
                value: newExpenseForm.perPerson,
                onChange: (e) => setNewExpenseForm({
                  ...newExpenseForm,
                  perPerson: e.target.value
                }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1978,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1976,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Total (₹) *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 1994,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                placeholder: "e.g. 200",
                value: newExpenseForm.totalAmount,
                onChange: (e) => setNewExpenseForm({
                  ...newExpenseForm,
                  totalAmount: e.target.value
                }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md font-bold text-[#002869] outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 1995,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 1993,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 1958,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Remarks" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2012,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "Optional details or vendor notes",
              value: newExpenseForm.remarks,
              onChange: (e) => setNewExpenseForm({
                ...newExpenseForm,
                remarks: e.target.value
              }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2013,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2011,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Receipt / Bill Attachment" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2029,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "px-3 py-1.5 bg-[#f4f3fb] border border-[#c4c6d3] rounded-md text-[12px] font-bold text-[#002869] hover:bg-[#dae2ff] flex items-center gap-1 cursor-pointer w-fit", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "upload_file" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2031,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Upload Receipt File" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2032,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "file",
                accept: "image/*,application/pdf",
                className: "hidden",
                onChange: (e) => handleUploadBillFile(e, true)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2033,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2030,
            columnNumber: 17
          }, this),
          newExpenseForm.billFileName && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-[#137333] font-semibold mt-1 block", children: [
            "✓ Attached: ",
            newExpenseForm.billFileName
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2041,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2028,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 1910,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-[#c4c6d3]", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowAddModal(false),
            className: "px-4 py-2 bg-white border border-[#c4c6d3] rounded-md text-[12.5px] font-bold text-[#434652] hover:bg-[#f4f3fb] cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2049,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleAddNewExpenseRow,
            className: "px-5 py-2 bg-[#fb7800] text-white rounded-md text-[12.5px] font-bold hover:bg-[#fb7800]/90 cursor-pointer shadow-xs",
            children: "Add Line Item"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2055,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2048,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1896,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 1895,
      columnNumber: 7
    }, this),
    showEditMetaModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 animate-[fadeIn_0.15s_ease-out]", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md max-w-md w-full overflow-hidden shadow-sm border border-[#c4c6d3] space-y-4 p-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-[#c4c6d3] pb-3", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-[#002869] flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "edit_note" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2074,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Edit Statement Details" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2075,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2073,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowEditMetaModal(false),
            className: "p-1 text-[#747783] hover:text-[#1a1b21] rounded-full cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2081,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2077,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2072,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 text-[13px]", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "College Name" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2087,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: metaForm.collegeName,
              onChange: (e) => setMetaForm({ ...metaForm, collegeName: e.target.value }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2088,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2086,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Cluster Name" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2097,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: metaForm.clusterName,
              onChange: (e) => setMetaForm({ ...metaForm, clusterName: e.target.value }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2098,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2096,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Session Title" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2107,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: metaForm.sessionName,
              onChange: (e) => setMetaForm({ ...metaForm, sessionName: e.target.value }),
              className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2108,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2106,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Session Day" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2118,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: metaForm.sessionDay,
                onChange: (e) => setMetaForm({ ...metaForm, sessionDay: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2119,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2117,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2128,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: metaForm.date,
                onChange: (e) => setMetaForm({ ...metaForm, date: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2129,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2127,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2116,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "SPOC Name" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2140,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: metaForm.spocName,
                onChange: (e) => setMetaForm({ ...metaForm, spocName: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2141,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2139,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-[#434652] mb-1", children: "Financer Name" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
              lineNumber: 2150,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: metaForm.financerName,
                onChange: (e) => setMetaForm({ ...metaForm, financerName: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md outline-none"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2151,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2149,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
          lineNumber: 2138,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2085,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-[#c4c6d3]", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowEditMetaModal(false),
            className: "px-4 py-2 bg-white border border-[#c4c6d3] rounded-md text-[12.5px] font-bold text-[#434652] hover:bg-[#f4f3fb] cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2162,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleSaveMetadata,
            className: "px-5 py-2 bg-[#002869] text-white rounded-md text-[12.5px] font-bold hover:bg-[#002869]/90 cursor-pointer shadow-xs",
            children: "Save Details"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2168,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2161,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 2071,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
      lineNumber: 2070,
      columnNumber: 7
    }, this),
    showAllBillsModal && allAttachedBills.length > 0 && /* @__PURE__ */ jsxDEV(
      "div",
      {
        onClick: () => setShowAllBillsModal(false),
        className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 cursor-pointer animate-[fadeIn_0.15s_ease-out]",
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: (e) => e.stopPropagation(),
            className: "bg-white rounded-md max-w-3xl w-full overflow-hidden shadow-sm flex flex-col max-h-[92vh] cursor-default border border-[#c4c6d3]",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#f4f3fb] border-b border-[#c4c6d3] flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold text-[#002869] flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px] text-[#137333]", children: "photo_library" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2194,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Attached Bills Gallery (",
                      activeGalleryIndex + 1,
                      " of ",
                      allAttachedBills.length,
                      ")"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2195,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2193,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#434652]", children: [
                    allAttachedBills[activeGalleryIndex].title,
                    " • ₹",
                    allAttachedBills[activeGalleryIndex].amount
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2197,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2192,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setShowAllBillsModal(false),
                    className: "p-1 text-[#434652] hover:bg-[#e8e7ef] rounded-full cursor-pointer",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2205,
                      columnNumber: 17
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2201,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2191,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#1a1b21] flex-1 flex items-center justify-center min-h-[380px] max-h-[60vh] relative", children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: allAttachedBills[activeGalleryIndex].url,
                    alt: "Bill",
                    className: "max-h-[52vh] object-contain rounded-md shadow-sm",
                    referrerPolicy: "no-referrer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2211,
                    columnNumber: 15
                  },
                  this
                ),
                allAttachedBills.length > 1 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setActiveGalleryIndex(
                        (prev) => prev === 0 ? allAttachedBills.length - 1 : prev - 1
                      ),
                      className: "absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 cursor-pointer",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[24px]", children: "chevron_left" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2229,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2221,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setActiveGalleryIndex(
                        (prev) => prev === allAttachedBills.length - 1 ? 0 : prev + 1
                      ),
                      className: "absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/90 cursor-pointer",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[24px]", children: "chevron_right" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2240,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2232,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2220,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2210,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-[#faf8ff] border-t border-[#c4c6d3] flex items-center gap-2 overflow-x-auto", children: allAttachedBills.map(
                (bill, idx) => /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setActiveGalleryIndex(idx),
                    className: `relative shrink-0 w-14 h-14 rounded-md overflow-hidden border-2 cursor-pointer transition-all ${activeGalleryIndex === idx ? "border-[#002869] scale-105 shadow-sm" : "border-[#c4c6d3] opacity-60 hover:opacity-100"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV("img", { src: bill.url, alt: "Thumb", className: "w-full h-full object-cover", referrerPolicy: "no-referrer" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2258,
                        columnNumber: 19
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-0 right-0 bg-black/70 text-white text-[9px] px-1 font-mono", children: [
                        "#",
                        idx + 1
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2259,
                        columnNumber: 19
                      }, this)
                    ]
                  },
                  idx,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2249,
                    columnNumber: 13
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2247,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white border-t border-[#c4c6d3] flex justify-between items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "a",
                  {
                    href: allAttachedBills[activeGalleryIndex].url,
                    download: allAttachedBills[activeGalleryIndex].fileName,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "px-3.5 py-1.5 bg-[#f4f3fb] border border-[#c4c6d3] text-[#002869] rounded-md text-[12px] font-bold hover:bg-[#dae2ff] flex items-center gap-1 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "download" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2274,
                        columnNumber: 17
                      }, this),
                      "Download This Bill"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2267,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setShowAllBillsModal(false),
                    className: "px-5 py-1.5 bg-[#002869] text-white rounded-md text-[12px] font-bold cursor-pointer",
                    children: "Done"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2278,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2266,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2187,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2183,
        columnNumber: 7
      },
      this
    ),
    showFullStatementModal && /* @__PURE__ */ jsxDEV(
      "div",
      {
        onClick: () => setShowFullStatementModal(false),
        className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-3 sm:p-6 cursor-pointer animate-[fadeIn_0.15s_ease-out]",
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: (e) => e.stopPropagation(),
            className: "bg-white rounded-md max-w-4xl w-full overflow-hidden shadow-sm flex flex-col max-h-[92vh] cursor-default border border-[#c4c6d3]",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#002869] text-white flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "receipt_long" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2303,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-[16px] font-bold", children: "Official TQI Finance Statement Preview" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2304,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2302,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: handleExportExcel,
                      className: "px-2.5 py-1 bg-white20 hover:bg-white30 text-white rounded text-[11.5px] font-bold flex items-center gap-1 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[15px]", children: "table_view" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2311,
                          columnNumber: 19
                        }, this),
                        "Excel"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2307,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: handleExportWord,
                      className: "px-2.5 py-1 bg-white20 hover:bg-white30 text-white rounded text-[11.5px] font-bold flex items-center gap-1 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[15px]", children: "description" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2318,
                          columnNumber: 19
                        }, this),
                        "Word"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2314,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: handleExportPDF,
                      disabled: isGeneratingPdf,
                      className: "px-2.5 py-1 bg-[#fb7800] text-white rounded text-[11.5px] font-bold flex items-center gap-1 cursor-pointer disabled:opacity-50",
                      title: "Download TQI Statement PDF",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[15px]", children: isGeneratingPdf ? "hourglass_top" : "picture_as_pdf" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2327,
                          columnNumber: 19
                        }, this),
                        isGeneratingPdf ? "Generating..." : "PDF"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2321,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setShowFullStatementModal(false),
                      className: "p-1 text-white/80 hover:text-white rounded-full cursor-pointer ml-1",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2336,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2332,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2306,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2301,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto space-y-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-center space-y-1.5 pb-2 border-b border-[#dae2ff]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TqiLogo, { size: 75, className: "mx-auto" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2345,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2344,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-[20px] font-extrabold text-[#000000] pt-1", children: "Talent Quest for India" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2347,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-bold text-[#434652]", children: "Academic year 2026-2027" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2350,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-extrabold text-[#002869] uppercase tracking-wider", children: "Finance report" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2353,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[12.5px] font-bold text-[#592600]", children: [
                    statementMeta.clusterName,
                    " Cluster"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2356,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2343,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-[#faf8ff] p-4 rounded-md border border-[#c4c6d3]/60 text-[12.5px] grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "COLLEGE" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2364,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#000000]", children: statementMeta.collegeName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2365,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2363,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "DATE" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2368,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000]", children: statementMeta.date }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2369,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2367,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "CLUSTER" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2372,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#002869]", children: statementMeta.clusterName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2373,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2371,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "SPOC" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2376,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000]", children: statementMeta.spocName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2377,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2375,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "SESSION" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2380,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000]", children: [
                      statementMeta.sessionName,
                      " (",
                      statementMeta.sessionDay,
                      ")"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2381,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2379,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] font-bold uppercase text-[10.5px] block", children: "FINANCER" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2384,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#000000]", children: statementMeta.financerName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2385,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2383,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2362,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left text-[12px] border-collapse border border-[#c4c6d3]", children: [
                  /* @__PURE__ */ jsxDEV("thead", { className: "bg-[#faf8ff] font-bold text-[#000000] border-b border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] w-10 text-center", children: "S.No" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2393,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] w-20", children: "Category" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2394,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3]", children: "Description" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2395,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] text-center w-14", children: "Count" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2396,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] text-center w-20", children: "Count×Amt" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2397,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] text-right w-20", children: "Total" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2398,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2 border-r border-[#c4c6d3] text-center w-16", children: "Bills" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2399,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "p-2", children: "Remarks" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2400,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2392,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2391,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[#c4c6d3]", children: [
                    tableItems.map(
                      (item) => /* @__PURE__ */ jsxDEV("tr", { children: [
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] text-center", children: item.sNo }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2406,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] font-bold text-[#002869]", children: item.category }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2407,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3]", children: item.description }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2408,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] text-center", children: item.count }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2409,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] text-center", children: item.countAmount }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2410,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] text-right font-bold text-[#002869]", children: [
                          "₹",
                          item.total.toLocaleString()
                        ] }, void 0, true, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2411,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 border-r border-[#c4c6d3] text-center", children: item.billUrl ? /* @__PURE__ */ jsxDEV("span", { className: "text-[#137333] font-bold text-[11px]", children: "Attached" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2415,
                          columnNumber: 41
                        }, this) : "—" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2414,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV("td", { className: "p-2 text-[#747783]", children: item.remarks }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                          lineNumber: 2417,
                          columnNumber: 23
                        }, this)
                      ] }, item.id, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2405,
                        columnNumber: 17
                      }, this)
                    ),
                    /* @__PURE__ */ jsxDEV("tr", { className: "bg-[#dae2ff] font-extrabold text-[#001947]", children: [
                      /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-2.5 border-r border-[#c4c6d3] text-right text-[13px]", children: "Grand Total" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2421,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { className: "p-2.5 border-r border-[#c4c6d3] text-right font-mono text-[14px]", children: [
                        "₹",
                        grandTotal.toLocaleString()
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2424,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("td", { colSpan: 2, className: "p-2.5 bg-[#dae2ff]" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                        lineNumber: 2427,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2420,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2403,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2390,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "pt-8 grid grid-cols-2 gap-8 text-center text-[12px]", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#000000] pt-1.5 font-bold", children: "Coordinator" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2435,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-[#747783]", children: statementMeta.spocName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2436,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2434,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-[#000000] pt-1.5 font-bold", children: "Cluster Admin" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2439,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-[#747783]", children: statementMeta.financerName }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                      lineNumber: 2440,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                    lineNumber: 2438,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2433,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2341,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-[#faf8ff] border-t border-[#c4c6d3] flex justify-end", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowFullStatementModal(false),
                  className: "px-5 py-2 bg-[#002869] text-white rounded-md text-[12.5px] font-bold cursor-pointer",
                  children: "Close Statement"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                  lineNumber: 2446,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
                lineNumber: 2445,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
            lineNumber: 2297,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
        lineNumber: 2293,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx",
    lineNumber: 1087,
    columnNumber: 5
  }, this);
};
_s(FinanceStatementView, "o4QSDtt0kMBoNeIBR3UnGOFNMQk=");
_c = FinanceStatementView;
var _c;
$RefreshReg$(_c, "FinanceStatementView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/FinanceStatementView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa2tDVSxTQXltQ00sVUF6bUNOOztBQWxrQ1YsT0FBT0EsU0FBU0MsVUFBVUMsZUFBdUI7QUFDakQsWUFBWUMsVUFBVTtBQUV0QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHVDQUF1QztBQUNoRCxTQUFTQyxtQkFBbUJDLHNDQUFzQztBQUNsRTtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFzQ0EsYUFBTUMsdUJBQTREQSxDQUFDO0FBQUEsRUFDeEVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxTQUFTO0FBQUEsRUFDVEM7QUFBQUEsRUFDQUMsY0FBYztBQUFBLEVBQ2RDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsZUFBZTtBQUFBLEVBQ2ZDLGFBQWE7QUFBQSxFQUNiQyxPQUFPO0FBQUEsRUFDUEM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUloQztBQUFBQSxJQUM1Q2lCLGtCQUFrQkQsT0FBT2lCLFNBQVMsSUFBSWpCLE9BQU8sQ0FBQyxFQUFFa0IsS0FBSztBQUFBLEVBQ3ZEO0FBR0EsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJcEMsU0FPdEMsSUFBSTtBQUVkLFFBQU0sQ0FBQ3FDLFVBQVVDLFdBQVcsSUFBSXRDLFNBQWlCLENBQUM7QUFDbEQsUUFBTSxDQUFDdUMsWUFBWUMsYUFBYSxJQUFJeEMsU0FBaUIsQ0FBQztBQUd0RCxRQUFNLENBQUN5QyxhQUFhQyxjQUFjLElBQUkxQyxTQUErQixJQUFJO0FBR3pFLFFBQU0sQ0FBQzJDLGNBQWNDLGVBQWUsSUFBSTVDLFNBQWtCLEtBQUs7QUFDL0QsUUFBTSxDQUFDNkMsZ0JBQWdCQyxpQkFBaUIsSUFBSTlDLFNBU3pDO0FBQUEsSUFDRCtDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMsT0FBTztBQUFBLElBQ1BDLFdBQVc7QUFBQSxJQUNYQyxhQUFhO0FBQUEsSUFDYkMsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUdELFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSXhELFNBQWtCLEtBQUs7QUFDekUsUUFBTSxDQUFDeUQsVUFBVUMsV0FBVyxJQUFJMUQsU0FRN0I7QUFBQSxJQUNEbUI7QUFBQUEsSUFDQUQ7QUFBQUEsSUFDQXlDLGFBQWE7QUFBQSxJQUNickM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUg7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixDQUFDO0FBR0QsUUFBTSxDQUFDdUMsd0JBQXdCQyx5QkFBeUIsSUFBSTdELFNBQWtCLEtBQUs7QUFDbkYsUUFBTSxDQUFDOEQsbUJBQW1CQyxvQkFBb0IsSUFBSS9ELFNBQWtCLEtBQUs7QUFDekUsUUFBTSxDQUFDZ0Usb0JBQW9CQyxxQkFBcUIsSUFBSWpFLFNBQWlCLENBQUM7QUFHdEUsUUFBTSxDQUFDa0UsY0FBY0MsZUFBZSxJQUFJbkUsU0FBd0IsSUFBSTtBQUNwRSxRQUFNb0UsWUFBWUEsQ0FBQ0MsUUFBZ0I7QUFDakNGLG9CQUFnQkUsR0FBRztBQUNuQkMsZUFBVyxNQUFNSCxnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxFQUM5QztBQUdBLFFBQU1JLGVBQWV0RSxRQUFRLE1BQU07QUFDakMsV0FBT2UsT0FBT3dELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRXZDLE9BQU9ILGVBQWUsS0FBSztBQUFBLEVBQ3pELEdBQUcsQ0FBQ2YsUUFBUWUsZUFBZSxDQUFDO0FBRzVCLFFBQU0yQyxnQkFBZ0J6RSxRQUFRLE1BQU07QUFDbEMsUUFBSXNFLGNBQWM7QUFDaEIsYUFBTztBQUFBLFFBQ0xwRCxhQUFhb0QsYUFBYXBELGVBQWVBO0FBQUFBLFFBQ3pDRCxhQUFhcUQsYUFBYXJELGVBQWVBO0FBQUFBLFFBQ3pDeUMsYUFBYVksYUFBYUk7QUFBQUEsUUFDMUJyRCxZQUFZaUQsYUFBYWpELGNBQWNBO0FBQUFBLFFBQ3ZDQyxNQUFNZ0QsYUFBYUssZUFBZXJEO0FBQUFBLFFBQ2xDSCxVQUFVbUQsYUFBYW5ELFlBQVlBO0FBQUFBLFFBQ25DQyxjQUFja0QsYUFBYWxELGdCQUFnQkE7QUFBQUEsUUFDM0N3RCxTQUFTO0FBQUEsUUFDVEMsUUFBUVAsYUFBYU8sVUFBVTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUVBLFFBQUkvQyxvQkFBb0IsZ0JBQWdCO0FBQ3RDLGFBQU87QUFBQSxRQUNMWjtBQUFBQSxRQUNBRDtBQUFBQSxRQUNBeUMsYUFBYTtBQUFBLFFBQ2JyQyxZQUFZO0FBQUEsUUFDWkM7QUFBQUEsUUFDQUg7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQXdELFNBQVM7QUFBQSxRQUNUQyxRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsTUFDTDNEO0FBQUFBLE1BQ0FEO0FBQUFBLE1BQ0F5QyxhQUFhLEdBQUc1QixlQUFlO0FBQUEsTUFDL0JULFlBQVlTO0FBQUFBLE1BQ1pSO0FBQUFBLE1BQ0FIO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0F3RCxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ1AsY0FBY3hDLGlCQUFpQlosYUFBYUQsYUFBYUksWUFBWUMsTUFBTUgsVUFBVUMsWUFBWSxDQUFDO0FBR3RHdEIsUUFBTWdGLFVBQVUsTUFBTTtBQUNwQnJCLGdCQUFZO0FBQUEsTUFDVnZDLGFBQWF1RCxjQUFjdkQ7QUFBQUEsTUFDM0JELGFBQWF3RCxjQUFjeEQ7QUFBQUEsTUFDM0J5QyxhQUFhZSxjQUFjZjtBQUFBQSxNQUMzQnJDLFlBQVlvRCxjQUFjcEQ7QUFBQUEsTUFDMUJDLE1BQU1tRCxjQUFjbkQ7QUFBQUEsTUFDcEJILFVBQVVzRCxjQUFjdEQ7QUFBQUEsTUFDeEJDLGNBQWNxRCxjQUFjckQ7QUFBQUEsSUFDOUIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDcUQsZUFBZTNDLGVBQWUsQ0FBQztBQUduQyxRQUFNaUQsYUFBOEIvRSxRQUFRLE1BQU07QUFFaEQsUUFBSXNFLGNBQWM7QUFDaEIsWUFBTVUsUUFBeUI7QUFDL0IsVUFBSUMsTUFBTTtBQUdWLFVBQUlYLGFBQWFZLFFBQVE7QUFDdkJaLHFCQUFhWSxPQUFPQyxRQUFRLENBQUNDLEdBQUdDLFFBQVE7QUFDdEMsZ0JBQU1DLFNBQVNGLEVBQUVHLGNBQWMsTUFBTUgsRUFBRW5DLGFBQWE7QUFDcEQrQixnQkFBTVEsS0FBSztBQUFBLFlBQ1R2RCxJQUFJbUQsRUFBRW5ELE1BQU0sU0FBU29ELEdBQUc7QUFBQSxZQUN4QkosS0FBS0E7QUFBQUEsWUFDTG5DLFVBQVU7QUFBQSxZQUNWQyxhQUFhLEdBQUdxQyxFQUFFSyxRQUFRLFFBQVEsTUFBTUwsRUFBRU0sTUFBTSxhQUFhO0FBQUEsWUFDN0QxQyxPQUFPb0MsRUFBRUcsYUFBYUksT0FBT1AsRUFBRUcsVUFBVSxJQUFJO0FBQUEsWUFDN0NLLGFBQWFSLEVBQUVHLGNBQWNILEVBQUVuQyxZQUFZLEdBQUdtQyxFQUFFRyxVQUFVLElBQUlILEVBQUVuQyxTQUFTLEtBQUs7QUFBQSxZQUM5RXFDO0FBQUFBLFlBQ0FsQyxTQUFTZ0MsRUFBRVMsTUFBTUMsT0FBTztBQUFBLFlBQ3hCekMsY0FBYytCLEVBQUVTLE1BQU1FLFlBQVk7QUFBQSxZQUNsQzVDLFNBQVNpQyxFQUFFakMsV0FBVztBQUFBLFlBQ3RCNkMsU0FBUztBQUFBLFlBQ1RDLE9BQU9iLEVBQUVuRDtBQUFBQSxVQUNYLENBQUM7QUFBQSxRQUNILENBQUM7QUFBQSxNQUNIO0FBR0EsVUFBSXFDLGFBQWE0QixNQUFNO0FBQ3JCLFlBQUk1QixhQUFhNEIsS0FBS0MsY0FBYzdCLGFBQWE0QixLQUFLQyxVQUFVQyxTQUFTLEtBQUs5QixhQUFhNEIsS0FBS0MsVUFBVWhELFVBQVU7QUFDbEg2QixnQkFBTVEsS0FBSztBQUFBLFlBQ1R2RCxJQUFJO0FBQUEsWUFDSmdELEtBQUtBO0FBQUFBLFlBQ0xuQyxVQUFVO0FBQUEsWUFDVkMsYUFBYTtBQUFBLFlBQ2JDLE9BQU87QUFBQSxZQUNQNEMsYUFBYTtBQUFBLFlBQ2JOLE9BQU9oQixhQUFhNEIsS0FBS0MsVUFBVUMsVUFBVTtBQUFBLFlBQzdDaEQsU0FBU2tCLGFBQWE0QixLQUFLQyxVQUFVTixNQUFNQyxPQUFPO0FBQUEsWUFDbER6QyxjQUFjaUIsYUFBYTRCLEtBQUtDLFVBQVVOLE1BQU1FLFlBQVk7QUFBQSxZQUM1RDVDLFNBQVNtQixhQUFhNEIsS0FBS0MsVUFBVWhELFdBQVc7QUFBQSxZQUNoRDZDLFNBQVM7QUFBQSxZQUNUSyxTQUFTO0FBQUEsVUFDWCxDQUFDO0FBQUEsUUFDSDtBQUVBLFlBQUkvQixhQUFhNEIsS0FBS0ksVUFBVWhDLGFBQWE0QixLQUFLSSxNQUFNRixTQUFTLEtBQUs5QixhQUFhNEIsS0FBS0ksTUFBTW5ELFVBQVU7QUFDdEc2QixnQkFBTVEsS0FBSztBQUFBLFlBQ1R2RCxJQUFJO0FBQUEsWUFDSmdELEtBQUtBO0FBQUFBLFlBQ0xuQyxVQUFVO0FBQUEsWUFDVkMsYUFBYTtBQUFBLFlBQ2JDLE9BQU87QUFBQSxZQUNQNEMsYUFBYTtBQUFBLFlBQ2JOLE9BQU9oQixhQUFhNEIsS0FBS0ksTUFBTUYsVUFBVTtBQUFBLFlBQ3pDaEQsU0FBU2tCLGFBQWE0QixLQUFLSSxNQUFNVCxNQUFNQyxPQUFPO0FBQUEsWUFDOUN6QyxjQUFjaUIsYUFBYTRCLEtBQUtJLE1BQU1ULE1BQU1FLFlBQVk7QUFBQSxZQUN4RDVDLFNBQVNtQixhQUFhNEIsS0FBS0ksTUFBTW5ELFdBQVc7QUFBQSxZQUM1QzZDLFNBQVM7QUFBQSxZQUNUSyxTQUFTO0FBQUEsVUFDWCxDQUFDO0FBQUEsUUFDSDtBQUVBLFlBQUkvQixhQUFhNEIsS0FBS0ssV0FBV2pDLGFBQWE0QixLQUFLSyxPQUFPSCxTQUFTLEtBQUs5QixhQUFhNEIsS0FBS0ssT0FBT3BELFVBQVU7QUFDekc2QixnQkFBTVEsS0FBSztBQUFBLFlBQ1R2RCxJQUFJO0FBQUEsWUFDSmdELEtBQUtBO0FBQUFBLFlBQ0xuQyxVQUFVO0FBQUEsWUFDVkMsYUFBYTtBQUFBLFlBQ2JDLE9BQU87QUFBQSxZQUNQNEMsYUFBYTtBQUFBLFlBQ2JOLE9BQU9oQixhQUFhNEIsS0FBS0ssT0FBT0gsVUFBVTtBQUFBLFlBQzFDaEQsU0FBU2tCLGFBQWE0QixLQUFLSyxPQUFPVixNQUFNQyxPQUFPO0FBQUEsWUFDL0N6QyxjQUFjaUIsYUFBYTRCLEtBQUtLLE9BQU9WLE1BQU1FLFlBQVk7QUFBQSxZQUN6RDVDLFNBQVNtQixhQUFhNEIsS0FBS0ssT0FBT3BELFdBQVc7QUFBQSxZQUM3QzZDLFNBQVM7QUFBQSxZQUNUSyxTQUFTO0FBQUEsVUFDWCxDQUFDO0FBQUEsUUFDSDtBQUVBLFlBQUkvQixhQUFhNEIsS0FBS00saUJBQWlCbEMsYUFBYTRCLEtBQUtNLGFBQWFKLFNBQVMsS0FBSzlCLGFBQWE0QixLQUFLTSxhQUFhckQsVUFBVTtBQUMzSDZCLGdCQUFNUSxLQUFLO0FBQUEsWUFDVHZELElBQUk7QUFBQSxZQUNKZ0QsS0FBS0E7QUFBQUEsWUFDTG5DLFVBQVU7QUFBQSxZQUNWQyxhQUFhO0FBQUEsWUFDYkMsT0FBTztBQUFBLFlBQ1A0QyxhQUFhO0FBQUEsWUFDYk4sT0FBT2hCLGFBQWE0QixLQUFLTSxhQUFhSixVQUFVO0FBQUEsWUFDaERoRCxTQUFTa0IsYUFBYTRCLEtBQUtNLGFBQWFYLE1BQU1DLE9BQU87QUFBQSxZQUNyRHpDLGNBQWNpQixhQUFhNEIsS0FBS00sYUFBYVgsTUFBTUUsWUFBWTtBQUFBLFlBQy9ENUMsU0FBU21CLGFBQWE0QixLQUFLTSxhQUFhckQsV0FBVztBQUFBLFlBQ25ENkMsU0FBUztBQUFBLFlBQ1RLLFNBQVM7QUFBQSxVQUNYLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUdBLFVBQUkvQixhQUFhbUMsZUFBZW5DLGFBQWFtQyxXQUFXTCxTQUFTLEtBQUs5QixhQUFhbUMsV0FBV3RELFVBQVU7QUFDdEc2QixjQUFNUSxLQUFLO0FBQUEsVUFDVHZELElBQUk7QUFBQSxVQUNKZ0QsS0FBS0E7QUFBQUEsVUFDTG5DLFVBQVU7QUFBQSxVQUNWQyxhQUFhO0FBQUEsVUFDYkMsT0FBTztBQUFBLFVBQ1A0QyxhQUFhO0FBQUEsVUFDYk4sT0FBT2hCLGFBQWFtQyxXQUFXTCxVQUFVO0FBQUEsVUFDekNoRCxTQUFTa0IsYUFBYW1DLFdBQVdaLE1BQU1DLE9BQU87QUFBQSxVQUM5Q3pDLGNBQWNpQixhQUFhbUMsV0FBV1osTUFBTUUsWUFBWTtBQUFBLFVBQ3hENUMsU0FBU21CLGFBQWFtQyxXQUFXdEQsV0FBVztBQUFBLFVBQzVDNkMsU0FBUztBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0g7QUFHQSxVQUFJMUIsYUFBYW9DLFlBQVk7QUFDM0JwQyxxQkFBYW9DLFdBQVd2QixRQUFRLENBQUN3QixJQUFJdEIsUUFBUTtBQUMzQyxjQUFJc0IsR0FBR1AsU0FBUyxLQUFLTyxHQUFHNUQsZUFBZTRELEdBQUd4RCxTQUFTO0FBQ2pENkIsa0JBQU1RLEtBQUs7QUFBQSxjQUNUdkQsSUFBSTBFLEdBQUcxRSxNQUFNLFNBQVNvRCxHQUFHO0FBQUEsY0FDekJKLEtBQUtBO0FBQUFBLGNBQ0xuQyxVQUFVO0FBQUEsY0FDVkMsYUFBYTRELEdBQUc1RCxlQUFlO0FBQUEsY0FDL0JDLE9BQU87QUFBQSxjQUNQNEMsYUFBYTtBQUFBLGNBQ2JOLE9BQU9xQixHQUFHUCxVQUFVO0FBQUEsY0FDcEJoRCxTQUFTdUQsR0FBR2QsTUFBTUMsT0FBTztBQUFBLGNBQ3pCekMsY0FBY3NELEdBQUdkLE1BQU1FLFlBQVk7QUFBQSxjQUNuQzVDLFNBQVN3RCxHQUFHeEQsV0FBVztBQUFBLGNBQ3ZCNkMsU0FBUztBQUFBLGNBQ1RDLE9BQU9VLEdBQUcxRTtBQUFBQSxZQUNaLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUVBLGFBQU8rQztBQUFBQSxJQUNUO0FBR0EsVUFBTTRCLGdCQUNKOUUsb0JBQW9CLGlCQUNoQmhCLFFBQVErRixPQUFPLENBQUNDLE1BQU1BLEVBQUVqQyxXQUFXLFVBQVUsSUFDN0MvRCxRQUFRK0YsT0FBTyxDQUFDQyxNQUFNQSxFQUFFekYsZUFBZVMsbUJBQW1CZ0YsRUFBRWpDLFdBQVcsVUFBVTtBQUV2RixRQUFJK0IsY0FBYzVFLFdBQVcsR0FBRztBQUM5QixhQUFPO0FBQUEsUUFDTDtBQUFBLFVBQ0VDLElBQUk7QUFBQSxVQUNKZ0QsS0FBSztBQUFBLFVBQ0xuQyxVQUFVO0FBQUEsVUFDVkMsYUFBYTtBQUFBLFVBQ2JDLE9BQU87QUFBQSxVQUNQNEMsYUFBYTtBQUFBLFVBQ2JOLE9BQU87QUFBQSxVQUNQbEMsU0FBUztBQUFBLFVBQ1RDLGNBQWM7QUFBQSxVQUNkRixTQUFTO0FBQUEsVUFDVDZDLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFDQTtBQUFBLFVBQ0UvRCxJQUFJO0FBQUEsVUFDSmdELEtBQUs7QUFBQSxVQUNMbkMsVUFBVTtBQUFBLFVBQ1ZDLGFBQWE7QUFBQSxVQUNiQyxPQUFPO0FBQUEsVUFDUDRDLGFBQWE7QUFBQSxVQUNiTixPQUFPO0FBQUEsVUFDUGxDLFNBQVM7QUFBQSxVQUNUQyxjQUFjO0FBQUEsVUFDZEYsU0FBUztBQUFBLFVBQ1Q2QyxTQUFTO0FBQUEsUUFDWDtBQUFBLFFBQ0E7QUFBQSxVQUNFL0QsSUFBSTtBQUFBLFVBQ0pnRCxLQUFLO0FBQUEsVUFDTG5DLFVBQVU7QUFBQSxVQUNWQyxhQUFhO0FBQUEsVUFDYkMsT0FBTztBQUFBLFVBQ1A0QyxhQUFhO0FBQUEsVUFDYk4sT0FBTztBQUFBLFVBQ1BsQyxTQUFTO0FBQUEsVUFDVEMsY0FBYztBQUFBLFVBQ2RGLFNBQVM7QUFBQSxVQUNUNkMsU0FBUztBQUFBLFFBQ1g7QUFBQSxRQUNBO0FBQUEsVUFDRS9ELElBQUk7QUFBQSxVQUNKZ0QsS0FBSztBQUFBLFVBQ0xuQyxVQUFVO0FBQUEsVUFDVkMsYUFBYTtBQUFBLFVBQ2JDLE9BQU87QUFBQSxVQUNQNEMsYUFBYTtBQUFBLFVBQ2JOLE9BQU87QUFBQSxVQUNQbEMsU0FBUztBQUFBLFVBQ1RDLGNBQWM7QUFBQSxVQUNkRixTQUFTO0FBQUEsVUFDVDZDLFNBQVM7QUFBQSxRQUNYO0FBQUEsTUFBQztBQUFBLElBRUw7QUFFQSxXQUFPWSxjQUFjRyxJQUFJLENBQUNELEdBQUd6QixTQUFTO0FBQUEsTUFDcENwRCxJQUFJNkUsRUFBRTdFO0FBQUFBLE1BQ05nRCxLQUFLSSxNQUFNO0FBQUEsTUFDWHZDLFVBQVVnRSxFQUFFaEU7QUFBQUEsTUFDWkMsYUFBYStELEVBQUUvRDtBQUFBQSxNQUNmQyxPQUFPOEQsRUFBRTlELFFBQVEyQyxPQUFPbUIsRUFBRTlELEtBQUssSUFBSTtBQUFBLE1BQ25DNEMsYUFBYWtCLEVBQUVsQixlQUFlO0FBQUEsTUFDOUJOLE9BQU93QixFQUFFVjtBQUFBQSxNQUNUaEQsU0FBUzBELEVBQUUxRCxXQUFXO0FBQUEsTUFDdEJDLGNBQWM7QUFBQSxNQUNkRixTQUFTMkQsRUFBRTNELFdBQVc7QUFBQSxNQUN0QjZDLFNBQVM7QUFBQSxNQUNUQyxPQUFPYSxFQUFFN0U7QUFBQUEsSUFDWCxFQUFFO0FBQUEsRUFDSixHQUFHLENBQUNxQyxjQUFjeEMsaUJBQWlCaEIsT0FBTyxDQUFDO0FBRzNDLFFBQU1rRyxjQUFjaEgsUUFBUSxNQUFNO0FBQ2hDLFdBQU8rRSxXQUNKOEIsT0FBTyxDQUFDSSxNQUFNQSxFQUFFbkUsYUFBYSxRQUFRLEVBQ3JDb0UsT0FBTyxDQUFDQyxLQUFLRixNQUFNRSxNQUFNRixFQUFFM0IsT0FBTyxDQUFDO0FBQUEsRUFDeEMsR0FBRyxDQUFDUCxVQUFVLENBQUM7QUFFZixRQUFNcUMsWUFBWXBILFFBQVEsTUFBTTtBQUM5QixXQUFPK0UsV0FDSjhCLE9BQU8sQ0FBQ0ksTUFBTUEsRUFBRW5FLGFBQWEsTUFBTSxFQUNuQ29FLE9BQU8sQ0FBQ0MsS0FBS0YsTUFBTUUsTUFBTUYsRUFBRTNCLE9BQU8sQ0FBQztBQUFBLEVBQ3hDLEdBQUcsQ0FBQ1AsVUFBVSxDQUFDO0FBRWYsUUFBTXNDLGtCQUFrQnJILFFBQVEsTUFBTTtBQUNwQyxXQUFPK0UsV0FDSjhCLE9BQU8sQ0FBQ0ksTUFBTUEsRUFBRW5FLGFBQWEsZ0JBQWdCbUUsRUFBRW5FLGFBQWEsV0FBVyxFQUN2RW9FLE9BQU8sQ0FBQ0MsS0FBS0YsTUFBTUUsTUFBTUYsRUFBRTNCLE9BQU8sQ0FBQztBQUFBLEVBQ3hDLEdBQUcsQ0FBQ1AsVUFBVSxDQUFDO0FBRWYsUUFBTXVDLGFBQWF0SCxRQUFRLE1BQU07QUFDL0IsV0FBTytFLFdBQ0o4QixPQUFPLENBQUNJLE1BQU1BLEVBQUVuRSxhQUFhLFdBQVdtRSxFQUFFbkUsYUFBYSxPQUFPLEVBQzlEb0UsT0FBTyxDQUFDQyxLQUFLRixNQUFNRSxNQUFNRixFQUFFM0IsT0FBTyxDQUFDO0FBQUEsRUFDeEMsR0FBRyxDQUFDUCxVQUFVLENBQUM7QUFFZixRQUFNd0MsYUFBYVAsY0FBY0ksWUFBWUMsa0JBQWtCQztBQUcvRCxRQUFNRSxtQkFBbUJ4SCxRQUFRLE1BQU07QUFDckMsV0FBTytFLFdBQ0o4QixPQUFPLENBQUNZLFNBQVNBLEtBQUtyRSxPQUFPLEVBQzdCMkQsSUFBSSxDQUFDVSxVQUFVO0FBQUEsTUFDZHhGLElBQUl3RixLQUFLeEYsTUFBTSxRQUFRd0YsS0FBS3hDLEdBQUc7QUFBQSxNQUMvQmEsS0FBSzJCLEtBQUtyRTtBQUFBQSxNQUNWc0IsT0FBTyxHQUFHK0MsS0FBSzNFLFFBQVEsS0FBSzJFLEtBQUsxRSxXQUFXO0FBQUEsTUFDNUNELFVBQVUyRSxLQUFLM0U7QUFBQUEsTUFDZnNELFFBQVFxQixLQUFLbkM7QUFBQUEsTUFDYm5DLFNBQVNzRSxLQUFLdEU7QUFBQUEsTUFDZDRDLFVBQVUwQixLQUFLcEUsZ0JBQWdCLEdBQUdvRSxLQUFLM0UsUUFBUTtBQUFBLElBQ2pELEVBQUU7QUFBQSxFQUNOLEdBQUcsQ0FBQ2lDLFVBQVUsQ0FBQztBQUdmLFFBQU0yQyx3QkFBd0JBLE1BQU07QUFDbEMsUUFBSXBELGdCQUFnQjdDLGVBQWU7QUFDakNBLG9CQUFjNkMsYUFBYXJDLEVBQUU7QUFDN0JrQyxnQkFBVSwwQkFBMEJNLGNBQWNwRCxVQUFVLHlCQUF5QjtBQUFBLElBQ3ZGLE9BQU87QUFDTDhDLGdCQUFVLCtEQUErRDtBQUFBLElBQzNFO0FBQUEsRUFDRjtBQUdBLFFBQU13RCxrQkFBa0JBLENBQUNGLFNBQXdCO0FBQy9DLFFBQUksQ0FBQ0csUUFBUSxvQ0FBb0NILEtBQUsxRSxXQUFXLElBQUksRUFBRztBQUV4RSxRQUFJdUIsZ0JBQWdCL0MsYUFBYTtBQUMvQixVQUFJc0csZUFBNkIsRUFBRSxHQUFHdkQsYUFBYTtBQUVuRCxVQUFJbUQsS0FBS3pCLFlBQVksV0FBV3lCLEtBQUt4QixPQUFPO0FBQzFDNEIscUJBQWEzQyxTQUFTMkMsYUFBYTNDLE9BQU8yQixPQUFPLENBQUN6QixNQUFNQSxFQUFFbkQsT0FBT3dGLEtBQUt4QixLQUFLO0FBQUEsTUFDN0UsV0FBV3dCLEtBQUt6QixZQUFZLFVBQVV5QixLQUFLcEIsU0FBUztBQUNsRHdCLHFCQUFhM0IsT0FBTztBQUFBLFVBQ2xCLEdBQUcyQixhQUFhM0I7QUFBQUEsVUFDaEIsQ0FBQ3VCLEtBQUtwQixPQUFPLEdBQUcsRUFBRUQsUUFBUSxHQUFHakQsU0FBUyxJQUFJMEMsTUFBTSxLQUFLO0FBQUEsUUFDdkQ7QUFBQSxNQUNGLFdBQVc0QixLQUFLekIsWUFBWSxjQUFjO0FBQ3hDNkIscUJBQWFwQixhQUFhLEVBQUVMLFFBQVEsR0FBR2pELFNBQVMsSUFBSTBDLE1BQU0sS0FBSztBQUFBLE1BQ2pFLFdBQVc0QixLQUFLekIsWUFBWSxXQUFXeUIsS0FBS3hCLE9BQU87QUFDakQ0QixxQkFBYW5CLGFBQWFtQixhQUFhbkIsV0FBV0csT0FBTyxDQUFDRixPQUFPQSxHQUFHMUUsT0FBT3dGLEtBQUt4QixLQUFLO0FBQUEsTUFDdkY7QUFHQSxZQUFNNkIsWUFBWUQsYUFBYTNDLE9BQU9nQyxPQUFPLENBQUNhLEdBQUczQyxNQUFNMkMsS0FBSzNDLEVBQUVHLGNBQWMsTUFBTUgsRUFBRW5DLGFBQWEsSUFBSSxDQUFDO0FBQ3RHLFlBQU0rRSxXQUNISCxhQUFhM0IsS0FBS0MsV0FBV0MsVUFBVSxNQUN2Q3lCLGFBQWEzQixLQUFLSSxPQUFPRixVQUFVLE1BQ25DeUIsYUFBYTNCLEtBQUtLLFFBQVFILFVBQVUsTUFDcEN5QixhQUFhM0IsS0FBS00sY0FBY0osVUFBVTtBQUM3QyxZQUFNNkIsZ0JBQWdCSixhQUFhcEIsWUFBWUwsVUFBVTtBQUN6RCxZQUFNOEIsV0FBV0wsYUFBYW5CLFdBQVdRLE9BQU8sQ0FBQ2EsR0FBR0ksTUFBTUosS0FBS0ksRUFBRS9CLFVBQVUsSUFBSSxDQUFDO0FBRWhGeUIsbUJBQWEzRSxjQUFjNEUsWUFBWUUsVUFBVUMsZ0JBQWdCQztBQUNqRTNHLGtCQUFZc0csWUFBWTtBQUN4QjFELGdCQUFVLFlBQVlzRCxLQUFLMUUsV0FBVyxHQUFHO0FBQUEsSUFDM0MsV0FBVzBFLEtBQUt6QixZQUFZLFdBQVd5QixLQUFLeEIsU0FBU3JFLHNCQUFzQjtBQUN6RUEsMkJBQXFCNkYsS0FBS3hCLEtBQUs7QUFDL0I5QixnQkFBVSxZQUFZc0QsS0FBSzFFLFdBQVcsR0FBRztBQUFBLElBQzNDLE9BQU87QUFDTG9CLGdCQUFVLHlCQUF5QjtBQUFBLElBQ3JDO0FBQUEsRUFDRjtBQUdBLFFBQU1pRSxzQkFBc0JBLE1BQU07QUFDaEMsUUFBSSxDQUFDNUYsWUFBYTtBQUVsQixRQUFJOEIsZ0JBQWdCL0MsYUFBYTtBQUMvQixZQUFNc0csZUFBNkIsRUFBRSxHQUFHdkQsYUFBYTtBQUVyRCxVQUFJOUIsWUFBWXdELFlBQVksV0FBV3hELFlBQVl5RCxPQUFPO0FBQ3hELGNBQU1vQyxPQUFPQyxTQUFTOUYsWUFBWVEsS0FBSyxLQUFLO0FBQzVDLFlBQUl1RixPQUFPO0FBQ1gsWUFBSS9GLFlBQVlvRCxZQUFZNEMsU0FBUyxHQUFHLEdBQUc7QUFDekNELGlCQUFPRSxXQUFXakcsWUFBWW9ELFlBQVk4QyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSztBQUFBLFFBQzlELFdBQVdMLE9BQU8sR0FBRztBQUNuQkUsaUJBQU8vRixZQUFZOEMsUUFBUStDO0FBQUFBLFFBQzdCO0FBRUEsY0FBTU0sUUFBUW5HLFlBQVlPLFlBQVkyRixNQUFNLEdBQUc7QUFDL0MsY0FBTWpELE9BQU9rRCxNQUFNLENBQUMsR0FBR0MsS0FBSyxLQUFLO0FBQ2pDLGNBQU1sRCxLQUFLaUQsTUFBTSxDQUFDLEdBQUdDLEtBQUssS0FBSztBQUUvQmYscUJBQWEzQyxTQUFTMkMsYUFBYTNDLE9BQU82QjtBQUFBQSxVQUFJLENBQUMzQixNQUM3Q0EsRUFBRW5ELE9BQU9PLFlBQVl5RCxRQUNqQjtBQUFBLFlBQ0UsR0FBR2I7QUFBQUEsWUFDSEs7QUFBQUEsWUFDQUM7QUFBQUEsWUFDQUgsWUFBWThDO0FBQUFBLFlBQ1pwRixXQUFXc0Y7QUFBQUEsWUFDWHBGLFNBQVNYLFlBQVlXO0FBQUFBLFlBQ3JCMEMsTUFBTXJELFlBQVlZLFVBQ2Q7QUFBQSxjQUNFMEMsS0FBS3RELFlBQVlZO0FBQUFBLGNBQ2pCMkMsVUFBVXZELFlBQVlhLGdCQUFnQjtBQUFBLGNBQ3RDd0YsZ0JBQWdCckcsWUFBWThDO0FBQUFBLFlBQzlCLElBQ0E7QUFBQSxVQUNOLElBQ0FGO0FBQUFBLFFBQ047QUFBQSxNQUNGLFdBQVc1QyxZQUFZd0QsWUFBWSxVQUFVeEQsWUFBWTZELFNBQVM7QUFDaEV3QixxQkFBYTNCLE9BQU87QUFBQSxVQUNsQixHQUFHMkIsYUFBYTNCO0FBQUFBLFVBQ2hCLENBQUMxRCxZQUFZNkQsT0FBTyxHQUFHO0FBQUEsWUFDckJELFFBQVE1RCxZQUFZOEM7QUFBQUEsWUFDcEJuQyxTQUFTWCxZQUFZVztBQUFBQSxZQUNyQjBDLE1BQU1yRCxZQUFZWSxVQUNkO0FBQUEsY0FDRTBDLEtBQUt0RCxZQUFZWTtBQUFBQSxjQUNqQjJDLFVBQVV2RCxZQUFZYSxnQkFBZ0I7QUFBQSxjQUN0Q3dGLGdCQUFnQnJHLFlBQVk4QztBQUFBQSxZQUM5QixJQUNBO0FBQUEsVUFDTjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFdBQVc5QyxZQUFZd0QsWUFBWSxjQUFjO0FBQy9DNkIscUJBQWFwQixhQUFhO0FBQUEsVUFDeEJMLFFBQVE1RCxZQUFZOEM7QUFBQUEsVUFDcEJuQyxTQUFTWCxZQUFZVztBQUFBQSxVQUNyQjBDLE1BQU1yRCxZQUFZWSxVQUNkO0FBQUEsWUFDRTBDLEtBQUt0RCxZQUFZWTtBQUFBQSxZQUNqQjJDLFVBQVV2RCxZQUFZYSxnQkFBZ0I7QUFBQSxZQUN0Q3dGLGdCQUFnQnJHLFlBQVk4QztBQUFBQSxVQUM5QixJQUNBO0FBQUEsUUFDTjtBQUFBLE1BQ0YsV0FBVzlDLFlBQVl3RCxZQUFZLFdBQVd4RCxZQUFZeUQsT0FBTztBQUMvRDRCLHFCQUFhbkIsYUFBYW1CLGFBQWFuQixXQUFXSztBQUFBQSxVQUFJLENBQUNKLE9BQ3JEQSxHQUFHMUUsT0FBT08sWUFBWXlELFFBQ2xCO0FBQUEsWUFDRSxHQUFHVTtBQUFBQSxZQUNINUQsYUFBYVAsWUFBWU87QUFBQUEsWUFDekJxRCxRQUFRNUQsWUFBWThDO0FBQUFBLFlBQ3BCbkMsU0FBU1gsWUFBWVc7QUFBQUEsWUFDckIwQyxNQUFNckQsWUFBWVksVUFDZDtBQUFBLGNBQ0UwQyxLQUFLdEQsWUFBWVk7QUFBQUEsY0FDakIyQyxVQUFVdkQsWUFBWWEsZ0JBQWdCO0FBQUEsY0FDdEN3RixnQkFBZ0JyRyxZQUFZOEM7QUFBQUEsWUFDOUIsSUFDQTtBQUFBLFVBQ04sSUFDQXFCO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBR0EsWUFBTW1CLFlBQVlELGFBQWEzQyxPQUFPZ0MsT0FBTyxDQUFDYSxHQUFHM0MsTUFBTTJDLEtBQUszQyxFQUFFRyxjQUFjLE1BQU1ILEVBQUVuQyxhQUFhLElBQUksQ0FBQztBQUN0RyxZQUFNK0UsV0FDSEgsYUFBYTNCLEtBQUtDLFdBQVdDLFVBQVUsTUFDdkN5QixhQUFhM0IsS0FBS0ksT0FBT0YsVUFBVSxNQUNuQ3lCLGFBQWEzQixLQUFLSyxRQUFRSCxVQUFVLE1BQ3BDeUIsYUFBYTNCLEtBQUtNLGNBQWNKLFVBQVU7QUFDN0MsWUFBTTZCLGdCQUFnQkosYUFBYXBCLFlBQVlMLFVBQVU7QUFDekQsWUFBTThCLFdBQVdMLGFBQWFuQixXQUFXUSxPQUFPLENBQUNhLEdBQUdJLE1BQU1KLEtBQUtJLEVBQUUvQixVQUFVLElBQUksQ0FBQztBQUNoRnlCLG1CQUFhM0UsY0FBYzRFLFlBQVlFLFVBQVVDLGdCQUFnQkM7QUFFakUzRyxrQkFBWXNHLFlBQVk7QUFDeEIxRCxnQkFBVSxZQUFZM0IsWUFBWU8sV0FBVyxHQUFHO0FBQUEsSUFDbEQsV0FBV1AsWUFBWXdELFlBQVksV0FBV3hELFlBQVl5RCxTQUFTdEUsc0JBQXNCO0FBQ3ZGQSwyQkFBcUJhLFlBQVl5RCxPQUFPO0FBQUEsUUFDdENsRCxhQUFhUCxZQUFZTztBQUFBQSxRQUN6QkQsVUFBVU4sWUFBWU07QUFBQUEsUUFDdEJzRCxRQUFRNUQsWUFBWThDO0FBQUFBLFFBQ3BCbkMsU0FBU1gsWUFBWVc7QUFBQUEsUUFDckJDLFNBQVNaLFlBQVlZLFdBQVcwRjtBQUFBQSxRQUNoQzlGLE9BQU9zRixTQUFTOUYsWUFBWVEsS0FBSyxLQUFLOEY7QUFBQUEsUUFDdENsRCxhQUFhcEQsWUFBWW9ELGVBQWVrRDtBQUFBQSxNQUMxQyxDQUFDO0FBQ0QzRSxnQkFBVSxZQUFZM0IsWUFBWU8sV0FBVyxHQUFHO0FBQUEsSUFDbEQ7QUFFQU4sbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBR0EsUUFBTXNHLHlCQUF5QkEsTUFBTTtBQUNuQyxRQUFJLENBQUNuRyxlQUFlRyxlQUFlLENBQUNILGVBQWVNLGFBQWE7QUFDOUQ4RixZQUFNLHNDQUFzQztBQUM1QztBQUFBLElBQ0Y7QUFFQSxVQUFNQyxXQUFXUixXQUFXN0YsZUFBZU0sV0FBVyxLQUFLO0FBQzNELFVBQU1tRixPQUFPQyxTQUFTMUYsZUFBZUksS0FBSyxLQUFLO0FBQy9DLFVBQU11RixPQUFPRSxXQUFXN0YsZUFBZUssU0FBUyxLQUFLO0FBQ3JELFVBQU1pRyxjQUFjRCxXQUFXLElBQUlBLFdBQVdaLE9BQU9FO0FBRXJELFFBQUlqRSxnQkFBZ0IvQyxhQUFhO0FBQy9CLFlBQU1zRyxlQUE2QixFQUFFLEdBQUd2RCxhQUFhO0FBRXJELFVBQUkxQixlQUFlRSxhQUFhLFVBQVU7QUFDeEMsY0FBTTZGLFFBQVEvRixlQUFlRyxZQUFZMkYsTUFBTSxHQUFHO0FBQ2xELGNBQU1qRCxPQUFPa0QsTUFBTSxDQUFDLEdBQUdDLEtBQUssS0FBSztBQUNqQyxjQUFNbEQsS0FBS2lELE1BQU0sQ0FBQyxHQUFHQyxLQUFLLEtBQUs7QUFFL0IsY0FBTU8sV0FBMkI7QUFBQSxVQUMvQmxILElBQUksU0FBU21ILEtBQUtDLElBQUksQ0FBQztBQUFBLFVBQ3ZCNUQ7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQUgsWUFBWThDLFFBQVE7QUFBQSxVQUNwQnBGLFdBQVdzRixRQUFRVztBQUFBQSxVQUNuQi9GLFNBQVNQLGVBQWVPO0FBQUFBLFVBQ3hCMEMsTUFBTWpELGVBQWVRLFVBQ2pCO0FBQUEsWUFDRTBDLEtBQUtsRCxlQUFlUTtBQUFBQSxZQUNwQjJDLFVBQVVuRCxlQUFlUyxnQkFBZ0I7QUFBQSxZQUN6Q3dGLGdCQUFnQks7QUFBQUEsWUFDaEJJLFlBQVk7QUFBQSxVQUNkLElBQ0E7QUFBQSxRQUNOO0FBQ0F6QixxQkFBYTNDLFNBQVMsQ0FBQyxHQUFHMkMsYUFBYTNDLFFBQVFpRSxRQUFRO0FBQUEsTUFDekQsV0FBV3ZHLGVBQWVFLGFBQWEsUUFBUTtBQUU3QytFLHFCQUFhM0IsT0FBTztBQUFBLFVBQ2xCLEdBQUcyQixhQUFhM0I7QUFBQUEsVUFDaEJNLGNBQWM7QUFBQSxZQUNaSixTQUFTeUIsYUFBYTNCLEtBQUtNLGNBQWNKLFVBQVUsS0FBSzhDO0FBQUFBLFlBQ3hEL0YsU0FBU1AsZUFBZU8sV0FBV1AsZUFBZUc7QUFBQUEsWUFDbEQ4QyxNQUFNakQsZUFBZVEsVUFDakI7QUFBQSxjQUNFMEMsS0FBS2xELGVBQWVRO0FBQUFBLGNBQ3BCMkMsVUFBVW5ELGVBQWVTLGdCQUFnQjtBQUFBLGNBQ3pDd0YsZ0JBQWdCSztBQUFBQSxjQUNoQkksWUFBWTtBQUFBLFlBQ2QsSUFDQXpCLGFBQWEzQixLQUFLTSxjQUFjWCxRQUFRO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQUEsTUFDRixXQUFXakQsZUFBZUUsYUFBYSxjQUFjO0FBQ25EK0UscUJBQWFwQixhQUFhO0FBQUEsVUFDeEJMLFNBQVN5QixhQUFhcEIsWUFBWUwsVUFBVSxLQUFLOEM7QUFBQUEsVUFDakQvRixTQUFTUCxlQUFlTyxXQUFXUCxlQUFlRztBQUFBQSxVQUNsRDhDLE1BQU1qRCxlQUFlUSxVQUNqQjtBQUFBLFlBQ0UwQyxLQUFLbEQsZUFBZVE7QUFBQUEsWUFDcEIyQyxVQUFVbkQsZUFBZVMsZ0JBQWdCO0FBQUEsWUFDekN3RixnQkFBZ0JLO0FBQUFBLFlBQ2hCSSxZQUFZO0FBQUEsVUFDZCxJQUNBekIsYUFBYXBCLFlBQVlaLFFBQVE7QUFBQSxRQUN2QztBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU1xQyxZQUFXO0FBQUEsVUFDZmpHLElBQUksU0FBU21ILEtBQUtDLElBQUksQ0FBQztBQUFBLFVBQ3ZCdEcsYUFBYUgsZUFBZUcsZUFBZTtBQUFBLFVBQzNDcUQsUUFBUThDO0FBQUFBLFVBQ1IvRixTQUFTUCxlQUFlTztBQUFBQSxVQUN4QjBDLE1BQU1qRCxlQUFlUSxVQUNqQjtBQUFBLFlBQ0UwQyxLQUFLbEQsZUFBZVE7QUFBQUEsWUFDcEIyQyxVQUFVbkQsZUFBZVMsZ0JBQWdCO0FBQUEsWUFDekN3RixnQkFBZ0JLO0FBQUFBLFlBQ2hCSSxZQUFZO0FBQUEsVUFDZCxJQUNBO0FBQUEsUUFDTjtBQUNBekIscUJBQWFuQixhQUFhLENBQUMsR0FBR21CLGFBQWFuQixZQUFZd0IsU0FBUTtBQUFBLE1BQ2pFO0FBR0EsWUFBTUosWUFBWUQsYUFBYTNDLE9BQU9nQyxPQUFPLENBQUNhLEdBQUczQyxNQUFNMkMsS0FBSzNDLEVBQUVHLGNBQWMsTUFBTUgsRUFBRW5DLGFBQWEsSUFBSSxDQUFDO0FBQ3RHLFlBQU0rRSxXQUNISCxhQUFhM0IsS0FBS0MsV0FBV0MsVUFBVSxNQUN2Q3lCLGFBQWEzQixLQUFLSSxPQUFPRixVQUFVLE1BQ25DeUIsYUFBYTNCLEtBQUtLLFFBQVFILFVBQVUsTUFDcEN5QixhQUFhM0IsS0FBS00sY0FBY0osVUFBVTtBQUM3QyxZQUFNNkIsZ0JBQWdCSixhQUFhcEIsWUFBWUwsVUFBVTtBQUN6RCxZQUFNOEIsV0FBV0wsYUFBYW5CLFdBQVdRLE9BQU8sQ0FBQ2EsR0FBR0ksTUFBTUosS0FBS0ksRUFBRS9CLFVBQVUsSUFBSSxDQUFDO0FBQ2hGeUIsbUJBQWEzRSxjQUFjNEUsWUFBWUUsVUFBVUMsZ0JBQWdCQztBQUVqRTNHLGtCQUFZc0csWUFBWTtBQUN4QjFELGdCQUFVLFVBQVV2QixlQUFlRyxXQUFXLGdCQUFnQjtBQUFBLElBQ2hFLFdBQVdyQixtQkFBbUI7QUFDNUJBLHdCQUFrQjtBQUFBLFFBQ2hCSixNQUFNbUQsY0FBY25EO0FBQUFBLFFBQ3BCeUIsYUFBYUgsZUFBZUcsZUFBZTtBQUFBLFFBQzNDRCxVQUFVRixlQUFlRTtBQUFBQSxRQUN6QnNELFFBQVE4QztBQUFBQSxRQUNSSyxhQUFhO0FBQUEsUUFDYkMsZUFBZS9FLGNBQWN4RDtBQUFBQSxRQUM3QndJLGFBQWE7QUFBQSxRQUNiNUUsUUFBUTtBQUFBLFFBQ1J6QixTQUFTUixlQUFlUSxXQUFXMEY7QUFBQUEsUUFDbkMzRixTQUFTUCxlQUFlTztBQUFBQSxRQUN4QkgsT0FBT3FGLFFBQVFTO0FBQUFBLFFBQ2ZsRCxhQUFheUMsUUFBUUUsT0FBTyxHQUFHRixJQUFJLElBQUlFLElBQUksS0FBS087QUFBQUEsUUFDaER6SCxZQUFZb0QsY0FBY3BEO0FBQUFBLE1BQzVCLENBQUM7QUFDRDhDLGdCQUFVLG1CQUFtQjtBQUFBLElBQy9CO0FBRUF4QixvQkFBZ0IsS0FBSztBQUNyQkUsc0JBQWtCO0FBQUEsTUFDaEJDLFVBQVU7QUFBQSxNQUNWQyxhQUFhO0FBQUEsTUFDYkMsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsU0FBUztBQUFBLE1BQ1RDLFNBQVM7QUFBQSxNQUNUQyxjQUFjO0FBQUEsSUFDaEIsQ0FBQztBQUFBLEVBQ0g7QUFHQSxRQUFNcUcscUJBQXFCQSxNQUFNO0FBQy9CLFFBQUlwRixnQkFBZ0IvQyxhQUFhO0FBQy9CLFlBQU1zRyxlQUE2QjtBQUFBLFFBQ2pDLEdBQUd2RDtBQUFBQSxRQUNISSxPQUFPbEIsU0FBU0U7QUFBQUEsUUFDaEJ4QyxhQUFhc0MsU0FBU3RDO0FBQUFBLFFBQ3RCRCxhQUFhdUMsU0FBU3ZDO0FBQUFBLFFBQ3RCSSxZQUFZbUMsU0FBU25DO0FBQUFBLFFBQ3JCc0QsYUFBYW5CLFNBQVNsQztBQUFBQSxRQUN0QkgsVUFBVXFDLFNBQVNyQztBQUFBQSxRQUNuQkMsY0FBY29DLFNBQVNwQztBQUFBQSxNQUN6QjtBQUNBRyxrQkFBWXNHLFlBQVk7QUFDeEIxRCxnQkFBVSwyQkFBMkI7QUFBQSxJQUN2QyxPQUFPO0FBQ0xBLGdCQUFVLDhCQUE4QjtBQUFBLElBQzFDO0FBQ0FaLHlCQUFxQixLQUFLO0FBQUEsRUFDNUI7QUFHQSxRQUFNb0csb0JBQW9CQSxNQUFNO0FBQzlCLFVBQU1DLEtBQUszSixLQUFLNEosTUFBTUMsU0FBUztBQUcvQixVQUFNQyxTQUFrQjtBQUFBLE1BQ3RCLENBQUMsMEJBQTBCLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7QUFBQSxNQUNyRCxDQUFDLDJCQUEyQixJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0FBQUEsTUFDdEQsQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLE1BQzdDLENBQUMsR0FBR3RGLGNBQWN4RCxXQUFXLFlBQVksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLE1BQ25FO0FBQUEsTUFDQSxDQUFDLFlBQVl3RCxjQUFjdkQsYUFBYSxJQUFJLFlBQVl1RCxjQUFjeEQsYUFBYSxJQUFJLFlBQVl3RCxjQUFjZixXQUFXO0FBQUEsTUFDNUgsQ0FBQyxTQUFTZSxjQUFjbkQsTUFBTSxJQUFJLFNBQVNtRCxjQUFjdEQsVUFBVSxJQUFJLGFBQWFzRCxjQUFjckQsWUFBWTtBQUFBLE1BQzlHLENBQUMsUUFBUXFELGNBQWNwRCxZQUFZLElBQUksV0FBV29ELGNBQWNJLFFBQVEsSUFBSSxJQUFJLEVBQUU7QUFBQSxNQUNsRjtBQUFBLE1BQ0EsQ0FBQyxtQkFBbUIsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLE1BQzlDLENBQUMsUUFBUSxZQUFZLGVBQWUsU0FBUyxnQkFBZ0IsZUFBZSxrQkFBa0IsU0FBUztBQUFBLElBQUM7QUFHMUdFLGVBQVdJLFFBQVEsQ0FBQ3NDLFNBQVM7QUFDM0JzQyxhQUFPdkU7QUFBQUEsUUFBSztBQUFBLFVBQ1ZpQyxLQUFLeEM7QUFBQUEsVUFDTHdDLEtBQUszRTtBQUFBQSxVQUNMMkUsS0FBSzFFO0FBQUFBLFVBQ0wwRSxLQUFLekU7QUFBQUEsVUFDTHlFLEtBQUs3QjtBQUFBQSxVQUNMNkIsS0FBS25DO0FBQUFBLFVBQ0xtQyxLQUFLckUsVUFBVSwyQkFBMkI7QUFBQSxVQUMxQ3FFLEtBQUt0RTtBQUFBQSxRQUFPO0FBQUEsTUFDYjtBQUFBLElBQ0gsQ0FBQztBQUVENEcsV0FBT3ZFLEtBQUssRUFBRTtBQUNkLFFBQUl3QixjQUFjLEdBQUc7QUFDbkIrQyxhQUFPdkUsS0FBSyxDQUFDLElBQUksSUFBSSxJQUFJLElBQUksaUJBQWlCd0IsYUFBYSxJQUFJLEVBQUUsQ0FBQztBQUFBLElBQ3BFO0FBQ0EsUUFBSUksWUFBWSxHQUFHO0FBQ2pCMkMsYUFBT3ZFLEtBQUssQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLGVBQWU0QixXQUFXLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDaEU7QUFDQSxRQUFJQyxrQkFBa0IsR0FBRztBQUN2QjBDLGFBQU92RSxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxxQkFBcUI2QixpQkFBaUIsSUFBSSxFQUFFLENBQUM7QUFBQSxJQUM1RTtBQUNBLFFBQUlDLGFBQWEsR0FBRztBQUNsQnlDLGFBQU92RSxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSx5QkFBeUI4QixZQUFZLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDM0U7QUFDQXlDLFdBQU92RSxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxzQkFBc0IrQixZQUFZLElBQUksRUFBRSxDQUFDO0FBQ3RFd0MsV0FBT3ZFLEtBQUssRUFBRTtBQUNkdUUsV0FBT3ZFLEtBQUssQ0FBQyxpQ0FBaUNmLGNBQWN0RCxVQUFVLElBQUksSUFBSSw0QkFBNEJzRCxjQUFjckQsY0FBYyxJQUFJLEVBQUUsQ0FBQztBQUU3SSxVQUFNNEksS0FBSy9KLEtBQUs0SixNQUFNSSxhQUFhRixNQUFNO0FBR3pDQyxPQUFHLE9BQU8sSUFBSTtBQUFBLE1BQ1osRUFBRUUsS0FBSyxFQUFFO0FBQUE7QUFBQSxNQUNULEVBQUVBLEtBQUssR0FBRztBQUFBO0FBQUEsTUFDVixFQUFFQSxLQUFLLEdBQUc7QUFBQTtBQUFBLE1BQ1YsRUFBRUEsS0FBSyxHQUFHO0FBQUE7QUFBQSxNQUNWLEVBQUVBLEtBQUssR0FBRztBQUFBO0FBQUEsTUFDVixFQUFFQSxLQUFLLEdBQUc7QUFBQTtBQUFBLE1BQ1YsRUFBRUEsS0FBSyxHQUFHO0FBQUE7QUFBQSxNQUNWLEVBQUVBLEtBQUssR0FBRztBQUFBO0FBQUEsSUFBRztBQUdmakssU0FBSzRKLE1BQU1NLGtCQUFrQlAsSUFBSUksSUFBSSxtQkFBbUI7QUFDeEQsVUFBTUksZUFBZTNGLGNBQWNwRCxXQUFXZ0osUUFBUSxpQkFBaUIsR0FBRztBQUMxRXBLLFNBQUtxSyxVQUFVVixJQUFJLHlCQUF5QlEsWUFBWSxPQUFPO0FBQy9EakcsY0FBVSx3Q0FBd0M7QUFBQSxFQUNwRDtBQUdBLFFBQU1vRyxtQkFBbUJBLE1BQU07QUFDN0IsVUFBTUgsZUFBZTNGLGNBQWNwRCxXQUFXZ0osUUFBUSxpQkFBaUIsR0FBRztBQUUxRSxVQUFNRyxnQkFBZ0J6RixXQUNuQmdDO0FBQUFBLE1BQ0MsQ0FBQ1UsU0FBUztBQUFBO0FBQUEsbUZBRWlFQSxLQUFLeEMsR0FBRztBQUFBLGtGQUNUd0MsS0FBSzNFLFFBQVE7QUFBQSwrREFDaEMyRSxLQUFLMUUsV0FBVztBQUFBLG1GQUNJMEUsS0FBS3pFLEtBQUs7QUFBQSxtRkFDVnlFLEtBQUs3QixXQUFXO0FBQUEseUdBQ002QixLQUFLbkMsTUFBTW1GLGVBQWUsQ0FBQztBQUFBLG1GQUNqRGhELEtBQUtyRSxVQUFVLGFBQWEsTUFBTTtBQUFBLCtFQUN0Q3FFLEtBQUt0RSxPQUFPO0FBQUE7QUFBQTtBQUFBLElBR3JGLEVBQ0N1SCxLQUFLLEVBQUU7QUFFVixVQUFNQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBeUJVbEcsY0FBY3hELFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0NBTXJCd0QsY0FBY3ZELFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FJekJ1RCxjQUFjbkQsSUFBSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FNbEJtRCxjQUFjeEQsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQUl6QndELGNBQWN0RCxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQU10QnNELGNBQWNmLFdBQVcsS0FBS2UsY0FBY3BELFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQ0FJdERvRCxjQUFjckQsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCbERvSixhQUFhO0FBQUEsY0FFYnhELGNBQWMsSUFDViw4TkFBOE5BLFlBQVl5RCxlQUFlLENBQUMsdUVBQzFQLEVBQUU7QUFBQSxjQUdOckQsWUFBWSxJQUNSLDROQUE0TkEsVUFBVXFELGVBQWUsQ0FBQyx1RUFDdFAsRUFBRTtBQUFBLGNBR05wRCxrQkFBa0IsSUFDZCxrT0FBa09BLGdCQUFnQm9ELGVBQWUsQ0FBQyx1RUFDbFEsRUFBRTtBQUFBLGNBR05uRCxhQUFhLElBQ1Qsc09BQXNPQSxXQUFXbUQsZUFBZSxDQUFDLHVFQUNqUSxFQUFFO0FBQUE7QUFBQTtBQUFBLDhHQUkwRmxELFdBQVdrRCxlQUFlLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvRUFVckVoRyxjQUFjdEQsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhEQUk1QnNELGNBQWNyRCxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUXBGLFVBQU13SixPQUFPLElBQUlDLEtBQUssQ0FBQyxVQUFVRixXQUFXLEdBQUc7QUFBQSxNQUM3Q0csTUFBTTtBQUFBLElBQ1IsQ0FBQztBQUNELFVBQU1oRixNQUFNaUYsSUFBSUMsZ0JBQWdCSixJQUFJO0FBQ3BDLFVBQU1LLE9BQU9DLFNBQVNDLGNBQWMsR0FBRztBQUN2Q0YsU0FBS0csT0FBT3RGO0FBQ1ptRixTQUFLSSxXQUFXLHlCQUF5QmpCLFlBQVk7QUFDckRjLGFBQVNJLEtBQUtDLFlBQVlOLElBQUk7QUFDOUJBLFNBQUtPLE1BQU07QUFDWE4sYUFBU0ksS0FBS0csWUFBWVIsSUFBSTtBQUM5QkYsUUFBSVcsZ0JBQWdCNUYsR0FBRztBQUN2QjNCLGNBQVUsK0NBQStDO0FBQUEsRUFDM0Q7QUFHQSxRQUFNLENBQUN3SCxpQkFBaUJDLGtCQUFrQixJQUFJN0wsU0FBUyxLQUFLO0FBRzVELFFBQU04TCxrQkFBa0IsWUFBWTtBQUNsQ0QsdUJBQW1CLElBQUk7QUFDdkJ6SCxjQUFVLDhEQUE4RDtBQUN4RSxRQUFJO0FBQ0YsWUFBTWhFLGdDQUFnQztBQUFBLFFBQ3BDMkwsV0FBVztBQUFBLFFBQ1hDLE1BQU10SDtBQUFBQSxRQUNOTyxPQUFPRDtBQUFBQSxRQUNQaUM7QUFBQUEsUUFDQUk7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQXlFLGVBQWV4RTtBQUFBQSxNQUNqQixDQUFDO0FBQ0RyRCxnQkFBVSw4QkFBOEI7QUFBQSxJQUMxQyxTQUFTOEgsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHFCQUFxQkYsR0FBRztBQUN0Q0csYUFBT0MsTUFBTTtBQUFBLElBQ2YsVUFBQztBQUNDVCx5QkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUdBLFFBQU1VLHVCQUF1QixPQUFPeEYsR0FBd0N5RixhQUFzQjtBQUNoRyxVQUFNQyxPQUFPMUYsRUFBRTJGLE9BQU9DLFFBQVEsQ0FBQztBQUMvQixRQUFJRixNQUFNO0FBQ1IsWUFBTUcsU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxhQUFPRSxTQUFTLFlBQVk7QUFDMUIsWUFBSUYsT0FBT0csUUFBUTtBQUNqQixnQkFBTUMsVUFBVUosT0FBT0c7QUFDdkIsZ0JBQU1FLFVBQVUsTUFBTTVNLGtCQUFrQjJNLE9BQU87QUFDL0MsY0FBSSxDQUFDQyxRQUFRQyxXQUFXRCxRQUFRRSxRQUFRLElBQUk7QUFDMUMvSSxzQkFBVSxxREFBcUQ7QUFBQSxVQUNqRTtBQUVBLGdCQUFNZ0osWUFBWTlNLCtCQUErQixJQUFJbU0sS0FBS1ksSUFBSTtBQUU5RCxjQUFJYixVQUFVO0FBQ1oxSiw4QkFBa0IsQ0FBQ3dLLFVBQVU7QUFBQSxjQUMzQixHQUFHQTtBQUFBQSxjQUNIakssU0FBUzJKO0FBQUFBLGNBQ1QxSixjQUFjbUosS0FBS1k7QUFBQUEsY0FDbkJ0SyxVQUFVcUssVUFBVXJLLFlBQVl1SyxLQUFLdks7QUFBQUEsY0FDckNDLGFBQWFvSyxVQUFVRyxVQUFVSCxVQUFVSSxjQUN2QyxXQUFXSixVQUFVRyxNQUFNLE1BQU1ILFVBQVVJLFdBQVcsS0FDdERGLEtBQUt0SztBQUFBQSxjQUNURyxhQUFhaUssVUFBVS9HLFNBQVNULE9BQU93SCxVQUFVL0csTUFBTSxJQUFJaUgsS0FBS25LO0FBQUFBLGNBQ2hFQyxTQUFTZ0ssVUFBVWhLLFdBQVdrSyxLQUFLbEs7QUFBQUEsWUFDckMsRUFBRTtBQUFBLFVBQ0osV0FBV1gsYUFBYTtBQUN0QkM7QUFBQUEsY0FBZSxDQUFDNEssU0FDZEEsT0FDSTtBQUFBLGdCQUNFLEdBQUdBO0FBQUFBLGdCQUNIakssU0FBUzJKO0FBQUFBLGdCQUNUMUosY0FBY21KLEtBQUtZO0FBQUFBLGdCQUNuQnJLLGFBQWFvSyxVQUFVRyxVQUFVSCxVQUFVSSxjQUN2QyxXQUFXSixVQUFVRyxNQUFNLE1BQU1ILFVBQVVJLFdBQVcsS0FDdERGLEtBQUt0SztBQUFBQSxnQkFDVHVDLE9BQU82SCxVQUFVL0csVUFBVWlILEtBQUsvSDtBQUFBQSxjQUNsQyxJQUNBO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFDQW5CLG9CQUFVLHdCQUF3QnFJLEtBQUtZLElBQUksRUFBRTtBQUFBLFFBQy9DO0FBQUEsTUFDRjtBQUNBVCxhQUFPYSxjQUFjaEIsSUFBSTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDBCQUVadkk7QUFBQUEsb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHdNQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLHdEQUF1RCw0QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQ25GLHVCQUFDLFVBQU1BLDBCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxTQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSw2SUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTckQ7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FBd0MsMEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFO0FBQUEsY0FBTTtBQUFBO0FBQUE7QUFBQSxVQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdDQUF1Qyw4QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT2tCO0FBQUFBLGNBQ1AsZUFBZSxDQUFDMkwsUUFBUTFMLG1CQUFtQjBMLEdBQUc7QUFBQSxjQUU5QztBQUFBLHVDQUFDLGlCQUFjLElBQUcsZ0NBQStCLFdBQVUsMkVBQ3pELGlDQUFDLGVBQVksYUFBWSwwQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNFMU07QUFBQUEseUJBQU9nRztBQUFBQSxvQkFBSSxDQUFDdkMsTUFDWCx1QkFBQyxjQUFzQixPQUFPQSxFQUFFdkMsSUFBRztBQUFBO0FBQUEsc0JBQ3hCdUMsRUFBRUU7QUFBQUEsc0JBQU07QUFBQSxzQkFBR0YsRUFBRW5EO0FBQUFBLHNCQUFXO0FBQUEsc0JBQVltRCxFQUFFdEIsWUFBWXVILGVBQWU7QUFBQSx5QkFEM0RqRyxFQUFFdkMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUEsa0JBQ0QsdUJBQUMsY0FBVyxPQUFNLGdCQUFlLHFEQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLGtCQUNyRXlMLE1BQU1qSSxLQUFLLEVBQUV6RCxRQUFRLEVBQUUsR0FBRyxDQUFDMkwsR0FBRzFHLE1BQU0sT0FBT0EsSUFBSSxDQUFDLEVBQUUsRUFBRUY7QUFBQUEsb0JBQUksQ0FBQzZHLFFBQ3hELHVCQUFDLGNBQXFCLE9BQU9BLEtBQzFCQTtBQUFBQTtBQUFBQSxzQkFBSTtBQUFBLHlCQURVQSxLQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQSxxQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBO0FBQUE7QUFBQTtBQUFBLFlBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxXQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUscUNBRWI7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU2xHO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQ1YsT0FBTTtBQUFBLFlBRU47QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUNBQXdDLG9CQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQU07QUFBQTtBQUFBO0FBQUEsVUFMcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU05RCwwQkFBMEIsSUFBSTtBQUFBLFlBQzdDLFdBQVU7QUFBQSxZQUNWLE9BQU07QUFBQSxZQUVOO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlDQUF3QywwQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUFNO0FBQUE7QUFBQTtBQUFBLFVBTDFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFHQzRELGlCQUFpQnhGLFNBQVMsS0FDekI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiZ0Msb0NBQXNCLENBQUM7QUFDdkJGLG1DQUFxQixJQUFJO0FBQUEsWUFDM0I7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUNWLE9BQU07QUFBQSxZQUVOO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlDQUF3Qyw2QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxjQUFNO0FBQUEsY0FDL0QwRCxpQkFBaUJ4RjtBQUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBLFVBVHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVVBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsK0VBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzJIO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU47QUFBQSx1Q0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRTtBQUFBLGdCQUFNO0FBQUE7QUFBQTtBQUFBLFlBTDFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU1k7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FDVixPQUFNO0FBQUEsY0FFTjtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FBd0MsMkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1FO0FBQUEsZ0JBQU07QUFBQTtBQUFBO0FBQUEsWUFMM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTc0I7QUFBQUEsY0FDVCxVQUFVRjtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHlDQUNiQSw0QkFBa0Isa0JBQWtCLG9CQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NBLGtCQUFrQixrQkFBa0I7QUFBQTtBQUFBO0FBQUEsWUFUdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsV0FuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9FQTtBQUFBLFNBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyR0E7QUFBQSxJQUdDbEgsY0FBY0csV0FDYix1QkFBQyxTQUFJLFdBQVUsb0lBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1GQUNiLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MsMkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUUsS0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSywwQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQ2hDLHVCQUFDLFVBQUssV0FBVSxnRkFBOEU7QUFBQTtBQUFBLFlBQ25GSCxjQUFjSTtBQUFBQSxlQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSx1Q0FBcUMsdUdBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBTUYsdUJBQUMsU0FBSSxJQUFHLCtCQUE4QixXQUFVLGdJQUc5QztBQUFBLDZCQUFDLFNBQUksV0FBVSxvR0FFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMkVBQXlFLHNDQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdURBQXFELHVDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUscUZBQW1GLDhCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ1pKO0FBQUFBLDBCQUFjeEQ7QUFBQUEsWUFBWTtBQUFBLGVBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxnR0FDZDtBQUFBLG1DQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFBTTtBQUFBLGVBRHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyx5REFDVHdELGNBQWNJLFdBQVcsYUFDckIsZ0NBQ0EsNkJBQTZCO0FBQUEsY0FDaEM7QUFBQTtBQUFBLGdCQUVNSixjQUFjSTtBQUFBQTtBQUFBQTtBQUFBQSxZQVB6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGdGQUE4RSx3QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxXQUFVLDBDQUNiSix3QkFBY3ZELGVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZ0ZBQThFLHdCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsMENBQ2J1RCx3QkFBY3hELGVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZ0ZBQThFLHdCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsNENBQ2J3RCx3QkFBY2YsZUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsZ0ZBQThFLHFCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsNENBQ2JlLHdCQUFjbkQsUUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxnRkFBOEUscUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSw0Q0FDYm1ELHdCQUFjdEQsWUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxnRkFBOEUseUJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSw0Q0FDYnNELHdCQUFjckQsZ0JBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxhQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMERBO0FBQUEsV0E5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStFQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsUUFBRyxXQUFVLHlGQUNaO0FBQUEsaUNBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQjtBQUFBLFVBQ3JCLHVCQUFDLFVBQUssV0FBVSxrRUFBZ0U7QUFBQTtBQUFBLFlBQzVFMkQsV0FBVy9DO0FBQUFBLFlBQU87QUFBQSxlQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwwQ0FDWitDO0FBQUFBLHFCQUFXZ0M7QUFBQUEsWUFBSSxDQUFDVSxTQUNmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHdDQUF1QztBQUFBO0FBQUEsd0JBQUVBLEtBQUt4QztBQUFBQSwyQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0U7QUFBQSxzQkFDbEUsdUJBQUMsVUFBSyxXQUFVLHdGQUNid0MsZUFBSzNFLFlBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsOENBQTRDO0FBQUE7QUFBQSxzQkFDeEQyRSxLQUFLbkMsTUFBTW1GLGVBQWU7QUFBQSx5QkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVUE7QUFBQSxrQkFFQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLG9DQUNWaEQsZUFBSzFFLGVBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDMEUsS0FBS3pFLFNBQVN5RSxLQUFLN0IsZUFDbEIsdUJBQUMsT0FBRSxXQUFVLCtDQUE2QztBQUFBO0FBQUEsc0JBQzlDNkIsS0FBS3pFO0FBQUFBLHNCQUFNO0FBQUEsc0JBQUl5RSxLQUFLN0I7QUFBQUEseUJBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlDQUNiNkIsZUFBS3RFLFdBQVcsa0JBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQ3NFLEtBQUtyRSxVQUNKO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxTQUFTLE1BQU07QUFDYmYsc0NBQVksQ0FBQztBQUNiRSx3Q0FBYyxDQUFDO0FBQ2ZKLDhDQUFvQjtBQUFBLDRCQUNsQjJELEtBQUsyQixLQUFLckU7QUFBQUEsNEJBQ1ZzQixPQUFPK0MsS0FBSzNFLFdBQVcsT0FBTzJFLEtBQUsxRTtBQUFBQSw0QkFDbkNELFVBQVUyRSxLQUFLM0U7QUFBQUEsNEJBQ2ZzRCxRQUFRcUIsS0FBS25DO0FBQUFBLDRCQUNiUyxVQUFVMEIsS0FBS3BFLGdCQUFpQm9FLEtBQUszRSxXQUFXO0FBQUEsNEJBQ2hEK0ssUUFBUXBHLEtBQUt4RjtBQUFBQSwwQkFDZixDQUFDO0FBQUEsd0JBQ0g7QUFBQSx3QkFDQSxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxVQUFLLFdBQVUseUNBQXdDLDRCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFvRTtBQUFBLDBCQUNwRSx1QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWU7QUFBQTtBQUFBO0FBQUEsc0JBakJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBa0JBLElBRUEsdUJBQUMsVUFBSyxXQUFVLGdDQUErQiwwQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSx1QkExQjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNEJBO0FBQUE7QUFBQTtBQUFBLGNBdERLd0YsS0FBS3hGO0FBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXdEQTtBQUFBLFVBQ0Q7QUFBQSxVQUdELHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzRUFBcUUsa0NBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNHO0FBQUEsWUFDckcrRSxjQUFjLEtBQ2IsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEscUNBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQ25CLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGdCQUFFQSxZQUFZeUQsZUFBZTtBQUFBLG1CQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRjtBQUFBLGlCQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFRHJELFlBQVksS0FDWCx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FDakIsdUJBQUMsVUFBSyxXQUFVLHNDQUFxQztBQUFBO0FBQUEsZ0JBQUVBLFVBQVVxRCxlQUFlO0FBQUEsbUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsaUJBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVEcEQsa0JBQWtCLEtBQ2pCLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLHFDQUFDLFVBQUssaUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUN2Qix1QkFBQyxVQUFLLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxnQkFBRUEsZ0JBQWdCb0QsZUFBZTtBQUFBLG1CQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RjtBQUFBLGlCQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFRG5ELGFBQWEsS0FDWix1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxxQ0FBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtCO0FBQUEsY0FDbEIsdUJBQUMsVUFBSyxXQUFVLHNDQUFxQztBQUFBO0FBQUEsZ0JBQUVBLFdBQVdtRCxlQUFlO0FBQUEsbUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsaUJBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLHFDQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUNsQix1QkFBQyxVQUFLLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxnQkFBRWxELFdBQVdrRCxlQUFlO0FBQUEsbUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsaUJBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLGFBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2RkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxrRkFDYixpQ0FBQyxXQUFNLFdBQVUsOERBQ2Y7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbUVBQ2YsaUNBQUMsUUFDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxvREFBbUQsb0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx3QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQSxZQUM3RCx1QkFBQyxRQUFHLFdBQVUsbUNBQWtDLDJCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLFFBQUcsV0FBVSxvREFBbUQscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsUUFBRyxXQUFVLG9EQUFtRCw0QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxRQUFHLFdBQVUsbURBQWtELHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQ3JFLHVCQUFDLFFBQUcsV0FBVSxvREFBbUQscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsUUFBRyxXQUFVLFNBQVEsdUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCO0FBQUEsZUFSL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSw2QkFDZDFGO0FBQUFBLHVCQUFXZ0M7QUFBQUEsY0FBSSxDQUFDVSxTQUNmLHVCQUFDLFFBQWlCLFdBQVUsaURBQzFCO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF5REEsZUFBS3hDLE9BQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdGO0FBQUEsZ0JBQ2hGLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWixpQ0FBQyxVQUFLLFdBQVUsZ0NBQWdDd0MsZUFBSzNFLFlBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsOERBQ1gyRSxlQUFLMUUsZUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHlEQUF5RDBFLGVBQUt6RSxTQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRjtBQUFBLGdCQUNsRix1QkFBQyxRQUFHLFdBQVUseURBQXlEeUUsZUFBSzdCLGVBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdGO0FBQUEsZ0JBQ3hGLHVCQUFDLFFBQUcsV0FBVSxpRkFBK0U7QUFBQTtBQUFBLGtCQUN6RjZCLEtBQUtuQyxNQUFNbUYsZUFBZTtBQUFBLHFCQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0EsdUJBQUMsUUFBRyxXQUFVLCtDQUNYaEQsZUFBS3JFLFVBQ0o7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNO0FBQ2JmLGtDQUFZLENBQUM7QUFDYkUsb0NBQWMsQ0FBQztBQUNmSiwwQ0FBb0I7QUFBQSx3QkFDbEIyRCxLQUFLMkIsS0FBS3JFO0FBQUFBLHdCQUNWc0IsT0FBTyxHQUFHK0MsS0FBSzNFLFFBQVEsS0FBSzJFLEtBQUsxRSxXQUFXO0FBQUEsd0JBQzVDRCxVQUFVMkUsS0FBSzNFO0FBQUFBLHdCQUNmc0QsUUFBUXFCLEtBQUtuQztBQUFBQSx3QkFDYlMsVUFBVTBCLEtBQUtwRSxnQkFBZ0IsR0FBR29FLEtBQUszRSxRQUFRO0FBQUEsd0JBQy9DK0ssUUFBUXBHLEtBQUt4RjtBQUFBQSxzQkFDZixDQUFDO0FBQUEsb0JBQ0g7QUFBQSxvQkFDQSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHlDQUF3Qyw0QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0U7QUFBQSxzQkFDcEUsdUJBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFVO0FBQUE7QUFBQTtBQUFBLGtCQWpCWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBa0JBLElBRUEsdUJBQUMsVUFBSyxXQUFVLDBDQUF5QyxpQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQsS0F0QjlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0JBO0FBQUEsZ0JBRUEsdUJBQUMsUUFBRyxXQUFVLHNDQUFzQ3dGLGVBQUt0RSxXQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRTtBQUFBLG1CQXpDMURzRSxLQUFLeEYsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBDQTtBQUFBLFlBQ0Q7QUFBQSxZQUdBK0UsY0FBYyxLQUNiLHVCQUFDLFFBQUcsV0FBVSx3Q0FDWjtBQUFBLHFDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsdUVBQXFFLDRCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsaUZBQStFO0FBQUE7QUFBQSxnQkFDekZBLFlBQVl5RCxlQUFlO0FBQUEsbUJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStDO0FBQUEsaUJBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUdEckQsWUFBWSxLQUNYLHVCQUFDLFFBQUcsV0FBVSx3Q0FDWjtBQUFBLHFDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsdUVBQXFFLDBCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsaUZBQStFO0FBQUE7QUFBQSxnQkFDekZBLFVBQVVxRCxlQUFlO0FBQUEsbUJBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStDO0FBQUEsaUJBUGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUdEcEQsa0JBQWtCLEtBQ2pCLHVCQUFDLFFBQUcsV0FBVSx3Q0FDWjtBQUFBLHFDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsdUVBQXFFLDRDQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsaUZBQStFO0FBQUE7QUFBQSxnQkFDekZBLGdCQUFnQm9ELGVBQWU7QUFBQSxtQkFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxpQkFQakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBR0RuRCxhQUFhLEtBQ1osdUJBQUMsUUFBRyxXQUFVLHdDQUNaO0FBQUEscUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSx1RUFBcUUsb0NBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxpRkFBK0U7QUFBQTtBQUFBLGdCQUN6RkEsV0FBV21ELGVBQWU7QUFBQSxtQkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSx3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxpQkFQakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBSUYsdUJBQUMsUUFBRyxXQUFVLDhDQUNaO0FBQUEscUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSx3RUFBc0UsMkJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxrRUFBZ0U7QUFBQTtBQUFBLGdCQUMxRWxELFdBQVdrRCxlQUFlO0FBQUEsbUJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQXpHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBHQTtBQUFBLGFBdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3SEEsS0F6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBIQTtBQUFBLFdBck9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzT0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkRBQXlELDJCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUE7QUFBQSxZQUFPaEcsY0FBY3REO0FBQUFBLGVBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsYUFKbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJEQUF5RCw2QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUFxQ3NELHdCQUFjckQsZ0JBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsYUFKakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0RUFBMEUsb0ZBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBeFdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5V0E7QUFBQSxJQUtDYyxvQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUyxNQUFNQyxvQkFBb0IsSUFBSTtBQUFBLFFBQ3ZDLFdBQVU7QUFBQSxRQUVWO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUMyRSxNQUFNQSxFQUFFZ0gsZ0JBQWdCO0FBQUEsWUFDbEMsV0FBVTtBQUFBLFlBR1Y7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0ZBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxXQUFVLGdFQUNaO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHdEQUF1RCx1QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEU7QUFBQSxvQkFDOUUsdUJBQUMsVUFBTTVMLDJCQUFpQndDLFNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThCO0FBQUEsdUJBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQ1Z4QztBQUFBQSxxQ0FBaUI2RCxZQUFZO0FBQUEsb0JBQXdCO0FBQUEsb0JBQVcsdUJBQUMsWUFBTyxXQUFVLGtCQUFpQjtBQUFBO0FBQUEsc0JBQUU3RCxpQkFBaUJrRSxVQUFVO0FBQUEseUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsdUJBRHJJO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUViO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNN0QsY0FBYyxDQUFDNkMsT0FBT0EsSUFBSSxNQUFNLEdBQUc7QUFBQSxzQkFDbEQsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDRCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvRTtBQUFBO0FBQUEsb0JBTHRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTS9DLFlBQVksQ0FBQzBMLE1BQU1DLEtBQUtDLElBQUlGLElBQUksTUFBTSxHQUFHLENBQUM7QUFBQSxzQkFDekQsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHVCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErRDtBQUFBO0FBQUEsb0JBTGpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTTFMLFlBQVksQ0FBQzBMLE1BQU1DLEtBQUtFLElBQUlILElBQUksTUFBTSxHQUFHLENBQUM7QUFBQSxzQkFDekQsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHdCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTTVMLG9CQUFvQixJQUFJO0FBQUEsc0JBQ3ZDLFdBQVU7QUFBQSxzQkFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2RDtBQUFBO0FBQUEsb0JBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLHFCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdDQTtBQUFBLG1CQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHFHQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU87QUFBQSxvQkFDTGdNLFdBQVcsU0FBUy9MLFFBQVEsWUFBWUUsVUFBVTtBQUFBLG9CQUNsRDhMLFlBQVk7QUFBQSxrQkFDZDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxLQUFLbE0saUJBQWlCNEQ7QUFBQUEsc0JBQ3RCLEtBQUk7QUFBQSxzQkFDSixXQUFVO0FBQUEsc0JBQ1YsZ0JBQWU7QUFBQSxzQkFDZixTQUFTLENBQUNnQixNQUFNO0FBRWQsd0JBQUNBLEVBQUUyRixPQUF1QjRCLE1BQU1DLFVBQVU7QUFDMUMsOEJBQU1DLFNBQVV6SCxFQUFFMkYsT0FBdUIrQjtBQUN6Qyw0QkFBSUQsVUFBVSxDQUFDQSxPQUFPRSxjQUFjLG1CQUFtQixHQUFHO0FBQ3hELGdDQUFNQyxjQUFjeEQsU0FBU0MsY0FBYyxLQUFLO0FBQ2hEdUQsc0NBQVlDLFlBQVk7QUFDeEJELHNDQUFZRSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUdBSW1EMU0saUJBQWlCd0MsS0FBSztBQUFBLG9HQUNuQnhDLGlCQUFpQmtFLFVBQVUsQ0FBQztBQUFBLGlHQUMvQjNCLGNBQWNuRCxJQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLN0ZpTixpQ0FBT2hELFlBQVltRCxXQUFXO0FBQUEsd0JBQ2hDO0FBQUEsc0JBQ0Y7QUFBQTtBQUFBLG9CQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBeUJJO0FBQUE7QUFBQSxnQkFoQ047QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0NBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNEZBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFNeE0saUJBQWlCNEQ7QUFBQUEsc0JBQ3ZCLFVBQVU1RCxpQkFBaUI2RCxZQUFZO0FBQUEsc0JBQ3ZDLFFBQU87QUFBQSxzQkFDUCxLQUFJO0FBQUEsc0JBQ0osV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsVUFBSyxXQUFVLHlDQUF3Qyx3QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0U7QUFBQSx3QkFBTTtBQUFBO0FBQUE7QUFBQSxvQkFQeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBTTdELGlCQUFpQjREO0FBQUFBLHNCQUN2QixRQUFPO0FBQUEsc0JBQ1AsS0FBSTtBQUFBLHNCQUNKLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFVBQUssV0FBVSx5Q0FBd0MsMkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW1FO0FBQUEsd0JBQU07QUFBQTtBQUFBO0FBQUEsb0JBTjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRQTtBQUFBLHFCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTNELG9CQUFvQixJQUFJO0FBQUEsb0JBQ3ZDLFdBQVU7QUFBQSxvQkFBMkc7QUFBQTtBQUFBLGtCQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxtQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4QkE7QUFBQTtBQUFBO0FBQUEsVUF6SEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBMEhBO0FBQUE7QUFBQSxNQTlIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUErSEE7QUFBQSxJQU1ESyxlQUNDLHVCQUFDLFNBQUksV0FBVSxnSUFDYixpQ0FBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsa0VBQ1o7QUFBQSxpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLG9CQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVELHVCQUFDLFVBQUssc0NBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLGVBQWUsSUFBSTtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUE7QUFBQSxVQUovRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx3QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkU7QUFBQSxVQUMzRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT0QsWUFBWU07QUFBQUEsY0FDbkIsZUFBZSxDQUFDMkssUUFDZGhMLGVBQWU7QUFBQSxnQkFDYixHQUFHRDtBQUFBQSxnQkFDSE0sVUFBVTJLO0FBQUFBLGNBQ1osQ0FBQztBQUFBLGNBR0g7QUFBQSx1Q0FBQyxpQkFBYyxXQUFVLHFFQUN2QixpQ0FBQyxlQUFZLGFBQVksY0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNDO0FBQUEseUNBQUMsY0FBVyxPQUFNLFVBQVMsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQ2pDLHVCQUFDLGNBQVcsT0FBTSxRQUFPLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM3Qix1QkFBQyxjQUFXLE9BQU0sY0FBYSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUM7QUFBQSxrQkFDekMsdUJBQUMsY0FBVyxPQUFNLFNBQVEscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEscUJBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQTtBQUFBO0FBQUEsWUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JBO0FBQUEsYUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsbUNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFDdEY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9qTCxZQUFZTztBQUFBQSxjQUNuQixVQUFVLENBQUMrRCxNQUNUckUsZUFBZTtBQUFBLGdCQUNiLEdBQUdEO0FBQUFBLGdCQUNITyxhQUFhK0QsRUFBRTJGLE9BQU9vQztBQUFBQSxjQUN4QixDQUFDO0FBQUEsY0FFSCxXQUFVO0FBQUE7QUFBQSxZQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVM4RztBQUFBLGFBWGhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0QsMENBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZGO0FBQUEsWUFDN0Y7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3JNLFlBQVlRO0FBQUFBLGdCQUNuQixVQUFVLENBQUM4RCxNQUNUckUsZUFBZTtBQUFBLGtCQUNiLEdBQUdEO0FBQUFBLGtCQUNIUSxPQUFPOEQsRUFBRTJGLE9BQU9vQztBQUFBQSxnQkFDbEIsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzhHO0FBQUEsZUFYaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0Qsa0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGO0FBQUEsWUFDckY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsS0FBSTtBQUFBLGdCQUNKLE9BQU9yTSxZQUFZOEM7QUFBQUEsZ0JBQ25CLFVBQVUsQ0FBQ3dCLE1BQ1RyRSxlQUFlO0FBQUEsa0JBQ2IsR0FBR0Q7QUFBQUEsa0JBQ0g4QyxPQUFPbUQsV0FBVzNCLEVBQUUyRixPQUFPb0MsS0FBSyxLQUFLO0FBQUEsZ0JBQ3ZDLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVV1STtBQUFBLGVBWnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx1QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3JNLFlBQVlXO0FBQUFBLGNBQ25CLFVBQVUsQ0FBQzJELE1BQ1RyRSxlQUFlO0FBQUEsZ0JBQ2IsR0FBR0Q7QUFBQUEsZ0JBQ0hXLFNBQVMyRCxFQUFFMkYsT0FBT29DO0FBQUFBLGNBQ3BCLENBQUM7QUFBQSxjQUVILFdBQVU7QUFBQTtBQUFBLFlBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUzhHO0FBQUEsYUFYaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx5Q0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsOEpBQ2Y7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLFVBQU1yTSxzQkFBWVksVUFBVSxzQkFBc0IsdUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkU7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFFBQU87QUFBQSxrQkFDUCxXQUFVO0FBQUEsa0JBQ1YsVUFBVSxDQUFDMEQsTUFBTXdGLHFCQUFxQnhGLEdBQUcsS0FBSztBQUFBO0FBQUEsZ0JBSmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlrRDtBQUFBLGlCQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQ3RFLFlBQVlZLFdBQ1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQ1BYLGVBQWU7QUFBQSxrQkFDYixHQUFHRDtBQUFBQSxrQkFDSFksU0FBUztBQUFBLGtCQUNUQyxjQUFjO0FBQUEsZ0JBQ2hCLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUNBQXdDLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RDtBQUFBLGtCQUFNO0FBQUE7QUFBQTtBQUFBLGNBVnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsZUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUNDYixZQUFZYSxnQkFDWCx1QkFBQyxVQUFLLFdBQVUsdURBQXFEO0FBQUE7QUFBQSxZQUN0RGIsWUFBWWE7QUFBQUEsZUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxXQTNIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEhBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNWixlQUFlLElBQUk7QUFBQSxZQUNsQyxXQUFVO0FBQUEsWUFBZ0k7QUFBQTtBQUFBLFVBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUzJGO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQXFIO0FBQUE7QUFBQSxVQUZqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F6SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBKQSxLQTNKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEpBO0FBQUEsSUFNRDFGLGdCQUNDLHVCQUFDLFNBQUksV0FBVSxnSUFDYixpQ0FBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsa0VBQ1o7QUFBQSxpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLFVBQ2xFLHVCQUFDLFVBQUsscUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxhQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLGdCQUFnQixLQUFLO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkQ7QUFBQTtBQUFBLFVBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbURBQWtELDBCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPQyxlQUFlRTtBQUFBQSxjQUN0QixlQUFlLENBQUMySyxRQUNkNUssa0JBQWtCO0FBQUEsZ0JBQ2hCLEdBQUdEO0FBQUFBLGdCQUNIRSxVQUFVMks7QUFBQUEsY0FDWixDQUFDO0FBQUEsY0FHSDtBQUFBLHVDQUFDLGlCQUFjLFdBQVUscUVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxjQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sVUFBUyxzQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDakMsdUJBQUMsY0FBVyxPQUFNLFFBQU8sb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUEsa0JBQzdCLHVCQUFDLGNBQVcsT0FBTSxjQUFhLDBCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QztBQUFBLGtCQUN6Qyx1QkFBQyxjQUFXLE9BQU0sU0FBUSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQSxxQkFKakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBO0FBQUE7QUFBQSxZQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUNkN0sseUJBQWVFLGFBQWEsV0FBVyxxQ0FBcUMsbUJBRC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUNFRixlQUFlRSxhQUFhLFdBQ3hCLHlCQUNBRixlQUFlRSxhQUFhLFNBQzVCLHNDQUNBO0FBQUEsY0FFTixPQUFPRixlQUFlRztBQUFBQSxjQUN0QixVQUFVLENBQUMrRCxNQUNUakUsa0JBQWtCO0FBQUEsZ0JBQ2hCLEdBQUdEO0FBQUFBLGdCQUNIRyxhQUFhK0QsRUFBRTJGLE9BQU9vQztBQUFBQSxjQUN4QixDQUFDO0FBQUEsY0FFSCxXQUFVO0FBQUE7QUFBQSxZQWhCWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQjhHO0FBQUEsYUFwQmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELHFCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RTtBQUFBLFlBQ3hFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLEtBQUk7QUFBQSxnQkFDSixhQUFZO0FBQUEsZ0JBQ1osT0FBT2pNLGVBQWVJO0FBQUFBLGdCQUN0QixVQUFVLENBQUM4RCxNQUNUakUsa0JBQWtCO0FBQUEsa0JBQ2hCLEdBQUdEO0FBQUFBLGtCQUNISSxPQUFPOEQsRUFBRTJGLE9BQU9vQztBQUFBQSxnQkFDbEIsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV3VGO0FBQUEsZUFiekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0QsOEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsS0FBSTtBQUFBLGdCQUNKLGFBQVk7QUFBQSxnQkFDWixPQUFPak0sZUFBZUs7QUFBQUEsZ0JBQ3RCLFVBQVUsQ0FBQzZELE1BQ1RqRSxrQkFBa0I7QUFBQSxrQkFDaEIsR0FBR0Q7QUFBQUEsa0JBQ0hLLFdBQVc2RCxFQUFFMkYsT0FBT29DO0FBQUFBLGdCQUN0QixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXdUY7QUFBQSxlQWJ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCwyQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxZQUM5RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxLQUFJO0FBQUEsZ0JBQ0osYUFBWTtBQUFBLGdCQUNaLE9BQU9qTSxlQUFlTTtBQUFBQSxnQkFDdEIsVUFBVSxDQUFDNEQsTUFDVGpFLGtCQUFrQjtBQUFBLGtCQUNoQixHQUFHRDtBQUFBQSxrQkFDSE0sYUFBYTRELEVBQUUyRixPQUFPb0M7QUFBQUEsZ0JBQ3hCLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdnSDtBQUFBLGVBYmxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxhQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbURBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx1QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsYUFBWTtBQUFBLGNBQ1osT0FBT2pNLGVBQWVPO0FBQUFBLGNBQ3RCLFVBQVUsQ0FBQzJELE1BQ1RqRSxrQkFBa0I7QUFBQSxnQkFDaEIsR0FBR0Q7QUFBQUEsZ0JBQ0hPLFNBQVMyRCxFQUFFMkYsT0FBT29DO0FBQUFBLGNBQ3BCLENBQUM7QUFBQSxjQUVILFdBQVU7QUFBQTtBQUFBLFlBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVXVGO0FBQUEsYUFaekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx5Q0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxVQUM1Rix1QkFBQyxXQUFNLFdBQVUsb0tBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FLHVCQUFDLFVBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsV0FBVTtBQUFBLGdCQUNWLFVBQVUsQ0FBQy9ILE1BQU13RixxQkFBcUJ4RixHQUFHLElBQUk7QUFBQTtBQUFBLGNBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlpRDtBQUFBLGVBUG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUNDbEUsZUFBZVMsZ0JBQ2QsdUJBQUMsVUFBSyxXQUFVLHVEQUFxRDtBQUFBO0FBQUEsWUFDdERULGVBQWVTO0FBQUFBLGVBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxXQXZJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0lBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNVixnQkFBZ0IsS0FBSztBQUFBLFlBQ3BDLFdBQVU7QUFBQSxZQUFnSTtBQUFBO0FBQUEsVUFGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTb0c7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBcUg7QUFBQTtBQUFBLFVBRmpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXJLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0tBLEtBdktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3S0E7QUFBQSxJQU1EekYscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGdJQUNiLGlDQUFDLFNBQUksV0FBVSx1R0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxrRUFDWjtBQUFBLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MseUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDakUsdUJBQUMsVUFBSyxzQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLGFBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMscUJBQXFCLEtBQUs7QUFBQSxZQUN6QyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsNEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9DLFNBQVN0QztBQUFBQSxjQUNoQixVQUFVLENBQUM0RixNQUFNckQsWUFBWSxFQUFFLEdBQUdELFVBQVV0QyxhQUFhNEYsRUFBRTJGLE9BQU9vQyxNQUFNLENBQUM7QUFBQSxjQUN6RSxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl1RjtBQUFBLGFBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsNEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU9yTCxTQUFTdkM7QUFBQUEsY0FDaEIsVUFBVSxDQUFDNkYsTUFBTXJELFlBQVksRUFBRSxHQUFHRCxVQUFVdkMsYUFBYTZGLEVBQUUyRixPQUFPb0MsTUFBTSxDQUFDO0FBQUEsY0FDekUsV0FBVTtBQUFBO0FBQUEsWUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUY7QUFBQSxhQU56RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbURBQWtELDZCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQ2hGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPckwsU0FBU0U7QUFBQUEsY0FDaEIsVUFBVSxDQUFDb0QsTUFBTXJELFlBQVksRUFBRSxHQUFHRCxVQUFVRSxhQUFhb0QsRUFBRTJGLE9BQU9vQyxNQUFNLENBQUM7QUFBQSxjQUN6RSxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl1RjtBQUFBLGFBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0QsMkJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3JMLFNBQVNuQztBQUFBQSxnQkFDaEIsVUFBVSxDQUFDeUYsTUFBTXJELFlBQVksRUFBRSxHQUFHRCxVQUFVbkMsWUFBWXlGLEVBQUUyRixPQUFPb0MsTUFBTSxDQUFDO0FBQUEsZ0JBQ3hFLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXVGO0FBQUEsZUFOekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0Qsb0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3JMLFNBQVNsQztBQUFBQSxnQkFDaEIsVUFBVSxDQUFDd0YsTUFBTXJELFlBQVksRUFBRSxHQUFHRCxVQUFVbEMsTUFBTXdGLEVBQUUyRixPQUFPb0MsTUFBTSxDQUFDO0FBQUEsZ0JBQ2xFLFdBQVU7QUFBQTtBQUFBLGNBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXVGO0FBQUEsZUFOekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELHlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9yTCxTQUFTckM7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzJGLE1BQU1yRCxZQUFZLEVBQUUsR0FBR0QsVUFBVXJDLFVBQVUyRixFQUFFMkYsT0FBT29DLE1BQU0sQ0FBQztBQUFBLGdCQUN0RSxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1RjtBQUFBLGVBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELDZCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRjtBQUFBLFlBQ2hGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9yTCxTQUFTcEM7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzBGLE1BQU1yRCxZQUFZLEVBQUUsR0FBR0QsVUFBVXBDLGNBQWMwRixFQUFFMkYsT0FBT29DLE1BQU0sQ0FBQztBQUFBLGdCQUMxRSxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1RjtBQUFBLGVBTnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0F6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTXRMLHFCQUFxQixLQUFLO0FBQUEsWUFDekMsV0FBVTtBQUFBLFlBQWdJO0FBQUE7QUFBQSxVQUY1STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNtRztBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFxSDtBQUFBO0FBQUEsVUFGakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBdkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3R0EsS0F6R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBHQTtBQUFBLElBTUQ3RixxQkFBcUIyRCxpQkFBaUJ4RixTQUFTLEtBQzlDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTLE1BQU04QixxQkFBcUIsS0FBSztBQUFBLFFBQ3pDLFdBQVU7QUFBQSxRQUVWO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUNnRCxNQUFNQSxFQUFFZ0gsZ0JBQWdCO0FBQUEsWUFDbEMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0ZBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsUUFBRyxXQUFVLGdFQUNaO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHdEQUF1RCw2QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Y7QUFBQSxvQkFDcEYsdUJBQUMsVUFBSztBQUFBO0FBQUEsc0JBQXlCL0oscUJBQXFCO0FBQUEsc0JBQUU7QUFBQSxzQkFBS3lELGlCQUFpQnhGO0FBQUFBLHNCQUFPO0FBQUEseUJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9GO0FBQUEsdUJBRnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQ1Z3RjtBQUFBQSxxQ0FBaUJ6RCxrQkFBa0IsRUFBRVc7QUFBQUEsb0JBQU07QUFBQSxvQkFBSzhDLGlCQUFpQnpELGtCQUFrQixFQUFFcUM7QUFBQUEsdUJBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNdEMscUJBQXFCLEtBQUs7QUFBQSxvQkFDekMsV0FBVTtBQUFBLG9CQUVWLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZEO0FBQUE7QUFBQSxrQkFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsbUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxnR0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLEtBQUswRCxpQkFBaUJ6RCxrQkFBa0IsRUFBRStCO0FBQUFBLG9CQUMxQyxLQUFJO0FBQUEsb0JBQ0osV0FBVTtBQUFBLG9CQUNWLGdCQUFlO0FBQUE7QUFBQSxrQkFKakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUk4QjtBQUFBLGdCQUk3QjBCLGlCQUFpQnhGLFNBQVMsS0FDekIsbUNBQ0U7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQ1BnQztBQUFBQSx3QkFBc0IsQ0FBQ3FKLFNBQ3JCQSxTQUFTLElBQUk3RixpQkFBaUJ4RixTQUFTLElBQUlxTCxPQUFPO0FBQUEsc0JBQ3BEO0FBQUEsc0JBRUYsV0FBVTtBQUFBLHNCQUVWLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MsNEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9FO0FBQUE7QUFBQSxvQkFSdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUNQcko7QUFBQUEsd0JBQXNCLENBQUNxSixTQUNyQkEsU0FBUzdGLGlCQUFpQnhGLFNBQVMsSUFBSSxJQUFJcUwsT0FBTztBQUFBLHNCQUNwRDtBQUFBLHNCQUVGLFdBQVU7QUFBQSxzQkFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDZCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRTtBQUFBO0FBQUEsb0JBUnZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLHFCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNCQTtBQUFBLG1CQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtDQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHNGQUNaN0YsMkJBQWlCVDtBQUFBQSxnQkFBSSxDQUFDbEIsTUFBTVIsUUFDM0I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUMsU0FBUyxNQUFNckIsc0JBQXNCcUIsR0FBRztBQUFBLG9CQUN4QyxXQUFXLGlHQUNUdEIsdUJBQXVCc0IsTUFDbkIseUNBQ0EsK0NBQStDO0FBQUEsb0JBR3JEO0FBQUEsNkNBQUMsU0FBSSxLQUFLUSxLQUFLQyxLQUFLLEtBQUksU0FBUSxXQUFVLDhCQUE2QixnQkFBZSxpQkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUc7QUFBQSxzQkFDbkcsdUJBQUMsVUFBSyxXQUFVLDhFQUE0RTtBQUFBO0FBQUEsd0JBQ3hGVCxNQUFNO0FBQUEsMkJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBO0FBQUE7QUFBQSxrQkFYS0E7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFhQTtBQUFBLGNBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU1tQyxpQkFBaUJ6RCxrQkFBa0IsRUFBRStCO0FBQUFBLG9CQUMzQyxVQUFVMEIsaUJBQWlCekQsa0JBQWtCLEVBQUVnQztBQUFBQSxvQkFDL0MsUUFBTztBQUFBLG9CQUNQLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxVQUFLLFdBQVUseUNBQXdDLHdCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRTtBQUFBLHNCQUFNO0FBQUE7QUFBQTtBQUFBLGtCQVB4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1qQyxxQkFBcUIsS0FBSztBQUFBLG9CQUN6QyxXQUFVO0FBQUEsb0JBQXFGO0FBQUE7QUFBQSxrQkFGakc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsbUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUE7QUFBQTtBQUFBLFVBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtHQTtBQUFBO0FBQUEsTUF0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdUdBO0FBQUEsSUFNREgsMEJBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsTUFBTUMsMEJBQTBCLEtBQUs7QUFBQSxRQUM5QyxXQUFVO0FBQUEsUUFFVjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxDQUFDa0QsTUFBTUEsRUFBRWdILGdCQUFnQjtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlDQUF3Qyw0QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0U7QUFBQSxrQkFDcEUsdUJBQUMsUUFBRyxXQUFVLHlCQUF3QixzREFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEU7QUFBQSxxQkFGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVNuRTtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrRTtBQUFBLHdCQUFNO0FBQUE7QUFBQTtBQUFBLG9CQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTWTtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRTtBQUFBLHdCQUFNO0FBQUE7QUFBQTtBQUFBLG9CQUozRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTc0I7QUFBQUEsc0JBQ1QsVUFBVUY7QUFBQUEsc0JBQ1YsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTjtBQUFBLCtDQUFDLFVBQUssV0FBVSx5Q0FDYkEsNEJBQWtCLGtCQUFrQixvQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNDQSxrQkFBa0Isa0JBQWtCO0FBQUE7QUFBQTtBQUFBLG9CQVR2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU0vSCwwQkFBMEIsS0FBSztBQUFBLHNCQUM5QyxXQUFVO0FBQUEsc0JBRVYsaUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkQ7QUFBQTtBQUFBLG9CQUovRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxtQkFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQ0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0RBQWdELHNDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdDQUFzQyx1Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxzRUFBb0UsOEJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ1phO0FBQUFBLGtDQUFjeEQ7QUFBQUEsb0JBQVk7QUFBQSx1QkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFVBQUssV0FBVSwwREFBeUQsdUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdGO0FBQUEsb0JBQ2hGLHVCQUFDLFVBQUssV0FBVSw0QkFBNEJ3RCx3QkFBY3ZELGVBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNFO0FBQUEsdUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDBEQUF5RCxvQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkU7QUFBQSxvQkFDN0UsdUJBQUMsVUFBSyxXQUFVLGdDQUFnQ3VELHdCQUFjbkQsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUU7QUFBQSx1QkFGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMERBQXlELHVCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRjtBQUFBLG9CQUNoRix1QkFBQyxVQUFLLFdBQVUsNEJBQTRCbUQsd0JBQWN4RCxlQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRTtBQUFBLHVCQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFVBQUssV0FBVSwwREFBeUQsb0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZFO0FBQUEsb0JBQzdFLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0N3RCx3QkFBY3RELFlBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVFO0FBQUEsdUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDBEQUF5RCx1QkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Y7QUFBQSxvQkFDaEYsdUJBQUMsVUFBSyxXQUFVLGdDQUFnQ3NEO0FBQUFBLG9DQUFjZjtBQUFBQSxzQkFBWTtBQUFBLHNCQUFHZSxjQUFjcEQ7QUFBQUEsc0JBQVc7QUFBQSx5QkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUc7QUFBQSx1QkFGekc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMERBQXlELHdCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRjtBQUFBLG9CQUNqRix1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDb0Qsd0JBQWNyRCxnQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkU7QUFBQSx1QkFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlCQTtBQUFBLGdCQUdBLHVCQUFDLFdBQU0sV0FBVSx3RUFDZjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxtRUFDZixpQ0FBQyxRQUNDO0FBQUEsMkNBQUMsUUFBRyxXQUFVLGtEQUFpRCxvQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUU7QUFBQSxvQkFDbkUsdUJBQUMsUUFBRyxXQUFVLHNDQUFxQyx3QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkQ7QUFBQSxvQkFDM0QsdUJBQUMsUUFBRyxXQUFVLGlDQUFnQywyQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsUUFBRyxXQUFVLGtEQUFpRCxxQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSxvQkFDcEUsdUJBQUMsUUFBRyxXQUFVLGtEQUFpRCx5QkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0U7QUFBQSxvQkFDeEUsdUJBQUMsUUFBRyxXQUFVLGlEQUFnRCxxQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUU7QUFBQSxvQkFDbkUsdUJBQUMsUUFBRyxXQUFVLGtEQUFpRCxxQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSxvQkFDcEUsdUJBQUMsUUFBRyxXQUFVLE9BQU0sdUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsdUJBUjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsV0FBTSxXQUFVLDZCQUNkMkQ7QUFBQUEsK0JBQVdnQztBQUFBQSxzQkFBSSxDQUFDVSxTQUNmLHVCQUFDLFFBQ0M7QUFBQSwrQ0FBQyxRQUFHLFdBQVUsNkNBQTZDQSxlQUFLeEMsT0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0U7QUFBQSx3QkFDcEUsdUJBQUMsUUFBRyxXQUFVLDBEQUEwRHdDLGVBQUszRSxZQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFzRjtBQUFBLHdCQUN0Rix1QkFBQyxRQUFHLFdBQVUsaUNBQWlDMkUsZUFBSzFFLGVBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdFO0FBQUEsd0JBQ2hFLHVCQUFDLFFBQUcsV0FBVSw2Q0FBNkMwRSxlQUFLekUsU0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBc0U7QUFBQSx3QkFDdEUsdUJBQUMsUUFBRyxXQUFVLDZDQUE2Q3lFLGVBQUs3QixlQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0RTtBQUFBLHdCQUM1RSx1QkFBQyxRQUFHLFdBQVUscUVBQW1FO0FBQUE7QUFBQSwwQkFDN0U2QixLQUFLbkMsTUFBTW1GLGVBQWU7QUFBQSw2QkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLFFBQUcsV0FBVSw2Q0FDWGhELGVBQUtyRSxVQUFVLHVCQUFDLFVBQUssV0FBVSx3Q0FBdUMsd0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStELElBQVUsT0FEM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBLHVCQUFDLFFBQUcsV0FBVSxzQkFBc0JxRSxlQUFLdEUsV0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUQ7QUFBQSwyQkFaMUNzRSxLQUFLeEYsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWFBO0FBQUEsb0JBQ0Q7QUFBQSxvQkFDRCx1QkFBQyxRQUFHLFdBQVUsOENBQ1o7QUFBQSw2Q0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLDBEQUF3RCwyQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUcsV0FBVSxvRUFBa0U7QUFBQTtBQUFBLHdCQUM1RXNGLFdBQVdrRCxlQUFlO0FBQUEsMkJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLHdCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErQztBQUFBLHlCQVBqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVFBO0FBQUEsdUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMEJBO0FBQUEscUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0NBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSw4Q0FBNkMsMkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVFO0FBQUEsb0JBQ3ZFLHVCQUFDLFNBQUksV0FBVSw4QkFBOEJoRyx3QkFBY3RELFlBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9FO0FBQUEsdUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsU0FBSSxXQUFVLDhDQUE2Qyw2QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUU7QUFBQSxvQkFDekUsdUJBQUMsU0FBSSxXQUFVLDhCQUE4QnNELHdCQUFjckQsZ0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdFO0FBQUEsdUJBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBckdGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0dBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNd0MsMEJBQTBCLEtBQUs7QUFBQSxrQkFDOUMsV0FBVTtBQUFBLGtCQUFxRjtBQUFBO0FBQUEsZ0JBRmpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBO0FBQUE7QUFBQSxVQTNKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE0SkE7QUFBQTtBQUFBLE1BaEtGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlLQTtBQUFBLE9BdjFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeTFDQTtBQUVKO0FBQUUvQixHQXYyRVdsQixzQkFBeUQ7QUFBQSxLQUF6REE7QUFBeUQsSUFBQW1PO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiWExTWCIsIlRxaUxvZ28iLCJnZW5lcmF0ZUFuZERvd25sb2FkU3RhdGVtZW50UERGIiwiY2hlY2tJbWFnZUNsYXJpdHkiLCJleHRyYWN0Um91dGVBbmREZXRhaWxzRnJvbVRleHQiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIkZpbmFuY2VTdGF0ZW1lbnRWaWV3Iiwib25CYWNrIiwib25OYXZpZ2F0ZSIsImVudHJpZXMiLCJkcmFmdHMiLCJhY3RpdmVEcmFmdElkIiwiY2x1c3Rlck5hbWUiLCJjb2xsZWdlTmFtZSIsInNwb2NOYW1lIiwiZmluYW5jZXJOYW1lIiwic2Vzc2lvbkRheSIsImRhdGUiLCJvblNhdmVEcmFmdCIsIm9uRGVsZXRlRHJhZnQiLCJvblN1Ym1pdERyYWZ0Iiwib25BZGRGaW5hbmNlRW50cnkiLCJvblVwZGF0ZUZpbmFuY2VFbnRyeSIsIm9uRGVsZXRlRmluYW5jZUVudHJ5IiwiX3MiLCJzZWxlY3RlZFZpZXdLZXkiLCJzZXRTZWxlY3RlZFZpZXdLZXkiLCJsZW5ndGgiLCJpZCIsImFjdGl2ZUJpbGxWaWV3ZXIiLCJzZXRBY3RpdmVCaWxsVmlld2VyIiwiYmlsbFpvb20iLCJzZXRCaWxsWm9vbSIsImJpbGxSb3RhdGUiLCJzZXRCaWxsUm90YXRlIiwiZWRpdGluZ0l0ZW0iLCJzZXRFZGl0aW5nSXRlbSIsInNob3dBZGRNb2RhbCIsInNldFNob3dBZGRNb2RhbCIsIm5ld0V4cGVuc2VGb3JtIiwic2V0TmV3RXhwZW5zZUZvcm0iLCJjYXRlZ29yeSIsImRlc2NyaXB0aW9uIiwiY291bnQiLCJwZXJQZXJzb24iLCJ0b3RhbEFtb3VudCIsInJlbWFya3MiLCJiaWxsVXJsIiwiYmlsbEZpbGVOYW1lIiwic2hvd0VkaXRNZXRhTW9kYWwiLCJzZXRTaG93RWRpdE1ldGFNb2RhbCIsIm1ldGFGb3JtIiwic2V0TWV0YUZvcm0iLCJzZXNzaW9uTmFtZSIsInNob3dGdWxsU3RhdGVtZW50TW9kYWwiLCJzZXRTaG93RnVsbFN0YXRlbWVudE1vZGFsIiwic2hvd0FsbEJpbGxzTW9kYWwiLCJzZXRTaG93QWxsQmlsbHNNb2RhbCIsImFjdGl2ZUdhbGxlcnlJbmRleCIsInNldEFjdGl2ZUdhbGxlcnlJbmRleCIsInRvYXN0TWVzc2FnZSIsInNldFRvYXN0TWVzc2FnZSIsInNob3dUb2FzdCIsIm1zZyIsInNldFRpbWVvdXQiLCJjdXJyZW50RHJhZnQiLCJmaW5kIiwiZCIsInN0YXRlbWVudE1ldGEiLCJ0aXRsZSIsInNlc3Npb25EYXRlIiwiaXNEcmFmdCIsInN0YXR1cyIsInVzZUVmZmVjdCIsInRhYmxlSXRlbXMiLCJpdGVtcyIsInNObyIsInJvdXRlcyIsImZvckVhY2giLCJyIiwiaWR4IiwidG90YWwiLCJ2b2x1bnRlZXJzIiwicHVzaCIsImZyb20iLCJ0byIsIlN0cmluZyIsImNvdW50QW1vdW50IiwiYmlsbCIsInVybCIsImZpbGVOYW1lIiwicmF3VHlwZSIsInJhd0lkIiwiZm9vZCIsImJyZWFrZmFzdCIsImFtb3VudCIsImZvb2RLZXkiLCJsdW5jaCIsImRpbm5lciIsInJlZnJlc2htZW50cyIsInN0YXRpb25lcnkiLCJvdGhlckl0ZW1zIiwib3QiLCJzb3VyY2VFbnRyaWVzIiwiZmlsdGVyIiwiZSIsIm1hcCIsInRyYXZlbFRvdGFsIiwiaSIsInJlZHVjZSIsInN1bSIsImZvb2RUb3RhbCIsInN0YXRpb25lcnlUb3RhbCIsIm90aGVyVG90YWwiLCJncmFuZFRvdGFsIiwiYWxsQXR0YWNoZWRCaWxscyIsIml0ZW0iLCJoYW5kbGVTdWJtaXRTdGF0ZW1lbnQiLCJoYW5kbGVEZWxldGVSb3ciLCJjb25maXJtIiwidXBkYXRlZERyYWZ0IiwibmV3VHJhdmVsIiwicyIsIm5ld0Zvb2QiLCJuZXdTdGF0aW9uZXJ5IiwibmV3T3RoZXIiLCJvIiwiaGFuZGxlU2F2ZUVkaXRlZFJvdyIsInZvbHMiLCJwYXJzZUludCIsInBlclAiLCJpbmNsdWRlcyIsInBhcnNlRmxvYXQiLCJzcGxpdCIsInBhcnRzIiwidHJpbSIsImRldGVjdGVkQW1vdW50IiwidW5kZWZpbmVkIiwiaGFuZGxlQWRkTmV3RXhwZW5zZVJvdyIsImFsZXJ0IiwidG90YWxBbXQiLCJmaW5hbEFtb3VudCIsIm5ld1JvdXRlIiwiRGF0ZSIsIm5vdyIsImlzVmVyaWZpZWQiLCJwYW5jaGF5YXRJZCIsInBhbmNoYXlhdE5hbWUiLCJ2aWxsYWdlTmFtZSIsImhhbmRsZVNhdmVNZXRhZGF0YSIsImhhbmRsZUV4cG9ydEV4Y2VsIiwid2IiLCJ1dGlscyIsImJvb2tfbmV3Iiwid3NEYXRhIiwid3MiLCJhb2FfdG9fc2hlZXQiLCJ3Y2giLCJib29rX2FwcGVuZF9zaGVldCIsImNsZWFuU2Vzc2lvbiIsInJlcGxhY2UiLCJ3cml0ZUZpbGUiLCJoYW5kbGVFeHBvcnRXb3JkIiwidGFibGVSb3dzSHRtbCIsInRvTG9jYWxlU3RyaW5nIiwiam9pbiIsIndvcmRDb250ZW50IiwiYmxvYiIsIkJsb2IiLCJ0eXBlIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwibGluayIsImRvY3VtZW50IiwiY3JlYXRlRWxlbWVudCIsImhyZWYiLCJkb3dubG9hZCIsImJvZHkiLCJhcHBlbmRDaGlsZCIsImNsaWNrIiwicmVtb3ZlQ2hpbGQiLCJyZXZva2VPYmplY3RVUkwiLCJpc0dlbmVyYXRpbmdQZGYiLCJzZXRJc0dlbmVyYXRpbmdQZGYiLCJoYW5kbGVFeHBvcnRQREYiLCJlbGVtZW50SWQiLCJtZXRhIiwiYXR0YWNoZWRCaWxscyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsIndpbmRvdyIsInByaW50IiwiaGFuZGxlVXBsb2FkQmlsbEZpbGUiLCJpc0Zvck5ldyIsImZpbGUiLCJ0YXJnZXQiLCJmaWxlcyIsInJlYWRlciIsIkZpbGVSZWFkZXIiLCJvbmxvYWQiLCJyZXN1bHQiLCJkYXRhVXJsIiwiY2xhcml0eSIsImlzQ2xlYXIiLCJzY29yZSIsImV4dHJhY3RlZCIsIm5hbWUiLCJwcmV2Iiwib3JpZ2luIiwiZGVzdGluYXRpb24iLCJyZWFkQXNEYXRhVVJMIiwidmFsIiwiQXJyYXkiLCJfIiwiZGF5IiwiaXRlbUlkIiwic3RvcFByb3BhZ2F0aW9uIiwieiIsIk1hdGgiLCJtaW4iLCJtYXgiLCJ0cmFuc2Zvcm0iLCJ0cmFuc2l0aW9uIiwic3R5bGUiLCJkaXNwbGF5IiwicGFyZW50IiwicGFyZW50RWxlbWVudCIsInF1ZXJ5U2VsZWN0b3IiLCJmYWxsYmFja0RpdiIsImNsYXNzTmFtZSIsImlubmVySFRNTCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmluYW5jZVN0YXRlbWVudFZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgWExTWCBmcm9tICd4bHN4JztcbmltcG9ydCB7IFRhYlR5cGUsIEZpbmFuY2VFbnRyeSwgRmluYW5jZURyYWZ0LCBSb3V0ZURyYWZ0SXRlbSwgRm9vZERyYWZ0SXRlbSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IFRxaUxvZ28gfSBmcm9tICcuL1RxaUxvZ28nO1xuaW1wb3J0IHsgZ2VuZXJhdGVBbmREb3dubG9hZFN0YXRlbWVudFBERiB9IGZyb20gJy4uL3V0aWxzL3BkZkdlbmVyYXRvcic7XG5pbXBvcnQgeyBjaGVja0ltYWdlQ2xhcml0eSwgZXh0cmFjdFJvdXRlQW5kRGV0YWlsc0Zyb21UZXh0IH0gZnJvbSAnLi4vdXRpbHMvYmlsbFBhcnNlcic7XG5pbXBvcnQge1xuICBTZWxlY3QsXG4gIFNlbGVjdENvbnRlbnQsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdFRyaWdnZXIsXG4gIFNlbGVjdFZhbHVlLFxufSBmcm9tICcuL3VpL3NlbGVjdCc7XG5cbmludGVyZmFjZSBTdGF0ZW1lbnRJdGVtIHtcbiAgaWQ6IHN0cmluZztcbiAgc05vOiBudW1iZXI7XG4gIGNhdGVnb3J5OiAnVHJhdmVsJyB8ICdGb29kJyB8ICdTdGF0aW9uZXJ5JyB8ICdPdGhlcicgfCAnTWF0ZXJpYWxzJyB8ICdBZG1pbic7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIGNvdW50OiBzdHJpbmc7XG4gIGNvdW50QW1vdW50OiBzdHJpbmc7XG4gIHRvdGFsOiBudW1iZXI7XG4gIGJpbGxVcmw6IHN0cmluZyB8IG51bGw7XG4gIGJpbGxGaWxlTmFtZT86IHN0cmluZztcbiAgcmVtYXJrczogc3RyaW5nO1xuICByYXdUeXBlPzogJ3JvdXRlJyB8ICdmb29kJyB8ICdzdGF0aW9uZXJ5JyB8ICdvdGhlcicgfCAnZW50cnknO1xuICByYXdJZD86IHN0cmluZztcbiAgZm9vZEtleT86ICdicmVha2Zhc3QnIHwgJ2x1bmNoJyB8ICdkaW5uZXInIHwgJ3JlZnJlc2htZW50cyc7XG59XG5cbmludGVyZmFjZSBGaW5hbmNlU3RhdGVtZW50Vmlld1Byb3BzIHtcbiAgb25CYWNrOiAoKSA9PiB2b2lkO1xuICBvbk5hdmlnYXRlOiAodGFiOiBUYWJUeXBlLCB0YXJnZXRJZD86IHN0cmluZykgPT4gdm9pZDtcbiAgZW50cmllcz86IEZpbmFuY2VFbnRyeVtdO1xuICBkcmFmdHM/OiBGaW5hbmNlRHJhZnRbXTtcbiAgYWN0aXZlRHJhZnRJZD86IHN0cmluZztcbiAgY2x1c3Rlck5hbWU/OiBzdHJpbmc7XG4gIGNvbGxlZ2VOYW1lPzogc3RyaW5nO1xuICBzcG9jTmFtZT86IHN0cmluZztcbiAgZmluYW5jZXJOYW1lPzogc3RyaW5nO1xuICBzZXNzaW9uRGF5Pzogc3RyaW5nO1xuICBkYXRlPzogc3RyaW5nO1xuICBvblNhdmVEcmFmdD86IChkcmFmdDogRmluYW5jZURyYWZ0KSA9PiB2b2lkO1xuICBvbkRlbGV0ZURyYWZ0PzogKGRyYWZ0SWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25TdWJtaXREcmFmdD86IChkcmFmdElkOiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uQWRkRmluYW5jZUVudHJ5PzogKGVudHJ5OiBPbWl0PEZpbmFuY2VFbnRyeSwgJ2lkJz4pID0+IHZvaWQ7XG4gIG9uVXBkYXRlRmluYW5jZUVudHJ5PzogKGlkOiBzdHJpbmcsIHVwZGF0ZWQ6IFBhcnRpYWw8RmluYW5jZUVudHJ5PikgPT4gdm9pZDtcbiAgb25EZWxldGVGaW5hbmNlRW50cnk/OiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEZpbmFuY2VTdGF0ZW1lbnRWaWV3OiBSZWFjdC5GQzxGaW5hbmNlU3RhdGVtZW50Vmlld1Byb3BzPiA9ICh7XG4gIG9uQmFjayxcbiAgb25OYXZpZ2F0ZSxcbiAgZW50cmllcyA9IFtdLFxuICBkcmFmdHMgPSBbXSxcbiAgYWN0aXZlRHJhZnRJZCxcbiAgY2x1c3Rlck5hbWUgPSAnRGhhcm1hcHVyaScsXG4gIGNvbGxlZ2VOYW1lID0gJ0suUy5SYW5nYXNhbXkgY29sbGVnZSBvZiBUZWNobm9sb2d5JyxcbiAgc3BvY05hbWUgPSAnTmFyZW5kaGFyJyxcbiAgZmluYW5jZXJOYW1lID0gJ1RRSSBGaW5hbmNlIFRlYW0nLFxuICBzZXNzaW9uRGF5ID0gJ0RheSAyJyxcbiAgZGF0ZSA9ICcyMDI2LTA4LTIwJyxcbiAgb25TYXZlRHJhZnQsXG4gIG9uRGVsZXRlRHJhZnQsXG4gIG9uU3VibWl0RHJhZnQsXG4gIG9uQWRkRmluYW5jZUVudHJ5LFxuICBvblVwZGF0ZUZpbmFuY2VFbnRyeSxcbiAgb25EZWxldGVGaW5hbmNlRW50cnksXG59KSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZFZpZXdLZXksIHNldFNlbGVjdGVkVmlld0tleV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgIGFjdGl2ZURyYWZ0SWQgfHwgKGRyYWZ0cy5sZW5ndGggPiAwID8gZHJhZnRzWzBdLmlkIDogJ2FsbC1hcHByb3ZlZCcpXG4gICk7XG5cbiAgLy8gQmlsbCBMaWdodGJveCBNb2RhbCBzdGF0ZVxuICBjb25zdCBbYWN0aXZlQmlsbFZpZXdlciwgc2V0QWN0aXZlQmlsbFZpZXdlcl0gPSB1c2VTdGF0ZTx7XG4gICAgdXJsOiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIGFtb3VudD86IG51bWJlcjtcbiAgICBmaWxlTmFtZT86IHN0cmluZztcbiAgICBpdGVtSWQ/OiBzdHJpbmc7XG4gIH0gfCBudWxsPihudWxsKTtcblxuICBjb25zdCBbYmlsbFpvb20sIHNldEJpbGxab29tXSA9IHVzZVN0YXRlPG51bWJlcj4oMSk7XG4gIGNvbnN0IFtiaWxsUm90YXRlLCBzZXRCaWxsUm90YXRlXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgLy8gRWRpdCBFeHBlbnNlIFJvdyBNb2RhbCBzdGF0ZVxuICBjb25zdCBbZWRpdGluZ0l0ZW0sIHNldEVkaXRpbmdJdGVtXSA9IHVzZVN0YXRlPFN0YXRlbWVudEl0ZW0gfCBudWxsPihudWxsKTtcblxuICAvLyBBZGQgRXhwZW5zZSBSb3cgTW9kYWwgc3RhdGVcbiAgY29uc3QgW3Nob3dBZGRNb2RhbCwgc2V0U2hvd0FkZE1vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW25ld0V4cGVuc2VGb3JtLCBzZXROZXdFeHBlbnNlRm9ybV0gPSB1c2VTdGF0ZTx7XG4gICAgY2F0ZWdvcnk6ICdUcmF2ZWwnIHwgJ0Zvb2QnIHwgJ1N0YXRpb25lcnknIHwgJ090aGVyJztcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgIGNvdW50OiBzdHJpbmc7XG4gICAgcGVyUGVyc29uOiBzdHJpbmc7XG4gICAgdG90YWxBbW91bnQ6IHN0cmluZztcbiAgICByZW1hcmtzOiBzdHJpbmc7XG4gICAgYmlsbFVybDogc3RyaW5nIHwgbnVsbDtcbiAgICBiaWxsRmlsZU5hbWU6IHN0cmluZztcbiAgfT4oe1xuICAgIGNhdGVnb3J5OiAnVHJhdmVsJyxcbiAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgY291bnQ6ICcnLFxuICAgIHBlclBlcnNvbjogJycsXG4gICAgdG90YWxBbW91bnQ6ICcnLFxuICAgIHJlbWFya3M6ICcnLFxuICAgIGJpbGxVcmw6IG51bGwsXG4gICAgYmlsbEZpbGVOYW1lOiAnJyxcbiAgfSk7XG5cbiAgLy8gRWRpdCBNZXRhZGF0YSBNb2RhbCBzdGF0ZVxuICBjb25zdCBbc2hvd0VkaXRNZXRhTW9kYWwsIHNldFNob3dFZGl0TWV0YU1vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW21ldGFGb3JtLCBzZXRNZXRhRm9ybV0gPSB1c2VTdGF0ZTx7XG4gICAgY29sbGVnZU5hbWU6IHN0cmluZztcbiAgICBjbHVzdGVyTmFtZTogc3RyaW5nO1xuICAgIHNlc3Npb25OYW1lOiBzdHJpbmc7XG4gICAgc2Vzc2lvbkRheTogc3RyaW5nO1xuICAgIGRhdGU6IHN0cmluZztcbiAgICBzcG9jTmFtZTogc3RyaW5nO1xuICAgIGZpbmFuY2VyTmFtZTogc3RyaW5nO1xuICB9Pih7XG4gICAgY29sbGVnZU5hbWUsXG4gICAgY2x1c3Rlck5hbWUsXG4gICAgc2Vzc2lvbk5hbWU6ICdEYXkgMiAtIFRyYXZlbCAmIFJlZnJlc2htZW50cyBTaGVldCcsXG4gICAgc2Vzc2lvbkRheSxcbiAgICBkYXRlLFxuICAgIHNwb2NOYW1lLFxuICAgIGZpbmFuY2VyTmFtZSxcbiAgfSk7XG5cbiAgLy8gRnVsbCBTdGF0ZW1lbnQgLyBBbGwgQmlsbHMgTW9kYWwgc3RhdGVcbiAgY29uc3QgW3Nob3dGdWxsU3RhdGVtZW50TW9kYWwsIHNldFNob3dGdWxsU3RhdGVtZW50TW9kYWxdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbc2hvd0FsbEJpbGxzTW9kYWwsIHNldFNob3dBbGxCaWxsc01vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2FjdGl2ZUdhbGxlcnlJbmRleCwgc2V0QWN0aXZlR2FsbGVyeUluZGV4XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgLy8gVG9hc3QgbWVzc2FnZVxuICBjb25zdCBbdG9hc3RNZXNzYWdlLCBzZXRUb2FzdE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNob3dUb2FzdCA9IChtc2c6IHN0cmluZykgPT4ge1xuICAgIHNldFRvYXN0TWVzc2FnZShtc2cpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VG9hc3RNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBGaW5kIGlmIGN1cnJlbnQgdmlldyBpcyBhIGRyYWZ0XG4gIGNvbnN0IGN1cnJlbnREcmFmdCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBkcmFmdHMuZmluZCgoZCkgPT4gZC5pZCA9PT0gc2VsZWN0ZWRWaWV3S2V5KSB8fCBudWxsO1xuICB9LCBbZHJhZnRzLCBzZWxlY3RlZFZpZXdLZXldKTtcblxuICAvLyBEZXJpdmUgc3RhdGVtZW50IG1ldGFkYXRhXG4gIGNvbnN0IHN0YXRlbWVudE1ldGEgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoY3VycmVudERyYWZ0KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb2xsZWdlTmFtZTogY3VycmVudERyYWZ0LmNvbGxlZ2VOYW1lIHx8IGNvbGxlZ2VOYW1lLFxuICAgICAgICBjbHVzdGVyTmFtZTogY3VycmVudERyYWZ0LmNsdXN0ZXJOYW1lIHx8IGNsdXN0ZXJOYW1lLFxuICAgICAgICBzZXNzaW9uTmFtZTogY3VycmVudERyYWZ0LnRpdGxlLFxuICAgICAgICBzZXNzaW9uRGF5OiBjdXJyZW50RHJhZnQuc2Vzc2lvbkRheSB8fCBzZXNzaW9uRGF5LFxuICAgICAgICBkYXRlOiBjdXJyZW50RHJhZnQuc2Vzc2lvbkRhdGUgfHwgZGF0ZSxcbiAgICAgICAgc3BvY05hbWU6IGN1cnJlbnREcmFmdC5zcG9jTmFtZSB8fCBzcG9jTmFtZSxcbiAgICAgICAgZmluYW5jZXJOYW1lOiBjdXJyZW50RHJhZnQuZmluYW5jZXJOYW1lIHx8IGZpbmFuY2VyTmFtZSxcbiAgICAgICAgaXNEcmFmdDogdHJ1ZSxcbiAgICAgICAgc3RhdHVzOiBjdXJyZW50RHJhZnQuc3RhdHVzIHx8ICdEcmFmdCcsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmIChzZWxlY3RlZFZpZXdLZXkgPT09ICdhbGwtYXBwcm92ZWQnKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb2xsZWdlTmFtZSxcbiAgICAgICAgY2x1c3Rlck5hbWUsXG4gICAgICAgIHNlc3Npb25OYW1lOiAnQ29tYmluZWQgQ2x1c3RlciBGaW5hbmNlIFN0YXRlbWVudCcsXG4gICAgICAgIHNlc3Npb25EYXk6ICdBbGwgU2Vzc2lvbnMnLFxuICAgICAgICBkYXRlOiBkYXRlLFxuICAgICAgICBzcG9jTmFtZSxcbiAgICAgICAgZmluYW5jZXJOYW1lLFxuICAgICAgICBpc0RyYWZ0OiBmYWxzZSxcbiAgICAgICAgc3RhdHVzOiAnQXBwcm92ZWQnIGFzIGNvbnN0LFxuICAgICAgfTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgY29sbGVnZU5hbWUsXG4gICAgICBjbHVzdGVyTmFtZSxcbiAgICAgIHNlc3Npb25OYW1lOiBgJHtzZWxlY3RlZFZpZXdLZXl9IEZpbmFuY2UgU3RhdGVtZW50YCxcbiAgICAgIHNlc3Npb25EYXk6IHNlbGVjdGVkVmlld0tleSxcbiAgICAgIGRhdGU6IGRhdGUsXG4gICAgICBzcG9jTmFtZSxcbiAgICAgIGZpbmFuY2VyTmFtZSxcbiAgICAgIGlzRHJhZnQ6IGZhbHNlLFxuICAgICAgc3RhdHVzOiAnQXBwcm92ZWQnIGFzIGNvbnN0LFxuICAgIH07XG4gIH0sIFtjdXJyZW50RHJhZnQsIHNlbGVjdGVkVmlld0tleSwgY29sbGVnZU5hbWUsIGNsdXN0ZXJOYW1lLCBzZXNzaW9uRGF5LCBkYXRlLCBzcG9jTmFtZSwgZmluYW5jZXJOYW1lXSk7XG5cbiAgLy8gU3luY2hyb25pemUgbWV0YWRhdGEgbW9kYWwgZm9ybSB3aGVuZXZlciBjdXJyZW50IHZpZXcgY2hhbmdlc1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldE1ldGFGb3JtKHtcbiAgICAgIGNvbGxlZ2VOYW1lOiBzdGF0ZW1lbnRNZXRhLmNvbGxlZ2VOYW1lLFxuICAgICAgY2x1c3Rlck5hbWU6IHN0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWUsXG4gICAgICBzZXNzaW9uTmFtZTogc3RhdGVtZW50TWV0YS5zZXNzaW9uTmFtZSxcbiAgICAgIHNlc3Npb25EYXk6IHN0YXRlbWVudE1ldGEuc2Vzc2lvbkRheSxcbiAgICAgIGRhdGU6IHN0YXRlbWVudE1ldGEuZGF0ZSxcbiAgICAgIHNwb2NOYW1lOiBzdGF0ZW1lbnRNZXRhLnNwb2NOYW1lLFxuICAgICAgZmluYW5jZXJOYW1lOiBzdGF0ZW1lbnRNZXRhLmZpbmFuY2VyTmFtZSxcbiAgICB9KTtcbiAgfSwgW3N0YXRlbWVudE1ldGEsIHNlbGVjdGVkVmlld0tleV0pO1xuXG4gIC8vIENvbXB1dGUgdGFibGUgbGluZSBpdGVtcyBkeW5hbWljYWxseVxuICBjb25zdCB0YWJsZUl0ZW1zOiBTdGF0ZW1lbnRJdGVtW10gPSB1c2VNZW1vKCgpID0+IHtcbiAgICAvLyAxLiBJZiB2aWV3aW5nIGEgc3RydWN0dXJlZCBEcmFmdFxuICAgIGlmIChjdXJyZW50RHJhZnQpIHtcbiAgICAgIGNvbnN0IGl0ZW1zOiBTdGF0ZW1lbnRJdGVtW10gPSBbXTtcbiAgICAgIGxldCBzTm8gPSAxO1xuXG4gICAgICAvLyBUcmF2ZWwgcm91dGVzXG4gICAgICBpZiAoY3VycmVudERyYWZ0LnJvdXRlcykge1xuICAgICAgICBjdXJyZW50RHJhZnQucm91dGVzLmZvckVhY2goKHIsIGlkeCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRvdGFsID0gKHIudm9sdW50ZWVycyB8fCAwKSAqIChyLnBlclBlcnNvbiB8fCAwKTtcbiAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiByLmlkIHx8IGByb3V0ZS0ke2lkeH1gLFxuICAgICAgICAgICAgc05vOiBzTm8rKyxcbiAgICAgICAgICAgIGNhdGVnb3J5OiAnVHJhdmVsJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBgJHtyLmZyb20gfHwgJ09yaWdpbid9IOKGkiAke3IudG8gfHwgJ0Rlc3RpbmF0aW9uJ31gLFxuICAgICAgICAgICAgY291bnQ6IHIudm9sdW50ZWVycyA/IFN0cmluZyhyLnZvbHVudGVlcnMpIDogJ+KAlCcsXG4gICAgICAgICAgICBjb3VudEFtb3VudDogci52b2x1bnRlZXJzICYmIHIucGVyUGVyc29uID8gYCR7ci52b2x1bnRlZXJzfcOXJHtyLnBlclBlcnNvbn1gIDogJ+KAlCcsXG4gICAgICAgICAgICB0b3RhbDogdG90YWwsXG4gICAgICAgICAgICBiaWxsVXJsOiByLmJpbGw/LnVybCB8fCAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1NTQ0MTU3MDctOWU0OWZlNzRhNmQwP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgICAgICAgYmlsbEZpbGVOYW1lOiByLmJpbGw/LmZpbGVOYW1lIHx8ICdUcmF2ZWxfVGlja2V0cy5qcGcnLFxuICAgICAgICAgICAgcmVtYXJrczogci5yZW1hcmtzIHx8ICdCdXMgLyBBdXRvIHRyYW5zcG9ydGF0aW9uIGZvciB2b2x1bnRlZXJzJyxcbiAgICAgICAgICAgIHJhd1R5cGU6ICdyb3V0ZScsXG4gICAgICAgICAgICByYXdJZDogci5pZCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEZvb2QgaXRlbXNcbiAgICAgIGlmIChjdXJyZW50RHJhZnQuZm9vZCkge1xuICAgICAgICBpZiAoY3VycmVudERyYWZ0LmZvb2QuYnJlYWtmYXN0ICYmIChjdXJyZW50RHJhZnQuZm9vZC5icmVha2Zhc3QuYW1vdW50ID4gMCB8fCBjdXJyZW50RHJhZnQuZm9vZC5icmVha2Zhc3QucmVtYXJrcykpIHtcbiAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiAnZm9vZC1icmVha2Zhc3QnLFxuICAgICAgICAgICAgc05vOiBzTm8rKyxcbiAgICAgICAgICAgIGNhdGVnb3J5OiAnRm9vZCcsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0JyZWFrZmFzdCcsXG4gICAgICAgICAgICBjb3VudDogJ+KAlCcsXG4gICAgICAgICAgICBjb3VudEFtb3VudDogJ+KAlCcsXG4gICAgICAgICAgICB0b3RhbDogY3VycmVudERyYWZ0LmZvb2QuYnJlYWtmYXN0LmFtb3VudCB8fCAwLFxuICAgICAgICAgICAgYmlsbFVybDogY3VycmVudERyYWZ0LmZvb2QuYnJlYWtmYXN0LmJpbGw/LnVybCB8fCAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1ODMzMzcxMzA0MTctMzM0NmExYmU3ZGVlP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgICAgICAgYmlsbEZpbGVOYW1lOiBjdXJyZW50RHJhZnQuZm9vZC5icmVha2Zhc3QuYmlsbD8uZmlsZU5hbWUgfHwgJ0JyZWFrZmFzdF9CaWxsLmpwZycsXG4gICAgICAgICAgICByZW1hcmtzOiBjdXJyZW50RHJhZnQuZm9vZC5icmVha2Zhc3QucmVtYXJrcyB8fCAnVGlmZmluICYgVGVhIGZvciB2b2x1bnRlZXJzIGF0IEFubmFwb29ybmEgaG90ZWwnLFxuICAgICAgICAgICAgcmF3VHlwZTogJ2Zvb2QnLFxuICAgICAgICAgICAgZm9vZEtleTogJ2JyZWFrZmFzdCcsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY3VycmVudERyYWZ0LmZvb2QubHVuY2ggJiYgKGN1cnJlbnREcmFmdC5mb29kLmx1bmNoLmFtb3VudCA+IDAgfHwgY3VycmVudERyYWZ0LmZvb2QubHVuY2gucmVtYXJrcykpIHtcbiAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiAnZm9vZC1sdW5jaCcsXG4gICAgICAgICAgICBzTm86IHNObysrLFxuICAgICAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnTHVuY2gnLFxuICAgICAgICAgICAgY291bnQ6ICfigJQnLFxuICAgICAgICAgICAgY291bnRBbW91bnQ6ICfigJQnLFxuICAgICAgICAgICAgdG90YWw6IGN1cnJlbnREcmFmdC5mb29kLmx1bmNoLmFtb3VudCB8fCAwLFxuICAgICAgICAgICAgYmlsbFVybDogY3VycmVudERyYWZ0LmZvb2QubHVuY2guYmlsbD8udXJsIHx8ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU4MzMzNzEzMDQxNy0zMzQ2YTFiZTdkZWU/dz02MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gICAgICAgICAgICBiaWxsRmlsZU5hbWU6IGN1cnJlbnREcmFmdC5mb29kLmx1bmNoLmJpbGw/LmZpbGVOYW1lIHx8ICdMdW5jaF9SZWNlaXB0LmpwZycsXG4gICAgICAgICAgICByZW1hcmtzOiBjdXJyZW50RHJhZnQuZm9vZC5sdW5jaC5yZW1hcmtzIHx8ICdNZWFscyBwYWNrZXQgYWxsb3dhbmNlJyxcbiAgICAgICAgICAgIHJhd1R5cGU6ICdmb29kJyxcbiAgICAgICAgICAgIGZvb2RLZXk6ICdsdW5jaCcsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY3VycmVudERyYWZ0LmZvb2QuZGlubmVyICYmIChjdXJyZW50RHJhZnQuZm9vZC5kaW5uZXIuYW1vdW50ID4gMCB8fCBjdXJyZW50RHJhZnQuZm9vZC5kaW5uZXIucmVtYXJrcykpIHtcbiAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiAnZm9vZC1kaW5uZXInLFxuICAgICAgICAgICAgc05vOiBzTm8rKyxcbiAgICAgICAgICAgIGNhdGVnb3J5OiAnRm9vZCcsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0Rpbm5lcicsXG4gICAgICAgICAgICBjb3VudDogJ+KAlCcsXG4gICAgICAgICAgICBjb3VudEFtb3VudDogJ+KAlCcsXG4gICAgICAgICAgICB0b3RhbDogY3VycmVudERyYWZ0LmZvb2QuZGlubmVyLmFtb3VudCB8fCAwLFxuICAgICAgICAgICAgYmlsbFVybDogY3VycmVudERyYWZ0LmZvb2QuZGlubmVyLmJpbGw/LnVybCB8fCBudWxsLFxuICAgICAgICAgICAgYmlsbEZpbGVOYW1lOiBjdXJyZW50RHJhZnQuZm9vZC5kaW5uZXIuYmlsbD8uZmlsZU5hbWUgfHwgJ0Rpbm5lcl9SZWNlaXB0LmpwZycsXG4gICAgICAgICAgICByZW1hcmtzOiBjdXJyZW50RHJhZnQuZm9vZC5kaW5uZXIucmVtYXJrcyB8fCAnVm9sdW50ZWVyIGRpbm5lcicsXG4gICAgICAgICAgICByYXdUeXBlOiAnZm9vZCcsXG4gICAgICAgICAgICBmb29kS2V5OiAnZGlubmVyJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjdXJyZW50RHJhZnQuZm9vZC5yZWZyZXNobWVudHMgJiYgKGN1cnJlbnREcmFmdC5mb29kLnJlZnJlc2htZW50cy5hbW91bnQgPiAwIHx8IGN1cnJlbnREcmFmdC5mb29kLnJlZnJlc2htZW50cy5yZW1hcmtzKSkge1xuICAgICAgICAgIGl0ZW1zLnB1c2goe1xuICAgICAgICAgICAgaWQ6ICdmb29kLXJlZnJlc2htZW50cycsXG4gICAgICAgICAgICBzTm86IHNObysrLFxuICAgICAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnUmVmcmVzaG1lbnRzICYgVGVhJyxcbiAgICAgICAgICAgIGNvdW50OiAn4oCUJyxcbiAgICAgICAgICAgIGNvdW50QW1vdW50OiAn4oCUJyxcbiAgICAgICAgICAgIHRvdGFsOiBjdXJyZW50RHJhZnQuZm9vZC5yZWZyZXNobWVudHMuYW1vdW50IHx8IDAsXG4gICAgICAgICAgICBiaWxsVXJsOiBjdXJyZW50RHJhZnQuZm9vZC5yZWZyZXNobWVudHMuYmlsbD8udXJsIHx8IG51bGwsXG4gICAgICAgICAgICBiaWxsRmlsZU5hbWU6IGN1cnJlbnREcmFmdC5mb29kLnJlZnJlc2htZW50cy5iaWxsPy5maWxlTmFtZSB8fCAnVGVhX1NuYWNrc19CaWxsLmpwZycsXG4gICAgICAgICAgICByZW1hcmtzOiBjdXJyZW50RHJhZnQuZm9vZC5yZWZyZXNobWVudHMucmVtYXJrcyB8fCAnVGVhIGFuZCBldmVuaW5nIHNuYWNrcycsXG4gICAgICAgICAgICByYXdUeXBlOiAnZm9vZCcsXG4gICAgICAgICAgICBmb29kS2V5OiAncmVmcmVzaG1lbnRzJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBTdGF0aW9uZXJ5XG4gICAgICBpZiAoY3VycmVudERyYWZ0LnN0YXRpb25lcnkgJiYgKGN1cnJlbnREcmFmdC5zdGF0aW9uZXJ5LmFtb3VudCA+IDAgfHwgY3VycmVudERyYWZ0LnN0YXRpb25lcnkucmVtYXJrcykpIHtcbiAgICAgICAgaXRlbXMucHVzaCh7XG4gICAgICAgICAgaWQ6ICdzdGF0aW9uZXJ5LW1haW4nLFxuICAgICAgICAgIHNObzogc05vKyssXG4gICAgICAgICAgY2F0ZWdvcnk6ICdTdGF0aW9uZXJ5JyxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ01hdGVyaWFscyAmIE5vdGVib29rcycsXG4gICAgICAgICAgY291bnQ6ICfigJQnLFxuICAgICAgICAgIGNvdW50QW1vdW50OiAn4oCUJyxcbiAgICAgICAgICB0b3RhbDogY3VycmVudERyYWZ0LnN0YXRpb25lcnkuYW1vdW50IHx8IDAsXG4gICAgICAgICAgYmlsbFVybDogY3VycmVudERyYWZ0LnN0YXRpb25lcnkuYmlsbD8udXJsIHx8IG51bGwsXG4gICAgICAgICAgYmlsbEZpbGVOYW1lOiBjdXJyZW50RHJhZnQuc3RhdGlvbmVyeS5iaWxsPy5maWxlTmFtZSB8fCAnU3RhdGlvbmVyeV9CaWxsLmpwZycsXG4gICAgICAgICAgcmVtYXJrczogY3VycmVudERyYWZ0LnN0YXRpb25lcnkucmVtYXJrcyB8fCAnQ2hhcnQgcGFwZXJzLCBtYXJrZXJzIGFuZCBhY3Rpdml0eSBraXRzJyxcbiAgICAgICAgICByYXdUeXBlOiAnc3RhdGlvbmVyeScsXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBPdGhlciBpdGVtc1xuICAgICAgaWYgKGN1cnJlbnREcmFmdC5vdGhlckl0ZW1zKSB7XG4gICAgICAgIGN1cnJlbnREcmFmdC5vdGhlckl0ZW1zLmZvckVhY2goKG90LCBpZHgpID0+IHtcbiAgICAgICAgICBpZiAob3QuYW1vdW50ID4gMCB8fCBvdC5kZXNjcmlwdGlvbiB8fCBvdC5yZW1hcmtzKSB7XG4gICAgICAgICAgICBpdGVtcy5wdXNoKHtcbiAgICAgICAgICAgICAgaWQ6IG90LmlkIHx8IGBvdGhlci0ke2lkeH1gLFxuICAgICAgICAgICAgICBzTm86IHNObysrLFxuICAgICAgICAgICAgICBjYXRlZ29yeTogJ090aGVyJyxcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG90LmRlc2NyaXB0aW9uIHx8ICdGaXJzdCBBaWQgS2l0ICYgV2F0ZXIgQ2FucycsXG4gICAgICAgICAgICAgIGNvdW50OiAn4oCUJyxcbiAgICAgICAgICAgICAgY291bnRBbW91bnQ6ICfigJQnLFxuICAgICAgICAgICAgICB0b3RhbDogb3QuYW1vdW50IHx8IDAsXG4gICAgICAgICAgICAgIGJpbGxVcmw6IG90LmJpbGw/LnVybCB8fCBudWxsLFxuICAgICAgICAgICAgICBiaWxsRmlsZU5hbWU6IG90LmJpbGw/LmZpbGVOYW1lIHx8ICdPdGhlcl9FeHBlbnNlX1NsaXAuanBnJyxcbiAgICAgICAgICAgICAgcmVtYXJrczogb3QucmVtYXJrcyB8fCAn4oCUJyxcbiAgICAgICAgICAgICAgcmF3VHlwZTogJ290aGVyJyxcbiAgICAgICAgICAgICAgcmF3SWQ6IG90LmlkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGl0ZW1zO1xuICAgIH1cblxuICAgIC8vIDIuIE90aGVyd2lzZSB1c2UgZW50cmllcyBsaXN0XG4gICAgY29uc3Qgc291cmNlRW50cmllcyA9XG4gICAgICBzZWxlY3RlZFZpZXdLZXkgPT09ICdhbGwtYXBwcm92ZWQnXG4gICAgICAgID8gZW50cmllcy5maWx0ZXIoKGUpID0+IGUuc3RhdHVzID09PSAnQXBwcm92ZWQnKVxuICAgICAgICA6IGVudHJpZXMuZmlsdGVyKChlKSA9PiBlLnNlc3Npb25EYXkgPT09IHNlbGVjdGVkVmlld0tleSB8fCBlLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJyk7XG5cbiAgICBpZiAoc291cmNlRW50cmllcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIHtcbiAgICAgICAgICBpZDogJ21vY2stMScsXG4gICAgICAgICAgc05vOiAxLFxuICAgICAgICAgIGNhdGVnb3J5OiAnVHJhdmVsJyxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ0tTUiBDb2xsZWdlIOKGkiBTYWxlbSAvIEFtbWFwZXR0YWknLFxuICAgICAgICAgIGNvdW50OiAnMjAnLFxuICAgICAgICAgIGNvdW50QW1vdW50OiAnMjDDlzEwJyxcbiAgICAgICAgICB0b3RhbDogMjAwLFxuICAgICAgICAgIGJpbGxVcmw6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU1NDQxNTcwNy05ZTQ5ZmU3NGE2ZDA/dz02MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gICAgICAgICAgYmlsbEZpbGVOYW1lOiAnQnVzX1Bhc3NfS1NSLmpwZycsXG4gICAgICAgICAgcmVtYXJrczogJ0J1cyB0cmFuc3BvcnRhdGlvbiBmb3IgMjAgdm9sdW50ZWVycycsXG4gICAgICAgICAgcmF3VHlwZTogJ2VudHJ5JyxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGlkOiAnbW9jay0yJyxcbiAgICAgICAgICBzTm86IDIsXG4gICAgICAgICAgY2F0ZWdvcnk6ICdGb29kJyxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogJ0JyZWFrZmFzdCcsXG4gICAgICAgICAgY291bnQ6ICfigJQnLFxuICAgICAgICAgIGNvdW50QW1vdW50OiAn4oCUJyxcbiAgICAgICAgICB0b3RhbDogMTAwMCxcbiAgICAgICAgICBiaWxsVXJsOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1ODMzMzcxMzA0MTctMzM0NmExYmU3ZGVlP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgICAgIGJpbGxGaWxlTmFtZTogJ0FubmFwb29ybmFfQnJlYWtmYXN0LmpwZycsXG4gICAgICAgICAgcmVtYXJrczogJ1RpZmZpbiAmIFRlYSBmb3IgMjAgdm9sdW50ZWVycyBhdCBBbm5hcG9vcm5hIGhvdGVsJyxcbiAgICAgICAgICByYXdUeXBlOiAnZW50cnknLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgaWQ6ICdtb2NrLTMnLFxuICAgICAgICAgIHNObzogMyxcbiAgICAgICAgICBjYXRlZ29yeTogJ0Zvb2QnLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnTHVuY2gnLFxuICAgICAgICAgIGNvdW50OiAn4oCUJyxcbiAgICAgICAgICBjb3VudEFtb3VudDogJ+KAlCcsXG4gICAgICAgICAgdG90YWw6IDUwMCxcbiAgICAgICAgICBiaWxsVXJsOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1ODMzMzcxMzA0MTctMzM0NmExYmU3ZGVlP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgICAgIGJpbGxGaWxlTmFtZTogJ0x1bmNoX1BhY2tldF9TbGlwLmpwZycsXG4gICAgICAgICAgcmVtYXJrczogJ01lYWxzIHBhY2tldCBhbGxvd2FuY2UnLFxuICAgICAgICAgIHJhd1R5cGU6ICdlbnRyeScsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBpZDogJ21vY2stNCcsXG4gICAgICAgICAgc05vOiA0LFxuICAgICAgICAgIGNhdGVnb3J5OiAnT3RoZXInLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiAnRmlyc3QgQWlkIEtpdCAmIFdhdGVyIENhbnMnLFxuICAgICAgICAgIGNvdW50OiAn4oCUJyxcbiAgICAgICAgICBjb3VudEFtb3VudDogJ+KAlCcsXG4gICAgICAgICAgdG90YWw6IDAsXG4gICAgICAgICAgYmlsbFVybDogbnVsbCxcbiAgICAgICAgICBiaWxsRmlsZU5hbWU6ICcnLFxuICAgICAgICAgIHJlbWFya3M6ICfigJQnLFxuICAgICAgICAgIHJhd1R5cGU6ICdlbnRyeScsXG4gICAgICAgIH0sXG4gICAgICBdO1xuICAgIH1cblxuICAgIHJldHVybiBzb3VyY2VFbnRyaWVzLm1hcCgoZSwgaWR4KSA9PiAoe1xuICAgICAgaWQ6IGUuaWQsXG4gICAgICBzTm86IGlkeCArIDEsXG4gICAgICBjYXRlZ29yeTogZS5jYXRlZ29yeSBhcyBhbnksXG4gICAgICBkZXNjcmlwdGlvbjogZS5kZXNjcmlwdGlvbixcbiAgICAgIGNvdW50OiBlLmNvdW50ID8gU3RyaW5nKGUuY291bnQpIDogJ+KAlCcsXG4gICAgICBjb3VudEFtb3VudDogZS5jb3VudEFtb3VudCB8fCAn4oCUJyxcbiAgICAgIHRvdGFsOiBlLmFtb3VudCxcbiAgICAgIGJpbGxVcmw6IGUuYmlsbFVybCB8fCAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1NTQ0MTU3MDctOWU0OWZlNzRhNmQwP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgICAgYmlsbEZpbGVOYW1lOiAnUmVjZWlwdF9Wb3VjaGVyLmpwZycsXG4gICAgICByZW1hcmtzOiBlLnJlbWFya3MgfHwgJ+KAlCcsXG4gICAgICByYXdUeXBlOiAnZW50cnknLFxuICAgICAgcmF3SWQ6IGUuaWQsXG4gICAgfSkpO1xuICB9LCBbY3VycmVudERyYWZ0LCBzZWxlY3RlZFZpZXdLZXksIGVudHJpZXNdKTtcblxuICAvLyBTdWJ0b3RhbHNcbiAgY29uc3QgdHJhdmVsVG90YWwgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gdGFibGVJdGVtc1xuICAgICAgLmZpbHRlcigoaSkgPT4gaS5jYXRlZ29yeSA9PT0gJ1RyYXZlbCcpXG4gICAgICAucmVkdWNlKChzdW0sIGkpID0+IHN1bSArIGkudG90YWwsIDApO1xuICB9LCBbdGFibGVJdGVtc10pO1xuXG4gIGNvbnN0IGZvb2RUb3RhbCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiB0YWJsZUl0ZW1zXG4gICAgICAuZmlsdGVyKChpKSA9PiBpLmNhdGVnb3J5ID09PSAnRm9vZCcpXG4gICAgICAucmVkdWNlKChzdW0sIGkpID0+IHN1bSArIGkudG90YWwsIDApO1xuICB9LCBbdGFibGVJdGVtc10pO1xuXG4gIGNvbnN0IHN0YXRpb25lcnlUb3RhbCA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiB0YWJsZUl0ZW1zXG4gICAgICAuZmlsdGVyKChpKSA9PiBpLmNhdGVnb3J5ID09PSAnU3RhdGlvbmVyeScgfHwgaS5jYXRlZ29yeSA9PT0gJ01hdGVyaWFscycpXG4gICAgICAucmVkdWNlKChzdW0sIGkpID0+IHN1bSArIGkudG90YWwsIDApO1xuICB9LCBbdGFibGVJdGVtc10pO1xuXG4gIGNvbnN0IG90aGVyVG90YWwgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gdGFibGVJdGVtc1xuICAgICAgLmZpbHRlcigoaSkgPT4gaS5jYXRlZ29yeSA9PT0gJ090aGVyJyB8fCBpLmNhdGVnb3J5ID09PSAnQWRtaW4nKVxuICAgICAgLnJlZHVjZSgoc3VtLCBpKSA9PiBzdW0gKyBpLnRvdGFsLCAwKTtcbiAgfSwgW3RhYmxlSXRlbXNdKTtcblxuICBjb25zdCBncmFuZFRvdGFsID0gdHJhdmVsVG90YWwgKyBmb29kVG90YWwgKyBzdGF0aW9uZXJ5VG90YWwgKyBvdGhlclRvdGFsO1xuXG4gIC8vIEV4dHJhY3QgYWxsIGF0dGFjaGVkIGJpbGxzIGZvciBnYWxsZXJ5XG4gIGNvbnN0IGFsbEF0dGFjaGVkQmlsbHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gdGFibGVJdGVtc1xuICAgICAgLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5iaWxsVXJsKVxuICAgICAgLm1hcCgoaXRlbSkgPT4gKHtcbiAgICAgICAgaWQ6IGl0ZW0uaWQgfHwgYGJpbGwtJHtpdGVtLnNOb31gLFxuICAgICAgICB1cmw6IGl0ZW0uYmlsbFVybCEsXG4gICAgICAgIHRpdGxlOiBgJHtpdGVtLmNhdGVnb3J5fTogJHtpdGVtLmRlc2NyaXB0aW9ufWAsXG4gICAgICAgIGNhdGVnb3J5OiBpdGVtLmNhdGVnb3J5LFxuICAgICAgICBhbW91bnQ6IGl0ZW0udG90YWwsXG4gICAgICAgIHJlbWFya3M6IGl0ZW0ucmVtYXJrcyxcbiAgICAgICAgZmlsZU5hbWU6IGl0ZW0uYmlsbEZpbGVOYW1lIHx8IGAke2l0ZW0uY2F0ZWdvcnl9X1JlY2VpcHQuanBnYCxcbiAgICAgIH0pKTtcbiAgfSwgW3RhYmxlSXRlbXNdKTtcblxuICAvLyBTVUJNSVQgU1RBVEVNRU5UIEZPUiBBUFBST1ZBTCAoVm9sdW50ZWVyIC8gU1BPQyBhY3Rpb24gb25seSAtIE5vIGRpcmVjdCBhcHByb3ZlIGJ1dHRvbilcbiAgY29uc3QgaGFuZGxlU3VibWl0U3RhdGVtZW50ID0gKCkgPT4ge1xuICAgIGlmIChjdXJyZW50RHJhZnQgJiYgb25TdWJtaXREcmFmdCkge1xuICAgICAgb25TdWJtaXREcmFmdChjdXJyZW50RHJhZnQuaWQpO1xuICAgICAgc2hvd1RvYXN0KGBGaW5hbmNlIFN0YXRlbWVudCBmb3IgXCIke3N0YXRlbWVudE1ldGEuc2Vzc2lvbkRheX1cIiBzdWJtaXR0ZWQgZm9yIHJldmlldyFgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2hvd1RvYXN0KCdGaW5hbmNlIHN0YXRlbWVudCBzdWJtaXR0ZWQgdG8gVFFJIEZpbmFuY2UgVGVhbSBzdWNjZXNzZnVsbHkhJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERFTEVURSBBTiBFWFBFTlNFIFJPV1xuICBjb25zdCBoYW5kbGVEZWxldGVSb3cgPSAoaXRlbTogU3RhdGVtZW50SXRlbSkgPT4ge1xuICAgIGlmICghY29uZmlybShgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSBcIiR7aXRlbS5kZXNjcmlwdGlvbn1cIj9gKSkgcmV0dXJuO1xuXG4gICAgaWYgKGN1cnJlbnREcmFmdCAmJiBvblNhdmVEcmFmdCkge1xuICAgICAgbGV0IHVwZGF0ZWREcmFmdDogRmluYW5jZURyYWZ0ID0geyAuLi5jdXJyZW50RHJhZnQgfTtcblxuICAgICAgaWYgKGl0ZW0ucmF3VHlwZSA9PT0gJ3JvdXRlJyAmJiBpdGVtLnJhd0lkKSB7XG4gICAgICAgIHVwZGF0ZWREcmFmdC5yb3V0ZXMgPSB1cGRhdGVkRHJhZnQucm91dGVzLmZpbHRlcigocikgPT4gci5pZCAhPT0gaXRlbS5yYXdJZCk7XG4gICAgICB9IGVsc2UgaWYgKGl0ZW0ucmF3VHlwZSA9PT0gJ2Zvb2QnICYmIGl0ZW0uZm9vZEtleSkge1xuICAgICAgICB1cGRhdGVkRHJhZnQuZm9vZCA9IHtcbiAgICAgICAgICAuLi51cGRhdGVkRHJhZnQuZm9vZCxcbiAgICAgICAgICBbaXRlbS5mb29kS2V5XTogeyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH0sXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKGl0ZW0ucmF3VHlwZSA9PT0gJ3N0YXRpb25lcnknKSB7XG4gICAgICAgIHVwZGF0ZWREcmFmdC5zdGF0aW9uZXJ5ID0geyBhbW91bnQ6IDAsIHJlbWFya3M6ICcnLCBiaWxsOiBudWxsIH07XG4gICAgICB9IGVsc2UgaWYgKGl0ZW0ucmF3VHlwZSA9PT0gJ290aGVyJyAmJiBpdGVtLnJhd0lkKSB7XG4gICAgICAgIHVwZGF0ZWREcmFmdC5vdGhlckl0ZW1zID0gdXBkYXRlZERyYWZ0Lm90aGVySXRlbXMuZmlsdGVyKChvdCkgPT4gb3QuaWQgIT09IGl0ZW0ucmF3SWQpO1xuICAgICAgfVxuXG4gICAgICAvLyBSZWNhbGN1bGF0ZSBkcmFmdCB0b3RhbFxuICAgICAgY29uc3QgbmV3VHJhdmVsID0gdXBkYXRlZERyYWZ0LnJvdXRlcy5yZWR1Y2UoKHMsIHIpID0+IHMgKyAoci52b2x1bnRlZXJzIHx8IDApICogKHIucGVyUGVyc29uIHx8IDApLCAwKTtcbiAgICAgIGNvbnN0IG5ld0Zvb2QgPVxuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QuYnJlYWtmYXN0Py5hbW91bnQgfHwgMCkgK1xuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QubHVuY2g/LmFtb3VudCB8fCAwKSArXG4gICAgICAgICh1cGRhdGVkRHJhZnQuZm9vZC5kaW5uZXI/LmFtb3VudCB8fCAwKSArXG4gICAgICAgICh1cGRhdGVkRHJhZnQuZm9vZC5yZWZyZXNobWVudHM/LmFtb3VudCB8fCAwKTtcbiAgICAgIGNvbnN0IG5ld1N0YXRpb25lcnkgPSB1cGRhdGVkRHJhZnQuc3RhdGlvbmVyeT8uYW1vdW50IHx8IDA7XG4gICAgICBjb25zdCBuZXdPdGhlciA9IHVwZGF0ZWREcmFmdC5vdGhlckl0ZW1zLnJlZHVjZSgocywgbykgPT4gcyArIChvLmFtb3VudCB8fCAwKSwgMCk7XG5cbiAgICAgIHVwZGF0ZWREcmFmdC50b3RhbEFtb3VudCA9IG5ld1RyYXZlbCArIG5ld0Zvb2QgKyBuZXdTdGF0aW9uZXJ5ICsgbmV3T3RoZXI7XG4gICAgICBvblNhdmVEcmFmdCh1cGRhdGVkRHJhZnQpO1xuICAgICAgc2hvd1RvYXN0KGBEZWxldGVkIFwiJHtpdGVtLmRlc2NyaXB0aW9ufVwiYCk7XG4gICAgfSBlbHNlIGlmIChpdGVtLnJhd1R5cGUgPT09ICdlbnRyeScgJiYgaXRlbS5yYXdJZCAmJiBvbkRlbGV0ZUZpbmFuY2VFbnRyeSkge1xuICAgICAgb25EZWxldGVGaW5hbmNlRW50cnkoaXRlbS5yYXdJZCk7XG4gICAgICBzaG93VG9hc3QoYERlbGV0ZWQgXCIke2l0ZW0uZGVzY3JpcHRpb259XCJgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2hvd1RvYXN0KGBJdGVtIHJlbW92ZWQgZnJvbSB2aWV3LmApO1xuICAgIH1cbiAgfTtcblxuICAvLyBTQVZFIEVESVRFRCBFWFBFTlNFIFJPV1xuICBjb25zdCBoYW5kbGVTYXZlRWRpdGVkUm93ID0gKCkgPT4ge1xuICAgIGlmICghZWRpdGluZ0l0ZW0pIHJldHVybjtcblxuICAgIGlmIChjdXJyZW50RHJhZnQgJiYgb25TYXZlRHJhZnQpIHtcbiAgICAgIGNvbnN0IHVwZGF0ZWREcmFmdDogRmluYW5jZURyYWZ0ID0geyAuLi5jdXJyZW50RHJhZnQgfTtcblxuICAgICAgaWYgKGVkaXRpbmdJdGVtLnJhd1R5cGUgPT09ICdyb3V0ZScgJiYgZWRpdGluZ0l0ZW0ucmF3SWQpIHtcbiAgICAgICAgY29uc3Qgdm9scyA9IHBhcnNlSW50KGVkaXRpbmdJdGVtLmNvdW50KSB8fCAwO1xuICAgICAgICBsZXQgcGVyUCA9IDA7XG4gICAgICAgIGlmIChlZGl0aW5nSXRlbS5jb3VudEFtb3VudC5pbmNsdWRlcygnw5cnKSkge1xuICAgICAgICAgIHBlclAgPSBwYXJzZUZsb2F0KGVkaXRpbmdJdGVtLmNvdW50QW1vdW50LnNwbGl0KCfDlycpWzFdKSB8fCAwO1xuICAgICAgICB9IGVsc2UgaWYgKHZvbHMgPiAwKSB7XG4gICAgICAgICAgcGVyUCA9IGVkaXRpbmdJdGVtLnRvdGFsIC8gdm9scztcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHBhcnRzID0gZWRpdGluZ0l0ZW0uZGVzY3JpcHRpb24uc3BsaXQoJ+KGkicpO1xuICAgICAgICBjb25zdCBmcm9tID0gcGFydHNbMF0/LnRyaW0oKSB8fCAnT3JpZ2luJztcbiAgICAgICAgY29uc3QgdG8gPSBwYXJ0c1sxXT8udHJpbSgpIHx8ICdEZXN0aW5hdGlvbic7XG5cbiAgICAgICAgdXBkYXRlZERyYWZ0LnJvdXRlcyA9IHVwZGF0ZWREcmFmdC5yb3V0ZXMubWFwKChyKSA9PlxuICAgICAgICAgIHIuaWQgPT09IGVkaXRpbmdJdGVtLnJhd0lkXG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAuLi5yLFxuICAgICAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICAgICAgdG8sXG4gICAgICAgICAgICAgICAgdm9sdW50ZWVyczogdm9scyxcbiAgICAgICAgICAgICAgICBwZXJQZXJzb246IHBlclAsXG4gICAgICAgICAgICAgICAgcmVtYXJrczogZWRpdGluZ0l0ZW0ucmVtYXJrcyxcbiAgICAgICAgICAgICAgICBiaWxsOiBlZGl0aW5nSXRlbS5iaWxsVXJsXG4gICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICB1cmw6IGVkaXRpbmdJdGVtLmJpbGxVcmwsXG4gICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWU6IGVkaXRpbmdJdGVtLmJpbGxGaWxlTmFtZSB8fCAnVHJhdmVsX0JpbGwuanBnJyxcbiAgICAgICAgICAgICAgICAgICAgICBkZXRlY3RlZEFtb3VudDogZWRpdGluZ0l0ZW0udG90YWwsXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIDogbnVsbCxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiByXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGVkaXRpbmdJdGVtLnJhd1R5cGUgPT09ICdmb29kJyAmJiBlZGl0aW5nSXRlbS5mb29kS2V5KSB7XG4gICAgICAgIHVwZGF0ZWREcmFmdC5mb29kID0ge1xuICAgICAgICAgIC4uLnVwZGF0ZWREcmFmdC5mb29kLFxuICAgICAgICAgIFtlZGl0aW5nSXRlbS5mb29kS2V5XToge1xuICAgICAgICAgICAgYW1vdW50OiBlZGl0aW5nSXRlbS50b3RhbCxcbiAgICAgICAgICAgIHJlbWFya3M6IGVkaXRpbmdJdGVtLnJlbWFya3MsXG4gICAgICAgICAgICBiaWxsOiBlZGl0aW5nSXRlbS5iaWxsVXJsXG4gICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgdXJsOiBlZGl0aW5nSXRlbS5iaWxsVXJsLFxuICAgICAgICAgICAgICAgICAgZmlsZU5hbWU6IGVkaXRpbmdJdGVtLmJpbGxGaWxlTmFtZSB8fCAnRm9vZF9CaWxsLmpwZycsXG4gICAgICAgICAgICAgICAgICBkZXRlY3RlZEFtb3VudDogZWRpdGluZ0l0ZW0udG90YWwsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA6IG51bGwsXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSBpZiAoZWRpdGluZ0l0ZW0ucmF3VHlwZSA9PT0gJ3N0YXRpb25lcnknKSB7XG4gICAgICAgIHVwZGF0ZWREcmFmdC5zdGF0aW9uZXJ5ID0ge1xuICAgICAgICAgIGFtb3VudDogZWRpdGluZ0l0ZW0udG90YWwsXG4gICAgICAgICAgcmVtYXJrczogZWRpdGluZ0l0ZW0ucmVtYXJrcyxcbiAgICAgICAgICBiaWxsOiBlZGl0aW5nSXRlbS5iaWxsVXJsXG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICB1cmw6IGVkaXRpbmdJdGVtLmJpbGxVcmwsXG4gICAgICAgICAgICAgICAgZmlsZU5hbWU6IGVkaXRpbmdJdGVtLmJpbGxGaWxlTmFtZSB8fCAnU3RhdGlvbmVyeV9CaWxsLmpwZycsXG4gICAgICAgICAgICAgICAgZGV0ZWN0ZWRBbW91bnQ6IGVkaXRpbmdJdGVtLnRvdGFsLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IG51bGwsXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKGVkaXRpbmdJdGVtLnJhd1R5cGUgPT09ICdvdGhlcicgJiYgZWRpdGluZ0l0ZW0ucmF3SWQpIHtcbiAgICAgICAgdXBkYXRlZERyYWZ0Lm90aGVySXRlbXMgPSB1cGRhdGVkRHJhZnQub3RoZXJJdGVtcy5tYXAoKG90KSA9PlxuICAgICAgICAgIG90LmlkID09PSBlZGl0aW5nSXRlbS5yYXdJZFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgLi4ub3QsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVkaXRpbmdJdGVtLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgIGFtb3VudDogZWRpdGluZ0l0ZW0udG90YWwsXG4gICAgICAgICAgICAgICAgcmVtYXJrczogZWRpdGluZ0l0ZW0ucmVtYXJrcyxcbiAgICAgICAgICAgICAgICBiaWxsOiBlZGl0aW5nSXRlbS5iaWxsVXJsXG4gICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICB1cmw6IGVkaXRpbmdJdGVtLmJpbGxVcmwsXG4gICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWU6IGVkaXRpbmdJdGVtLmJpbGxGaWxlTmFtZSB8fCAnT3RoZXJfQmlsbC5qcGcnLFxuICAgICAgICAgICAgICAgICAgICAgIGRldGVjdGVkQW1vdW50OiBlZGl0aW5nSXRlbS50b3RhbCxcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IG90XG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIFJlLXN1bVxuICAgICAgY29uc3QgbmV3VHJhdmVsID0gdXBkYXRlZERyYWZ0LnJvdXRlcy5yZWR1Y2UoKHMsIHIpID0+IHMgKyAoci52b2x1bnRlZXJzIHx8IDApICogKHIucGVyUGVyc29uIHx8IDApLCAwKTtcbiAgICAgIGNvbnN0IG5ld0Zvb2QgPVxuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QuYnJlYWtmYXN0Py5hbW91bnQgfHwgMCkgK1xuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QubHVuY2g/LmFtb3VudCB8fCAwKSArXG4gICAgICAgICh1cGRhdGVkRHJhZnQuZm9vZC5kaW5uZXI/LmFtb3VudCB8fCAwKSArXG4gICAgICAgICh1cGRhdGVkRHJhZnQuZm9vZC5yZWZyZXNobWVudHM/LmFtb3VudCB8fCAwKTtcbiAgICAgIGNvbnN0IG5ld1N0YXRpb25lcnkgPSB1cGRhdGVkRHJhZnQuc3RhdGlvbmVyeT8uYW1vdW50IHx8IDA7XG4gICAgICBjb25zdCBuZXdPdGhlciA9IHVwZGF0ZWREcmFmdC5vdGhlckl0ZW1zLnJlZHVjZSgocywgbykgPT4gcyArIChvLmFtb3VudCB8fCAwKSwgMCk7XG4gICAgICB1cGRhdGVkRHJhZnQudG90YWxBbW91bnQgPSBuZXdUcmF2ZWwgKyBuZXdGb29kICsgbmV3U3RhdGlvbmVyeSArIG5ld090aGVyO1xuXG4gICAgICBvblNhdmVEcmFmdCh1cGRhdGVkRHJhZnQpO1xuICAgICAgc2hvd1RvYXN0KGBVcGRhdGVkIFwiJHtlZGl0aW5nSXRlbS5kZXNjcmlwdGlvbn1cImApO1xuICAgIH0gZWxzZSBpZiAoZWRpdGluZ0l0ZW0ucmF3VHlwZSA9PT0gJ2VudHJ5JyAmJiBlZGl0aW5nSXRlbS5yYXdJZCAmJiBvblVwZGF0ZUZpbmFuY2VFbnRyeSkge1xuICAgICAgb25VcGRhdGVGaW5hbmNlRW50cnkoZWRpdGluZ0l0ZW0ucmF3SWQsIHtcbiAgICAgICAgZGVzY3JpcHRpb246IGVkaXRpbmdJdGVtLmRlc2NyaXB0aW9uLFxuICAgICAgICBjYXRlZ29yeTogZWRpdGluZ0l0ZW0uY2F0ZWdvcnkgYXMgYW55LFxuICAgICAgICBhbW91bnQ6IGVkaXRpbmdJdGVtLnRvdGFsLFxuICAgICAgICByZW1hcmtzOiBlZGl0aW5nSXRlbS5yZW1hcmtzLFxuICAgICAgICBiaWxsVXJsOiBlZGl0aW5nSXRlbS5iaWxsVXJsIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgY291bnQ6IHBhcnNlSW50KGVkaXRpbmdJdGVtLmNvdW50KSB8fCB1bmRlZmluZWQsXG4gICAgICAgIGNvdW50QW1vdW50OiBlZGl0aW5nSXRlbS5jb3VudEFtb3VudCB8fCB1bmRlZmluZWQsXG4gICAgICB9KTtcbiAgICAgIHNob3dUb2FzdChgVXBkYXRlZCBcIiR7ZWRpdGluZ0l0ZW0uZGVzY3JpcHRpb259XCJgKTtcbiAgICB9XG5cbiAgICBzZXRFZGl0aW5nSXRlbShudWxsKTtcbiAgfTtcblxuICAvLyBBREQgTkVXIEVYUEVOU0UgUk9XIFRPIFNUQVRFTUVOVFxuICBjb25zdCBoYW5kbGVBZGROZXdFeHBlbnNlUm93ID0gKCkgPT4ge1xuICAgIGlmICghbmV3RXhwZW5zZUZvcm0uZGVzY3JpcHRpb24gJiYgIW5ld0V4cGVuc2VGb3JtLnRvdGFsQW1vdW50KSB7XG4gICAgICBhbGVydCgnUGxlYXNlIGZpbGwgaW4gZGVzY3JpcHRpb24gb3IgYW1vdW50Jyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdG90YWxBbXQgPSBwYXJzZUZsb2F0KG5ld0V4cGVuc2VGb3JtLnRvdGFsQW1vdW50KSB8fCAwO1xuICAgIGNvbnN0IHZvbHMgPSBwYXJzZUludChuZXdFeHBlbnNlRm9ybS5jb3VudCkgfHwgMDtcbiAgICBjb25zdCBwZXJQID0gcGFyc2VGbG9hdChuZXdFeHBlbnNlRm9ybS5wZXJQZXJzb24pIHx8IDA7XG4gICAgY29uc3QgZmluYWxBbW91bnQgPSB0b3RhbEFtdCA+IDAgPyB0b3RhbEFtdCA6IHZvbHMgKiBwZXJQO1xuXG4gICAgaWYgKGN1cnJlbnREcmFmdCAmJiBvblNhdmVEcmFmdCkge1xuICAgICAgY29uc3QgdXBkYXRlZERyYWZ0OiBGaW5hbmNlRHJhZnQgPSB7IC4uLmN1cnJlbnREcmFmdCB9O1xuXG4gICAgICBpZiAobmV3RXhwZW5zZUZvcm0uY2F0ZWdvcnkgPT09ICdUcmF2ZWwnKSB7XG4gICAgICAgIGNvbnN0IHBhcnRzID0gbmV3RXhwZW5zZUZvcm0uZGVzY3JpcHRpb24uc3BsaXQoJ+KGkicpO1xuICAgICAgICBjb25zdCBmcm9tID0gcGFydHNbMF0/LnRyaW0oKSB8fCAnT3JpZ2luJztcbiAgICAgICAgY29uc3QgdG8gPSBwYXJ0c1sxXT8udHJpbSgpIHx8ICdEZXN0aW5hdGlvbic7XG5cbiAgICAgICAgY29uc3QgbmV3Um91dGU6IFJvdXRlRHJhZnRJdGVtID0ge1xuICAgICAgICAgIGlkOiBgcm91dGUtJHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICB2b2x1bnRlZXJzOiB2b2xzIHx8IDEsXG4gICAgICAgICAgcGVyUGVyc29uOiBwZXJQIHx8IGZpbmFsQW1vdW50LFxuICAgICAgICAgIHJlbWFya3M6IG5ld0V4cGVuc2VGb3JtLnJlbWFya3MsXG4gICAgICAgICAgYmlsbDogbmV3RXhwZW5zZUZvcm0uYmlsbFVybFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgdXJsOiBuZXdFeHBlbnNlRm9ybS5iaWxsVXJsLFxuICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBuZXdFeHBlbnNlRm9ybS5iaWxsRmlsZU5hbWUgfHwgJ1RyYXZlbF9CaWxsLmpwZycsXG4gICAgICAgICAgICAgICAgZGV0ZWN0ZWRBbW91bnQ6IGZpbmFsQW1vdW50LFxuICAgICAgICAgICAgICAgIGlzVmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDogbnVsbCxcbiAgICAgICAgfTtcbiAgICAgICAgdXBkYXRlZERyYWZ0LnJvdXRlcyA9IFsuLi51cGRhdGVkRHJhZnQucm91dGVzLCBuZXdSb3V0ZV07XG4gICAgICB9IGVsc2UgaWYgKG5ld0V4cGVuc2VGb3JtLmNhdGVnb3J5ID09PSAnRm9vZCcpIHtcbiAgICAgICAgLy8gYWRkIHRvIHJlZnJlc2htZW50cyBvciBjdXN0b21cbiAgICAgICAgdXBkYXRlZERyYWZ0LmZvb2QgPSB7XG4gICAgICAgICAgLi4udXBkYXRlZERyYWZ0LmZvb2QsXG4gICAgICAgICAgcmVmcmVzaG1lbnRzOiB7XG4gICAgICAgICAgICBhbW91bnQ6ICh1cGRhdGVkRHJhZnQuZm9vZC5yZWZyZXNobWVudHM/LmFtb3VudCB8fCAwKSArIGZpbmFsQW1vdW50LFxuICAgICAgICAgICAgcmVtYXJrczogbmV3RXhwZW5zZUZvcm0ucmVtYXJrcyB8fCBuZXdFeHBlbnNlRm9ybS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIGJpbGw6IG5ld0V4cGVuc2VGb3JtLmJpbGxVcmxcbiAgICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgICB1cmw6IG5ld0V4cGVuc2VGb3JtLmJpbGxVcmwsXG4gICAgICAgICAgICAgICAgICBmaWxlTmFtZTogbmV3RXhwZW5zZUZvcm0uYmlsbEZpbGVOYW1lIHx8ICdGb29kX0JpbGwuanBnJyxcbiAgICAgICAgICAgICAgICAgIGRldGVjdGVkQW1vdW50OiBmaW5hbEFtb3VudCxcbiAgICAgICAgICAgICAgICAgIGlzVmVyaWZpZWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA6IHVwZGF0ZWREcmFmdC5mb29kLnJlZnJlc2htZW50cz8uYmlsbCB8fCBudWxsLFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKG5ld0V4cGVuc2VGb3JtLmNhdGVnb3J5ID09PSAnU3RhdGlvbmVyeScpIHtcbiAgICAgICAgdXBkYXRlZERyYWZ0LnN0YXRpb25lcnkgPSB7XG4gICAgICAgICAgYW1vdW50OiAodXBkYXRlZERyYWZ0LnN0YXRpb25lcnk/LmFtb3VudCB8fCAwKSArIGZpbmFsQW1vdW50LFxuICAgICAgICAgIHJlbWFya3M6IG5ld0V4cGVuc2VGb3JtLnJlbWFya3MgfHwgbmV3RXhwZW5zZUZvcm0uZGVzY3JpcHRpb24sXG4gICAgICAgICAgYmlsbDogbmV3RXhwZW5zZUZvcm0uYmlsbFVybFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgdXJsOiBuZXdFeHBlbnNlRm9ybS5iaWxsVXJsLFxuICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBuZXdFeHBlbnNlRm9ybS5iaWxsRmlsZU5hbWUgfHwgJ1N0YXRpb25lcnlfQmlsbC5qcGcnLFxuICAgICAgICAgICAgICAgIGRldGVjdGVkQW1vdW50OiBmaW5hbEFtb3VudCxcbiAgICAgICAgICAgICAgICBpc1ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHVwZGF0ZWREcmFmdC5zdGF0aW9uZXJ5Py5iaWxsIHx8IG51bGwsXG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBuZXdPdGhlciA9IHtcbiAgICAgICAgICBpZDogYG90aGVyLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBuZXdFeHBlbnNlRm9ybS5kZXNjcmlwdGlvbiB8fCAnTWlzY2VsbGFuZW91cyBFeHBlbnNlJyxcbiAgICAgICAgICBhbW91bnQ6IGZpbmFsQW1vdW50LFxuICAgICAgICAgIHJlbWFya3M6IG5ld0V4cGVuc2VGb3JtLnJlbWFya3MsXG4gICAgICAgICAgYmlsbDogbmV3RXhwZW5zZUZvcm0uYmlsbFVybFxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgdXJsOiBuZXdFeHBlbnNlRm9ybS5iaWxsVXJsLFxuICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBuZXdFeHBlbnNlRm9ybS5iaWxsRmlsZU5hbWUgfHwgJ090aGVyX1NsaXAuanBnJyxcbiAgICAgICAgICAgICAgICBkZXRlY3RlZEFtb3VudDogZmluYWxBbW91bnQsXG4gICAgICAgICAgICAgICAgaXNWZXJpZmllZDogdHJ1ZSxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiBudWxsLFxuICAgICAgICB9O1xuICAgICAgICB1cGRhdGVkRHJhZnQub3RoZXJJdGVtcyA9IFsuLi51cGRhdGVkRHJhZnQub3RoZXJJdGVtcywgbmV3T3RoZXJdO1xuICAgICAgfVxuXG4gICAgICAvLyBSZS1zdW1cbiAgICAgIGNvbnN0IG5ld1RyYXZlbCA9IHVwZGF0ZWREcmFmdC5yb3V0ZXMucmVkdWNlKChzLCByKSA9PiBzICsgKHIudm9sdW50ZWVycyB8fCAwKSAqIChyLnBlclBlcnNvbiB8fCAwKSwgMCk7XG4gICAgICBjb25zdCBuZXdGb29kID1cbiAgICAgICAgKHVwZGF0ZWREcmFmdC5mb29kLmJyZWFrZmFzdD8uYW1vdW50IHx8IDApICtcbiAgICAgICAgKHVwZGF0ZWREcmFmdC5mb29kLmx1bmNoPy5hbW91bnQgfHwgMCkgK1xuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QuZGlubmVyPy5hbW91bnQgfHwgMCkgK1xuICAgICAgICAodXBkYXRlZERyYWZ0LmZvb2QucmVmcmVzaG1lbnRzPy5hbW91bnQgfHwgMCk7XG4gICAgICBjb25zdCBuZXdTdGF0aW9uZXJ5ID0gdXBkYXRlZERyYWZ0LnN0YXRpb25lcnk/LmFtb3VudCB8fCAwO1xuICAgICAgY29uc3QgbmV3T3RoZXIgPSB1cGRhdGVkRHJhZnQub3RoZXJJdGVtcy5yZWR1Y2UoKHMsIG8pID0+IHMgKyAoby5hbW91bnQgfHwgMCksIDApO1xuICAgICAgdXBkYXRlZERyYWZ0LnRvdGFsQW1vdW50ID0gbmV3VHJhdmVsICsgbmV3Rm9vZCArIG5ld1N0YXRpb25lcnkgKyBuZXdPdGhlcjtcblxuICAgICAgb25TYXZlRHJhZnQodXBkYXRlZERyYWZ0KTtcbiAgICAgIHNob3dUb2FzdChgQWRkZWQgXCIke25ld0V4cGVuc2VGb3JtLmRlc2NyaXB0aW9ufVwiIHRvIHN0YXRlbWVudGApO1xuICAgIH0gZWxzZSBpZiAob25BZGRGaW5hbmNlRW50cnkpIHtcbiAgICAgIG9uQWRkRmluYW5jZUVudHJ5KHtcbiAgICAgICAgZGF0ZTogc3RhdGVtZW50TWV0YS5kYXRlLFxuICAgICAgICBkZXNjcmlwdGlvbjogbmV3RXhwZW5zZUZvcm0uZGVzY3JpcHRpb24gfHwgJ0V4cGVuc2UgRW50cnknLFxuICAgICAgICBjYXRlZ29yeTogbmV3RXhwZW5zZUZvcm0uY2F0ZWdvcnkgYXMgYW55LFxuICAgICAgICBhbW91bnQ6IGZpbmFsQW1vdW50LFxuICAgICAgICBwYW5jaGF5YXRJZDogJ2RoYXJtYXB1cmktbWFpbicsXG4gICAgICAgIHBhbmNoYXlhdE5hbWU6IHN0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWUsXG4gICAgICAgIHZpbGxhZ2VOYW1lOiAnQ2x1c3RlciBDZW50ZXInLFxuICAgICAgICBzdGF0dXM6ICdEcmFmdCcsXG4gICAgICAgIGJpbGxVcmw6IG5ld0V4cGVuc2VGb3JtLmJpbGxVcmwgfHwgdW5kZWZpbmVkLFxuICAgICAgICByZW1hcmtzOiBuZXdFeHBlbnNlRm9ybS5yZW1hcmtzLFxuICAgICAgICBjb3VudDogdm9scyB8fCB1bmRlZmluZWQsXG4gICAgICAgIGNvdW50QW1vdW50OiB2b2xzICYmIHBlclAgPyBgJHt2b2xzfcOXJHtwZXJQfWAgOiB1bmRlZmluZWQsXG4gICAgICAgIHNlc3Npb25EYXk6IHN0YXRlbWVudE1ldGEuc2Vzc2lvbkRheSxcbiAgICAgIH0pO1xuICAgICAgc2hvd1RvYXN0KGBBZGRlZCBleHBlbnNlIHJvd2ApO1xuICAgIH1cblxuICAgIHNldFNob3dBZGRNb2RhbChmYWxzZSk7XG4gICAgc2V0TmV3RXhwZW5zZUZvcm0oe1xuICAgICAgY2F0ZWdvcnk6ICdUcmF2ZWwnLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgY291bnQ6ICcnLFxuICAgICAgcGVyUGVyc29uOiAnJyxcbiAgICAgIHRvdGFsQW1vdW50OiAnJyxcbiAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgYmlsbFVybDogbnVsbCxcbiAgICAgIGJpbGxGaWxlTmFtZTogJycsXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gU0FWRSBNRVRBREFUQSBDSEFOR0VTXG4gIGNvbnN0IGhhbmRsZVNhdmVNZXRhZGF0YSA9ICgpID0+IHtcbiAgICBpZiAoY3VycmVudERyYWZ0ICYmIG9uU2F2ZURyYWZ0KSB7XG4gICAgICBjb25zdCB1cGRhdGVkRHJhZnQ6IEZpbmFuY2VEcmFmdCA9IHtcbiAgICAgICAgLi4uY3VycmVudERyYWZ0LFxuICAgICAgICB0aXRsZTogbWV0YUZvcm0uc2Vzc2lvbk5hbWUsXG4gICAgICAgIGNvbGxlZ2VOYW1lOiBtZXRhRm9ybS5jb2xsZWdlTmFtZSxcbiAgICAgICAgY2x1c3Rlck5hbWU6IG1ldGFGb3JtLmNsdXN0ZXJOYW1lLFxuICAgICAgICBzZXNzaW9uRGF5OiBtZXRhRm9ybS5zZXNzaW9uRGF5LFxuICAgICAgICBzZXNzaW9uRGF0ZTogbWV0YUZvcm0uZGF0ZSxcbiAgICAgICAgc3BvY05hbWU6IG1ldGFGb3JtLnNwb2NOYW1lLFxuICAgICAgICBmaW5hbmNlck5hbWU6IG1ldGFGb3JtLmZpbmFuY2VyTmFtZSxcbiAgICAgIH07XG4gICAgICBvblNhdmVEcmFmdCh1cGRhdGVkRHJhZnQpO1xuICAgICAgc2hvd1RvYXN0KCdTdGF0ZW1lbnQgZGV0YWlscyB1cGRhdGVkJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNob3dUb2FzdCgnTWV0YWRhdGEgdXBkYXRlZCBmb3IgcHJldmlldycpO1xuICAgIH1cbiAgICBzZXRTaG93RWRpdE1ldGFNb2RhbChmYWxzZSk7XG4gIH07XG5cbiAgLy8gRVhDRUwgKC5YTFNYKSBFWFBPUlQgVVNJTkcgWExTWCBMSUJSQVJZXG4gIGNvbnN0IGhhbmRsZUV4cG9ydEV4Y2VsID0gKCkgPT4ge1xuICAgIGNvbnN0IHdiID0gWExTWC51dGlscy5ib29rX25ldygpO1xuXG4gICAgLy8gQ3JlYXRlIHN0eWxlZCBtYXRyaXggZGF0YVxuICAgIGNvbnN0IHdzRGF0YTogYW55W11bXSA9IFtcbiAgICAgIFsnVEFMRU5UIFFVRVNUIEZPUiBJTkRJQScsICcnLCAnJywgJycsICcnLCAnJywgJycsICcnXSxcbiAgICAgIFsnQWNhZGVtaWMgeWVhciAyMDI2LTIwMjcnLCAnJywgJycsICcnLCAnJywgJycsICcnLCAnJ10sXG4gICAgICBbJ0ZJTkFOQ0UgUkVQT1JUJywgJycsICcnLCAnJywgJycsICcnLCAnJywgJyddLFxuICAgICAgW2Ake3N0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWV9IENsdXN0ZXJgLCAnJywgJycsICcnLCAnJywgJycsICcnLCAnJ10sXG4gICAgICBbXSxcbiAgICAgIFsnQ09MTEVHRTonLCBzdGF0ZW1lbnRNZXRhLmNvbGxlZ2VOYW1lLCAnJywgJ0NMVVNURVI6Jywgc3RhdGVtZW50TWV0YS5jbHVzdGVyTmFtZSwgJycsICdTRVNTSU9OOicsIHN0YXRlbWVudE1ldGEuc2Vzc2lvbk5hbWVdLFxuICAgICAgWydEQVRFOicsIHN0YXRlbWVudE1ldGEuZGF0ZSwgJycsICdTUE9DOicsIHN0YXRlbWVudE1ldGEuc3BvY05hbWUsICcnLCAnRklOQU5DRVI6Jywgc3RhdGVtZW50TWV0YS5maW5hbmNlck5hbWVdLFxuICAgICAgWydEQVk6Jywgc3RhdGVtZW50TWV0YS5zZXNzaW9uRGF5LCAnJywgJ1NUQVRVUzonLCBzdGF0ZW1lbnRNZXRhLnN0YXR1cywgJycsICcnLCAnJ10sXG4gICAgICBbXSxcbiAgICAgIFsnRVhQRU5TRSBERVRBSUxTJywgJycsICcnLCAnJywgJycsICcnLCAnJywgJyddLFxuICAgICAgWydTLk5vJywgJ0NhdGVnb3J5JywgJ0Rlc2NyaXB0aW9uJywgJ0NvdW50JywgJ0NvdW50w5dBbW91bnQnLCAnVG90YWwgKElOUiknLCAnQmlsbHMgQXR0YWNoZWQnLCAnUmVtYXJrcyddLFxuICAgIF07XG5cbiAgICB0YWJsZUl0ZW1zLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgIHdzRGF0YS5wdXNoKFtcbiAgICAgICAgaXRlbS5zTm8sXG4gICAgICAgIGl0ZW0uY2F0ZWdvcnksXG4gICAgICAgIGl0ZW0uZGVzY3JpcHRpb24sXG4gICAgICAgIGl0ZW0uY291bnQsXG4gICAgICAgIGl0ZW0uY291bnRBbW91bnQsXG4gICAgICAgIGl0ZW0udG90YWwsXG4gICAgICAgIGl0ZW0uYmlsbFVybCA/ICdZZXMgKFJlY2VpcHQgQXR0YWNoZWQpJyA6ICdOb25lJyxcbiAgICAgICAgaXRlbS5yZW1hcmtzLFxuICAgICAgXSk7XG4gICAgfSk7XG5cbiAgICB3c0RhdGEucHVzaChbXSk7XG4gICAgaWYgKHRyYXZlbFRvdGFsID4gMCkge1xuICAgICAgd3NEYXRhLnB1c2goWycnLCAnJywgJycsICcnLCAnVHJhdmVsIFRvdGFsOicsIHRyYXZlbFRvdGFsLCAnJywgJyddKTtcbiAgICB9XG4gICAgaWYgKGZvb2RUb3RhbCA+IDApIHtcbiAgICAgIHdzRGF0YS5wdXNoKFsnJywgJycsICcnLCAnJywgJ0Zvb2QgVG90YWw6JywgZm9vZFRvdGFsLCAnJywgJyddKTtcbiAgICB9XG4gICAgaWYgKHN0YXRpb25lcnlUb3RhbCA+IDApIHtcbiAgICAgIHdzRGF0YS5wdXNoKFsnJywgJycsICcnLCAnJywgJ1N0YXRpb25lcnkgVG90YWw6Jywgc3RhdGlvbmVyeVRvdGFsLCAnJywgJyddKTtcbiAgICB9XG4gICAgaWYgKG90aGVyVG90YWwgPiAwKSB7XG4gICAgICB3c0RhdGEucHVzaChbJycsICcnLCAnJywgJycsICdPdGhlciBFeHBlbnNlcyBUb3RhbDonLCBvdGhlclRvdGFsLCAnJywgJyddKTtcbiAgICB9XG4gICAgd3NEYXRhLnB1c2goWycnLCAnJywgJycsICcnLCAnR1JBTkQgVE9UQUwgKElOUik6JywgZ3JhbmRUb3RhbCwgJycsICcnXSk7XG4gICAgd3NEYXRhLnB1c2goW10pO1xuICAgIHdzRGF0YS5wdXNoKFsnQ29vcmRpbmF0b3IgLyBTUE9DIFNpZ25hdHVyZTonLCBzdGF0ZW1lbnRNZXRhLnNwb2NOYW1lLCAnJywgJycsICdDbHVzdGVyIEFkbWluIFNpZ25hdHVyZTonLCBzdGF0ZW1lbnRNZXRhLmZpbmFuY2VyTmFtZSwgJycsICcnXSk7XG5cbiAgICBjb25zdCB3cyA9IFhMU1gudXRpbHMuYW9hX3RvX3NoZWV0KHdzRGF0YSk7XG5cbiAgICAvLyBTZXQgY29sdW1uIHdpZHRoc1xuICAgIHdzWychY29scyddID0gW1xuICAgICAgeyB3Y2g6IDggfSwgIC8vIFMuTm9cbiAgICAgIHsgd2NoOiAxNCB9LCAvLyBDYXRlZ29yeVxuICAgICAgeyB3Y2g6IDM1IH0sIC8vIERlc2NyaXB0aW9uXG4gICAgICB7IHdjaDogMTAgfSwgLy8gQ291bnRcbiAgICAgIHsgd2NoOiAxNSB9LCAvLyBDb3VudCB4IEFtb3VudFxuICAgICAgeyB3Y2g6IDE0IH0sIC8vIFRvdGFsXG4gICAgICB7IHdjaDogMjAgfSwgLy8gQmlsbHNcbiAgICAgIHsgd2NoOiAzNSB9LCAvLyBSZW1hcmtzXG4gICAgXTtcblxuICAgIFhMU1gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCAnRmluYW5jZSBTdGF0ZW1lbnQnKTtcbiAgICBjb25zdCBjbGVhblNlc3Npb24gPSBzdGF0ZW1lbnRNZXRhLnNlc3Npb25EYXkucmVwbGFjZSgvW15hLXpBLVowLTldL2csICdfJyk7XG4gICAgWExTWC53cml0ZUZpbGUod2IsIGBUUUlfRmluYW5jZV9TdGF0ZW1lbnRfJHtjbGVhblNlc3Npb259Lnhsc3hgKTtcbiAgICBzaG93VG9hc3QoJ0V4Y2VsICgueGxzeCkgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkhJyk7XG4gIH07XG5cbiAgLy8gV09SRCAoLkRPQykgRVhQT1JUIFVTSU5HIE1JTUUgSFRNTC9XT1JEIEZPUk1BVFxuICBjb25zdCBoYW5kbGVFeHBvcnRXb3JkID0gKCkgPT4ge1xuICAgIGNvbnN0IGNsZWFuU2Vzc2lvbiA9IHN0YXRlbWVudE1ldGEuc2Vzc2lvbkRheS5yZXBsYWNlKC9bXmEtekEtWjAtOV0vZywgJ18nKTtcblxuICAgIGNvbnN0IHRhYmxlUm93c0h0bWwgPSB0YWJsZUl0ZW1zXG4gICAgICAubWFwKFxuICAgICAgICAoaXRlbSkgPT4gYFxuICAgICAgPHRyIHN0eWxlPVwiYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjNGM2ZDM7XCI+XG4gICAgICAgIDx0ZCBzdHlsZT1cInBhZGRpbmc6IDhweDsgdGV4dC1hbGlnbjogY2VudGVyOyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPiR7aXRlbS5zTm99PC90ZD5cbiAgICAgICAgPHRkIHN0eWxlPVwicGFkZGluZzogOHB4OyBmb250LXdlaWdodDogYm9sZDsgYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcIj4ke2l0ZW0uY2F0ZWdvcnl9PC90ZD5cbiAgICAgICAgPHRkIHN0eWxlPVwicGFkZGluZzogOHB4OyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPiR7aXRlbS5kZXNjcmlwdGlvbn08L3RkPlxuICAgICAgICA8dGQgc3R5bGU9XCJwYWRkaW5nOiA4cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcIj4ke2l0ZW0uY291bnR9PC90ZD5cbiAgICAgICAgPHRkIHN0eWxlPVwicGFkZGluZzogOHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XCI+JHtpdGVtLmNvdW50QW1vdW50fTwvdGQ+XG4gICAgICAgIDx0ZCBzdHlsZT1cInBhZGRpbmc6IDhweDsgdGV4dC1hbGlnbjogcmlnaHQ7IGZvbnQtd2VpZ2h0OiBib2xkOyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPlJzLiAke2l0ZW0udG90YWwudG9Mb2NhbGVTdHJpbmcoKX08L3RkPlxuICAgICAgICA8dGQgc3R5bGU9XCJwYWRkaW5nOiA4cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcIj4ke2l0ZW0uYmlsbFVybCA/ICdBdHRhY2hlZCcgOiAnTm9uZSd9PC90ZD5cbiAgICAgICAgPHRkIHN0eWxlPVwicGFkZGluZzogOHB4OyBjb2xvcjogIzU1NTU1NTsgYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcIj4ke2l0ZW0ucmVtYXJrc308L3RkPlxuICAgICAgPC90cj5cbiAgICBgXG4gICAgICApXG4gICAgICAuam9pbignJyk7XG5cbiAgICBjb25zdCB3b3JkQ29udGVudCA9IGBcbiAgICAgIDxodG1sIHhtbG5zOm89XCJ1cm46c2NoZW1hcy1taWNyb3NvZnQtY29tOm9mZmljZTpvZmZpY2VcIiB4bWxuczp3PVwidXJuOnNjaGVtYXMtbWljcm9zb2Z0LWNvbTpvZmZpY2U6d29yZFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvVFIvUkVDLWh0bWw0MFwiPlxuICAgICAgPGhlYWQ+XG4gICAgICAgIDxtZXRhIGNoYXJzZXQ9XCJ1dGYtOFwiPlxuICAgICAgICA8dGl0bGU+VFFJIEZpbmFuY2UgU3RhdGVtZW50PC90aXRsZT5cbiAgICAgICAgPHN0eWxlPlxuICAgICAgICAgIGJvZHkgeyBmb250LWZhbWlseTogJ0NhbGlicmknLCAnQXJpYWwnLCBzYW5zLXNlcmlmOyBtYXJnaW46IDQwcHg7IGNvbG9yOiAjMWExYjIxOyB9XG4gICAgICAgICAgLmhlYWRlci10aXRsZSB7IGZvbnQtc2l6ZTogMjJweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IHRleHQtYWxpZ246IGNlbnRlcjsgY29sb3I6ICMwMDI4Njk7IG1hcmdpbi1ib3R0b206IDRweDsgfVxuICAgICAgICAgIC5oZWFkZXItc3ViIHsgZm9udC1zaXplOiAxNHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IGNvbG9yOiAjNTU1NTU1OyBtYXJnaW4tYm90dG9tOiAyNHB4OyBmb250LXdlaWdodDogYm9sZDsgfVxuICAgICAgICAgIC5tZXRhLWNvbnRhaW5lciB7IHdpZHRoOiAxMDAlOyBtYXJnaW4tYm90dG9tOiAyNHB4OyBmb250LXNpemU6IDEzcHg7IH1cbiAgICAgICAgICAubWV0YS10YWJsZSB7IHdpZHRoOiAxMDAlOyBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlOyBtYXJnaW4tYm90dG9tOiAyMHB4OyB9XG4gICAgICAgICAgLm1ldGEtdGFibGUgdGQgeyBwYWRkaW5nOiA2cHggMTBweDsgYm9yZGVyOiBub25lOyB9XG4gICAgICAgICAgLm1ldGEtbGFiZWwgeyBmb250LXNpemU6IDExcHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBjb2xvcjogIzY2NjY2NjsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgfVxuICAgICAgICAgIC5tZXRhLXZhbCB7IGZvbnQtc2l6ZTogMTNweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IGNvbG9yOiAjMDAwMDAwOyB9XG4gICAgICAgICAgLmRhdGEtdGFibGUgeyB3aWR0aDogMTAwJTsgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTsgZm9udC1zaXplOiAxMnB4OyBtYXJnaW4tdG9wOiAxMHB4OyB9XG4gICAgICAgICAgLmRhdGEtdGFibGUgdGggeyBiYWNrZ3JvdW5kLWNvbG9yOiAjZjBmNGZmOyBjb2xvcjogIzAwMjg2OTsgcGFkZGluZzogMTBweCA4cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBib3JkZXI6IDFweCBzb2xpZCAjY2NjY2NjOyB9XG4gICAgICAgICAgLnN1YnRvdGFsLXJvdyB7IGJhY2tncm91bmQtY29sb3I6ICNmYWY4ZmY7IGZvbnQtd2VpZ2h0OiBib2xkOyB9XG4gICAgICAgICAgLmdyYW5kLXRvdGFsLXJvdyB7IGJhY2tncm91bmQtY29sb3I6ICNkYWUyZmY7IGZvbnQtd2VpZ2h0OiBib2xkOyBmb250LXNpemU6IDE0cHg7IGNvbG9yOiAjMDAxOTQ3OyB9XG4gICAgICAgICAgLnNpZ25hdHVyZXMgeyBtYXJnaW4tdG9wOiA1MHB4OyB3aWR0aDogMTAwJTsgfVxuICAgICAgICA8L3N0eWxlPlxuICAgICAgPC9oZWFkPlxuICAgICAgPGJvZHk+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItdGl0bGVcIj5UYWxlbnQgUXVlc3QgZm9yIEluZGlhPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDE1cHg7IHRleHQtYWxpZ246IGNlbnRlcjsgY29sb3I6ICM0MzQ2NTI7IGZvbnQtd2VpZ2h0OiBib2xkOyBtYXJnaW4tYm90dG9tOiAycHg7XCI+QWNhZGVtaWMgeWVhciAyMDI2LTIwMjc8L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTogMTVweDsgdGV4dC1hbGlnbjogY2VudGVyOyBjb2xvcjogIzAwMjg2OTsgZm9udC13ZWlnaHQ6IGJvbGQ7IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7IG1hcmdpbi1ib3R0b206IDJweDtcIj5GaW5hbmNlIHJlcG9ydDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyLXN1YlwiPiR7c3RhdGVtZW50TWV0YS5jbHVzdGVyTmFtZX0gQ2x1c3RlcjwvZGl2PlxuXG4gICAgICAgIDx0YWJsZSBjbGFzcz1cIm1ldGEtdGFibGVcIj5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGQgd2lkdGg9XCI1MCVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtbGFiZWxcIj5DT0xMRUdFPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXRhLXZhbFwiPiR7c3RhdGVtZW50TWV0YS5jb2xsZWdlTmFtZX08L2Rpdj5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQgd2lkdGg9XCI1MCVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtbGFiZWxcIj5EQVRFPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXRhLXZhbFwiPiR7c3RhdGVtZW50TWV0YS5kYXRlfTwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtbGFiZWxcIj5DTFVTVEVSPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXRhLXZhbFwiPiR7c3RhdGVtZW50TWV0YS5jbHVzdGVyTmFtZX08L2Rpdj5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtZXRhLWxhYmVsXCI+U1BPQzwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWV0YS12YWxcIj4ke3N0YXRlbWVudE1ldGEuc3BvY05hbWV9PC9kaXY+XG4gICAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWV0YS1sYWJlbFwiPlNFU1NJT048L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtdmFsXCI+JHtzdGF0ZW1lbnRNZXRhLnNlc3Npb25OYW1lfSAoJHtzdGF0ZW1lbnRNZXRhLnNlc3Npb25EYXl9KTwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtbGFiZWxcIj5GSU5BTkNFUjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWV0YS12YWxcIj4ke3N0YXRlbWVudE1ldGEuZmluYW5jZXJOYW1lfTwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8L3RyPlxuICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgIDxoMyBzdHlsZT1cImZvbnQtc2l6ZTogMTRweDsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgY29sb3I6ICMwMDI4Njk7IG1hcmdpbi10b3A6IDIwcHg7IGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjMDAyODY5OyBwYWRkaW5nLWJvdHRvbTogNHB4O1wiPkV4cGVuc2UgRGV0YWlsczwvaDM+XG5cbiAgICAgICAgPHRhYmxlIGNsYXNzPVwiZGF0YS10YWJsZVwiPlxuICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgPHRoIHdpZHRoPVwiNSVcIj5TLk5vPC90aD5cbiAgICAgICAgICAgICAgPHRoIHdpZHRoPVwiMTIlXCI+Q2F0ZWdvcnk8L3RoPlxuICAgICAgICAgICAgICA8dGggd2lkdGg9XCIzMCVcIj5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgIDx0aCB3aWR0aD1cIjglXCI+Q291bnQ8L3RoPlxuICAgICAgICAgICAgICA8dGggd2lkdGg9XCIxMiVcIj5Db3VudMOXQW1vdW50PC90aD5cbiAgICAgICAgICAgICAgPHRoIHdpZHRoPVwiMTIlXCI+VG90YWw8L3RoPlxuICAgICAgICAgICAgICA8dGggd2lkdGg9XCI4JVwiPkJpbGxzPC90aD5cbiAgICAgICAgICAgICAgPHRoIHdpZHRoPVwiMTMlXCI+UmVtYXJrczwvdGg+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgJHt0YWJsZVJvd3NIdG1sfVxuICAgICAgICAgICAgJHtcbiAgICAgICAgICAgICAgdHJhdmVsVG90YWwgPiAwXG4gICAgICAgICAgICAgICAgPyBgPHRyIGNsYXNzPVwic3VidG90YWwtcm93XCI+PHRkIGNvbHNwYW49XCI1XCIgc3R5bGU9XCJ0ZXh0LWFsaWduOiByaWdodDsgcGFkZGluZzogOHB4OyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPlRyYXZlbCBUb3RhbDo8L3RkPjx0ZCBzdHlsZT1cInRleHQtYWxpZ246IHJpZ2h0OyBwYWRkaW5nOiA4cHg7IGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7IGNvbG9yOiAjMDAyODY5O1wiPlJzLiAke3RyYXZlbFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9PC90ZD48dGQgY29sc3Bhbj1cIjJcIiBzdHlsZT1cImJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XCI+PC90ZD48L3RyPmBcbiAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAke1xuICAgICAgICAgICAgICBmb29kVG90YWwgPiAwXG4gICAgICAgICAgICAgICAgPyBgPHRyIGNsYXNzPVwic3VidG90YWwtcm93XCI+PHRkIGNvbHNwYW49XCI1XCIgc3R5bGU9XCJ0ZXh0LWFsaWduOiByaWdodDsgcGFkZGluZzogOHB4OyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPkZvb2QgVG90YWw6PC90ZD48dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOiByaWdodDsgcGFkZGluZzogOHB4OyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkOyBjb2xvcjogIzAwMjg2OTtcIj5Scy4gJHtmb29kVG90YWwudG9Mb2NhbGVTdHJpbmcoKX08L3RkPjx0ZCBjb2xzcGFuPVwiMlwiIHN0eWxlPVwiYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcIj48L3RkPjwvdHI+YFxuICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICR7XG4gICAgICAgICAgICAgIHN0YXRpb25lcnlUb3RhbCA+IDBcbiAgICAgICAgICAgICAgICA/IGA8dHIgY2xhc3M9XCJzdWJ0b3RhbC1yb3dcIj48dGQgY29sc3Bhbj1cIjVcIiBzdHlsZT1cInRleHQtYWxpZ246IHJpZ2h0OyBwYWRkaW5nOiA4cHg7IGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XCI+U3RhdGlvbmVyeSBUb3RhbDo8L3RkPjx0ZCBzdHlsZT1cInRleHQtYWxpZ246IHJpZ2h0OyBwYWRkaW5nOiA4cHg7IGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7IGNvbG9yOiAjMDAyODY5O1wiPlJzLiAke3N0YXRpb25lcnlUb3RhbC50b0xvY2FsZVN0cmluZygpfTwvdGQ+PHRkIGNvbHNwYW49XCIyXCIgc3R5bGU9XCJib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1wiPjwvdGQ+PC90cj5gXG4gICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgJHtcbiAgICAgICAgICAgICAgb3RoZXJUb3RhbCA+IDBcbiAgICAgICAgICAgICAgICA/IGA8dHIgY2xhc3M9XCJzdWJ0b3RhbC1yb3dcIj48dGQgY29sc3Bhbj1cIjVcIiBzdHlsZT1cInRleHQtYWxpZ246IHJpZ2h0OyBwYWRkaW5nOiA4cHg7IGJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XCI+T3RoZXIgRXhwZW5zZXMgVG90YWw6PC90ZD48dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOiByaWdodDsgcGFkZGluZzogOHB4OyBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkOyBjb2xvcjogIzAwMjg2OTtcIj5Scy4gJHtvdGhlclRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9PC90ZD48dGQgY29sc3Bhbj1cIjJcIiBzdHlsZT1cImJvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7XCI+PC90ZD48L3RyPmBcbiAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA8dHIgY2xhc3M9XCJncmFuZC10b3RhbC1yb3dcIj5cbiAgICAgICAgICAgICAgPHRkIGNvbHNwYW49XCI1XCIgc3R5bGU9XCJ0ZXh0LWFsaWduOiByaWdodDsgcGFkZGluZzogMTBweDsgYm9yZGVyOiAxcHggc29saWQgIzAwMjg2OTsgZm9udC1zaXplOiAxNHB4O1wiPkdSQU5EIFRPVEFMOjwvdGQ+XG4gICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246IHJpZ2h0OyBwYWRkaW5nOiAxMHB4OyBib3JkZXI6IDFweCBzb2xpZCAjMDAyODY5OyBmb250LXNpemU6IDE0cHg7XCI+UnMuICR7Z3JhbmRUb3RhbC50b0xvY2FsZVN0cmluZygpfTwvdGQ+XG4gICAgICAgICAgICAgIDx0ZCBjb2xzcGFuPVwiMlwiIHN0eWxlPVwiYm9yZGVyOiAxcHggc29saWQgIzAwMjg2OTtcIj48L3RkPlxuICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgIDx0YWJsZSBjbGFzcz1cInNpZ25hdHVyZXNcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDYwcHg7XCI+XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRkIHdpZHRoPVwiNTAlXCIgc3R5bGU9XCJ0ZXh0LWFsaWduOiBjZW50ZXI7XCI+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJib3JkZXItdG9wOiAxcHggc29saWQgIzAwMDAwMDsgd2lkdGg6IDIwMHB4OyBtYXJnaW46IDAgYXV0bzsgcGFkZGluZy10b3A6IDVweDsgZm9udC13ZWlnaHQ6IGJvbGQ7XCI+Q29vcmRpbmF0b3I8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM1NTU1NTU7XCI+U1BPQzogJHtzdGF0ZW1lbnRNZXRhLnNwb2NOYW1lfTwvZGl2PlxuICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDx0ZCB3aWR0aD1cIjUwJVwiIHN0eWxlPVwidGV4dC1hbGlnbjogY2VudGVyO1wiPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiYm9yZGVyLXRvcDogMXB4IHNvbGlkICMwMDAwMDA7IHdpZHRoOiAyMDBweDsgbWFyZ2luOiAwIGF1dG87IHBhZGRpbmctdG9wOiA1cHg7IGZvbnQtd2VpZ2h0OiBib2xkO1wiPkNsdXN0ZXIgQWRtaW48L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM1NTU1NTU7XCI+JHtzdGF0ZW1lbnRNZXRhLmZpbmFuY2VyTmFtZX08L2Rpdj5cbiAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgPC90YWJsZT5cbiAgICAgIDwvYm9keT5cbiAgICAgIDwvaHRtbD5cbiAgICBgO1xuXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFsnXFx1ZmVmZicsIHdvcmRDb250ZW50XSwge1xuICAgICAgdHlwZTogJ2FwcGxpY2F0aW9uL21zd29yZDtjaGFyc2V0PXV0Zi04JyxcbiAgICB9KTtcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgbGluay5ocmVmID0gdXJsO1xuICAgIGxpbmsuZG93bmxvYWQgPSBgVFFJX0ZpbmFuY2VfU3RhdGVtZW50XyR7Y2xlYW5TZXNzaW9ufS5kb2NgO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgbGluay5jbGljaygpO1xuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgIHNob3dUb2FzdCgnV29yZCAoLmRvYykgZG9jdW1lbnQgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkhJyk7XG4gIH07XG5cbiAgLy8gU3RhdGUgZm9yIFBERiBHZW5lcmF0aW9uXG4gIGNvbnN0IFtpc0dlbmVyYXRpbmdQZGYsIHNldElzR2VuZXJhdGluZ1BkZl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gQ2xpZW50LVNpZGUgUERGIEdlbmVyYXRpb24gSGFuZGxlclxuICBjb25zdCBoYW5kbGVFeHBvcnRQREYgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0SXNHZW5lcmF0aW5nUGRmKHRydWUpO1xuICAgIHNob3dUb2FzdCgnR2VuZXJhdGluZyBvZmZpY2lhbCBUUUkgUERGIFN0YXRlbWVudCB3aXRoIGF0dGFjaGVkIGJpbGxzLi4uJyk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGdlbmVyYXRlQW5kRG93bmxvYWRTdGF0ZW1lbnRQREYoe1xuICAgICAgICBlbGVtZW50SWQ6ICdwcmludGFibGUtdHFpLXN0YXRlbWVudC1kb2MnLFxuICAgICAgICBtZXRhOiBzdGF0ZW1lbnRNZXRhLFxuICAgICAgICBpdGVtczogdGFibGVJdGVtcyxcbiAgICAgICAgdHJhdmVsVG90YWwsXG4gICAgICAgIGZvb2RUb3RhbCxcbiAgICAgICAgc3RhdGlvbmVyeVRvdGFsLFxuICAgICAgICBvdGhlclRvdGFsLFxuICAgICAgICBncmFuZFRvdGFsLFxuICAgICAgICBhdHRhY2hlZEJpbGxzOiBhbGxBdHRhY2hlZEJpbGxzLFxuICAgICAgfSk7XG4gICAgICBzaG93VG9hc3QoJ1BERiBkb3dubG9hZGVkIHN1Y2Nlc3NmdWxseSEnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1BERiBleHBvcnQgZXJyb3I6JywgZXJyKTtcbiAgICAgIHdpbmRvdy5wcmludCgpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0dlbmVyYXRpbmdQZGYoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEaXJlY3QgZmlsZSB1cGxvYWQgcmVhZGVyIGZvciBiaWxsIGF0dGFjaG1lbnQgd2l0aCBDbGFyaXR5IENoZWNrICYgUm91dGUgQXV0by1EZXRlY3Rpb25cbiAgY29uc3QgaGFuZGxlVXBsb2FkQmlsbEZpbGUgPSBhc3luYyAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4sIGlzRm9yTmV3OiBib29sZWFuKSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKGZpbGUpIHtcbiAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgICByZWFkZXIub25sb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAocmVhZGVyLnJlc3VsdCkge1xuICAgICAgICAgIGNvbnN0IGRhdGFVcmwgPSByZWFkZXIucmVzdWx0IGFzIHN0cmluZztcbiAgICAgICAgICBjb25zdCBjbGFyaXR5ID0gYXdhaXQgY2hlY2tJbWFnZUNsYXJpdHkoZGF0YVVybCk7XG4gICAgICAgICAgaWYgKCFjbGFyaXR5LmlzQ2xlYXIgJiYgY2xhcml0eS5zY29yZSA8IDI1KSB7XG4gICAgICAgICAgICBzaG93VG9hc3QoJ+KaoO+4jyBOb3RpY2U6IEJpbGwgcGhvdG8gbWF5IGJlIGJsdXJyeSBvciBsb3cgcXVhbGl0eS4nKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBleHRyYWN0ZWQgPSBleHRyYWN0Um91dGVBbmREZXRhaWxzRnJvbVRleHQoJycsIGZpbGUubmFtZSk7XG5cbiAgICAgICAgICBpZiAoaXNGb3JOZXcpIHtcbiAgICAgICAgICAgIHNldE5ld0V4cGVuc2VGb3JtKChwcmV2KSA9PiAoe1xuICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICBiaWxsVXJsOiBkYXRhVXJsLFxuICAgICAgICAgICAgICBiaWxsRmlsZU5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgICAgY2F0ZWdvcnk6IGV4dHJhY3RlZC5jYXRlZ29yeSB8fCBwcmV2LmNhdGVnb3J5LFxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZXh0cmFjdGVkLm9yaWdpbiAmJiBleHRyYWN0ZWQuZGVzdGluYXRpb24gXG4gICAgICAgICAgICAgICAgPyBgVHJhdmVsOiAke2V4dHJhY3RlZC5vcmlnaW59IOKGkiAke2V4dHJhY3RlZC5kZXN0aW5hdGlvbn1gXG4gICAgICAgICAgICAgICAgOiBwcmV2LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICB0b3RhbEFtb3VudDogZXh0cmFjdGVkLmFtb3VudCA/IFN0cmluZyhleHRyYWN0ZWQuYW1vdW50KSA6IHByZXYudG90YWxBbW91bnQsXG4gICAgICAgICAgICAgIHJlbWFya3M6IGV4dHJhY3RlZC5yZW1hcmtzIHx8IHByZXYucmVtYXJrcyxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGVkaXRpbmdJdGVtKSB7XG4gICAgICAgICAgICBzZXRFZGl0aW5nSXRlbSgocHJldikgPT5cbiAgICAgICAgICAgICAgcHJldlxuICAgICAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxuICAgICAgICAgICAgICAgICAgICBiaWxsVXJsOiBkYXRhVXJsLFxuICAgICAgICAgICAgICAgICAgICBiaWxsRmlsZU5hbWU6IGZpbGUubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGV4dHJhY3RlZC5vcmlnaW4gJiYgZXh0cmFjdGVkLmRlc3RpbmF0aW9uIFxuICAgICAgICAgICAgICAgICAgICAgID8gYFRyYXZlbDogJHtleHRyYWN0ZWQub3JpZ2lufSDihpIgJHtleHRyYWN0ZWQuZGVzdGluYXRpb259YFxuICAgICAgICAgICAgICAgICAgICAgIDogcHJldi5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgdG90YWw6IGV4dHJhY3RlZC5hbW91bnQgfHwgcHJldi50b3RhbCxcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA6IG51bGxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNob3dUb2FzdChgQXR0YWNoZWQgJiB2ZXJpZmllZDogJHtmaWxlLm5hbWV9YCk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTYgcGItMTZcIj5cbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XG4gICAgICB7dG9hc3RNZXNzYWdlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBib3R0b20tNiByaWdodC02IHotWzE2MF0gYmctWyMwMDE5NDddIHRleHQtd2hpdGUgcHgtNCBweS0yLjUgcm91bmRlZC1tZCBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTNweF0gZm9udC1zZW1pYm9sZCBib3JkZXIgYm9yZGVyLVsjZGFlMmZmXS80MCBhbmltYXRlLVtzbGlkZVVwXzAuMnNfZWFzZS1vdXRdXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxOHB4XSB0ZXh0LVsjODBkNDkxXVwiPmNoZWNrX2NpcmNsZTwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57dG9hc3RNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVE9QIENPTlRST0wgQkFSIChQcmludCBIaWRkZW4pICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS83MCBzaGFkb3cteHMgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHByaW50OmhpZGRlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQmFja31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGhvdmVyOmJnLVsjZGFlMmZmXS80MCBjdXJzb3ItcG9pbnRlciBiZy1bI2Y0ZjNmYl0gcHgtMy41IHB5LTIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS82MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxOHB4XVwiPmFycm93X2JhY2s8L3NwYW4+XG4gICAgICAgICAgICBCYWNrIHRvIEZpbmFuY2VcbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBTZWxlY3QgU3RhdGVtZW50IFNlc3Npb24gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdXCI+U2Vzc2lvbiBTaGVldDo8L3NwYW4+XG4gICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFZpZXdLZXl9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkVmlld0tleSh2YWwpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBpZD1cImZpbmFuY2Utc2Vzc2lvbi1zaGVldC1zZWxlY3RcIiBjbGFzc05hbWU9XCJ3LTU2IGgtOCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBib3JkZXItWyNjNGM2ZDNdIGJnLVsjZmFmOGZmXVwiPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTZXNzaW9uIFNoZWV0XCIgLz5cbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICB7ZHJhZnRzLm1hcCgoZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtkLmlkfSB2YWx1ZT17ZC5pZH0+XG4gICAgICAgICAgICAgICAgICAgIFtEcmFmdF0ge2QudGl0bGV9ICh7ZC5zZXNzaW9uRGF5fSkgLSAmIzgzNzc7e2QudG90YWxBbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbC1hcHByb3ZlZFwiPkNvbWJpbmVkIEFwcHJvdmVkIFN0YXRlbWVudCAoQ2x1c3Rlcik8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IDggfSwgKF8sIGkpID0+IGBEYXkgJHtpICsgMX1gKS5tYXAoKGRheSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtkYXl9IHZhbHVlPXtkYXl9PlxuICAgICAgICAgICAgICAgICAgICB7ZGF5fSBTdGF0ZW1lbnRcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBY3Rpb24gQnV0dG9uczogU3VibWl0LCBWaWV3IFN0YXRlbWVudCwgQWxsIEJpbGxzLCBFeGNlbCwgV29yZCwgUHJpbnQvUERGICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHsvKiBTdWJtaXQgZm9yIEFwcHJvdmFsIChTUE9DIC8gVm9sdW50ZWVyIHdvcmtmbG93KSAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXRTdGF0ZW1lbnR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMuNSBweS0yIGJnLVsjMTM3MzMzXSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgaG92ZXI6YmctWyMxMzczMzNdLzkwIHNoYWRvdy14cyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT1cIlN1Ym1pdCB0aGlzIHN0YXRlbWVudCBmb3IgY2x1c3RlciByZXZpZXcgYW5kIGFwcHJvdmFsXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE3cHhdXCI+c2VuZDwvc3Bhbj5cbiAgICAgICAgICAgIFN1Ym1pdCBmb3IgQXBwcm92YWxcbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBWaWV3IFN0YXRlbWVudCBNb2RhbCBUcmlnZ2VyICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dGdWxsU3RhdGVtZW50TW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiBiZy1bIzAwMjg2OV0gdGV4dC13aGl0ZSByb3VuZGVkLW1kIHRleHQtWzEycHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bIzAwMjg2OV0vOTAgc2hhZG93LXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwiT3BlbiBjbGVhbiBwcmV2aWV3IHN0YXRlbWVudCB3aXRoIGFsbCBhdHRhY2hlZCBiaWxsc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxN3B4XVwiPnZpc2liaWxpdHk8L3NwYW4+XG4gICAgICAgICAgICBWaWV3IFN0YXRlbWVudFxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIFZpZXcgQWxsIEJpbGxzIEdhbGxlcnkgKi99XG4gICAgICAgICAge2FsbEF0dGFjaGVkQmlsbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRBY3RpdmVHYWxsZXJ5SW5kZXgoMCk7XG4gICAgICAgICAgICAgICAgc2V0U2hvd0FsbEJpbGxzTW9kYWwodHJ1ZSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIGJnLVsjZmFmOGZmXSBib3JkZXIgYm9yZGVyLVsjMDAyODY5XS8zMCB0ZXh0LVsjMDAyODY5XSByb3VuZGVkLW1kIHRleHQtWzEycHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bI2RhZTJmZl0gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIlZpZXcgYWxsIGF0dGFjaGVkIGJpbGwgcmVjZWlwdHMgaW4gYSBnYWxsZXJ5XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxN3B4XVwiPnBob3RvX2xpYnJhcnk8L3NwYW4+XG4gICAgICAgICAgICAgIEFsbCBCaWxscyAoe2FsbEF0dGFjaGVkQmlsbHMubGVuZ3RofSlcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRXhwb3J0IE9wdGlvbnM6IEV4Y2VsLCBXb3JkLCBQREYgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1bI2Y0ZjNmYl0gcC0xIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0RXhjZWx9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQtWyMxMzczMzNdIGhvdmVyOmJnLXdoaXRlIHJvdW5kZWQgdGV4dC1bMTEuNXB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIEV4Y2VsIFNoZWV0ICgueGxzeClcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+dGFibGVfdmlldzwvc3Bhbj5cbiAgICAgICAgICAgICAgRXhjZWxcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydFdvcmR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQtWyMwMDI4NjldIGhvdmVyOmJnLXdoaXRlIHJvdW5kZWQgdGV4dC1bMTEuNXB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIE1pY3Jvc29mdCBXb3JkIERvY3VtZW50ICguZG9jKVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5kZXNjcmlwdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgV29yZFxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0UERGfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNHZW5lcmF0aW5nUGRmfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yLjUgcHktMSB0ZXh0LVsjNTkyNjAwXSBob3ZlcjpiZy13aGl0ZSByb3VuZGVkIHRleHQtWzExLjVweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkV4cG9ydCBhcyBPZmZpY2lhbCBUUUkgUERGIFN0YXRlbWVudFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5cbiAgICAgICAgICAgICAgICB7aXNHZW5lcmF0aW5nUGRmID8gJ2hvdXJnbGFzc190b3AnIDogJ3BpY3R1cmVfYXNfcGRmJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICB7aXNHZW5lcmF0aW5nUGRmID8gJ0dlbmVyYXRpbmcuLi4nIDogJ1BERid9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIERSQUZUIE5PVElGSUNBVElPTiBCQU5ORVIgKi99XG4gICAgICB7c3RhdGVtZW50TWV0YS5pc0RyYWZ0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bI2ZmZjdmMl0gYm9yZGVyIGJvcmRlci1bI2ZmZGJjOF0gcm91bmRlZC1tZCBwLTMuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgdGV4dC1bMTNweF0gcHJpbnQ6aGlkZGVuIHNoYWRvdy14c1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB0ZXh0LVsjNTkyNjAwXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbWQgYmctWyNmZmRiYzhdIHRleHQtWyM1OTI2MDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5kZXNjcmlwdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5PZmZpY2lhbCBUUUkgRmluYW5jZSBTaGVldDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1bI2ZmZGJjOF0gdGV4dC1bIzU5MjYwMF0gdGV4dC1bMTAuNXB4XSBweC0yIHB5LTAuMiByb3VuZGVkIGZvbnQtZXh0cmFib2xkXCI+XG4gICAgICAgICAgICAgICAgICBTdGF0dXM6IHtzdGF0ZW1lbnRNZXRhLnN0YXR1c31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMS41cHhdIHRleHQtWyM3NjI5MDBdIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIENsdXN0ZXIgYXVkaXQgc3RhdGVtZW50IHByZXZpZXcuIENsaWNrIHJlY2VpcHQgYnV0dG9ucyBiZWxvdyB0byBpbnNwZWN0IHZlcmlmaWVkIGJpbGxzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBPRkZJQ0lBTCBUUUkgRklOQU5DRSBTSEVFVCBET0NVTUVOVCAoUFJJTlRBQkxFICYgVU5CT1hFRCBIRUFERVIpICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICA8ZGl2IGlkPVwicHJpbnRhYmxlLXRxaS1zdGF0ZW1lbnQtZG9jXCIgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS84MCBzaGFkb3ctc20gcC02IHNtOnAtMTIgc3BhY2UteS04IHByaW50OnAtMCBwcmludDpib3JkZXItbm9uZSBwcmludDpzaGFkb3ctbm9uZVwiPlxuICAgICAgICBcbiAgICAgICAgey8qIDEuIFRRSSBPRkZJQ0lBTCBMT0dPICYgVElUTEUgSEVBREVSICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHNwYWNlLXktMi41IHBiLTQgYm9yZGVyLWIgYm9yZGVyLVsjZGFlMmZmXVwiPlxuICAgICAgICAgIHsvKiBBdXRoZW50aWMgVFFJIENpcmN1bGFyIFRydXN0IExvZ28gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgPFRxaUxvZ28gc2l6ZT17OTJ9IGNsYXNzTmFtZT1cIm14LWF1dG9cIiAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEgcHQtMVwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtWzIycHhdIHNtOnRleHQtWzI2cHhdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDAwMDBdIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIFRhbGVudCBRdWVzdCBmb3IgSW5kaWFcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXVwiPlxuICAgICAgICAgICAgICBBY2FkZW1pYyB5ZWFyIDIwMjYtMjAyN1xuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIHNtOnRleHQtWzE1cHhdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDI4NjldIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICBGaW5hbmNlIHJlcG9ydFxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzLjVweF0gc206dGV4dC1bMTQuNXB4XSBmb250LWJvbGQgdGV4dC1bIzU5MjYwMF1cIj5cbiAgICAgICAgICAgICAge3N0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWV9IENsdXN0ZXJcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogMi4gVU5CT1hFRCBDTEVBTiBNRVRBREFUQSBTRUNUSU9OICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjZmFmOGZmXSByb3VuZGVkLW1kIHAtNSBzbTpwLTYgYm9yZGVyIGJvcmRlci1bI2RhZTJmZl0vODAgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zIGJvcmRlci1iIGJvcmRlci1bI2RhZTJmZl0gcGItMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgdGV4dC1bIzAwMjg2OV0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmluZm88L3NwYW4+XG4gICAgICAgICAgICAgIFNlc3Npb24gJmFtcDsgQ2x1c3RlciBEZXRhaWxzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtcbiAgICAgICAgICAgICAgICAgIHN0YXRlbWVudE1ldGEuc3RhdHVzID09PSAnQXBwcm92ZWQnXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjZTZmNGVhXSB0ZXh0LVsjMTM3MzMzXSdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctWyNmZmRiYzhdIHRleHQtWyM1OTI2MDBdJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU3RhdHVzOiB7c3RhdGVtZW50TWV0YS5zdGF0dXN9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENsZWFuIDItQ29sdW1uIFVuYm94ZWQgS2V5LVZhbHVlIExheW91dCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLXktMy41IGdhcC14LThcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1iYXNlbGluZSBnYXAtMSBzbTpnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHctMjQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIENPTExFR0U6XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjMDAwMDAwXSB0ZXh0LVsxMy41cHhdXCI+XG4gICAgICAgICAgICAgICAgICB7c3RhdGVtZW50TWV0YS5jb2xsZWdlTmFtZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1iYXNlbGluZSBnYXAtMSBzbTpnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHctMjQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIENMVVNURVI6XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSB0ZXh0LVsxMy41cHhdXCI+XG4gICAgICAgICAgICAgICAgICB7c3RhdGVtZW50TWV0YS5jbHVzdGVyTmFtZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1iYXNlbGluZSBnYXAtMSBzbTpnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHctMjQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIFNFU1NJT046XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMDAwMF0gdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnRNZXRhLnNlc3Npb25OYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWJhc2VsaW5lIGdhcC0xIHNtOmdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdy0yNCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgREFURTpcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDAwMDAwXSB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICAgICAge3N0YXRlbWVudE1ldGEuZGF0ZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1iYXNlbGluZSBnYXAtMSBzbTpnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gZm9udC1ib2xkIHRleHQtWyM3NDc3ODNdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHctMjQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgIFNQT0M6XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMDAwMF0gdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnRNZXRhLnNwb2NOYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWJhc2VsaW5lIGdhcC0xIHNtOmdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTEuNXB4XSBmb250LWJvbGQgdGV4dC1bIzc0Nzc4M10gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdy0yNCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgRklOQU5DRVI6XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMDAwMF0gdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnRNZXRhLmZpbmFuY2VyTmFtZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiAzLiBFWFBFTlNFIERFVEFJTFMgU0VDVElPTiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtWzE0cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAwMDAwXSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+RXhwZW5zZSBEZXRhaWxzPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtWyM3NDc3ODNdIGxvd2VyY2FzZSBmb250LW5vcm1hbFwiPlxuICAgICAgICAgICAgICAgICh7dGFibGVJdGVtcy5sZW5ndGh9IGl0ZW1zIGxvZ2dlZClcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBNYWluIEV4cGVuc2UgVGFibGUgKE1vYmlsZSBDYXJkcyBWaWV3KSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJsb2NrIG1kOmhpZGRlbiBzcGFjZS15LTMgcHJpbnQ6aGlkZGVuXCI+XG4gICAgICAgICAgICB7dGFibGVJdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIGJnLVsjZmFmOGZmXS81MCBzcGFjZS15LTJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1bIzc0Nzc4M11cIj4je2l0ZW0uc05vfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctWyNkYWUyZmZdIHRleHQtWyMwMDI4NjldXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+XG4gICAgICAgICAgICAgICAgICAgIOKCuXtpdGVtLnRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzFhMWIyMV1cIj5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICB7aXRlbS5jb3VudCAmJiBpdGVtLmNvdW50QW1vdW50ICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzU1NTU1NV0gbXQtMC41IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIEZvcm11bGE6IHtpdGVtLmNvdW50fSDDlyB7aXRlbS5jb3VudEFtb3VudH1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTEuNSBib3JkZXItdCBib3JkZXItWyNjNGM2ZDNdLzYwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNTU1NTU1XSB0cnVuY2F0ZSBtYXgtdy1bMTcwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlbWFya3MgfHwgJ0V4cGVuc2UgaXRlbSd9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLmJpbGxVcmwgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRCaWxsWm9vbSgxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEJpbGxSb3RhdGUoMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVCaWxsVmlld2VyKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiBpdGVtLmJpbGxVcmwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBpdGVtLmNhdGVnb3J5ICsgJzogJyArIGl0ZW0uZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiBpdGVtLmNhdGVnb3J5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IGl0ZW0udG90YWwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBpdGVtLmJpbGxGaWxlTmFtZSB8fCAoaXRlbS5jYXRlZ29yeSArICdfQmlsbC5qcGcnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbUlkOiBpdGVtLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgYmctWyNlNmY0ZWFdIHRleHQtWyMxMzczMzNdIGJvcmRlciBib3JkZXItWyMxMzczMzNdLzMwIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1ib2xkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTRweF1cIj5yZWNlaXB0X2xvbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmlldyBCaWxsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyM3NDc3ODNdIHRleHQtWzEwLjVweF1cIj5ObyByZWNlaXB0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cblxuICAgICAgICAgICAgey8qIE1vYmlsZSBDYXRlZ29yeSBUb3RhbHMgU3VtbWFyeSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLVsjZGFlMmZmXSBiZy1bI2ZhZjhmZl0gc3BhY2UteS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPkNhdGVnb3J5IFN1YnRvdGFsczwvZGl2PlxuICAgICAgICAgICAgICB7dHJhdmVsVG90YWwgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWyM0MzQ2NTJdXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5UcmF2ZWwgVG90YWw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPuKCuXt0cmF2ZWxUb3RhbC50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAge2Zvb2RUb3RhbCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkZvb2QgVG90YWw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPuKCuXtmb29kVG90YWwudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHtzdGF0aW9uZXJ5VG90YWwgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWyM0MzQ2NTJdXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5TdGF0aW9uZXJ5IFRvdGFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj7igrl7c3RhdGlvbmVyeVRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB7b3RoZXJUb3RhbCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPk90aGVyIFRvdGFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj7igrl7b3RoZXJUb3RhbC50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBwdC0yIGJvcmRlci10IGJvcmRlci1bI2RhZTJmZl0gZm9udC1ib2xkIHRleHQtc20gdGV4dC1bIzAwMTk0N11cIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5HcmFuZCBUb3RhbDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtYmFzZSB0ZXh0LVsjMDAyODY5XVwiPuKCuXtncmFuZFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1haW4gRXhwZW5zZSBUYWJsZSAoRGVza3RvcCBWaWV3KSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBtZDpibG9jayBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSBvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1tZCBwcmludDpibG9ja1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC1bMTJweF0gYm9yZGVyLWNvbGxhcHNlIG1pbi13LVs3MDBweF1cIj5cbiAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLVsjZmFmOGZmXSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdIGZvbnQtYm9sZCB0ZXh0LVsjMDAwMDAwXVwiPlxuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHctMTIgdGV4dC1jZW50ZXJcIj5TLk5vPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHctMjRcIj5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXVwiPkRlc2NyaXB0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtY2VudGVyIHctMTZcIj5Db3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlciB3LTI0XCI+Q291bnTDl0Ftb3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IHctMjRcIj5Ub3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlciB3LTI0XCI+QmlsbHM8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMi41XCI+UmVtYXJrczwvdGg+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgICB7dGFibGVJdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLVsjZmFmOGZmXS84MCB0cmFuc2l0aW9uLWNvbG9ycyBncm91cFwiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSBmb250LW1vbm8gdGV4dC1jZW50ZXJcIj57aXRlbS5zTm99PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyMwMDI4NjldXCI+e2l0ZW0uY2F0ZWdvcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSBmb250LW1lZGl1bSB0ZXh0LVsjMWExYjIxXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlciBmb250LW1vbm9cIj57aXRlbS5jb3VudH08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlciBmb250LW1vbm9cIj57aXRlbS5jb3VudEFtb3VudH08L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj5cbiAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS50b3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgey8qIEJJTExTIENPTFVNTjogQ2xpY2thYmxlIFZpZXdlciAmIFRodW1ibmFpbCAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iaWxsVXJsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QmlsbFpvb20oMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QmlsbFJvdGF0ZSgwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVCaWxsVmlld2VyKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogaXRlbS5iaWxsVXJsISxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBgJHtpdGVtLmNhdGVnb3J5fTogJHtpdGVtLmRlc2NyaXB0aW9ufWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeTogaXRlbS5jYXRlZ29yeSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogaXRlbS50b3RhbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBpdGVtLmJpbGxGaWxlTmFtZSB8fCBgJHtpdGVtLmNhdGVnb3J5fV9CaWxsLmpwZ2AsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtSWQ6IGl0ZW0uaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIGJnLVsjZTZmNGVhXSBob3ZlcjpiZy1bI2NlZWFkNl0gdGV4dC1bIzEzNzMzM10gYm9yZGVyIGJvcmRlci1bIzEzNzMzM10vMzAgcm91bmRlZC1tZCB0ZXh0LVsxMS41cHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciBzaGFkb3ctMnhzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDbGljayB0byB2aWV3IGZ1bGwgcmVjZWlwdCAvIGJpbGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE1cHhdXCI+cmVjZWlwdF9sb25nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5WaWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyM3NDc3ODNdIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtXCI+4oCUPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IHRleHQtWyM1NTU1NTVdIHRleHQtWzExLjVweF1cIj57aXRlbS5yZW1hcmtzfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuXG4gICAgICAgICAgICAgICAgey8qIFN1YnRvdGFscyAqL31cbiAgICAgICAgICAgICAgICB7dHJhdmVsVG90YWwgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1bI2ZhZjhmZl0gZm9udC1tZWRpdW0gdGV4dC1bMTJweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezV9IGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1yaWdodCBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgICAgICBUcmF2ZWwgVG90YWxcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+XG4gICAgICAgICAgICAgICAgICAgICAg4oK5e3RyYXZlbFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXsyfSBjbGFzc05hbWU9XCJwLTIuNSBiZy1bI2ZhZjhmZl1cIj48L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAge2Zvb2RUb3RhbCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLVsjZmFmOGZmXSBmb250LW1lZGl1bSB0ZXh0LVsxMnB4XVwiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17NX0gY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEZvb2QgVG90YWxcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+XG4gICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvb2RUb3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Mn0gY2xhc3NOYW1lPVwicC0yLjUgYmctWyNmYWY4ZmZdXCI+PC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHtzdGF0aW9uZXJ5VG90YWwgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1bI2ZhZjhmZl0gZm9udC1tZWRpdW0gdGV4dC1bMTJweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezV9IGNsYXNzTmFtZT1cInAtMi41IGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1yaWdodCBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgICAgICBTdGF0aW9uZXJ5IC8gTWF0ZXJpYWxzIFRvdGFsXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtcmlnaHQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKCuXtzdGF0aW9uZXJ5VG90YWwudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezJ9IGNsYXNzTmFtZT1cInAtMi41IGJnLVsjZmFmOGZmXVwiPjwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7b3RoZXJUb3RhbCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLVsjZmFmOGZmXSBmb250LW1lZGl1bSB0ZXh0LVsxMnB4XVwiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17NX0gY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIE90aGVyIEV4cGVuc2VzIFRvdGFsXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtcmlnaHQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKCuXtvdGhlclRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXsyfSBjbGFzc05hbWU9XCJwLTIuNSBiZy1bI2ZhZjhmZl1cIj48L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgey8qIEdyYW5kIFRvdGFsIFN0cmlwICovfVxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1bI2RhZTJmZl0gZm9udC1leHRyYWJvbGQgdGV4dC1bIzAwMTk0N11cIj5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs1fSBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IHRleHQtWzEzLjVweF0gdHJhY2tpbmctd2lkZVwiPlxuICAgICAgICAgICAgICAgICAgICBHcmFuZCBUb3RhbFxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyB0ZXh0LVsxNXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICDigrl7Z3JhbmRUb3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXsyfSBjbGFzc05hbWU9XCJwLTMgYmctWyNkYWUyZmZdXCI+PC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIDQuIEZPT1RFUiBTSUdOLU9GRiBTRUNUSU9OICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTggc206cHQtMTQgZ3JpZCBncmlkLWNvbHMtMiBnYXAtMTIgdGV4dC1jZW50ZXIgdGV4dC1bMTJweF1cIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItWyMwMDAwMDBdIHB0LTIgZm9udC1ib2xkIHRleHQtWyMwMDAwMDBdXCI+XG4gICAgICAgICAgICAgIENvb3JkaW5hdG9yXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzc0Nzc4M10gbXQtMC41XCI+U1BPQzoge3N0YXRlbWVudE1ldGEuc3BvY05hbWV9PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItWyMwMDAwMDBdIHB0LTIgZm9udC1ib2xkIHRleHQtWyMwMDAwMDBdXCI+XG4gICAgICAgICAgICAgIENsdXN0ZXIgQWRtaW5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzQ3NzgzXSBtdC0wLjVcIj57c3RhdGVtZW50TWV0YS5maW5hbmNlck5hbWV9PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBdWRpdCBEb2N1bWVudCBGb290ZXIgTm90ZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwdC0yIHRleHQtWzExcHhdIHRleHQtWyM3NDc3ODNdIGJvcmRlci10IGJvcmRlci1bI2RhZTJmZl0vNjBcIj5cbiAgICAgICAgICBUYWxlbnQgUXVlc3QgZm9yIEluZGlhIOKAlCBPZmZpY2lhbCBGaW5hbmNlIFN0YXRlbWVudCAmYW1wOyBBdWRpdCBEb2N1bWVudFxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBCSUxMIExJR0hUQk9YICYgVklFV0VSIE1PREFMICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7YWN0aXZlQmlsbFZpZXdlciAmJiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVCaWxsVmlld2VyKG51bGwpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS05MDAvNzUgYmFja2Ryb3AtYmx1ci1zbSB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNiBjdXJzb3ItcG9pbnRlciBhbmltYXRlLVtmYWRlSW5fMC4xNXNfZWFzZS1vdXRdXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBtYXgtdy0yeGwgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF0gY3Vyc29yLWRlZmF1bHQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM11cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1bI2Y0ZjNmYl0gYm9yZGVyLWIgYm9yZGVyLVsjYzRjNmQzXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTVweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdIHRleHQtWyMxMzczMzNdXCI+cmVjZWlwdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPnthY3RpdmVCaWxsVmlld2VyLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExLjVweF0gdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVCaWxsVmlld2VyLmZpbGVOYW1lIHx8ICdBdHRhY2hlZCBSZWNlaXB0IEZpbGUnfSDigKIgQW1vdW50OiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtWyMwMDI4NjldXCI+4oK5e2FjdGl2ZUJpbGxWaWV3ZXIuYW1vdW50IHx8IDB9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICB7LyogUm90YXRlICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJpbGxSb3RhdGUoKHIpID0+IChyICsgOTApICUgMzYwKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtWyM0MzQ2NTJdIGhvdmVyOmJnLVsjZThlN2VmXSByb3VuZGVkLW1kIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUm90YXRlIEltYWdlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+cm90YXRlX3JpZ2h0PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIHsvKiBab29tIEluICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJpbGxab29tKCh6KSA9PiBNYXRoLm1pbih6ICsgMC4yNSwgMi41KSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LVsjNDM0NjUyXSBob3ZlcjpiZy1bI2U4ZTdlZl0gcm91bmRlZC1tZCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlpvb20gSW5cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF1cIj56b29tX2luPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIHsvKiBab29tIE91dCAqL31cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCaWxsWm9vbSgoeikgPT4gTWF0aC5tYXgoeiAtIDAuMjUsIDAuNSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNlOGU3ZWZdIHJvdW5kZWQtbWQgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJab29tIE91dFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxOHB4XVwiPnpvb21fb3V0PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIHsvKiBDbG9zZSAqL31cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVCaWxsVmlld2VyKG51bGwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNlOGU3ZWZdIHJvdW5kZWQtZnVsbCBjdXJzb3ItcG9pbnRlciBtbC0xXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBSZWNlaXB0IEltYWdlIERpc3BsYXkgQ2FudmFzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctWyMxYTFiMjFdIGZsZXgtMSBvdmVyZmxvdy1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1pbi1oLVszNDBweF0gbWF4LWgtWzYwdmhdXCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBgc2NhbGUoJHtiaWxsWm9vbX0pIHJvdGF0ZSgke2JpbGxSb3RhdGV9ZGVnKWAsXG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiAndHJhbnNmb3JtIDAuMnMgZWFzZS1vdXQnLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LXctZnVsbFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICBzcmM9e2FjdGl2ZUJpbGxWaWV3ZXIudXJsfVxuICAgICAgICAgICAgICAgICAgYWx0PVwiQmlsbCBSZWNlaXB0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1heC1oLVs1MHZoXSBvYmplY3QtY29udGFpbiByb3VuZGVkLW1kIHNoYWRvdy1zbSBteC1hdXRvXCJcbiAgICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgLy8gRmFsbGJhY2sgZ2VuZXJhdGVkIHN0eWxlZCByZWNlaXB0IHZvdWNoZXIgaWYgbGluayBmYWlsc1xuICAgICAgICAgICAgICAgICAgICAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcmVudCA9IChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkucGFyZW50RWxlbWVudDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcmVudCAmJiAhcGFyZW50LnF1ZXJ5U2VsZWN0b3IoJy52b3VjaGVyLWZhbGxiYWNrJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmYWxsYmFja0RpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgICAgICAgICAgICAgICAgIGZhbGxiYWNrRGl2LmNsYXNzTmFtZSA9ICd2b3VjaGVyLWZhbGxiYWNrIGJnLXdoaXRlIHRleHQtWyMxYTFiMjFdIHAtNiByb3VuZGVkLW1kIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSB3LTgwIHRleHQtY2VudGVyIGZvbnQtbW9ubyBzcGFjZS15LTInO1xuICAgICAgICAgICAgICAgICAgICAgIGZhbGxiYWNrRGl2LmlubmVySFRNTCA9IGBcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDE2cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBjb2xvcjogIzAwMjg2OTtcIj5UQUxFTlQgUVVFU1QgRk9SIElORElBPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzY2NjtcIj5PRkZJQ0lBTCBFWFBFTlNFIFZPVUNIRVI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxociBzdHlsZT1cImJvcmRlcjogMC41cHggZGFzaGVkICNhYWE7IG1hcmdpbjogOHB4IDA7XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDEycHg7IHRleHQtYWxpZ246IGxlZnQ7XCI+PHN0cm9uZz5JdGVtOjwvc3Ryb25nPiAke2FjdGl2ZUJpbGxWaWV3ZXIudGl0bGV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMnB4OyB0ZXh0LWFsaWduOiBsZWZ0O1wiPjxzdHJvbmc+QW1vdW50Ojwvc3Ryb25nPiDigrkke2FjdGl2ZUJpbGxWaWV3ZXIuYW1vdW50IHx8IDB9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMnB4OyB0ZXh0LWFsaWduOiBsZWZ0O1wiPjxzdHJvbmc+RGF0ZTo8L3N0cm9uZz4gJHtzdGF0ZW1lbnRNZXRhLmRhdGV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMnB4OyB0ZXh0LWFsaWduOiBsZWZ0O1wiPjxzdHJvbmc+U3RhdHVzOjwvc3Ryb25nPiBWZXJpZmllZCBSZWNlaXB0IEF0dGFjaGVkPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aHIgc3R5bGU9XCJib3JkZXI6IDAuNXB4IGRhc2hlZCAjYWFhOyBtYXJnaW46IDhweCAwO1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxMHB4OyBjb2xvcjogIzJlN2QzMjsgZm9udC13ZWlnaHQ6IGJvbGQ7XCI+W0RJR0lUQUxMWSBWRVJJRklFRCBJTiBDTFVTVEVSIFJFR0lTVFJZXTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIGA7XG4gICAgICAgICAgICAgICAgICAgICAgcGFyZW50LmFwcGVuZENoaWxkKGZhbGxiYWNrRGl2KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTW9kYWwgQm90dG9tIEFjdGlvbiBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSBib3JkZXItdCBib3JkZXItWyNjNGM2ZDNdIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICBocmVmPXthY3RpdmVCaWxsVmlld2VyLnVybH1cbiAgICAgICAgICAgICAgICAgIGRvd25sb2FkPXthY3RpdmVCaWxsVmlld2VyLmZpbGVOYW1lIHx8ICdUUUlfUmVjZWlwdC5qcGcnfVxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctWyNmNGYzZmJdIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHRleHQtWyMwMDI4NjldIHJvdW5kZWQtbWQgdGV4dC1bMTJweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjZGFlMmZmXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmRvd25sb2FkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgRG93bmxvYWQgUmVjZWlwdFxuICAgICAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICBocmVmPXthY3RpdmVCaWxsVmlld2VyLnVybH1cbiAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICByZWw9XCJub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQtWyMwMDI4NjldIHRleHQtWzEycHhdIGZvbnQtYm9sZCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5vcGVuX2luX25ldzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIE9wZW4gaW4gTmV3IFRhYlxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUJpbGxWaWV3ZXIobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYmctWyMwMDI4NjldIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtWzEycHhdIHJvdW5kZWQtbWQgaG92ZXI6YmctWyMwMDI4NjldLzkwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENsb3NlIFByZXZpZXdcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBFRElUIEVYUEVOU0UgUk9XIE1PREFMICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7ZWRpdGluZ0l0ZW0gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS05MDAvNzUgYmFja2Ryb3AtYmx1ci1zbSB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGFuaW1hdGUtW2ZhZGVJbl8wLjE1c19lYXNlLW91dF1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgbWF4LXctbGcgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gc3BhY2UteS00IHAtNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLVsjYzRjNmQzXSBwYi0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF1cIj5lZGl0PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPkVkaXQgRXhwZW5zZSBMaW5lIEl0ZW08L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFZGl0aW5nSXRlbShudWxsKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1bIzc0Nzc4M10gaG92ZXI6dGV4dC1bIzFhMWIyMV0gcm91bmRlZC1mdWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMuNSB0ZXh0LVsxM3B4XVwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPkNhdGVnb3J5PC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0l0ZW0uY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PlxuICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nSXRlbSh7XG4gICAgICAgICAgICAgICAgICAgICAgLi4uZWRpdGluZ0l0ZW0sXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHZhbCBhcyBhbnksXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMwMDI4NjldIGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQ2F0ZWdvcnlcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiVHJhdmVsXCI+VHJhdmVsPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZvb2RcIj5Gb29kPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlN0YXRpb25lcnlcIj5TdGF0aW9uZXJ5PC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk90aGVyXCI+T3RoZXI8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+RGVzY3JpcHRpb24gLyBSb3V0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0l0ZW0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdJdGVtKHtcbiAgICAgICAgICAgICAgICAgICAgICAuLi5lZGl0aW5nSXRlbSxcbiAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZS50YXJnZXQudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzAwMjg2OV1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5Db3VudCAoVm9sdW50ZWVycyAvIEl0ZW1zKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0l0ZW0uY291bnR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nSXRlbSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5lZGl0aW5nSXRlbSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBlLnRhcmdldC52YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMDAyODY5XVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPlRvdGFsIEFtb3VudCAo4oK5KSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0aW5nSXRlbS50b3RhbH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRpbmdJdGVtKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmVkaXRpbmdJdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgdG90YWw6IHBhcnNlRmxvYXQoZS50YXJnZXQudmFsdWUpIHx8IDAsXG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwMDI4NjldXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+UmVtYXJrczwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdGluZ0l0ZW0ucmVtYXJrc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ0l0ZW0oe1xuICAgICAgICAgICAgICAgICAgICAgIC4uLmVkaXRpbmdJdGVtLFxuICAgICAgICAgICAgICAgICAgICAgIHJlbWFya3M6IGUudGFyZ2V0LnZhbHVlLFxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSByb3VuZGVkLW1kIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwMDI4NjldXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQmlsbCBBdHRhY2htZW50IEZpZWxkICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPlJlY2VpcHQgLyBCaWxsIEF0dGFjaG1lbnQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1bI2Y0ZjNmYl0gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB0ZXh0LVsxMnB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gaG92ZXI6YmctWyNkYWUyZmZdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj51cGxvYWRfZmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2VkaXRpbmdJdGVtLmJpbGxVcmwgPyAnQ2hhbmdlIEJpbGwgUGhvdG8nIDogJ1VwbG9hZCBCaWxsIFBob3RvJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLGFwcGxpY2F0aW9uL3BkZlwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVVwbG9hZEJpbGxGaWxlKGUsIGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgIHtlZGl0aW5nSXRlbS5iaWxsVXJsICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nSXRlbSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmVkaXRpbmdJdGVtLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBiaWxsVXJsOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBiaWxsRmlsZU5hbWU6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bI2JhMWExYV0gaG92ZXI6YmctWyNmZmRhZDZdIHB4LTIgcHktMSByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTRweF1cIj5kZWxldGU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgUmVtb3ZlIEJpbGxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHtlZGl0aW5nSXRlbS5iaWxsRmlsZU5hbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1bIzEzNzMzM10gZm9udC1zZW1pYm9sZCBtdC0xIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgIOKckyBBdHRhY2hlZDoge2VkaXRpbmdJdGVtLmJpbGxGaWxlTmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLVsjYzRjNmQzXVwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ0l0ZW0obnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNmNGYzZmJdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVFZGl0ZWRSb3d9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgaG92ZXI6YmctWyMwMDI4NjldLzkwIGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBBREQgRVhQRU5TRSBST1cgTU9EQUwgKi99XG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHtzaG93QWRkTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctZ3JheS05MDAvNzUgYmFja2Ryb3AtYmx1ci1zbSB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGFuaW1hdGUtW2ZhZGVJbl8wLjE1c19lYXNlLW91dF1cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgbWF4LXctbGcgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gc3BhY2UteS00IHAtNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLVsjYzRjNmQzXSBwYi0zXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF1cIj5hZGRfY2lyY2xlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFkZCBFeHBlbnNlIExpbmUgSXRlbTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtWyM3NDc3ODNdIGhvdmVyOnRleHQtWyMxYTFiMjFdIHJvdW5kZWQtZnVsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zLjUgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5DYXRlZ29yeSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RXhwZW5zZUZvcm0uY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PlxuICAgICAgICAgICAgICAgICAgICBzZXROZXdFeHBlbnNlRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgLi4ubmV3RXhwZW5zZUZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHZhbCBhcyBhbnksXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMwMDI4NjldIGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQ2F0ZWdvcnlcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiVHJhdmVsXCI+VHJhdmVsPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkZvb2RcIj5Gb29kPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlN0YXRpb25lcnlcIj5TdGF0aW9uZXJ5PC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIk90aGVyXCI+T3RoZXI8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICB7bmV3RXhwZW5zZUZvcm0uY2F0ZWdvcnkgPT09ICdUcmF2ZWwnID8gJ1JvdXRlIChlLmcuIEtTUiBDb2xsZWdlIOKGkiBTYWxlbSknIDogJ0Rlc2NyaXB0aW9uIConfVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICAgICAgICAgIG5ld0V4cGVuc2VGb3JtLmNhdGVnb3J5ID09PSAnVHJhdmVsJ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ09yaWdpbiDihpIgRGVzdGluYXRpb24nXG4gICAgICAgICAgICAgICAgICAgICAgOiBuZXdFeHBlbnNlRm9ybS5jYXRlZ29yeSA9PT0gJ0Zvb2QnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnQnJlYWtmYXN0IC8gTHVuY2ggLyBUZWEgYWxsb3dhbmNlJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ0FjdGl2aXR5IG1hdGVyaWFscyAvIEJhbm5lciAvIE1pc2MnXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RXhwZW5zZUZvcm0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgIHNldE5ld0V4cGVuc2VGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgICAuLi5uZXdFeHBlbnNlRm9ybSxcbiAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZS50YXJnZXQudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzAwMjg2OV1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5Db3VudDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gMjBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RXhwZW5zZUZvcm0uY291bnR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBzZXROZXdFeHBlbnNlRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5uZXdFeHBlbnNlRm9ybSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiBlLnRhcmdldC52YWx1ZSxcbiAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5QZXIgUGVyc29uICjigrkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiAxMFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdFeHBlbnNlRm9ybS5wZXJQZXJzb259XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICBzZXROZXdFeHBlbnNlRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5uZXdFeHBlbnNlRm9ybSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlclBlcnNvbjogZS50YXJnZXQudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+VG90YWwgKOKCuSkgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0V4cGVuc2VGb3JtLnRvdGFsQW1vdW50fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgc2V0TmV3RXhwZW5zZUZvcm0oe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4ubmV3RXhwZW5zZUZvcm0sXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbEFtb3VudDogZS50YXJnZXQudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPlJlbWFya3M8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPcHRpb25hbCBkZXRhaWxzIG9yIHZlbmRvciBub3Rlc1wiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RXhwZW5zZUZvcm0ucmVtYXJrc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgc2V0TmV3RXhwZW5zZUZvcm0oe1xuICAgICAgICAgICAgICAgICAgICAgIC4uLm5ld0V4cGVuc2VGb3JtLFxuICAgICAgICAgICAgICAgICAgICAgIHJlbWFya3M6IGUudGFyZ2V0LnZhbHVlLFxuICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSByb3VuZGVkLW1kIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEJpbGwgQXR0YWNobWVudCAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5SZWNlaXB0IC8gQmlsbCBBdHRhY2htZW50PC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctWyNmNGYzZmJdIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGhvdmVyOmJnLVsjZGFlMmZmXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlciB3LWZpdFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPnVwbG9hZF9maWxlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+VXBsb2FkIFJlY2VpcHQgRmlsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLyosYXBwbGljYXRpb24vcGRmXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVVcGxvYWRCaWxsRmlsZShlLCB0cnVlKX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7bmV3RXhwZW5zZUZvcm0uYmlsbEZpbGVOYW1lICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyMxMzczMzNdIGZvbnQtc2VtaWJvbGQgbXQtMSBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICDinJMgQXR0YWNoZWQ6IHtuZXdFeHBlbnNlRm9ybS5iaWxsRmlsZU5hbWV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0zIGJvcmRlci10IGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNmNGYzZmJdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZE5ld0V4cGVuc2VSb3d9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLVsjZmI3ODAwXSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgaG92ZXI6YmctWyNmYjc4MDBdLzkwIGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBBZGQgTGluZSBJdGVtXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7LyogRURJVCBNRVRBREFUQSBNT0RBTCAqL31cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAge3Nob3dFZGl0TWV0YU1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBhbmltYXRlLVtmYWRlSW5fMC4xNXNfZWFzZS1vdXRdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHNwYWNlLXktNCBwLTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2M0YzZkM10gcGItM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1bMTZweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+ZWRpdF9ub3RlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPkVkaXQgU3RhdGVtZW50IERldGFpbHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RWRpdE1ldGFNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtWyM3NDc3ODNdIGhvdmVyOnRleHQtWyMxYTFiMjFdIHJvdW5kZWQtZnVsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQtWzEzcHhdXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+Q29sbGVnZSBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXttZXRhRm9ybS5jb2xsZWdlTmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWV0YUZvcm0oeyAuLi5tZXRhRm9ybSwgY29sbGVnZU5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSByb3VuZGVkLW1kIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5DbHVzdGVyIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e21ldGFGb3JtLmNsdXN0ZXJOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXRhRm9ybSh7IC4uLm1ldGFGb3JtLCBjbHVzdGVyTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPlNlc3Npb24gVGl0bGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e21ldGFGb3JtLnNlc3Npb25OYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXRhRm9ybSh7IC4uLm1ldGFGb3JtLCBzZXNzaW9uTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LVsjNDM0NjUyXSBtYi0xXCI+U2Vzc2lvbiBEYXk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21ldGFGb3JtLnNlc3Npb25EYXl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWV0YUZvcm0oeyAuLi5tZXRhRm9ybSwgc2Vzc2lvbkRheTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5EYXRlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXttZXRhRm9ybS5kYXRlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1ldGFGb3JtKHsgLi4ubWV0YUZvcm0sIGRhdGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIG1iLTFcIj5TUE9DIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21ldGFGb3JtLnNwb2NOYW1lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1ldGFGb3JtKHsgLi4ubWV0YUZvcm0sIHNwb2NOYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSByb3VuZGVkLW1kIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gbWItMVwiPkZpbmFuY2VyIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e21ldGFGb3JtLmZpbmFuY2VyTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXRhRm9ybSh7IC4uLm1ldGFGb3JtLCBmaW5hbmNlck5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTIgcHQtMyBib3JkZXItdCBib3JkZXItWyNjNGM2ZDNdXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RWRpdE1ldGFNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXdoaXRlIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNmNGYzZmJdIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVNZXRhZGF0YX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgYmctWyMwMDI4NjldIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LVsxMi41cHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bIzAwMjg2OV0vOTAgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFNhdmUgRGV0YWlsc1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgey8qIEFMTCBCSUxMUyBHQUxMRVJZIE1PREFMICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7c2hvd0FsbEJpbGxzTW9kYWwgJiYgYWxsQXR0YWNoZWRCaWxscy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBbGxCaWxsc01vZGFsKGZhbHNlKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBjdXJzb3ItcG9pbnRlciBhbmltYXRlLVtmYWRlSW5fMC4xNXNfZWFzZS1vdXRdXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBtYXgtdy0zeGwgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTJ2aF0gY3Vyc29yLWRlZmF1bHQgYm9yZGVyIGJvcmRlci1bI2M0YzZkM11cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLVsjZjRmM2ZiXSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxNnB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF0gdGV4dC1bIzEzNzMzM11cIj5waG90b19saWJyYXJ5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+QXR0YWNoZWQgQmlsbHMgR2FsbGVyeSAoe2FjdGl2ZUdhbGxlcnlJbmRleCArIDF9IG9mIHthbGxBdHRhY2hlZEJpbGxzLmxlbmd0aH0pPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgIHthbGxBdHRhY2hlZEJpbGxzW2FjdGl2ZUdhbGxlcnlJbmRleF0udGl0bGV9IOKAoiDigrl7YWxsQXR0YWNoZWRCaWxsc1thY3RpdmVHYWxsZXJ5SW5kZXhdLmFtb3VudH1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FsbEJpbGxzTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LVsjNDM0NjUyXSBob3ZlcjpiZy1bI2U4ZTdlZl0gcm91bmRlZC1mdWxsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEdhbGxlcnkgSW1hZ2UgRGlzcGxheSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLVsjMWExYjIxXSBmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWluLWgtWzM4MHB4XSBtYXgtaC1bNjB2aF0gcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIHNyYz17YWxsQXR0YWNoZWRCaWxsc1thY3RpdmVHYWxsZXJ5SW5kZXhdLnVybH1cbiAgICAgICAgICAgICAgICBhbHQ9XCJCaWxsXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXgtaC1bNTJ2aF0gb2JqZWN0LWNvbnRhaW4gcm91bmRlZC1tZCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgIHsvKiBQcmV2IC8gTmV4dCBidXR0b25zICovfVxuICAgICAgICAgICAgICB7YWxsQXR0YWNoZWRCaWxscy5sZW5ndGggPiAxICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUdhbGxlcnlJbmRleCgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXYgPT09IDAgPyBhbGxBdHRhY2hlZEJpbGxzLmxlbmd0aCAtIDEgOiBwcmV2IC0gMVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTQgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYmxhY2svNjAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBob3ZlcjpiZy1ibGFjay85MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjRweF1cIj5jaGV2cm9uX2xlZnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUdhbGxlcnlJbmRleCgocHJldikgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXYgPT09IGFsbEF0dGFjaGVkQmlsbHMubGVuZ3RoIC0gMSA/IDAgOiBwcmV2ICsgMVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC00IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWJsYWNrLzYwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaG92ZXI6YmctYmxhY2svOTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzI0cHhdXCI+Y2hldnJvbl9yaWdodDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUaHVtYm5haWwgU3RyaXAgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1bI2ZhZjhmZl0gYm9yZGVyLXQgYm9yZGVyLVsjYzRjNmQzXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAge2FsbEF0dGFjaGVkQmlsbHMubWFwKChiaWxsLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUdhbGxlcnlJbmRleChpZHgpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgc2hyaW5rLTAgdy0xNCBoLTE0IHJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci0yIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZUdhbGxlcnlJbmRleCA9PT0gaWR4XG4gICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLVsjMDAyODY5XSBzY2FsZS0xMDUgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1bI2M0YzZkM10gb3BhY2l0eS02MCBob3ZlcjpvcGFjaXR5LTEwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtiaWxsLnVybH0gYWx0PVwiVGh1bWJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCBiZy1ibGFjay83MCB0ZXh0LXdoaXRlIHRleHQtWzlweF0gcHgtMSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgI3tpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy13aGl0ZSBib3JkZXItdCBib3JkZXItWyNjNGM2ZDNdIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgIGhyZWY9e2FsbEF0dGFjaGVkQmlsbHNbYWN0aXZlR2FsbGVyeUluZGV4XS51cmx9XG4gICAgICAgICAgICAgICAgZG93bmxvYWQ9e2FsbEF0dGFjaGVkQmlsbHNbYWN0aXZlR2FsbGVyeUluZGV4XS5maWxlTmFtZX1cbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgIHJlbD1cIm5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYmctWyNmNGYzZmJdIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHRleHQtWyMwMDI4NjldIHJvdW5kZWQtbWQgdGV4dC1bMTJweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjZGFlMmZmXSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZG93bmxvYWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgRG93bmxvYWQgVGhpcyBCaWxsXG4gICAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FsbEJpbGxzTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMS41IGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTJweF0gZm9udC1ib2xkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERvbmVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cbiAgICAgIHsvKiBWSUVXIFNUQVRFTUVOVCBNT0RBTCAoUE9QVVAgVklFVyBTVEFURU1FTlQpICovfVxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XG4gICAgICB7c2hvd0Z1bGxTdGF0ZW1lbnRNb2RhbCAmJiAoXG4gICAgICAgIDxkaXZcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RnVsbFN0YXRlbWVudE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMyBzbTpwLTYgY3Vyc29yLXBvaW50ZXIgYW5pbWF0ZS1bZmFkZUluXzAuMTVzX2Vhc2Utb3V0XVwiXG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgbWF4LXctNHhsIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGZsZXggZmxleC1jb2wgbWF4LWgtWzkydmhdIGN1cnNvci1kZWZhdWx0IGJvcmRlciBib3JkZXItWyNjNGM2ZDNdXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1bIzAwMjg2OV0gdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5yZWNlaXB0X2xvbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE2cHhdIGZvbnQtYm9sZFwiPk9mZmljaWFsIFRRSSBGaW5hbmNlIFN0YXRlbWVudCBQcmV2aWV3PC9oMz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnRFeGNlbH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIGJnLXdoaXRlMjAgaG92ZXI6Ymctd2hpdGUzMCB0ZXh0LXdoaXRlIHJvdW5kZWQgdGV4dC1bMTEuNXB4XSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTVweF1cIj50YWJsZV92aWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgRXhjZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnRXb3JkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctd2hpdGUyMCBob3ZlcjpiZy13aGl0ZTMwIHRleHQtd2hpdGUgcm91bmRlZCB0ZXh0LVsxMS41cHhdIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNXB4XVwiPmRlc2NyaXB0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgV29yZFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydFBERn1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0dlbmVyYXRpbmdQZGZ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1bI2ZiNzgwMF0gdGV4dC13aGl0ZSByb3VuZGVkIHRleHQtWzExLjVweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBUUUkgU3RhdGVtZW50IFBERlwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICB7aXNHZW5lcmF0aW5nUGRmID8gJ2hvdXJnbGFzc190b3AnIDogJ3BpY3R1cmVfYXNfcGRmJ31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0dlbmVyYXRpbmdQZGYgPyAnR2VuZXJhdGluZy4uLicgOiAnUERGJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RnVsbFN0YXRlbWVudE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXdoaXRlLzgwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1mdWxsIGN1cnNvci1wb2ludGVyIG1sLTFcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMS41IHBiLTIgYm9yZGVyLWIgYm9yZGVyLVsjZGFlMmZmXVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxUcWlMb2dvIHNpemU9ezc1fSBjbGFzc05hbWU9XCJteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMjBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1bIzAwMDAwMF0gcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgVGFsZW50IFF1ZXN0IGZvciBJbmRpYVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml1cIj5cbiAgICAgICAgICAgICAgICAgIEFjYWRlbWljIHllYXIgMjAyNi0yMDI3XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxM3B4XSBmb250LWV4dHJhYm9sZCB0ZXh0LVsjMDAyODY5XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgIEZpbmFuY2UgcmVwb3J0XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMi41cHhdIGZvbnQtYm9sZCB0ZXh0LVsjNTkyNjAwXVwiPlxuICAgICAgICAgICAgICAgICAge3N0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWV9IENsdXN0ZXJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFVuYm94ZWQgTWV0YWRhdGEgaW4gTW9kYWwgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctWyNmYWY4ZmZdIHAtNCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItWyNjNGM2ZDNdLzYwIHRleHQtWzEyLjVweF0gZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwLjVweF0gYmxvY2tcIj5DT0xMRUdFPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDAwMDBdXCI+e3N0YXRlbWVudE1ldGEuY29sbGVnZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwLjVweF0gYmxvY2tcIj5EQVRFPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDAwMDAwXVwiPntzdGF0ZW1lbnRNZXRhLmRhdGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwLjVweF0gYmxvY2tcIj5DTFVTVEVSPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+e3N0YXRlbWVudE1ldGEuY2x1c3Rlck5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwLjVweF0gYmxvY2tcIj5TUE9DPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMDAwMDAwXVwiPntzdGF0ZW1lbnRNZXRhLnNwb2NOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzc0Nzc4M10gZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LVsxMC41cHhdIGJsb2NrXCI+U0VTU0lPTjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMDAwMF1cIj57c3RhdGVtZW50TWV0YS5zZXNzaW9uTmFtZX0gKHtzdGF0ZW1lbnRNZXRhLnNlc3Npb25EYXl9KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzc0Nzc4M10gZm9udC1ib2xkIHVwcGVyY2FzZSB0ZXh0LVsxMC41cHhdIGJsb2NrXCI+RklOQU5DRVI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyMwMDAwMDBdXCI+e3N0YXRlbWVudE1ldGEuZmluYW5jZXJOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRhYmxlICovfVxuICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LVsxMnB4XSBib3JkZXItY29sbGFwc2UgYm9yZGVyIGJvcmRlci1bI2M0YzZkM11cIj5cbiAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctWyNmYWY4ZmZdIGZvbnQtYm9sZCB0ZXh0LVsjMDAwMDAwXSBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdXCI+XG4gICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB3LTEwIHRleHQtY2VudGVyXCI+Uy5ObzwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB3LTIwXCI+Q2F0ZWdvcnk8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM11cIj5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlciB3LTE0XCI+Q291bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1jZW50ZXIgdy0yMFwiPkNvdW50w5dBbXQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1yaWdodCB3LTIwXCI+VG90YWw8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1jZW50ZXIgdy0xNlwiPkJpbGxzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlJlbWFya3M8L3RoPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtWyNjNGM2ZDNdXCI+XG4gICAgICAgICAgICAgICAgICB7dGFibGVJdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbS5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtY2VudGVyXCI+e2l0ZW0uc05vfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPntpdGVtLmNhdGVnb3J5fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdXCI+e2l0ZW0uZGVzY3JpcHRpb259PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlci1yIGJvcmRlci1bI2M0YzZkM10gdGV4dC1jZW50ZXJcIj57aXRlbS5jb3VudH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LWNlbnRlclwiPntpdGVtLmNvdW50QW1vdW50fTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtcmlnaHQgZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS50b3RhbC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMiBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iaWxsVXJsID8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzEzNzMzM10gZm9udC1ib2xkIHRleHQtWzExcHhdXCI+QXR0YWNoZWQ8L3NwYW4+IDogJ+KAlCd9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIHRleHQtWyM3NDc3ODNdXCI+e2l0ZW0ucmVtYXJrc308L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctWyNkYWUyZmZdIGZvbnQtZXh0cmFib2xkIHRleHQtWyMwMDE5NDddXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs1fSBjbGFzc05hbWU9XCJwLTIuNSBib3JkZXItciBib3JkZXItWyNjNGM2ZDNdIHRleHQtcmlnaHQgdGV4dC1bMTNweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICBHcmFuZCBUb3RhbFxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yLjUgYm9yZGVyLXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyB0ZXh0LVsxNHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKCuXtncmFuZFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXsyfSBjbGFzc05hbWU9XCJwLTIuNSBiZy1bI2RhZTJmZl1cIj48L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgICAgICAgIHsvKiBTaWduYXR1cmVzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTggZ3JpZCBncmlkLWNvbHMtMiBnYXAtOCB0ZXh0LWNlbnRlciB0ZXh0LVsxMnB4XVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1bIzAwMDAwMF0gcHQtMS41IGZvbnQtYm9sZFwiPkNvb3JkaW5hdG9yPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyM3NDc3ODNdXCI+e3N0YXRlbWVudE1ldGEuc3BvY05hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLVsjMDAwMDAwXSBwdC0xLjUgZm9udC1ib2xkXCI+Q2x1c3RlciBBZG1pbjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNzQ3NzgzXVwiPntzdGF0ZW1lbnRNZXRhLmZpbmFuY2VyTmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctWyNmYWY4ZmZdIGJvcmRlci10IGJvcmRlci1bI2M0YzZkM10gZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0Z1bGxTdGF0ZW1lbnRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC1bMTIuNXB4XSBmb250LWJvbGQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ2xvc2UgU3RhdGVtZW50XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cblxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0ZpbmFuY2VTdGF0ZW1lbnRWaWV3LnRzeCJ9