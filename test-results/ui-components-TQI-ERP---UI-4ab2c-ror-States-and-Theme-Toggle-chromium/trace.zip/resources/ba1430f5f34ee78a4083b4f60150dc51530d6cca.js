import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\LottieIllustration.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const LottieIllustration = ({
  type,
  className = "",
  size = 64
}) => {
  if (type === "empty-notifications") {
    return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center justify-center ${className}`, children: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "text-muted-foreground/60 transition-colors",
        children: [
          /* @__PURE__ */ jsxDEV("path", { d: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
            lineNumber: 28,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "M10.3 21a1.94 1.94 0 0 0 3.4 0" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
            lineNumber: 29,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("circle", { cx: "18", cy: "6", r: "2", className: "fill-primary stroke-background stroke-2" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
            lineNumber: 30,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
        lineNumber: 17,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
      lineNumber: 16,
      columnNumber: 7
    }, this);
  }
  if (type === "empty-approvals") {
    return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center justify-center ${className}`, children: /* @__PURE__ */ jsxDEV(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "text-emerald-500/80 transition-colors",
        children: [
          /* @__PURE__ */ jsxDEV("path", { d: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
            lineNumber: 50,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("path", { d: "m9 12 2 2 4-4" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
            lineNumber: 51,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
        lineNumber: 39,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center justify-center ${className}`, children: /* @__PURE__ */ jsxDEV(
    "svg",
    {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      className: "text-muted-foreground/60 transition-colors",
      children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: "12", cy: "12", r: "10" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
          lineNumber: 70,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "8", x2: "12", y2: "12" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
          lineNumber: 71,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
          lineNumber: 72,
          columnNumber: 9
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
      lineNumber: 59,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
};
_c = LottieIllustration;
var _c;
$RefreshReg$(_c, "LottieIllustration");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LottieIllustration.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJVO0FBbkJILGFBQU1BLHFCQUF3REEsQ0FBQztBQUFBLEVBQ3BFQztBQUFBQSxFQUNBQyxZQUFZO0FBQUEsRUFDWkMsT0FBTztBQUNULE1BQU07QUFDSixNQUFJRixTQUFTLHVCQUF1QjtBQUNsQyxXQUNFLHVCQUFDLFNBQUksV0FBVyxvQ0FBb0NDLFNBQVMsSUFDM0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9DO0FBQUFBLFFBQ1AsUUFBUUE7QUFBQUEsUUFDUixTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxRQUFPO0FBQUEsUUFDUCxhQUFZO0FBQUEsUUFDWixlQUFjO0FBQUEsUUFDZCxnQkFBZTtBQUFBLFFBQ2YsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxVQUFLLEdBQUUsK0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxVQUFLLEdBQUUsb0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0M7QUFBQSxVQUN4Qyx1QkFBQyxZQUFPLElBQUcsTUFBSyxJQUFHLEtBQUksR0FBRSxLQUFJLFdBQVUsNkNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUE7QUFBQTtBQUFBLE1BYmxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLEVBRUo7QUFFQSxNQUFJRixTQUFTLG1CQUFtQjtBQUM5QixXQUNFLHVCQUFDLFNBQUksV0FBVyxvQ0FBb0NDLFNBQVMsSUFDM0Q7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9DO0FBQUFBLFFBQ1AsUUFBUUE7QUFBQUEsUUFDUixTQUFRO0FBQUEsUUFDUixNQUFLO0FBQUEsUUFDTCxRQUFPO0FBQUEsUUFDUCxhQUFZO0FBQUEsUUFDWixlQUFjO0FBQUEsUUFDZCxnQkFBZTtBQUFBLFFBQ2YsV0FBVTtBQUFBLFFBRVY7QUFBQSxpQ0FBQyxVQUFLLEdBQUUsOEVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRix1QkFBQyxVQUFLLEdBQUUsbUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQTtBQUFBO0FBQUEsTUFaekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVcsb0NBQW9DRCxTQUFTLElBQzNEO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFPQztBQUFBQSxNQUNQLFFBQVFBO0FBQUFBLE1BQ1IsU0FBUTtBQUFBLE1BQ1IsTUFBSztBQUFBLE1BQ0wsUUFBTztBQUFBLE1BQ1AsYUFBWTtBQUFBLE1BQ1osZUFBYztBQUFBLE1BQ2QsZ0JBQWU7QUFBQSxNQUNmLFdBQVU7QUFBQSxNQUVWO0FBQUEsK0JBQUMsWUFBTyxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsUUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQzlCLHVCQUFDLFVBQUssSUFBRyxNQUFLLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsVUFBSyxJQUFHLE1BQUssSUFBRyxNQUFLLElBQUcsU0FBUSxJQUFHLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQTtBQUFBO0FBQUEsSUFiMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBRUMsS0FuRVdKO0FBQXFELElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxvdHRpZUlsbHVzdHJhdGlvbiIsInR5cGUiLCJjbGFzc05hbWUiLCJzaXplIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTG90dGllSWxsdXN0cmF0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgTG90dGllSWxsdXN0cmF0aW9uUHJvcHMge1xuICB0eXBlOiAnZW1wdHktbm90aWZpY2F0aW9ucycgfCAnZW1wdHktYXBwcm92YWxzJyB8ICdhbmFseXRpY3MnIHwgJ2ZpbmFuY2UnIHwgJ3N0dWRlbnRzJztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzaXplPzogbnVtYmVyO1xufVxuXG5leHBvcnQgY29uc3QgTG90dGllSWxsdXN0cmF0aW9uOiBSZWFjdC5GQzxMb3R0aWVJbGx1c3RyYXRpb25Qcm9wcz4gPSAoe1xuICB0eXBlLFxuICBjbGFzc05hbWUgPSAnJyxcbiAgc2l6ZSA9IDY0LFxufSkgPT4ge1xuICBpZiAodHlwZSA9PT0gJ2VtcHR5LW5vdGlmaWNhdGlvbnMnKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtjbGFzc05hbWV9YH0+XG4gICAgICAgIDxzdmdcbiAgICAgICAgICB3aWR0aD17c2l6ZX1cbiAgICAgICAgICBoZWlnaHQ9e3NpemV9XG4gICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjVcIlxuICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kLzYwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxwYXRoIGQ9XCJNNiA4YTYgNiAwIDAgMSAxMiAwYzAgNyAzIDkgMyA5SDNzMy0yIDMtOVwiIC8+XG4gICAgICAgICAgPHBhdGggZD1cIk0xMC4zIDIxYTEuOTQgMS45NCAwIDAgMCAzLjQgMFwiIC8+XG4gICAgICAgICAgPGNpcmNsZSBjeD1cIjE4XCIgY3k9XCI2XCIgcj1cIjJcIiBjbGFzc05hbWU9XCJmaWxsLXByaW1hcnkgc3Ryb2tlLWJhY2tncm91bmQgc3Ryb2tlLTJcIiAvPlxuICAgICAgICA8L3N2Zz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAodHlwZSA9PT0gJ2VtcHR5LWFwcHJvdmFscycpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciAke2NsYXNzTmFtZX1gfT5cbiAgICAgICAgPHN2Z1xuICAgICAgICAgIHdpZHRoPXtzaXplfVxuICAgICAgICAgIGhlaWdodD17c2l6ZX1cbiAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXG4gICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwLzgwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxwYXRoIGQ9XCJNMTIgMjJjNS41MjMgMCAxMC00LjQ3NyAxMC0xMFMxNy41MjMgMiAxMiAyIDIgNi40NzcgMiAxMnM0LjQ3NyAxMCAxMCAxMHpcIiAvPlxuICAgICAgICAgIDxwYXRoIGQ9XCJtOSAxMiAyIDIgNC00XCIgLz5cbiAgICAgICAgPC9zdmc+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICR7Y2xhc3NOYW1lfWB9PlxuICAgICAgPHN2Z1xuICAgICAgICB3aWR0aD17c2l6ZX1cbiAgICAgICAgaGVpZ2h0PXtzaXplfVxuICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXG4gICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmQvNjAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgPlxuICAgICAgICA8Y2lyY2xlIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjEwXCIgLz5cbiAgICAgICAgPGxpbmUgeDE9XCIxMlwiIHkxPVwiOFwiIHgyPVwiMTJcIiB5Mj1cIjEyXCIgLz5cbiAgICAgICAgPGxpbmUgeDE9XCIxMlwiIHkxPVwiMTZcIiB4Mj1cIjEyLjAxXCIgeTI9XCIxNlwiIC8+XG4gICAgICA8L3N2Zz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG90dGllSWxsdXN0cmF0aW9uLnRzeCJ9