import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SessionReportView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import { FileText, Users, ClipboardList, AlertTriangle, MessageSquare, Save, Send, Eye, XCircle, Search } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const SessionReportView = ({
  sessionReports,
  sessions,
  clusters,
  currentUserRole,
  currentUserClusterId,
  onSaveReport,
  onDeleteReport
}) => {
  _s();
  const isSuperAdmin = currentUserRole === "Super Admin";
  const [activeTab, setActiveTab] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [showFormModal, setShowFormModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    sessionId: "",
    sessionSummary: "",
    studentCount: 0,
    attendanceSummary: "",
    activities: "",
    issues: "",
    remarks: ""
  });
  const clusterSessions = useMemo(() => {
    return isSuperAdmin ? sessions : sessions.filter((s) => s.clusterId === currentUserClusterId);
  }, [sessions, isSuperAdmin, currentUserClusterId]);
  const visibleReports = useMemo(() => {
    let filtered = sessionReports;
    if (!isSuperAdmin) {
      filtered = filtered.filter((r) => r.clusterId === currentUserClusterId);
    }
    if (activeTab !== "All") {
      filtered = filtered.filter((r) => r.status === activeTab);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter((r) => {
        const session = sessions.find((s) => s.id === r.sessionId);
        return session?.name.toLowerCase().includes(q) || r.clusterName?.toLowerCase().includes(q);
      });
    }
    return filtered;
  }, [sessionReports, currentUserClusterId, isSuperAdmin, activeTab, searchQuery, sessions]);
  const handleOpenForm = (report) => {
    if (report) {
      setFormData(report);
    } else {
      setFormData({
        sessionId: "",
        sessionSummary: "",
        studentCount: 0,
        attendanceSummary: "",
        activities: "",
        issues: "",
        remarks: ""
      });
    }
    setShowFormModal(true);
  };
  const handleSave = async (status) => {
    if (!formData.sessionId) return;
    setIsSubmitting(true);
    try {
      await onSaveReport({ ...formData, status });
      setShowFormModal(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const getStatusBadge = (status) => {
    switch (status) {
      case "DRAFT":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300", children: "Draft" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 107,
          columnNumber: 16
        }, this);
      case "SUBMITTED":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300", children: "Submitted" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 109,
          columnNumber: 16
        }, this);
      case "APPROVED":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300", children: "Approved" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 111,
          columnNumber: 16
        }, this);
      default:
        return null;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 dark:text-white flex items-center gap-2", children: [
          "Session Reports",
          /* @__PURE__ */ jsxDEV("span", { className: "bg-brand-100 text-brand-800 text-sm font-medium px-2.5 py-0.5 rounded-full dark:bg-brand-900/30 dark:text-brand-300", children: sessionReports.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 123,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 dark:text-gray-400 mt-1", children: "Detailed qualitative session reporting" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => handleOpenForm(),
          className: "flex items-center gap-2 bg-brand-500 hover:bg-brand-600 text-white px-4 py-2 rounded-lg transition-colors font-medium",
          children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 134,
              columnNumber: 11
            }, this),
            "New Report"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 130,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 119,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-gray-200 dark:border-gray-700 flex flex-col md:flex-row justify-between items-start md:items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex space-x-2 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto", children: ["All", "DRAFT", "SUBMITTED", "APPROVED"].map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab(tab),
              className: `px-4 py-2 text-sm font-medium rounded-lg whitespace-nowrap transition-colors ${activeTab === tab ? "bg-brand-50 text-brand-700 dark:bg-brand-900/20 dark:text-brand-300" : "text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700"}`,
              children: tab === "All" ? "All Reports" : tab.charAt(0) + tab.slice(1).toLowerCase()
            },
            tab,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 143,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 141,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative w-full md:w-64", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 158,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "Search session or cluster...",
              value: searchQuery,
              onChange: (e) => setSearchQuery(e.target.value),
              className: "w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 159,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 p-6", children: [
        visibleReports.map((report) => {
          const session = sessions.find((s) => s.id === report.sessionId);
          return /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-5 hover:shadow-md transition-shadow", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-3", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-900 dark:text-white truncate", title: session?.name || "Unknown Session", children: session?.name || "Unknown Session" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 176,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400 mt-1", children: [
                  "Day ",
                  report.dayNumber || session?.dayNumber,
                  " ",
                  isSuperAdmin && `• ${report.clusterName}`
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 179,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 175,
                columnNumber: 19
              }, this),
              getStatusBadge(report.status)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 174,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 dark:text-gray-300 line-clamp-3 mb-4 h-15", children: report.sessionSummary || /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 italic", children: "No summary provided" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 187,
              columnNumber: 45
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 186,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-4 border-t border-gray-100 dark:border-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400", children: [
                /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 192,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  report.studentCount,
                  " Students"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 193,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 191,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setSelectedReport(report);
                      setShowViewModal(true);
                    },
                    className: "p-1.5 text-gray-500 hover:text-brand-600 dark:text-gray-400 dark:hover:text-brand-400 rounded-md hover:bg-brand-50 dark:hover:bg-brand-900/30 transition-colors",
                    title: "View Details",
                    children: /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                      lineNumber: 202,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                    lineNumber: 197,
                    columnNumber: 21
                  },
                  this
                ),
                !isSuperAdmin && report.status === "DRAFT" && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleOpenForm(report),
                    className: "text-xs font-medium text-brand-600 hover:text-brand-700 dark:text-brand-400 dark:hover:text-brand-300 px-2 py-1",
                    children: "Edit"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                    lineNumber: 205,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 196,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 190,
              columnNumber: 17
            }, this)
          ] }, report.id, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 173,
            columnNumber: 15
          }, this);
        }),
        visibleReports.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-12 text-center text-gray-500 dark:text-gray-400", children: "No session reports found matching your filters." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 218,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 169,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 139,
      columnNumber: 7
    }, this),
    showFormModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-2xl my-8 overflow-hidden flex flex-col max-h-[90vh]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center shrink-0", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 dark:text-white", children: formData.id ? "Edit Session Report" : "New Session Report" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 230,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowFormModal(false), className: "text-gray-400 hover:text-gray-500", children: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 234,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 233,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 229,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Session" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 240,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: formData.sessionId,
              onValueChange: (val) => setFormData({ ...formData, sessionId: val }),
              disabled: !!formData.id,
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 disabled:opacity-60", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select a session" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 247,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 246,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: clusterSessions.map(
                  (s) => /* @__PURE__ */ jsxDEV(SelectItem, { value: s.id, children: [
                    s.name,
                    " (Day ",
                    s.dayNumber,
                    ")"
                  ] }, s.id, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                    lineNumber: 251,
                    columnNumber: 19
                  }, this)
                ) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                  lineNumber: 249,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 241,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 239,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 261,
              columnNumber: 19
            }, this),
            " Session Summary"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 260,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: formData.sessionSummary,
              onChange: (e) => setFormData({ ...formData, sessionSummary: e.target.value }),
              rows: 3,
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              placeholder: "Provide a general summary of how the session went...",
              required: true
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 263,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 259,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 276,
                columnNumber: 21
              }, this),
              " Student Count"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 275,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                min: "0",
                value: formData.studentCount,
                onChange: (e) => setFormData({ ...formData, studentCount: parseInt(e.target.value) || 0 }),
                className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
                required: true
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 278,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 274,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(ClipboardList, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 289,
                columnNumber: 21
              }, this),
              " Attendance Summary"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 288,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                value: formData.attendanceSummary,
                onChange: (e) => setFormData({ ...formData, attendanceSummary: e.target.value }),
                rows: 2,
                className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
                placeholder: "Brief note on attendance..."
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 291,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 287,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 273,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 303,
              columnNumber: 19
            }, this),
            " Activities Conducted"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 302,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: formData.activities,
              onChange: (e) => setFormData({ ...formData, activities: e.target.value }),
              rows: 3,
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              placeholder: "Detail the activities carried out..."
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 305,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 301,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5 text-amber-600 dark:text-amber-500", children: [
            /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 316,
              columnNumber: 19
            }, this),
            " Issues / Challenges"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 315,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: formData.issues,
              onChange: (e) => setFormData({ ...formData, issues: e.target.value }),
              rows: 2,
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              placeholder: "Note any challenges faced during the session..."
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 318,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 314,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(MessageSquare, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 329,
              columnNumber: 19
            }, this),
            " General Remarks"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 328,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: formData.remarks,
              onChange: (e) => setFormData({ ...formData, remarks: e.target.value }),
              rows: 2,
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              placeholder: "Any additional remarks..."
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 331,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 327,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 238,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex justify-end gap-3 shrink-0", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowFormModal(false),
            className: "px-4 py-2 text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg dark:text-gray-300 dark:bg-gray-700 dark:border-gray-600 dark:hover:bg-gray-600 transition-colors",
            disabled: isSubmitting,
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 342,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleSave("DRAFT"),
            disabled: isSubmitting || !formData.sessionId,
            className: "px-4 py-2 text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg dark:text-gray-200 dark:bg-gray-600 dark:hover:bg-gray-500 transition-colors flex items-center gap-2 disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxDEV(Save, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 355,
                columnNumber: 17
              }, this),
              "Save Draft"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 350,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleSave("SUBMITTED"),
            disabled: isSubmitting || !formData.sessionId,
            className: "px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxDEV(Send, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 363,
                columnNumber: 17
              }, this),
              "Submit Report"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 358,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 341,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 228,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 227,
      columnNumber: 7
    }, this),
    showViewModal && selectedReport && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-2xl my-8 overflow-hidden flex flex-col max-h-[90vh]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center shrink-0", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-3", children: [
          "Report Details",
          getStatusBadge(selectedReport.status)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 376,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowViewModal(false), className: "text-gray-400 hover:text-gray-500", children: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 381,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 380,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 375,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 text-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-medium text-gray-500 dark:text-gray-400", children: "Session" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 388,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block mt-1 text-gray-900 dark:text-gray-200 font-medium", children: sessions.find((s) => s.id === selectedReport.sessionId)?.name || "Unknown" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 389,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 387,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "block font-medium text-gray-500 dark:text-gray-400", children: "Cluster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 394,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "block mt-1 text-gray-900 dark:text-gray-200", children: selectedReport.clusterName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 395,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 393,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 386,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 401,
              columnNumber: 19
            }, this),
            " Session Summary"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 400,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-700 text-sm text-gray-800 dark:text-gray-300 whitespace-pre-wrap", children: selectedReport.sessionSummary }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 403,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 399,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
              /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 411,
                columnNumber: 21
              }, this),
              " Student Count"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 410,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-semibold text-gray-900 dark:text-white px-3", children: selectedReport.studentCount }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 413,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 409,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
              /* @__PURE__ */ jsxDEV(ClipboardList, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
                lineNumber: 419,
                columnNumber: 21
              }, this),
              " Attendance Summary"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 418,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-800 dark:text-gray-300 px-3", children: selectedReport.attendanceSummary || "-" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 421,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 417,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 408,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 429,
              columnNumber: 19
            }, this),
            " Activities"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 428,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-700 text-sm text-gray-800 dark:text-gray-300 whitespace-pre-wrap", children: selectedReport.activities || "-" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 431,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 427,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
            /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 438,
              columnNumber: 19
            }, this),
            " Issues"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 437,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-100 dark:border-red-900/30 text-sm text-gray-800 dark:text-gray-300 whitespace-pre-wrap", children: selectedReport.issues || "-" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 440,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 436,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center gap-1.5 mb-2", children: [
            /* @__PURE__ */ jsxDEV(MessageSquare, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
              lineNumber: 447,
              columnNumber: 19
            }, this),
            " Remarks"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 446,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-100 dark:border-gray-700 text-sm text-gray-800 dark:text-gray-300 whitespace-pre-wrap", children: selectedReport.remarks || "-" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
            lineNumber: 449,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 445,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 385,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex justify-end shrink-0", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setShowViewModal(false),
          className: "px-4 py-2 text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg dark:text-gray-300 dark:bg-gray-700 dark:border-gray-600 dark:hover:bg-gray-600 transition-colors",
          children: "Close"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
          lineNumber: 456,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
        lineNumber: 455,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 374,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
      lineNumber: 373,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx",
    lineNumber: 118,
    columnNumber: 5
  }, this);
};
_s(SessionReportView, "n2IcpgMwSKf/+uvVOEmOWN09BVc=");
_c = SessionReportView;
export default SessionReportView;
var _c;
$RefreshReg$(_c, "SessionReportView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionReportView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEdlOztBQTFHZixTQUFnQkEsVUFBVUMsZUFBZTtBQUN6QyxTQUFTQyxVQUFVQyxPQUFPQyxlQUFlQyxlQUFlQyxlQUFlQyxNQUFNQyxNQUFNQyxLQUFLQyxTQUFTQyxjQUFjO0FBRS9HO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQVlQLE1BQU1DLG9CQUFzREEsQ0FBQztBQUFBLEVBQzNEQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU1DLGVBQWVMLG9CQUFvQjtBQUN6QyxRQUFNLENBQUNNLFdBQVdDLFlBQVksSUFBSTVCLFNBQXFELEtBQUs7QUFDNUYsUUFBTSxDQUFDNkIsYUFBYUMsY0FBYyxJQUFJOUIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQytCLGVBQWVDLGdCQUFnQixJQUFJaEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ2lDLGVBQWVDLGdCQUFnQixJQUFJbEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ21DLGdCQUFnQkMsaUJBQWlCLElBQUlwQyxTQUErQixJQUFJO0FBQy9FLFFBQU0sQ0FBQ3FDLGNBQWNDLGVBQWUsSUFBSXRDLFNBQVMsS0FBSztBQUd0RCxRQUFNLENBQUN1QyxVQUFVQyxXQUFXLElBQUl4QyxTQUFpQztBQUFBLElBQy9EeUMsV0FBVztBQUFBLElBQ1hDLGdCQUFnQjtBQUFBLElBQ2hCQyxjQUFjO0FBQUEsSUFDZEMsbUJBQW1CO0FBQUEsSUFDbkJDLFlBQVk7QUFBQSxJQUNaQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLGtCQUFrQi9DLFFBQVEsTUFBTTtBQUNwQyxXQUFPeUIsZUFBZVAsV0FBV0EsU0FBUzhCLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRUMsY0FBYzdCLG9CQUFvQjtBQUFBLEVBQzVGLEdBQUcsQ0FBQ0gsVUFBVU8sY0FBY0osb0JBQW9CLENBQUM7QUFFakQsUUFBTThCLGlCQUFpQm5ELFFBQVEsTUFBTTtBQUNuQyxRQUFJb0QsV0FBV25DO0FBQ2YsUUFBSSxDQUFDUSxjQUFjO0FBQ2pCMkIsaUJBQVdBLFNBQVNKLE9BQU8sQ0FBQUssTUFBS0EsRUFBRUgsY0FBYzdCLG9CQUFvQjtBQUFBLElBQ3RFO0FBRUEsUUFBSUssY0FBYyxPQUFPO0FBQ3ZCMEIsaUJBQVdBLFNBQVNKLE9BQU8sQ0FBQUssTUFBS0EsRUFBRUMsV0FBVzVCLFNBQVM7QUFBQSxJQUN4RDtBQUVBLFFBQUlFLGFBQWE7QUFDZixZQUFNMkIsSUFBSTNCLFlBQVk0QixZQUFZO0FBQ2xDSixpQkFBV0EsU0FBU0osT0FBTyxDQUFBSyxNQUFLO0FBQzlCLGNBQU1JLFVBQVV2QyxTQUFTd0MsS0FBSyxDQUFBVCxNQUFLQSxFQUFFVSxPQUFPTixFQUFFYixTQUFTO0FBQ3ZELGVBQU9pQixTQUFTRyxLQUFLSixZQUFZLEVBQUVLLFNBQVNOLENBQUMsS0FBS0YsRUFBRVMsYUFBYU4sWUFBWSxFQUFFSyxTQUFTTixDQUFDO0FBQUEsTUFDM0YsQ0FBQztBQUFBLElBQ0g7QUFDQSxXQUFPSDtBQUFBQSxFQUNULEdBQUcsQ0FBQ25DLGdCQUFnQkksc0JBQXNCSSxjQUFjQyxXQUFXRSxhQUFhVixRQUFRLENBQUM7QUFFekYsUUFBTTZDLGlCQUFpQkEsQ0FBQ0MsV0FBMkI7QUFDakQsUUFBSUEsUUFBUTtBQUNWekIsa0JBQVl5QixNQUFNO0FBQUEsSUFDcEIsT0FBTztBQUNMekIsa0JBQVk7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWEMsZ0JBQWdCO0FBQUEsUUFDaEJDLGNBQWM7QUFBQSxRQUNkQyxtQkFBbUI7QUFBQSxRQUNuQkMsWUFBWTtBQUFBLFFBQ1pDLFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBQUEsSUFDSDtBQUNBZixxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTWtDLGFBQWEsT0FBT1gsV0FBa0M7QUFDMUQsUUFBSSxDQUFDaEIsU0FBU0UsVUFBVztBQUN6Qkgsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU1mLGFBQWEsRUFBRSxHQUFHZ0IsVUFBVWdCLE9BQU8sQ0FBQztBQUMxQ3ZCLHVCQUFpQixLQUFLO0FBQUEsSUFDeEIsU0FBU21DLE9BQU87QUFDZEMsY0FBUUQsTUFBTUEsS0FBSztBQUFBLElBQ3JCLFVBQUM7QUFDQzdCLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTStCLGlCQUFpQkEsQ0FBQ2QsV0FBbUI7QUFDekMsWUFBUUEsUUFBTTtBQUFBLE1BQ1osS0FBSztBQUNILGVBQU8sdUJBQUMsVUFBSyxXQUFVLHlJQUF3SSxxQkFBeEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SjtBQUFBLE1BQ3RLLEtBQUs7QUFDSCxlQUFPLHVCQUFDLFVBQUssV0FBVSw0SUFBMkkseUJBQTNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0s7QUFBQSxNQUM3SyxLQUFLO0FBQ0gsZUFBTyx1QkFBQyxVQUFLLFdBQVUsZ0pBQStJLHdCQUEvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVLO0FBQUEsTUFDaEw7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw0RUFBMEU7QUFBQTtBQUFBLFVBRXRGLHVCQUFDLFVBQUssV0FBVSx1SEFDYnJDLHlCQUFlb0QsVUFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQWdELHNEQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1HO0FBQUEsV0FQckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNTixlQUFlO0FBQUEsVUFDOUIsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwrR0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpSUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxnRUFDWixXQUFDLE9BQU8sU0FBUyxhQUFhLFVBQVUsRUFBRU87QUFBQUEsVUFBSSxDQUFBQyxRQUM3QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNNUMsYUFBYTRDLEdBQVU7QUFBQSxjQUN0QyxXQUFXLGdGQUNUN0MsY0FBYzZDLE1BQ1Ysd0VBQ0EsMkVBQTJFO0FBQUEsY0FHaEZBLGtCQUFRLFFBQVEsZ0JBQWdCQSxJQUFJQyxPQUFPLENBQUMsSUFBSUQsSUFBSUUsTUFBTSxDQUFDLEVBQUVqQixZQUFZO0FBQUE7QUFBQSxZQVJyRWU7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsOEVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRGO0FBQUEsVUFDNUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU8zQztBQUFBQSxjQUNQLFVBQVUsQ0FBQzhDLE1BQU03QyxlQUFlNkMsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGNBQzlDLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS29MO0FBQUEsYUFQdEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNaekI7QUFBQUEsdUJBQWVtQixJQUFJLENBQUNOLFdBQVc7QUFDOUIsZ0JBQU1QLFVBQVV2QyxTQUFTd0MsS0FBSyxDQUFBVCxNQUFLQSxFQUFFVSxPQUFPSyxPQUFPeEIsU0FBUztBQUM1RCxpQkFDRSx1QkFBQyxTQUFvQixXQUFVLDBIQUM3QjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsd0RBQXVELE9BQU9pQixTQUFTRyxRQUFRLG1CQUMxRkgsbUJBQVNHLFFBQVEscUJBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsaURBQStDO0FBQUE7QUFBQSxrQkFDdkRJLE9BQU9hLGFBQWFwQixTQUFTb0I7QUFBQUEsa0JBQVU7QUFBQSxrQkFBRXBELGdCQUFnQixLQUFLdUMsT0FBT0YsV0FBVztBQUFBLHFCQUR2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0NNLGVBQWVKLE9BQU9WLE1BQU07QUFBQSxpQkFUL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsT0FBRSxXQUFVLG1FQUNWVSxpQkFBT3ZCLGtCQUFrQix1QkFBQyxVQUFLLFdBQVUsd0JBQXVCLG1DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRCxLQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEI7QUFBQSxnQkFDMUIsdUJBQUMsVUFBTXVCO0FBQUFBLHlCQUFPdEI7QUFBQUEsa0JBQWE7QUFBQSxxQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQSxtQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU07QUFBRVAsd0NBQWtCNkIsTUFBTTtBQUFHL0IsdUNBQWlCLElBQUk7QUFBQSxvQkFBRztBQUFBLG9CQUNwRSxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdCO0FBQUE7QUFBQSxrQkFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0MsQ0FBQ1IsZ0JBQWdCdUMsT0FBT1YsV0FBVyxXQUNsQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1TLGVBQWVDLE1BQU07QUFBQSxvQkFDcEMsV0FBVTtBQUFBLG9CQUFpSDtBQUFBO0FBQUEsa0JBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsZUF4Q1FBLE9BQU9MLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUNBO0FBQUEsUUFFSixDQUFDO0FBQUEsUUFDQVIsZUFBZWtCLFdBQVcsS0FDekIsdUJBQUMsU0FBSSxXQUFVLG9FQUFrRSwrREFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FuREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFEQTtBQUFBLFNBbkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRkE7QUFBQSxJQUdDdkMsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHdHQUNiLGlDQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnR0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx1REFDWFEsbUJBQVNxQixLQUFLLHdCQUF3Qix3QkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTTVCLGlCQUFpQixLQUFLLEdBQUcsV0FBVSxxQ0FDeEQsaUNBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbUVBQWtFLHVCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLFVBQzFGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPTyxTQUFTRTtBQUFBQSxjQUNoQixlQUFlLENBQUNzQyxRQUFRdkMsWUFBWSxFQUFFLEdBQUdELFVBQVVFLFdBQVdzQyxJQUFJLENBQUM7QUFBQSxjQUNuRSxVQUFVLENBQUMsQ0FBQ3hDLFNBQVNxQjtBQUFBQSxjQUVyQjtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsNEdBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNFWiwwQkFBZ0J1QjtBQUFBQSxrQkFBSSxDQUFDckIsTUFDcEIsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRVUsSUFDN0JWO0FBQUFBLHNCQUFFVztBQUFBQSxvQkFBSztBQUFBLG9CQUFPWCxFQUFFNEI7QUFBQUEsb0JBQVU7QUFBQSx1QkFEWjVCLEVBQUVVLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQTtBQUFBO0FBQUEsWUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNkZBQ2Y7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUEsZUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9yQixTQUFTRztBQUFBQSxjQUNoQixVQUFVLENBQUNpQyxNQUFNbkMsWUFBWSxFQUFDLEdBQUdELFVBQVVHLGdCQUFnQmlDLEVBQUVDLE9BQU9DLE1BQUssQ0FBQztBQUFBLGNBQzFFLE1BQU07QUFBQSxjQUNOLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLFVBQVE7QUFBQTtBQUFBLFlBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVU7QUFBQSxhQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2RkFDZjtBQUFBLHFDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQUc7QUFBQSxpQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsS0FBSTtBQUFBLGdCQUNKLE9BQU90QyxTQUFTSTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDZ0MsTUFBTW5DLFlBQVksRUFBQyxHQUFHRCxVQUFVSSxjQUFjcUMsU0FBU0wsRUFBRUMsT0FBT0MsS0FBSyxLQUFLLEVBQUMsQ0FBQztBQUFBLGdCQUN2RixXQUFVO0FBQUEsZ0JBQ1YsVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLGVBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2RkFDZjtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0M7QUFBQSxjQUFHO0FBQUEsaUJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT3RDLFNBQVNLO0FBQUFBLGdCQUNoQixVQUFVLENBQUMrQixNQUFNbkMsWUFBWSxFQUFDLEdBQUdELFVBQVVLLG1CQUFtQitCLEVBQUVDLE9BQU9DLE1BQUssQ0FBQztBQUFBLGdCQUM3RSxNQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLGFBQVk7QUFBQTtBQUFBLGNBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSzJDO0FBQUEsZUFUN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNkZBQ2Y7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUEsZUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU90QyxTQUFTTTtBQUFBQSxjQUNoQixVQUFVLENBQUM4QixNQUFNbkMsWUFBWSxFQUFDLEdBQUdELFVBQVVNLFlBQVk4QixFQUFFQyxPQUFPQyxNQUFLLENBQUM7QUFBQSxjQUN0RSxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtvRDtBQUFBLGFBVHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnSUFDZjtBQUFBLG1DQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFHO0FBQUEsZUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU90QyxTQUFTTztBQUFBQSxjQUNoQixVQUFVLENBQUM2QixNQUFNbkMsWUFBWSxFQUFDLEdBQUdELFVBQVVPLFFBQVE2QixFQUFFQyxPQUFPQyxNQUFLLENBQUM7QUFBQSxjQUNsRSxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUsrRDtBQUFBLGFBVGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw2RkFDZjtBQUFBLG1DQUFDLGlCQUFjLFdBQVUsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFHO0FBQUEsZUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU90QyxTQUFTUTtBQUFBQSxjQUNoQixVQUFVLENBQUM0QixNQUFNbkMsWUFBWSxFQUFDLEdBQUdELFVBQVVRLFNBQVM0QixFQUFFQyxPQUFPQyxNQUFLLENBQUM7QUFBQSxjQUNuRSxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt5QztBQUFBLGFBVDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBcEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU03QyxpQkFBaUIsS0FBSztBQUFBLFlBQ3JDLFdBQVU7QUFBQSxZQUNWLFVBQVVLO0FBQUFBLFlBQWE7QUFBQTtBQUFBLFVBSnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNNkIsV0FBVyxPQUFPO0FBQUEsWUFDakMsVUFBVTdCLGdCQUFnQixDQUFDRSxTQUFTRTtBQUFBQSxZQUNwQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNeUIsV0FBVyxXQUFXO0FBQUEsWUFDckMsVUFBVTdCLGdCQUFnQixDQUFDRSxTQUFTRTtBQUFBQSxZQUNwQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLFNBMUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EySUEsS0E1SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZJQTtBQUFBLElBSURSLGlCQUFpQkUsa0JBQ2hCLHVCQUFDLFNBQUksV0FBVSx3R0FDYixpQ0FBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0dBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsK0VBQTZFO0FBQUE7QUFBQSxVQUV4RmtDLGVBQWVsQyxlQUFlb0IsTUFBTTtBQUFBLGFBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1yQixpQkFBaUIsS0FBSyxHQUFHLFdBQVUscUNBQ3hELGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNEQUFxRCx1QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUM1RSx1QkFBQyxVQUFLLFdBQVUsMkRBQ2JmLG1CQUFTd0MsS0FBSyxDQUFBVCxNQUFLQSxFQUFFVSxPQUFPekIsZUFBZU0sU0FBUyxHQUFHb0IsUUFBUSxhQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHNEQUFxRCx1QkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUM1RSx1QkFBQyxVQUFLLFdBQVUsK0NBQStDMUIseUJBQWU0QixlQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBLGVBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSx1RkFDWjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQUc7QUFBQSxlQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEpBQ1o1Qix5QkFBZU8sa0JBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx1RkFDWjtBQUFBLHFDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQUc7QUFBQSxpQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDREQUNaUCx5QkFBZVEsZ0JBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdUZBQ1o7QUFBQSxxQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FBRztBQUFBLGlCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsaURBQ1pSLHlCQUFlUyxxQkFBcUIsT0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsdUZBQ1o7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFHO0FBQUEsZUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBKQUNaVCx5QkFBZVUsY0FBYyxPQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsdUZBQ1o7QUFBQSxtQ0FBQyxpQkFBYyxXQUFVLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFBRztBQUFBLGVBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5SkFDWlYseUJBQWVXLFVBQVUsT0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVGQUNaO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSxhQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQUc7QUFBQSxlQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsMEpBQ1pYLHlCQUFlWSxXQUFXLE9BRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw4R0FDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNYixpQkFBaUIsS0FBSztBQUFBLFVBQ3JDLFdBQVU7QUFBQSxVQUF1TDtBQUFBO0FBQUEsUUFGbk07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUZBLEtBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyRkE7QUFBQSxPQTFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNFZBO0FBRUo7QUFBRVQsR0E5YklSLG1CQUFtRDtBQUFBLEtBQW5EQTtBQWdjTixlQUFlQTtBQUFrQixJQUFBZ0U7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VNZW1vIiwiRmlsZVRleHQiLCJVc2VycyIsIkNsaXBib2FyZExpc3QiLCJBbGVydFRyaWFuZ2xlIiwiTWVzc2FnZVNxdWFyZSIsIlNhdmUiLCJTZW5kIiwiRXllIiwiWENpcmNsZSIsIlNlYXJjaCIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiU2Vzc2lvblJlcG9ydFZpZXciLCJzZXNzaW9uUmVwb3J0cyIsInNlc3Npb25zIiwiY2x1c3RlcnMiLCJjdXJyZW50VXNlclJvbGUiLCJjdXJyZW50VXNlckNsdXN0ZXJJZCIsIm9uU2F2ZVJlcG9ydCIsIm9uRGVsZXRlUmVwb3J0IiwiX3MiLCJpc1N1cGVyQWRtaW4iLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5Iiwic2hvd0Zvcm1Nb2RhbCIsInNldFNob3dGb3JtTW9kYWwiLCJzaG93Vmlld01vZGFsIiwic2V0U2hvd1ZpZXdNb2RhbCIsInNlbGVjdGVkUmVwb3J0Iiwic2V0U2VsZWN0ZWRSZXBvcnQiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2Vzc2lvbklkIiwic2Vzc2lvblN1bW1hcnkiLCJzdHVkZW50Q291bnQiLCJhdHRlbmRhbmNlU3VtbWFyeSIsImFjdGl2aXRpZXMiLCJpc3N1ZXMiLCJyZW1hcmtzIiwiY2x1c3RlclNlc3Npb25zIiwiZmlsdGVyIiwicyIsImNsdXN0ZXJJZCIsInZpc2libGVSZXBvcnRzIiwiZmlsdGVyZWQiLCJyIiwic3RhdHVzIiwicSIsInRvTG93ZXJDYXNlIiwic2Vzc2lvbiIsImZpbmQiLCJpZCIsIm5hbWUiLCJpbmNsdWRlcyIsImNsdXN0ZXJOYW1lIiwiaGFuZGxlT3BlbkZvcm0iLCJyZXBvcnQiLCJoYW5kbGVTYXZlIiwiZXJyb3IiLCJjb25zb2xlIiwiZ2V0U3RhdHVzQmFkZ2UiLCJsZW5ndGgiLCJtYXAiLCJ0YWIiLCJjaGFyQXQiLCJzbGljZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImRheU51bWJlciIsInZhbCIsInBhcnNlSW50IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2Vzc2lvblJlcG9ydFZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZpbGVUZXh0LCBVc2VycywgQ2xpcGJvYXJkTGlzdCwgQWxlcnRUcmlhbmdsZSwgTWVzc2FnZVNxdWFyZSwgU2F2ZSwgU2VuZCwgRXllLCBYQ2lyY2xlLCBTZWFyY2ggfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHR5cGUgeyBTZXNzaW9uUmVwb3J0LCBTZXNzaW9uLCBVc2VyUm9sZSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJy4vdWkvc2VsZWN0JztcblxuaW50ZXJmYWNlIFNlc3Npb25SZXBvcnRWaWV3UHJvcHMge1xuICBzZXNzaW9uUmVwb3J0czogU2Vzc2lvblJlcG9ydFtdO1xuICBzZXNzaW9uczogU2Vzc2lvbltdO1xuICBjbHVzdGVyczogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfVtdO1xuICBjdXJyZW50VXNlclJvbGU6IFVzZXJSb2xlO1xuICBjdXJyZW50VXNlckNsdXN0ZXJJZDogc3RyaW5nO1xuICBvblNhdmVSZXBvcnQ6IChyZXBvcnQ6IFBhcnRpYWw8U2Vzc2lvblJlcG9ydD4pID0+IFByb21pc2U8dm9pZD47XG4gIG9uRGVsZXRlUmVwb3J0OiAocmVwb3J0SWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbn1cblxuY29uc3QgU2Vzc2lvblJlcG9ydFZpZXc6IFJlYWN0LkZDPFNlc3Npb25SZXBvcnRWaWV3UHJvcHM+ID0gKHtcbiAgc2Vzc2lvblJlcG9ydHMsXG4gIHNlc3Npb25zLFxuICBjbHVzdGVycyxcbiAgY3VycmVudFVzZXJSb2xlLFxuICBjdXJyZW50VXNlckNsdXN0ZXJJZCxcbiAgb25TYXZlUmVwb3J0LFxuICBvbkRlbGV0ZVJlcG9ydFxufSkgPT4ge1xuICBjb25zdCBpc1N1cGVyQWRtaW4gPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbic7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwnQWxsJyB8ICdEUkFGVCcgfCAnU1VCTUlUVEVEJyB8ICdBUFBST1ZFRCc+KCdBbGwnKTtcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzaG93Rm9ybU1vZGFsLCBzZXRTaG93Rm9ybU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dWaWV3TW9kYWwsIHNldFNob3dWaWV3TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2VsZWN0ZWRSZXBvcnQsIHNldFNlbGVjdGVkUmVwb3J0XSA9IHVzZVN0YXRlPFNlc3Npb25SZXBvcnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBGb3JtIFN0YXRlXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8UGFydGlhbDxTZXNzaW9uUmVwb3J0Pj4oe1xuICAgIHNlc3Npb25JZDogJycsXG4gICAgc2Vzc2lvblN1bW1hcnk6ICcnLFxuICAgIHN0dWRlbnRDb3VudDogMCxcbiAgICBhdHRlbmRhbmNlU3VtbWFyeTogJycsXG4gICAgYWN0aXZpdGllczogJycsXG4gICAgaXNzdWVzOiAnJyxcbiAgICByZW1hcmtzOiAnJyxcbiAgfSk7XG5cbiAgY29uc3QgY2x1c3RlclNlc3Npb25zID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIGlzU3VwZXJBZG1pbiA/IHNlc3Npb25zIDogc2Vzc2lvbnMuZmlsdGVyKHMgPT4gcy5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcbiAgfSwgW3Nlc3Npb25zLCBpc1N1cGVyQWRtaW4sIGN1cnJlbnRVc2VyQ2x1c3RlcklkXSk7XG5cbiAgY29uc3QgdmlzaWJsZVJlcG9ydHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBsZXQgZmlsdGVyZWQgPSBzZXNzaW9uUmVwb3J0cztcbiAgICBpZiAoIWlzU3VwZXJBZG1pbikge1xuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIociA9PiByLmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xuICAgIH1cbiAgICBcbiAgICBpZiAoYWN0aXZlVGFiICE9PSAnQWxsJykge1xuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIociA9PiByLnN0YXR1cyA9PT0gYWN0aXZlVGFiKTtcbiAgICB9XG5cbiAgICBpZiAoc2VhcmNoUXVlcnkpIHtcbiAgICAgIGNvbnN0IHEgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpO1xuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIociA9PiB7XG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSBzZXNzaW9ucy5maW5kKHMgPT4gcy5pZCA9PT0gci5zZXNzaW9uSWQpO1xuICAgICAgICByZXR1cm4gc2Vzc2lvbj8ubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpIHx8IHIuY2x1c3Rlck5hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGZpbHRlcmVkO1xuICB9LCBbc2Vzc2lvblJlcG9ydHMsIGN1cnJlbnRVc2VyQ2x1c3RlcklkLCBpc1N1cGVyQWRtaW4sIGFjdGl2ZVRhYiwgc2VhcmNoUXVlcnksIHNlc3Npb25zXSk7XG5cbiAgY29uc3QgaGFuZGxlT3BlbkZvcm0gPSAocmVwb3J0PzogU2Vzc2lvblJlcG9ydCkgPT4ge1xuICAgIGlmIChyZXBvcnQpIHtcbiAgICAgIHNldEZvcm1EYXRhKHJlcG9ydCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldEZvcm1EYXRhKHtcbiAgICAgICAgc2Vzc2lvbklkOiAnJyxcbiAgICAgICAgc2Vzc2lvblN1bW1hcnk6ICcnLFxuICAgICAgICBzdHVkZW50Q291bnQ6IDAsXG4gICAgICAgIGF0dGVuZGFuY2VTdW1tYXJ5OiAnJyxcbiAgICAgICAgYWN0aXZpdGllczogJycsXG4gICAgICAgIGlzc3VlczogJycsXG4gICAgICAgIHJlbWFya3M6ICcnLFxuICAgICAgfSk7XG4gICAgfVxuICAgIHNldFNob3dGb3JtTW9kYWwodHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jIChzdGF0dXM6ICdEUkFGVCcgfCAnU1VCTUlUVEVEJykgPT4ge1xuICAgIGlmICghZm9ybURhdGEuc2Vzc2lvbklkKSByZXR1cm47XG4gICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBvblNhdmVSZXBvcnQoeyAuLi5mb3JtRGF0YSwgc3RhdHVzIH0pO1xuICAgICAgc2V0U2hvd0Zvcm1Nb2RhbChmYWxzZSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBnZXRTdGF0dXNCYWRnZSA9IChzdGF0dXM6IHN0cmluZykgPT4ge1xuICAgIHN3aXRjaCAoc3RhdHVzKSB7XG4gICAgICBjYXNlICdEUkFGVCc6XG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+RHJhZnQ8L3NwYW4+O1xuICAgICAgY2FzZSAnU1VCTUlUVEVEJzpcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAgZGFyazpiZy1ibHVlLTkwMC8zMCBkYXJrOnRleHQtYmx1ZS0zMDBcIj5TdWJtaXR0ZWQ8L3NwYW4+O1xuICAgICAgY2FzZSAnQVBQUk9WRUQnOlxuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIGRhcms6YmctZ3JlZW4tOTAwLzMwIGRhcms6dGV4dC1ncmVlbi0zMDBcIj5BcHByb3ZlZDwvc3Bhbj47XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICBTZXNzaW9uIFJlcG9ydHNcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWJyYW5kLTEwMCB0ZXh0LWJyYW5kLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGRhcms6YmctYnJhbmQtOTAwLzMwIGRhcms6dGV4dC1icmFuZC0zMDBcIj5cbiAgICAgICAgICAgICAge3Nlc3Npb25SZXBvcnRzLmxlbmd0aH1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPkRldGFpbGVkIHF1YWxpdGF0aXZlIHNlc3Npb24gcmVwb3J0aW5nPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3BlbkZvcm0oKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1icmFuZC01MDAgaG92ZXI6YmctYnJhbmQtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tZWRpdW1cIlxuICAgICAgICA+XG4gICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIE5ldyBSZXBvcnRcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktODAwIHJvdW5kZWQtMnhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWQ6aXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMiBvdmVyZmxvdy14LWF1dG8gcGItMiBtZDpwYi0wIHctZnVsbCBtZDp3LWF1dG9cIj5cbiAgICAgICAgICAgIHtbJ0FsbCcsICdEUkFGVCcsICdTVUJNSVRURUQnLCAnQVBQUk9WRUQnXS5tYXAodGFiID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17dGFifVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIgYXMgYW55KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLWxnIHdoaXRlc3BhY2Utbm93cmFwIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IHRhYiBcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAgdGV4dC1icmFuZC03MDAgZGFyazpiZy1icmFuZC05MDAvMjAgZGFyazp0ZXh0LWJyYW5kLTMwMCcgXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS0xMDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6YmctZ3JheS03MDAnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dGFiID09PSAnQWxsJyA/ICdBbGwgUmVwb3J0cycgOiB0YWIuY2hhckF0KDApICsgdGFiLnNsaWNlKDEpLnRvTG93ZXJDYXNlKCl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWQ6dy02NFwiPlxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiB0cmFuc2Zvcm0gLXRyYW5zbGF0ZS15LTEvMiBoLTQgdy00IHRleHQtZ3JheS00MDBcIiAvPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBzZXNzaW9uIG9yIGNsdXN0ZXIuLi5cIiBcbiAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItNCBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTMgZ2FwLTYgcC02XCI+XG4gICAgICAgICAge3Zpc2libGVSZXBvcnRzLm1hcCgocmVwb3J0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IHJlcG9ydC5zZXNzaW9uSWQpO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e3JlcG9ydC5pZH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHJvdW5kZWQteGwgcC01IGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIiB0aXRsZT17c2Vzc2lvbj8ubmFtZSB8fCAnVW5rbm93biBTZXNzaW9uJ30+XG4gICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24/Lm5hbWUgfHwgJ1Vua25vd24gU2Vzc2lvbid9XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRGF5IHtyZXBvcnQuZGF5TnVtYmVyIHx8IHNlc3Npb24/LmRheU51bWJlcn0ge2lzU3VwZXJBZG1pbiAmJiBg4oCiICR7cmVwb3J0LmNsdXN0ZXJOYW1lfWB9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzQmFkZ2UocmVwb3J0LnN0YXR1cyl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMCBsaW5lLWNsYW1wLTMgbWItNCBoLTE1XCI+XG4gICAgICAgICAgICAgICAgICB7cmVwb3J0LnNlc3Npb25TdW1tYXJ5IHx8IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaXRhbGljXCI+Tm8gc3VtbWFyeSBwcm92aWRlZDwvc3Bhbj59XG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3JlcG9ydC5zdHVkZW50Q291bnR9IFN0dWRlbnRzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRTZWxlY3RlZFJlcG9ydChyZXBvcnQpOyBzZXRTaG93Vmlld01vZGFsKHRydWUpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgcm91bmRlZC1tZCBob3ZlcjpiZy1icmFuZC01MCBkYXJrOmhvdmVyOmJnLWJyYW5kLTkwMC8zMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJWaWV3IERldGFpbHNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEV5ZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIHshaXNTdXBlckFkbWluICYmIHJlcG9ydC5zdGF0dXMgPT09ICdEUkFGVCcgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Gb3JtKHJlcG9ydCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtNjAwIGhvdmVyOnRleHQtYnJhbmQtNzAwIGRhcms6dGV4dC1icmFuZC00MDAgZGFyazpob3Zlcjp0ZXh0LWJyYW5kLTMwMCBweC0yIHB5LTFcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgICAge3Zpc2libGVSZXBvcnRzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLWZ1bGwgcHktMTIgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgTm8gc2Vzc2lvbiByZXBvcnRzIGZvdW5kIG1hdGNoaW5nIHlvdXIgZmlsdGVycy5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGb3JtIE1vZGFsICovfVxuICAgICAge3Nob3dGb3JtTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci1zbSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctZ3JheS04MDAgcm91bmRlZC0yeGwgc2hhZG93LXhsIHctZnVsbCBtYXgtdy0yeGwgbXktOCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF1cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5pZCA/ICdFZGl0IFNlc3Npb24gUmVwb3J0JyA6ICdOZXcgU2Vzc2lvbiBSZXBvcnQnfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dGb3JtTW9kYWwoZmFsc2UpfSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICA8WENpcmNsZSBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5TZXNzaW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2Vzc2lvbklkfVxuICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgc2Vzc2lvbklkOiB2YWwgfSl9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ISFmb3JtRGF0YS5pZH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCB0ZXh0LXhzIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDAgZGlzYWJsZWQ6b3BhY2l0eS02MFwiPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYSBzZXNzaW9uXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICB7Y2x1c3RlclNlc3Npb25zLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cy5pZH0gdmFsdWU9e3MuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3MubmFtZX0gKERheSB7cy5kYXlOdW1iZXJ9KVxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IFNlc3Npb24gU3VtbWFyeVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2Vzc2lvblN1bW1hcnl9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsuLi5mb3JtRGF0YSwgc2Vzc2lvblN1bW1hcnk6IGUudGFyZ2V0LnZhbHVlfSl9XG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQcm92aWRlIGEgZ2VuZXJhbCBzdW1tYXJ5IG9mIGhvdyB0aGUgc2Vzc2lvbiB3ZW50Li4uXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IFN0dWRlbnQgQ291bnRcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3R1ZGVudENvdW50fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsuLi5mb3JtRGF0YSwgc3R1ZGVudENvdW50OiBwYXJzZUludChlLnRhcmdldC52YWx1ZSkgfHwgMH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IEF0dGVuZGFuY2UgU3VtbWFyeVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYXR0ZW5kYW5jZVN1bW1hcnl9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCBhdHRlbmRhbmNlU3VtbWFyeTogZS50YXJnZXQudmFsdWV9KX1cbiAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJyaWVmIG5vdGUgb24gYXR0ZW5kYW5jZS4uLlwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBBY3Rpdml0aWVzIENvbmR1Y3RlZFxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWN0aXZpdGllc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCBhY3Rpdml0aWVzOiBlLnRhcmdldC52YWx1ZX0pfVxuICAgICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGRhcms6YmctZ3JheS03MDAgZGFyazpib3JkZXItZ3JheS02MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGV0YWlsIHRoZSBhY3Rpdml0aWVzIGNhcnJpZWQgb3V0Li4uXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNTAwXCI+XG4gICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gSXNzdWVzIC8gQ2hhbGxlbmdlc1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuaXNzdWVzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7Li4uZm9ybURhdGEsIGlzc3VlczogZS50YXJnZXQudmFsdWV9KX1cbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vdGUgYW55IGNoYWxsZW5nZXMgZmFjZWQgZHVyaW5nIHRoZSBzZXNzaW9uLi4uXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IEdlbmVyYWwgUmVtYXJrc1xuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucmVtYXJrc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCByZW1hcmtzOiBlLnRhcmdldC52YWx1ZX0pfVxuICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGRhcms6YmctZ3JheS03MDAgZGFyazpib3JkZXItZ3JheS02MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQW55IGFkZGl0aW9uYWwgcmVtYXJrcy4uLlwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTgwMC81MCBmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Rm9ybU1vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGhvdmVyOmJnLWdyYXktNTAgcm91bmRlZC1sZyBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpiZy1ncmF5LTcwMCBkYXJrOmJvcmRlci1ncmF5LTYwMCBkYXJrOmhvdmVyOmJnLWdyYXktNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2F2ZSgnRFJBRlQnKX1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nIHx8ICFmb3JtRGF0YS5zZXNzaW9uSWR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtZ3JheS03MDAgYmctZ3JheS0yMDAgaG92ZXI6YmctZ3JheS0zMDAgcm91bmRlZC1sZyBkYXJrOnRleHQtZ3JheS0yMDAgZGFyazpiZy1ncmF5LTYwMCBkYXJrOmhvdmVyOmJnLWdyYXktNTAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgU2F2ZSBEcmFmdFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmUoJ1NVQk1JVFRFRCcpfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmcgfHwgIWZvcm1EYXRhLnNlc3Npb25JZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYnJhbmQtNTAwIGhvdmVyOmJnLWJyYW5kLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICBTdWJtaXQgUmVwb3J0XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFZpZXcgTW9kYWwgKi99XG4gICAgICB7c2hvd1ZpZXdNb2RhbCAmJiBzZWxlY3RlZFJlcG9ydCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXNtIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBzaGFkb3cteGwgdy1mdWxsIG1heC13LTJ4bCBteS04IG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG1heC1oLVs5MHZoXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgUmVwb3J0IERldGFpbHNcbiAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzQmFkZ2Uoc2VsZWN0ZWRSZXBvcnQuc3RhdHVzKX1cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Vmlld01vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IG92ZXJmbG93LXktYXV0byBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5TZXNzaW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgbXQtMSB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTIwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICB7c2Vzc2lvbnMuZmluZChzID0+IHMuaWQgPT09IHNlbGVjdGVkUmVwb3J0LnNlc3Npb25JZCk/Lm5hbWUgfHwgJ1Vua25vd24nfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkNsdXN0ZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBtdC0xIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktMjAwXCI+e3NlbGVjdGVkUmVwb3J0LmNsdXN0ZXJOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gU2Vzc2lvbiBTdW1tYXJ5XG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1ncmF5LTUwIGRhcms6YmctZ3JheS05MDAvNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHRleHQtc20gdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVwb3J0LnNlc3Npb25TdW1tYXJ5fVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gU3R1ZGVudCBDb3VudFxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUmVwb3J0LnN0dWRlbnRDb3VudH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IEF0dGVuZGFuY2UgU3VtbWFyeVxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlcG9ydC5hdHRlbmRhbmNlU3VtbWFyeSB8fCAnLSd9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4gQWN0aXZpdGllc1xuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctZ3JheS01MCBkYXJrOmJnLWdyYXktOTAwLzUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCB0ZXh0LXNtIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlcG9ydC5hY3Rpdml0aWVzIHx8ICctJ31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBJc3N1ZXNcbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXJlZC01MCBkYXJrOmJnLXJlZC05MDAvMjAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC0xMDAgZGFyazpib3JkZXItcmVkLTkwMC8zMCB0ZXh0LXNtIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlcG9ydC5pc3N1ZXMgfHwgJy0nfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IFJlbWFya3NcbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTkwMC81MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS03MDAgdGV4dC1zbSB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSZXBvcnQucmVtYXJrcyB8fCAnLSd9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBiZy1ncmF5LTUwIGRhcms6YmctZ3JheS04MDAvNTAgZmxleCBqdXN0aWZ5LWVuZCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1ZpZXdNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTUwIHJvdW5kZWQtbGcgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6YmctZ3JheS03MDAgZGFyazpib3JkZXItZ3JheS02MDAgZGFyazpob3ZlcjpiZy1ncmF5LTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDbG9zZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTZXNzaW9uUmVwb3J0VmlldztcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9TZXNzaW9uUmVwb3J0Vmlldy50c3gifQ==