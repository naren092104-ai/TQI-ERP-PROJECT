import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/VolunteersView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Plus,
  Search,
  Users,
  Award,
  GraduationCap,
  BookOpen,
  Eye,
  Edit3,
  Trash2,
  X,
  CheckCircle2
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import Badge from "/src/components/ui/badge.tsx";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "/src/components/ui/table.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { ActionButton } from "/src/components/ui/action-button.tsx";
export const VolunteersView = ({
  volunteers,
  panchayats = [],
  onAddVolunteer,
  onEditVolunteer,
  onUpdateVolunteer,
  onDeleteVolunteer,
  onBulkImportVolunteers
}) => {
  _s();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingVolunteer, setEditingVolunteer] = useState(null);
  const [viewingModalVolunteer, setViewingModalVolunteer] = useState(null);
  const [volunteerToDelete, setVolunteerToDelete] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4e3);
  };
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "+91 ",
    college: "Government College of Engineering, Dharmapuri",
    department: "Computer Science and Engineering",
    year: "4th Year",
    totalSessions: 0,
    attendanceRate: 100
  });
  const departmentOptions = [
    "Computer Science and Engineering",
    "Electronics and Communication Engineering",
    "Mechanical Engineering",
    "Information Technology",
    "Electrical and Electronics Engineering",
    "Civil Engineering",
    "Biotechnology",
    "Artificial Intelligence & Data Science",
    "Arts & Science / Commerce"
  ];
  const yearOptions = [
    "1st Year",
    "2nd Year",
    "3rd Year",
    "4th Year",
    "Post Graduate",
    "Alumnus"
  ];
  const filteredVolunteers = useMemo(() => {
    return volunteers.filter((v) => {
      const matchSearch = v.name.toLowerCase().includes(searchTerm.toLowerCase()) || v.email.toLowerCase().includes(searchTerm.toLowerCase()) || v.phone.includes(searchTerm) || v.college && v.college.toLowerCase().includes(searchTerm.toLowerCase()) || v.department && v.department.toLowerCase().includes(searchTerm.toLowerCase());
      const matchDept = !selectedDepartment || v.department === selectedDepartment;
      const matchYear = !selectedYear || v.year === selectedYear;
      return matchSearch && matchDept && matchYear;
    });
  }, [volunteers, searchTerm, selectedDepartment, selectedYear]);
  const handleSaveVolunteer = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      showToast("Please enter volunteer name");
      return;
    }
    if (editingVolunteer) {
      if (onEditVolunteer) {
        onEditVolunteer(editingVolunteer.id, {
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim(),
          college: formData.college.trim(),
          department: formData.department,
          year: formData.year,
          totalSessions: formData.totalSessions,
          attendanceRate: formData.attendanceRate
        });
      } else if (onUpdateVolunteer) {
        onUpdateVolunteer(editingVolunteer.id, {
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim(),
          college: formData.college.trim(),
          department: formData.department,
          year: formData.year,
          totalSessions: formData.totalSessions,
          attendanceRate: formData.attendanceRate
        });
      }
      if (viewingModalVolunteer?.id === editingVolunteer.id) {
        setViewingModalVolunteer({
          ...viewingModalVolunteer,
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim(),
          college: formData.college.trim(),
          department: formData.department,
          year: formData.year,
          totalSessions: formData.totalSessions,
          attendanceRate: formData.attendanceRate
        });
      }
      showToast("Updated volunteer " + formData.name);
      setEditingVolunteer(null);
    } else {
      onAddVolunteer({
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        college: formData.college.trim(),
        department: formData.department,
        year: formData.year
      });
      showToast("Added volunteer " + formData.name);
    }
    setShowAddModal(false);
    setFormData({
      name: "",
      email: "",
      phone: "+91 ",
      college: "Government College of Engineering, Dharmapuri",
      department: "Computer Science and Engineering",
      year: "4th Year",
      totalSessions: 0,
      attendanceRate: 100
    });
  };
  const handleEditClick = (vol) => {
    setEditingVolunteer(vol);
    setFormData({
      name: vol.name,
      email: vol.email,
      phone: vol.phone,
      college: vol.college || "Government College of Engineering, Dharmapuri",
      department: vol.department || "Computer Science and Engineering",
      year: vol.year || "4th Year",
      totalSessions: vol.totalSessions || 0,
      attendanceRate: vol.attendanceRate || 100
    });
    setShowAddModal(true);
  };
  const handleConfirmDelete = () => {
    if (!volunteerToDelete) return;
    const volName = volunteerToDelete.name;
    onDeleteVolunteer(volunteerToDelete.id);
    if (viewingModalVolunteer?.id === volunteerToDelete.id) {
      setViewingModalVolunteer(null);
    }
    showToast("Volunteer " + volName + " deleted successfully");
    setVolunteerToDelete(null);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    toastMessage && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-[99999] flex items-center gap-2 rounded-xl bg-gray-900 px-4 py-3 text-xs font-semibold text-white shadow-theme-lg dark:bg-white dark:text-gray-900 animate-in fade-in-0 slide-in-from-bottom-5", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-success-500 shrink-0" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 215,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: toastMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 216,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setToastMessage(null),
          className: "ml-2 text-gray-400 hover:text-white dark:hover:text-gray-900 cursor-pointer",
          children: /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 222,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 217,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 214,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Volunteers & Mentors Directory" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 230,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            volunteers.length,
            " Active"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 233,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 229,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Roster of college volunteers, department specializations, and attendance performance." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 237,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 228,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV(
          ActionButton,
          {
            onClick: () => {
              if (onBulkImportVolunteers) {
                const mockData = [{ name: "Test Vol", email: "test@vol.com", phone: "123" }];
                const clusterId = panchayats.length > 0 ? panchayats[0].clusterId || panchayats[0].cluster || "" : "";
                onBulkImportVolunteers(mockData, clusterId);
              } else {
                alert("Bulk import functionality is not connected yet.");
              }
            },
            size: "sm",
            variant: "outline",
            children: "Bulk Import"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 243,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          ActionButton,
          {
            onClick: () => {
              setEditingVolunteer(null);
              setFormData({
                name: "",
                email: "",
                phone: "+91 ",
                college: "Government College of Engineering, Dharmapuri",
                department: "Computer Science and Engineering",
                year: "4th Year",
                totalSessions: 0,
                attendanceRate: 100
              });
              setShowAddModal(true);
            },
            size: "sm",
            variant: "primary",
            icon: /* @__PURE__ */ jsxDEV(Plus, { size: 15 }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 281,
              columnNumber: 19
            }, this),
            children: "Add Volunteer"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 264,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 242,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 227,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Mentors" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 291,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Users, { className: "h-4 w-4 text-brand-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 292,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 290,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: volunteers.length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 294,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 289,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Departments" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 299,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(BookOpen, { className: "h-4 w-4 text-success-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 300,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 298,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: new Set(volunteers.map((v) => v.department)).size }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 302,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 297,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Avg Attendance" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 309,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Award, { className: "h-4 w-4 text-theme-purple-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 310,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 308,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: volunteers.length > 0 ? Math.round(volunteers.reduce((acc, v) => acc + (v.attendanceRate || 100), 0) / volunteers.length) + "%" : "100%" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 312,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 307,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 sm:p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Final Year" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 321,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(GraduationCap, { className: "h-4 w-4 text-warning-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 322,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 320,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: volunteers.filter((v) => v.year && v.year.includes("4th")).length }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 324,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 319,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 288,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 332,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search by name, department, college...",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 333,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 331,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-48", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedDepartment || "all",
            onValueChange: (val) => setSelectedDepartment(val === "all" ? "" : val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Departments" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 349,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 348,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Departments" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                  lineNumber: 352,
                  columnNumber: 17
                }, this),
                departmentOptions.map(
                  (dept) => /* @__PURE__ */ jsxDEV(SelectItem, { value: dept, children: dept }, dept, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 354,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 351,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 344,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 343,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-32", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedYear || "all",
            onValueChange: (val) => setSelectedYear(val === "all" ? "" : val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Years" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 368,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 367,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Years" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                  lineNumber: 371,
                  columnNumber: 17
                }, this),
                yearOptions.map(
                  (yr) => /* @__PURE__ */ jsxDEV(SelectItem, { value: yr, children: yr }, yr, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 373,
                    columnNumber: 17
                  }, this)
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 370,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 363,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 362,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400 dark:text-gray-500 ml-auto md:ml-1", children: [
          filteredVolunteers.length,
          " of ",
          volunteers.length
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 381,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 342,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 330,
      columnNumber: 7
    }, this),
    filteredVolunteers.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-16 text-center", children: [
      /* @__PURE__ */ jsxDEV(Users, { className: "mx-auto h-12 w-12 text-gray-300 dark:text-gray-600" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 389,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "mt-3 text-base font-semibold text-gray-800 dark:text-white", children: "No volunteers found" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 390,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: searchTerm || selectedDepartment || selectedYear ? "Try clearing your filters." : "Add your first volunteer mentor to get started." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 391,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 388,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "w-[260px]", children: "Volunteer Name" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 400,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Department" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 401,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Year" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 402,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "College" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 403,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Contact" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 404,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 405,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 399,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 398,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: filteredVolunteers.map(
        (vol) => /* @__PURE__ */ jsxDEV(
          TableRow,
          {
            onClick: () => setViewingModalVolunteer(vol),
            className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 items-center justify-center rounded-full bg-brand-50 text-xs font-bold text-brand-500 dark:bg-brand-500/10 dark:text-brand-400 shrink-0", children: vol.avatarText || vol.name.slice(0, 2).toUpperCase() }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                  lineNumber: 417,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-gray-900 dark:text-white", children: vol.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                  lineNumber: 420,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 416,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 415,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-700 dark:text-gray-300", children: vol.department }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 424,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 423,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: vol.year }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 429,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 428,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-500 dark:text-gray-400 text-xs max-w-[200px] truncate", children: vol.college || "—" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 433,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(TableCell, { className: "font-mono text-xs text-gray-500 dark:text-gray-400", children: vol.phone }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 436,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-1", onClick: (e) => e.stopPropagation(), children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setViewingModalVolunteer(vol),
                    className: "rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 hover:text-gray-800 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-white transition cursor-pointer",
                    title: "View details",
                    children: /* @__PURE__ */ jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                      lineNumber: 447,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 441,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleEditClick(vol),
                    className: "rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 hover:text-brand-500 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                    title: "Edit volunteer",
                    children: /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                      lineNumber: 455,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 449,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setVolunteerToDelete(vol),
                    className: "rounded-lg p-1.5 text-gray-500 hover:bg-error-50 hover:text-error-600 dark:text-gray-400 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition cursor-pointer",
                    title: "Delete volunteer",
                    children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                      lineNumber: 463,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 457,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 440,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 439,
                columnNumber: 19
              }, this)
            ]
          },
          vol.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 410,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 408,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 397,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 396,
      columnNumber: 7
    }, this),
    viewingModalVolunteer && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95 space-y-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900 dark:text-white", children: "Volunteer Profile" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 479,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setViewingModalVolunteer(null),
            className: "inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-white transition cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 485,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 480,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 478,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 rounded-xl bg-gray-50/80 p-4 dark:bg-white/[0.02]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex h-14 w-14 items-center justify-center rounded-full bg-brand-500 text-lg font-bold text-white shadow-theme-xs", children: viewingModalVolunteer.avatarText || viewingModalVolunteer.name.slice(0, 2).toUpperCase() }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 490,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-0.5", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-bold text-gray-900 dark:text-white", children: viewingModalVolunteer.name }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 494,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400", children: viewingModalVolunteer.email }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 495,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-mono text-gray-600 dark:text-gray-300", children: viewingModalVolunteer.phone }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 496,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 493,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 489,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 rounded-xl border border-gray-100 p-4 text-xs dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold uppercase text-gray-400 block mb-1", children: "Department" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 503,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 dark:text-white", children: viewingModalVolunteer.department }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 504,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 502,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold uppercase text-gray-400 block mb-1", children: "Year of Study" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 507,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 dark:text-white", children: viewingModalVolunteer.year }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 508,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 506,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 501,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold uppercase text-gray-400 block mb-1", children: "Institution" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 512,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600 dark:text-gray-300", children: viewingModalVolunteer.college }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 513,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 511,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 500,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-gray-100 p-3 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase font-semibold text-gray-400", children: "Sessions Attended" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 519,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-brand-500 mt-1", children: viewingModalVolunteer.totalSessions || 0 }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 520,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 518,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-gray-100 p-3 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] uppercase font-semibold text-gray-400", children: "Attendance Rate" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 523,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-success-500 mt-1", children: [
            viewingModalVolunteer.attendanceRate || 100,
            "%"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 524,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 522,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 517,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              const toDelete = viewingModalVolunteer;
              setViewingModalVolunteer(null);
              setVolunteerToDelete(toDelete);
            },
            className: "rounded-xl border border-error-200 bg-error-50 px-3.5 py-2 text-xs font-semibold text-error-600 hover:bg-error-100 dark:border-error-900/40 dark:bg-error-500/10 dark:text-error-400 transition cursor-pointer",
            children: "Delete Volunteer"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 529,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setViewingModalVolunteer(null),
              className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
              children: "Close"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 542,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                const toEdit = viewingModalVolunteer;
                setViewingModalVolunteer(null);
                handleEditClick(toEdit);
              },
              className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
              children: "Edit Volunteer"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 549,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 541,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 528,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 477,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 476,
      columnNumber: 7
    }, this),
    volunteerToDelete && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 text-center animate-in fade-in-0 zoom-in-95 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-error-50 text-error-500 dark:bg-error-500/10", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-6 w-6" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 571,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 570,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Delete Volunteer?" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 574,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-gray-500 dark:text-gray-400", children: [
          "Are you sure you want to remove ",
          /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-800 dark:text-white", children: volunteerToDelete.name }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 576,
            columnNumber: 49
          }, this),
          " from the directory?"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 575,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 573,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2.5 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setVolunteerToDelete(null),
            className: "flex-1 rounded-xl border border-gray-300 bg-white py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 580,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleConfirmDelete,
            className: "flex-1 rounded-xl bg-error-500 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-error-600 transition cursor-pointer",
            children: "Yes, Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 587,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 579,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 569,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 568,
      columnNumber: 7
    }, this),
    showAddModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900 dark:text-white", children: editingVolunteer ? "Edit Volunteer" : "Add New Volunteer" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 604,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowAddModal(false),
            className: "inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-white transition cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 612,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 607,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 603,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSaveVolunteer, className: "mt-5 space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Full Name *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 618,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              required: true,
              placeholder: "Enter volunteer name",
              value: formData.name,
              onChange: (e) => setFormData({ ...formData, name: e.target.value }),
              className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 621,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 617,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Email Address" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 633,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "email",
                placeholder: "you@college.edu",
                value: formData.email,
                onChange: (e) => setFormData({ ...formData, email: e.target.value }),
                className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 636,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 632,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Phone Number" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 645,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "tel",
                placeholder: "+91 98765 43210",
                value: formData.phone,
                onChange: (e) => setFormData({ ...formData, phone: e.target.value }),
                className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 648,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 644,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 631,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "College / Institution" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 659,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "e.g. Government College of Engineering, Dharmapuri",
              value: formData.college,
              onChange: (e) => setFormData({ ...formData, college: e.target.value }),
              className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 662,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 658,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Department *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 673,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.department,
                onValueChange: (val) => setFormData({ ...formData, department: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-800", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Department" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 681,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 680,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: departmentOptions.map(
                    (dept) => /* @__PURE__ */ jsxDEV(SelectItem, { value: dept, children: dept }, dept, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                      lineNumber: 685,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 683,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 676,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 672,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Year *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 694,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.year,
                onValueChange: (val) => setFormData({ ...formData, year: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs rounded-lg border-gray-300 dark:border-gray-700 dark:bg-gray-800", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Year" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 702,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 701,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: yearOptions.map(
                    (yr) => /* @__PURE__ */ jsxDEV(SelectItem, { value: yr, children: yr }, yr, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                      lineNumber: 706,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                    lineNumber: 704,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
                lineNumber: 697,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
            lineNumber: 693,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 671,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowAddModal(false),
              className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition cursor-pointer",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 716,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
              children: editingVolunteer ? "Update Volunteer" : "Save Volunteer"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
              lineNumber: 723,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
          lineNumber: 715,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
        lineNumber: 616,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 602,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
      lineNumber: 601,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx",
    lineNumber: 212,
    columnNumber: 5
  }, this);
};
_s(VolunteersView, "P2S6bhppHFqCFl0ch9Eg0w3hMuQ=");
_c = VolunteersView;
var _c;
$RefreshReg$(_c, "VolunteersView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/VolunteersView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc05VOztBQXROVixTQUFnQkEsVUFBVUMsZUFBZTtBQUN6QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLE9BQU9DLGFBQWFDLFdBQVdDLFVBQVVDLGlCQUFpQjtBQUNuRTtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxvQkFBb0I7QUFZdEIsYUFBTUMsaUJBQWdEQSxDQUFDO0FBQUEsRUFDNURDO0FBQUFBLEVBQ0FDLGFBQWE7QUFBQSxFQUNiQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJbkMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ29DLG9CQUFvQkMscUJBQXFCLElBQUlyQyxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDc0MsY0FBY0MsZUFBZSxJQUFJdkMsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3dDLGNBQWNDLGVBQWUsSUFBSXpDLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUMwQyxrQkFBa0JDLG1CQUFtQixJQUFJM0MsU0FBMkIsSUFBSTtBQUMvRSxRQUFNLENBQUM0Qyx1QkFBdUJDLHdCQUF3QixJQUFJN0MsU0FBMkIsSUFBSTtBQUN6RixRQUFNLENBQUM4QyxtQkFBbUJDLG9CQUFvQixJQUFJL0MsU0FBMkIsSUFBSTtBQUNqRixRQUFNLENBQUNnRCxjQUFjQyxlQUFlLElBQUlqRCxTQUF3QixJQUFJO0FBRXBFLFFBQU1rRCxZQUFZQSxDQUFDQyxRQUFnQjtBQUNqQ0Ysb0JBQWdCRSxHQUFHO0FBQ25CQyxlQUFXLE1BQU07QUFDZkgsc0JBQWdCLElBQUk7QUFBQSxJQUN0QixHQUFHLEdBQUk7QUFBQSxFQUNUO0FBRUEsUUFBTSxDQUFDSSxVQUFVQyxXQUFXLElBQUl0RCxTQUFTO0FBQUEsSUFDdkN1RCxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLElBQ1pDLE1BQU07QUFBQSxJQUNOQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUVELFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUEyQjtBQUc3QixRQUFNQyxjQUFjO0FBQUEsSUFDbEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQVM7QUFHWCxRQUFNQyxxQkFBcUJoRSxRQUFRLE1BQU07QUFDdkMsV0FBT3lCLFdBQVd3QyxPQUFPLENBQUNDLE1BQU07QUFDOUIsWUFBTUMsY0FDSkQsRUFBRVosS0FBS2MsWUFBWSxFQUFFQyxTQUFTcEMsV0FBV21DLFlBQVksQ0FBQyxLQUN0REYsRUFBRVgsTUFBTWEsWUFBWSxFQUFFQyxTQUFTcEMsV0FBV21DLFlBQVksQ0FBQyxLQUN2REYsRUFBRVYsTUFBTWEsU0FBU3BDLFVBQVUsS0FDMUJpQyxFQUFFVCxXQUFXUyxFQUFFVCxRQUFRVyxZQUFZLEVBQUVDLFNBQVNwQyxXQUFXbUMsWUFBWSxDQUFDLEtBQ3RFRixFQUFFUixjQUFjUSxFQUFFUixXQUFXVSxZQUFZLEVBQUVDLFNBQVNwQyxXQUFXbUMsWUFBWSxDQUFDO0FBRS9FLFlBQU1FLFlBQVksQ0FBQ25DLHNCQUFzQitCLEVBQUVSLGVBQWV2QjtBQUMxRCxZQUFNb0MsWUFBWSxDQUFDbEMsZ0JBQWdCNkIsRUFBRVAsU0FBU3RCO0FBRTlDLGFBQU84QixlQUFlRyxhQUFhQztBQUFBQSxJQUNyQyxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUM5QyxZQUFZUSxZQUFZRSxvQkFBb0JFLFlBQVksQ0FBQztBQUU3RCxRQUFNbUMsc0JBQXNCQSxDQUFDQyxNQUF1QjtBQUNsREEsTUFBRUMsZUFBZTtBQUNqQixRQUFJLENBQUN0QixTQUFTRSxLQUFLcUIsS0FBSyxHQUFHO0FBQ3pCMUIsZ0JBQVUsNkJBQTZCO0FBQ3ZDO0FBQUEsSUFDRjtBQUVBLFFBQUlSLGtCQUFrQjtBQUNwQixVQUFJYixpQkFBaUI7QUFDbkJBLHdCQUFnQmEsaUJBQWlCbUMsSUFBSTtBQUFBLFVBQ25DdEIsTUFBTUYsU0FBU0UsS0FBS3FCLEtBQUs7QUFBQSxVQUN6QnBCLE9BQU9ILFNBQVNHLE1BQU1vQixLQUFLO0FBQUEsVUFDM0JuQixPQUFPSixTQUFTSSxNQUFNbUIsS0FBSztBQUFBLFVBQzNCbEIsU0FBU0wsU0FBU0ssUUFBUWtCLEtBQUs7QUFBQSxVQUMvQmpCLFlBQVlOLFNBQVNNO0FBQUFBLFVBQ3JCQyxNQUFNUCxTQUFTTztBQUFBQSxVQUNmQyxlQUFlUixTQUFTUTtBQUFBQSxVQUN4QkMsZ0JBQWdCVCxTQUFTUztBQUFBQSxRQUMzQixDQUFDO0FBQUEsTUFDSCxXQUFXaEMsbUJBQW1CO0FBQzVCQSwwQkFBa0JZLGlCQUFpQm1DLElBQUk7QUFBQSxVQUNyQ3RCLE1BQU1GLFNBQVNFLEtBQUtxQixLQUFLO0FBQUEsVUFDekJwQixPQUFPSCxTQUFTRyxNQUFNb0IsS0FBSztBQUFBLFVBQzNCbkIsT0FBT0osU0FBU0ksTUFBTW1CLEtBQUs7QUFBQSxVQUMzQmxCLFNBQVNMLFNBQVNLLFFBQVFrQixLQUFLO0FBQUEsVUFDL0JqQixZQUFZTixTQUFTTTtBQUFBQSxVQUNyQkMsTUFBTVAsU0FBU087QUFBQUEsVUFDZkMsZUFBZVIsU0FBU1E7QUFBQUEsVUFDeEJDLGdCQUFnQlQsU0FBU1M7QUFBQUEsUUFDM0IsQ0FBQztBQUFBLE1BQ0g7QUFFQSxVQUFJbEIsdUJBQXVCaUMsT0FBT25DLGlCQUFpQm1DLElBQUk7QUFDckRoQyxpQ0FBeUI7QUFBQSxVQUN2QixHQUFHRDtBQUFBQSxVQUNIVyxNQUFNRixTQUFTRSxLQUFLcUIsS0FBSztBQUFBLFVBQ3pCcEIsT0FBT0gsU0FBU0csTUFBTW9CLEtBQUs7QUFBQSxVQUMzQm5CLE9BQU9KLFNBQVNJLE1BQU1tQixLQUFLO0FBQUEsVUFDM0JsQixTQUFTTCxTQUFTSyxRQUFRa0IsS0FBSztBQUFBLFVBQy9CakIsWUFBWU4sU0FBU007QUFBQUEsVUFDckJDLE1BQU1QLFNBQVNPO0FBQUFBLFVBQ2ZDLGVBQWVSLFNBQVNRO0FBQUFBLFVBQ3hCQyxnQkFBZ0JULFNBQVNTO0FBQUFBLFFBQzNCLENBQUM7QUFBQSxNQUNIO0FBRUFaLGdCQUFVLHVCQUF1QkcsU0FBU0UsSUFBSTtBQUM5Q1osMEJBQW9CLElBQUk7QUFBQSxJQUMxQixPQUFPO0FBQ0xmLHFCQUFlO0FBQUEsUUFDYjJCLE1BQU1GLFNBQVNFLEtBQUtxQixLQUFLO0FBQUEsUUFDekJwQixPQUFPSCxTQUFTRyxNQUFNb0IsS0FBSztBQUFBLFFBQzNCbkIsT0FBT0osU0FBU0ksTUFBTW1CLEtBQUs7QUFBQSxRQUMzQmxCLFNBQVNMLFNBQVNLLFFBQVFrQixLQUFLO0FBQUEsUUFDL0JqQixZQUFZTixTQUFTTTtBQUFBQSxRQUNyQkMsTUFBTVAsU0FBU087QUFBQUEsTUFDakIsQ0FBQztBQUNEVixnQkFBVSxxQkFBcUJHLFNBQVNFLElBQUk7QUFBQSxJQUM5QztBQUVBZCxvQkFBZ0IsS0FBSztBQUNyQmEsZ0JBQVk7QUFBQSxNQUNWQyxNQUFNO0FBQUEsTUFDTkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxlQUFlO0FBQUEsTUFDZkMsZ0JBQWdCO0FBQUEsSUFDbEIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNZ0Isa0JBQWtCQSxDQUFDQyxRQUFtQjtBQUMxQ3BDLHdCQUFvQm9DLEdBQUc7QUFDdkJ6QixnQkFBWTtBQUFBLE1BQ1ZDLE1BQU13QixJQUFJeEI7QUFBQUEsTUFDVkMsT0FBT3VCLElBQUl2QjtBQUFBQSxNQUNYQyxPQUFPc0IsSUFBSXRCO0FBQUFBLE1BQ1hDLFNBQVNxQixJQUFJckIsV0FBVztBQUFBLE1BQ3hCQyxZQUFZb0IsSUFBSXBCLGNBQWM7QUFBQSxNQUM5QkMsTUFBTW1CLElBQUluQixRQUFRO0FBQUEsTUFDbEJDLGVBQWVrQixJQUFJbEIsaUJBQWlCO0FBQUEsTUFDcENDLGdCQUFnQmlCLElBQUlqQixrQkFBa0I7QUFBQSxJQUN4QyxDQUFDO0FBQ0RyQixvQkFBZ0IsSUFBSTtBQUFBLEVBQ3RCO0FBRUEsUUFBTXVDLHNCQUFzQkEsTUFBTTtBQUNoQyxRQUFJLENBQUNsQyxrQkFBbUI7QUFDeEIsVUFBTW1DLFVBQVVuQyxrQkFBa0JTO0FBQ2xDeEIsc0JBQWtCZSxrQkFBa0IrQixFQUFFO0FBRXRDLFFBQUlqQyx1QkFBdUJpQyxPQUFPL0Isa0JBQWtCK0IsSUFBSTtBQUN0RGhDLCtCQUF5QixJQUFJO0FBQUEsSUFDL0I7QUFFQUssY0FBVSxlQUFlK0IsVUFBVSx1QkFBdUI7QUFDMURsQyx5QkFBcUIsSUFBSTtBQUFBLEVBQzNCO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBQ1pDO0FBQUFBLG9CQUNDLHVCQUFDLFNBQUksV0FBVSwyTkFDYjtBQUFBLDZCQUFDLGdCQUFhLFdBQVUsdUNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRCx1QkFBQyxVQUFNQSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTUMsZ0JBQWdCLElBQUk7QUFBQSxVQUNuQyxXQUFVO0FBQUEsVUFFVixpQ0FBQyxLQUFFLFdBQVUsaUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEI7QUFBQTtBQUFBLFFBTDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsOEVBQTRFLDhDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCdkI7QUFBQUEsdUJBQVd3RDtBQUFBQSxZQUFPO0FBQUEsZUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQStDLHFHQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiLGtCQUFJbEQsd0JBQXdCO0FBTTFCLHNCQUFNbUQsV0FBVyxDQUFDLEVBQUU1QixNQUFNLFlBQVlDLE9BQU8sZ0JBQWdCQyxPQUFPLE1BQU0sQ0FBQztBQUMzRSxzQkFBTTJCLFlBQVl6RCxXQUFXdUQsU0FBUyxJQUFLdkQsV0FBVyxDQUFDLEVBQUV5RCxhQUFhekQsV0FBVyxDQUFDLEVBQUUwRCxXQUFXLEtBQU07QUFDckdyRCx1Q0FBdUJtRCxVQUFVQyxTQUFTO0FBQUEsY0FDNUMsT0FBTztBQUNMRSxzQkFBTSxpREFBaUQ7QUFBQSxjQUN6RDtBQUFBLFlBQ0Y7QUFBQSxZQUNBLE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUFTO0FBQUE7QUFBQSxVQWhCbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBbUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2IzQyxrQ0FBb0IsSUFBSTtBQUN4QlcsMEJBQVk7QUFBQSxnQkFDVkMsTUFBTTtBQUFBLGdCQUNOQyxPQUFPO0FBQUEsZ0JBQ1BDLE9BQU87QUFBQSxnQkFDUEMsU0FBUztBQUFBLGdCQUNUQyxZQUFZO0FBQUEsZ0JBQ1pDLE1BQU07QUFBQSxnQkFDTkMsZUFBZTtBQUFBLGdCQUNmQyxnQkFBZ0I7QUFBQSxjQUNsQixDQUFDO0FBQ0RyQiw4QkFBZ0IsSUFBSTtBQUFBLFlBQ3RCO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUFRO0FBQUEsWUFDUixNQUFNLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUFJO0FBQUE7QUFBQSxVQWpCM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0JBO0FBQUEsV0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQTtBQUFBLFNBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyREE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxtRkFBa0YsNkJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStHO0FBQUEsVUFDL0csdUJBQUMsU0FBTSxXQUFVLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlEQUF5RGYscUJBQVd3RCxVQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsV0FMNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLDJCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RztBQUFBLFVBQzdHLHVCQUFDLFlBQVMsV0FBVSw4QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxhQUZoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5REFDWixjQUFJSyxJQUFJN0QsV0FBVzhELElBQUksQ0FBQXJCLE1BQUtBLEVBQUVSLFVBQVUsQ0FBQyxFQUFFOEIsUUFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxtRkFBa0YsOEJBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdIO0FBQUEsVUFDaEgsdUJBQUMsU0FBTSxXQUFVLG1DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLGFBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlEQUNaL0QscUJBQVd3RCxTQUFTLElBQ2pCUSxLQUFLQyxNQUFNakUsV0FBV2tFLE9BQU8sQ0FBQ0MsS0FBSzFCLE1BQU0wQixPQUFPMUIsRUFBRUwsa0JBQWtCLE1BQU0sQ0FBQyxJQUFJcEMsV0FBV3dELE1BQU0sSUFBSSxNQUNwRyxVQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsb0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLDBCQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RztBQUFBLFVBQzVHLHVCQUFDLGlCQUFjLFdBQVUsOEJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsYUFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseURBQ1p4RCxxQkFBV3dDLE9BQU8sQ0FBQUMsTUFBS0EsRUFBRVAsUUFBUU8sRUFBRVAsS0FBS1UsU0FBUyxLQUFLLENBQUMsRUFBRVksVUFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0NBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsMEZBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxRQUN4RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT2hEO0FBQUFBLFlBQ1AsVUFBVSxDQUFDd0MsTUFBTXZDLGNBQWN1QyxFQUFFb0IsT0FBT0MsS0FBSztBQUFBLFlBQzdDLFdBQVU7QUFBQTtBQUFBLFVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS21UO0FBQUEsV0FQclQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTzNELHNCQUFzQjtBQUFBLFlBQzdCLGVBQWUsQ0FBQzRELFFBQVEzRCxzQkFBc0IyRCxRQUFRLFFBQVEsS0FBS0EsR0FBRztBQUFBLFlBRXRFO0FBQUEscUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVkscUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLGlCQUNDO0FBQUEsdUNBQUMsY0FBVyxPQUFNLE9BQU0sK0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDO0FBQUEsZ0JBQ3RDakMsa0JBQWtCeUI7QUFBQUEsa0JBQUksQ0FBQ1MsU0FDdEIsdUJBQUMsY0FBc0IsT0FBT0EsTUFDM0JBLGtCQURjQSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQSxtQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUE7QUFBQTtBQUFBLFVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8zRCxnQkFBZ0I7QUFBQSxZQUN2QixlQUFlLENBQUMwRCxRQUFRekQsZ0JBQWdCeUQsUUFBUSxRQUFRLEtBQUtBLEdBQUc7QUFBQSxZQUVoRTtBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGVBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLGlCQUNDO0FBQUEsdUNBQUMsY0FBVyxPQUFNLE9BQU0seUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2hDaEMsWUFBWXdCO0FBQUFBLGtCQUFJLENBQUNVLE9BQ2hCLHVCQUFDLGNBQW9CLE9BQU9BLElBQ3pCQSxnQkFEY0EsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUEsbUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBO0FBQUE7QUFBQSxVQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFVBQUssV0FBVSw0REFDYmpDO0FBQUFBLDZCQUFtQmlCO0FBQUFBLFVBQU87QUFBQSxVQUFLeEQsV0FBV3dEO0FBQUFBLGFBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxTQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdURBO0FBQUEsSUFFQ2pCLG1CQUFtQmlCLFdBQVcsSUFDN0IsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsU0FBTSxXQUFVLHdEQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCxtQ0FBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLE1BQzlGLHVCQUFDLE9BQUUsV0FBVSxpREFDVmhELHdCQUFjRSxzQkFBc0JFLGVBQWUsK0JBQStCLHFEQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5SEFDYixpQ0FBQyxTQUNDO0FBQUEsNkJBQUMsZUFDQyxpQ0FBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxVQUFRLE1BQUMsV0FBVSxhQUFZLDhCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDeEQsdUJBQUMsYUFBVSxVQUFRLE1BQUMsMEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUM5Qix1QkFBQyxhQUFVLFVBQVEsTUFBQyxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLGFBQVUsVUFBUSxNQUFDLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDM0IsdUJBQUMsYUFBVSxVQUFRLE1BQUMsdUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMzQix1QkFBQyxhQUFVLFVBQVEsTUFBQyxXQUFVLGNBQWEsdUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxXQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLGFBQ0UyQiw2QkFBbUJ1QjtBQUFBQSxRQUFJLENBQUNULFFBQ3ZCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU1sQyx5QkFBeUJrQyxHQUFHO0FBQUEsWUFDM0MsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxhQUNDLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx3SkFDWkEsY0FBSW9CLGNBQWNwQixJQUFJeEIsS0FBSzZDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLFlBQVksS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FBK0N0QixjQUFJeEIsUUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUU7QUFBQSxtQkFKekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLGFBQ0MsaUNBQUMsVUFBSyxXQUFVLHdEQUNid0IsY0FBSXBCLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLGFBQ0MsaUNBQUMsU0FBTSxPQUFNLFNBQVEsTUFBSyxNQUN2Qm9CLGNBQUluQixRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxhQUFVLFdBQVUsbUVBQ2xCbUIsY0FBSXJCLFdBQVcsT0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsYUFBVSxXQUFVLHNEQUNsQnFCLGNBQUl0QixTQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLGFBQVUsV0FBVSxjQUNuQixpQ0FBQyxTQUFJLFdBQVUsdUNBQXNDLFNBQVMsQ0FBQ2lCLE1BQU1BLEVBQUU0QixnQkFBZ0IsR0FDckY7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNekQseUJBQXlCa0MsR0FBRztBQUFBLG9CQUMzQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdCO0FBQUE7QUFBQSxrQkFOMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTUQsZ0JBQWdCQyxHQUFHO0FBQUEsb0JBQ2xDLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBRU4saUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBCO0FBQUE7QUFBQSxrQkFONUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTWhDLHFCQUFxQmdDLEdBQUc7QUFBQSxvQkFDdkMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkI7QUFBQTtBQUFBLGtCQU43QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxtQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyQkE7QUFBQTtBQUFBO0FBQUEsVUF2REtBLElBQUlGO0FBQUFBLFVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXlEQTtBQUFBLE1BQ0QsS0E1REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZEQTtBQUFBLFNBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5RUEsS0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJFQTtBQUFBLElBSURqQyx5QkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0hBQ2IsaUNBQUMsU0FBSSxXQUFVLDRLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1EQUFrRCxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1DLHlCQUF5QixJQUFJO0FBQUEsWUFDNUMsV0FBVTtBQUFBLFlBRVYsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQTtBQUFBLFVBTHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxSEFDWkQsZ0NBQXNCdUQsY0FBY3ZELHNCQUFzQlcsS0FBSzZDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLFlBQVksS0FEMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxxREFBcUR6RCxnQ0FBc0JXLFFBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsVUFDOUYsdUJBQUMsT0FBRSxXQUFVLDRDQUE0Q1gsZ0NBQXNCWSxTQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLE9BQUUsV0FBVSxzREFBc0RaLGdDQUFzQmEsU0FBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Y7QUFBQSxhQUhqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSxnRUFBK0QsMEJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlGO0FBQUEsWUFDekYsdUJBQUMsVUFBSyxXQUFVLCtDQUErQ2IsZ0NBQXNCZSxjQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRztBQUFBLGVBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZ0VBQStELDZCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RjtBQUFBLFlBQzVGLHVCQUFDLFVBQUssV0FBVSwrQ0FBK0NmLGdDQUFzQmdCLFFBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUEsZUFGNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsVUFBSyxXQUFVLGdFQUErRCwyQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRix1QkFBQyxVQUFLLFdBQVUsZ0RBQWdEaEIsZ0NBQXNCYyxXQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLGFBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscURBQW9ELGlDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLFVBQ3BGLHVCQUFDLFNBQUksV0FBVSwwQ0FBMENkLGdDQUFzQmlCLGlCQUFpQixLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRztBQUFBLGFBRnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFEQUFvRCwrQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRix1QkFBQyxTQUFJLFdBQVUsNENBQTRDakI7QUFBQUEsa0NBQXNCa0Isa0JBQWtCO0FBQUEsWUFBSTtBQUFBLGVBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdHO0FBQUEsYUFGMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU07QUFDYixvQkFBTXlDLFdBQVczRDtBQUNqQkMsdUNBQXlCLElBQUk7QUFDN0JFLG1DQUFxQndELFFBQVE7QUFBQSxZQUMvQjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQWdOO0FBQUE7QUFBQSxVQVA1TjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTFELHlCQUF5QixJQUFJO0FBQUEsY0FDNUMsV0FBVTtBQUFBLGNBQThMO0FBQUE7QUFBQSxZQUgxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUNiLHNCQUFNMkQsU0FBUzVEO0FBQ2ZDLHlDQUF5QixJQUFJO0FBQzdCaUMsZ0NBQWdCMEIsTUFBTTtBQUFBLGNBQ3hCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBaUk7QUFBQTtBQUFBLFlBUDdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUZBLEtBdEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RkE7QUFBQSxJQUlEMUQscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGdIQUNiLGlDQUFDLFNBQUksV0FBVSx3TEFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtSEFDYixpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUscURBQW9ELGlDQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsUUFDbkYsdUJBQUMsT0FBRSxXQUFVLGlEQUErQztBQUFBO0FBQUEsVUFDMUIsdUJBQUMsWUFBTyxXQUFVLGlDQUFpQ0EsNEJBQWtCUyxRQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRTtBQUFBLFVBQVM7QUFBQSxhQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTVIscUJBQXFCLElBQUk7QUFBQSxZQUN4QyxXQUFVO0FBQUEsWUFBZ007QUFBQTtBQUFBLFVBSDVNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU2lDO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQW1JO0FBQUE7QUFBQSxVQUgvSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsSUFJRHhDLGdCQUNDLHVCQUFDLFNBQUksV0FBVSxnSEFDYixpQ0FBQyxTQUFJLFdBQVUsa0tBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsbURBQ1hFLDZCQUFtQixtQkFBbUIsdUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUQsZ0JBQWdCLEtBQUs7QUFBQSxZQUNwQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBO0FBQUEsVUFMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVZ0MscUJBQXFCLFdBQVUsMEJBQzdDO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnR0FBOEYsMkJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osT0FBT3BCLFNBQVNFO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQ21CLE1BQU1wQixZQUFZLEVBQUUsR0FBR0QsVUFBVUUsTUFBTW1CLEVBQUVvQixPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUNsRSxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU13UTtBQUFBLGFBVjFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnR0FBOEYsNkJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixPQUFPMUMsU0FBU0c7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQ2tCLE1BQU1wQixZQUFZLEVBQUUsR0FBR0QsVUFBVUcsT0FBT2tCLEVBQUVvQixPQUFPQyxNQUFNLENBQUM7QUFBQSxnQkFDbkUsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLc1E7QUFBQSxlQVR4UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdHQUE4Riw0QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsYUFBWTtBQUFBLGdCQUNaLE9BQU8xQyxTQUFTSTtBQUFBQSxnQkFDaEIsVUFBVSxDQUFDaUIsTUFBTXBCLFlBQVksRUFBRSxHQUFHRCxVQUFVSSxPQUFPaUIsRUFBRW9CLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGdCQUNuRSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtzUTtBQUFBLGVBVHhRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdHQUE4RixxQ0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU8xQyxTQUFTSztBQUFBQSxjQUNoQixVQUFVLENBQUNnQixNQUFNcEIsWUFBWSxFQUFFLEdBQUdELFVBQVVLLFNBQVNnQixFQUFFb0IsT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDckUsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLd1E7QUFBQSxhQVQxUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0dBQThGLDRCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8xQyxTQUFTTTtBQUFBQSxnQkFDaEIsZUFBZSxDQUFDcUMsUUFBUTFDLFlBQVksRUFBRSxHQUFHRCxVQUFVTSxZQUFZcUMsSUFBSSxDQUFDO0FBQUEsZ0JBRXBFO0FBQUEseUNBQUMsaUJBQWMsV0FBVSx3RkFDdkIsaUNBQUMsZUFBWSxhQUFZLHVCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsaUJBQ0VqQyw0QkFBa0J5QjtBQUFBQSxvQkFBSSxDQUFDUyxTQUN0Qix1QkFBQyxjQUFzQixPQUFPQSxNQUMzQkEsa0JBRGNBLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdHQUE4RixzQkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPNUMsU0FBU087QUFBQUEsZ0JBQ2hCLGVBQWUsQ0FBQ29DLFFBQVExQyxZQUFZLEVBQUUsR0FBR0QsVUFBVU8sTUFBTW9DLElBQUksQ0FBQztBQUFBLGdCQUU5RDtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsd0ZBQ3ZCLGlDQUFDLGVBQVksYUFBWSxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFaEMsc0JBQVl3QjtBQUFBQSxvQkFBSSxDQUFDVSxPQUNoQix1QkFBQyxjQUFvQixPQUFPQSxJQUN6QkEsZ0JBRGNBLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQTtBQUFBO0FBQUEsY0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXpELGdCQUFnQixLQUFLO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBQW9OO0FBQUE7QUFBQSxZQUhoTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUVUQyw2QkFBbUIscUJBQXFCO0FBQUE7QUFBQSxZQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FqSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtIQTtBQUFBLFNBaElGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpSUEsS0FsSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1JQTtBQUFBLE9BeGdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMGdCQTtBQUVKO0FBQUVULEdBM3JCV1IsZ0JBQTZDO0FBQUEsS0FBN0NBO0FBQTZDLElBQUFnRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJQbHVzIiwiU2VhcmNoIiwiVXNlcnMiLCJBd2FyZCIsIkdyYWR1YXRpb25DYXAiLCJCb29rT3BlbiIsIkV5ZSIsIkVkaXQzIiwiVHJhc2gyIiwiWCIsIkNoZWNrQ2lyY2xlMiIsIkJhZGdlIiwiVGFibGUiLCJUYWJsZUhlYWRlciIsIlRhYmxlQm9keSIsIlRhYmxlUm93IiwiVGFibGVDZWxsIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJBY3Rpb25CdXR0b24iLCJWb2x1bnRlZXJzVmlldyIsInZvbHVudGVlcnMiLCJwYW5jaGF5YXRzIiwib25BZGRWb2x1bnRlZXIiLCJvbkVkaXRWb2x1bnRlZXIiLCJvblVwZGF0ZVZvbHVudGVlciIsIm9uRGVsZXRlVm9sdW50ZWVyIiwib25CdWxrSW1wb3J0Vm9sdW50ZWVycyIsIl9zIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzZWxlY3RlZERlcGFydG1lbnQiLCJzZXRTZWxlY3RlZERlcGFydG1lbnQiLCJzZWxlY3RlZFllYXIiLCJzZXRTZWxlY3RlZFllYXIiLCJzaG93QWRkTW9kYWwiLCJzZXRTaG93QWRkTW9kYWwiLCJlZGl0aW5nVm9sdW50ZWVyIiwic2V0RWRpdGluZ1ZvbHVudGVlciIsInZpZXdpbmdNb2RhbFZvbHVudGVlciIsInNldFZpZXdpbmdNb2RhbFZvbHVudGVlciIsInZvbHVudGVlclRvRGVsZXRlIiwic2V0Vm9sdW50ZWVyVG9EZWxldGUiLCJ0b2FzdE1lc3NhZ2UiLCJzZXRUb2FzdE1lc3NhZ2UiLCJzaG93VG9hc3QiLCJtc2ciLCJzZXRUaW1lb3V0IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm5hbWUiLCJlbWFpbCIsInBob25lIiwiY29sbGVnZSIsImRlcGFydG1lbnQiLCJ5ZWFyIiwidG90YWxTZXNzaW9ucyIsImF0dGVuZGFuY2VSYXRlIiwiZGVwYXJ0bWVudE9wdGlvbnMiLCJ5ZWFyT3B0aW9ucyIsImZpbHRlcmVkVm9sdW50ZWVycyIsImZpbHRlciIsInYiLCJtYXRjaFNlYXJjaCIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJtYXRjaERlcHQiLCJtYXRjaFllYXIiLCJoYW5kbGVTYXZlVm9sdW50ZWVyIiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsImlkIiwiaGFuZGxlRWRpdENsaWNrIiwidm9sIiwiaGFuZGxlQ29uZmlybURlbGV0ZSIsInZvbE5hbWUiLCJsZW5ndGgiLCJtb2NrRGF0YSIsImNsdXN0ZXJJZCIsImNsdXN0ZXIiLCJhbGVydCIsIlNldCIsIm1hcCIsInNpemUiLCJNYXRoIiwicm91bmQiLCJyZWR1Y2UiLCJhY2MiLCJ0YXJnZXQiLCJ2YWx1ZSIsInZhbCIsImRlcHQiLCJ5ciIsImF2YXRhclRleHQiLCJzbGljZSIsInRvVXBwZXJDYXNlIiwic3RvcFByb3BhZ2F0aW9uIiwidG9EZWxldGUiLCJ0b0VkaXQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWb2x1bnRlZXJzVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBcbiAgUGx1cywgXG4gIFNlYXJjaCwgXG4gIFVzZXJzLCBcbiAgQXdhcmQsIFxuICBHcmFkdWF0aW9uQ2FwLCBcbiAgQm9va09wZW4sIFxuICBFeWUsIFxuICBFZGl0MywgXG4gIFRyYXNoMiwgXG4gIFgsIFxuICBDaGVja0NpcmNsZTJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgVm9sdW50ZWVyLCBQYW5jaGF5YXQgfSBmcm9tIFwiLi4vdHlwZXNcIjtcbmltcG9ydCBCYWRnZSBmcm9tIFwiLi91aS9iYWRnZVwiO1xuaW1wb3J0IHsgVGFibGUsIFRhYmxlSGVhZGVyLCBUYWJsZUJvZHksIFRhYmxlUm93LCBUYWJsZUNlbGwgfSBmcm9tIFwiLi91aS90YWJsZVwiO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSBcIi4vdWkvc2VsZWN0XCI7XG5pbXBvcnQgeyBBY3Rpb25CdXR0b24gfSBmcm9tIFwiLi91aS9hY3Rpb24tYnV0dG9uXCI7XG5cbmludGVyZmFjZSBWb2x1bnRlZXJzVmlld1Byb3BzIHtcbiAgdm9sdW50ZWVyczogVm9sdW50ZWVyW107XG4gIHBhbmNoYXlhdHM/OiBQYW5jaGF5YXRbXTtcbiAgb25BZGRWb2x1bnRlZXI6IChuZXdWb2w6IE9taXQ8Vm9sdW50ZWVyLCBcImlkXCIgfCBcImF2YXRhclRleHRcIiB8IFwicmVjZW50U2Vzc2lvbnNcIiB8IFwidG90YWxTZXNzaW9uc1wiIHwgXCJhdHRlbmRhbmNlUmF0ZVwiPikgPT4gdm9pZDtcbiAgb25FZGl0Vm9sdW50ZWVyPzogKGlkOiBzdHJpbmcsIHVwZGF0ZWQ6IFBhcnRpYWw8Vm9sdW50ZWVyPikgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWQ7XG4gIG9uVXBkYXRlVm9sdW50ZWVyPzogKGlkOiBzdHJpbmcsIHVwZGF0ZWQ6IFBhcnRpYWw8Vm9sdW50ZWVyPikgPT4gdm9pZDtcbiAgb25EZWxldGVWb2x1bnRlZXI6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkJ1bGtJbXBvcnRWb2x1bnRlZXJzPzogKHZvbHVudGVlcnM6IGFueVtdLCBjbHVzdGVySWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBWb2x1bnRlZXJzVmlldzogUmVhY3QuRkM8Vm9sdW50ZWVyc1ZpZXdQcm9wcz4gPSAoe1xuICB2b2x1bnRlZXJzLFxuICBwYW5jaGF5YXRzID0gW10sXG4gIG9uQWRkVm9sdW50ZWVyLFxuICBvbkVkaXRWb2x1bnRlZXIsXG4gIG9uVXBkYXRlVm9sdW50ZWVyLFxuICBvbkRlbGV0ZVZvbHVudGVlcixcbiAgb25CdWxrSW1wb3J0Vm9sdW50ZWVycyxcbn0pID0+IHtcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzZWxlY3RlZERlcGFydG1lbnQsIHNldFNlbGVjdGVkRGVwYXJ0bWVudF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NlbGVjdGVkWWVhciwgc2V0U2VsZWN0ZWRZZWFyXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc2hvd0FkZE1vZGFsLCBzZXRTaG93QWRkTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdGluZ1ZvbHVudGVlciwgc2V0RWRpdGluZ1ZvbHVudGVlcl0gPSB1c2VTdGF0ZTxWb2x1bnRlZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3ZpZXdpbmdNb2RhbFZvbHVudGVlciwgc2V0Vmlld2luZ01vZGFsVm9sdW50ZWVyXSA9IHVzZVN0YXRlPFZvbHVudGVlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdm9sdW50ZWVyVG9EZWxldGUsIHNldFZvbHVudGVlclRvRGVsZXRlXSA9IHVzZVN0YXRlPFZvbHVudGVlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdG9hc3RNZXNzYWdlLCBzZXRUb2FzdE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3Qgc2hvd1RvYXN0ID0gKG1zZzogc3RyaW5nKSA9PiB7XG4gICAgc2V0VG9hc3RNZXNzYWdlKG1zZyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRUb2FzdE1lc3NhZ2UobnVsbCk7XG4gICAgfSwgNDAwMCk7XG4gIH07XG5cbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XG4gICAgbmFtZTogXCJcIixcbiAgICBlbWFpbDogXCJcIixcbiAgICBwaG9uZTogXCIrOTEgXCIsXG4gICAgY29sbGVnZTogXCJHb3Zlcm5tZW50IENvbGxlZ2Ugb2YgRW5naW5lZXJpbmcsIERoYXJtYXB1cmlcIixcbiAgICBkZXBhcnRtZW50OiBcIkNvbXB1dGVyIFNjaWVuY2UgYW5kIEVuZ2luZWVyaW5nXCIsXG4gICAgeWVhcjogXCI0dGggWWVhclwiLFxuICAgIHRvdGFsU2Vzc2lvbnM6IDAsXG4gICAgYXR0ZW5kYW5jZVJhdGU6IDEwMCxcbiAgfSk7XG5cbiAgY29uc3QgZGVwYXJ0bWVudE9wdGlvbnMgPSBbXG4gICAgXCJDb21wdXRlciBTY2llbmNlIGFuZCBFbmdpbmVlcmluZ1wiLFxuICAgIFwiRWxlY3Ryb25pY3MgYW5kIENvbW11bmljYXRpb24gRW5naW5lZXJpbmdcIixcbiAgICBcIk1lY2hhbmljYWwgRW5naW5lZXJpbmdcIixcbiAgICBcIkluZm9ybWF0aW9uIFRlY2hub2xvZ3lcIixcbiAgICBcIkVsZWN0cmljYWwgYW5kIEVsZWN0cm9uaWNzIEVuZ2luZWVyaW5nXCIsXG4gICAgXCJDaXZpbCBFbmdpbmVlcmluZ1wiLFxuICAgIFwiQmlvdGVjaG5vbG9neVwiLFxuICAgIFwiQXJ0aWZpY2lhbCBJbnRlbGxpZ2VuY2UgJiBEYXRhIFNjaWVuY2VcIixcbiAgICBcIkFydHMgJiBTY2llbmNlIC8gQ29tbWVyY2VcIixcbiAgXTtcblxuICBjb25zdCB5ZWFyT3B0aW9ucyA9IFtcbiAgICBcIjFzdCBZZWFyXCIsXG4gICAgXCIybmQgWWVhclwiLFxuICAgIFwiM3JkIFllYXJcIixcbiAgICBcIjR0aCBZZWFyXCIsXG4gICAgXCJQb3N0IEdyYWR1YXRlXCIsXG4gICAgXCJBbHVtbnVzXCIsXG4gIF07XG5cbiAgY29uc3QgZmlsdGVyZWRWb2x1bnRlZXJzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHZvbHVudGVlcnMuZmlsdGVyKCh2KSA9PiB7XG4gICAgICBjb25zdCBtYXRjaFNlYXJjaCA9XG4gICAgICAgIHYubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgdi5lbWFpbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgdi5waG9uZS5pbmNsdWRlcyhzZWFyY2hUZXJtKSB8fFxuICAgICAgICAodi5jb2xsZWdlICYmIHYuY29sbGVnZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkpIHx8XG4gICAgICAgICh2LmRlcGFydG1lbnQgJiYgdi5kZXBhcnRtZW50LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSk7XG5cbiAgICAgIGNvbnN0IG1hdGNoRGVwdCA9ICFzZWxlY3RlZERlcGFydG1lbnQgfHwgdi5kZXBhcnRtZW50ID09PSBzZWxlY3RlZERlcGFydG1lbnQ7XG4gICAgICBjb25zdCBtYXRjaFllYXIgPSAhc2VsZWN0ZWRZZWFyIHx8IHYueWVhciA9PT0gc2VsZWN0ZWRZZWFyO1xuXG4gICAgICByZXR1cm4gbWF0Y2hTZWFyY2ggJiYgbWF0Y2hEZXB0ICYmIG1hdGNoWWVhcjtcbiAgICB9KTtcbiAgfSwgW3ZvbHVudGVlcnMsIHNlYXJjaFRlcm0sIHNlbGVjdGVkRGVwYXJ0bWVudCwgc2VsZWN0ZWRZZWFyXSk7XG5cbiAgY29uc3QgaGFuZGxlU2F2ZVZvbHVudGVlciA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFmb3JtRGF0YS5uYW1lLnRyaW0oKSkge1xuICAgICAgc2hvd1RvYXN0KFwiUGxlYXNlIGVudGVyIHZvbHVudGVlciBuYW1lXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChlZGl0aW5nVm9sdW50ZWVyKSB7XG4gICAgICBpZiAob25FZGl0Vm9sdW50ZWVyKSB7XG4gICAgICAgIG9uRWRpdFZvbHVudGVlcihlZGl0aW5nVm9sdW50ZWVyLmlkLCB7XG4gICAgICAgICAgbmFtZTogZm9ybURhdGEubmFtZS50cmltKCksXG4gICAgICAgICAgZW1haWw6IGZvcm1EYXRhLmVtYWlsLnRyaW0oKSxcbiAgICAgICAgICBwaG9uZTogZm9ybURhdGEucGhvbmUudHJpbSgpLFxuICAgICAgICAgIGNvbGxlZ2U6IGZvcm1EYXRhLmNvbGxlZ2UudHJpbSgpLFxuICAgICAgICAgIGRlcGFydG1lbnQ6IGZvcm1EYXRhLmRlcGFydG1lbnQsXG4gICAgICAgICAgeWVhcjogZm9ybURhdGEueWVhcixcbiAgICAgICAgICB0b3RhbFNlc3Npb25zOiBmb3JtRGF0YS50b3RhbFNlc3Npb25zLFxuICAgICAgICAgIGF0dGVuZGFuY2VSYXRlOiBmb3JtRGF0YS5hdHRlbmRhbmNlUmF0ZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKG9uVXBkYXRlVm9sdW50ZWVyKSB7XG4gICAgICAgIG9uVXBkYXRlVm9sdW50ZWVyKGVkaXRpbmdWb2x1bnRlZXIuaWQsIHtcbiAgICAgICAgICBuYW1lOiBmb3JtRGF0YS5uYW1lLnRyaW0oKSxcbiAgICAgICAgICBlbWFpbDogZm9ybURhdGEuZW1haWwudHJpbSgpLFxuICAgICAgICAgIHBob25lOiBmb3JtRGF0YS5waG9uZS50cmltKCksXG4gICAgICAgICAgY29sbGVnZTogZm9ybURhdGEuY29sbGVnZS50cmltKCksXG4gICAgICAgICAgZGVwYXJ0bWVudDogZm9ybURhdGEuZGVwYXJ0bWVudCxcbiAgICAgICAgICB5ZWFyOiBmb3JtRGF0YS55ZWFyLFxuICAgICAgICAgIHRvdGFsU2Vzc2lvbnM6IGZvcm1EYXRhLnRvdGFsU2Vzc2lvbnMsXG4gICAgICAgICAgYXR0ZW5kYW5jZVJhdGU6IGZvcm1EYXRhLmF0dGVuZGFuY2VSYXRlLFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKHZpZXdpbmdNb2RhbFZvbHVudGVlcj8uaWQgPT09IGVkaXRpbmdWb2x1bnRlZXIuaWQpIHtcbiAgICAgICAgc2V0Vmlld2luZ01vZGFsVm9sdW50ZWVyKHtcbiAgICAgICAgICAuLi52aWV3aW5nTW9kYWxWb2x1bnRlZXIsXG4gICAgICAgICAgbmFtZTogZm9ybURhdGEubmFtZS50cmltKCksXG4gICAgICAgICAgZW1haWw6IGZvcm1EYXRhLmVtYWlsLnRyaW0oKSxcbiAgICAgICAgICBwaG9uZTogZm9ybURhdGEucGhvbmUudHJpbSgpLFxuICAgICAgICAgIGNvbGxlZ2U6IGZvcm1EYXRhLmNvbGxlZ2UudHJpbSgpLFxuICAgICAgICAgIGRlcGFydG1lbnQ6IGZvcm1EYXRhLmRlcGFydG1lbnQsXG4gICAgICAgICAgeWVhcjogZm9ybURhdGEueWVhcixcbiAgICAgICAgICB0b3RhbFNlc3Npb25zOiBmb3JtRGF0YS50b3RhbFNlc3Npb25zLFxuICAgICAgICAgIGF0dGVuZGFuY2VSYXRlOiBmb3JtRGF0YS5hdHRlbmRhbmNlUmF0ZSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHNob3dUb2FzdChcIlVwZGF0ZWQgdm9sdW50ZWVyIFwiICsgZm9ybURhdGEubmFtZSk7XG4gICAgICBzZXRFZGl0aW5nVm9sdW50ZWVyKG51bGwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBvbkFkZFZvbHVudGVlcih7XG4gICAgICAgIG5hbWU6IGZvcm1EYXRhLm5hbWUudHJpbSgpLFxuICAgICAgICBlbWFpbDogZm9ybURhdGEuZW1haWwudHJpbSgpLFxuICAgICAgICBwaG9uZTogZm9ybURhdGEucGhvbmUudHJpbSgpLFxuICAgICAgICBjb2xsZWdlOiBmb3JtRGF0YS5jb2xsZWdlLnRyaW0oKSxcbiAgICAgICAgZGVwYXJ0bWVudDogZm9ybURhdGEuZGVwYXJ0bWVudCxcbiAgICAgICAgeWVhcjogZm9ybURhdGEueWVhcixcbiAgICAgIH0pO1xuICAgICAgc2hvd1RvYXN0KFwiQWRkZWQgdm9sdW50ZWVyIFwiICsgZm9ybURhdGEubmFtZSk7XG4gICAgfVxuXG4gICAgc2V0U2hvd0FkZE1vZGFsKGZhbHNlKTtcbiAgICBzZXRGb3JtRGF0YSh7XG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgZW1haWw6IFwiXCIsXG4gICAgICBwaG9uZTogXCIrOTEgXCIsXG4gICAgICBjb2xsZWdlOiBcIkdvdmVybm1lbnQgQ29sbGVnZSBvZiBFbmdpbmVlcmluZywgRGhhcm1hcHVyaVwiLFxuICAgICAgZGVwYXJ0bWVudDogXCJDb21wdXRlciBTY2llbmNlIGFuZCBFbmdpbmVlcmluZ1wiLFxuICAgICAgeWVhcjogXCI0dGggWWVhclwiLFxuICAgICAgdG90YWxTZXNzaW9uczogMCxcbiAgICAgIGF0dGVuZGFuY2VSYXRlOiAxMDAsXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRWRpdENsaWNrID0gKHZvbDogVm9sdW50ZWVyKSA9PiB7XG4gICAgc2V0RWRpdGluZ1ZvbHVudGVlcih2b2wpO1xuICAgIHNldEZvcm1EYXRhKHtcbiAgICAgIG5hbWU6IHZvbC5uYW1lLFxuICAgICAgZW1haWw6IHZvbC5lbWFpbCxcbiAgICAgIHBob25lOiB2b2wucGhvbmUsXG4gICAgICBjb2xsZWdlOiB2b2wuY29sbGVnZSB8fCBcIkdvdmVybm1lbnQgQ29sbGVnZSBvZiBFbmdpbmVlcmluZywgRGhhcm1hcHVyaVwiLFxuICAgICAgZGVwYXJ0bWVudDogdm9sLmRlcGFydG1lbnQgfHwgXCJDb21wdXRlciBTY2llbmNlIGFuZCBFbmdpbmVlcmluZ1wiLFxuICAgICAgeWVhcjogdm9sLnllYXIgfHwgXCI0dGggWWVhclwiLFxuICAgICAgdG90YWxTZXNzaW9uczogdm9sLnRvdGFsU2Vzc2lvbnMgfHwgMCxcbiAgICAgIGF0dGVuZGFuY2VSYXRlOiB2b2wuYXR0ZW5kYW5jZVJhdGUgfHwgMTAwLFxuICAgIH0pO1xuICAgIHNldFNob3dBZGRNb2RhbCh0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDb25maXJtRGVsZXRlID0gKCkgPT4ge1xuICAgIGlmICghdm9sdW50ZWVyVG9EZWxldGUpIHJldHVybjtcbiAgICBjb25zdCB2b2xOYW1lID0gdm9sdW50ZWVyVG9EZWxldGUubmFtZTtcbiAgICBvbkRlbGV0ZVZvbHVudGVlcih2b2x1bnRlZXJUb0RlbGV0ZS5pZCk7XG5cbiAgICBpZiAodmlld2luZ01vZGFsVm9sdW50ZWVyPy5pZCA9PT0gdm9sdW50ZWVyVG9EZWxldGUuaWQpIHtcbiAgICAgIHNldFZpZXdpbmdNb2RhbFZvbHVudGVlcihudWxsKTtcbiAgICB9XG5cbiAgICBzaG93VG9hc3QoXCJWb2x1bnRlZXIgXCIgKyB2b2xOYW1lICsgXCIgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XG4gICAgc2V0Vm9sdW50ZWVyVG9EZWxldGUobnVsbCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTZcIj5cbiAgICAgIHt0b2FzdE1lc3NhZ2UgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS02IHJpZ2h0LTYgei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYmctZ3JheS05MDAgcHgtNCBweS0zIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS1sZyBkYXJrOmJnLXdoaXRlIGRhcms6dGV4dC1ncmF5LTkwMCBhbmltYXRlLWluIGZhZGUtaW4tMCBzbGlkZS1pbi1mcm9tLWJvdHRvbS01XCI+XG4gICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtc3VjY2Vzcy01MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIDxzcGFuPnt0b2FzdE1lc3NhZ2V9PC9zcGFuPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VG9hc3RNZXNzYWdlKG51bGwpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtd2hpdGUgZGFyazpob3Zlcjp0ZXh0LWdyYXktOTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBWb2x1bnRlZXJzICYgTWVudG9ycyBEaXJlY3RvcnlcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIHt2b2x1bnRlZXJzLmxlbmd0aH0gQWN0aXZlXG4gICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgUm9zdGVyIG9mIGNvbGxlZ2Ugdm9sdW50ZWVycywgZGVwYXJ0bWVudCBzcGVjaWFsaXphdGlvbnMsIGFuZCBhdHRlbmRhbmNlIHBlcmZvcm1hbmNlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgIDxBY3Rpb25CdXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgaWYgKG9uQnVsa0ltcG9ydFZvbHVudGVlcnMpIHtcbiAgICAgICAgICAgICAgICAvLyBJbiBhIGZ1bGwgaW1wbGVtZW50YXRpb24sIHRoaXMgd291bGQgb3BlbiBhIG1vZGFsIHdpdGggYSBmaWxlIGlucHV0XG4gICAgICAgICAgICAgICAgLy8gRm9yIG5vdywgd2UnbGwganVzdCB0cmlnZ2VyIGl0IHdpdGggYW4gZW1wdHkgYXJyYXkgb3IgYmFzaWMgbW9jayBkYXRhIHRvIHNob3cgaXQncyB3aXJlZCB1cFxuICAgICAgICAgICAgICAgIC8vIFR5cGljYWxseSB5b3UnZCBoYXZlIGFuIGA8aW5wdXQgdHlwZT1cImZpbGVcIiAvPmAgYW5kIHJlYWQgaXQuXG4gICAgICAgICAgICAgICAgLy8gU2luY2UgdGhpcyBjb21wb25lbnQgZGlkbid0IGhhdmUgdGhlIGJ1bGsgaW1wb3J0IG1vZGFsIFVJIGFscmVhZHkgbGlrZSBTdHVkZW50c1ZpZXcgZGlkLFxuICAgICAgICAgICAgICAgIC8vIHdlJ2xsIGp1c3Qgd2lyZSB1cCBhIHNpbXBsZSBoYW5kbGVyLlxuICAgICAgICAgICAgICAgIGNvbnN0IG1vY2tEYXRhID0gW3sgbmFtZTogJ1Rlc3QgVm9sJywgZW1haWw6ICd0ZXN0QHZvbC5jb20nLCBwaG9uZTogJzEyMycgfV07XG4gICAgICAgICAgICAgICAgY29uc3QgY2x1c3RlcklkID0gcGFuY2hheWF0cy5sZW5ndGggPiAwID8gKHBhbmNoYXlhdHNbMF0uY2x1c3RlcklkIHx8IHBhbmNoYXlhdHNbMF0uY2x1c3RlciB8fCAnJykgOiAnJztcbiAgICAgICAgICAgICAgICBvbkJ1bGtJbXBvcnRWb2x1bnRlZXJzKG1vY2tEYXRhLCBjbHVzdGVySWQpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGFsZXJ0KCdCdWxrIGltcG9ydCBmdW5jdGlvbmFsaXR5IGlzIG5vdCBjb25uZWN0ZWQgeWV0LicpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBCdWxrIEltcG9ydFxuICAgICAgICAgIDwvQWN0aW9uQnV0dG9uPlxuXG4gICAgICAgICAgPEFjdGlvbkJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICBzZXRFZGl0aW5nVm9sdW50ZWVyKG51bGwpO1xuICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJcIixcbiAgICAgICAgICAgICAgICBlbWFpbDogXCJcIixcbiAgICAgICAgICAgICAgICBwaG9uZTogXCIrOTEgXCIsXG4gICAgICAgICAgICAgICAgY29sbGVnZTogXCJHb3Zlcm5tZW50IENvbGxlZ2Ugb2YgRW5naW5lZXJpbmcsIERoYXJtYXB1cmlcIixcbiAgICAgICAgICAgICAgICBkZXBhcnRtZW50OiBcIkNvbXB1dGVyIFNjaWVuY2UgYW5kIEVuZ2luZWVyaW5nXCIsXG4gICAgICAgICAgICAgICAgeWVhcjogXCI0dGggWWVhclwiLFxuICAgICAgICAgICAgICAgIHRvdGFsU2Vzc2lvbnM6IDAsXG4gICAgICAgICAgICAgICAgYXR0ZW5kYW5jZVJhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHNldFNob3dBZGRNb2RhbCh0cnVlKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgdmFyaWFudD1cInByaW1hcnlcIlxuICAgICAgICAgICAgaWNvbj17PFBsdXMgc2l6ZT17MTV9IC8+fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIEFkZCBWb2x1bnRlZXJcbiAgICAgICAgICA8L0FjdGlvbkJ1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc206cC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+VG90YWwgTWVudG9yczwvc3Bhbj5cbiAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtYnJhbmQtNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZvbHVudGVlcnMubGVuZ3RofTwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC00IHNtOnAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkRlcGFydG1lbnRzPC9zcGFuPlxuICAgICAgICAgICAgPEJvb2tPcGVuIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1zdWNjZXNzLTUwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAge25ldyBTZXQodm9sdW50ZWVycy5tYXAodiA9PiB2LmRlcGFydG1lbnQpKS5zaXplfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC00IHNtOnAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkF2ZyBBdHRlbmRhbmNlPC9zcGFuPlxuICAgICAgICAgICAgPEF3YXJkIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC10aGVtZS1wdXJwbGUtNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICB7dm9sdW50ZWVycy5sZW5ndGggPiAwIFxuICAgICAgICAgICAgICA/IE1hdGgucm91bmQodm9sdW50ZWVycy5yZWR1Y2UoKGFjYywgdikgPT4gYWNjICsgKHYuYXR0ZW5kYW5jZVJhdGUgfHwgMTAwKSwgMCkgLyB2b2x1bnRlZXJzLmxlbmd0aCkgKyBcIiVcIlxuICAgICAgICAgICAgICA6IFwiMTAwJVwifVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC00IHNtOnAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkZpbmFsIFllYXI8L3NwYW4+XG4gICAgICAgICAgICA8R3JhZHVhdGlvbkNhcCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtd2FybmluZy01MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgIHt2b2x1bnRlZXJzLmZpbHRlcih2ID0+IHYueWVhciAmJiB2LnllYXIuaW5jbHVkZXMoXCI0dGhcIikpLmxlbmd0aH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctc21cIj5cbiAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBuYW1lLCBkZXBhcnRtZW50LCBjb2xsZWdlLi4uXCJcbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcGwtMTAgcHItNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTgwMCBzaGFkb3ctdGhlbWUteHMgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNTAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQ4XCI+XG4gICAgICAgICAgICA8U2VsZWN0XG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERlcGFydG1lbnQgfHwgXCJhbGxcIn1cbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWREZXBhcnRtZW50KHZhbCA9PT0gXCJhbGxcIiA/IFwiXCIgOiB2YWwpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBEZXBhcnRtZW50c1wiIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgRGVwYXJ0bWVudHM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAge2RlcGFydG1lbnRPcHRpb25zLm1hcCgoZGVwdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtkZXB0fSB2YWx1ZT17ZGVwdH0+XG4gICAgICAgICAgICAgICAgICAgIHtkZXB0fVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0zMlwiPlxuICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRZZWFyIHx8IFwiYWxsXCJ9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkWWVhcih2YWwgPT09IFwiYWxsXCIgPyBcIlwiIDogdmFsKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgWWVhcnNcIiAvPlxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFllYXJzPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIHt5ZWFyT3B0aW9ucy5tYXAoKHlyKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3lyfSB2YWx1ZT17eXJ9PlxuICAgICAgICAgICAgICAgICAgICB7eXJ9XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMCBtbC1hdXRvIG1kOm1sLTFcIj5cbiAgICAgICAgICAgIHtmaWx0ZXJlZFZvbHVudGVlcnMubGVuZ3RofSBvZiB7dm9sdW50ZWVycy5sZW5ndGh9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZmlsdGVyZWRWb2x1bnRlZXJzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJteC1hdXRvIGgtMTIgdy0xMiB0ZXh0LWdyYXktMzAwIGRhcms6dGV4dC1ncmF5LTYwMFwiIC8+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj5ObyB2b2x1bnRlZXJzIGZvdW5kPC9oMz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgIHtzZWFyY2hUZXJtIHx8IHNlbGVjdGVkRGVwYXJ0bWVudCB8fCBzZWxlY3RlZFllYXIgPyBcIlRyeSBjbGVhcmluZyB5b3VyIGZpbHRlcnMuXCIgOiBcIkFkZCB5b3VyIGZpcnN0IHZvbHVudGVlciBtZW50b3IgdG8gZ2V0IHN0YXJ0ZWQuXCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgPFRhYmxlPlxuICAgICAgICAgICAgPFRhYmxlSGVhZGVyPlxuICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlciBjbGFzc05hbWU9XCJ3LVsyNjBweF1cIj5Wb2x1bnRlZXIgTmFtZTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+RGVwYXJ0bWVudDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+WWVhcjwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+Q29sbGVnZTwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+Q29udGFjdDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXIgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPkFjdGlvbnM8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICAgIDwvVGFibGVIZWFkZXI+XG4gICAgICAgICAgICA8VGFibGVCb2R5PlxuICAgICAgICAgICAgICB7ZmlsdGVyZWRWb2x1bnRlZXJzLm1hcCgodm9sKSA9PiAoXG4gICAgICAgICAgICAgICAgPFRhYmxlUm93XG4gICAgICAgICAgICAgICAgICBrZXk9e3ZvbC5pZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdNb2RhbFZvbHVudGVlcih2b2wpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MC84MCBkYXJrOmhvdmVyOmJnLXdoaXRlL1swLjAyXSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTkgdy05IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctYnJhbmQtNTAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgZGFyazpiZy1icmFuZC01MDAvMTAgZGFyazp0ZXh0LWJyYW5kLTQwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3ZvbC5hdmF0YXJUZXh0IHx8IHZvbC5uYW1lLnNsaWNlKDAsIDIpLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZvbC5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt2b2wuZGVwYXJ0bWVudH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJsaWdodFwiIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt2b2wueWVhcn1cbiAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0ZXh0LXhzIG1heC13LVsyMDBweF0gdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3ZvbC5jb2xsZWdlIHx8IFwi4oCUXCJ9XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge3ZvbC5waG9uZX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTFcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3aW5nTW9kYWxWb2x1bnRlZXIodm9sKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJWaWV3IGRldGFpbHNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFZGl0Q2xpY2sodm9sKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXQgdm9sdW50ZWVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWb2x1bnRlZXJUb0RlbGV0ZSh2b2wpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNTAwIGhvdmVyOmJnLWVycm9yLTUwIGhvdmVyOnRleHQtZXJyb3ItNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOmJnLWVycm9yLTUwMC8xMCBkYXJrOmhvdmVyOnRleHQtZXJyb3ItNDAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgdm9sdW50ZWVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgICAgPC9UYWJsZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVmlldyBWb2x1bnRlZXIgRGV0YWlscyBNb2RhbCAqL31cbiAgICAgIHt2aWV3aW5nTW9kYWxWb2x1bnRlZXIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LXktYXV0byBiZy1ncmF5LTkwMC83NSBwLTQgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LWxnIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC02IHNoYWRvdy10aGVtZS14bCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTUgc3BhY2UteS01XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5Wb2x1bnRlZXIgUHJvZmlsZTwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3aW5nTW9kYWxWb2x1bnRlZXIobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCByb3VuZGVkLXhsIGJnLWdyYXktNTAvODAgcC00IGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTE0IHctMTQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1icmFuZC01MDAgdGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHNcIj5cbiAgICAgICAgICAgICAgICB7dmlld2luZ01vZGFsVm9sdW50ZWVyLmF2YXRhclRleHQgfHwgdmlld2luZ01vZGFsVm9sdW50ZWVyLm5hbWUuc2xpY2UoMCwgMikudG9VcHBlckNhc2UoKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPnt2aWV3aW5nTW9kYWxWb2x1bnRlZXIubmFtZX08L2g0PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57dmlld2luZ01vZGFsVm9sdW50ZWVyLmVtYWlsfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPnt2aWV3aW5nTW9kYWxWb2x1bnRlZXIucGhvbmV9PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00IHRleHQteHMgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRleHQtZ3JheS00MDAgYmxvY2sgbWItMVwiPkRlcGFydG1lbnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZpZXdpbmdNb2RhbFZvbHVudGVlci5kZXBhcnRtZW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1ncmF5LTQwMCBibG9jayBtYi0xXCI+WWVhciBvZiBTdHVkeTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57dmlld2luZ01vZGFsVm9sdW50ZWVyLnllYXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0ZXh0LWdyYXktNDAwIGJsb2NrIG1iLTFcIj5JbnN0aXR1dGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPnt2aWV3aW5nTW9kYWxWb2x1bnRlZXIuY29sbGVnZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTMgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDBcIj5TZXNzaW9ucyBBdHRlbmRlZDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYnJhbmQtNTAwIG10LTFcIj57dmlld2luZ01vZGFsVm9sdW50ZWVyLnRvdGFsU2Vzc2lvbnMgfHwgMH08L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtMyBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMFwiPkF0dGVuZGFuY2UgUmF0ZTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc3VjY2Vzcy01MDAgbXQtMVwiPnt2aWV3aW5nTW9kYWxWb2x1bnRlZXIuYXR0ZW5kYW5jZVJhdGUgfHwgMTAwfSU8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHRvRGVsZXRlID0gdmlld2luZ01vZGFsVm9sdW50ZWVyO1xuICAgICAgICAgICAgICAgICAgc2V0Vmlld2luZ01vZGFsVm9sdW50ZWVyKG51bGwpO1xuICAgICAgICAgICAgICAgICAgc2V0Vm9sdW50ZWVyVG9EZWxldGUodG9EZWxldGUpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCBiZy1lcnJvci01MCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1lcnJvci02MDAgaG92ZXI6YmctZXJyb3ItMTAwIGRhcms6Ym9yZGVyLWVycm9yLTkwMC80MCBkYXJrOmJnLWVycm9yLTUwMC8xMCBkYXJrOnRleHQtZXJyb3ItNDAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRGVsZXRlIFZvbHVudGVlclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3aW5nTW9kYWxWb2x1bnRlZXIobnVsbCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2xvc2VcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdG9FZGl0ID0gdmlld2luZ01vZGFsVm9sdW50ZWVyO1xuICAgICAgICAgICAgICAgICAgICBzZXRWaWV3aW5nTW9kYWxWb2x1bnRlZXIobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUVkaXRDbGljayh0b0VkaXQpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctYnJhbmQtNTAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEVkaXQgVm9sdW50ZWVyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIERlbGV0ZSBDb25maXJtYXRpb24gTW9kYWwgKi99XG4gICAgICB7dm9sdW50ZWVyVG9EZWxldGUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LXktYXV0byBiZy1ncmF5LTkwMC83NSBwLTQgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC02IHNoYWRvdy10aGVtZS14bCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIHRleHQtY2VudGVyIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBoLTEyIHctMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1lcnJvci01MCB0ZXh0LWVycm9yLTUwMCBkYXJrOmJnLWVycm9yLTUwMC8xMFwiPlxuICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPkRlbGV0ZSBWb2x1bnRlZXI/PC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHJlbW92ZSA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZvbHVudGVlclRvRGVsZXRlLm5hbWV9PC9zdHJvbmc+IGZyb20gdGhlIGRpcmVjdG9yeT9cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yLjUgcHQtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vm9sdW50ZWVyVG9EZWxldGUobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25maXJtRGVsZXRlfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSByb3VuZGVkLXhsIGJnLWVycm9yLTUwMCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1lcnJvci02MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBZZXMsIERlbGV0ZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBBZGQvRWRpdCBWb2x1bnRlZXIgTW9kYWwgKi99XG4gICAgICB7c2hvd0FkZE1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy15LWF1dG8gYmctZ3JheS05MDAvNzUgcC00IGJhY2tkcm9wLWJsdXItc21cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3ctdGhlbWUteGwgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBhbmltYXRlLWluIGZhZGUtaW4tMCB6b29tLWluLTk1XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7ZWRpdGluZ1ZvbHVudGVlciA/IFwiRWRpdCBWb2x1bnRlZXJcIiA6IFwiQWRkIE5ldyBWb2x1bnRlZXJcIn1cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaC04IHctOCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNhdmVWb2x1bnRlZXJ9IGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSAqXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHZvbHVudGVlciBuYW1lXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5uYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgRW1haWwgQWRkcmVzc1xuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInlvdUBjb2xsZWdlLmVkdVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbWFpbDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIgdGV4dC14cyB0ZXh0LWdyYXktODAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwLzEwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiKzkxIDk4NzY1IDQzMjEwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBob25lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIENvbGxlZ2UgLyBJbnN0aXR1dGlvblxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gR292ZXJubWVudCBDb2xsZWdlIG9mIEVuZ2luZWVyaW5nLCBEaGFybWFwdXJpXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb2xsZWdlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBjb2xsZWdlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgRGVwYXJ0bWVudCAqXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGVwYXJ0bWVudH1cbiAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZGVwYXJ0bWVudDogdmFsIH0pfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCB0ZXh0LXhzIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGVwYXJ0bWVudFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgICAge2RlcGFydG1lbnRPcHRpb25zLm1hcCgoZGVwdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtkZXB0fSB2YWx1ZT17ZGVwdH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkZXB0fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgWWVhciAqXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEueWVhcn1cbiAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgeWVhcjogdmFsIH0pfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCB0ZXh0LXhzIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgWWVhclwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgICAge3llYXJPcHRpb25zLm1hcCgoeXIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17eXJ9IHZhbHVlPXt5cn0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt5cn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctYnJhbmQtNTAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtlZGl0aW5nVm9sdW50ZWVyID8gXCJVcGRhdGUgVm9sdW50ZWVyXCIgOiBcIlNhdmUgVm9sdW50ZWVyXCJ9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1ZvbHVudGVlcnNWaWV3LnRzeCJ9