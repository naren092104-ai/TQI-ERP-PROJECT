import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useCallback = __vite__cjsImport1_react["useCallback"];
import { Navigation } from "/src/components/Navigation.tsx";
import { LoginPage } from "/src/components/LoginPage.tsx";
import { DashboardView } from "/src/components/DashboardView.tsx";
import { ApprovalCenterView } from "/src/components/ApprovalCenterView.tsx";
import { ClustersView } from "/src/components/ClustersView.tsx";
import { AuditLogView } from "/src/components/AuditLogView.tsx";
import { UserManagementView } from "/src/components/UserManagementView.tsx";
import { PanchayatsView } from "/src/components/PanchayatsView.tsx";
import { PanchayatDetailView } from "/src/components/PanchayatDetailView.tsx";
import { StudentsView } from "/src/components/StudentsView.tsx?t=1787664734569";
import { VolunteersView } from "/src/components/VolunteersView.tsx?t=1787664331692";
import { SessionsView } from "/src/components/SessionsView.tsx?t=1787664727125";
import { AttendanceView } from "/src/components/AttendanceView.tsx";
import { LessonPlanView } from "/src/components/LessonPlanView.tsx?t=1787664706362";
import { SessionPhotosView } from "/src/components/SessionPhotosView.tsx?t=1787664718568";
import { FinanceView } from "/src/components/FinanceView.tsx";
import { FinanceStatementView } from "/src/components/FinanceStatementView.tsx?t=1787665964082";
import { ReportsView } from "/src/components/ReportsView.tsx";
import { ReportPreviewView } from "/src/components/ReportPreviewView.tsx";
import { NotificationsView } from "/src/components/NotificationsView.tsx";
import { SettingsView } from "/src/components/SettingsView.tsx";
import { ModuleLibraryView } from "/src/components/ModuleLibraryView.tsx?t=1787665598286";
import { AcademicSetupView } from "/src/components/AcademicSetupView.tsx";
import { Header } from "/src/components/Header.tsx";
import { ErrorBoundary } from "/src/components/ErrorBoundary.tsx";
import DateChangeRequestView from "/src/components/DateChangeRequestView.tsx?t=1787664362460";
import SessionReportView from "/src/components/SessionReportView.tsx?t=1787665768053";
import SessionSubmissionView from "/src/components/SessionSubmissionView.tsx?t=1787664389659";
import { apiUrl } from "/src/utils/api.ts";
export default function App() {
  _s();
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem("tqi_auth_session");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
    }
    return null;
  });
  const [currentUserRole, setCurrentUserRole] = useState(currentUser?.role || "Super Admin");
  const [currentUserClusterId, setCurrentUserClusterId] = useState(currentUser?.clusterId || "all");
  const [currentTab, setCurrentTab] = useState(() => {
    try {
      const savedTab = localStorage.getItem(`tqi_current_tab_${currentUser?.role || "Super Admin"}`);
      return savedTab === "academic-setup" && currentUser?.role !== "Super Admin" ? "dashboard" : savedTab || "dashboard";
    } catch {
      return "dashboard";
    }
  });
  const [selectedPanchayatId, setSelectedPanchayatId] = useState("vedakkattamaduvu");
  const [initialStudentFilters, setInitialStudentFilters] = useState(void 0);
  const [activeDraftId, setActiveDraftId] = useState(void 0);
  const [activeFinanceDraftId, setActiveFinanceDraftId] = useState(void 0);
  const [openNewFinanceModal, setOpenNewFinanceModal] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [selectedLessonPlanId, setSelectedLessonPlanId] = useState(void 0);
  useEffect(() => {
    try {
      localStorage.setItem(`tqi_current_tab_${currentUserRole}`, currentTab);
    } catch {
    }
  }, [currentTab, currentUserRole]);
  const [clusters, setClusters] = useState([]);
  const [users, setUsers] = useState([]);
  const [approvals, setApprovals] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [panchayats, setPanchayats] = useState([]);
  const [students, setStudents] = useState([]);
  const [volunteers, setVolunteers] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [attendanceSessions, setAttendanceSessions] = useState([]);
  const [financeEntries, setFinanceEntries] = useState([]);
  const [financeDrafts, setFinanceDrafts] = useState([]);
  const [lessonPlans, setLessonPlans] = useState([]);
  const [photoGroups, setPhotoGroups] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [dateChangeRequests, setDateChangeRequests] = useState([]);
  const [sessionReports, setSessionReports] = useState([]);
  const [sessionSubmissions, setSessionSubmissions] = useState([]);
  const [academicYears, setAcademicYears] = useState([]);
  const [modules, setModules] = useState([]);
  const fetchBackendData = useCallback(async (signal) => {
    if (!currentUser?.token) return;
    await new Promise((resolve) => {
      const t = setTimeout(resolve, 300);
      signal.addEventListener("abort", () => clearTimeout(t), { once: true });
    });
    if (signal.aborted) return;
    const headers = {
      Authorization: `Bearer ${currentUser.token}`,
      "x-user-role": currentUserRole,
      "x-user-cluster-id": currentUserClusterId
    };
    const get = (url) => fetch(apiUrl(url), { headers, signal }).then((response) => {
      if (response.status === 401) {
        localStorage.removeItem("tqi_auth_session");
        setCurrentUser(null);
        return null;
      }
      return response.ok ? response.json() : null;
    }).catch(() => null);
    try {
      const [
        panchayatsRes,
        studentsRes,
        volunteersRes,
        sessionsRes,
        attendanceRes,
        financeRes,
        lessonPlansRes,
        approvalsRes,
        auditRes,
        notificationsRes,
        clustersRes,
        usersRes,
        dateChangeRequestsRes,
        sessionReportsRes,
        sessionSubmissionsRes,
        academicYearsRes,
        modulesRes
      ] = await Promise.all(
        [
          get(`/api/panchayats?clusterId=${currentUserClusterId}`),
          get(`/api/students?clusterId=${currentUserClusterId}`),
          get(`/api/volunteers?clusterId=${currentUserClusterId}`),
          get(`/api/sessions?clusterId=${currentUserClusterId}`),
          get(`/api/attendance?clusterId=${currentUserClusterId}`),
          get(`/api/finance?clusterId=${currentUserClusterId}`),
          get(`/api/lesson-plans?clusterId=${currentUserClusterId}`),
          get(`/api/approvals?clusterId=${currentUserClusterId}`),
          get(`/api/audit-logs?clusterId=${currentUserClusterId}`),
          get("/api/notifications"),
          get("/api/clusters"),
          get("/api/users"),
          get("/api/date-change-requests"),
          get("/api/session-reports"),
          get("/api/session-submissions"),
          get("/api/academic-years"),
          get("/api/modules")
        ]
      );
      if (signal.aborted) return;
      if (Array.isArray(panchayatsRes?.panchayats)) setPanchayats(panchayatsRes.panchayats);
      if (Array.isArray(studentsRes?.students)) setStudents(studentsRes.students);
      if (Array.isArray(volunteersRes?.volunteers)) setVolunteers(volunteersRes.volunteers);
      if (Array.isArray(sessionsRes?.sessions)) setSessions(sessionsRes.sessions);
      if (Array.isArray(attendanceRes?.attendanceSessions)) setAttendanceSessions(attendanceRes.attendanceSessions);
      if (Array.isArray(financeRes?.financeEntries)) setFinanceEntries(financeRes.financeEntries);
      if (Array.isArray(lessonPlansRes?.lessonPlans)) setLessonPlans(lessonPlansRes.lessonPlans);
      if (Array.isArray(approvalsRes?.approvals)) setApprovals(approvalsRes.approvals);
      if (Array.isArray(auditRes?.auditLogs)) setAuditLogs(auditRes.auditLogs);
      if (Array.isArray(notificationsRes?.notifications)) setNotifications(notificationsRes.notifications);
      if (Array.isArray(clustersRes?.clusters)) setClusters(clustersRes.clusters);
      if (Array.isArray(usersRes?.users)) setUsers(usersRes.users);
      if (Array.isArray(dateChangeRequestsRes?.dateChangeRequests)) setDateChangeRequests(dateChangeRequestsRes.dateChangeRequests);
      if (Array.isArray(sessionReportsRes?.sessionReports)) setSessionReports(sessionReportsRes.sessionReports);
      if (Array.isArray(sessionSubmissionsRes?.sessionSubmissions)) setSessionSubmissions(sessionSubmissionsRes.sessionSubmissions);
      if (Array.isArray(academicYearsRes?.academicYears)) setAcademicYears(academicYearsRes.academicYears);
      if (Array.isArray(modulesRes?.modules)) setModules(modulesRes.modules);
      else if (Array.isArray(modulesRes?.data)) setModules(modulesRes.data);
    } catch {
    }
  }, [currentUser?.token, currentUserRole, currentUserClusterId]);
  useEffect(() => {
    if (!currentUser?.token) return;
    const controller = new AbortController();
    fetchBackendData(controller.signal);
    return () => controller.abort();
  }, [fetchBackendData, currentUser?.token]);
  const handleLoginSuccess = (session) => {
    try {
      localStorage.setItem("tqi_auth_session", JSON.stringify(session));
    } catch {
    }
    setCurrentUser(session);
    setCurrentUserRole(session.role);
    setCurrentUserClusterId(session.clusterId);
    setCurrentTab("dashboard");
    if (session.role === "Super Admin") {
      setSelectedPanchayatId("vedakkattamaduvu");
    } else if (session.clusterId === "salem") {
      setSelectedPanchayatId("yercaud");
    } else if (session.clusterId === "namakkal") {
      setSelectedPanchayatId("kolli-hills");
    } else if (session.clusterId === "dharmapuri") {
      setSelectedPanchayatId("vedakkattamaduvu");
    }
  };
  const handleLogout = () => {
    try {
      localStorage.removeItem("tqi_auth_session");
    } catch {
    }
    setCurrentUser(null);
    setCurrentTab("dashboard");
  };
  const handleRoleChange = (role, clusterId) => {
    setCurrentUserRole(role);
    if (role === "Cluster Admin" && clusterId) {
      setCurrentUserClusterId(clusterId);
    } else if (role === "Super Admin") {
      setCurrentUserClusterId("all");
    }
  };
  const handleApproveSubmission = async (id, module, recordId) => {
    try {
      await fetch(apiUrl(`/api/approvals/${id}/approve`), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "",
          "x-user-role": currentUserRole,
          "x-user-cluster-id": currentUserClusterId
        }
      });
    } catch {
    }
    setApprovals(
      (prev) => prev.map((a) => a.id === id ? { ...a, status: "Approved" } : a)
    );
    if (module === "Attendance") {
      setAttendanceSessions(
        (prev) => prev.map((s) => s.id === recordId ? { ...s, status: "Approved" } : s)
      );
    } else if (module === "Lesson Plan") {
      setLessonPlans(
        (prev) => prev.map((lp) => lp.id === recordId ? { ...lp, status: "Approved" } : lp)
      );
    } else if (module === "Finance") {
      setFinanceDrafts(
        (prev) => prev.map((fd) => fd.id === recordId ? { ...fd, status: "Approved" } : fd)
      );
      setFinanceEntries(
        (prev) => prev.map((fe) => fe.id === recordId || fe.draftId === recordId ? { ...fe, status: "Approved" } : fe)
      );
    }
    const newLog = {
      id: `log-${Date.now()}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19),
      userId: "u-super-admin-1",
      userName: "Dr. K. Senthil Nathan",
      userRole: "Super Admin",
      action: `Approved ${module}`,
      module,
      recordId,
      clusterId: currentUserClusterId,
      clusterName: "Dharmapuri Cluster",
      details: `Approved ${module} submission (${recordId})`
    };
    setAuditLogs((prev) => [newLog, ...prev]);
    const newNotif = {
      id: `notif-${Date.now()}`,
      title: `${module} Approved`,
      message: `Super Admin has approved ${module} (${recordId}).`,
      timeAgo: "Just now",
      isRead: false,
      type: "approval"
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };
  const handleRequestCorrection = async (id, module, recordId, reason) => {
    try {
      await fetch(apiUrl(`/api/approvals/${id}/request-correction`), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "",
          "x-user-role": currentUserRole,
          "x-user-cluster-id": currentUserClusterId
        },
        body: JSON.stringify({ reason })
      });
    } catch {
    }
    setApprovals(
      (prev) => prev.map(
        (a) => a.id === id ? { ...a, status: "Correction Requested", correctionReason: reason } : a
      )
    );
    if (module === "Attendance") {
      setAttendanceSessions(
        (prev) => prev.map(
          (s) => s.id === recordId ? { ...s, status: "Correction Requested", correctionReason: reason } : s
        )
      );
    } else if (module === "Lesson Plan") {
      setLessonPlans(
        (prev) => prev.map(
          (lp) => lp.id === recordId ? { ...lp, status: "Correction Requested", correctionReason: reason } : lp
        )
      );
    } else if (module === "Finance") {
      setFinanceDrafts(
        (prev) => prev.map(
          (fd) => fd.id === recordId ? { ...fd, status: "Correction Requested", correctionReason: reason } : fd
        )
      );
    }
    const newLog = {
      id: `log-${Date.now()}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 19),
      userId: "u-super-admin-1",
      userName: "Dr. K. Senthil Nathan",
      userRole: "Super Admin",
      action: `Correction Requested on ${module}`,
      module,
      recordId,
      clusterId: currentUserClusterId,
      clusterName: "Dharmapuri Cluster",
      details: `Correction requested for ${recordId}: "${reason}"`
    };
    setAuditLogs((prev) => [newLog, ...prev]);
    const newNotif = {
      id: `notif-${Date.now()}`,
      title: `Correction Requested: ${module}`,
      message: `Super Admin requested changes on ${recordId}: "${reason}"`,
      timeAgo: "Just now",
      isRead: false,
      type: "correction"
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };
  const handleRejectSubmission = async (id, module, recordId, reason) => {
    try {
      await fetch(apiUrl(`/api/approvals/${id}/reject`), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "",
          "x-user-role": currentUserRole,
          "x-user-cluster-id": currentUserClusterId
        },
        body: JSON.stringify({ reason })
      });
    } catch {
    }
    setApprovals(
      (prev) => prev.map((a) => a.id === id ? { ...a, status: "Rejected", correctionReason: reason } : a)
    );
  };
  const handleAddCluster = async (newC) => {
    try {
      const response = await fetch(apiUrl("/api/clusters"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "" },
        body: JSON.stringify(newC)
      });
      const data = await response.json();
      if (!response.ok || !data?.success) throw new Error(data?.error || "Unable to create cluster.");
      if (data.cluster) setClusters((prev) => [...prev, data.cluster]);
      if (data.user) setUsers((prev) => [...prev, data.user]);
      else {
        const usersResponse = await fetch(apiUrl("/api/users"), { headers: { Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "" } });
        const usersData = await usersResponse.json();
        if (Array.isArray(usersData?.users)) setUsers(usersData.users);
      }
      return true;
    } catch (error) {
      throw error;
    }
  };
  const handleDeleteCluster = async (clusterId) => {
    try {
      await fetch(apiUrl(`/api/clusters/${clusterId}`), {
        method: "DELETE",
        headers: { Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "" }
      });
      setClusters((prev) => prev.filter((c) => c.id !== clusterId));
    } catch (error) {
      setClusters((prev) => prev.filter((c) => c.id !== clusterId));
    }
  };
  const handleAddUser = async (newU) => {
    try {
      const response = await fetch(apiUrl("/api/users"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : ""
        },
        body: JSON.stringify(newU)
      });
      const data = await response.json();
      if (!response.ok || !data?.success) {
        throw new Error(data?.error || "Unable to create user.");
      }
      if (data.user) {
        setUsers((prev) => [...prev, data.user]);
      }
      try {
        const cRes = await fetch(apiUrl("/api/clusters"), {
          headers: { Authorization: currentUser?.token ? `Bearer ${currentUser.token}` : "" }
        });
        const cData = await cRes.json();
        if (Array.isArray(cData?.clusters)) setClusters(cData.clusters);
      } catch {
      }
      return true;
    } catch (error) {
      throw error;
    }
  };
  const handleUpdateUser = async (id, user) => {
    try {
      const response = await fetch(apiUrl(`/api/users/${id}`), { method: "PUT", headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` }, body: JSON.stringify(user) });
      const data = await response.json();
      if (!response.ok || !data.success) {
        return false;
      }
      setUsers((prev) => prev.map((item) => item.id === id ? { ...item, ...data.user } : item));
      return true;
    } catch {
      return false;
    }
  };
  const handleDeleteUser = async (id) => {
    const response = await fetch(apiUrl(`/api/users/${id}`), { method: "DELETE", headers: { Authorization: `Bearer ${currentUser?.token || ""}` } });
    const data = await response.json();
    if (!response.ok || !data.success) return;
    setUsers((prev) => prev.filter((item) => item.id !== id));
  };
  const handleResetPassword = async (id, password) => {
    const response = await fetch(apiUrl(`/api/users/${id}/reset-password`), { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` }, body: JSON.stringify({ password }) });
    const data = await response.json();
    if (!response.ok || !data.success) return;
    setUsers((prev) => prev.map((item) => item.id === id ? { ...item, mustChangePassword: false } : item));
  };
  const handleNavigate = (tab, targetId, secondaryParam) => {
    if (tab === "panchayat-detail" && targetId) {
      setSelectedPanchayatId(targetId);
    }
    if (tab === "students") {
      if (targetId || secondaryParam) {
        setInitialStudentFilters({
          panchayatId: targetId,
          villageId: secondaryParam
        });
      }
    }
    if (tab === "attendance-draft" || tab === "attendance") {
      if (targetId) {
        setActiveDraftId(targetId);
      }
      setCurrentTab("attendance");
      return;
    }
    if (tab === "lesson-plan") {
      if (targetId) {
        setSelectedLessonPlanId(targetId);
      } else {
        setSelectedLessonPlanId(void 0);
      }
      setCurrentTab("lesson-plan");
      return;
    }
    if (tab === "finance-statement") {
      if (targetId) {
        setActiveFinanceDraftId(targetId);
      }
      setCurrentTab("finance-statement");
      return;
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const handleAddPanchayat = (newPanchayat) => {
    const newId = newPanchayat.name.toLowerCase().replace(/\s+/g, "-");
    const villagesList = newPanchayat.initialVillages.map((vName, idx) => ({
      id: `v-${Date.now()}-${idx}`,
      name: vName,
      studentCount: 0
    }));
    const created = {
      id: newId,
      name: newPanchayat.name,
      cluster: newPanchayat.cluster || "Dharmapuri",
      status: newPanchayat.status || "On Track",
      villagesCount: villagesList.length,
      activeStudents: 0,
      volunteersCount: 0,
      villages: villagesList
    };
    setPanchayats((prev) => [created, ...prev]);
  };
  const handleAddVillage = (panchayatId, villageName) => {
    setPanchayats(
      (prev) => prev.map((p) => {
        if (p.id === panchayatId) {
          const newVillage = {
            id: `v-${Date.now()}`,
            name: villageName,
            studentCount: 0
          };
          const updatedVillages = [...p.villages, newVillage];
          return {
            ...p,
            villages: updatedVillages,
            villagesCount: updatedVillages.length
          };
        }
        return p;
      })
    );
  };
  const handleAddStudent = (newStudent) => {
    const newId = `stu-${Date.now()}`;
    const code = `STU-24-${String(students.length + 1).padStart(3, "0")}`;
    const avatarLetter = newStudent.name.charAt(0).toUpperCase();
    const colors = ["bg-[#0b3d91] text-white", "bg-[#345baf] text-white", "bg-[#521a00] text-white", "bg-[#592600] text-white"];
    const avatarBg = colors[students.length % colors.length];
    const created = {
      ...newStudent,
      id: newId,
      code,
      avatarLetter,
      avatarBg
    };
    setStudents((prev) => [created, ...prev]);
    setPanchayats(
      (prev) => prev.map((p) => {
        if (p.id === newStudent.panchayatId) {
          const updatedVillages = p.villages.map(
            (v) => v.name === newStudent.villageName || v.id === newStudent.villageId ? { ...v, studentCount: v.studentCount + 1 } : v
          );
          return {
            ...p,
            activeStudents: p.activeStudents + 1,
            villages: updatedVillages
          };
        }
        return p;
      })
    );
  };
  const handleBulkAddStudents = (newStudentsList) => {
    if (!newStudentsList || newStudentsList.length === 0) return;
    const colors = [
      "bg-[#0b3d91] text-white",
      "bg-[#345baf] text-white",
      "bg-[#521a00] text-white",
      "bg-[#592600] text-white"
    ];
    const currentTotal = students.length;
    const createdBatch = newStudentsList.map((st, idx) => {
      const codeNumber = currentTotal + idx + 1;
      return {
        ...st,
        id: `stu-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
        code: `STU-24-${String(codeNumber).padStart(3, "0")}`,
        avatarLetter: (st.name || "S").charAt(0).toUpperCase(),
        avatarBg: colors[(currentTotal + idx) % colors.length]
      };
    });
    setStudents((prev) => [...createdBatch, ...prev]);
    setPanchayats(
      (prev) => prev.map((p) => {
        const matchingAdded = createdBatch.filter((s) => s.panchayatId === p.id);
        if (matchingAdded.length > 0) {
          const updatedVillages = p.villages.map((v) => {
            const villageAdded = matchingAdded.filter(
              (s) => s.villageId === v.id || s.villageName === v.name
            );
            return {
              ...v,
              studentCount: v.studentCount + villageAdded.length
            };
          });
          return {
            ...p,
            activeStudents: p.activeStudents + matchingAdded.length,
            villages: updatedVillages
          };
        }
        return p;
      })
    );
  };
  const handleUpdateStudent = (id, updated) => {
    setStudents((prev) => prev.map((s) => s.id === id ? { ...s, ...updated } : s));
  };
  const handleDeleteStudent = (id) => {
    const toDelete = students.find((s) => s.id === id);
    if (toDelete) {
      setPanchayats(
        (prev) => prev.map((p) => {
          if (p.id === toDelete.panchayatId) {
            const updatedVillages = p.villages.map(
              (v) => v.name === toDelete.villageName || v.id === toDelete.villageId ? { ...v, studentCount: Math.max(0, v.studentCount - 1) } : v
            );
            return {
              ...p,
              activeStudents: Math.max(0, p.activeStudents - 1),
              villages: updatedVillages
            };
          }
          return p;
        })
      );
    }
    setStudents((prev) => prev.filter((s) => s.id !== id));
  };
  const handleAddVolunteer = (newVol) => {
    const newId = `vol-${Date.now()}`;
    const names = newVol.name.split(" ");
    const avatarText = names.length > 1 ? `${names[0][0]}${names[1][0]}`.toUpperCase() : newVol.name.slice(0, 2).toUpperCase();
    const created = {
      ...newVol,
      id: newId,
      avatarText,
      totalSessions: 0,
      attendanceRate: 100,
      recentSessions: []
    };
    setVolunteers((prev) => [created, ...prev]);
  };
  const handleUpdateVolunteer = (id, updated) => {
    setVolunteers((prev) => prev.map((v) => v.id === id ? { ...v, ...updated } : v));
  };
  const handleDeleteVolunteer = (id) => {
    setVolunteers((prev) => prev.filter((v) => v.id !== id));
  };
  const handleAddSession = (newSession) => {
    const created = {
      ...newSession,
      id: `sess-${Date.now()}`
    };
    setSessions((prev) => [created, ...prev]);
  };
  const handleUpdateSession = async (id, updated) => {
    const existing = sessions.find((session) => session.id === id);
    if (currentUser?.token && existing) {
      const response = await fetch(apiUrl(`/api/sessions/${id}`), {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser.token}` },
        body: JSON.stringify({
          ...existing,
          ...updated,
          academicYear: existing.academicYear,
          dayNumber: existing.dayNumber,
          sessionName: existing.name
        })
      });
      if (!response.ok) return;
    }
    setSessions((prev) => prev.map((s) => s.id === id ? { ...s, ...updated } : s));
  };
  const handleDeleteSession = (id) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
  };
  const handleSaveAttendance = async (session) => {
    if (currentUserRole === "Cluster Admin" && currentUser?.token) {
      const response = await fetch(apiUrl("/api/attendance"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser.token}` },
        body: JSON.stringify(session)
      });
      if (!response.ok) return;
    }
    setAttendanceSessions((prev) => {
      const idx = prev.findIndex((s) => s.id === session.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = session;
        return copy;
      }
      return [session, ...prev];
    });
    if (session.status === "Submitted") {
      const newAppr = {
        id: `appr-${Date.now()}`,
        module: "Attendance",
        recordId: session.id,
        recordTitle: `${session.panchayatName || "Center"} - ${session.sessionName || "Attendance"}`,
        clusterId: currentUserClusterId,
        clusterName: "Dharmapuri Cluster",
        submittedBy: "Dharmapuri Cluster Admin",
        submittedAt: "Just now",
        status: "Pending",
        details: {
          presentCount: session.presentCount || session.records?.filter((s) => s.status === "Present").length || 0,
          totalCount: session.totalCount || session.records?.length || 0,
          villageName: session.villageName || "",
          dayNumber: session.dayNumber || 1
        }
      };
      setApprovals((prev) => [newAppr, ...prev]);
    }
  };
  const handleAddFinanceEntry = (entry) => {
    const created = {
      ...entry,
      id: `fin-${Date.now()}-${Math.floor(Math.random() * 1e3)}`
    };
    setFinanceEntries((prev) => [created, ...prev]);
  };
  const handleUpdateFinanceEntry = (id, updated) => {
    setFinanceEntries((prev) => prev.map((e) => e.id === id ? { ...e, ...updated } : e));
  };
  const handleDeleteFinanceEntry = (id) => {
    setFinanceEntries((prev) => prev.filter((e) => e.id !== id));
  };
  const handleSaveFinanceDraft = (draft) => {
    setFinanceDrafts((prev) => {
      const idx = prev.findIndex((d) => d.id === draft.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = draft;
        return copy;
      }
      return [draft, ...prev];
    });
  };
  const handleDeleteFinanceDraft = (draftId) => {
    setFinanceDrafts((prev) => prev.filter((d) => d.id !== draftId));
  };
  const handleSubmitFinanceDraft = (draftId) => {
    setFinanceDrafts(
      (prev) => prev.map((d) => d.id === draftId ? { ...d, status: "Pending" } : d)
    );
    setFinanceEntries(
      (prev) => prev.map((e) => e.draftId === draftId ? { ...e, status: "Pending" } : e)
    );
    const targetDraft = financeDrafts.find((d) => d.id === draftId);
    const newAppr = {
      id: `appr-${Date.now()}`,
      module: "Finance",
      recordId: draftId,
      recordTitle: targetDraft?.title || "Finance Claim Voucher",
      clusterId: currentUserClusterId,
      clusterName: "Dharmapuri Cluster",
      submittedBy: "Dharmapuri Cluster Admin",
      submittedAt: "Just now",
      status: "Pending",
      details: {
        totalAmount: targetDraft?.totalAmount || 0,
        itemCount: targetDraft?.routes?.length || 1,
        spocName: "Admin"
      }
    };
    setApprovals((prev) => [newAppr, ...prev]);
  };
  const handleAddLessonPlan = (plan) => {
    const created = {
      ...plan,
      id: `lp-${Date.now()}`
    };
    setLessonPlans((prev) => [created, ...prev]);
  };
  const handleUpdateLessonPlan = (id, plan) => {
    setLessonPlans((prev) => prev.map((p) => p.id === id ? { ...p, ...plan } : p));
  };
  const handleDeleteLessonPlan = (id) => {
    setLessonPlans((prev) => prev.filter((p) => p.id !== id));
  };
  const handleMarkAsRead = (id) => {
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, isRead: true } : n));
  };
  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };
  const handleSubmitDateChangeRequest = async (sessionId, originalDate, requestedDate, reason) => {
    try {
      const response = await fetch(apiUrl("/api/date-change-requests"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify({ sessionId, originalDate, requestedDate, reason })
      });
      const data = await response.json();
      if (data?.success && data.dateChangeRequest) {
        setDateChangeRequests((prev) => [data.dateChangeRequest, ...prev]);
      }
    } catch {
    }
  };
  const handleReviewDateChangeRequest = async (requestId, action, remarks) => {
    try {
      const response = await fetch(apiUrl(`/api/date-change-requests/${requestId}/${action}`), {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify({ remarks })
      });
      const data = await response.json();
      if (data?.success) {
        setDateChangeRequests((prev) => prev.map((r) => r.id === requestId ? { ...r, status: action === "approve" ? "APPROVED" : "REJECTED", reviewRemarks: remarks } : r));
        if (action === "approve") {
          fetchBackendData(new AbortController().signal);
        }
      }
    } catch {
    }
  };
  const handleSaveSessionReport = async (report) => {
    try {
      const response = await fetch(apiUrl("/api/session-reports"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify(report)
      });
      const data = await response.json();
      if (data?.success && data.sessionReport) {
        setSessionReports((prev) => {
          const idx = prev.findIndex((r) => r.id === data.sessionReport.id);
          if (idx >= 0) {
            const copy = [...prev];
            copy[idx] = data.sessionReport;
            return copy;
          }
          return [data.sessionReport, ...prev];
        });
      }
    } catch {
    }
  };
  const handleDeleteSessionReport = async (reportId) => {
    try {
      await fetch(apiUrl(`/api/session-reports/${reportId}`), {
        method: "DELETE",
        headers: { Authorization: `Bearer ${currentUser?.token || ""}` }
      });
      setSessionReports((prev) => prev.filter((r) => r.id !== reportId));
    } catch {
    }
  };
  const handleSubmitSession = async (sessionId, clusterId, dayNumber) => {
    try {
      const response = await fetch(apiUrl("/api/session-submissions"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify({ sessionId, clusterId, dayNumber })
      });
      const data = await response.json();
      if (data?.success && data.submission) {
        setSessionSubmissions((prev) => [data.submission, ...prev]);
        return { success: true };
      }
      return { success: false, error: data?.error, missingItems: data?.missingItems };
    } catch {
      return { success: false, error: "Network error" };
    }
  };
  const handleReviewSubmission = async (submissionId, action, remarks) => {
    try {
      await fetch(apiUrl(`/api/session-submissions/${submissionId}/review`), {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify({ action, remarks })
      });
      setSessionSubmissions((prev) => prev.map((s) => s.id === submissionId ? {
        ...s,
        status: action === "approve" ? "APPROVED" : "RESUBMISSION_REQUIRED",
        reviewRemarks: remarks
      } : s));
    } catch {
    }
  };
  const handleResubmitSession = async (submissionId) => {
    try {
      await fetch(apiUrl(`/api/session-submissions/${submissionId}/resubmit`), {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` }
      });
      setSessionSubmissions((prev) => prev.map((s) => s.id === submissionId ? { ...s, status: "RESUBMITTED" } : s));
    } catch {
    }
  };
  const handleCreateModule = async (moduleData) => {
    try {
      const response = await fetch(apiUrl("/api/modules"), {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify(moduleData)
      });
      const data = await response.json();
      const newMod = {
        id: data?.module?.id || `mod-${Date.now()}`,
        moduleNumber: moduleData.moduleNumber,
        moduleName: moduleData.moduleName,
        topic: moduleData.topic,
        description: moduleData.description,
        academicYear: moduleData.academicYear,
        dayNumber: moduleData.dayNumber,
        status: "Active",
        version: 1,
        resources: [],
        createdBy: currentUser?.name || "Super Admin",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      setModules((prev) => [newMod, ...prev]);
    } catch {
    }
  };
  const handleUpdateModule = async (id, moduleData) => {
    try {
      const response = await fetch(apiUrl(`/api/modules/${id}`), {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${currentUser?.token || ""}` },
        body: JSON.stringify(moduleData)
      });
      const data = await response.json();
      if (data?.success && data.data) {
        setModules((prev) => prev.map((m) => m.id === id ? { ...m, ...data.data } : m));
      }
    } catch {
    }
  };
  const handleDeleteModule = async (id) => {
    try {
      await fetch(apiUrl(`/api/modules/${id}`), {
        method: "DELETE",
        headers: { Authorization: `Bearer ${currentUser?.token || ""}` }
      });
      setModules((prev) => prev.filter((m) => m.id !== id));
    } catch {
    }
  };
  const handleUploadModuleResource = async (moduleId, file) => {
    try {
      const formData = new FormData();
      formData.append("file", file);
      const response = await fetch(apiUrl(`/api/modules/${moduleId}/resources`), {
        method: "POST",
        headers: { Authorization: `Bearer ${currentUser?.token || ""}` },
        body: formData
      });
      const data = await response.json();
      if (data?.success && data.resource) {
        setModules((prev) => prev.map((m) => {
          if (m.id === moduleId) {
            const resources = m.resources ? [...m.resources, data.resource] : [data.resource];
            return { ...m, resources };
          }
          return m;
        }));
      }
    } catch {
    }
  };
  const handleDownloadModuleResource = (moduleId, resourceId) => {
    const downloadUrl = apiUrl(`/api/modules/${moduleId}/resources/${resourceId}/download`);
    window.open(downloadUrl, "_blank");
  };
  if (!currentUser) {
    return /* @__PURE__ */ jsxDEV(LoginPage, { onLoginSuccess: handleLoginSuccess }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
      lineNumber: 1094,
      columnNumber: 12
    }, this);
  }
  const clusterFilterKey = currentUserClusterId === "salem" ? "Salem" : currentUserClusterId === "namakkal" ? "Namakkal" : "Dharmapuri";
  const displayPanchayats = currentUserRole === "Super Admin" ? panchayats : panchayats.filter((p) => (p.cluster || "").toLowerCase() === clusterFilterKey.toLowerCase());
  const displayPanchayatIds = new Set(displayPanchayats.map((p) => p.id));
  const displayStudents = currentUserRole === "Super Admin" ? students : students.filter((s) => displayPanchayatIds.has(s.panchayatId));
  const displayVolunteers = currentUserRole === "Super Admin" ? volunteers : volunteers.filter((v) => !v.panchayatId || displayPanchayatIds.has(v.panchayatId) || v.clusterId === currentUserClusterId);
  const displaySessions = currentUserRole === "Super Admin" ? sessions : sessions.filter((s) => displayPanchayatIds.has(s.panchayatId) || s.clusterId === currentUserClusterId);
  const displayAttendance = currentUserRole === "Super Admin" ? attendanceSessions : attendanceSessions.filter((a) => displayPanchayatIds.has(a.panchayatId) || a.clusterId === currentUserClusterId);
  const displayFinance = currentUserRole === "Super Admin" ? financeEntries : financeEntries.filter((f) => !f.panchayatId || displayPanchayatIds.has(f.panchayatId) || f.clusterId === currentUserClusterId);
  const displayFinanceDrafts = currentUserRole === "Super Admin" ? financeDrafts : financeDrafts.filter((fd) => !fd.clusterId || fd.clusterId === currentUserClusterId);
  const displayLessonPlans = currentUserRole === "Super Admin" ? lessonPlans : lessonPlans.filter((lp) => !lp.clusterId || lp.clusterId === currentUserClusterId || lp.panchayatId && displayPanchayatIds.has(lp.panchayatId));
  const displayApprovals = currentUserRole === "Super Admin" ? approvals : approvals.filter((a) => a.clusterId === currentUserClusterId);
  const displayAuditLogs = currentUserRole === "Super Admin" ? auditLogs : auditLogs.filter((al) => al.clusterId === currentUserClusterId);
  const displayDateChangeRequests = currentUserRole === "Super Admin" ? dateChangeRequests : dateChangeRequests.filter((r) => r.clusterId === currentUserClusterId);
  const displaySessionReports = currentUserRole === "Super Admin" ? sessionReports : sessionReports.filter((r) => r.clusterId === currentUserClusterId);
  const displaySessionSubmissions = currentUserRole === "Super Admin" ? sessionSubmissions : sessionSubmissions.filter((s) => s.clusterId === currentUserClusterId);
  const currentPanchayat = displayPanchayats.find((p) => p.id === selectedPanchayatId) || displayPanchayats[0] || panchayats[0];
  const pendingApprovalsCount = displayApprovals.filter((a) => a.status === "Pending").length;
  const pendingCount = notifications.filter((n) => !n.isRead).length;
  const currentClusterObj = clusters.find((c) => c.id === currentUserClusterId) || clusters[0];
  const activeClusterName = currentUserRole === "Super Admin" ? "All Clusters (Tamil Nadu)" : currentClusterObj?.name || "Dharmapuri Cluster";
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen w-full max-w-full overflow-x-hidden bg-gray-50 dark:bg-gray-950 font-outfit", children: [
    /* @__PURE__ */ jsxDEV(
      Navigation,
      {
        currentTab,
        onSelectTab: (tab) => {
          if (tab === "attendance") setActiveDraftId(void 0);
          if (tab === "students") setInitialStudentFilters(void 0);
          setCurrentTab(tab);
          setMobileSidebarOpen(false);
        },
        notifications,
        userRole: currentUserRole,
        clusterName: activeClusterName,
        adminName: currentUser.name,
        userEmail: currentUser.email,
        pendingApprovalsCount,
        isCollapsed: sidebarCollapsed,
        onToggleCollapse: () => setSidebarCollapsed((prev) => !prev),
        onLogout: handleLogout,
        isMobileOpen: mobileSidebarOpen,
        onCloseMobile: () => setMobileSidebarOpen(false)
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
        lineNumber: 1164,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `flex-1 flex flex-col min-w-0 transition-all duration-300 ease-in-out ${sidebarCollapsed ? "lg:ml-[90px]" : "lg:ml-[290px]"}`,
        children: [
          /* @__PURE__ */ jsxDEV(
            Header,
            {
              userEmail: currentUser.email,
              userName: currentUser.name,
              userRole: currentUserRole,
              clusters,
              selectedClusterId: currentUserClusterId,
              onSelectCluster: (cid) => setCurrentUserClusterId(cid),
              notifications,
              pendingApprovalsCount,
              onNavigate: (tab, targetId) => {
                handleNavigate(tab, targetId);
                setMobileSidebarOpen(false);
              },
              onLogout: handleLogout,
              onRoleChange: (role) => handleRoleChange(role, currentUserClusterId),
              onToggleSidebar: () => {
                if (window.innerWidth < 1024) {
                  setMobileSidebarOpen((prev) => !prev);
                } else {
                  setSidebarCollapsed((prev) => !prev);
                }
              }
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
              lineNumber: 1192,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("main", { className: "flex-1 w-full max-w-full overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full p-4 md:p-6 lg:p-8", children: /* @__PURE__ */ jsxDEV(ErrorBoundary, { children: [
            currentTab === "dashboard" && /* @__PURE__ */ jsxDEV(
              DashboardView,
              {
                onNavigate: handleNavigate,
                onOpenNewSession: () => setCurrentTab("sessions"),
                onOpenNewFinance: () => {
                  setCurrentTab("finance");
                  setOpenNewFinanceModal(true);
                },
                onOpenNewAttendance: () => {
                  setActiveDraftId(void 0);
                  setCurrentTab("attendance");
                },
                panchayats: displayPanchayats,
                studentsCount: displayStudents.length,
                volunteersCount: displayVolunteers.length,
                sessionsCount: displaySessions.length,
                pendingCount,
                attendanceDrafts: displayAttendance,
                userRole: currentUserRole,
                clusters,
                approvals: displayApprovals,
                clusterName: activeClusterName,
                financeEntries: displayFinance,
                sessions: displaySessions,
                students: displayStudents,
                volunteers: displayVolunteers
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1221,
                columnNumber: 15
              },
              this
            ),
            currentTab === "academic-setup" && currentUserRole === "Super Admin" && /* @__PURE__ */ jsxDEV(
              AcademicSetupView,
              {
                authToken: currentUser.token,
                onSetupSaved: () => fetchBackendData(new AbortController().signal)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1250,
                columnNumber: 15
              },
              this
            ),
            currentTab === "approvals" && /* @__PURE__ */ jsxDEV(
              ApprovalCenterView,
              {
                approvals: displayApprovals,
                clusters,
                userRole: currentUserRole,
                onApprove: handleApproveSubmission,
                onRequestCorrection: handleRequestCorrection,
                onReject: handleRejectSubmission,
                onNavigate: handleNavigate
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1257,
                columnNumber: 15
              },
              this
            ),
            currentTab === "clusters" && /* @__PURE__ */ jsxDEV(
              ClustersView,
              {
                clusters,
                userRole: currentUserRole,
                onNavigate: handleNavigate,
                onAddCluster: handleAddCluster,
                onDeleteCluster: handleDeleteCluster
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1269,
                columnNumber: 15
              },
              this
            ),
            currentTab === "audit-logs" && /* @__PURE__ */ jsxDEV(
              AuditLogView,
              {
                auditLogs: displayAuditLogs,
                userRole: currentUserRole
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1279,
                columnNumber: 15
              },
              this
            ),
            currentTab === "users" && /* @__PURE__ */ jsxDEV(
              UserManagementView,
              {
                users,
                clusters,
                onAddUser: handleAddUser,
                onUpdateUser: handleUpdateUser,
                onDeleteUser: handleDeleteUser,
                onResetPassword: handleResetPassword
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1286,
                columnNumber: 15
              },
              this
            ),
            currentTab === "panchayats" && /* @__PURE__ */ jsxDEV(
              PanchayatsView,
              {
                panchayats: displayPanchayats,
                onSelectPanchayat: (id) => {
                  setSelectedPanchayatId(id);
                  setCurrentTab("panchayat-detail");
                },
                onAddPanchayat: handleAddPanchayat,
                onNavigate: handleNavigate
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1297,
                columnNumber: 15
              },
              this
            ),
            currentTab === "panchayat-detail" && /* @__PURE__ */ jsxDEV(
              PanchayatDetailView,
              {
                panchayat: currentPanchayat,
                students: displayStudents,
                onBack: () => setCurrentTab("panchayats"),
                onNavigate: handleNavigate,
                onAddVillage: handleAddVillage
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1309,
                columnNumber: 15
              },
              this
            ),
            currentTab === "students" && /* @__PURE__ */ jsxDEV(
              StudentsView,
              {
                students: displayStudents,
                panchayats: displayPanchayats,
                initialFilters: initialStudentFilters,
                onAddStudent: handleAddStudent,
                onBulkImportStudents: handleBulkAddStudents,
                onUpdateStudent: handleUpdateStudent,
                onDeleteStudent: handleDeleteStudent
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1319,
                columnNumber: 15
              },
              this
            ),
            currentTab === "volunteers" && /* @__PURE__ */ jsxDEV(
              VolunteersView,
              {
                volunteers: displayVolunteers,
                panchayats: displayPanchayats,
                onAddVolunteer: handleAddVolunteer,
                onUpdateVolunteer: handleUpdateVolunteer,
                onDeleteVolunteer: handleDeleteVolunteer
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1331,
                columnNumber: 15
              },
              this
            ),
            currentTab === "sessions" && /* @__PURE__ */ jsxDEV(
              SessionsView,
              {
                sessions: displaySessions,
                panchayats: displayPanchayats,
                volunteers: displayVolunteers,
                onNavigate: handleNavigate,
                onAddSession: handleAddSession,
                onUpdateSession: handleUpdateSession,
                onDeleteSession: handleDeleteSession,
                canManageSchedule: currentUserRole === "Cluster Admin"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1341,
                columnNumber: 15
              },
              this
            ),
            currentTab === "attendance" && /* @__PURE__ */ jsxDEV(
              AttendanceView,
              {
                attendanceSessions: displayAttendance,
                students: displayStudents,
                panchayats: displayPanchayats,
                draftId: activeDraftId,
                onNavigate: handleNavigate,
                onSaveAttendance: handleSaveAttendance
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1354,
                columnNumber: 15
              },
              this
            ),
            currentTab === "lesson-plan" && /* @__PURE__ */ jsxDEV(
              LessonPlanView,
              {
                lessonPlans: displayLessonPlans,
                sessions: displaySessions,
                panchayats: displayPanchayats,
                volunteers: displayVolunteers,
                selectedLessonPlanId,
                onNavigate: handleNavigate,
                onAddLessonPlan: handleAddLessonPlan,
                onUpdateLessonPlan: handleUpdateLessonPlan,
                onDeleteLessonPlan: handleDeleteLessonPlan
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1365,
                columnNumber: 15
              },
              this
            ),
            currentTab === "session-photos" && /* @__PURE__ */ jsxDEV(
              SessionPhotosView,
              {
                panchayats: displayPanchayats,
                clusters,
                authToken: currentUser.token,
                userRole: currentUserRole,
                currentCluster: currentUserClusterId === "all" ? "Dharmapuri" : currentUserClusterId,
                onNavigate: handleNavigate
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1379,
                columnNumber: 15
              },
              this
            ),
            currentTab === "finance" && /* @__PURE__ */ jsxDEV(
              FinanceView,
              {
                financeEntries: displayFinance,
                panchayats: displayPanchayats,
                sessions,
                drafts: displayFinanceDrafts,
                onNavigate: handleNavigate,
                onAddFinanceEntry: handleAddFinanceEntry,
                onUpdateFinanceEntry: handleUpdateFinanceEntry,
                onDeleteFinanceEntry: handleDeleteFinanceEntry,
                onSaveDraft: handleSaveFinanceDraft,
                onDeleteDraft: handleDeleteFinanceDraft,
                onSubmitDraft: handleSubmitFinanceDraft,
                isOpenNewModal: openNewFinanceModal,
                onCloseNewModal: () => setOpenNewFinanceModal(false)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1390,
                columnNumber: 15
              },
              this
            ),
            currentTab === "finance-statement" && /* @__PURE__ */ jsxDEV(
              FinanceStatementView,
              {
                entries: displayFinance,
                drafts: displayFinanceDrafts,
                activeDraftId: activeFinanceDraftId,
                onBack: () => setCurrentTab("finance"),
                onNavigate: handleNavigate,
                onSaveDraft: handleSaveFinanceDraft,
                onDeleteDraft: handleDeleteFinanceDraft,
                onSubmitDraft: handleSubmitFinanceDraft,
                onAddFinanceEntry: handleAddFinanceEntry,
                onUpdateFinanceEntry: handleUpdateFinanceEntry,
                onDeleteFinanceEntry: handleDeleteFinanceEntry
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1408,
                columnNumber: 15
              },
              this
            ),
            currentTab === "reports" && /* @__PURE__ */ jsxDEV(
              ReportsView,
              {
                sessions: displaySessions,
                lessonPlans: displayLessonPlans,
                panchayats: displayPanchayats,
                volunteers: displayVolunteers,
                students: displayStudents,
                onNavigate: handleNavigate
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1424,
                columnNumber: 15
              },
              this
            ),
            currentTab === "report-preview" && /* @__PURE__ */ jsxDEV(
              ReportPreviewView,
              {
                onBack: () => setCurrentTab("reports"),
                onNavigate: handleNavigate
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1435,
                columnNumber: 15
              },
              this
            ),
            currentTab === "notifications" && /* @__PURE__ */ jsxDEV(
              NotificationsView,
              {
                notifications,
                onNavigate: handleNavigate,
                onMarkAsRead: handleMarkAsRead,
                onMarkAllAsRead: handleMarkAllAsRead
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1442,
                columnNumber: 15
              },
              this
            ),
            currentTab === "settings" && /* @__PURE__ */ jsxDEV(
              SettingsView,
              {
                currentUser,
                onUpdateProfile: (updated) => {
                  setCurrentUser((prev) => prev ? { ...prev, ...updated } : prev);
                }
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1451,
                columnNumber: 15
              },
              this
            ),
            currentTab === "date-change-requests" && /* @__PURE__ */ jsxDEV(
              DateChangeRequestView,
              {
                dateChangeRequests: displayDateChangeRequests,
                sessions: displaySessions,
                currentUserRole,
                currentUserId: currentUser.id || "",
                currentUserClusterId,
                onSubmitRequest: handleSubmitDateChangeRequest,
                onReviewRequest: handleReviewDateChangeRequest
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1460,
                columnNumber: 15
              },
              this
            ),
            currentTab === "session-reports" && /* @__PURE__ */ jsxDEV(
              SessionReportView,
              {
                sessionReports: displaySessionReports,
                sessions: displaySessions,
                clusters,
                currentUserRole,
                currentUserClusterId,
                onSaveReport: handleSaveSessionReport,
                onDeleteReport: handleDeleteSessionReport
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1472,
                columnNumber: 15
              },
              this
            ),
            currentTab === "session-submissions" && /* @__PURE__ */ jsxDEV(
              SessionSubmissionView,
              {
                sessionSubmissions: displaySessionSubmissions,
                sessions: displaySessions,
                clusters,
                currentUserRole,
                currentUserId: currentUser.id || "",
                currentUserClusterId,
                onSubmitSession: handleSubmitSession,
                onReviewSubmission: handleReviewSubmission,
                onResubmit: handleResubmitSession,
                onNavigateToTab: (tab) => setCurrentTab(tab)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1484,
                columnNumber: 15
              },
              this
            ),
            currentTab === "module-library" && /* @__PURE__ */ jsxDEV(
              ModuleLibraryView,
              {
                modules,
                currentUserRole,
                onCreateModule: handleCreateModule,
                onUpdateModule: handleUpdateModule,
                onDeleteModule: handleDeleteModule,
                onUploadResource: handleUploadModuleResource,
                onDownloadResource: handleDownloadModuleResource
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
                lineNumber: 1498,
                columnNumber: 15
              },
              this
            )
          ] }, `${currentTab}-${currentUserRole}`, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
            lineNumber: 1218,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
            lineNumber: 1217,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
            lineNumber: 1216,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
        lineNumber: 1186,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx",
    lineNumber: 1162,
    columnNumber: 5
  }, this);
}
_s(App, "11viB75z8zMbTp9/UvGrFFuCego=");
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcWtDVzs7QUFya0NYLFNBQWdCQSxVQUFVQyxXQUFXQyxtQkFBbUI7QUF3QnhELFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBOEI7QUFDdkMsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsMkJBQTJCO0FBQ3BDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQywyQkFBMkI7QUFDbEMsU0FBU0MsY0FBYztBQUd2Qix3QkFBd0JDLE1BQU07QUFBQUMsS0FBQTtBQUU1QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSW5DLFNBQTZCLE1BQU07QUFDdkUsUUFBSTtBQUNGLFlBQU1vQyxRQUFRQyxhQUFhQyxRQUFRLGtCQUFrQjtBQUNyRCxVQUFJRixPQUFPO0FBQ1QsZUFBT0csS0FBS0MsTUFBTUosS0FBSztBQUFBLE1BQ3pCO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFDTjtBQUVGLFdBQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNLENBQUNLLGlCQUFpQkMsa0JBQWtCLElBQUkxQyxTQUFtQmtDLGFBQWFTLFFBQVEsYUFBYTtBQUNuRyxRQUFNLENBQUNDLHNCQUFzQkMsdUJBQXVCLElBQUk3QyxTQUFpQmtDLGFBQWFZLGFBQWEsS0FBSztBQUd4RyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWhELFNBQWtCLE1BQU07QUFDMUQsUUFBSTtBQUNGLFlBQU1pRCxXQUFXWixhQUFhQyxRQUFRLG1CQUFtQkosYUFBYVMsUUFBUSxhQUFhLEVBQUU7QUFDN0YsYUFBT00sYUFBYSxvQkFBb0JmLGFBQWFTLFNBQVMsZ0JBQWdCLGNBQWNNLFlBQVk7QUFBQSxJQUMxRyxRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLENBQUNDLHFCQUFxQkMsc0JBQXNCLElBQUluRCxTQUFpQixrQkFBa0I7QUFDekYsUUFBTSxDQUFDb0QsdUJBQXVCQyx3QkFBd0IsSUFBSXJELFNBQW1Fc0QsTUFBUztBQUN0SSxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJeEQsU0FBNkJzRCxNQUFTO0FBQ2hGLFFBQU0sQ0FBQ0csc0JBQXNCQyx1QkFBdUIsSUFBSTFELFNBQTZCc0QsTUFBUztBQUM5RixRQUFNLENBQUNLLHFCQUFxQkMsc0JBQXNCLElBQUk1RCxTQUFrQixLQUFLO0FBQzdFLFFBQU0sQ0FBQzZELGtCQUFrQkMsbUJBQW1CLElBQUk5RCxTQUFrQixLQUFLO0FBQ3ZFLFFBQU0sQ0FBQytELG1CQUFtQkMsb0JBQW9CLElBQUloRSxTQUFrQixLQUFLO0FBQ3pFLFFBQU0sQ0FBQ2lFLHNCQUFzQkMsdUJBQXVCLElBQUlsRSxTQUE2QnNELE1BQVM7QUFFOUZyRCxZQUFVLE1BQU07QUFDZCxRQUFJO0FBQ0ZvQyxtQkFBYThCLFFBQVEsbUJBQW1CMUIsZUFBZSxJQUFJTSxVQUFVO0FBQUEsSUFDdkUsUUFBUTtBQUFBLElBQ047QUFBQSxFQUVKLEdBQUcsQ0FBQ0EsWUFBWU4sZUFBZSxDQUFDO0FBR2hDLFFBQU0sQ0FBQzJCLFVBQVVDLFdBQVcsSUFBSXJFLFNBQW9CLEVBQUU7QUFDdEQsUUFBTSxDQUFDc0UsT0FBT0MsUUFBUSxJQUFJdkUsU0FBaUIsRUFBRTtBQUM3QyxRQUFNLENBQUN3RSxXQUFXQyxZQUFZLElBQUl6RSxTQUF5QixFQUFFO0FBQzdELFFBQU0sQ0FBQzBFLFdBQVdDLFlBQVksSUFBSTNFLFNBQTBCLEVBQUU7QUFDOUQsUUFBTSxDQUFDNEUsWUFBWUMsYUFBYSxJQUFJN0UsU0FBc0IsRUFBRTtBQUM1RCxRQUFNLENBQUM4RSxVQUFVQyxXQUFXLElBQUkvRSxTQUFvQixFQUFFO0FBQ3RELFFBQU0sQ0FBQ2dGLFlBQVlDLGFBQWEsSUFBSWpGLFNBQXNCLEVBQUU7QUFDNUQsUUFBTSxDQUFDa0YsVUFBVUMsV0FBVyxJQUFJbkYsU0FBb0IsRUFBRTtBQUN0RCxRQUFNLENBQUNvRixvQkFBb0JDLHFCQUFxQixJQUFJckYsU0FBOEIsRUFBRTtBQUNwRixRQUFNLENBQUNzRixnQkFBZ0JDLGlCQUFpQixJQUFJdkYsU0FBeUIsRUFBRTtBQUN2RSxRQUFNLENBQUN3RixlQUFlQyxnQkFBZ0IsSUFBSXpGLFNBQXlCLEVBQUU7QUFDckUsUUFBTSxDQUFDMEYsYUFBYUMsY0FBYyxJQUFJM0YsU0FBdUIsRUFBRTtBQUMvRCxRQUFNLENBQUM0RixhQUFhQyxjQUFjLElBQUk3RixTQUE4QixFQUFFO0FBQ3RFLFFBQU0sQ0FBQzhGLGVBQWVDLGdCQUFnQixJQUFJL0YsU0FBNkIsRUFBRTtBQUN6RSxRQUFNLENBQUNnRyxvQkFBb0JDLHFCQUFxQixJQUFJakcsU0FBOEIsRUFBRTtBQUNwRixRQUFNLENBQUNrRyxnQkFBZ0JDLGlCQUFpQixJQUFJbkcsU0FBMEIsRUFBRTtBQUN4RSxRQUFNLENBQUNvRyxvQkFBb0JDLHFCQUFxQixJQUFJckcsU0FBOEIsRUFBRTtBQUNwRixRQUFNLENBQUNzRyxlQUFlQyxnQkFBZ0IsSUFBSXZHLFNBQXlCLEVBQUU7QUFDckUsUUFBTSxDQUFDd0csU0FBU0MsVUFBVSxJQUFJekcsU0FBc0IsRUFBRTtBQUd0RCxRQUFNMEcsbUJBQW1CeEcsWUFBWSxPQUFPeUcsV0FBd0I7QUFDbEUsUUFBSSxDQUFDekUsYUFBYTBFLE1BQU87QUFLekIsVUFBTSxJQUFJQyxRQUFjLENBQUNDLFlBQVk7QUFDbkMsWUFBTUMsSUFBSUMsV0FBV0YsU0FBUyxHQUFHO0FBQ2pDSCxhQUFPTSxpQkFBaUIsU0FBUyxNQUFNQyxhQUFhSCxDQUFDLEdBQUcsRUFBRUksTUFBTSxLQUFLLENBQUM7QUFBQSxJQUN4RSxDQUFDO0FBQ0QsUUFBSVIsT0FBT1MsUUFBUztBQUVwQixVQUFNQyxVQUFVO0FBQUEsTUFDZEMsZUFBZSxVQUFVcEYsWUFBWTBFLEtBQUs7QUFBQSxNQUMxQyxlQUFlbkU7QUFBQUEsTUFDZixxQkFBcUJHO0FBQUFBLElBQ3ZCO0FBRUEsVUFBTTJFLE1BQU1BLENBQUNDLFFBQ1hDLE1BQU0xRixPQUFPeUYsR0FBRyxHQUFHLEVBQUVILFNBQVNWLE9BQU8sQ0FBQyxFQUNuQ2UsS0FBSyxDQUFDQyxhQUFhO0FBQ2xCLFVBQUlBLFNBQVNDLFdBQVcsS0FBSztBQUMzQnZGLHFCQUFhd0YsV0FBVyxrQkFBa0I7QUFDMUMxRix1QkFBZSxJQUFJO0FBQ25CLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBT3dGLFNBQVNHLEtBQUtILFNBQVNJLEtBQUssSUFBSTtBQUFBLElBQ3pDLENBQUMsRUFDQUMsTUFBTSxNQUFNLElBQUk7QUFFckIsUUFBSTtBQUNGLFlBQU07QUFBQSxRQUNKQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxNQUFVLElBQ1IsTUFBTXBDLFFBQVFxQztBQUFBQSxRQUFJO0FBQUEsVUFDcEIzQixJQUFJLDZCQUE2QjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDdkQyRSxJQUFJLDJCQUEyQjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDckQyRSxJQUFJLDZCQUE2QjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDdkQyRSxJQUFJLDJCQUEyQjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDckQyRSxJQUFJLDZCQUE2QjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDdkQyRSxJQUFJLDBCQUEwQjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDcEQyRSxJQUFJLCtCQUErQjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDekQyRSxJQUFJLDRCQUE0QjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDdEQyRSxJQUFJLDZCQUE2QjNFLG9CQUFvQixFQUFFO0FBQUEsVUFDdkQyRSxJQUFJLG9CQUFvQjtBQUFBLFVBQ3hCQSxJQUFJLGVBQWU7QUFBQSxVQUNuQkEsSUFBSSxZQUFZO0FBQUEsVUFDaEJBLElBQUksMkJBQTJCO0FBQUEsVUFDL0JBLElBQUksc0JBQXNCO0FBQUEsVUFDMUJBLElBQUksMEJBQTBCO0FBQUEsVUFDOUJBLElBQUkscUJBQXFCO0FBQUEsVUFDekJBLElBQUksY0FBYztBQUFBLFFBQUM7QUFBQSxNQUNwQjtBQUVELFVBQUlaLE9BQU9TLFFBQVM7QUFFcEIsVUFBSStCLE1BQU1DLFFBQVFuQixlQUFlckQsVUFBVSxFQUFXQyxlQUFjb0QsY0FBY3JELFVBQVU7QUFDNUYsVUFBSXVFLE1BQU1DLFFBQVFsQixhQUFhcEQsUUFBUSxFQUFlQyxhQUFZbUQsWUFBWXBELFFBQVE7QUFDdEYsVUFBSXFFLE1BQU1DLFFBQVFqQixlQUFlbkQsVUFBVSxFQUFXQyxlQUFja0QsY0FBY25ELFVBQVU7QUFDNUYsVUFBSW1FLE1BQU1DLFFBQVFoQixhQUFhbEQsUUFBUSxFQUFlQyxhQUFZaUQsWUFBWWxELFFBQVE7QUFDdEYsVUFBSWlFLE1BQU1DLFFBQVFmLGVBQWVqRCxrQkFBa0IsRUFBR0MsdUJBQXNCZ0QsY0FBY2pELGtCQUFrQjtBQUM1RyxVQUFJK0QsTUFBTUMsUUFBUWQsWUFBWWhELGNBQWMsRUFBVUMsbUJBQWtCK0MsV0FBV2hELGNBQWM7QUFDakcsVUFBSTZELE1BQU1DLFFBQVFiLGdCQUFnQjdDLFdBQVcsRUFBU0MsZ0JBQWU0QyxlQUFlN0MsV0FBVztBQUMvRixVQUFJeUQsTUFBTUMsUUFBUVosY0FBY2hFLFNBQVMsRUFBYUMsY0FBYStELGFBQWFoRSxTQUFTO0FBQ3pGLFVBQUkyRSxNQUFNQyxRQUFRWCxVQUFVL0QsU0FBUyxFQUFpQkMsY0FBYThELFNBQVMvRCxTQUFTO0FBQ3JGLFVBQUl5RSxNQUFNQyxRQUFRVixrQkFBa0I1QyxhQUFhLEVBQUtDLGtCQUFpQjJDLGlCQUFpQjVDLGFBQWE7QUFDckcsVUFBSXFELE1BQU1DLFFBQVFULGFBQWF2RSxRQUFRLEVBQWVDLGFBQVlzRSxZQUFZdkUsUUFBUTtBQUN0RixVQUFJK0UsTUFBTUMsUUFBUVIsVUFBVXRFLEtBQUssRUFBcUJDLFVBQVNxRSxTQUFTdEUsS0FBSztBQUM3RSxVQUFJNkUsTUFBTUMsUUFBUVAsdUJBQXVCN0Msa0JBQWtCLEVBQUdDLHVCQUFzQjRDLHNCQUFzQjdDLGtCQUFrQjtBQUM1SCxVQUFJbUQsTUFBTUMsUUFBUU4sbUJBQW1CNUMsY0FBYyxFQUFXQyxtQkFBa0IyQyxrQkFBa0I1QyxjQUFjO0FBQ2hILFVBQUlpRCxNQUFNQyxRQUFRTCx1QkFBdUIzQyxrQkFBa0IsRUFBR0MsdUJBQXNCMEMsc0JBQXNCM0Msa0JBQWtCO0FBQzVILFVBQUkrQyxNQUFNQyxRQUFRSixrQkFBa0IxQyxhQUFhLEVBQWFDLGtCQUFpQnlDLGlCQUFpQjFDLGFBQWE7QUFDN0csVUFBSTZDLE1BQU1DLFFBQVFILFlBQVl6QyxPQUFPLEVBQXlCQyxZQUFXd0MsV0FBV3pDLE9BQU87QUFBQSxlQUNsRjJDLE1BQU1DLFFBQVFILFlBQVlJLElBQUksRUFBdUI1QyxZQUFXd0MsV0FBV0ksSUFBSTtBQUFBLElBQzFGLFFBQVE7QUFBQSxJQUNOO0FBQUEsRUFFSixHQUFHLENBQUNuSCxhQUFhMEUsT0FBT25FLGlCQUFpQkcsb0JBQW9CLENBQUM7QUFFOUQzQyxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNpQyxhQUFhMEUsTUFBTztBQUN6QixVQUFNMEMsYUFBYSxJQUFJQyxnQkFBZ0I7QUFDdkM3QyxxQkFBaUI0QyxXQUFXM0MsTUFBTTtBQUNsQyxXQUFPLE1BQU0yQyxXQUFXRSxNQUFNO0FBQUEsRUFDaEMsR0FBRyxDQUFDOUMsa0JBQWtCeEUsYUFBYTBFLEtBQUssQ0FBQztBQUd6QyxRQUFNNkMscUJBQXFCQSxDQUFDQyxZQUF5QjtBQUNuRCxRQUFJO0FBQ0ZySCxtQkFBYThCLFFBQVEsb0JBQW9CNUIsS0FBS29ILFVBQVVELE9BQU8sQ0FBQztBQUFBLElBQ2xFLFFBQVE7QUFBQSxJQUNOO0FBRUZ2SCxtQkFBZXVILE9BQU87QUFDdEJoSCx1QkFBbUJnSCxRQUFRL0csSUFBSTtBQUMvQkUsNEJBQXdCNkcsUUFBUTVHLFNBQVM7QUFDekNFLGtCQUFjLFdBQVc7QUFDekIsUUFBSTBHLFFBQVEvRyxTQUFTLGVBQWU7QUFDbENRLDZCQUF1QixrQkFBa0I7QUFBQSxJQUMzQyxXQUFXdUcsUUFBUTVHLGNBQWMsU0FBUztBQUN4Q0ssNkJBQXVCLFNBQVM7QUFBQSxJQUNsQyxXQUFXdUcsUUFBUTVHLGNBQWMsWUFBWTtBQUMzQ0ssNkJBQXVCLGFBQWE7QUFBQSxJQUN0QyxXQUFXdUcsUUFBUTVHLGNBQWMsY0FBYztBQUM3Q0ssNkJBQXVCLGtCQUFrQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU15RyxlQUFlQSxNQUFNO0FBQ3pCLFFBQUk7QUFDRnZILG1CQUFhd0YsV0FBVyxrQkFBa0I7QUFBQSxJQUM1QyxRQUFRO0FBQUEsSUFDTjtBQUVGMUYsbUJBQWUsSUFBSTtBQUNuQmEsa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBR0EsUUFBTTZHLG1CQUFtQkEsQ0FBQ2xILE1BQWdCRyxjQUF1QjtBQUMvREosdUJBQW1CQyxJQUFJO0FBQ3ZCLFFBQUlBLFNBQVMsbUJBQW1CRyxXQUFXO0FBQ3pDRCw4QkFBd0JDLFNBQVM7QUFBQSxJQUNuQyxXQUFXSCxTQUFTLGVBQWU7QUFDakNFLDhCQUF3QixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBR0EsUUFBTWlILDBCQUEwQixPQUFPQyxJQUFZQyxRQUFnQkMsYUFBcUI7QUFDdEYsUUFBSTtBQUNGLFlBQU14QyxNQUFNMUYsT0FBTyxrQkFBa0JnSSxFQUFFLFVBQVUsR0FBRztBQUFBLFFBQ2xERyxRQUFRO0FBQUEsUUFDUjdDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCQyxlQUFlcEYsYUFBYTBFLFFBQVEsVUFBVTFFLFlBQVkwRSxLQUFLLEtBQUs7QUFBQSxVQUNwRSxlQUFlbkU7QUFBQUEsVUFDZixxQkFBcUJHO0FBQUFBLFFBQ3ZCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDTjtBQUdGNkI7QUFBQUEsTUFBYSxDQUFDMEYsU0FDWkEsS0FBS0MsSUFBSSxDQUFDQyxNQUFPQSxFQUFFTixPQUFPQSxLQUFLLEVBQUUsR0FBR00sR0FBR3pDLFFBQVEsV0FBVyxJQUFJeUMsQ0FBRTtBQUFBLElBQ2xFO0FBRUEsUUFBSUwsV0FBVyxjQUFjO0FBQzNCM0U7QUFBQUEsUUFBc0IsQ0FBQzhFLFNBQ3JCQSxLQUFLQyxJQUFJLENBQUNFLE1BQU9BLEVBQUVQLE9BQU9FLFdBQVcsRUFBRSxHQUFHSyxHQUFHMUMsUUFBUSxXQUFXLElBQUkwQyxDQUFFO0FBQUEsTUFDeEU7QUFBQSxJQUNGLFdBQVdOLFdBQVcsZUFBZTtBQUNuQ3JFO0FBQUFBLFFBQWUsQ0FBQ3dFLFNBQ2RBLEtBQUtDLElBQUksQ0FBQ0csT0FBUUEsR0FBR1IsT0FBT0UsV0FBVyxFQUFFLEdBQUdNLElBQUkzQyxRQUFRLFdBQVcsSUFBSTJDLEVBQUc7QUFBQSxNQUM1RTtBQUFBLElBQ0YsV0FBV1AsV0FBVyxXQUFXO0FBQy9CdkU7QUFBQUEsUUFBaUIsQ0FBQzBFLFNBQ2hCQSxLQUFLQyxJQUFJLENBQUNJLE9BQVFBLEdBQUdULE9BQU9FLFdBQVcsRUFBRSxHQUFHTyxJQUFJNUMsUUFBUSxXQUFXLElBQUk0QyxFQUFHO0FBQUEsTUFDNUU7QUFDQWpGO0FBQUFBLFFBQWtCLENBQUM0RSxTQUNqQkEsS0FBS0MsSUFBSSxDQUFDSyxPQUFRQSxHQUFHVixPQUFPRSxZQUFZUSxHQUFHQyxZQUFZVCxXQUFXLEVBQUUsR0FBR1EsSUFBSTdDLFFBQVEsV0FBVyxJQUFJNkMsRUFBRztBQUFBLE1BQ3ZHO0FBQUEsSUFDRjtBQUVBLFVBQU1FLFNBQXdCO0FBQUEsTUFDNUJaLElBQUksT0FBT2EsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDckJDLFlBQVcsb0JBQUlGLEtBQUssR0FBRUcsWUFBWSxFQUFFQyxRQUFRLEtBQUssR0FBRyxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQ2pFQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxNQUNWQyxRQUFRLFlBQVlyQixNQUFNO0FBQUEsTUFDMUJBO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FuSCxXQUFXRjtBQUFBQSxNQUNYMEksYUFBYTtBQUFBLE1BQ2JDLFNBQVMsWUFBWXZCLE1BQU0sZ0JBQWdCQyxRQUFRO0FBQUEsSUFDckQ7QUFDQXRGLGlCQUFhLENBQUN3RixTQUFTLENBQUNRLFFBQVEsR0FBR1IsSUFBSSxDQUFDO0FBRXhDLFVBQU1xQixXQUE2QjtBQUFBLE1BQ2pDekIsSUFBSSxTQUFTYSxLQUFLQyxJQUFJLENBQUM7QUFBQSxNQUN2QlksT0FBTyxHQUFHekIsTUFBTTtBQUFBLE1BQ2hCMEIsU0FBUyw0QkFBNEIxQixNQUFNLEtBQUtDLFFBQVE7QUFBQSxNQUN4RDBCLFNBQVM7QUFBQSxNQUNUQyxRQUFRO0FBQUEsTUFDUkMsTUFBTTtBQUFBLElBQ1I7QUFDQTlGLHFCQUFpQixDQUFDb0UsU0FBUyxDQUFDcUIsVUFBVSxHQUFHckIsSUFBSSxDQUFDO0FBQUEsRUFDaEQ7QUFFQSxRQUFNMkIsMEJBQTBCLE9BQU8vQixJQUFZQyxRQUFnQkMsVUFBa0I4QixXQUFtQjtBQUN0RyxRQUFJO0FBQ0YsWUFBTXRFLE1BQU0xRixPQUFPLGtCQUFrQmdJLEVBQUUscUJBQXFCLEdBQUc7QUFBQSxRQUM3REcsUUFBUTtBQUFBLFFBQ1I3QyxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQkMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLO0FBQUEsVUFDcEUsZUFBZW5FO0FBQUFBLFVBQ2YscUJBQXFCRztBQUFBQSxRQUN2QjtBQUFBLFFBQ0FvSixNQUFNekosS0FBS29ILFVBQVUsRUFBRW9DLE9BQU8sQ0FBQztBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNOO0FBR0Z0SDtBQUFBQSxNQUFhLENBQUMwRixTQUNaQSxLQUFLQztBQUFBQSxRQUFJLENBQUNDLE1BQ1JBLEVBQUVOLE9BQU9BLEtBQUssRUFBRSxHQUFHTSxHQUFHekMsUUFBUSx3QkFBd0JxRSxrQkFBa0JGLE9BQU8sSUFBSTFCO0FBQUFBLE1BQ3JGO0FBQUEsSUFDRjtBQUVBLFFBQUlMLFdBQVcsY0FBYztBQUMzQjNFO0FBQUFBLFFBQXNCLENBQUM4RSxTQUNyQkEsS0FBS0M7QUFBQUEsVUFBSSxDQUFDRSxNQUNSQSxFQUFFUCxPQUFPRSxXQUNMLEVBQUUsR0FBR0ssR0FBRzFDLFFBQVEsd0JBQXdCcUUsa0JBQWtCRixPQUFPLElBQ2pFekI7QUFBQUEsUUFDTjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFdBQVdOLFdBQVcsZUFBZTtBQUNuQ3JFO0FBQUFBLFFBQWUsQ0FBQ3dFLFNBQ2RBLEtBQUtDO0FBQUFBLFVBQUksQ0FBQ0csT0FDUkEsR0FBR1IsT0FBT0UsV0FDTixFQUFFLEdBQUdNLElBQUkzQyxRQUFRLHdCQUF3QnFFLGtCQUFrQkYsT0FBTyxJQUNsRXhCO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRixXQUFXUCxXQUFXLFdBQVc7QUFDL0J2RTtBQUFBQSxRQUFpQixDQUFDMEUsU0FDaEJBLEtBQUtDO0FBQUFBLFVBQUksQ0FBQ0ksT0FDUkEsR0FBR1QsT0FBT0UsV0FDTixFQUFFLEdBQUdPLElBQUk1QyxRQUFRLHdCQUF3QnFFLGtCQUFrQkYsT0FBTyxJQUNsRXZCO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFVBQU1HLFNBQXdCO0FBQUEsTUFDNUJaLElBQUksT0FBT2EsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDckJDLFlBQVcsb0JBQUlGLEtBQUssR0FBRUcsWUFBWSxFQUFFQyxRQUFRLEtBQUssR0FBRyxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQ2pFQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxNQUNWQyxRQUFRLDJCQUEyQnJCLE1BQU07QUFBQSxNQUN6Q0E7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQW5ILFdBQVdGO0FBQUFBLE1BQ1gwSSxhQUFhO0FBQUEsTUFDYkMsU0FBUyw0QkFBNEJ0QixRQUFRLE1BQU04QixNQUFNO0FBQUEsSUFDM0Q7QUFDQXBILGlCQUFhLENBQUN3RixTQUFTLENBQUNRLFFBQVEsR0FBR1IsSUFBSSxDQUFDO0FBRXhDLFVBQU1xQixXQUE2QjtBQUFBLE1BQ2pDekIsSUFBSSxTQUFTYSxLQUFLQyxJQUFJLENBQUM7QUFBQSxNQUN2QlksT0FBTyx5QkFBeUJ6QixNQUFNO0FBQUEsTUFDdEMwQixTQUFTLG9DQUFvQ3pCLFFBQVEsTUFBTThCLE1BQU07QUFBQSxNQUNqRUosU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsSUFDUjtBQUNBOUYscUJBQWlCLENBQUNvRSxTQUFTLENBQUNxQixVQUFVLEdBQUdyQixJQUFJLENBQUM7QUFBQSxFQUNoRDtBQUVBLFFBQU0rQix5QkFBeUIsT0FBT25DLElBQVlDLFFBQWdCQyxVQUFrQjhCLFdBQW1CO0FBQ3JHLFFBQUk7QUFDRixZQUFNdEUsTUFBTTFGLE9BQU8sa0JBQWtCZ0ksRUFBRSxTQUFTLEdBQUc7QUFBQSxRQUNqREcsUUFBUTtBQUFBLFFBQ1I3QyxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQkMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLO0FBQUEsVUFDcEUsZUFBZW5FO0FBQUFBLFVBQ2YscUJBQXFCRztBQUFBQSxRQUN2QjtBQUFBLFFBQ0FvSixNQUFNekosS0FBS29ILFVBQVUsRUFBRW9DLE9BQU8sQ0FBQztBQUFBLE1BQ2pDLENBQUM7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNOO0FBR0Z0SDtBQUFBQSxNQUFhLENBQUMwRixTQUNaQSxLQUFLQyxJQUFJLENBQUNDLE1BQU9BLEVBQUVOLE9BQU9BLEtBQUssRUFBRSxHQUFHTSxHQUFHekMsUUFBUSxZQUFZcUUsa0JBQWtCRixPQUFPLElBQUkxQixDQUFFO0FBQUEsSUFDNUY7QUFBQSxFQUNGO0FBR0EsUUFBTThCLG1CQUFtQixPQUFPQyxTQUEyQjtBQUN6RCxRQUFJO0FBQ0YsWUFBTXpFLFdBQVcsTUFBTUYsTUFBTTFGLE9BQU8sZUFBZSxHQUFHO0FBQUEsUUFDcERtSSxRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRSxnQkFBZ0Isb0JBQW9CQyxlQUFlcEYsYUFBYTBFLFFBQVEsVUFBVTFFLFlBQVkwRSxLQUFLLEtBQUssR0FBRztBQUFBLFFBQ3RIb0YsTUFBTXpKLEtBQUtvSCxVQUFVeUMsSUFBSTtBQUFBLE1BQzNCLENBQUM7QUFDRCxZQUFNL0MsT0FBTyxNQUFNMUIsU0FBU0ksS0FBSztBQUNqQyxVQUFJLENBQUNKLFNBQVNHLE1BQU0sQ0FBQ3VCLE1BQU1nRCxRQUFTLE9BQU0sSUFBSUMsTUFBTWpELE1BQU1rRCxTQUFTLDJCQUEyQjtBQUM5RixVQUFJbEQsS0FBS21ELFFBQVNuSSxhQUFZLENBQUM4RixTQUFTLENBQUMsR0FBR0EsTUFBTWQsS0FBS21ELE9BQU8sQ0FBQztBQUMvRCxVQUFJbkQsS0FBS29ELEtBQU1sSSxVQUFTLENBQUM0RixTQUFTLENBQUMsR0FBR0EsTUFBTWQsS0FBS29ELElBQUksQ0FBQztBQUFBLFdBQ2pEO0FBQ0gsY0FBTUMsZ0JBQWdCLE1BQU1qRixNQUFNMUYsT0FBTyxZQUFZLEdBQUcsRUFBRXNGLFNBQVMsRUFBRUMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLLEdBQUcsRUFBRSxDQUFDO0FBQy9JLGNBQU0rRixZQUFZLE1BQU1ELGNBQWMzRSxLQUFLO0FBQzNDLFlBQUlvQixNQUFNQyxRQUFRdUQsV0FBV3JJLEtBQUssRUFBR0MsVUFBU29JLFVBQVVySSxLQUFLO0FBQUEsTUFDL0Q7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTaUksT0FBWTtBQUNuQixZQUFNQTtBQUFBQSxJQUNSO0FBQUEsRUFDRjtBQUdBLFFBQU1LLHNCQUFzQixPQUFPOUosY0FBc0I7QUFDdkQsUUFBSTtBQUNGLFlBQU0yRSxNQUFNMUYsT0FBTyxpQkFBaUJlLFNBQVMsRUFBRSxHQUFHO0FBQUEsUUFDaERvSCxRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRUMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLLEdBQUc7QUFBQSxNQUNwRixDQUFDO0FBQ0R2QyxrQkFBWSxDQUFDOEYsU0FBU0EsS0FBSzBDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRS9DLE9BQU9qSCxTQUFTLENBQUM7QUFBQSxJQUM5RCxTQUFTeUosT0FBWTtBQUNuQmxJLGtCQUFZLENBQUM4RixTQUFTQSxLQUFLMEMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFL0MsT0FBT2pILFNBQVMsQ0FBQztBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUdBLFFBQU1pSyxnQkFBZ0IsT0FBT0MsU0FBd0I7QUFDbkQsUUFBSTtBQUNGLFlBQU1yRixXQUFXLE1BQU1GLE1BQU0xRixPQUFPLFlBQVksR0FBRztBQUFBLFFBQ2pEbUksUUFBUTtBQUFBLFFBQ1I3QyxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQkMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLO0FBQUEsUUFDdEU7QUFBQSxRQUNBb0YsTUFBTXpKLEtBQUtvSCxVQUFVcUQsSUFBSTtBQUFBLE1BQzNCLENBQUM7QUFDRCxZQUFNM0QsT0FBTyxNQUFNMUIsU0FBU0ksS0FBSztBQUNqQyxVQUFJLENBQUNKLFNBQVNHLE1BQU0sQ0FBQ3VCLE1BQU1nRCxTQUFTO0FBQ2xDLGNBQU0sSUFBSUMsTUFBTWpELE1BQU1rRCxTQUFTLHdCQUF3QjtBQUFBLE1BQ3pEO0FBQ0EsVUFBSWxELEtBQUtvRCxNQUFNO0FBQ2JsSSxpQkFBUyxDQUFDNEYsU0FBUyxDQUFDLEdBQUdBLE1BQU1kLEtBQUtvRCxJQUFJLENBQUM7QUFBQSxNQUN6QztBQUNBLFVBQUk7QUFDRixjQUFNUSxPQUFPLE1BQU14RixNQUFNMUYsT0FBTyxlQUFlLEdBQUc7QUFBQSxVQUNoRHNGLFNBQVMsRUFBRUMsZUFBZXBGLGFBQWEwRSxRQUFRLFVBQVUxRSxZQUFZMEUsS0FBSyxLQUFLLEdBQUc7QUFBQSxRQUNwRixDQUFDO0FBQ0QsY0FBTXNHLFFBQVEsTUFBTUQsS0FBS2xGLEtBQUs7QUFDOUIsWUFBSW9CLE1BQU1DLFFBQVE4RCxPQUFPOUksUUFBUSxFQUFHQyxhQUFZNkksTUFBTTlJLFFBQVE7QUFBQSxNQUNoRSxRQUFRO0FBQUEsTUFDTjtBQUVGLGFBQU87QUFBQSxJQUNULFNBQVNtSSxPQUFZO0FBQ25CLFlBQU1BO0FBQUFBLElBQ1I7QUFBQSxFQUNGO0FBRUEsUUFBTVksbUJBQW1CLE9BQU9wRCxJQUFZMEMsU0FBd0I7QUFDbEUsUUFBSTtBQUNGLFlBQU05RSxXQUFXLE1BQU1GLE1BQU0xRixPQUFPLGNBQWNnSSxFQUFFLEVBQUUsR0FBRyxFQUFFRyxRQUFRLE9BQU83QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsYUFBYTBFLFNBQVMsRUFBRSxHQUFHLEdBQUdvRixNQUFNekosS0FBS29ILFVBQVU4QyxJQUFJLEVBQUUsQ0FBQztBQUM1TSxZQUFNcEQsT0FBTyxNQUFNMUIsU0FBU0ksS0FBSztBQUNqQyxVQUFJLENBQUNKLFNBQVNHLE1BQU0sQ0FBQ3VCLEtBQUtnRCxTQUFTO0FBQUUsZUFBTztBQUFBLE1BQU87QUFDbkQ5SCxlQUFTLENBQUM0RixTQUFTQSxLQUFLQyxJQUFJLENBQUNnRCxTQUFTQSxLQUFLckQsT0FBT0EsS0FBSyxFQUFFLEdBQUdxRCxNQUFNLEdBQUcvRCxLQUFLb0QsS0FBSyxJQUFJVyxJQUFJLENBQUM7QUFDeEYsYUFBTztBQUFBLElBQ1QsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFFBQU1DLG1CQUFtQixPQUFPdEQsT0FBZTtBQUM3QyxVQUFNcEMsV0FBVyxNQUFNRixNQUFNMUYsT0FBTyxjQUFjZ0ksRUFBRSxFQUFFLEdBQUcsRUFBRUcsUUFBUSxVQUFVN0MsU0FBUyxFQUFFQyxlQUFlLFVBQVVwRixhQUFhMEUsU0FBUyxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQy9JLFVBQU15QyxPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFFBQUksQ0FBQ0osU0FBU0csTUFBTSxDQUFDdUIsS0FBS2dELFFBQVM7QUFDbkM5SCxhQUFTLENBQUM0RixTQUFTQSxLQUFLMEMsT0FBTyxDQUFDTyxTQUFTQSxLQUFLckQsT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDMUQ7QUFFQSxRQUFNdUQsc0JBQXNCLE9BQU92RCxJQUFZd0QsYUFBcUI7QUFDbEUsVUFBTTVGLFdBQVcsTUFBTUYsTUFBTTFGLE9BQU8sY0FBY2dJLEVBQUUsaUJBQWlCLEdBQUcsRUFBRUcsUUFBUSxRQUFRN0MsU0FBUyxFQUFFLGdCQUFnQixvQkFBb0JDLGVBQWUsVUFBVXBGLGFBQWEwRSxTQUFTLEVBQUUsR0FBRyxHQUFHb0YsTUFBTXpKLEtBQUtvSCxVQUFVLEVBQUU0RCxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQ3BPLFVBQU1sRSxPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFFBQUksQ0FBQ0osU0FBU0csTUFBTSxDQUFDdUIsS0FBS2dELFFBQVM7QUFDbkM5SCxhQUFTLENBQUM0RixTQUFTQSxLQUFLQyxJQUFJLENBQUNnRCxTQUFTQSxLQUFLckQsT0FBT0EsS0FBSyxFQUFFLEdBQUdxRCxNQUFNSSxvQkFBb0IsTUFBTSxJQUFJSixJQUFJLENBQUM7QUFBQSxFQUN2RztBQUdBLFFBQU1LLGlCQUFpQkEsQ0FBQ0MsS0FBY0MsVUFBbUJDLG1CQUE0QjtBQUNuRixRQUFJRixRQUFRLHNCQUFzQkMsVUFBVTtBQUMxQ3hLLDZCQUF1QndLLFFBQVE7QUFBQSxJQUNqQztBQUNBLFFBQUlELFFBQVEsWUFBWTtBQUN0QixVQUFJQyxZQUFZQyxnQkFBZ0I7QUFDOUJ2SyxpQ0FBeUI7QUFBQSxVQUN2QndLLGFBQWFGO0FBQUFBLFVBQ2JHLFdBQVdGO0FBQUFBLFFBQ2IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQ0EsUUFBSUYsUUFBUSxzQkFBc0JBLFFBQVEsY0FBYztBQUN0RCxVQUFJQyxVQUFVO0FBQ1puSyx5QkFBaUJtSyxRQUFRO0FBQUEsTUFDM0I7QUFDQTNLLG9CQUFjLFlBQVk7QUFDMUI7QUFBQSxJQUNGO0FBQ0EsUUFBSTBLLFFBQVEsZUFBZTtBQUN6QixVQUFJQyxVQUFVO0FBQ1p6SixnQ0FBd0J5SixRQUFRO0FBQUEsTUFDbEMsT0FBTztBQUNMekosZ0NBQXdCWixNQUFTO0FBQUEsTUFDbkM7QUFDQU4sb0JBQWMsYUFBYTtBQUMzQjtBQUFBLElBQ0Y7QUFDQSxRQUFJMEssUUFBUSxxQkFBcUI7QUFDL0IsVUFBSUMsVUFBVTtBQUNaakssZ0NBQXdCaUssUUFBUTtBQUFBLE1BQ2xDO0FBQ0EzSyxvQkFBYyxtQkFBbUI7QUFDakM7QUFBQSxJQUNGO0FBQ0FBLGtCQUFjMEssR0FBRztBQUNqQkssV0FBT0MsU0FBUyxFQUFFQyxLQUFLLEdBQUdDLFVBQVUsU0FBUyxDQUFDO0FBQUEsRUFDaEQ7QUFHQSxRQUFNQyxxQkFBcUJBLENBQUNDLGlCQUt0QjtBQUNKLFVBQU1DLFFBQVFELGFBQWFFLEtBQUtDLFlBQVksRUFBRXZELFFBQVEsUUFBUSxHQUFHO0FBQ2pFLFVBQU13RCxlQUFlSixhQUFhSyxnQkFBZ0JyRSxJQUFJLENBQUNzRSxPQUFPQyxTQUFTO0FBQUEsTUFDckU1RSxJQUFJLEtBQUthLEtBQUtDLElBQUksQ0FBQyxJQUFJOEQsR0FBRztBQUFBLE1BQzFCTCxNQUFNSTtBQUFBQSxNQUNORSxjQUFjO0FBQUEsSUFDaEIsRUFBRTtBQUVGLFVBQU1DLFVBQXFCO0FBQUEsTUFDekI5RSxJQUFJc0U7QUFBQUEsTUFDSkMsTUFBTUYsYUFBYUU7QUFBQUEsTUFDbkI5QixTQUFTNEIsYUFBYTVCLFdBQVc7QUFBQSxNQUNqQzVFLFFBQVF3RyxhQUFheEcsVUFBVTtBQUFBLE1BQy9Ca0gsZUFBZU4sYUFBYU87QUFBQUEsTUFDNUJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxpQkFBaUI7QUFBQSxNQUNqQkMsVUFBVVY7QUFBQUEsSUFDWjtBQUVBM0osa0JBQWMsQ0FBQ3NGLFNBQVMsQ0FBQzBFLFNBQVMsR0FBRzFFLElBQUksQ0FBQztBQUFBLEVBQzVDO0FBRUEsUUFBTWdGLG1CQUFtQkEsQ0FBQ3RCLGFBQXFCdUIsZ0JBQXdCO0FBQ3JFdks7QUFBQUEsTUFBYyxDQUFDc0YsU0FDYkEsS0FBS0MsSUFBSSxDQUFDaUYsTUFBTTtBQUNkLFlBQUlBLEVBQUV0RixPQUFPOEQsYUFBYTtBQUN4QixnQkFBTXlCLGFBQWE7QUFBQSxZQUNqQnZGLElBQUksS0FBS2EsS0FBS0MsSUFBSSxDQUFDO0FBQUEsWUFDbkJ5RCxNQUFNYztBQUFBQSxZQUNOUixjQUFjO0FBQUEsVUFDaEI7QUFDQSxnQkFBTVcsa0JBQWtCLENBQUMsR0FBR0YsRUFBRUgsVUFBVUksVUFBVTtBQUNsRCxpQkFBTztBQUFBLFlBQ0wsR0FBR0Q7QUFBQUEsWUFDSEgsVUFBVUs7QUFBQUEsWUFDVlQsZUFBZVMsZ0JBQWdCUjtBQUFBQSxVQUNqQztBQUFBLFFBQ0Y7QUFDQSxlQUFPTTtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLFFBQU1HLG1CQUFtQkEsQ0FBQ0MsZUFBMkU7QUFDbkcsVUFBTXBCLFFBQVEsT0FBT3pELEtBQUtDLElBQUksQ0FBQztBQUMvQixVQUFNNkUsT0FBTyxVQUFVQyxPQUFPN0ssU0FBU2lLLFNBQVMsQ0FBQyxFQUFFYSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ25FLFVBQU1DLGVBQWVKLFdBQVduQixLQUFLd0IsT0FBTyxDQUFDLEVBQUVDLFlBQVk7QUFDM0QsVUFBTUMsU0FBUyxDQUFDLDJCQUEyQiwyQkFBMkIsMkJBQTJCLHlCQUF5QjtBQUMxSCxVQUFNQyxXQUFXRCxPQUFPbEwsU0FBU2lLLFNBQVNpQixPQUFPakIsTUFBTTtBQUV2RCxVQUFNRixVQUFtQjtBQUFBLE1BQ3ZCLEdBQUdZO0FBQUFBLE1BQ0gxRixJQUFJc0U7QUFBQUEsTUFDSnFCO0FBQUFBLE1BQ0FHO0FBQUFBLE1BQ0FJO0FBQUFBLElBQ0Y7QUFDQWxMLGdCQUFZLENBQUNvRixTQUFTLENBQUMwRSxTQUFTLEdBQUcxRSxJQUFJLENBQUM7QUFFeEN0RjtBQUFBQSxNQUFjLENBQUNzRixTQUNiQSxLQUFLQyxJQUFJLENBQUNpRixNQUFNO0FBQ2QsWUFBSUEsRUFBRXRGLE9BQU8wRixXQUFXNUIsYUFBYTtBQUNuQyxnQkFBTTBCLGtCQUFrQkYsRUFBRUgsU0FBUzlFO0FBQUFBLFlBQUksQ0FBQzhGLE1BQ3RDQSxFQUFFNUIsU0FBU21CLFdBQVdMLGVBQWVjLEVBQUVuRyxPQUFPMEYsV0FBVzNCLFlBQ3JELEVBQUUsR0FBR29DLEdBQUd0QixjQUFjc0IsRUFBRXRCLGVBQWUsRUFBRSxJQUN6Q3NCO0FBQUFBLFVBQ047QUFDQSxpQkFBTztBQUFBLFlBQ0wsR0FBR2I7QUFBQUEsWUFDSEwsZ0JBQWdCSyxFQUFFTCxpQkFBaUI7QUFBQSxZQUNuQ0UsVUFBVUs7QUFBQUEsVUFDWjtBQUFBLFFBQ0Y7QUFDQSxlQUFPRjtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1jLHdCQUF3QkEsQ0FDNUJDLG9CQUNHO0FBQ0gsUUFBSSxDQUFDQSxtQkFBbUJBLGdCQUFnQnJCLFdBQVcsRUFBRztBQUV0RCxVQUFNaUIsU0FBUztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUF5QjtBQUczQixVQUFNSyxlQUFldkwsU0FBU2lLO0FBQzlCLFVBQU11QixlQUEwQkYsZ0JBQWdCaEcsSUFBSSxDQUFDbUcsSUFBSTVCLFFBQVE7QUFDL0QsWUFBTTZCLGFBQWFILGVBQWUxQixNQUFNO0FBQ3hDLGFBQU87QUFBQSxRQUNMLEdBQUc0QjtBQUFBQSxRQUNIeEcsSUFBSSxPQUFPYSxLQUFLQyxJQUFJLENBQUMsSUFBSThELEdBQUcsSUFBSThCLEtBQUtDLE9BQU8sRUFBRUMsU0FBUyxFQUFFLEVBQUVDLFVBQVUsR0FBRyxDQUFDLENBQUM7QUFBQSxRQUMxRWxCLE1BQU0sVUFBVUMsT0FBT2EsVUFBVSxFQUFFWixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsUUFDbkRDLGVBQWVVLEdBQUdqQyxRQUFRLEtBQUt3QixPQUFPLENBQUMsRUFBRUMsWUFBWTtBQUFBLFFBQ3JERSxVQUFVRCxRQUFRSyxlQUFlMUIsT0FBT3FCLE9BQU9qQixNQUFNO0FBQUEsTUFDdkQ7QUFBQSxJQUNGLENBQUM7QUFFRGhLLGdCQUFZLENBQUNvRixTQUFTLENBQUMsR0FBR21HLGNBQWMsR0FBR25HLElBQUksQ0FBQztBQUVoRHRGO0FBQUFBLE1BQWMsQ0FBQ3NGLFNBQ2JBLEtBQUtDLElBQUksQ0FBQ2lGLE1BQU07QUFDZCxjQUFNd0IsZ0JBQWdCUCxhQUFhekQsT0FBTyxDQUFDdkMsTUFBTUEsRUFBRXVELGdCQUFnQndCLEVBQUV0RixFQUFFO0FBQ3ZFLFlBQUk4RyxjQUFjOUIsU0FBUyxHQUFHO0FBQzVCLGdCQUFNUSxrQkFBa0JGLEVBQUVILFNBQVM5RSxJQUFJLENBQUM4RixNQUFNO0FBQzVDLGtCQUFNWSxlQUFlRCxjQUFjaEU7QUFBQUEsY0FDakMsQ0FBQ3ZDLE1BQU1BLEVBQUV3RCxjQUFjb0MsRUFBRW5HLE1BQU1PLEVBQUU4RSxnQkFBZ0JjLEVBQUU1QjtBQUFBQSxZQUNyRDtBQUNBLG1CQUFPO0FBQUEsY0FDTCxHQUFHNEI7QUFBQUEsY0FDSHRCLGNBQWNzQixFQUFFdEIsZUFBZWtDLGFBQWEvQjtBQUFBQSxZQUM5QztBQUFBLFVBQ0YsQ0FBQztBQUNELGlCQUFPO0FBQUEsWUFDTCxHQUFHTTtBQUFBQSxZQUNITCxnQkFBZ0JLLEVBQUVMLGlCQUFpQjZCLGNBQWM5QjtBQUFBQSxZQUNqREcsVUFBVUs7QUFBQUEsVUFDWjtBQUFBLFFBQ0Y7QUFDQSxlQUFPRjtBQUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0wQixzQkFBc0JBLENBQUNoSCxJQUFZaUgsWUFBOEI7QUFDckVqTSxnQkFBWSxDQUFDb0YsU0FBU0EsS0FBS0MsSUFBSSxDQUFDRSxNQUFPQSxFQUFFUCxPQUFPQSxLQUFLLEVBQUUsR0FBR08sR0FBRyxHQUFHMEcsUUFBUSxJQUFJMUcsQ0FBRSxDQUFDO0FBQUEsRUFDakY7QUFFQSxRQUFNMkcsc0JBQXNCQSxDQUFDbEgsT0FBZTtBQUMxQyxVQUFNbUgsV0FBV3BNLFNBQVNxTSxLQUFLLENBQUM3RyxNQUFNQSxFQUFFUCxPQUFPQSxFQUFFO0FBQ2pELFFBQUltSCxVQUFVO0FBQ1pyTTtBQUFBQSxRQUFjLENBQUNzRixTQUNiQSxLQUFLQyxJQUFJLENBQUNpRixNQUFNO0FBQ2QsY0FBSUEsRUFBRXRGLE9BQU9tSCxTQUFTckQsYUFBYTtBQUNqQyxrQkFBTTBCLGtCQUFrQkYsRUFBRUgsU0FBUzlFO0FBQUFBLGNBQUksQ0FBQzhGLE1BQ3RDQSxFQUFFNUIsU0FBUzRDLFNBQVM5QixlQUFlYyxFQUFFbkcsT0FBT21ILFNBQVNwRCxZQUNqRCxFQUFFLEdBQUdvQyxHQUFHdEIsY0FBYzZCLEtBQUtXLElBQUksR0FBR2xCLEVBQUV0QixlQUFlLENBQUMsRUFBRSxJQUN0RHNCO0FBQUFBLFlBQ047QUFDQSxtQkFBTztBQUFBLGNBQ0wsR0FBR2I7QUFBQUEsY0FDSEwsZ0JBQWdCeUIsS0FBS1csSUFBSSxHQUFHL0IsRUFBRUwsaUJBQWlCLENBQUM7QUFBQSxjQUNoREUsVUFBVUs7QUFBQUEsWUFDWjtBQUFBLFVBQ0Y7QUFDQSxpQkFBT0Y7QUFBQUEsUUFDVCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQXRLLGdCQUFZLENBQUNvRixTQUFTQSxLQUFLMEMsT0FBTyxDQUFDdkMsTUFBTUEsRUFBRVAsT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDdkQ7QUFHQSxRQUFNc0gscUJBQXFCQSxDQUFDQyxXQUF5RztBQUNuSSxVQUFNakQsUUFBUSxPQUFPekQsS0FBS0MsSUFBSSxDQUFDO0FBQy9CLFVBQU0wRyxRQUFRRCxPQUFPaEQsS0FBS2tELE1BQU0sR0FBRztBQUNuQyxVQUFNQyxhQUFhRixNQUFNeEMsU0FBUyxJQUFJLEdBQUd3QyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBR0EsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUd4QixZQUFZLElBQUl1QixPQUFPaEQsS0FBS3JELE1BQU0sR0FBRyxDQUFDLEVBQUU4RSxZQUFZO0FBRXpILFVBQU1sQixVQUFxQjtBQUFBLE1BQ3pCLEdBQUd5QztBQUFBQSxNQUNIdkgsSUFBSXNFO0FBQUFBLE1BQ0pvRDtBQUFBQSxNQUNBQyxlQUFlO0FBQUEsTUFDZkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLElBQ2xCO0FBQ0EzTSxrQkFBYyxDQUFDa0YsU0FBUyxDQUFDMEUsU0FBUyxHQUFHMUUsSUFBSSxDQUFDO0FBQUEsRUFDNUM7QUFFQSxRQUFNMEgsd0JBQXdCQSxDQUFDOUgsSUFBWWlILFlBQWdDO0FBQ3pFL0wsa0JBQWMsQ0FBQ2tGLFNBQVNBLEtBQUtDLElBQUksQ0FBQzhGLE1BQU9BLEVBQUVuRyxPQUFPQSxLQUFLLEVBQUUsR0FBR21HLEdBQUcsR0FBR2MsUUFBUSxJQUFJZCxDQUFFLENBQUM7QUFBQSxFQUNuRjtBQUVBLFFBQU00Qix3QkFBd0JBLENBQUMvSCxPQUFlO0FBQzVDOUUsa0JBQWMsQ0FBQ2tGLFNBQVNBLEtBQUswQyxPQUFPLENBQUNxRCxNQUFNQSxFQUFFbkcsT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDekQ7QUFHQSxRQUFNZ0ksbUJBQW1CQSxDQUFDQyxlQUFvQztBQUM1RCxVQUFNbkQsVUFBbUI7QUFBQSxNQUN2QixHQUFHbUQ7QUFBQUEsTUFDSGpJLElBQUksUUFBUWEsS0FBS0MsSUFBSSxDQUFDO0FBQUEsSUFDeEI7QUFDQTFGLGdCQUFZLENBQUNnRixTQUFTLENBQUMwRSxTQUFTLEdBQUcxRSxJQUFJLENBQUM7QUFBQSxFQUMxQztBQUVBLFFBQU04SCxzQkFBc0IsT0FBT2xJLElBQVlpSCxZQUE4QjtBQUMzRSxVQUFNa0IsV0FBV2hOLFNBQVNpTSxLQUFLLENBQUN6SCxZQUFZQSxRQUFRSyxPQUFPQSxFQUFFO0FBQzdELFFBQUk3SCxhQUFhMEUsU0FBU3NMLFVBQVU7QUFDbEMsWUFBTXZLLFdBQVcsTUFBTUYsTUFBTTFGLE9BQU8saUJBQWlCZ0ksRUFBRSxFQUFFLEdBQUc7QUFBQSxRQUMxREcsUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsWUFBWTBFLEtBQUssR0FBRztBQUFBLFFBQzVGb0YsTUFBTXpKLEtBQUtvSCxVQUFVO0FBQUEsVUFDbkIsR0FBR3VJO0FBQUFBLFVBQ0gsR0FBR2xCO0FBQUFBLFVBQ0htQixjQUFjRCxTQUFTQztBQUFBQSxVQUN2QkMsV0FBV0YsU0FBU0U7QUFBQUEsVUFDcEJDLGFBQWFILFNBQVM1RDtBQUFBQSxRQUN4QixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQ0QsVUFBSSxDQUFDM0csU0FBU0csR0FBSTtBQUFBLElBQ3BCO0FBQ0EzQyxnQkFBWSxDQUFDZ0YsU0FBU0EsS0FBS0MsSUFBSSxDQUFDRSxNQUFPQSxFQUFFUCxPQUFPQSxLQUFLLEVBQUUsR0FBR08sR0FBRyxHQUFHMEcsUUFBUSxJQUFJMUcsQ0FBRSxDQUFDO0FBQUEsRUFDakY7QUFFQSxRQUFNZ0ksc0JBQXNCQSxDQUFDdkksT0FBZTtBQUMxQzVFLGdCQUFZLENBQUNnRixTQUFTQSxLQUFLMEMsT0FBTyxDQUFDdkMsTUFBTUEsRUFBRVAsT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDdkQ7QUFHQSxRQUFNd0ksdUJBQXVCLE9BQU83SSxZQUErQjtBQUNqRSxRQUFJakgsb0JBQW9CLG1CQUFtQlAsYUFBYTBFLE9BQU87QUFDN0QsWUFBTWUsV0FBVyxNQUFNRixNQUFNMUYsT0FBTyxpQkFBaUIsR0FBRztBQUFBLFFBQ3REbUksUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsWUFBWTBFLEtBQUssR0FBRztBQUFBLFFBQzVGb0YsTUFBTXpKLEtBQUtvSCxVQUFVRCxPQUFPO0FBQUEsTUFDOUIsQ0FBQztBQUNELFVBQUksQ0FBQy9CLFNBQVNHLEdBQUk7QUFBQSxJQUNwQjtBQUVBekMsMEJBQXNCLENBQUM4RSxTQUFTO0FBQzlCLFlBQU13RSxNQUFNeEUsS0FBS3FJLFVBQVUsQ0FBQ2xJLE1BQU1BLEVBQUVQLE9BQU9MLFFBQVFLLEVBQUU7QUFDckQsVUFBSTRFLE9BQU8sR0FBRztBQUNaLGNBQU04RCxPQUFPLENBQUMsR0FBR3RJLElBQUk7QUFDckJzSSxhQUFLOUQsR0FBRyxJQUFJakY7QUFDWixlQUFPK0k7QUFBQUEsTUFDVDtBQUNBLGFBQU8sQ0FBQy9JLFNBQVMsR0FBR1MsSUFBSTtBQUFBLElBQzFCLENBQUM7QUFFRCxRQUFJVCxRQUFROUIsV0FBVyxhQUFhO0FBQ2xDLFlBQU04SyxVQUF3QjtBQUFBLFFBQzVCM0ksSUFBSSxRQUFRYSxLQUFLQyxJQUFJLENBQUM7QUFBQSxRQUN0QmIsUUFBUTtBQUFBLFFBQ1JDLFVBQVVQLFFBQVFLO0FBQUFBLFFBQ2xCNEksYUFBYSxHQUFHakosUUFBUWtKLGlCQUFpQixRQUFRLE1BQU1sSixRQUFRMkksZUFBZSxZQUFZO0FBQUEsUUFDMUZ2UCxXQUFXRjtBQUFBQSxRQUNYMEksYUFBYTtBQUFBLFFBQ2J1SCxhQUFhO0FBQUEsUUFDYkMsYUFBYTtBQUFBLFFBQ2JsTCxRQUFRO0FBQUEsUUFDUjJELFNBQVM7QUFBQSxVQUNQd0gsY0FBY3JKLFFBQVFxSixnQkFBZ0JySixRQUFRc0osU0FBU25HLE9BQU8sQ0FBQ3ZDLE1BQU1BLEVBQUUxQyxXQUFXLFNBQVMsRUFBRW1ILFVBQVU7QUFBQSxVQUN2R2tFLFlBQVl2SixRQUFRdUosY0FBY3ZKLFFBQVFzSixTQUFTakUsVUFBVTtBQUFBLFVBQzdESyxhQUFhMUYsUUFBUTBGLGVBQWU7QUFBQSxVQUNwQ2dELFdBQVcxSSxRQUFRMEksYUFBYTtBQUFBLFFBQ2xDO0FBQUEsTUFDRjtBQUNBM04sbUJBQWEsQ0FBQzBGLFNBQVMsQ0FBQ3VJLFNBQVMsR0FBR3ZJLElBQUksQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUdBLFFBQU0rSSx3QkFBd0JBLENBQUNDLFVBQW9DO0FBQ2pFLFVBQU10RSxVQUF3QjtBQUFBLE1BQzVCLEdBQUdzRTtBQUFBQSxNQUNIcEosSUFBSSxPQUFPYSxLQUFLQyxJQUFJLENBQUMsSUFBSTRGLEtBQUsyQyxNQUFNM0MsS0FBS0MsT0FBTyxJQUFJLEdBQUksQ0FBQztBQUFBLElBQzNEO0FBQ0FuTCxzQkFBa0IsQ0FBQzRFLFNBQVMsQ0FBQzBFLFNBQVMsR0FBRzFFLElBQUksQ0FBQztBQUFBLEVBQ2hEO0FBRUEsUUFBTWtKLDJCQUEyQkEsQ0FBQ3RKLElBQVlpSCxZQUFtQztBQUMvRXpMLHNCQUFrQixDQUFDNEUsU0FBU0EsS0FBS0MsSUFBSSxDQUFDa0osTUFBT0EsRUFBRXZKLE9BQU9BLEtBQUssRUFBRSxHQUFHdUosR0FBRyxHQUFHdEMsUUFBUSxJQUFJc0MsQ0FBRSxDQUFDO0FBQUEsRUFDdkY7QUFFQSxRQUFNQywyQkFBMkJBLENBQUN4SixPQUFlO0FBQy9DeEUsc0JBQWtCLENBQUM0RSxTQUFTQSxLQUFLMEMsT0FBTyxDQUFDeUcsTUFBTUEsRUFBRXZKLE9BQU9BLEVBQUUsQ0FBQztBQUFBLEVBQzdEO0FBRUEsUUFBTXlKLHlCQUF5QkEsQ0FBQ0MsVUFBd0I7QUFDdERoTyxxQkFBaUIsQ0FBQzBFLFNBQVM7QUFDekIsWUFBTXdFLE1BQU14RSxLQUFLcUksVUFBVSxDQUFDa0IsTUFBTUEsRUFBRTNKLE9BQU8wSixNQUFNMUosRUFBRTtBQUNuRCxVQUFJNEUsT0FBTyxHQUFHO0FBQ1osY0FBTThELE9BQU8sQ0FBQyxHQUFHdEksSUFBSTtBQUNyQnNJLGFBQUs5RCxHQUFHLElBQUk4RTtBQUNaLGVBQU9oQjtBQUFBQSxNQUNUO0FBQ0EsYUFBTyxDQUFDZ0IsT0FBTyxHQUFHdEosSUFBSTtBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTXdKLDJCQUEyQkEsQ0FBQ2pKLFlBQW9CO0FBQ3BEakYscUJBQWlCLENBQUMwRSxTQUFTQSxLQUFLMEMsT0FBTyxDQUFDNkcsTUFBTUEsRUFBRTNKLE9BQU9XLE9BQU8sQ0FBQztBQUFBLEVBQ2pFO0FBRUEsUUFBTWtKLDJCQUEyQkEsQ0FBQ2xKLFlBQW9CO0FBQ3BEakY7QUFBQUEsTUFBaUIsQ0FBQzBFLFNBQ2hCQSxLQUFLQyxJQUFJLENBQUNzSixNQUFPQSxFQUFFM0osT0FBT1csVUFBVSxFQUFFLEdBQUdnSixHQUFHOUwsUUFBUSxVQUFVLElBQUk4TCxDQUFFO0FBQUEsSUFDdEU7QUFDQW5PO0FBQUFBLE1BQWtCLENBQUM0RSxTQUNqQkEsS0FBS0MsSUFBSSxDQUFDa0osTUFBT0EsRUFBRTVJLFlBQVlBLFVBQVUsRUFBRSxHQUFHNEksR0FBRzFMLFFBQVEsVUFBVSxJQUFJMEwsQ0FBRTtBQUFBLElBQzNFO0FBRUEsVUFBTU8sY0FBY3JPLGNBQWMyTCxLQUFLLENBQUN1QyxNQUFNQSxFQUFFM0osT0FBT1csT0FBTztBQUM5RCxVQUFNZ0ksVUFBd0I7QUFBQSxNQUM1QjNJLElBQUksUUFBUWEsS0FBS0MsSUFBSSxDQUFDO0FBQUEsTUFDdEJiLFFBQVE7QUFBQSxNQUNSQyxVQUFVUztBQUFBQSxNQUNWaUksYUFBYWtCLGFBQWFwSSxTQUFTO0FBQUEsTUFDbkMzSSxXQUFXRjtBQUFBQSxNQUNYMEksYUFBYTtBQUFBLE1BQ2J1SCxhQUFhO0FBQUEsTUFDYkMsYUFBYTtBQUFBLE1BQ2JsTCxRQUFRO0FBQUEsTUFDUjJELFNBQVM7QUFBQSxRQUNQdUksYUFBYUQsYUFBYUMsZUFBZTtBQUFBLFFBQ3pDQyxXQUFXRixhQUFhRyxRQUFRakYsVUFBVTtBQUFBLFFBQzFDa0YsVUFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0F4UCxpQkFBYSxDQUFDMEYsU0FBUyxDQUFDdUksU0FBUyxHQUFHdkksSUFBSSxDQUFDO0FBQUEsRUFDM0M7QUFHQSxRQUFNK0osc0JBQXNCQSxDQUFDQyxTQUFpQztBQUM1RCxVQUFNdEYsVUFBc0I7QUFBQSxNQUMxQixHQUFHc0Y7QUFBQUEsTUFDSHBLLElBQUksTUFBTWEsS0FBS0MsSUFBSSxDQUFDO0FBQUEsSUFDdEI7QUFDQWxGLG1CQUFlLENBQUN3RSxTQUFTLENBQUMwRSxTQUFTLEdBQUcxRSxJQUFJLENBQUM7QUFBQSxFQUM3QztBQUVBLFFBQU1pSyx5QkFBeUJBLENBQUNySyxJQUFZb0ssU0FBOEI7QUFDeEV4TyxtQkFBZSxDQUFDd0UsU0FBU0EsS0FBS0MsSUFBSSxDQUFDaUYsTUFBT0EsRUFBRXRGLE9BQU9BLEtBQUssRUFBRSxHQUFHc0YsR0FBRyxHQUFHOEUsS0FBSyxJQUFJOUUsQ0FBRSxDQUFDO0FBQUEsRUFDakY7QUFFQSxRQUFNZ0YseUJBQXlCQSxDQUFDdEssT0FBZTtBQUM3Q3BFLG1CQUFlLENBQUN3RSxTQUFTQSxLQUFLMEMsT0FBTyxDQUFDd0MsTUFBTUEsRUFBRXRGLE9BQU9BLEVBQUUsQ0FBQztBQUFBLEVBQzFEO0FBR0EsUUFBTXVLLG1CQUFtQkEsQ0FBQ3ZLLE9BQWU7QUFDdkNoRSxxQkFBaUIsQ0FBQ29FLFNBQVNBLEtBQUtDLElBQUksQ0FBQ21LLE1BQU9BLEVBQUV4SyxPQUFPQSxLQUFLLEVBQUUsR0FBR3dLLEdBQUczSSxRQUFRLEtBQUssSUFBSTJJLENBQUUsQ0FBQztBQUFBLEVBQ3hGO0FBRUEsUUFBTUMsc0JBQXNCQSxNQUFNO0FBQ2hDek8scUJBQWlCLENBQUNvRSxTQUFTQSxLQUFLQyxJQUFJLENBQUNtSyxPQUFPLEVBQUUsR0FBR0EsR0FBRzNJLFFBQVEsS0FBSyxFQUFFLENBQUM7QUFBQSxFQUN0RTtBQUdBLFFBQU02SSxnQ0FBZ0MsT0FBT0MsV0FBbUJDLGNBQXNCQyxlQUF1QjdJLFdBQW1CO0FBQzlILFFBQUk7QUFDRixZQUFNcEUsV0FBVyxNQUFNRixNQUFNMUYsT0FBTywyQkFBMkIsR0FBRztBQUFBLFFBQ2hFbUksUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsYUFBYTBFLFNBQVMsRUFBRSxHQUFHO0FBQUEsUUFDbkdvRixNQUFNekosS0FBS29ILFVBQVUsRUFBRStLLFdBQVdDLGNBQWNDLGVBQWU3SSxPQUFPLENBQUM7QUFBQSxNQUN6RSxDQUFDO0FBQ0QsWUFBTTFDLE9BQU8sTUFBTTFCLFNBQVNJLEtBQUs7QUFDakMsVUFBSXNCLE1BQU1nRCxXQUFXaEQsS0FBS3dMLG1CQUFtQjtBQUMzQzVPLDhCQUFzQixDQUFBa0UsU0FBUSxDQUFDZCxLQUFLd0wsbUJBQW1CLEdBQUcxSyxJQUFJLENBQUM7QUFBQSxNQUNqRTtBQUFBLElBQ0YsUUFBUTtBQUFBLElBQUU7QUFBQSxFQUNaO0FBRUEsUUFBTTJLLGdDQUFnQyxPQUFPQyxXQUFtQjFKLFFBQThCMkosWUFBb0I7QUFDaEgsUUFBSTtBQUNGLFlBQU1yTixXQUFXLE1BQU1GLE1BQU0xRixPQUFPLDZCQUE2QmdULFNBQVMsSUFBSTFKLE1BQU0sRUFBRSxHQUFHO0FBQUEsUUFDdkZuQixRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRSxnQkFBZ0Isb0JBQW9CQyxlQUFlLFVBQVVwRixhQUFhMEUsU0FBUyxFQUFFLEdBQUc7QUFBQSxRQUNuR29GLE1BQU16SixLQUFLb0gsVUFBVSxFQUFFcUwsUUFBUSxDQUFDO0FBQUEsTUFDbEMsQ0FBQztBQUNELFlBQU0zTCxPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFVBQUlzQixNQUFNZ0QsU0FBUztBQUNqQnBHLDhCQUFzQixDQUFBa0UsU0FBUUEsS0FBS0MsSUFBSSxDQUFBNkssTUFBS0EsRUFBRWxMLE9BQU9nTCxZQUFZLEVBQUUsR0FBR0UsR0FBR3JOLFFBQVF5RCxXQUFXLFlBQVksYUFBYSxZQUFZNkosZUFBZUYsUUFBUSxJQUFJQyxDQUFDLENBQUM7QUFDOUosWUFBSTVKLFdBQVcsV0FBVztBQUV4QjNFLDJCQUFpQixJQUFJNkMsZ0JBQWdCLEVBQUU1QyxNQUFNO0FBQUEsUUFDL0M7QUFBQSxNQUNGO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFHQSxRQUFNd08sMEJBQTBCLE9BQU9DLFdBQW1DO0FBQ3hFLFFBQUk7QUFDRixZQUFNek4sV0FBVyxNQUFNRixNQUFNMUYsT0FBTyxzQkFBc0IsR0FBRztBQUFBLFFBQzNEbUksUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsYUFBYTBFLFNBQVMsRUFBRSxHQUFHO0FBQUEsUUFDbkdvRixNQUFNekosS0FBS29ILFVBQVV5TCxNQUFNO0FBQUEsTUFDN0IsQ0FBQztBQUNELFlBQU0vTCxPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFVBQUlzQixNQUFNZ0QsV0FBV2hELEtBQUtnTSxlQUFlO0FBQ3ZDbFAsMEJBQWtCLENBQUFnRSxTQUFRO0FBQ3hCLGdCQUFNd0UsTUFBTXhFLEtBQUtxSSxVQUFVLENBQUF5QyxNQUFLQSxFQUFFbEwsT0FBT1YsS0FBS2dNLGNBQWN0TCxFQUFFO0FBQzlELGNBQUk0RSxPQUFPLEdBQUc7QUFBRSxrQkFBTThELE9BQU8sQ0FBQyxHQUFHdEksSUFBSTtBQUFHc0ksaUJBQUs5RCxHQUFHLElBQUl0RixLQUFLZ007QUFBZSxtQkFBTzVDO0FBQUFBLFVBQU07QUFDckYsaUJBQU8sQ0FBQ3BKLEtBQUtnTSxlQUFlLEdBQUdsTCxJQUFJO0FBQUEsUUFDckMsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUFFO0FBQUEsRUFDWjtBQUVBLFFBQU1tTCw0QkFBNEIsT0FBT0MsYUFBcUI7QUFDNUQsUUFBSTtBQUNGLFlBQU05TixNQUFNMUYsT0FBTyx3QkFBd0J3VCxRQUFRLEVBQUUsR0FBRztBQUFBLFFBQ3REckwsUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUVDLGVBQWUsVUFBVXBGLGFBQWEwRSxTQUFTLEVBQUUsR0FBRztBQUFBLE1BQ2pFLENBQUM7QUFDRFQsd0JBQWtCLENBQUFnRSxTQUFRQSxLQUFLMEMsT0FBTyxDQUFBb0ksTUFBS0EsRUFBRWxMLE9BQU93TCxRQUFRLENBQUM7QUFBQSxJQUMvRCxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFHQSxRQUFNQyxzQkFBc0IsT0FBT2QsV0FBbUI1UixXQUFtQnNQLGNBQXNCO0FBQzdGLFFBQUk7QUFDRixZQUFNekssV0FBVyxNQUFNRixNQUFNMUYsT0FBTywwQkFBMEIsR0FBRztBQUFBLFFBQy9EbUksUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQkMsZUFBZSxVQUFVcEYsYUFBYTBFLFNBQVMsRUFBRSxHQUFHO0FBQUEsUUFDbkdvRixNQUFNekosS0FBS29ILFVBQVUsRUFBRStLLFdBQVc1UixXQUFXc1AsVUFBVSxDQUFDO0FBQUEsTUFDMUQsQ0FBQztBQUNELFlBQU0vSSxPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFVBQUlzQixNQUFNZ0QsV0FBV2hELEtBQUtvTSxZQUFZO0FBQ3BDcFAsOEJBQXNCLENBQUE4RCxTQUFRLENBQUNkLEtBQUtvTSxZQUFZLEdBQUd0TCxJQUFJLENBQUM7QUFDeEQsZUFBTyxFQUFFa0MsU0FBUyxLQUFLO0FBQUEsTUFDekI7QUFDQSxhQUFPLEVBQUVBLFNBQVMsT0FBT0UsT0FBT2xELE1BQU1rRCxPQUFPbUosY0FBY3JNLE1BQU1xTSxhQUFhO0FBQUEsSUFDaEYsUUFBUTtBQUNOLGFBQU8sRUFBRXJKLFNBQVMsT0FBT0UsT0FBTyxnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0oseUJBQXlCLE9BQU9DLGNBQXNCdkssUUFBb0MySixZQUFvQjtBQUNsSCxRQUFJO0FBQ0YsWUFBTXZOLE1BQU0xRixPQUFPLDRCQUE0QjZULFlBQVksU0FBUyxHQUFHO0FBQUEsUUFDckUxTCxRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRSxnQkFBZ0Isb0JBQW9CQyxlQUFlLFVBQVVwRixhQUFhMEUsU0FBUyxFQUFFLEdBQUc7QUFBQSxRQUNuR29GLE1BQU16SixLQUFLb0gsVUFBVSxFQUFFMEIsUUFBUTJKLFFBQVEsQ0FBQztBQUFBLE1BQzFDLENBQUM7QUFDRDNPLDRCQUFzQixDQUFBOEQsU0FBUUEsS0FBS0MsSUFBSSxDQUFBRSxNQUFLQSxFQUFFUCxPQUFPNkwsZUFBZTtBQUFBLFFBQ2xFLEdBQUd0TDtBQUFBQSxRQUNIMUMsUUFBUXlELFdBQVcsWUFBWSxhQUFhO0FBQUEsUUFDNUM2SixlQUFlRjtBQUFBQSxNQUNqQixJQUFJMUssQ0FBQyxDQUFDO0FBQUEsSUFDUixRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFFQSxRQUFNdUwsd0JBQXdCLE9BQU9ELGlCQUF5QjtBQUM1RCxRQUFJO0FBQ0YsWUFBTW5PLE1BQU0xRixPQUFPLDRCQUE0QjZULFlBQVksV0FBVyxHQUFHO0FBQUEsUUFDdkUxTCxRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRSxnQkFBZ0Isb0JBQW9CQyxlQUFlLFVBQVVwRixhQUFhMEUsU0FBUyxFQUFFLEdBQUc7QUFBQSxNQUNyRyxDQUFDO0FBQ0RQLDRCQUFzQixDQUFBOEQsU0FBUUEsS0FBS0MsSUFBSSxDQUFBRSxNQUFLQSxFQUFFUCxPQUFPNkwsZUFBZSxFQUFFLEdBQUd0TCxHQUFHMUMsUUFBUSxjQUFjLElBQUkwQyxDQUFDLENBQUM7QUFBQSxJQUMxRyxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFHQSxRQUFNd0wscUJBQXFCLE9BQU9DLGVBQTBJO0FBQzFLLFFBQUk7QUFDRixZQUFNcE8sV0FBVyxNQUFNRixNQUFNMUYsT0FBTyxjQUFjLEdBQUc7QUFBQSxRQUNuRG1JLFFBQVE7QUFBQSxRQUNSN0MsU0FBUyxFQUFFLGdCQUFnQixvQkFBb0JDLGVBQWUsVUFBVXBGLGFBQWEwRSxTQUFTLEVBQUUsR0FBRztBQUFBLFFBQ25Hb0YsTUFBTXpKLEtBQUtvSCxVQUFVb00sVUFBVTtBQUFBLE1BQ2pDLENBQUM7QUFDRCxZQUFNMU0sT0FBTyxNQUFNMUIsU0FBU0ksS0FBSztBQUNqQyxZQUFNaU8sU0FBb0I7QUFBQSxRQUN4QmpNLElBQUlWLE1BQU1XLFFBQVFELE1BQU0sT0FBT2EsS0FBS0MsSUFBSSxDQUFDO0FBQUEsUUFDekNvTCxjQUFjRixXQUFXRTtBQUFBQSxRQUN6QkMsWUFBWUgsV0FBV0c7QUFBQUEsUUFDdkJDLE9BQU9KLFdBQVdJO0FBQUFBLFFBQ2xCQyxhQUFhTCxXQUFXSztBQUFBQSxRQUN4QmpFLGNBQWM0RCxXQUFXNUQ7QUFBQUEsUUFDekJDLFdBQVcyRCxXQUFXM0Q7QUFBQUEsUUFDdEJ4SyxRQUFRO0FBQUEsUUFDUnlPLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsV0FBV3JVLGFBQWFvTSxRQUFRO0FBQUEsUUFDaENrSSxZQUFXLG9CQUFJNUwsS0FBSyxHQUFFRyxZQUFZO0FBQUEsUUFDbEMwTCxZQUFXLG9CQUFJN0wsS0FBSyxHQUFFRyxZQUFZO0FBQUEsTUFDcEM7QUFDQXRFLGlCQUFXLENBQUEwRCxTQUFRLENBQUM2TCxRQUFRLEdBQUc3TCxJQUFJLENBQUM7QUFBQSxJQUN0QyxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFFQSxRQUFNdU0scUJBQXFCLE9BQU8zTSxJQUFZZ00sZUFBb0I7QUFDaEUsUUFBSTtBQUNGLFlBQU1wTyxXQUFXLE1BQU1GLE1BQU0xRixPQUFPLGdCQUFnQmdJLEVBQUUsRUFBRSxHQUFHO0FBQUEsUUFDekRHLFFBQVE7QUFBQSxRQUNSN0MsU0FBUyxFQUFFLGdCQUFnQixvQkFBb0JDLGVBQWUsVUFBVXBGLGFBQWEwRSxTQUFTLEVBQUUsR0FBRztBQUFBLFFBQ25Hb0YsTUFBTXpKLEtBQUtvSCxVQUFVb00sVUFBVTtBQUFBLE1BQ2pDLENBQUM7QUFDRCxZQUFNMU0sT0FBTyxNQUFNMUIsU0FBU0ksS0FBSztBQUNqQyxVQUFJc0IsTUFBTWdELFdBQVdoRCxLQUFLQSxNQUFNO0FBQzlCNUMsbUJBQVcsQ0FBQTBELFNBQVFBLEtBQUtDLElBQUksQ0FBQXVNLE1BQUtBLEVBQUU1TSxPQUFPQSxLQUFLLEVBQUUsR0FBRzRNLEdBQUcsR0FBR3ROLEtBQUtBLEtBQUssSUFBSXNOLENBQUMsQ0FBQztBQUFBLE1BQzVFO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFFQSxRQUFNQyxxQkFBcUIsT0FBTzdNLE9BQWU7QUFDL0MsUUFBSTtBQUNGLFlBQU10QyxNQUFNMUYsT0FBTyxnQkFBZ0JnSSxFQUFFLEVBQUUsR0FBRztBQUFBLFFBQ3hDRyxRQUFRO0FBQUEsUUFDUjdDLFNBQVMsRUFBRUMsZUFBZSxVQUFVcEYsYUFBYTBFLFNBQVMsRUFBRSxHQUFHO0FBQUEsTUFDakUsQ0FBQztBQUNESCxpQkFBVyxDQUFBMEQsU0FBUUEsS0FBSzBDLE9BQU8sQ0FBQThKLE1BQUtBLEVBQUU1TSxPQUFPQSxFQUFFLENBQUM7QUFBQSxJQUNsRCxRQUFRO0FBQUEsSUFBRTtBQUFBLEVBQ1o7QUFFQSxRQUFNOE0sNkJBQTZCLE9BQU9DLFVBQWtCQyxTQUFlO0FBQ3pFLFFBQUk7QUFDRixZQUFNQyxXQUFXLElBQUlDLFNBQVM7QUFDOUJELGVBQVNFLE9BQU8sUUFBUUgsSUFBSTtBQUM1QixZQUFNcFAsV0FBVyxNQUFNRixNQUFNMUYsT0FBTyxnQkFBZ0IrVSxRQUFRLFlBQVksR0FBRztBQUFBLFFBQ3pFNU0sUUFBUTtBQUFBLFFBQ1I3QyxTQUFTLEVBQUVDLGVBQWUsVUFBVXBGLGFBQWEwRSxTQUFTLEVBQUUsR0FBRztBQUFBLFFBQy9Eb0YsTUFBTWdMO0FBQUFBLE1BQ1IsQ0FBQztBQUNELFlBQU0zTixPQUFPLE1BQU0xQixTQUFTSSxLQUFLO0FBQ2pDLFVBQUlzQixNQUFNZ0QsV0FBV2hELEtBQUs4TixVQUFVO0FBQ2xDMVEsbUJBQVcsQ0FBQTBELFNBQVFBLEtBQUtDLElBQUksQ0FBQXVNLE1BQUs7QUFDL0IsY0FBSUEsRUFBRTVNLE9BQU8rTSxVQUFVO0FBQ3JCLGtCQUFNUixZQUFZSyxFQUFFTCxZQUFZLENBQUMsR0FBR0ssRUFBRUwsV0FBV2pOLEtBQUs4TixRQUFRLElBQUksQ0FBQzlOLEtBQUs4TixRQUFRO0FBQ2hGLG1CQUFPLEVBQUUsR0FBR1IsR0FBR0wsVUFBVTtBQUFBLFVBQzNCO0FBQ0EsaUJBQU9LO0FBQUFBLFFBQ1QsQ0FBQyxDQUFDO0FBQUEsTUFDSjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBQUU7QUFBQSxFQUNaO0FBRUEsUUFBTVMsK0JBQStCQSxDQUFDTixVQUFrQk8sZUFBdUI7QUFDN0UsVUFBTUMsY0FBY3ZWLE9BQU8sZ0JBQWdCK1UsUUFBUSxjQUFjTyxVQUFVLFdBQVc7QUFDdEZ0SixXQUFPd0osS0FBS0QsYUFBYSxRQUFRO0FBQUEsRUFDbkM7QUFHQSxNQUFJLENBQUNwVixhQUFhO0FBQ2hCLFdBQU8sdUJBQUMsYUFBVSxnQkFBZ0J1SCxzQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUFBLEVBQ3ZEO0FBR0EsUUFBTStOLG1CQUFtQjVVLHlCQUF5QixVQUFVLFVBQVVBLHlCQUF5QixhQUFhLGFBQWE7QUFFekgsUUFBTTZVLG9CQUFvQmhWLG9CQUFvQixnQkFDMUNtQyxhQUNBQSxXQUFXaUksT0FBTyxDQUFDd0MsT0FBT0EsRUFBRTdDLFdBQVcsSUFBSStCLFlBQVksTUFBTWlKLGlCQUFpQmpKLFlBQVksQ0FBQztBQUUvRixRQUFNbUosc0JBQXNCLElBQUlDLElBQUlGLGtCQUFrQnJOLElBQUksQ0FBQ2lGLE1BQU1BLEVBQUV0RixFQUFFLENBQUM7QUFFdEUsUUFBTTZOLGtCQUFrQm5WLG9CQUFvQixnQkFDeENxQyxXQUNBQSxTQUFTK0gsT0FBTyxDQUFDdkMsTUFBTW9OLG9CQUFvQkcsSUFBSXZOLEVBQUV1RCxXQUFXLENBQUM7QUFFakUsUUFBTWlLLG9CQUFvQnJWLG9CQUFvQixnQkFDMUN1QyxhQUNBQSxXQUFXNkgsT0FBTyxDQUFDcUQsTUFBTSxDQUFDQSxFQUFFckMsZUFBZTZKLG9CQUFvQkcsSUFBSTNILEVBQUVyQyxXQUFXLEtBQUtxQyxFQUFFcE4sY0FBY0Ysb0JBQW9CO0FBRTdILFFBQU1tVixrQkFBa0J0VixvQkFBb0IsZ0JBQ3hDeUMsV0FDQUEsU0FBUzJILE9BQU8sQ0FBQ3ZDLE1BQU1vTixvQkFBb0JHLElBQUl2TixFQUFFdUQsV0FBVyxLQUFLdkQsRUFBRXhILGNBQWNGLG9CQUFvQjtBQUV6RyxRQUFNb1Ysb0JBQW9CdlYsb0JBQW9CLGdCQUMxQzJDLHFCQUNBQSxtQkFBbUJ5SCxPQUFPLENBQUN4QyxNQUFNcU4sb0JBQW9CRyxJQUFJeE4sRUFBRXdELFdBQVcsS0FBS3hELEVBQUV2SCxjQUFjRixvQkFBb0I7QUFFbkgsUUFBTXFWLGlCQUFpQnhWLG9CQUFvQixnQkFDdkM2QyxpQkFDQUEsZUFBZXVILE9BQU8sQ0FBQ3FMLE1BQU0sQ0FBQ0EsRUFBRXJLLGVBQWU2SixvQkFBb0JHLElBQUlLLEVBQUVySyxXQUFXLEtBQUtxSyxFQUFFcFYsY0FBY0Ysb0JBQW9CO0FBRWpJLFFBQU11Vix1QkFBdUIxVixvQkFBb0IsZ0JBQzdDK0MsZ0JBQ0FBLGNBQWNxSCxPQUFPLENBQUNyQyxPQUFPLENBQUNBLEdBQUcxSCxhQUFhMEgsR0FBRzFILGNBQWNGLG9CQUFvQjtBQUV2RixRQUFNd1YscUJBQXFCM1Ysb0JBQW9CLGdCQUMzQ2lELGNBQ0FBLFlBQVltSCxPQUFPLENBQUN0QyxPQUFPLENBQUNBLEdBQUd6SCxhQUFheUgsR0FBR3pILGNBQWNGLHdCQUF5QjJILEdBQUdzRCxlQUFlNkosb0JBQW9CRyxJQUFJdE4sR0FBR3NELFdBQVcsQ0FBRTtBQUVwSixRQUFNd0ssbUJBQW1CNVYsb0JBQW9CLGdCQUN6QytCLFlBQ0FBLFVBQVVxSSxPQUFPLENBQUN4QyxNQUFNQSxFQUFFdkgsY0FBY0Ysb0JBQW9CO0FBRWhFLFFBQU0wVixtQkFBbUI3VixvQkFBb0IsZ0JBQ3pDaUMsWUFDQUEsVUFBVW1JLE9BQU8sQ0FBQzBMLE9BQU9BLEdBQUd6VixjQUFjRixvQkFBb0I7QUFFbEUsUUFBTTRWLDRCQUE0Qi9WLG9CQUFvQixnQkFDbER1RCxxQkFDQUEsbUJBQW1CNkcsT0FBTyxDQUFBb0ksTUFBS0EsRUFBRW5TLGNBQWNGLG9CQUFvQjtBQUV2RSxRQUFNNlYsd0JBQXdCaFcsb0JBQW9CLGdCQUM5Q3lELGlCQUNBQSxlQUFlMkcsT0FBTyxDQUFBb0ksTUFBS0EsRUFBRW5TLGNBQWNGLG9CQUFvQjtBQUVuRSxRQUFNOFYsNEJBQTRCalcsb0JBQW9CLGdCQUNsRDJELHFCQUNBQSxtQkFBbUJ5RyxPQUFPLENBQUF2QyxNQUFLQSxFQUFFeEgsY0FBY0Ysb0JBQW9CO0FBRXZFLFFBQU0rVixtQkFBbUJsQixrQkFBa0J0RyxLQUFLLENBQUM5QixNQUFNQSxFQUFFdEYsT0FBTzdHLG1CQUFtQixLQUFLdVUsa0JBQWtCLENBQUMsS0FBSzdTLFdBQVcsQ0FBQztBQUM1SCxRQUFNZ1Usd0JBQXdCUCxpQkFBaUJ4TCxPQUFPLENBQUN4QyxNQUFNQSxFQUFFekMsV0FBVyxTQUFTLEVBQUVtSDtBQUNyRixRQUFNOEosZUFBZS9TLGNBQWMrRyxPQUFPLENBQUMwSCxNQUFNLENBQUNBLEVBQUUzSSxNQUFNLEVBQUVtRDtBQUU1RCxRQUFNK0osb0JBQW9CMVUsU0FBUytNLEtBQUssQ0FBQ3JFLE1BQU1BLEVBQUUvQyxPQUFPbkgsb0JBQW9CLEtBQUt3QixTQUFTLENBQUM7QUFDM0YsUUFBTTJVLG9CQUFvQnRXLG9CQUFvQixnQkFBZ0IsOEJBQStCcVcsbUJBQW1CeEssUUFBUTtBQUV4SCxTQUNFLHVCQUFDLFNBQUksV0FBVSw0RkFFYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsYUFBYSxDQUFDWixRQUFRO0FBQ3BCLGNBQUlBLFFBQVEsYUFBY2xLLGtCQUFpQkYsTUFBUztBQUNwRCxjQUFJb0ssUUFBUSxXQUFZckssMEJBQXlCQyxNQUFTO0FBQzFETix3QkFBYzBLLEdBQWM7QUFDNUIxSiwrQkFBcUIsS0FBSztBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVXZCO0FBQUFBLFFBQ1YsYUFBYXNXO0FBQUFBLFFBQ2IsV0FBVzdXLFlBQVlvTTtBQUFBQSxRQUN2QixXQUFXcE0sWUFBWThXO0FBQUFBLFFBQ3ZCO0FBQUEsUUFDQSxhQUFhblY7QUFBQUEsUUFDYixrQkFBa0IsTUFBTUMsb0JBQW9CLENBQUNxRyxTQUFTLENBQUNBLElBQUk7QUFBQSxRQUMzRCxVQUFVUDtBQUFBQSxRQUNWLGNBQWM3RjtBQUFBQSxRQUNkLGVBQWUsTUFBTUMscUJBQXFCLEtBQUs7QUFBQTtBQUFBLE1BbEJqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFrQm1EO0FBQUEsSUFJbkQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsd0VBQ1RILG1CQUFtQixpQkFBaUIsZUFBZTtBQUFBLFFBSXJEO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVczQixZQUFZOFc7QUFBQUEsY0FDdkIsVUFBVTlXLFlBQVlvTTtBQUFBQSxjQUN0QixVQUFVN0w7QUFBQUEsY0FDVjtBQUFBLGNBQ0EsbUJBQW1CRztBQUFBQSxjQUNuQixpQkFBaUIsQ0FBQ3FXLFFBQVFwVyx3QkFBd0JvVyxHQUFHO0FBQUEsY0FDckQ7QUFBQSxjQUNBO0FBQUEsY0FDQSxZQUFZLENBQUN2TCxLQUFLQyxhQUFhO0FBQzdCRiwrQkFBZUMsS0FBS0MsUUFBUTtBQUM1QjNKLHFDQUFxQixLQUFLO0FBQUEsY0FDNUI7QUFBQSxjQUNBLFVBQVU0RjtBQUFBQSxjQUNWLGNBQWMsQ0FBQ2pILFNBQVNrSCxpQkFBaUJsSCxNQUFNQyxvQkFBb0I7QUFBQSxjQUNuRSxpQkFBaUIsTUFBTTtBQUNyQixvQkFBSW1MLE9BQU9tTCxhQUFhLE1BQU07QUFDNUJsVix1Q0FBcUIsQ0FBQ21HLFNBQVMsQ0FBQ0EsSUFBSTtBQUFBLGdCQUN0QyxPQUFPO0FBQ0xyRyxzQ0FBb0IsQ0FBQ3FHLFNBQVMsQ0FBQ0EsSUFBSTtBQUFBLGdCQUNyQztBQUFBLGNBQ0Y7QUFBQTtBQUFBLFlBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCSTtBQUFBLFVBR0osdUJBQUMsVUFBSyxXQUFVLDhDQUNkLGlDQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxpQkFFRXBIO0FBQUFBLDJCQUFlLGVBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxZQUFZMEs7QUFBQUEsZ0JBQ1osa0JBQWtCLE1BQU16SyxjQUFjLFVBQVU7QUFBQSxnQkFDaEQsa0JBQWtCLE1BQU07QUFDdEJBLGdDQUFjLFNBQVM7QUFDdkJZLHlDQUF1QixJQUFJO0FBQUEsZ0JBQzdCO0FBQUEsZ0JBQ0EscUJBQXFCLE1BQU07QUFDekJKLG1DQUFpQkYsTUFBUztBQUMxQk4sZ0NBQWMsWUFBWTtBQUFBLGdCQUM1QjtBQUFBLGdCQUNBLFlBQVl5VTtBQUFBQSxnQkFDWixlQUFlRyxnQkFBZ0I3STtBQUFBQSxnQkFDL0IsaUJBQWlCK0ksa0JBQWtCL0k7QUFBQUEsZ0JBQ25DLGVBQWVnSixnQkFBZ0JoSjtBQUFBQSxnQkFDL0I7QUFBQSxnQkFDQSxrQkFBa0JpSjtBQUFBQSxnQkFDbEIsVUFBVXZWO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsV0FBVzRWO0FBQUFBLGdCQUNYLGFBQWFVO0FBQUFBLGdCQUNiLGdCQUFnQmQ7QUFBQUEsZ0JBQ2hCLFVBQVVGO0FBQUFBLGdCQUNWLFVBQVVIO0FBQUFBLGdCQUNWLFlBQVlFO0FBQUFBO0FBQUFBLGNBeEJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXdCZ0M7QUFBQSxZQUlqQy9VLGVBQWUsb0JBQW9CTixvQkFBb0IsaUJBQ3REO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBV1AsWUFBWTBFO0FBQUFBLGdCQUN2QixjQUFjLE1BQU1GLGlCQUFpQixJQUFJNkMsZ0JBQWdCLEVBQUU1QyxNQUFNO0FBQUE7QUFBQSxjQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFcUU7QUFBQSxZQUl0RTVELGVBQWUsZUFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVdzVjtBQUFBQSxnQkFDWDtBQUFBLGdCQUNBLFVBQVU1VjtBQUFBQSxnQkFDVixXQUFXcUg7QUFBQUEsZ0JBQ1gscUJBQXFCZ0M7QUFBQUEsZ0JBQ3JCLFVBQVVJO0FBQUFBLGdCQUNWLFlBQVl1QjtBQUFBQTtBQUFBQSxjQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU82QjtBQUFBLFlBSTlCMUssZUFBZSxjQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxVQUFVTjtBQUFBQSxnQkFDVixZQUFZZ0w7QUFBQUEsZ0JBQ1osY0FBY3RCO0FBQUFBLGdCQUNkLGlCQUFpQlM7QUFBQUE7QUFBQUEsY0FMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VDO0FBQUEsWUFJeEM3SixlQUFlLGdCQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBV3VWO0FBQUFBLGdCQUNYLFVBQVU3VjtBQUFBQTtBQUFBQSxjQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUU0QjtBQUFBLFlBSTdCTSxlQUFlLFdBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsV0FBV2dLO0FBQUFBLGdCQUNYLGNBQWNJO0FBQUFBLGdCQUNkLGNBQWNFO0FBQUFBLGdCQUNkLGlCQUFpQkM7QUFBQUE7QUFBQUEsY0FObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXVDO0FBQUEsWUFJeEN2SyxlQUFlLGdCQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsWUFBWTBVO0FBQUFBLGdCQUNaLG1CQUFtQixDQUFDMU4sT0FBTztBQUN6QjVHLHlDQUF1QjRHLEVBQUU7QUFDekIvRyxnQ0FBYyxrQkFBa0I7QUFBQSxnQkFDbEM7QUFBQSxnQkFDQSxnQkFBZ0JtTDtBQUFBQSxnQkFDaEIsWUFBWVY7QUFBQUE7QUFBQUEsY0FQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPNkI7QUFBQSxZQUk5QjFLLGVBQWUsc0JBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXNFY7QUFBQUEsZ0JBQ1gsVUFBVWY7QUFBQUEsZ0JBQ1YsUUFBUSxNQUFNNVUsY0FBYyxZQUFZO0FBQUEsZ0JBQ3hDLFlBQVl5SztBQUFBQSxnQkFDWixjQUFjMEI7QUFBQUE7QUFBQUEsY0FMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS2lDO0FBQUEsWUFJbENwTSxlQUFlLGNBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxVQUFVNlU7QUFBQUEsZ0JBQ1YsWUFBWUg7QUFBQUEsZ0JBQ1osZ0JBQWdCclU7QUFBQUEsZ0JBQ2hCLGNBQWNvTTtBQUFBQSxnQkFDZCxzQkFBc0JXO0FBQUFBLGdCQUN0QixpQkFBaUJZO0FBQUFBLGdCQUNqQixpQkFBaUJFO0FBQUFBO0FBQUFBLGNBUG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU91QztBQUFBLFlBSXhDbE8sZUFBZSxnQkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFlBQVkrVTtBQUFBQSxnQkFDWixZQUFZTDtBQUFBQSxnQkFDWixnQkFBZ0JwRztBQUFBQSxnQkFDaEIsbUJBQW1CUTtBQUFBQSxnQkFDbkIsbUJBQW1CQztBQUFBQTtBQUFBQSxjQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLMkM7QUFBQSxZQUk1Qy9PLGVBQWUsY0FDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFVBQVVnVjtBQUFBQSxnQkFDVixZQUFZTjtBQUFBQSxnQkFDWixZQUFZSztBQUFBQSxnQkFDWixZQUFZcks7QUFBQUEsZ0JBQ1osY0FBY3NFO0FBQUFBLGdCQUNkLGlCQUFpQkU7QUFBQUEsZ0JBQ2pCLGlCQUFpQks7QUFBQUEsZ0JBQ2pCLG1CQUFtQjdQLG9CQUFvQjtBQUFBO0FBQUEsY0FSekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUXlEO0FBQUEsWUFJMURNLGVBQWUsZ0JBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxvQkFBb0JpVjtBQUFBQSxnQkFDcEIsVUFBVUo7QUFBQUEsZ0JBQ1YsWUFBWUg7QUFBQUEsZ0JBQ1osU0FBU2xVO0FBQUFBLGdCQUNULFlBQVlrSztBQUFBQSxnQkFDWixrQkFBa0I4RTtBQUFBQTtBQUFBQSxjQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNeUM7QUFBQSxZQUkxQ3hQLGVBQWUsaUJBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFhcVY7QUFBQUEsZ0JBQ2IsVUFBVUw7QUFBQUEsZ0JBQ1YsWUFBWU47QUFBQUEsZ0JBQ1osWUFBWUs7QUFBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxZQUFZcks7QUFBQUEsZ0JBQ1osaUJBQWlCeUc7QUFBQUEsZ0JBQ2pCLG9CQUFvQkU7QUFBQUEsZ0JBQ3BCLG9CQUFvQkM7QUFBQUE7QUFBQUEsY0FUdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzZDO0FBQUEsWUFJOUN0UixlQUFlLG9CQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsWUFBWTBVO0FBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBV3ZWLFlBQVkwRTtBQUFBQSxnQkFDdkIsVUFBVW5FO0FBQUFBLGdCQUNWLGdCQUFnQkcseUJBQXlCLFFBQVEsZUFBZUE7QUFBQUEsZ0JBQ2hFLFlBQVk2SztBQUFBQTtBQUFBQSxjQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU02QjtBQUFBLFlBSTlCMUssZUFBZSxhQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZ0JBQWdCa1Y7QUFBQUEsZ0JBQ2hCLFlBQVlSO0FBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsUUFBUVU7QUFBQUEsZ0JBQ1IsWUFBWTFLO0FBQUFBLGdCQUNaLG1CQUFtQnlGO0FBQUFBLGdCQUNuQixzQkFBc0JHO0FBQUFBLGdCQUN0QixzQkFBc0JFO0FBQUFBLGdCQUN0QixhQUFhQztBQUFBQSxnQkFDYixlQUFlRztBQUFBQSxnQkFDZixlQUFlQztBQUFBQSxnQkFDZixnQkFBZ0JqUTtBQUFBQSxnQkFDaEIsaUJBQWlCLE1BQU1DLHVCQUF1QixLQUFLO0FBQUE7QUFBQSxjQWJyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhdUQ7QUFBQSxZQUl4RGIsZUFBZSx1QkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNrVjtBQUFBQSxnQkFDVCxRQUFRRTtBQUFBQSxnQkFDUixlQUFlMVU7QUFBQUEsZ0JBQ2YsUUFBUSxNQUFNVCxjQUFjLFNBQVM7QUFBQSxnQkFDckMsWUFBWXlLO0FBQUFBLGdCQUNaLGFBQWErRjtBQUFBQSxnQkFDYixlQUFlRztBQUFBQSxnQkFDZixlQUFlQztBQUFBQSxnQkFDZixtQkFBbUJWO0FBQUFBLGdCQUNuQixzQkFBc0JHO0FBQUFBLGdCQUN0QixzQkFBc0JFO0FBQUFBO0FBQUFBLGNBWHhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdpRDtBQUFBLFlBSWxEeFEsZUFBZSxhQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsVUFBVWdWO0FBQUFBLGdCQUNWLGFBQWFLO0FBQUFBLGdCQUNiLFlBQVlYO0FBQUFBLGdCQUNaLFlBQVlLO0FBQUFBLGdCQUNaLFVBQVVGO0FBQUFBLGdCQUNWLFlBQVluSztBQUFBQTtBQUFBQSxjQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU02QjtBQUFBLFlBSTlCMUssZUFBZSxvQkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQVEsTUFBTUMsY0FBYyxTQUFTO0FBQUEsZ0JBQ3JDLFlBQVl5SztBQUFBQTtBQUFBQSxjQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUU2QjtBQUFBLFlBSTlCMUssZUFBZSxtQkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsWUFBWTBLO0FBQUFBLGdCQUNaLGNBQWM2RztBQUFBQSxnQkFDZCxpQkFBaUJFO0FBQUFBO0FBQUFBLGNBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1QztBQUFBLFlBSXhDelIsZUFBZSxjQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxpQkFBaUIsQ0FBQ2lPLFlBQVk7QUFDNUI3TyxpQ0FBZSxDQUFDZ0ksU0FBVUEsT0FBTyxFQUFFLEdBQUdBLE1BQU0sR0FBRzZHLFFBQVEsSUFBSTdHLElBQUs7QUFBQSxnQkFDbEU7QUFBQTtBQUFBLGNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUk7QUFBQSxZQUlMcEgsZUFBZSwwQkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLG9CQUFvQnlWO0FBQUFBLGdCQUNwQixVQUFVVDtBQUFBQSxnQkFDVjtBQUFBLGdCQUNBLGVBQWU3VixZQUFZNkgsTUFBTTtBQUFBLGdCQUNqQztBQUFBLGdCQUNBLGlCQUFpQjBLO0FBQUFBLGdCQUNqQixpQkFBaUJLO0FBQUFBO0FBQUFBLGNBUG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9pRDtBQUFBLFlBSWxEL1IsZUFBZSxxQkFDZDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGdCQUFnQjBWO0FBQUFBLGdCQUNoQixVQUFVVjtBQUFBQSxnQkFDVjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxjQUFjNUM7QUFBQUEsZ0JBQ2QsZ0JBQWdCRztBQUFBQTtBQUFBQSxjQVBsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPNEM7QUFBQSxZQUk3Q3ZTLGVBQWUseUJBQ2Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxvQkFBb0IyVjtBQUFBQSxnQkFDcEIsVUFBVVg7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLGVBQWU3VixZQUFZNkgsTUFBTTtBQUFBLGdCQUNqQztBQUFBLGdCQUNBLGlCQUFpQnlMO0FBQUFBLGdCQUNqQixvQkFBb0JHO0FBQUFBLGdCQUNwQixZQUFZRTtBQUFBQSxnQkFDWixpQkFBaUIsQ0FBQ25JLFFBQVExSyxjQUFjMEssR0FBYztBQUFBO0FBQUEsY0FWeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVTBEO0FBQUEsWUFHM0QzSyxlQUFlLG9CQUNkO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLGdCQUFnQitTO0FBQUFBLGdCQUNoQixnQkFBZ0JZO0FBQUFBLGdCQUNoQixnQkFBZ0JFO0FBQUFBLGdCQUNoQixrQkFBa0JDO0FBQUFBLGdCQUNsQixvQkFBb0JPO0FBQUFBO0FBQUFBLGNBUHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9tRDtBQUFBLGVBL1JuQyxHQUFHclUsVUFBVSxJQUFJTixlQUFlLElBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa1NBLEtBblNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb1NBLEtBclNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc1NBO0FBQUE7QUFBQTtBQUFBLE1BcFVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFVQTtBQUFBLE9BN1ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4VkE7QUFFSjtBQUFDUixHQWw3Q3VCRCxLQUFHO0FBQUEsS0FBSEE7QUFBRyxJQUFBbVg7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDYWxsYmFjayIsIk5hdmlnYXRpb24iLCJMb2dpblBhZ2UiLCJEYXNoYm9hcmRWaWV3IiwiQXBwcm92YWxDZW50ZXJWaWV3IiwiQ2x1c3RlcnNWaWV3IiwiQXVkaXRMb2dWaWV3IiwiVXNlck1hbmFnZW1lbnRWaWV3IiwiUGFuY2hheWF0c1ZpZXciLCJQYW5jaGF5YXREZXRhaWxWaWV3IiwiU3R1ZGVudHNWaWV3IiwiVm9sdW50ZWVyc1ZpZXciLCJTZXNzaW9uc1ZpZXciLCJBdHRlbmRhbmNlVmlldyIsIkxlc3NvblBsYW5WaWV3IiwiU2Vzc2lvblBob3Rvc1ZpZXciLCJGaW5hbmNlVmlldyIsIkZpbmFuY2VTdGF0ZW1lbnRWaWV3IiwiUmVwb3J0c1ZpZXciLCJSZXBvcnRQcmV2aWV3VmlldyIsIk5vdGlmaWNhdGlvbnNWaWV3IiwiU2V0dGluZ3NWaWV3IiwiTW9kdWxlTGlicmFyeVZpZXciLCJBY2FkZW1pY1NldHVwVmlldyIsIkhlYWRlciIsIkVycm9yQm91bmRhcnkiLCJEYXRlQ2hhbmdlUmVxdWVzdFZpZXciLCJTZXNzaW9uUmVwb3J0VmlldyIsIlNlc3Npb25TdWJtaXNzaW9uVmlldyIsImFwaVVybCIsIkFwcCIsIl9zIiwiY3VycmVudFVzZXIiLCJzZXRDdXJyZW50VXNlciIsInNhdmVkIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsImN1cnJlbnRVc2VyUm9sZSIsInNldEN1cnJlbnRVc2VyUm9sZSIsInJvbGUiLCJjdXJyZW50VXNlckNsdXN0ZXJJZCIsInNldEN1cnJlbnRVc2VyQ2x1c3RlcklkIiwiY2x1c3RlcklkIiwiY3VycmVudFRhYiIsInNldEN1cnJlbnRUYWIiLCJzYXZlZFRhYiIsInNlbGVjdGVkUGFuY2hheWF0SWQiLCJzZXRTZWxlY3RlZFBhbmNoYXlhdElkIiwiaW5pdGlhbFN0dWRlbnRGaWx0ZXJzIiwic2V0SW5pdGlhbFN0dWRlbnRGaWx0ZXJzIiwidW5kZWZpbmVkIiwiYWN0aXZlRHJhZnRJZCIsInNldEFjdGl2ZURyYWZ0SWQiLCJhY3RpdmVGaW5hbmNlRHJhZnRJZCIsInNldEFjdGl2ZUZpbmFuY2VEcmFmdElkIiwib3Blbk5ld0ZpbmFuY2VNb2RhbCIsInNldE9wZW5OZXdGaW5hbmNlTW9kYWwiLCJzaWRlYmFyQ29sbGFwc2VkIiwic2V0U2lkZWJhckNvbGxhcHNlZCIsIm1vYmlsZVNpZGViYXJPcGVuIiwic2V0TW9iaWxlU2lkZWJhck9wZW4iLCJzZWxlY3RlZExlc3NvblBsYW5JZCIsInNldFNlbGVjdGVkTGVzc29uUGxhbklkIiwic2V0SXRlbSIsImNsdXN0ZXJzIiwic2V0Q2x1c3RlcnMiLCJ1c2VycyIsInNldFVzZXJzIiwiYXBwcm92YWxzIiwic2V0QXBwcm92YWxzIiwiYXVkaXRMb2dzIiwic2V0QXVkaXRMb2dzIiwicGFuY2hheWF0cyIsInNldFBhbmNoYXlhdHMiLCJzdHVkZW50cyIsInNldFN0dWRlbnRzIiwidm9sdW50ZWVycyIsInNldFZvbHVudGVlcnMiLCJzZXNzaW9ucyIsInNldFNlc3Npb25zIiwiYXR0ZW5kYW5jZVNlc3Npb25zIiwic2V0QXR0ZW5kYW5jZVNlc3Npb25zIiwiZmluYW5jZUVudHJpZXMiLCJzZXRGaW5hbmNlRW50cmllcyIsImZpbmFuY2VEcmFmdHMiLCJzZXRGaW5hbmNlRHJhZnRzIiwibGVzc29uUGxhbnMiLCJzZXRMZXNzb25QbGFucyIsInBob3RvR3JvdXBzIiwic2V0UGhvdG9Hcm91cHMiLCJub3RpZmljYXRpb25zIiwic2V0Tm90aWZpY2F0aW9ucyIsImRhdGVDaGFuZ2VSZXF1ZXN0cyIsInNldERhdGVDaGFuZ2VSZXF1ZXN0cyIsInNlc3Npb25SZXBvcnRzIiwic2V0U2Vzc2lvblJlcG9ydHMiLCJzZXNzaW9uU3VibWlzc2lvbnMiLCJzZXRTZXNzaW9uU3VibWlzc2lvbnMiLCJhY2FkZW1pY1llYXJzIiwic2V0QWNhZGVtaWNZZWFycyIsIm1vZHVsZXMiLCJzZXRNb2R1bGVzIiwiZmV0Y2hCYWNrZW5kRGF0YSIsInNpZ25hbCIsInRva2VuIiwiUHJvbWlzZSIsInJlc29sdmUiLCJ0Iiwic2V0VGltZW91dCIsImFkZEV2ZW50TGlzdGVuZXIiLCJjbGVhclRpbWVvdXQiLCJvbmNlIiwiYWJvcnRlZCIsImhlYWRlcnMiLCJBdXRob3JpemF0aW9uIiwiZ2V0IiwidXJsIiwiZmV0Y2giLCJ0aGVuIiwicmVzcG9uc2UiLCJzdGF0dXMiLCJyZW1vdmVJdGVtIiwib2siLCJqc29uIiwiY2F0Y2giLCJwYW5jaGF5YXRzUmVzIiwic3R1ZGVudHNSZXMiLCJ2b2x1bnRlZXJzUmVzIiwic2Vzc2lvbnNSZXMiLCJhdHRlbmRhbmNlUmVzIiwiZmluYW5jZVJlcyIsImxlc3NvblBsYW5zUmVzIiwiYXBwcm92YWxzUmVzIiwiYXVkaXRSZXMiLCJub3RpZmljYXRpb25zUmVzIiwiY2x1c3RlcnNSZXMiLCJ1c2Vyc1JlcyIsImRhdGVDaGFuZ2VSZXF1ZXN0c1JlcyIsInNlc3Npb25SZXBvcnRzUmVzIiwic2Vzc2lvblN1Ym1pc3Npb25zUmVzIiwiYWNhZGVtaWNZZWFyc1JlcyIsIm1vZHVsZXNSZXMiLCJhbGwiLCJBcnJheSIsImlzQXJyYXkiLCJkYXRhIiwiY29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImFib3J0IiwiaGFuZGxlTG9naW5TdWNjZXNzIiwic2Vzc2lvbiIsInN0cmluZ2lmeSIsImhhbmRsZUxvZ291dCIsImhhbmRsZVJvbGVDaGFuZ2UiLCJoYW5kbGVBcHByb3ZlU3VibWlzc2lvbiIsImlkIiwibW9kdWxlIiwicmVjb3JkSWQiLCJtZXRob2QiLCJwcmV2IiwibWFwIiwiYSIsInMiLCJscCIsImZkIiwiZmUiLCJkcmFmdElkIiwibmV3TG9nIiwiRGF0ZSIsIm5vdyIsInRpbWVzdGFtcCIsInRvSVNPU3RyaW5nIiwicmVwbGFjZSIsInNsaWNlIiwidXNlcklkIiwidXNlck5hbWUiLCJ1c2VyUm9sZSIsImFjdGlvbiIsImNsdXN0ZXJOYW1lIiwiZGV0YWlscyIsIm5ld05vdGlmIiwidGl0bGUiLCJtZXNzYWdlIiwidGltZUFnbyIsImlzUmVhZCIsInR5cGUiLCJoYW5kbGVSZXF1ZXN0Q29ycmVjdGlvbiIsInJlYXNvbiIsImJvZHkiLCJjb3JyZWN0aW9uUmVhc29uIiwiaGFuZGxlUmVqZWN0U3VibWlzc2lvbiIsImhhbmRsZUFkZENsdXN0ZXIiLCJuZXdDIiwic3VjY2VzcyIsIkVycm9yIiwiZXJyb3IiLCJjbHVzdGVyIiwidXNlciIsInVzZXJzUmVzcG9uc2UiLCJ1c2Vyc0RhdGEiLCJoYW5kbGVEZWxldGVDbHVzdGVyIiwiZmlsdGVyIiwiYyIsImhhbmRsZUFkZFVzZXIiLCJuZXdVIiwiY1JlcyIsImNEYXRhIiwiaGFuZGxlVXBkYXRlVXNlciIsIml0ZW0iLCJoYW5kbGVEZWxldGVVc2VyIiwiaGFuZGxlUmVzZXRQYXNzd29yZCIsInBhc3N3b3JkIiwibXVzdENoYW5nZVBhc3N3b3JkIiwiaGFuZGxlTmF2aWdhdGUiLCJ0YWIiLCJ0YXJnZXRJZCIsInNlY29uZGFyeVBhcmFtIiwicGFuY2hheWF0SWQiLCJ2aWxsYWdlSWQiLCJ3aW5kb3ciLCJzY3JvbGxUbyIsInRvcCIsImJlaGF2aW9yIiwiaGFuZGxlQWRkUGFuY2hheWF0IiwibmV3UGFuY2hheWF0IiwibmV3SWQiLCJuYW1lIiwidG9Mb3dlckNhc2UiLCJ2aWxsYWdlc0xpc3QiLCJpbml0aWFsVmlsbGFnZXMiLCJ2TmFtZSIsImlkeCIsInN0dWRlbnRDb3VudCIsImNyZWF0ZWQiLCJ2aWxsYWdlc0NvdW50IiwibGVuZ3RoIiwiYWN0aXZlU3R1ZGVudHMiLCJ2b2x1bnRlZXJzQ291bnQiLCJ2aWxsYWdlcyIsImhhbmRsZUFkZFZpbGxhZ2UiLCJ2aWxsYWdlTmFtZSIsInAiLCJuZXdWaWxsYWdlIiwidXBkYXRlZFZpbGxhZ2VzIiwiaGFuZGxlQWRkU3R1ZGVudCIsIm5ld1N0dWRlbnQiLCJjb2RlIiwiU3RyaW5nIiwicGFkU3RhcnQiLCJhdmF0YXJMZXR0ZXIiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsImNvbG9ycyIsImF2YXRhckJnIiwidiIsImhhbmRsZUJ1bGtBZGRTdHVkZW50cyIsIm5ld1N0dWRlbnRzTGlzdCIsImN1cnJlbnRUb3RhbCIsImNyZWF0ZWRCYXRjaCIsInN0IiwiY29kZU51bWJlciIsIk1hdGgiLCJyYW5kb20iLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsIm1hdGNoaW5nQWRkZWQiLCJ2aWxsYWdlQWRkZWQiLCJoYW5kbGVVcGRhdGVTdHVkZW50IiwidXBkYXRlZCIsImhhbmRsZURlbGV0ZVN0dWRlbnQiLCJ0b0RlbGV0ZSIsImZpbmQiLCJtYXgiLCJoYW5kbGVBZGRWb2x1bnRlZXIiLCJuZXdWb2wiLCJuYW1lcyIsInNwbGl0IiwiYXZhdGFyVGV4dCIsInRvdGFsU2Vzc2lvbnMiLCJhdHRlbmRhbmNlUmF0ZSIsInJlY2VudFNlc3Npb25zIiwiaGFuZGxlVXBkYXRlVm9sdW50ZWVyIiwiaGFuZGxlRGVsZXRlVm9sdW50ZWVyIiwiaGFuZGxlQWRkU2Vzc2lvbiIsIm5ld1Nlc3Npb24iLCJoYW5kbGVVcGRhdGVTZXNzaW9uIiwiZXhpc3RpbmciLCJhY2FkZW1pY1llYXIiLCJkYXlOdW1iZXIiLCJzZXNzaW9uTmFtZSIsImhhbmRsZURlbGV0ZVNlc3Npb24iLCJoYW5kbGVTYXZlQXR0ZW5kYW5jZSIsImZpbmRJbmRleCIsImNvcHkiLCJuZXdBcHByIiwicmVjb3JkVGl0bGUiLCJwYW5jaGF5YXROYW1lIiwic3VibWl0dGVkQnkiLCJzdWJtaXR0ZWRBdCIsInByZXNlbnRDb3VudCIsInJlY29yZHMiLCJ0b3RhbENvdW50IiwiaGFuZGxlQWRkRmluYW5jZUVudHJ5IiwiZW50cnkiLCJmbG9vciIsImhhbmRsZVVwZGF0ZUZpbmFuY2VFbnRyeSIsImUiLCJoYW5kbGVEZWxldGVGaW5hbmNlRW50cnkiLCJoYW5kbGVTYXZlRmluYW5jZURyYWZ0IiwiZHJhZnQiLCJkIiwiaGFuZGxlRGVsZXRlRmluYW5jZURyYWZ0IiwiaGFuZGxlU3VibWl0RmluYW5jZURyYWZ0IiwidGFyZ2V0RHJhZnQiLCJ0b3RhbEFtb3VudCIsIml0ZW1Db3VudCIsInJvdXRlcyIsInNwb2NOYW1lIiwiaGFuZGxlQWRkTGVzc29uUGxhbiIsInBsYW4iLCJoYW5kbGVVcGRhdGVMZXNzb25QbGFuIiwiaGFuZGxlRGVsZXRlTGVzc29uUGxhbiIsImhhbmRsZU1hcmtBc1JlYWQiLCJuIiwiaGFuZGxlTWFya0FsbEFzUmVhZCIsImhhbmRsZVN1Ym1pdERhdGVDaGFuZ2VSZXF1ZXN0Iiwic2Vzc2lvbklkIiwib3JpZ2luYWxEYXRlIiwicmVxdWVzdGVkRGF0ZSIsImRhdGVDaGFuZ2VSZXF1ZXN0IiwiaGFuZGxlUmV2aWV3RGF0ZUNoYW5nZVJlcXVlc3QiLCJyZXF1ZXN0SWQiLCJyZW1hcmtzIiwiciIsInJldmlld1JlbWFya3MiLCJoYW5kbGVTYXZlU2Vzc2lvblJlcG9ydCIsInJlcG9ydCIsInNlc3Npb25SZXBvcnQiLCJoYW5kbGVEZWxldGVTZXNzaW9uUmVwb3J0IiwicmVwb3J0SWQiLCJoYW5kbGVTdWJtaXRTZXNzaW9uIiwic3VibWlzc2lvbiIsIm1pc3NpbmdJdGVtcyIsImhhbmRsZVJldmlld1N1Ym1pc3Npb24iLCJzdWJtaXNzaW9uSWQiLCJoYW5kbGVSZXN1Ym1pdFNlc3Npb24iLCJoYW5kbGVDcmVhdGVNb2R1bGUiLCJtb2R1bGVEYXRhIiwibmV3TW9kIiwibW9kdWxlTnVtYmVyIiwibW9kdWxlTmFtZSIsInRvcGljIiwiZGVzY3JpcHRpb24iLCJ2ZXJzaW9uIiwicmVzb3VyY2VzIiwiY3JlYXRlZEJ5IiwiY3JlYXRlZEF0IiwidXBkYXRlZEF0IiwiaGFuZGxlVXBkYXRlTW9kdWxlIiwibSIsImhhbmRsZURlbGV0ZU1vZHVsZSIsImhhbmRsZVVwbG9hZE1vZHVsZVJlc291cmNlIiwibW9kdWxlSWQiLCJmaWxlIiwiZm9ybURhdGEiLCJGb3JtRGF0YSIsImFwcGVuZCIsInJlc291cmNlIiwiaGFuZGxlRG93bmxvYWRNb2R1bGVSZXNvdXJjZSIsInJlc291cmNlSWQiLCJkb3dubG9hZFVybCIsIm9wZW4iLCJjbHVzdGVyRmlsdGVyS2V5IiwiZGlzcGxheVBhbmNoYXlhdHMiLCJkaXNwbGF5UGFuY2hheWF0SWRzIiwiU2V0IiwiZGlzcGxheVN0dWRlbnRzIiwiaGFzIiwiZGlzcGxheVZvbHVudGVlcnMiLCJkaXNwbGF5U2Vzc2lvbnMiLCJkaXNwbGF5QXR0ZW5kYW5jZSIsImRpc3BsYXlGaW5hbmNlIiwiZiIsImRpc3BsYXlGaW5hbmNlRHJhZnRzIiwiZGlzcGxheUxlc3NvblBsYW5zIiwiZGlzcGxheUFwcHJvdmFscyIsImRpc3BsYXlBdWRpdExvZ3MiLCJhbCIsImRpc3BsYXlEYXRlQ2hhbmdlUmVxdWVzdHMiLCJkaXNwbGF5U2Vzc2lvblJlcG9ydHMiLCJkaXNwbGF5U2Vzc2lvblN1Ym1pc3Npb25zIiwiY3VycmVudFBhbmNoYXlhdCIsInBlbmRpbmdBcHByb3ZhbHNDb3VudCIsInBlbmRpbmdDb3VudCIsImN1cnJlbnRDbHVzdGVyT2JqIiwiYWN0aXZlQ2x1c3Rlck5hbWUiLCJlbWFpbCIsImNpZCIsImlubmVyV2lkdGgiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHtcclxuICBUYWJUeXBlLFxyXG4gIFN0dWRlbnQsXHJcbiAgVm9sdW50ZWVyLFxyXG4gIFNlc3Npb24sXHJcbiAgQXR0ZW5kYW5jZVNlc3Npb24sXHJcbiAgRmluYW5jZUVudHJ5LFxyXG4gIEZpbmFuY2VEcmFmdCxcclxuICBMZXNzb25QbGFuLFxyXG4gIFNlc3Npb25QaG90b0dyb3VwLFxyXG4gIE5vdGlmaWNhdGlvbkl0ZW0sXHJcbiAgUGFuY2hheWF0LFxyXG4gIFVzZXJSb2xlLFxyXG4gIENsdXN0ZXIsXHJcbiAgQXBwcm92YWxJdGVtLFxyXG4gIEF1ZGl0TG9nRW50cnksXHJcbiAgVXNlcixcclxuICBEYXRlQ2hhbmdlUmVxdWVzdCxcclxuICBTZXNzaW9uUmVwb3J0LFxyXG4gIFNlc3Npb25TdWJtaXNzaW9uLFxyXG4gIEFjYWRlbWljWWVhcixcclxuICBUcWlNb2R1bGUsXHJcbn0gZnJvbSAnLi90eXBlcyc7XHJcbmltcG9ydCB7IE5hdmlnYXRpb24gfSBmcm9tICcuL2NvbXBvbmVudHMvTmF2aWdhdGlvbic7XHJcbmltcG9ydCB7IExvZ2luUGFnZSwgQXV0aFNlc3Npb24gfSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5QYWdlJztcclxuaW1wb3J0IHsgRGFzaGJvYXJkVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3JztcclxuaW1wb3J0IHsgQXBwcm92YWxDZW50ZXJWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL0FwcHJvdmFsQ2VudGVyVmlldyc7XHJcbmltcG9ydCB7IENsdXN0ZXJzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9DbHVzdGVyc1ZpZXcnO1xyXG5pbXBvcnQgeyBBdWRpdExvZ1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQXVkaXRMb2dWaWV3JztcclxuaW1wb3J0IHsgVXNlck1hbmFnZW1lbnRWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1VzZXJNYW5hZ2VtZW50Vmlldyc7XHJcbmltcG9ydCB7IFBhbmNoYXlhdHNWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1BhbmNoYXlhdHNWaWV3JztcclxuaW1wb3J0IHsgUGFuY2hheWF0RGV0YWlsVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9QYW5jaGF5YXREZXRhaWxWaWV3JztcclxuaW1wb3J0IHsgU3R1ZGVudHNWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1N0dWRlbnRzVmlldyc7XHJcbmltcG9ydCB7IFZvbHVudGVlcnNWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1ZvbHVudGVlcnNWaWV3JztcclxuaW1wb3J0IHsgU2Vzc2lvbnNWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1Nlc3Npb25zVmlldyc7XHJcbmltcG9ydCB7IEF0dGVuZGFuY2VWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL0F0dGVuZGFuY2VWaWV3JztcclxuaW1wb3J0IHsgTGVzc29uUGxhblZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvTGVzc29uUGxhblZpZXcnO1xyXG5pbXBvcnQgeyBTZXNzaW9uUGhvdG9zVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9TZXNzaW9uUGhvdG9zVmlldyc7XHJcbmltcG9ydCB7IEZpbmFuY2VWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL0ZpbmFuY2VWaWV3JztcclxuaW1wb3J0IHsgRmluYW5jZVN0YXRlbWVudFZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvRmluYW5jZVN0YXRlbWVudFZpZXcnO1xyXG5pbXBvcnQgeyBSZXBvcnRzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9SZXBvcnRzVmlldyc7XHJcbmltcG9ydCB7IFJlcG9ydFByZXZpZXdWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL1JlcG9ydFByZXZpZXdWaWV3JztcclxuaW1wb3J0IHsgTm90aWZpY2F0aW9uc1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uc1ZpZXcnO1xyXG5pbXBvcnQgeyBTZXR0aW5nc1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvU2V0dGluZ3NWaWV3JztcclxuaW1wb3J0IHsgTW9kdWxlTGlicmFyeVZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvTW9kdWxlTGlicmFyeVZpZXcnO1xyXG5pbXBvcnQgeyBBY2FkZW1pY1NldHVwVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9BY2FkZW1pY1NldHVwVmlldyc7XHJcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4vY29tcG9uZW50cy9IZWFkZXInO1xyXG5pbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAnLi9jb21wb25lbnRzL0Vycm9yQm91bmRhcnknO1xyXG5pbXBvcnQgRGF0ZUNoYW5nZVJlcXVlc3RWaWV3IGZyb20gJy4vY29tcG9uZW50cy9EYXRlQ2hhbmdlUmVxdWVzdFZpZXcnO1xyXG5pbXBvcnQgU2Vzc2lvblJlcG9ydFZpZXcgZnJvbSAnLi9jb21wb25lbnRzL1Nlc3Npb25SZXBvcnRWaWV3JztcclxuaW1wb3J0IFNlc3Npb25TdWJtaXNzaW9uVmlldyBmcm9tICcuL2NvbXBvbmVudHMvU2Vzc2lvblN1Ym1pc3Npb25WaWV3JztcclxuaW1wb3J0IHsgYXBpVXJsIH0gZnJvbSAnLi91dGlscy9hcGknO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcclxuICAvLyBTZXNzaW9uICYgQXV0aGVudGljYXRpb24gU3RhdGVcclxuICBjb25zdCBbY3VycmVudFVzZXIsIHNldEN1cnJlbnRVc2VyXSA9IHVzZVN0YXRlPEF1dGhTZXNzaW9uIHwgbnVsbD4oKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndHFpX2F1dGhfc2Vzc2lvbicpO1xyXG4gICAgICBpZiAoc2F2ZWQpIHtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShzYXZlZCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmUgaW52YWxpZCBzZXNzaW9uIGRhdGFcclxuICAgIH1cclxuICAgIHJldHVybiBudWxsO1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbY3VycmVudFVzZXJSb2xlLCBzZXRDdXJyZW50VXNlclJvbGVdID0gdXNlU3RhdGU8VXNlclJvbGU+KGN1cnJlbnRVc2VyPy5yb2xlIHx8ICdTdXBlciBBZG1pbicpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlckNsdXN0ZXJJZCwgc2V0Q3VycmVudFVzZXJDbHVzdGVySWRdID0gdXNlU3RhdGU8c3RyaW5nPihjdXJyZW50VXNlcj8uY2x1c3RlcklkIHx8ICdhbGwnKTtcclxuXHJcbiAgLy8gTmF2aWdhdGlvbiAmIFZpZXcgU3RhdGVcclxuICBjb25zdCBbY3VycmVudFRhYiwgc2V0Q3VycmVudFRhYl0gPSB1c2VTdGF0ZTxUYWJUeXBlPigoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBzYXZlZFRhYiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGB0cWlfY3VycmVudF90YWJfJHtjdXJyZW50VXNlcj8ucm9sZSB8fCAnU3VwZXIgQWRtaW4nfWApIGFzIFRhYlR5cGUgfCBudWxsO1xyXG4gICAgICByZXR1cm4gc2F2ZWRUYWIgPT09ICdhY2FkZW1pYy1zZXR1cCcgJiYgY3VycmVudFVzZXI/LnJvbGUgIT09ICdTdXBlciBBZG1pbicgPyAnZGFzaGJvYXJkJyA6IHNhdmVkVGFiIHx8ICdkYXNoYm9hcmQnO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHJldHVybiAnZGFzaGJvYXJkJztcclxuICAgIH1cclxuICB9KTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXRJZCwgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCd2ZWRha2thdHRhbWFkdXZ1Jyk7XHJcbiAgY29uc3QgW2luaXRpYWxTdHVkZW50RmlsdGVycywgc2V0SW5pdGlhbFN0dWRlbnRGaWx0ZXJzXSA9IHVzZVN0YXRlPHsgcGFuY2hheWF0SWQ/OiBzdHJpbmc7IHZpbGxhZ2VJZD86IHN0cmluZyB9IHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xyXG4gIGNvbnN0IFthY3RpdmVEcmFmdElkLCBzZXRBY3RpdmVEcmFmdElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcclxuICBjb25zdCBbYWN0aXZlRmluYW5jZURyYWZ0SWQsIHNldEFjdGl2ZUZpbmFuY2VEcmFmdElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcclxuICBjb25zdCBbb3Blbk5ld0ZpbmFuY2VNb2RhbCwgc2V0T3Blbk5ld0ZpbmFuY2VNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XHJcbiAgY29uc3QgW3NpZGViYXJDb2xsYXBzZWQsIHNldFNpZGViYXJDb2xsYXBzZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xyXG4gIGNvbnN0IFttb2JpbGVTaWRlYmFyT3Blbiwgc2V0TW9iaWxlU2lkZWJhck9wZW5dID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExlc3NvblBsYW5JZCwgc2V0U2VsZWN0ZWRMZXNzb25QbGFuSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYHRxaV9jdXJyZW50X3RhYl8ke2N1cnJlbnRVc2VyUm9sZX1gLCBjdXJyZW50VGFiKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmUgc3RvcmFnZSBmYWlsdXJlc1xyXG4gICAgfVxyXG4gIH0sIFtjdXJyZW50VGFiLCBjdXJyZW50VXNlclJvbGVdKTtcclxuXHJcbiAgLy8gQ29yZSBEYXRhIENvbGxlY3Rpb25zIChjbGVhbiBpbml0aWFsIHN0YXRlIGZyb20gREIpXHJcbiAgY29uc3QgW2NsdXN0ZXJzLCBzZXRDbHVzdGVyc10gPSB1c2VTdGF0ZTxDbHVzdGVyW10+KFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlPFVzZXJbXT4oW10pO1xyXG4gIGNvbnN0IFthcHByb3ZhbHMsIHNldEFwcHJvdmFsc10gPSB1c2VTdGF0ZTxBcHByb3ZhbEl0ZW1bXT4oW10pO1xyXG4gIGNvbnN0IFthdWRpdExvZ3MsIHNldEF1ZGl0TG9nc10gPSB1c2VTdGF0ZTxBdWRpdExvZ0VudHJ5W10+KFtdKTtcclxuICBjb25zdCBbcGFuY2hheWF0cywgc2V0UGFuY2hheWF0c10gPSB1c2VTdGF0ZTxQYW5jaGF5YXRbXT4oW10pO1xyXG4gIGNvbnN0IFtzdHVkZW50cywgc2V0U3R1ZGVudHNdID0gdXNlU3RhdGU8U3R1ZGVudFtdPihbXSk7XHJcbiAgY29uc3QgW3ZvbHVudGVlcnMsIHNldFZvbHVudGVlcnNdID0gdXNlU3RhdGU8Vm9sdW50ZWVyW10+KFtdKTtcclxuICBjb25zdCBbc2Vzc2lvbnMsIHNldFNlc3Npb25zXSA9IHVzZVN0YXRlPFNlc3Npb25bXT4oW10pO1xyXG4gIGNvbnN0IFthdHRlbmRhbmNlU2Vzc2lvbnMsIHNldEF0dGVuZGFuY2VTZXNzaW9uc10gPSB1c2VTdGF0ZTxBdHRlbmRhbmNlU2Vzc2lvbltdPihbXSk7XHJcbiAgY29uc3QgW2ZpbmFuY2VFbnRyaWVzLCBzZXRGaW5hbmNlRW50cmllc10gPSB1c2VTdGF0ZTxGaW5hbmNlRW50cnlbXT4oW10pO1xyXG4gIGNvbnN0IFtmaW5hbmNlRHJhZnRzLCBzZXRGaW5hbmNlRHJhZnRzXSA9IHVzZVN0YXRlPEZpbmFuY2VEcmFmdFtdPihbXSk7XHJcbiAgY29uc3QgW2xlc3NvblBsYW5zLCBzZXRMZXNzb25QbGFuc10gPSB1c2VTdGF0ZTxMZXNzb25QbGFuW10+KFtdKTtcclxuICBjb25zdCBbcGhvdG9Hcm91cHMsIHNldFBob3RvR3JvdXBzXSA9IHVzZVN0YXRlPFNlc3Npb25QaG90b0dyb3VwW10+KFtdKTtcclxuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZTxOb3RpZmljYXRpb25JdGVtW10+KFtdKTtcclxuICBjb25zdCBbZGF0ZUNoYW5nZVJlcXVlc3RzLCBzZXREYXRlQ2hhbmdlUmVxdWVzdHNdID0gdXNlU3RhdGU8RGF0ZUNoYW5nZVJlcXVlc3RbXT4oW10pO1xyXG4gIGNvbnN0IFtzZXNzaW9uUmVwb3J0cywgc2V0U2Vzc2lvblJlcG9ydHNdID0gdXNlU3RhdGU8U2Vzc2lvblJlcG9ydFtdPihbXSk7XHJcbiAgY29uc3QgW3Nlc3Npb25TdWJtaXNzaW9ucywgc2V0U2Vzc2lvblN1Ym1pc3Npb25zXSA9IHVzZVN0YXRlPFNlc3Npb25TdWJtaXNzaW9uW10+KFtdKTtcclxuICBjb25zdCBbYWNhZGVtaWNZZWFycywgc2V0QWNhZGVtaWNZZWFyc10gPSB1c2VTdGF0ZTxBY2FkZW1pY1llYXJbXT4oW10pO1xyXG4gIGNvbnN0IFttb2R1bGVzLCBzZXRNb2R1bGVzXSA9IHVzZVN0YXRlPFRxaU1vZHVsZVtdPihbXSk7XHJcblxyXG4gIC8vIFN5bmMgd2l0aCBBUEkgQmFja2VuZFxyXG4gIGNvbnN0IGZldGNoQmFja2VuZERhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoc2lnbmFsOiBBYm9ydFNpZ25hbCkgPT4ge1xyXG4gICAgaWYgKCFjdXJyZW50VXNlcj8udG9rZW4pIHJldHVybjtcclxuXHJcbiAgICAvLyAzMDAgbXMgZGVib3VuY2Ug4oCUIFJlYWN0IDE5IFN0cmljdCBNb2RlIHVubW91bnRzIGFuZCByZW1vdW50cyBpbW1lZGlhdGVseVxyXG4gICAgLy8gaW4gZGV2LiBUaGUgYWJvcnQgZnJvbSB0aGUgZmlyc3QgbW91bnQgY2FuY2VscyB0aGlzIHRpbWVyIGJlZm9yZSB0aGVcclxuICAgIC8vIHJlcXVlc3RzIGZpcmUsIHNvIG9ubHkgdGhlIHNlY29uZCAoc3Vydml2aW5nKSBtb3VudCBhY3R1YWxseSBmZXRjaGVzLlxyXG4gICAgYXdhaXQgbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUpID0+IHtcclxuICAgICAgY29uc3QgdCA9IHNldFRpbWVvdXQocmVzb2x2ZSwgMzAwKTtcclxuICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4gY2xlYXJUaW1lb3V0KHQpLCB7IG9uY2U6IHRydWUgfSk7XHJcbiAgICB9KTtcclxuICAgIGlmIChzaWduYWwuYWJvcnRlZCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGhlYWRlcnMgPSB7XHJcbiAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gLFxyXG4gICAgICAneC11c2VyLXJvbGUnOiBjdXJyZW50VXNlclJvbGUsXHJcbiAgICAgICd4LXVzZXItY2x1c3Rlci1pZCc6IGN1cnJlbnRVc2VyQ2x1c3RlcklkLFxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBnZXQgPSAodXJsOiBzdHJpbmcpID0+XHJcbiAgICAgIGZldGNoKGFwaVVybCh1cmwpLCB7IGhlYWRlcnMsIHNpZ25hbCB9KVxyXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxKSB7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0cWlfYXV0aF9zZXNzaW9uJyk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKG51bGwpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayA/IHJlc3BvbnNlLmpzb24oKSA6IG51bGw7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKCkgPT4gbnVsbCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgW1xyXG4gICAgICAgIHBhbmNoYXlhdHNSZXMsXHJcbiAgICAgICAgc3R1ZGVudHNSZXMsXHJcbiAgICAgICAgdm9sdW50ZWVyc1JlcyxcclxuICAgICAgICBzZXNzaW9uc1JlcyxcclxuICAgICAgICBhdHRlbmRhbmNlUmVzLFxyXG4gICAgICAgIGZpbmFuY2VSZXMsXHJcbiAgICAgICAgbGVzc29uUGxhbnNSZXMsXHJcbiAgICAgICAgYXBwcm92YWxzUmVzLFxyXG4gICAgICAgIGF1ZGl0UmVzLFxyXG4gICAgICAgIG5vdGlmaWNhdGlvbnNSZXMsXHJcbiAgICAgICAgY2x1c3RlcnNSZXMsXHJcbiAgICAgICAgdXNlcnNSZXMsXHJcbiAgICAgICAgZGF0ZUNoYW5nZVJlcXVlc3RzUmVzLFxyXG4gICAgICAgIHNlc3Npb25SZXBvcnRzUmVzLFxyXG4gICAgICAgIHNlc3Npb25TdWJtaXNzaW9uc1JlcyxcclxuICAgICAgICBhY2FkZW1pY1llYXJzUmVzLFxyXG4gICAgICAgIG1vZHVsZXNSZXMsXHJcbiAgICAgIF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgZ2V0KGAvYXBpL3BhbmNoYXlhdHM/Y2x1c3RlcklkPSR7Y3VycmVudFVzZXJDbHVzdGVySWR9YCksXHJcbiAgICAgICAgZ2V0KGAvYXBpL3N0dWRlbnRzP2NsdXN0ZXJJZD0ke2N1cnJlbnRVc2VyQ2x1c3RlcklkfWApLFxyXG4gICAgICAgIGdldChgL2FwaS92b2x1bnRlZXJzP2NsdXN0ZXJJZD0ke2N1cnJlbnRVc2VyQ2x1c3RlcklkfWApLFxyXG4gICAgICAgIGdldChgL2FwaS9zZXNzaW9ucz9jbHVzdGVySWQ9JHtjdXJyZW50VXNlckNsdXN0ZXJJZH1gKSxcclxuICAgICAgICBnZXQoYC9hcGkvYXR0ZW5kYW5jZT9jbHVzdGVySWQ9JHtjdXJyZW50VXNlckNsdXN0ZXJJZH1gKSxcclxuICAgICAgICBnZXQoYC9hcGkvZmluYW5jZT9jbHVzdGVySWQ9JHtjdXJyZW50VXNlckNsdXN0ZXJJZH1gKSxcclxuICAgICAgICBnZXQoYC9hcGkvbGVzc29uLXBsYW5zP2NsdXN0ZXJJZD0ke2N1cnJlbnRVc2VyQ2x1c3RlcklkfWApLFxyXG4gICAgICAgIGdldChgL2FwaS9hcHByb3ZhbHM/Y2x1c3RlcklkPSR7Y3VycmVudFVzZXJDbHVzdGVySWR9YCksXHJcbiAgICAgICAgZ2V0KGAvYXBpL2F1ZGl0LWxvZ3M/Y2x1c3RlcklkPSR7Y3VycmVudFVzZXJDbHVzdGVySWR9YCksXHJcbiAgICAgICAgZ2V0KCcvYXBpL25vdGlmaWNhdGlvbnMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvY2x1c3RlcnMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvdXNlcnMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvZGF0ZS1jaGFuZ2UtcmVxdWVzdHMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvc2Vzc2lvbi1yZXBvcnRzJyksXHJcbiAgICAgICAgZ2V0KCcvYXBpL3Nlc3Npb24tc3VibWlzc2lvbnMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvYWNhZGVtaWMteWVhcnMnKSxcclxuICAgICAgICBnZXQoJy9hcGkvbW9kdWxlcycpLFxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIGlmIChzaWduYWwuYWJvcnRlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkocGFuY2hheWF0c1Jlcz8ucGFuY2hheWF0cykpICAgICAgICAgc2V0UGFuY2hheWF0cyhwYW5jaGF5YXRzUmVzLnBhbmNoYXlhdHMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShzdHVkZW50c1Jlcz8uc3R1ZGVudHMpKSAgICAgICAgICAgICBzZXRTdHVkZW50cyhzdHVkZW50c1Jlcy5zdHVkZW50cyk7XHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZvbHVudGVlcnNSZXM/LnZvbHVudGVlcnMpKSAgICAgICAgIHNldFZvbHVudGVlcnModm9sdW50ZWVyc1Jlcy52b2x1bnRlZXJzKTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc2Vzc2lvbnNSZXM/LnNlc3Npb25zKSkgICAgICAgICAgICAgc2V0U2Vzc2lvbnMoc2Vzc2lvbnNSZXMuc2Vzc2lvbnMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShhdHRlbmRhbmNlUmVzPy5hdHRlbmRhbmNlU2Vzc2lvbnMpKSBzZXRBdHRlbmRhbmNlU2Vzc2lvbnMoYXR0ZW5kYW5jZVJlcy5hdHRlbmRhbmNlU2Vzc2lvbnMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShmaW5hbmNlUmVzPy5maW5hbmNlRW50cmllcykpICAgICAgICBzZXRGaW5hbmNlRW50cmllcyhmaW5hbmNlUmVzLmZpbmFuY2VFbnRyaWVzKTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkobGVzc29uUGxhbnNSZXM/Lmxlc3NvblBsYW5zKSkgICAgICAgc2V0TGVzc29uUGxhbnMobGVzc29uUGxhbnNSZXMubGVzc29uUGxhbnMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShhcHByb3ZhbHNSZXM/LmFwcHJvdmFscykpICAgICAgICAgICBzZXRBcHByb3ZhbHMoYXBwcm92YWxzUmVzLmFwcHJvdmFscyk7XHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGF1ZGl0UmVzPy5hdWRpdExvZ3MpKSAgICAgICAgICAgICAgIHNldEF1ZGl0TG9ncyhhdWRpdFJlcy5hdWRpdExvZ3MpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShub3RpZmljYXRpb25zUmVzPy5ub3RpZmljYXRpb25zKSkgICBzZXROb3RpZmljYXRpb25zKG5vdGlmaWNhdGlvbnNSZXMubm90aWZpY2F0aW9ucyk7XHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGNsdXN0ZXJzUmVzPy5jbHVzdGVycykpICAgICAgICAgICAgIHNldENsdXN0ZXJzKGNsdXN0ZXJzUmVzLmNsdXN0ZXJzKTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkodXNlcnNSZXM/LnVzZXJzKSkgICAgICAgICAgICAgICAgICAgc2V0VXNlcnModXNlcnNSZXMudXNlcnMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRlQ2hhbmdlUmVxdWVzdHNSZXM/LmRhdGVDaGFuZ2VSZXF1ZXN0cykpIHNldERhdGVDaGFuZ2VSZXF1ZXN0cyhkYXRlQ2hhbmdlUmVxdWVzdHNSZXMuZGF0ZUNoYW5nZVJlcXVlc3RzKTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc2Vzc2lvblJlcG9ydHNSZXM/LnNlc3Npb25SZXBvcnRzKSkgICAgICAgICBzZXRTZXNzaW9uUmVwb3J0cyhzZXNzaW9uUmVwb3J0c1Jlcy5zZXNzaW9uUmVwb3J0cyk7XHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHNlc3Npb25TdWJtaXNzaW9uc1Jlcz8uc2Vzc2lvblN1Ym1pc3Npb25zKSkgc2V0U2Vzc2lvblN1Ym1pc3Npb25zKHNlc3Npb25TdWJtaXNzaW9uc1Jlcy5zZXNzaW9uU3VibWlzc2lvbnMpO1xyXG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShhY2FkZW1pY1llYXJzUmVzPy5hY2FkZW1pY1llYXJzKSkgICAgICAgICAgIHNldEFjYWRlbWljWWVhcnMoYWNhZGVtaWNZZWFyc1Jlcy5hY2FkZW1pY1llYXJzKTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkobW9kdWxlc1Jlcz8ubW9kdWxlcykpICAgICAgICAgICAgICAgICAgICAgICBzZXRNb2R1bGVzKG1vZHVsZXNSZXMubW9kdWxlcyk7XHJcbiAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkobW9kdWxlc1Jlcz8uZGF0YSkpICAgICAgICAgICAgICAgICAgICAgc2V0TW9kdWxlcyhtb2R1bGVzUmVzLmRhdGEpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIE5ldHdvcmsgZXJyb3Igb3IgYWJvcnQg4oCUIGtlZXAgZXhpc3RpbmcgaW4tbWVtb3J5IHN0YXRlLlxyXG4gICAgfVxyXG4gIH0sIFtjdXJyZW50VXNlcj8udG9rZW4sIGN1cnJlbnRVc2VyUm9sZSwgY3VycmVudFVzZXJDbHVzdGVySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghY3VycmVudFVzZXI/LnRva2VuKSByZXR1cm47XHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgZmV0Y2hCYWNrZW5kRGF0YShjb250cm9sbGVyLnNpZ25hbCk7XHJcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpO1xyXG4gIH0sIFtmZXRjaEJhY2tlbmREYXRhLCBjdXJyZW50VXNlcj8udG9rZW5dKTtcclxuXHJcbiAgLy8gQXV0aCBIYW5kbGVyc1xyXG4gIGNvbnN0IGhhbmRsZUxvZ2luU3VjY2VzcyA9IChzZXNzaW9uOiBBdXRoU2Vzc2lvbikgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RxaV9hdXRoX3Nlc3Npb24nLCBKU09OLnN0cmluZ2lmeShzZXNzaW9uKSk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gaWdub3JlXHJcbiAgICB9XHJcbiAgICBzZXRDdXJyZW50VXNlcihzZXNzaW9uKTtcclxuICAgIHNldEN1cnJlbnRVc2VyUm9sZShzZXNzaW9uLnJvbGUpO1xyXG4gICAgc2V0Q3VycmVudFVzZXJDbHVzdGVySWQoc2Vzc2lvbi5jbHVzdGVySWQpO1xyXG4gICAgc2V0Q3VycmVudFRhYignZGFzaGJvYXJkJyk7XHJcbiAgICBpZiAoc2Vzc2lvbi5yb2xlID09PSAnU3VwZXIgQWRtaW4nKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkUGFuY2hheWF0SWQoJ3ZlZGFra2F0dGFtYWR1dnUnKTtcclxuICAgIH0gZWxzZSBpZiAoc2Vzc2lvbi5jbHVzdGVySWQgPT09ICdzYWxlbScpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZCgneWVyY2F1ZCcpO1xyXG4gICAgfSBlbHNlIGlmIChzZXNzaW9uLmNsdXN0ZXJJZCA9PT0gJ25hbWFra2FsJykge1xyXG4gICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdElkKCdrb2xsaS1oaWxscycpO1xyXG4gICAgfSBlbHNlIGlmIChzZXNzaW9uLmNsdXN0ZXJJZCA9PT0gJ2RoYXJtYXB1cmknKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkUGFuY2hheWF0SWQoJ3ZlZGFra2F0dGFtYWR1dnUnKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndHFpX2F1dGhfc2Vzc2lvbicpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIGlnbm9yZVxyXG4gICAgfVxyXG4gICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICBzZXRDdXJyZW50VGFiKCdkYXNoYm9hcmQnKTtcclxuICB9O1xyXG5cclxuICAvLyBSb2xlIHN3aXRjaGluZ1xyXG4gIGNvbnN0IGhhbmRsZVJvbGVDaGFuZ2UgPSAocm9sZTogVXNlclJvbGUsIGNsdXN0ZXJJZD86IHN0cmluZykgPT4ge1xyXG4gICAgc2V0Q3VycmVudFVzZXJSb2xlKHJvbGUpO1xyXG4gICAgaWYgKHJvbGUgPT09ICdDbHVzdGVyIEFkbWluJyAmJiBjbHVzdGVySWQpIHtcclxuICAgICAgc2V0Q3VycmVudFVzZXJDbHVzdGVySWQoY2x1c3RlcklkKTtcclxuICAgIH0gZWxzZSBpZiAocm9sZSA9PT0gJ1N1cGVyIEFkbWluJykge1xyXG4gICAgICBzZXRDdXJyZW50VXNlckNsdXN0ZXJJZCgnYWxsJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gU3VwZXIgQWRtaW4gQXBwcm92YWwgQWN0aW9uc1xyXG4gIGNvbnN0IGhhbmRsZUFwcHJvdmVTdWJtaXNzaW9uID0gYXN5bmMgKGlkOiBzdHJpbmcsIG1vZHVsZTogc3RyaW5nLCByZWNvcmRJZDogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvYXBwcm92YWxzLyR7aWR9L2FwcHJvdmVgKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICBBdXRob3JpemF0aW9uOiBjdXJyZW50VXNlcj8udG9rZW4gPyBgQmVhcmVyICR7Y3VycmVudFVzZXIudG9rZW59YCA6ICcnLFxyXG4gICAgICAgICAgJ3gtdXNlci1yb2xlJzogY3VycmVudFVzZXJSb2xlLFxyXG4gICAgICAgICAgJ3gtdXNlci1jbHVzdGVyLWlkJzogY3VycmVudFVzZXJDbHVzdGVySWQsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gaWdub3JlXHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXBwcm92YWxzKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgoYSkgPT4gKGEuaWQgPT09IGlkID8geyAuLi5hLCBzdGF0dXM6ICdBcHByb3ZlZCcgfSA6IGEpKVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAobW9kdWxlID09PSAnQXR0ZW5kYW5jZScpIHtcclxuICAgICAgc2V0QXR0ZW5kYW5jZVNlc3Npb25zKChwcmV2KSA9PlxyXG4gICAgICAgIHByZXYubWFwKChzKSA9PiAocy5pZCA9PT0gcmVjb3JkSWQgPyB7IC4uLnMsIHN0YXR1czogJ0FwcHJvdmVkJyB9IDogcykpXHJcbiAgICAgICk7XHJcbiAgICB9IGVsc2UgaWYgKG1vZHVsZSA9PT0gJ0xlc3NvbiBQbGFuJykge1xyXG4gICAgICBzZXRMZXNzb25QbGFucygocHJldikgPT5cclxuICAgICAgICBwcmV2Lm1hcCgobHApID0+IChscC5pZCA9PT0gcmVjb3JkSWQgPyB7IC4uLmxwLCBzdGF0dXM6ICdBcHByb3ZlZCcgfSA6IGxwKSlcclxuICAgICAgKTtcclxuICAgIH0gZWxzZSBpZiAobW9kdWxlID09PSAnRmluYW5jZScpIHtcclxuICAgICAgc2V0RmluYW5jZURyYWZ0cygocHJldikgPT5cclxuICAgICAgICBwcmV2Lm1hcCgoZmQpID0+IChmZC5pZCA9PT0gcmVjb3JkSWQgPyB7IC4uLmZkLCBzdGF0dXM6ICdBcHByb3ZlZCcgfSA6IGZkKSlcclxuICAgICAgKTtcclxuICAgICAgc2V0RmluYW5jZUVudHJpZXMoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKGZlKSA9PiAoZmUuaWQgPT09IHJlY29yZElkIHx8IGZlLmRyYWZ0SWQgPT09IHJlY29yZElkID8geyAuLi5mZSwgc3RhdHVzOiAnQXBwcm92ZWQnIH0gOiBmZSkpXHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbmV3TG9nOiBBdWRpdExvZ0VudHJ5ID0ge1xyXG4gICAgICBpZDogYGxvZy0ke0RhdGUubm93KCl9YCxcclxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkucmVwbGFjZSgnVCcsICcgJykuc2xpY2UoMCwgMTkpLFxyXG4gICAgICB1c2VySWQ6ICd1LXN1cGVyLWFkbWluLTEnLFxyXG4gICAgICB1c2VyTmFtZTogJ0RyLiBLLiBTZW50aGlsIE5hdGhhbicsXHJcbiAgICAgIHVzZXJSb2xlOiAnU3VwZXIgQWRtaW4nLFxyXG4gICAgICBhY3Rpb246IGBBcHByb3ZlZCAke21vZHVsZX1gLFxyXG4gICAgICBtb2R1bGUsXHJcbiAgICAgIHJlY29yZElkLFxyXG4gICAgICBjbHVzdGVySWQ6IGN1cnJlbnRVc2VyQ2x1c3RlcklkLFxyXG4gICAgICBjbHVzdGVyTmFtZTogJ0RoYXJtYXB1cmkgQ2x1c3RlcicsXHJcbiAgICAgIGRldGFpbHM6IGBBcHByb3ZlZCAke21vZHVsZX0gc3VibWlzc2lvbiAoJHtyZWNvcmRJZH0pYCxcclxuICAgIH07XHJcbiAgICBzZXRBdWRpdExvZ3MoKHByZXYpID0+IFtuZXdMb2csIC4uLnByZXZdKTtcclxuXHJcbiAgICBjb25zdCBuZXdOb3RpZjogTm90aWZpY2F0aW9uSXRlbSA9IHtcclxuICAgICAgaWQ6IGBub3RpZi0ke0RhdGUubm93KCl9YCxcclxuICAgICAgdGl0bGU6IGAke21vZHVsZX0gQXBwcm92ZWRgLFxyXG4gICAgICBtZXNzYWdlOiBgU3VwZXIgQWRtaW4gaGFzIGFwcHJvdmVkICR7bW9kdWxlfSAoJHtyZWNvcmRJZH0pLmAsXHJcbiAgICAgIHRpbWVBZ286ICdKdXN0IG5vdycsXHJcbiAgICAgIGlzUmVhZDogZmFsc2UsXHJcbiAgICAgIHR5cGU6ICdhcHByb3ZhbCcsXHJcbiAgICB9O1xyXG4gICAgc2V0Tm90aWZpY2F0aW9ucygocHJldikgPT4gW25ld05vdGlmLCAuLi5wcmV2XSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVxdWVzdENvcnJlY3Rpb24gPSBhc3luYyAoaWQ6IHN0cmluZywgbW9kdWxlOiBzdHJpbmcsIHJlY29yZElkOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvYXBwcm92YWxzLyR7aWR9L3JlcXVlc3QtY29ycmVjdGlvbmApLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIEF1dGhvcml6YXRpb246IGN1cnJlbnRVc2VyPy50b2tlbiA/IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gIDogJycsXHJcbiAgICAgICAgICAneC11c2VyLXJvbGUnOiBjdXJyZW50VXNlclJvbGUsXHJcbiAgICAgICAgICAneC11c2VyLWNsdXN0ZXItaWQnOiBjdXJyZW50VXNlckNsdXN0ZXJJZCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcmVhc29uIH0pLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH1cclxuXHJcbiAgICBzZXRBcHByb3ZhbHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYubWFwKChhKSA9PlxyXG4gICAgICAgIGEuaWQgPT09IGlkID8geyAuLi5hLCBzdGF0dXM6ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCcsIGNvcnJlY3Rpb25SZWFzb246IHJlYXNvbiB9IDogYVxyXG4gICAgICApXHJcbiAgICApO1xyXG5cclxuICAgIGlmIChtb2R1bGUgPT09ICdBdHRlbmRhbmNlJykge1xyXG4gICAgICBzZXRBdHRlbmRhbmNlU2Vzc2lvbnMoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKHMpID0+XHJcbiAgICAgICAgICBzLmlkID09PSByZWNvcmRJZFxyXG4gICAgICAgICAgICA/IHsgLi4ucywgc3RhdHVzOiAnQ29ycmVjdGlvbiBSZXF1ZXN0ZWQnLCBjb3JyZWN0aW9uUmVhc29uOiByZWFzb24gfVxyXG4gICAgICAgICAgICA6IHNcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcbiAgICB9IGVsc2UgaWYgKG1vZHVsZSA9PT0gJ0xlc3NvbiBQbGFuJykge1xyXG4gICAgICBzZXRMZXNzb25QbGFucygocHJldikgPT5cclxuICAgICAgICBwcmV2Lm1hcCgobHApID0+XHJcbiAgICAgICAgICBscC5pZCA9PT0gcmVjb3JkSWRcclxuICAgICAgICAgICAgPyB7IC4uLmxwLCBzdGF0dXM6ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCcsIGNvcnJlY3Rpb25SZWFzb246IHJlYXNvbiB9XHJcbiAgICAgICAgICAgIDogbHBcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcbiAgICB9IGVsc2UgaWYgKG1vZHVsZSA9PT0gJ0ZpbmFuY2UnKSB7XHJcbiAgICAgIHNldEZpbmFuY2VEcmFmdHMoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKGZkKSA9PlxyXG4gICAgICAgICAgZmQuaWQgPT09IHJlY29yZElkXHJcbiAgICAgICAgICAgID8geyAuLi5mZCwgc3RhdHVzOiAnQ29ycmVjdGlvbiBSZXF1ZXN0ZWQnLCBjb3JyZWN0aW9uUmVhc29uOiByZWFzb24gfVxyXG4gICAgICAgICAgICA6IGZkXHJcbiAgICAgICAgKVxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IG5ld0xvZzogQXVkaXRMb2dFbnRyeSA9IHtcclxuICAgICAgaWQ6IGBsb2ctJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnJlcGxhY2UoJ1QnLCAnICcpLnNsaWNlKDAsIDE5KSxcclxuICAgICAgdXNlcklkOiAndS1zdXBlci1hZG1pbi0xJyxcclxuICAgICAgdXNlck5hbWU6ICdEci4gSy4gU2VudGhpbCBOYXRoYW4nLFxyXG4gICAgICB1c2VyUm9sZTogJ1N1cGVyIEFkbWluJyxcclxuICAgICAgYWN0aW9uOiBgQ29ycmVjdGlvbiBSZXF1ZXN0ZWQgb24gJHttb2R1bGV9YCxcclxuICAgICAgbW9kdWxlLFxyXG4gICAgICByZWNvcmRJZCxcclxuICAgICAgY2x1c3RlcklkOiBjdXJyZW50VXNlckNsdXN0ZXJJZCxcclxuICAgICAgY2x1c3Rlck5hbWU6ICdEaGFybWFwdXJpIENsdXN0ZXInLFxyXG4gICAgICBkZXRhaWxzOiBgQ29ycmVjdGlvbiByZXF1ZXN0ZWQgZm9yICR7cmVjb3JkSWR9OiBcIiR7cmVhc29ufVwiYCxcclxuICAgIH07XHJcbiAgICBzZXRBdWRpdExvZ3MoKHByZXYpID0+IFtuZXdMb2csIC4uLnByZXZdKTtcclxuXHJcbiAgICBjb25zdCBuZXdOb3RpZjogTm90aWZpY2F0aW9uSXRlbSA9IHtcclxuICAgICAgaWQ6IGBub3RpZi0ke0RhdGUubm93KCl9YCxcclxuICAgICAgdGl0bGU6IGBDb3JyZWN0aW9uIFJlcXVlc3RlZDogJHttb2R1bGV9YCxcclxuICAgICAgbWVzc2FnZTogYFN1cGVyIEFkbWluIHJlcXVlc3RlZCBjaGFuZ2VzIG9uICR7cmVjb3JkSWR9OiBcIiR7cmVhc29ufVwiYCxcclxuICAgICAgdGltZUFnbzogJ0p1c3Qgbm93JyxcclxuICAgICAgaXNSZWFkOiBmYWxzZSxcclxuICAgICAgdHlwZTogJ2NvcnJlY3Rpb24nLFxyXG4gICAgfTtcclxuICAgIHNldE5vdGlmaWNhdGlvbnMoKHByZXYpID0+IFtuZXdOb3RpZiwgLi4ucHJldl0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlamVjdFN1Ym1pc3Npb24gPSBhc3luYyAoaWQ6IHN0cmluZywgbW9kdWxlOiBzdHJpbmcsIHJlY29yZElkOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvYXBwcm92YWxzLyR7aWR9L3JlamVjdGApLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIEF1dGhvcml6YXRpb246IGN1cnJlbnRVc2VyPy50b2tlbiA/IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gIDogJycsXHJcbiAgICAgICAgICAneC11c2VyLXJvbGUnOiBjdXJyZW50VXNlclJvbGUsXHJcbiAgICAgICAgICAneC11c2VyLWNsdXN0ZXItaWQnOiBjdXJyZW50VXNlckNsdXN0ZXJJZCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcmVhc29uIH0pLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH1cclxuXHJcbiAgICBzZXRBcHByb3ZhbHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYubWFwKChhKSA9PiAoYS5pZCA9PT0gaWQgPyB7IC4uLmEsIHN0YXR1czogJ1JlamVjdGVkJywgY29ycmVjdGlvblJlYXNvbjogcmVhc29uIH0gOiBhKSlcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgLy8gQWRkIENsdXN0ZXIgTXV0YXRpb25cclxuICBjb25zdCBoYW5kbGVBZGRDbHVzdGVyID0gYXN5bmMgKG5ld0M6IFBhcnRpYWw8Q2x1c3Rlcj4pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL2NsdXN0ZXJzJyksIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGN1cnJlbnRVc2VyPy50b2tlbiA/IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gIDogJycgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShuZXdDKSxcclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2sgfHwgIWRhdGE/LnN1Y2Nlc3MpIHRocm93IG5ldyBFcnJvcihkYXRhPy5lcnJvciB8fCAnVW5hYmxlIHRvIGNyZWF0ZSBjbHVzdGVyLicpO1xyXG4gICAgICBpZiAoZGF0YS5jbHVzdGVyKSBzZXRDbHVzdGVycygocHJldikgPT4gWy4uLnByZXYsIGRhdGEuY2x1c3Rlcl0pO1xyXG4gICAgICBpZiAoZGF0YS51c2VyKSBzZXRVc2VycygocHJldikgPT4gWy4uLnByZXYsIGRhdGEudXNlcl0pO1xyXG4gICAgICBlbHNlIHtcclxuICAgICAgICBjb25zdCB1c2Vyc1Jlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL3VzZXJzJyksIHsgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBjdXJyZW50VXNlcj8udG9rZW4gPyBgQmVhcmVyICR7Y3VycmVudFVzZXIudG9rZW59YCA6ICcnIH0gfSk7XHJcbiAgICAgICAgY29uc3QgdXNlcnNEYXRhID0gYXdhaXQgdXNlcnNSZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodXNlcnNEYXRhPy51c2VycykpIHNldFVzZXJzKHVzZXJzRGF0YS51c2Vycyk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XHJcbiAgICAgIHRocm93IGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIERlbGV0ZSBDbHVzdGVyIE11dGF0aW9uXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQ2x1c3RlciA9IGFzeW5jIChjbHVzdGVySWQ6IHN0cmluZykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZmV0Y2goYXBpVXJsKGAvYXBpL2NsdXN0ZXJzLyR7Y2x1c3RlcklkfWApLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGN1cnJlbnRVc2VyPy50b2tlbiA/IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gIDogJycgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldENsdXN0ZXJzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigoYykgPT4gYy5pZCAhPT0gY2x1c3RlcklkKSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XHJcbiAgICAgIHNldENsdXN0ZXJzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigoYykgPT4gYy5pZCAhPT0gY2x1c3RlcklkKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQWRkIFVzZXIgTXV0YXRpb25cclxuICBjb25zdCBoYW5kbGVBZGRVc2VyID0gYXN5bmMgKG5ld1U6IFBhcnRpYWw8VXNlcj4pID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL3VzZXJzJyksIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgQXV0aG9yaXphdGlvbjogY3VycmVudFVzZXI/LnRva2VuID8gYEJlYXJlciAke2N1cnJlbnRVc2VyLnRva2VufWAgOiAnJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG5ld1UpLFxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihkYXRhPy5lcnJvciB8fCAnVW5hYmxlIHRvIGNyZWF0ZSB1c2VyLicpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChkYXRhLnVzZXIpIHtcclxuICAgICAgICBzZXRVc2VycygocHJldikgPT4gWy4uLnByZXYsIGRhdGEudXNlcl0pO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgY1JlcyA9IGF3YWl0IGZldGNoKGFwaVVybCgnL2FwaS9jbHVzdGVycycpLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGN1cnJlbnRVc2VyPy50b2tlbiA/IGBCZWFyZXIgJHtjdXJyZW50VXNlci50b2tlbn1gIDogJycgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBjb25zdCBjRGF0YSA9IGF3YWl0IGNSZXMuanNvbigpO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGNEYXRhPy5jbHVzdGVycykpIHNldENsdXN0ZXJzKGNEYXRhLmNsdXN0ZXJzKTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgLy8gaWdub3JlXHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XHJcbiAgICAgIHRocm93IGVycm9yO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVVzZXIgPSBhc3luYyAoaWQ6IHN0cmluZywgdXNlcjogUGFydGlhbDxVc2VyPikgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvdXNlcnMvJHtpZH1gKSwgeyBtZXRob2Q6ICdQVVQnLCBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlcj8udG9rZW4gfHwgJyd9YCB9LCBib2R5OiBKU09OLnN0cmluZ2lmeSh1c2VyKSB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YS5zdWNjZXNzKSB7IHJldHVybiBmYWxzZTsgfVxyXG4gICAgICBzZXRVc2VycygocHJldikgPT4gcHJldi5tYXAoKGl0ZW0pID0+IGl0ZW0uaWQgPT09IGlkID8geyAuLi5pdGVtLCAuLi5kYXRhLnVzZXIgfSA6IGl0ZW0pKTtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvdXNlcnMvJHtpZH1gKSwgeyBtZXRob2Q6ICdERUxFVEUnLCBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlcj8udG9rZW4gfHwgJyd9YCB9IH0pO1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgIGlmICghcmVzcG9uc2Uub2sgfHwgIWRhdGEuc3VjY2VzcykgcmV0dXJuO1xyXG4gICAgc2V0VXNlcnMoKHByZXYpID0+IHByZXYuZmlsdGVyKChpdGVtKSA9PiBpdGVtLmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlc2V0UGFzc3dvcmQgPSBhc3luYyAoaWQ6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvdXNlcnMvJHtpZH0vcmVzZXQtcGFzc3dvcmRgKSwgeyBtZXRob2Q6ICdQT1NUJywgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSwgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBwYXNzd29yZCB9KSB9KTtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICBpZiAoIXJlc3BvbnNlLm9rIHx8ICFkYXRhLnN1Y2Nlc3MpIHJldHVybjtcclxuICAgIHNldFVzZXJzKChwcmV2KSA9PiBwcmV2Lm1hcCgoaXRlbSkgPT4gaXRlbS5pZCA9PT0gaWQgPyB7IC4uLml0ZW0sIG11c3RDaGFuZ2VQYXNzd29yZDogZmFsc2UgfSA6IGl0ZW0pKTtcclxuICB9O1xyXG5cclxuICAvLyBOYXZpZ2F0aW9uIGhhbmRsZXJzXHJcbiAgY29uc3QgaGFuZGxlTmF2aWdhdGUgPSAodGFiOiBUYWJUeXBlLCB0YXJnZXRJZD86IHN0cmluZywgc2Vjb25kYXJ5UGFyYW0/OiBzdHJpbmcpID0+IHtcclxuICAgIGlmICh0YWIgPT09ICdwYW5jaGF5YXQtZGV0YWlsJyAmJiB0YXJnZXRJZCkge1xyXG4gICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdElkKHRhcmdldElkKTtcclxuICAgIH1cclxuICAgIGlmICh0YWIgPT09ICdzdHVkZW50cycpIHtcclxuICAgICAgaWYgKHRhcmdldElkIHx8IHNlY29uZGFyeVBhcmFtKSB7XHJcbiAgICAgICAgc2V0SW5pdGlhbFN0dWRlbnRGaWx0ZXJzKHtcclxuICAgICAgICAgIHBhbmNoYXlhdElkOiB0YXJnZXRJZCxcclxuICAgICAgICAgIHZpbGxhZ2VJZDogc2Vjb25kYXJ5UGFyYW0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0YWIgPT09ICdhdHRlbmRhbmNlLWRyYWZ0JyB8fCB0YWIgPT09ICdhdHRlbmRhbmNlJykge1xyXG4gICAgICBpZiAodGFyZ2V0SWQpIHtcclxuICAgICAgICBzZXRBY3RpdmVEcmFmdElkKHRhcmdldElkKTtcclxuICAgICAgfVxyXG4gICAgICBzZXRDdXJyZW50VGFiKCdhdHRlbmRhbmNlJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGlmICh0YWIgPT09ICdsZXNzb24tcGxhbicpIHtcclxuICAgICAgaWYgKHRhcmdldElkKSB7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRMZXNzb25QbGFuSWQodGFyZ2V0SWQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFNlbGVjdGVkTGVzc29uUGxhbklkKHVuZGVmaW5lZCk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0Q3VycmVudFRhYignbGVzc29uLXBsYW4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKHRhYiA9PT0gJ2ZpbmFuY2Utc3RhdGVtZW50Jykge1xyXG4gICAgICBpZiAodGFyZ2V0SWQpIHtcclxuICAgICAgICBzZXRBY3RpdmVGaW5hbmNlRHJhZnRJZCh0YXJnZXRJZCk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0Q3VycmVudFRhYignZmluYW5jZS1zdGF0ZW1lbnQnKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0Q3VycmVudFRhYih0YWIpO1xyXG4gICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gUGFuY2hheWF0IG11dGF0aW9uc1xyXG4gIGNvbnN0IGhhbmRsZUFkZFBhbmNoYXlhdCA9IChuZXdQYW5jaGF5YXQ6IHtcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIGNsdXN0ZXI6IHN0cmluZztcclxuICAgIHN0YXR1czogJ09uIFRyYWNrJyB8ICdDb3JyZWN0aW9uIFJlcXVpcmVkJyB8ICdBY3Rpb24gTmVlZGVkJztcclxuICAgIGluaXRpYWxWaWxsYWdlczogc3RyaW5nW107XHJcbiAgfSkgPT4ge1xyXG4gICAgY29uc3QgbmV3SWQgPSBuZXdQYW5jaGF5YXQubmFtZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1xccysvZywgJy0nKTtcclxuICAgIGNvbnN0IHZpbGxhZ2VzTGlzdCA9IG5ld1BhbmNoYXlhdC5pbml0aWFsVmlsbGFnZXMubWFwKCh2TmFtZSwgaWR4KSA9PiAoe1xyXG4gICAgICBpZDogYHYtJHtEYXRlLm5vdygpfS0ke2lkeH1gLFxyXG4gICAgICBuYW1lOiB2TmFtZSxcclxuICAgICAgc3R1ZGVudENvdW50OiAwLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGNvbnN0IGNyZWF0ZWQ6IFBhbmNoYXlhdCA9IHtcclxuICAgICAgaWQ6IG5ld0lkLFxyXG4gICAgICBuYW1lOiBuZXdQYW5jaGF5YXQubmFtZSxcclxuICAgICAgY2x1c3RlcjogbmV3UGFuY2hheWF0LmNsdXN0ZXIgfHwgJ0RoYXJtYXB1cmknLFxyXG4gICAgICBzdGF0dXM6IG5ld1BhbmNoYXlhdC5zdGF0dXMgfHwgJ09uIFRyYWNrJyxcclxuICAgICAgdmlsbGFnZXNDb3VudDogdmlsbGFnZXNMaXN0Lmxlbmd0aCxcclxuICAgICAgYWN0aXZlU3R1ZGVudHM6IDAsXHJcbiAgICAgIHZvbHVudGVlcnNDb3VudDogMCxcclxuICAgICAgdmlsbGFnZXM6IHZpbGxhZ2VzTGlzdCxcclxuICAgIH07XHJcblxyXG4gICAgc2V0UGFuY2hheWF0cygocHJldikgPT4gW2NyZWF0ZWQsIC4uLnByZXZdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRWaWxsYWdlID0gKHBhbmNoYXlhdElkOiBzdHJpbmcsIHZpbGxhZ2VOYW1lOiBzdHJpbmcpID0+IHtcclxuICAgIHNldFBhbmNoYXlhdHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYubWFwKChwKSA9PiB7XHJcbiAgICAgICAgaWYgKHAuaWQgPT09IHBhbmNoYXlhdElkKSB7XHJcbiAgICAgICAgICBjb25zdCBuZXdWaWxsYWdlID0ge1xyXG4gICAgICAgICAgICBpZDogYHYtJHtEYXRlLm5vdygpfWAsXHJcbiAgICAgICAgICAgIG5hbWU6IHZpbGxhZ2VOYW1lLFxyXG4gICAgICAgICAgICBzdHVkZW50Q291bnQ6IDAsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgY29uc3QgdXBkYXRlZFZpbGxhZ2VzID0gWy4uLnAudmlsbGFnZXMsIG5ld1ZpbGxhZ2VdO1xyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgdmlsbGFnZXM6IHVwZGF0ZWRWaWxsYWdlcyxcclxuICAgICAgICAgICAgdmlsbGFnZXNDb3VudDogdXBkYXRlZFZpbGxhZ2VzLmxlbmd0aCxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICAvLyBTdHVkZW50IG11dGF0aW9uc1xyXG4gIGNvbnN0IGhhbmRsZUFkZFN0dWRlbnQgPSAobmV3U3R1ZGVudDogT21pdDxTdHVkZW50LCAnaWQnIHwgJ2NvZGUnIHwgJ2F2YXRhckxldHRlcicgfCAnYXZhdGFyQmcnPikgPT4ge1xyXG4gICAgY29uc3QgbmV3SWQgPSBgc3R1LSR7RGF0ZS5ub3coKX1gO1xyXG4gICAgY29uc3QgY29kZSA9IGBTVFUtMjQtJHtTdHJpbmcoc3R1ZGVudHMubGVuZ3RoICsgMSkucGFkU3RhcnQoMywgJzAnKX1gO1xyXG4gICAgY29uc3QgYXZhdGFyTGV0dGVyID0gbmV3U3R1ZGVudC5uYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpO1xyXG4gICAgY29uc3QgY29sb3JzID0gWydiZy1bIzBiM2Q5MV0gdGV4dC13aGl0ZScsICdiZy1bIzM0NWJhZl0gdGV4dC13aGl0ZScsICdiZy1bIzUyMWEwMF0gdGV4dC13aGl0ZScsICdiZy1bIzU5MjYwMF0gdGV4dC13aGl0ZSddO1xyXG4gICAgY29uc3QgYXZhdGFyQmcgPSBjb2xvcnNbc3R1ZGVudHMubGVuZ3RoICUgY29sb3JzLmxlbmd0aF07XHJcblxyXG4gICAgY29uc3QgY3JlYXRlZDogU3R1ZGVudCA9IHtcclxuICAgICAgLi4ubmV3U3R1ZGVudCxcclxuICAgICAgaWQ6IG5ld0lkLFxyXG4gICAgICBjb2RlLFxyXG4gICAgICBhdmF0YXJMZXR0ZXIsXHJcbiAgICAgIGF2YXRhckJnLFxyXG4gICAgfTtcclxuICAgIHNldFN0dWRlbnRzKChwcmV2KSA9PiBbY3JlYXRlZCwgLi4ucHJldl0pO1xyXG5cclxuICAgIHNldFBhbmNoYXlhdHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYubWFwKChwKSA9PiB7XHJcbiAgICAgICAgaWYgKHAuaWQgPT09IG5ld1N0dWRlbnQucGFuY2hheWF0SWQpIHtcclxuICAgICAgICAgIGNvbnN0IHVwZGF0ZWRWaWxsYWdlcyA9IHAudmlsbGFnZXMubWFwKCh2KSA9PlxyXG4gICAgICAgICAgICB2Lm5hbWUgPT09IG5ld1N0dWRlbnQudmlsbGFnZU5hbWUgfHwgdi5pZCA9PT0gbmV3U3R1ZGVudC52aWxsYWdlSWRcclxuICAgICAgICAgICAgICA/IHsgLi4udiwgc3R1ZGVudENvdW50OiB2LnN0dWRlbnRDb3VudCArIDEgfVxyXG4gICAgICAgICAgICAgIDogdlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgIGFjdGl2ZVN0dWRlbnRzOiBwLmFjdGl2ZVN0dWRlbnRzICsgMSxcclxuICAgICAgICAgICAgdmlsbGFnZXM6IHVwZGF0ZWRWaWxsYWdlcyxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVCdWxrQWRkU3R1ZGVudHMgPSAoXHJcbiAgICBuZXdTdHVkZW50c0xpc3Q6IEFycmF5PE9taXQ8U3R1ZGVudCwgJ2lkJyB8ICdjb2RlJyB8ICdhdmF0YXJMZXR0ZXInIHwgJ2F2YXRhckJnJz4+XHJcbiAgKSA9PiB7XHJcbiAgICBpZiAoIW5ld1N0dWRlbnRzTGlzdCB8fCBuZXdTdHVkZW50c0xpc3QubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgY29sb3JzID0gW1xyXG4gICAgICAnYmctWyMwYjNkOTFdIHRleHQtd2hpdGUnLFxyXG4gICAgICAnYmctWyMzNDViYWZdIHRleHQtd2hpdGUnLFxyXG4gICAgICAnYmctWyM1MjFhMDBdIHRleHQtd2hpdGUnLFxyXG4gICAgICAnYmctWyM1OTI2MDBdIHRleHQtd2hpdGUnLFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBjdXJyZW50VG90YWwgPSBzdHVkZW50cy5sZW5ndGg7XHJcbiAgICBjb25zdCBjcmVhdGVkQmF0Y2g6IFN0dWRlbnRbXSA9IG5ld1N0dWRlbnRzTGlzdC5tYXAoKHN0LCBpZHgpID0+IHtcclxuICAgICAgY29uc3QgY29kZU51bWJlciA9IGN1cnJlbnRUb3RhbCArIGlkeCArIDE7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3QsXHJcbiAgICAgICAgaWQ6IGBzdHUtJHtEYXRlLm5vdygpfS0ke2lkeH0tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoMiwgNil9YCxcclxuICAgICAgICBjb2RlOiBgU1RVLTI0LSR7U3RyaW5nKGNvZGVOdW1iZXIpLnBhZFN0YXJ0KDMsICcwJyl9YCxcclxuICAgICAgICBhdmF0YXJMZXR0ZXI6IChzdC5uYW1lIHx8ICdTJykuY2hhckF0KDApLnRvVXBwZXJDYXNlKCksXHJcbiAgICAgICAgYXZhdGFyQmc6IGNvbG9yc1soY3VycmVudFRvdGFsICsgaWR4KSAlIGNvbG9ycy5sZW5ndGhdLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0U3R1ZGVudHMoKHByZXYpID0+IFsuLi5jcmVhdGVkQmF0Y2gsIC4uLnByZXZdKTtcclxuXHJcbiAgICBzZXRQYW5jaGF5YXRzKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgocCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoaW5nQWRkZWQgPSBjcmVhdGVkQmF0Y2guZmlsdGVyKChzKSA9PiBzLnBhbmNoYXlhdElkID09PSBwLmlkKTtcclxuICAgICAgICBpZiAobWF0Y2hpbmdBZGRlZC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB1cGRhdGVkVmlsbGFnZXMgPSBwLnZpbGxhZ2VzLm1hcCgodikgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB2aWxsYWdlQWRkZWQgPSBtYXRjaGluZ0FkZGVkLmZpbHRlcihcclxuICAgICAgICAgICAgICAocykgPT4gcy52aWxsYWdlSWQgPT09IHYuaWQgfHwgcy52aWxsYWdlTmFtZSA9PT0gdi5uYW1lXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgLi4udixcclxuICAgICAgICAgICAgICBzdHVkZW50Q291bnQ6IHYuc3R1ZGVudENvdW50ICsgdmlsbGFnZUFkZGVkLmxlbmd0aCxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgYWN0aXZlU3R1ZGVudHM6IHAuYWN0aXZlU3R1ZGVudHMgKyBtYXRjaGluZ0FkZGVkLmxlbmd0aCxcclxuICAgICAgICAgICAgdmlsbGFnZXM6IHVwZGF0ZWRWaWxsYWdlcyxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwO1xyXG4gICAgICB9KVxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVTdHVkZW50ID0gKGlkOiBzdHJpbmcsIHVwZGF0ZWQ6IFBhcnRpYWw8U3R1ZGVudD4pID0+IHtcclxuICAgIHNldFN0dWRlbnRzKChwcmV2KSA9PiBwcmV2Lm1hcCgocykgPT4gKHMuaWQgPT09IGlkID8geyAuLi5zLCAuLi51cGRhdGVkIH0gOiBzKSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVN0dWRlbnQgPSAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgdG9EZWxldGUgPSBzdHVkZW50cy5maW5kKChzKSA9PiBzLmlkID09PSBpZCk7XHJcbiAgICBpZiAodG9EZWxldGUpIHtcclxuICAgICAgc2V0UGFuY2hheWF0cygocHJldikgPT5cclxuICAgICAgICBwcmV2Lm1hcCgocCkgPT4ge1xyXG4gICAgICAgICAgaWYgKHAuaWQgPT09IHRvRGVsZXRlLnBhbmNoYXlhdElkKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRWaWxsYWdlcyA9IHAudmlsbGFnZXMubWFwKCh2KSA9PlxyXG4gICAgICAgICAgICAgIHYubmFtZSA9PT0gdG9EZWxldGUudmlsbGFnZU5hbWUgfHwgdi5pZCA9PT0gdG9EZWxldGUudmlsbGFnZUlkXHJcbiAgICAgICAgICAgICAgICA/IHsgLi4udiwgc3R1ZGVudENvdW50OiBNYXRoLm1heCgwLCB2LnN0dWRlbnRDb3VudCAtIDEpIH1cclxuICAgICAgICAgICAgICAgIDogdlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgYWN0aXZlU3R1ZGVudHM6IE1hdGgubWF4KDAsIHAuYWN0aXZlU3R1ZGVudHMgLSAxKSxcclxuICAgICAgICAgICAgICB2aWxsYWdlczogdXBkYXRlZFZpbGxhZ2VzLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgfSlcclxuICAgICAgKTtcclxuICAgIH1cclxuICAgIHNldFN0dWRlbnRzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigocykgPT4gcy5pZCAhPT0gaWQpKTtcclxuICB9O1xyXG5cclxuICAvLyBWb2x1bnRlZXIgbXV0YXRpb25zXHJcbiAgY29uc3QgaGFuZGxlQWRkVm9sdW50ZWVyID0gKG5ld1ZvbDogT21pdDxWb2x1bnRlZXIsICdpZCcgfCAnYXZhdGFyVGV4dCcgfCAncmVjZW50U2Vzc2lvbnMnIHwgJ3RvdGFsU2Vzc2lvbnMnIHwgJ2F0dGVuZGFuY2VSYXRlJz4pID0+IHtcclxuICAgIGNvbnN0IG5ld0lkID0gYHZvbC0ke0RhdGUubm93KCl9YDtcclxuICAgIGNvbnN0IG5hbWVzID0gbmV3Vm9sLm5hbWUuc3BsaXQoJyAnKTtcclxuICAgIGNvbnN0IGF2YXRhclRleHQgPSBuYW1lcy5sZW5ndGggPiAxID8gYCR7bmFtZXNbMF1bMF19JHtuYW1lc1sxXVswXX1gLnRvVXBwZXJDYXNlKCkgOiBuZXdWb2wubmFtZS5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpO1xyXG5cclxuICAgIGNvbnN0IGNyZWF0ZWQ6IFZvbHVudGVlciA9IHtcclxuICAgICAgLi4ubmV3Vm9sLFxyXG4gICAgICBpZDogbmV3SWQsXHJcbiAgICAgIGF2YXRhclRleHQsXHJcbiAgICAgIHRvdGFsU2Vzc2lvbnM6IDAsXHJcbiAgICAgIGF0dGVuZGFuY2VSYXRlOiAxMDAsXHJcbiAgICAgIHJlY2VudFNlc3Npb25zOiBbXSxcclxuICAgIH07XHJcbiAgICBzZXRWb2x1bnRlZXJzKChwcmV2KSA9PiBbY3JlYXRlZCwgLi4ucHJldl0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVZvbHVudGVlciA9IChpZDogc3RyaW5nLCB1cGRhdGVkOiBQYXJ0aWFsPFZvbHVudGVlcj4pID0+IHtcclxuICAgIHNldFZvbHVudGVlcnMoKHByZXYpID0+IHByZXYubWFwKCh2KSA9PiAodi5pZCA9PT0gaWQgPyB7IC4uLnYsIC4uLnVwZGF0ZWQgfSA6IHYpKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlVm9sdW50ZWVyID0gKGlkOiBzdHJpbmcpID0+IHtcclxuICAgIHNldFZvbHVudGVlcnMoKHByZXYpID0+IHByZXYuZmlsdGVyKCh2KSA9PiB2LmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIC8vIFNlc3Npb24gbXV0YXRpb25zXHJcbiAgY29uc3QgaGFuZGxlQWRkU2Vzc2lvbiA9IChuZXdTZXNzaW9uOiBPbWl0PFNlc3Npb24sICdpZCc+KSA9PiB7XHJcbiAgICBjb25zdCBjcmVhdGVkOiBTZXNzaW9uID0ge1xyXG4gICAgICAuLi5uZXdTZXNzaW9uLFxyXG4gICAgICBpZDogYHNlc3MtJHtEYXRlLm5vdygpfWAsXHJcbiAgICB9O1xyXG4gICAgc2V0U2Vzc2lvbnMoKHByZXYpID0+IFtjcmVhdGVkLCAuLi5wcmV2XSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlU2Vzc2lvbiA9IGFzeW5jIChpZDogc3RyaW5nLCB1cGRhdGVkOiBQYXJ0aWFsPFNlc3Npb24+KSA9PiB7XHJcbiAgICBjb25zdCBleGlzdGluZyA9IHNlc3Npb25zLmZpbmQoKHNlc3Npb24pID0+IHNlc3Npb24uaWQgPT09IGlkKTtcclxuICAgIGlmIChjdXJyZW50VXNlcj8udG9rZW4gJiYgZXhpc3RpbmcpIHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvc2Vzc2lvbnMvJHtpZH1gKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXIudG9rZW59YCB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIC4uLmV4aXN0aW5nLFxyXG4gICAgICAgICAgLi4udXBkYXRlZCxcclxuICAgICAgICAgIGFjYWRlbWljWWVhcjogZXhpc3RpbmcuYWNhZGVtaWNZZWFyLFxyXG4gICAgICAgICAgZGF5TnVtYmVyOiBleGlzdGluZy5kYXlOdW1iZXIsXHJcbiAgICAgICAgICBzZXNzaW9uTmFtZTogZXhpc3RpbmcubmFtZSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSk7XHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFNlc3Npb25zKChwcmV2KSA9PiBwcmV2Lm1hcCgocykgPT4gKHMuaWQgPT09IGlkID8geyAuLi5zLCAuLi51cGRhdGVkIH0gOiBzKSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVNlc3Npb24gPSAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0U2Vzc2lvbnMoKHByZXYpID0+IHByZXYuZmlsdGVyKChzKSA9PiBzLmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIC8vIEF0dGVuZGFuY2UgbXV0YXRpb25zXHJcbiAgY29uc3QgaGFuZGxlU2F2ZUF0dGVuZGFuY2UgPSBhc3luYyAoc2Vzc2lvbjogQXR0ZW5kYW5jZVNlc3Npb24pID0+IHtcclxuICAgIGlmIChjdXJyZW50VXNlclJvbGUgPT09ICdDbHVzdGVyIEFkbWluJyAmJiBjdXJyZW50VXNlcj8udG9rZW4pIHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoJy9hcGkvYXR0ZW5kYW5jZScpLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXIudG9rZW59YCB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHNlc3Npb24pLFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEF0dGVuZGFuY2VTZXNzaW9ucygocHJldikgPT4ge1xyXG4gICAgICBjb25zdCBpZHggPSBwcmV2LmZpbmRJbmRleCgocykgPT4gcy5pZCA9PT0gc2Vzc2lvbi5pZCk7XHJcbiAgICAgIGlmIChpZHggPj0gMCkge1xyXG4gICAgICAgIGNvbnN0IGNvcHkgPSBbLi4ucHJldl07XHJcbiAgICAgICAgY29weVtpZHhdID0gc2Vzc2lvbjtcclxuICAgICAgICByZXR1cm4gY29weTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gW3Nlc3Npb24sIC4uLnByZXZdO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKHNlc3Npb24uc3RhdHVzID09PSAnU3VibWl0dGVkJykge1xyXG4gICAgICBjb25zdCBuZXdBcHByOiBBcHByb3ZhbEl0ZW0gPSB7XHJcbiAgICAgICAgaWQ6IGBhcHByLSR7RGF0ZS5ub3coKX1gLFxyXG4gICAgICAgIG1vZHVsZTogJ0F0dGVuZGFuY2UnLFxyXG4gICAgICAgIHJlY29yZElkOiBzZXNzaW9uLmlkLFxyXG4gICAgICAgIHJlY29yZFRpdGxlOiBgJHtzZXNzaW9uLnBhbmNoYXlhdE5hbWUgfHwgJ0NlbnRlcid9IC0gJHtzZXNzaW9uLnNlc3Npb25OYW1lIHx8ICdBdHRlbmRhbmNlJ31gLFxyXG4gICAgICAgIGNsdXN0ZXJJZDogY3VycmVudFVzZXJDbHVzdGVySWQsXHJcbiAgICAgICAgY2x1c3Rlck5hbWU6ICdEaGFybWFwdXJpIENsdXN0ZXInLFxyXG4gICAgICAgIHN1Ym1pdHRlZEJ5OiAnRGhhcm1hcHVyaSBDbHVzdGVyIEFkbWluJyxcclxuICAgICAgICBzdWJtaXR0ZWRBdDogJ0p1c3Qgbm93JyxcclxuICAgICAgICBzdGF0dXM6ICdQZW5kaW5nJyxcclxuICAgICAgICBkZXRhaWxzOiB7XHJcbiAgICAgICAgICBwcmVzZW50Q291bnQ6IHNlc3Npb24ucHJlc2VudENvdW50IHx8IHNlc3Npb24ucmVjb3Jkcz8uZmlsdGVyKChzKSA9PiBzLnN0YXR1cyA9PT0gJ1ByZXNlbnQnKS5sZW5ndGggfHwgMCxcclxuICAgICAgICAgIHRvdGFsQ291bnQ6IHNlc3Npb24udG90YWxDb3VudCB8fCBzZXNzaW9uLnJlY29yZHM/Lmxlbmd0aCB8fCAwLFxyXG4gICAgICAgICAgdmlsbGFnZU5hbWU6IHNlc3Npb24udmlsbGFnZU5hbWUgfHwgJycsXHJcbiAgICAgICAgICBkYXlOdW1iZXI6IHNlc3Npb24uZGF5TnVtYmVyIHx8IDEsXHJcbiAgICAgICAgfSxcclxuICAgICAgfTtcclxuICAgICAgc2V0QXBwcm92YWxzKChwcmV2KSA9PiBbbmV3QXBwciwgLi4ucHJldl0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEZpbmFuY2UgbXV0YXRpb25zXHJcbiAgY29uc3QgaGFuZGxlQWRkRmluYW5jZUVudHJ5ID0gKGVudHJ5OiBPbWl0PEZpbmFuY2VFbnRyeSwgJ2lkJz4pID0+IHtcclxuICAgIGNvbnN0IGNyZWF0ZWQ6IEZpbmFuY2VFbnRyeSA9IHtcclxuICAgICAgLi4uZW50cnksXHJcbiAgICAgIGlkOiBgZmluLSR7RGF0ZS5ub3coKX0tJHtNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDAwKX1gLFxyXG4gICAgfTtcclxuICAgIHNldEZpbmFuY2VFbnRyaWVzKChwcmV2KSA9PiBbY3JlYXRlZCwgLi4ucHJldl0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZUZpbmFuY2VFbnRyeSA9IChpZDogc3RyaW5nLCB1cGRhdGVkOiBQYXJ0aWFsPEZpbmFuY2VFbnRyeT4pID0+IHtcclxuICAgIHNldEZpbmFuY2VFbnRyaWVzKChwcmV2KSA9PiBwcmV2Lm1hcCgoZSkgPT4gKGUuaWQgPT09IGlkID8geyAuLi5lLCAuLi51cGRhdGVkIH0gOiBlKSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUZpbmFuY2VFbnRyeSA9IChpZDogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRGaW5hbmNlRW50cmllcygocHJldikgPT4gcHJldi5maWx0ZXIoKGUpID0+IGUuaWQgIT09IGlkKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2F2ZUZpbmFuY2VEcmFmdCA9IChkcmFmdDogRmluYW5jZURyYWZ0KSA9PiB7XHJcbiAgICBzZXRGaW5hbmNlRHJhZnRzKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlkeCA9IHByZXYuZmluZEluZGV4KChkKSA9PiBkLmlkID09PSBkcmFmdC5pZCk7XHJcbiAgICAgIGlmIChpZHggPj0gMCkge1xyXG4gICAgICAgIGNvbnN0IGNvcHkgPSBbLi4ucHJldl07XHJcbiAgICAgICAgY29weVtpZHhdID0gZHJhZnQ7XHJcbiAgICAgICAgcmV0dXJuIGNvcHk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIFtkcmFmdCwgLi4ucHJldl07XHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVGaW5hbmNlRHJhZnQgPSAoZHJhZnRJZDogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRGaW5hbmNlRHJhZnRzKChwcmV2KSA9PiBwcmV2LmZpbHRlcigoZCkgPT4gZC5pZCAhPT0gZHJhZnRJZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdEZpbmFuY2VEcmFmdCA9IChkcmFmdElkOiBzdHJpbmcpID0+IHtcclxuICAgIHNldEZpbmFuY2VEcmFmdHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYubWFwKChkKSA9PiAoZC5pZCA9PT0gZHJhZnRJZCA/IHsgLi4uZCwgc3RhdHVzOiAnUGVuZGluZycgfSA6IGQpKVxyXG4gICAgKTtcclxuICAgIHNldEZpbmFuY2VFbnRyaWVzKChwcmV2KSA9PlxyXG4gICAgICBwcmV2Lm1hcCgoZSkgPT4gKGUuZHJhZnRJZCA9PT0gZHJhZnRJZCA/IHsgLi4uZSwgc3RhdHVzOiAnUGVuZGluZycgfSA6IGUpKVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCB0YXJnZXREcmFmdCA9IGZpbmFuY2VEcmFmdHMuZmluZCgoZCkgPT4gZC5pZCA9PT0gZHJhZnRJZCk7XHJcbiAgICBjb25zdCBuZXdBcHByOiBBcHByb3ZhbEl0ZW0gPSB7XHJcbiAgICAgIGlkOiBgYXBwci0ke0RhdGUubm93KCl9YCxcclxuICAgICAgbW9kdWxlOiAnRmluYW5jZScsXHJcbiAgICAgIHJlY29yZElkOiBkcmFmdElkLFxyXG4gICAgICByZWNvcmRUaXRsZTogdGFyZ2V0RHJhZnQ/LnRpdGxlIHx8ICdGaW5hbmNlIENsYWltIFZvdWNoZXInLFxyXG4gICAgICBjbHVzdGVySWQ6IGN1cnJlbnRVc2VyQ2x1c3RlcklkLFxyXG4gICAgICBjbHVzdGVyTmFtZTogJ0RoYXJtYXB1cmkgQ2x1c3RlcicsXHJcbiAgICAgIHN1Ym1pdHRlZEJ5OiAnRGhhcm1hcHVyaSBDbHVzdGVyIEFkbWluJyxcclxuICAgICAgc3VibWl0dGVkQXQ6ICdKdXN0IG5vdycsXHJcbiAgICAgIHN0YXR1czogJ1BlbmRpbmcnLFxyXG4gICAgICBkZXRhaWxzOiB7XHJcbiAgICAgICAgdG90YWxBbW91bnQ6IHRhcmdldERyYWZ0Py50b3RhbEFtb3VudCB8fCAwLFxyXG4gICAgICAgIGl0ZW1Db3VudDogdGFyZ2V0RHJhZnQ/LnJvdXRlcz8ubGVuZ3RoIHx8IDEsXHJcbiAgICAgICAgc3BvY05hbWU6ICdBZG1pbicsXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gICAgc2V0QXBwcm92YWxzKChwcmV2KSA9PiBbbmV3QXBwciwgLi4ucHJldl0pO1xyXG4gIH07XHJcblxyXG4gIC8vIExlc3NvbiBQbGFuIG11dGF0aW9uc1xyXG4gIGNvbnN0IGhhbmRsZUFkZExlc3NvblBsYW4gPSAocGxhbjogT21pdDxMZXNzb25QbGFuLCAnaWQnPikgPT4ge1xyXG4gICAgY29uc3QgY3JlYXRlZDogTGVzc29uUGxhbiA9IHtcclxuICAgICAgLi4ucGxhbixcclxuICAgICAgaWQ6IGBscC0ke0RhdGUubm93KCl9YCxcclxuICAgIH07XHJcbiAgICBzZXRMZXNzb25QbGFucygocHJldikgPT4gW2NyZWF0ZWQsIC4uLnByZXZdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVMZXNzb25QbGFuID0gKGlkOiBzdHJpbmcsIHBsYW46IFBhcnRpYWw8TGVzc29uUGxhbj4pID0+IHtcclxuICAgIHNldExlc3NvblBsYW5zKChwcmV2KSA9PiBwcmV2Lm1hcCgocCkgPT4gKHAuaWQgPT09IGlkID8geyAuLi5wLCAuLi5wbGFuIH0gOiBwKSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUxlc3NvblBsYW4gPSAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0TGVzc29uUGxhbnMoKHByZXYpID0+IHByZXYuZmlsdGVyKChwKSA9PiBwLmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIC8vIE5vdGlmaWNhdGlvbiBhY3Rpb25zXHJcbiAgY29uc3QgaGFuZGxlTWFya0FzUmVhZCA9IChpZDogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXROb3RpZmljYXRpb25zKChwcmV2KSA9PiBwcmV2Lm1hcCgobikgPT4gKG4uaWQgPT09IGlkID8geyAuLi5uLCBpc1JlYWQ6IHRydWUgfSA6IG4pKSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTWFya0FsbEFzUmVhZCA9ICgpID0+IHtcclxuICAgIHNldE5vdGlmaWNhdGlvbnMoKHByZXYpID0+IHByZXYubWFwKChuKSA9PiAoeyAuLi5uLCBpc1JlYWQ6IHRydWUgfSkpKTtcclxuICB9O1xyXG5cclxuICAvLyBEYXRlIENoYW5nZSBSZXF1ZXN0IGhhbmRsZXJzXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0RGF0ZUNoYW5nZVJlcXVlc3QgPSBhc3luYyAoc2Vzc2lvbklkOiBzdHJpbmcsIG9yaWdpbmFsRGF0ZTogc3RyaW5nLCByZXF1ZXN0ZWREYXRlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCgnL2FwaS9kYXRlLWNoYW5nZS1yZXF1ZXN0cycpLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHNlc3Npb25JZCwgb3JpZ2luYWxEYXRlLCByZXF1ZXN0ZWREYXRlLCByZWFzb24gfSksXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICBpZiAoZGF0YT8uc3VjY2VzcyAmJiBkYXRhLmRhdGVDaGFuZ2VSZXF1ZXN0KSB7XHJcbiAgICAgICAgc2V0RGF0ZUNoYW5nZVJlcXVlc3RzKHByZXYgPT4gW2RhdGEuZGF0ZUNoYW5nZVJlcXVlc3QsIC4uLnByZXZdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCB7IC8qIGlnbm9yZSAqLyB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmV2aWV3RGF0ZUNoYW5nZVJlcXVlc3QgPSBhc3luYyAocmVxdWVzdElkOiBzdHJpbmcsIGFjdGlvbjogJ2FwcHJvdmUnIHwgJ3JlamVjdCcsIHJlbWFya3M6IHN0cmluZykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvZGF0ZS1jaGFuZ2UtcmVxdWVzdHMvJHtyZXF1ZXN0SWR9LyR7YWN0aW9ufWApLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlcj8udG9rZW4gfHwgJyd9YCB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcmVtYXJrcyB9KSxcclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgIGlmIChkYXRhPy5zdWNjZXNzKSB7XHJcbiAgICAgICAgc2V0RGF0ZUNoYW5nZVJlcXVlc3RzKHByZXYgPT4gcHJldi5tYXAociA9PiByLmlkID09PSByZXF1ZXN0SWQgPyB7IC4uLnIsIHN0YXR1czogYWN0aW9uID09PSAnYXBwcm92ZScgPyAnQVBQUk9WRUQnIDogJ1JFSkVDVEVEJywgcmV2aWV3UmVtYXJrczogcmVtYXJrcyB9IDogcikpO1xyXG4gICAgICAgIGlmIChhY3Rpb24gPT09ICdhcHByb3ZlJykge1xyXG4gICAgICAgICAgLy8gUmVmcmVzaCBzZXNzaW9ucyB0byBnZXQgdXBkYXRlZCBkYXRlc1xyXG4gICAgICAgICAgZmV0Y2hCYWNrZW5kRGF0YShuZXcgQWJvcnRDb250cm9sbGVyKCkuc2lnbmFsKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxyXG4gIH07XHJcblxyXG4gIC8vIFNlc3Npb24gUmVwb3J0IGhhbmRsZXJzXHJcbiAgY29uc3QgaGFuZGxlU2F2ZVNlc3Npb25SZXBvcnQgPSBhc3luYyAocmVwb3J0OiBQYXJ0aWFsPFNlc3Npb25SZXBvcnQ+KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCgnL2FwaS9zZXNzaW9uLXJlcG9ydHMnKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke2N1cnJlbnRVc2VyPy50b2tlbiB8fCAnJ31gIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVwb3J0KSxcclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XHJcbiAgICAgIGlmIChkYXRhPy5zdWNjZXNzICYmIGRhdGEuc2Vzc2lvblJlcG9ydCkge1xyXG4gICAgICAgIHNldFNlc3Npb25SZXBvcnRzKHByZXYgPT4ge1xyXG4gICAgICAgICAgY29uc3QgaWR4ID0gcHJldi5maW5kSW5kZXgociA9PiByLmlkID09PSBkYXRhLnNlc3Npb25SZXBvcnQuaWQpO1xyXG4gICAgICAgICAgaWYgKGlkeCA+PSAwKSB7IGNvbnN0IGNvcHkgPSBbLi4ucHJldl07IGNvcHlbaWR4XSA9IGRhdGEuc2Vzc2lvblJlcG9ydDsgcmV0dXJuIGNvcHk7IH1cclxuICAgICAgICAgIHJldHVybiBbZGF0YS5zZXNzaW9uUmVwb3J0LCAuLi5wcmV2XTtcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCB7IC8qIGlnbm9yZSAqLyB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlU2Vzc2lvblJlcG9ydCA9IGFzeW5jIChyZXBvcnRJZDogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvc2Vzc2lvbi1yZXBvcnRzLyR7cmVwb3J0SWR9YCksIHtcclxuICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke2N1cnJlbnRVc2VyPy50b2tlbiB8fCAnJ31gIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTZXNzaW9uUmVwb3J0cyhwcmV2ID0+IHByZXYuZmlsdGVyKHIgPT4gci5pZCAhPT0gcmVwb3J0SWQpKTtcclxuICAgIH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxyXG4gIH07XHJcblxyXG4gIC8vIFNlc3Npb24gU3VibWlzc2lvbiBoYW5kbGVyc1xyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdFNlc3Npb24gPSBhc3luYyAoc2Vzc2lvbklkOiBzdHJpbmcsIGNsdXN0ZXJJZDogc3RyaW5nLCBkYXlOdW1iZXI6IG51bWJlcikgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoJy9hcGkvc2Vzc2lvbi1zdWJtaXNzaW9ucycpLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHNlc3Npb25JZCwgY2x1c3RlcklkLCBkYXlOdW1iZXIgfSksXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICBpZiAoZGF0YT8uc3VjY2VzcyAmJiBkYXRhLnN1Ym1pc3Npb24pIHtcclxuICAgICAgICBzZXRTZXNzaW9uU3VibWlzc2lvbnMocHJldiA9PiBbZGF0YS5zdWJtaXNzaW9uLCAuLi5wcmV2XSk7XHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZGF0YT8uZXJyb3IsIG1pc3NpbmdJdGVtczogZGF0YT8ubWlzc2luZ0l0ZW1zIH07XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnTmV0d29yayBlcnJvcicgfTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZXZpZXdTdWJtaXNzaW9uID0gYXN5bmMgKHN1Ym1pc3Npb25JZDogc3RyaW5nLCBhY3Rpb246ICdhcHByb3ZlJyB8ICdyZXN1Ym1pc3Npb24nLCByZW1hcmtzOiBzdHJpbmcpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGZldGNoKGFwaVVybChgL2FwaS9zZXNzaW9uLXN1Ym1pc3Npb25zLyR7c3VibWlzc2lvbklkfS9yZXZpZXdgKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGFjdGlvbiwgcmVtYXJrcyB9KSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlc3Npb25TdWJtaXNzaW9ucyhwcmV2ID0+IHByZXYubWFwKHMgPT4gcy5pZCA9PT0gc3VibWlzc2lvbklkID8ge1xyXG4gICAgICAgIC4uLnMsXHJcbiAgICAgICAgc3RhdHVzOiBhY3Rpb24gPT09ICdhcHByb3ZlJyA/ICdBUFBST1ZFRCcgOiAnUkVTVUJNSVNTSU9OX1JFUVVJUkVEJyxcclxuICAgICAgICByZXZpZXdSZW1hcmtzOiByZW1hcmtzLFxyXG4gICAgICB9IDogcykpO1xyXG4gICAgfSBjYXRjaCB7IC8qIGlnbm9yZSAqLyB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVzdWJtaXRTZXNzaW9uID0gYXN5bmMgKHN1Ym1pc3Npb25JZDogc3RyaW5nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvc2Vzc2lvbi1zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vcmVzdWJtaXRgKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNlc3Npb25TdWJtaXNzaW9ucyhwcmV2ID0+IHByZXYubWFwKHMgPT4gcy5pZCA9PT0gc3VibWlzc2lvbklkID8geyAuLi5zLCBzdGF0dXM6ICdSRVNVQk1JVFRFRCcgfSA6IHMpKTtcclxuICAgIH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxyXG4gIH07XHJcblxyXG4gIC8vIE1vZHVsZSBoYW5kbGVyc1xyXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZU1vZHVsZSA9IGFzeW5jIChtb2R1bGVEYXRhOiB7IG1vZHVsZU51bWJlcjogc3RyaW5nOyBtb2R1bGVOYW1lOiBzdHJpbmc7IHRvcGljOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmc7IGFjYWRlbWljWWVhcjogc3RyaW5nOyBkYXlOdW1iZXI6IG51bWJlciB9KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGFwaVVybCgnL2FwaS9tb2R1bGVzJyksIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlcj8udG9rZW4gfHwgJyd9YCB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG1vZHVsZURhdGEpLFxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgY29uc3QgbmV3TW9kOiBUcWlNb2R1bGUgPSB7XHJcbiAgICAgICAgaWQ6IGRhdGE/Lm1vZHVsZT8uaWQgfHwgYG1vZC0ke0RhdGUubm93KCl9YCxcclxuICAgICAgICBtb2R1bGVOdW1iZXI6IG1vZHVsZURhdGEubW9kdWxlTnVtYmVyLFxyXG4gICAgICAgIG1vZHVsZU5hbWU6IG1vZHVsZURhdGEubW9kdWxlTmFtZSxcclxuICAgICAgICB0b3BpYzogbW9kdWxlRGF0YS50b3BpYyxcclxuICAgICAgICBkZXNjcmlwdGlvbjogbW9kdWxlRGF0YS5kZXNjcmlwdGlvbixcclxuICAgICAgICBhY2FkZW1pY1llYXI6IG1vZHVsZURhdGEuYWNhZGVtaWNZZWFyLFxyXG4gICAgICAgIGRheU51bWJlcjogbW9kdWxlRGF0YS5kYXlOdW1iZXIsXHJcbiAgICAgICAgc3RhdHVzOiAnQWN0aXZlJyxcclxuICAgICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICAgIHJlc291cmNlczogW10sXHJcbiAgICAgICAgY3JlYXRlZEJ5OiBjdXJyZW50VXNlcj8ubmFtZSB8fCAnU3VwZXIgQWRtaW4nLFxyXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICB9O1xyXG4gICAgICBzZXRNb2R1bGVzKHByZXYgPT4gW25ld01vZCwgLi4ucHJldl0pO1xyXG4gICAgfSBjYXRjaCB7IC8qIGlnbm9yZSAqLyB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kdWxlID0gYXN5bmMgKGlkOiBzdHJpbmcsIG1vZHVsZURhdGE6IGFueSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvbW9kdWxlcy8ke2lkfWApLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtjdXJyZW50VXNlcj8udG9rZW4gfHwgJyd9YCB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KG1vZHVsZURhdGEpLFxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgaWYgKGRhdGE/LnN1Y2Nlc3MgJiYgZGF0YS5kYXRhKSB7XHJcbiAgICAgICAgc2V0TW9kdWxlcyhwcmV2ID0+IHByZXYubWFwKG0gPT4gbS5pZCA9PT0gaWQgPyB7IC4uLm0sIC4uLmRhdGEuZGF0YSB9IDogbSkpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIHsgLyogaWdub3JlICovIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2R1bGUgPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgZmV0Y2goYXBpVXJsKGAvYXBpL21vZHVsZXMvJHtpZH1gKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y3VycmVudFVzZXI/LnRva2VuIHx8ICcnfWAgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldE1vZHVsZXMocHJldiA9PiBwcmV2LmZpbHRlcihtID0+IG0uaWQgIT09IGlkKSk7XHJcbiAgICB9IGNhdGNoIHsgLyogaWdub3JlICovIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGxvYWRNb2R1bGVSZXNvdXJjZSA9IGFzeW5jIChtb2R1bGVJZDogc3RyaW5nLCBmaWxlOiBGaWxlKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ZpbGUnLCBmaWxlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvbW9kdWxlcy8ke21vZHVsZUlkfS9yZXNvdXJjZXNgKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke2N1cnJlbnRVc2VyPy50b2tlbiB8fCAnJ31gIH0sXHJcbiAgICAgICAgYm9keTogZm9ybURhdGEsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICBpZiAoZGF0YT8uc3VjY2VzcyAmJiBkYXRhLnJlc291cmNlKSB7XHJcbiAgICAgICAgc2V0TW9kdWxlcyhwcmV2ID0+IHByZXYubWFwKG0gPT4ge1xyXG4gICAgICAgICAgaWYgKG0uaWQgPT09IG1vZHVsZUlkKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc291cmNlcyA9IG0ucmVzb3VyY2VzID8gWy4uLm0ucmVzb3VyY2VzLCBkYXRhLnJlc291cmNlXSA6IFtkYXRhLnJlc291cmNlXTtcclxuICAgICAgICAgICAgcmV0dXJuIHsgLi4ubSwgcmVzb3VyY2VzIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICByZXR1cm4gbTtcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggeyAvKiBpZ25vcmUgKi8gfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkTW9kdWxlUmVzb3VyY2UgPSAobW9kdWxlSWQ6IHN0cmluZywgcmVzb3VyY2VJZDogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkb3dubG9hZFVybCA9IGFwaVVybChgL2FwaS9tb2R1bGVzLyR7bW9kdWxlSWR9L3Jlc291cmNlcy8ke3Jlc291cmNlSWR9L2Rvd25sb2FkYCk7XHJcbiAgICB3aW5kb3cub3Blbihkb3dubG9hZFVybCwgJ19ibGFuaycpO1xyXG4gIH07XHJcblxyXG4gIC8vIElmIHVzZXIgaXMgbG9nZ2VkIG91dCwgcmVuZGVyIHRoZSBMb2dpbiBQYWdlXHJcbiAgaWYgKCFjdXJyZW50VXNlcikge1xyXG4gICAgcmV0dXJuIDxMb2dpblBhZ2Ugb25Mb2dpblN1Y2Nlc3M9e2hhbmRsZUxvZ2luU3VjY2Vzc30gLz47XHJcbiAgfVxyXG5cclxuICAvLyBTY29wZWQgRGF0YSBMaXN0cyBiYXNlZCBvbiBMb2dnZWQtaW4gVXNlciBSb2xlIGFuZCBDbHVzdGVyXHJcbiAgY29uc3QgY2x1c3RlckZpbHRlcktleSA9IGN1cnJlbnRVc2VyQ2x1c3RlcklkID09PSAnc2FsZW0nID8gJ1NhbGVtJyA6IGN1cnJlbnRVc2VyQ2x1c3RlcklkID09PSAnbmFtYWtrYWwnID8gJ05hbWFra2FsJyA6ICdEaGFybWFwdXJpJztcclxuICBcclxuICBjb25zdCBkaXNwbGF5UGFuY2hheWF0cyA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyBwYW5jaGF5YXRzXHJcbiAgICA6IHBhbmNoYXlhdHMuZmlsdGVyKChwKSA9PiAocC5jbHVzdGVyIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBjbHVzdGVyRmlsdGVyS2V5LnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5UGFuY2hheWF0SWRzID0gbmV3IFNldChkaXNwbGF5UGFuY2hheWF0cy5tYXAoKHApID0+IHAuaWQpKTtcclxuXHJcbiAgY29uc3QgZGlzcGxheVN0dWRlbnRzID0gY3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nXHJcbiAgICA/IHN0dWRlbnRzXHJcbiAgICA6IHN0dWRlbnRzLmZpbHRlcigocykgPT4gZGlzcGxheVBhbmNoYXlhdElkcy5oYXMocy5wYW5jaGF5YXRJZCkpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5Vm9sdW50ZWVycyA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyB2b2x1bnRlZXJzXHJcbiAgICA6IHZvbHVudGVlcnMuZmlsdGVyKCh2KSA9PiAhdi5wYW5jaGF5YXRJZCB8fCBkaXNwbGF5UGFuY2hheWF0SWRzLmhhcyh2LnBhbmNoYXlhdElkKSB8fCB2LmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5U2Vzc2lvbnMgPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbidcclxuICAgID8gc2Vzc2lvbnNcclxuICAgIDogc2Vzc2lvbnMuZmlsdGVyKChzKSA9PiBkaXNwbGF5UGFuY2hheWF0SWRzLmhhcyhzLnBhbmNoYXlhdElkKSB8fCBzLmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5QXR0ZW5kYW5jZSA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyBhdHRlbmRhbmNlU2Vzc2lvbnNcclxuICAgIDogYXR0ZW5kYW5jZVNlc3Npb25zLmZpbHRlcigoYSkgPT4gZGlzcGxheVBhbmNoYXlhdElkcy5oYXMoYS5wYW5jaGF5YXRJZCkgfHwgYS5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcclxuXHJcbiAgY29uc3QgZGlzcGxheUZpbmFuY2UgPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbidcclxuICAgID8gZmluYW5jZUVudHJpZXNcclxuICAgIDogZmluYW5jZUVudHJpZXMuZmlsdGVyKChmKSA9PiAhZi5wYW5jaGF5YXRJZCB8fCBkaXNwbGF5UGFuY2hheWF0SWRzLmhhcyhmLnBhbmNoYXlhdElkKSB8fCBmLmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5RmluYW5jZURyYWZ0cyA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyBmaW5hbmNlRHJhZnRzXHJcbiAgICA6IGZpbmFuY2VEcmFmdHMuZmlsdGVyKChmZCkgPT4gIWZkLmNsdXN0ZXJJZCB8fCBmZC5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcclxuXHJcbiAgY29uc3QgZGlzcGxheUxlc3NvblBsYW5zID0gY3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nXHJcbiAgICA/IGxlc3NvblBsYW5zXHJcbiAgICA6IGxlc3NvblBsYW5zLmZpbHRlcigobHApID0+ICFscC5jbHVzdGVySWQgfHwgbHAuY2x1c3RlcklkID09PSBjdXJyZW50VXNlckNsdXN0ZXJJZCB8fCAobHAucGFuY2hheWF0SWQgJiYgZGlzcGxheVBhbmNoYXlhdElkcy5oYXMobHAucGFuY2hheWF0SWQpKSk7XHJcblxyXG4gIGNvbnN0IGRpc3BsYXlBcHByb3ZhbHMgPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbidcclxuICAgID8gYXBwcm92YWxzXHJcbiAgICA6IGFwcHJvdmFscy5maWx0ZXIoKGEpID0+IGEuY2x1c3RlcklkID09PSBjdXJyZW50VXNlckNsdXN0ZXJJZCk7XHJcblxyXG4gIGNvbnN0IGRpc3BsYXlBdWRpdExvZ3MgPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbidcclxuICAgID8gYXVkaXRMb2dzXHJcbiAgICA6IGF1ZGl0TG9ncy5maWx0ZXIoKGFsKSA9PiBhbC5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcclxuXHJcbiAgY29uc3QgZGlzcGxheURhdGVDaGFuZ2VSZXF1ZXN0cyA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyBkYXRlQ2hhbmdlUmVxdWVzdHNcclxuICAgIDogZGF0ZUNoYW5nZVJlcXVlc3RzLmZpbHRlcihyID0+IHIuY2x1c3RlcklkID09PSBjdXJyZW50VXNlckNsdXN0ZXJJZCk7XHJcblxyXG4gIGNvbnN0IGRpc3BsYXlTZXNzaW9uUmVwb3J0cyA9IGN1cnJlbnRVc2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJ1xyXG4gICAgPyBzZXNzaW9uUmVwb3J0c1xyXG4gICAgOiBzZXNzaW9uUmVwb3J0cy5maWx0ZXIociA9PiByLmNsdXN0ZXJJZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpO1xyXG5cclxuICBjb25zdCBkaXNwbGF5U2Vzc2lvblN1Ym1pc3Npb25zID0gY3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nXHJcbiAgICA/IHNlc3Npb25TdWJtaXNzaW9uc1xyXG4gICAgOiBzZXNzaW9uU3VibWlzc2lvbnMuZmlsdGVyKHMgPT4gcy5jbHVzdGVySWQgPT09IGN1cnJlbnRVc2VyQ2x1c3RlcklkKTtcclxuXHJcbiAgY29uc3QgY3VycmVudFBhbmNoYXlhdCA9IGRpc3BsYXlQYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IHNlbGVjdGVkUGFuY2hheWF0SWQpIHx8IGRpc3BsYXlQYW5jaGF5YXRzWzBdIHx8IHBhbmNoYXlhdHNbMF07XHJcbiAgY29uc3QgcGVuZGluZ0FwcHJvdmFsc0NvdW50ID0gZGlzcGxheUFwcHJvdmFscy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSAnUGVuZGluZycpLmxlbmd0aDtcclxuICBjb25zdCBwZW5kaW5nQ291bnQgPSBub3RpZmljYXRpb25zLmZpbHRlcigobikgPT4gIW4uaXNSZWFkKS5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IGN1cnJlbnRDbHVzdGVyT2JqID0gY2x1c3RlcnMuZmluZCgoYykgPT4gYy5pZCA9PT0gY3VycmVudFVzZXJDbHVzdGVySWQpIHx8IGNsdXN0ZXJzWzBdO1xyXG4gIGNvbnN0IGFjdGl2ZUNsdXN0ZXJOYW1lID0gY3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nID8gJ0FsbCBDbHVzdGVycyAoVGFtaWwgTmFkdSknIDogKGN1cnJlbnRDbHVzdGVyT2JqPy5uYW1lIHx8ICdEaGFybWFwdXJpIENsdXN0ZXInKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIHctZnVsbCBtYXgtdy1mdWxsIG92ZXJmbG93LXgtaGlkZGVuIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTk1MCBmb250LW91dGZpdFwiPlxyXG4gICAgICB7LyogTmF2aWdhdGlvbiAoZml4ZWQgc2lkZWJhciBvbiBkZXNrdG9wLCBzbGlkZS1pbiBkcmF3ZXIgb24gbW9iaWxlKSAqL31cclxuICAgICAgPE5hdmlnYXRpb25cclxuICAgICAgICBjdXJyZW50VGFiPXtjdXJyZW50VGFifVxyXG4gICAgICAgIG9uU2VsZWN0VGFiPXsodGFiKSA9PiB7XHJcbiAgICAgICAgICBpZiAodGFiID09PSAnYXR0ZW5kYW5jZScpIHNldEFjdGl2ZURyYWZ0SWQodW5kZWZpbmVkKTtcclxuICAgICAgICAgIGlmICh0YWIgPT09ICdzdHVkZW50cycpIHNldEluaXRpYWxTdHVkZW50RmlsdGVycyh1bmRlZmluZWQpO1xyXG4gICAgICAgICAgc2V0Q3VycmVudFRhYih0YWIgYXMgVGFiVHlwZSk7XHJcbiAgICAgICAgICBzZXRNb2JpbGVTaWRlYmFyT3BlbihmYWxzZSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBub3RpZmljYXRpb25zPXtub3RpZmljYXRpb25zfVxyXG4gICAgICAgIHVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgY2x1c3Rlck5hbWU9e2FjdGl2ZUNsdXN0ZXJOYW1lfVxyXG4gICAgICAgIGFkbWluTmFtZT17Y3VycmVudFVzZXIubmFtZX1cclxuICAgICAgICB1c2VyRW1haWw9e2N1cnJlbnRVc2VyLmVtYWlsfVxyXG4gICAgICAgIHBlbmRpbmdBcHByb3ZhbHNDb3VudD17cGVuZGluZ0FwcHJvdmFsc0NvdW50fVxyXG4gICAgICAgIGlzQ29sbGFwc2VkPXtzaWRlYmFyQ29sbGFwc2VkfVxyXG4gICAgICAgIG9uVG9nZ2xlQ29sbGFwc2U9eygpID0+IHNldFNpZGViYXJDb2xsYXBzZWQoKHByZXYpID0+ICFwcmV2KX1cclxuICAgICAgICBvbkxvZ291dD17aGFuZGxlTG9nb3V0fVxyXG4gICAgICAgIGlzTW9iaWxlT3Blbj17bW9iaWxlU2lkZWJhck9wZW59XHJcbiAgICAgICAgb25DbG9zZU1vYmlsZT17KCkgPT4gc2V0TW9iaWxlU2lkZWJhck9wZW4oZmFsc2UpfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgey8qIE1haW4gY29udGVudCB3aXRoIG9mZnNldCBmb3IgZml4ZWQgc2lkZWJhciBvbiBkZXNrdG9wICovfVxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIGZsZXggZmxleC1jb2wgbWluLXctMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgJHtcclxuICAgICAgICAgIHNpZGViYXJDb2xsYXBzZWQgPyAnbGc6bWwtWzkwcHhdJyA6ICdsZzptbC1bMjkwcHhdJ1xyXG4gICAgICAgIH1gfVxyXG4gICAgICA+XHJcbiAgICAgICAgey8qIFRhaWxBZG1pbiBUb3AgSGVhZGVyICovfVxyXG4gICAgICAgIDxIZWFkZXJcclxuICAgICAgICAgIHVzZXJFbWFpbD17Y3VycmVudFVzZXIuZW1haWx9XHJcbiAgICAgICAgICB1c2VyTmFtZT17Y3VycmVudFVzZXIubmFtZX1cclxuICAgICAgICAgIHVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgICBjbHVzdGVycz17Y2x1c3RlcnN9XHJcbiAgICAgICAgICBzZWxlY3RlZENsdXN0ZXJJZD17Y3VycmVudFVzZXJDbHVzdGVySWR9XHJcbiAgICAgICAgICBvblNlbGVjdENsdXN0ZXI9eyhjaWQpID0+IHNldEN1cnJlbnRVc2VyQ2x1c3RlcklkKGNpZCl9XHJcbiAgICAgICAgICBub3RpZmljYXRpb25zPXtub3RpZmljYXRpb25zfVxyXG4gICAgICAgICAgcGVuZGluZ0FwcHJvdmFsc0NvdW50PXtwZW5kaW5nQXBwcm92YWxzQ291bnR9XHJcbiAgICAgICAgICBvbk5hdmlnYXRlPXsodGFiLCB0YXJnZXRJZCkgPT4ge1xyXG4gICAgICAgICAgICBoYW5kbGVOYXZpZ2F0ZSh0YWIsIHRhcmdldElkKTtcclxuICAgICAgICAgICAgc2V0TW9iaWxlU2lkZWJhck9wZW4oZmFsc2UpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIG9uTG9nb3V0PXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICBvblJvbGVDaGFuZ2U9eyhyb2xlKSA9PiBoYW5kbGVSb2xlQ2hhbmdlKHJvbGUsIGN1cnJlbnRVc2VyQ2x1c3RlcklkKX1cclxuICAgICAgICAgIG9uVG9nZ2xlU2lkZWJhcj17KCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAod2luZG93LmlubmVyV2lkdGggPCAxMDI0KSB7XHJcbiAgICAgICAgICAgICAgc2V0TW9iaWxlU2lkZWJhck9wZW4oKHByZXYpID0+ICFwcmV2KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICBzZXRTaWRlYmFyQ29sbGFwc2VkKChwcmV2KSA9PiAhcHJldik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHctZnVsbCBtYXgtdy1mdWxsIG92ZXJmbG93LXgtaGlkZGVuXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBwLTQgbWQ6cC02IGxnOnAtOFwiPlxyXG4gICAgICAgICAgICA8RXJyb3JCb3VuZGFyeSBrZXk9e2Ake2N1cnJlbnRUYWJ9LSR7Y3VycmVudFVzZXJSb2xlfWB9PlxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ2Rhc2hib2FyZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPERhc2hib2FyZFZpZXdcclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17aGFuZGxlTmF2aWdhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uT3Blbk5ld1Nlc3Npb249eygpID0+IHNldEN1cnJlbnRUYWIoJ3Nlc3Npb25zJyl9XHJcbiAgICAgICAgICAgICAgICAgIG9uT3Blbk5ld0ZpbmFuY2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50VGFiKCdmaW5hbmNlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0T3Blbk5ld0ZpbmFuY2VNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgb25PcGVuTmV3QXR0ZW5kYW5jZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZURyYWZ0SWQodW5kZWZpbmVkKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50VGFiKCdhdHRlbmRhbmNlJyk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIHBhbmNoYXlhdHM9e2Rpc3BsYXlQYW5jaGF5YXRzfVxyXG4gICAgICAgICAgICAgICAgICBzdHVkZW50c0NvdW50PXtkaXNwbGF5U3R1ZGVudHMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICB2b2x1bnRlZXJzQ291bnQ9e2Rpc3BsYXlWb2x1bnRlZXJzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbnNDb3VudD17ZGlzcGxheVNlc3Npb25zLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgcGVuZGluZ0NvdW50PXtwZW5kaW5nQ291bnR9XHJcbiAgICAgICAgICAgICAgICAgIGF0dGVuZGFuY2VEcmFmdHM9e2Rpc3BsYXlBdHRlbmRhbmNlfVxyXG4gICAgICAgICAgICAgICAgICB1c2VyUm9sZT17Y3VycmVudFVzZXJSb2xlfVxyXG4gICAgICAgICAgICAgICAgICBjbHVzdGVycz17Y2x1c3RlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGFwcHJvdmFscz17ZGlzcGxheUFwcHJvdmFsc31cclxuICAgICAgICAgICAgICAgICAgY2x1c3Rlck5hbWU9e2FjdGl2ZUNsdXN0ZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICBmaW5hbmNlRW50cmllcz17ZGlzcGxheUZpbmFuY2V9XHJcbiAgICAgICAgICAgICAgICAgIHNlc3Npb25zPXtkaXNwbGF5U2Vzc2lvbnN9XHJcbiAgICAgICAgICAgICAgICAgIHN0dWRlbnRzPXtkaXNwbGF5U3R1ZGVudHN9XHJcbiAgICAgICAgICAgICAgICAgIHZvbHVudGVlcnM9e2Rpc3BsYXlWb2x1bnRlZXJzfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ2FjYWRlbWljLXNldHVwJyAmJiBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbicgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEFjYWRlbWljU2V0dXBWaWV3XHJcbiAgICAgICAgICAgICAgICAgIGF1dGhUb2tlbj17Y3VycmVudFVzZXIudG9rZW59XHJcbiAgICAgICAgICAgICAgICAgIG9uU2V0dXBTYXZlZD17KCkgPT4gZmV0Y2hCYWNrZW5kRGF0YShuZXcgQWJvcnRDb250cm9sbGVyKCkuc2lnbmFsKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdhcHByb3ZhbHMnICYmIChcclxuICAgICAgICAgICAgICAgIDxBcHByb3ZhbENlbnRlclZpZXdcclxuICAgICAgICAgICAgICAgICAgYXBwcm92YWxzPXtkaXNwbGF5QXBwcm92YWxzfVxyXG4gICAgICAgICAgICAgICAgICBjbHVzdGVycz17Y2x1c3RlcnN9XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQXBwcm92ZT17aGFuZGxlQXBwcm92ZVN1Ym1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgIG9uUmVxdWVzdENvcnJlY3Rpb249e2hhbmRsZVJlcXVlc3RDb3JyZWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICBvblJlamVjdD17aGFuZGxlUmVqZWN0U3VibWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17aGFuZGxlTmF2aWdhdGV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnY2x1c3RlcnMnICYmIChcclxuICAgICAgICAgICAgICAgIDxDbHVzdGVyc1ZpZXdcclxuICAgICAgICAgICAgICAgICAgY2x1c3RlcnM9e2NsdXN0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICB1c2VyUm9sZT17Y3VycmVudFVzZXJSb2xlfVxyXG4gICAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtoYW5kbGVOYXZpZ2F0ZX1cclxuICAgICAgICAgICAgICAgICAgb25BZGRDbHVzdGVyPXtoYW5kbGVBZGRDbHVzdGVyfVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZUNsdXN0ZXI9e2hhbmRsZURlbGV0ZUNsdXN0ZXJ9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnYXVkaXQtbG9ncycgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEF1ZGl0TG9nVmlld1xyXG4gICAgICAgICAgICAgICAgICBhdWRpdExvZ3M9e2Rpc3BsYXlBdWRpdExvZ3N9XHJcbiAgICAgICAgICAgICAgICAgIHVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAndXNlcnMnICYmIChcclxuICAgICAgICAgICAgICAgIDxVc2VyTWFuYWdlbWVudFZpZXdcclxuICAgICAgICAgICAgICAgICAgdXNlcnM9e3VzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjbHVzdGVycz17Y2x1c3RlcnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQWRkVXNlcj17aGFuZGxlQWRkVXNlcn1cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVVc2VyPXtoYW5kbGVVcGRhdGVVc2VyfVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZVVzZXI9e2hhbmRsZURlbGV0ZVVzZXJ9XHJcbiAgICAgICAgICAgICAgICAgIG9uUmVzZXRQYXNzd29yZD17aGFuZGxlUmVzZXRQYXNzd29yZH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdwYW5jaGF5YXRzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8UGFuY2hheWF0c1ZpZXdcclxuICAgICAgICAgICAgICAgICAgcGFuY2hheWF0cz17ZGlzcGxheVBhbmNoYXlhdHN9XHJcbiAgICAgICAgICAgICAgICAgIG9uU2VsZWN0UGFuY2hheWF0PXsoaWQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdElkKGlkKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50VGFiKCdwYW5jaGF5YXQtZGV0YWlsJyk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIG9uQWRkUGFuY2hheWF0PXtoYW5kbGVBZGRQYW5jaGF5YXR9XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ3BhbmNoYXlhdC1kZXRhaWwnICYmIChcclxuICAgICAgICAgICAgICAgIDxQYW5jaGF5YXREZXRhaWxWaWV3XHJcbiAgICAgICAgICAgICAgICAgIHBhbmNoYXlhdD17Y3VycmVudFBhbmNoYXlhdH1cclxuICAgICAgICAgICAgICAgICAgc3R1ZGVudHM9e2Rpc3BsYXlTdHVkZW50c31cclxuICAgICAgICAgICAgICAgICAgb25CYWNrPXsoKSA9PiBzZXRDdXJyZW50VGFiKCdwYW5jaGF5YXRzJyl9XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkFkZFZpbGxhZ2U9e2hhbmRsZUFkZFZpbGxhZ2V9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnc3R1ZGVudHMnICYmIChcclxuICAgICAgICAgICAgICAgIDxTdHVkZW50c1ZpZXdcclxuICAgICAgICAgICAgICAgICAgc3R1ZGVudHM9e2Rpc3BsYXlTdHVkZW50c31cclxuICAgICAgICAgICAgICAgICAgcGFuY2hheWF0cz17ZGlzcGxheVBhbmNoYXlhdHN9XHJcbiAgICAgICAgICAgICAgICAgIGluaXRpYWxGaWx0ZXJzPXtpbml0aWFsU3R1ZGVudEZpbHRlcnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uQWRkU3R1ZGVudD17aGFuZGxlQWRkU3R1ZGVudH1cclxuICAgICAgICAgICAgICAgICAgb25CdWxrSW1wb3J0U3R1ZGVudHM9e2hhbmRsZUJ1bGtBZGRTdHVkZW50c31cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVTdHVkZW50PXtoYW5kbGVVcGRhdGVTdHVkZW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZVN0dWRlbnQ9e2hhbmRsZURlbGV0ZVN0dWRlbnR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAndm9sdW50ZWVycycgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFZvbHVudGVlcnNWaWV3XHJcbiAgICAgICAgICAgICAgICAgIHZvbHVudGVlcnM9e2Rpc3BsYXlWb2x1bnRlZXJzfVxyXG4gICAgICAgICAgICAgICAgICBwYW5jaGF5YXRzPXtkaXNwbGF5UGFuY2hheWF0c31cclxuICAgICAgICAgICAgICAgICAgb25BZGRWb2x1bnRlZXI9e2hhbmRsZUFkZFZvbHVudGVlcn1cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVWb2x1bnRlZXI9e2hhbmRsZVVwZGF0ZVZvbHVudGVlcn1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGVWb2x1bnRlZXI9e2hhbmRsZURlbGV0ZVZvbHVudGVlcn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdzZXNzaW9ucycgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFNlc3Npb25zVmlld1xyXG4gICAgICAgICAgICAgICAgICBzZXNzaW9ucz17ZGlzcGxheVNlc3Npb25zfVxyXG4gICAgICAgICAgICAgICAgICBwYW5jaGF5YXRzPXtkaXNwbGF5UGFuY2hheWF0c31cclxuICAgICAgICAgICAgICAgICAgdm9sdW50ZWVycz17ZGlzcGxheVZvbHVudGVlcnN9XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkFkZFNlc3Npb249e2hhbmRsZUFkZFNlc3Npb259XHJcbiAgICAgICAgICAgICAgICAgIG9uVXBkYXRlU2Vzc2lvbj17aGFuZGxlVXBkYXRlU2Vzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGVTZXNzaW9uPXtoYW5kbGVEZWxldGVTZXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICBjYW5NYW5hZ2VTY2hlZHVsZT17Y3VycmVudFVzZXJSb2xlID09PSAnQ2x1c3RlciBBZG1pbid9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnYXR0ZW5kYW5jZScgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEF0dGVuZGFuY2VWaWV3XHJcbiAgICAgICAgICAgICAgICAgIGF0dGVuZGFuY2VTZXNzaW9ucz17ZGlzcGxheUF0dGVuZGFuY2V9XHJcbiAgICAgICAgICAgICAgICAgIHN0dWRlbnRzPXtkaXNwbGF5U3R1ZGVudHN9XHJcbiAgICAgICAgICAgICAgICAgIHBhbmNoYXlhdHM9e2Rpc3BsYXlQYW5jaGF5YXRzfVxyXG4gICAgICAgICAgICAgICAgICBkcmFmdElkPXthY3RpdmVEcmFmdElkfVxyXG4gICAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtoYW5kbGVOYXZpZ2F0ZX1cclxuICAgICAgICAgICAgICAgICAgb25TYXZlQXR0ZW5kYW5jZT17aGFuZGxlU2F2ZUF0dGVuZGFuY2V9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnbGVzc29uLXBsYW4nICYmIChcclxuICAgICAgICAgICAgICAgIDxMZXNzb25QbGFuVmlld1xyXG4gICAgICAgICAgICAgICAgICBsZXNzb25QbGFucz17ZGlzcGxheUxlc3NvblBsYW5zfVxyXG4gICAgICAgICAgICAgICAgICBzZXNzaW9ucz17ZGlzcGxheVNlc3Npb25zfVxyXG4gICAgICAgICAgICAgICAgICBwYW5jaGF5YXRzPXtkaXNwbGF5UGFuY2hheWF0c31cclxuICAgICAgICAgICAgICAgICAgdm9sdW50ZWVycz17ZGlzcGxheVZvbHVudGVlcnN9XHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkTGVzc29uUGxhbklkPXtzZWxlY3RlZExlc3NvblBsYW5JZH1cclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17aGFuZGxlTmF2aWdhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQWRkTGVzc29uUGxhbj17aGFuZGxlQWRkTGVzc29uUGxhbn1cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVMZXNzb25QbGFuPXtoYW5kbGVVcGRhdGVMZXNzb25QbGFufVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZUxlc3NvblBsYW49e2hhbmRsZURlbGV0ZUxlc3NvblBsYW59XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnc2Vzc2lvbi1waG90b3MnICYmIChcclxuICAgICAgICAgICAgICAgIDxTZXNzaW9uUGhvdG9zVmlld1xyXG4gICAgICAgICAgICAgICAgICBwYW5jaGF5YXRzPXtkaXNwbGF5UGFuY2hheWF0c31cclxuICAgICAgICAgICAgICAgICAgY2x1c3RlcnM9e2NsdXN0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICBhdXRoVG9rZW49e2N1cnJlbnRVc2VyLnRva2VufVxyXG4gICAgICAgICAgICAgICAgICB1c2VyUm9sZT17Y3VycmVudFVzZXJSb2xlfVxyXG4gICAgICAgICAgICAgICAgICBjdXJyZW50Q2x1c3Rlcj17Y3VycmVudFVzZXJDbHVzdGVySWQgPT09ICdhbGwnID8gJ0RoYXJtYXB1cmknIDogY3VycmVudFVzZXJDbHVzdGVySWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ2ZpbmFuY2UnICYmIChcclxuICAgICAgICAgICAgICAgIDxGaW5hbmNlVmlld1xyXG4gICAgICAgICAgICAgICAgICBmaW5hbmNlRW50cmllcz17ZGlzcGxheUZpbmFuY2V9XHJcbiAgICAgICAgICAgICAgICAgIHBhbmNoYXlhdHM9e2Rpc3BsYXlQYW5jaGF5YXRzfVxyXG4gICAgICAgICAgICAgICAgICBzZXNzaW9ucz17c2Vzc2lvbnN9XHJcbiAgICAgICAgICAgICAgICAgIGRyYWZ0cz17ZGlzcGxheUZpbmFuY2VEcmFmdHN9XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGU9e2hhbmRsZU5hdmlnYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkFkZEZpbmFuY2VFbnRyeT17aGFuZGxlQWRkRmluYW5jZUVudHJ5fVxyXG4gICAgICAgICAgICAgICAgICBvblVwZGF0ZUZpbmFuY2VFbnRyeT17aGFuZGxlVXBkYXRlRmluYW5jZUVudHJ5fVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZUZpbmFuY2VFbnRyeT17aGFuZGxlRGVsZXRlRmluYW5jZUVudHJ5fVxyXG4gICAgICAgICAgICAgICAgICBvblNhdmVEcmFmdD17aGFuZGxlU2F2ZUZpbmFuY2VEcmFmdH1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGVEcmFmdD17aGFuZGxlRGVsZXRlRmluYW5jZURyYWZ0fVxyXG4gICAgICAgICAgICAgICAgICBvblN1Ym1pdERyYWZ0PXtoYW5kbGVTdWJtaXRGaW5hbmNlRHJhZnR9XHJcbiAgICAgICAgICAgICAgICAgIGlzT3Blbk5ld01vZGFsPXtvcGVuTmV3RmluYW5jZU1vZGFsfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsb3NlTmV3TW9kYWw9eygpID0+IHNldE9wZW5OZXdGaW5hbmNlTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ2ZpbmFuY2Utc3RhdGVtZW50JyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8RmluYW5jZVN0YXRlbWVudFZpZXdcclxuICAgICAgICAgICAgICAgICAgZW50cmllcz17ZGlzcGxheUZpbmFuY2V9XHJcbiAgICAgICAgICAgICAgICAgIGRyYWZ0cz17ZGlzcGxheUZpbmFuY2VEcmFmdHN9XHJcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZURyYWZ0SWQ9e2FjdGl2ZUZpbmFuY2VEcmFmdElkfVxyXG4gICAgICAgICAgICAgICAgICBvbkJhY2s9eygpID0+IHNldEN1cnJlbnRUYWIoJ2ZpbmFuY2UnKX1cclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17aGFuZGxlTmF2aWdhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uU2F2ZURyYWZ0PXtoYW5kbGVTYXZlRmluYW5jZURyYWZ0fVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZURyYWZ0PXtoYW5kbGVEZWxldGVGaW5hbmNlRHJhZnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uU3VibWl0RHJhZnQ9e2hhbmRsZVN1Ym1pdEZpbmFuY2VEcmFmdH1cclxuICAgICAgICAgICAgICAgICAgb25BZGRGaW5hbmNlRW50cnk9e2hhbmRsZUFkZEZpbmFuY2VFbnRyeX1cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVGaW5hbmNlRW50cnk9e2hhbmRsZVVwZGF0ZUZpbmFuY2VFbnRyeX1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGVGaW5hbmNlRW50cnk9e2hhbmRsZURlbGV0ZUZpbmFuY2VFbnRyeX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdyZXBvcnRzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8UmVwb3J0c1ZpZXdcclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbnM9e2Rpc3BsYXlTZXNzaW9uc31cclxuICAgICAgICAgICAgICAgICAgbGVzc29uUGxhbnM9e2Rpc3BsYXlMZXNzb25QbGFuc31cclxuICAgICAgICAgICAgICAgICAgcGFuY2hheWF0cz17ZGlzcGxheVBhbmNoYXlhdHN9XHJcbiAgICAgICAgICAgICAgICAgIHZvbHVudGVlcnM9e2Rpc3BsYXlWb2x1bnRlZXJzfVxyXG4gICAgICAgICAgICAgICAgICBzdHVkZW50cz17ZGlzcGxheVN0dWRlbnRzfVxyXG4gICAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtoYW5kbGVOYXZpZ2F0ZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdyZXBvcnQtcHJldmlldycgJiYgKFxyXG4gICAgICAgICAgICAgICAgPFJlcG9ydFByZXZpZXdWaWV3XHJcbiAgICAgICAgICAgICAgICAgIG9uQmFjaz17KCkgPT4gc2V0Q3VycmVudFRhYigncmVwb3J0cycpfVxyXG4gICAgICAgICAgICAgICAgICBvbk5hdmlnYXRlPXtoYW5kbGVOYXZpZ2F0ZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdub3RpZmljYXRpb25zJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Tm90aWZpY2F0aW9uc1ZpZXdcclxuICAgICAgICAgICAgICAgICAgbm90aWZpY2F0aW9ucz17bm90aWZpY2F0aW9uc31cclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17aGFuZGxlTmF2aWdhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uTWFya0FzUmVhZD17aGFuZGxlTWFya0FzUmVhZH1cclxuICAgICAgICAgICAgICAgICAgb25NYXJrQWxsQXNSZWFkPXtoYW5kbGVNYXJrQWxsQXNSZWFkfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ3NldHRpbmdzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U2V0dGluZ3NWaWV3XHJcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyPXtjdXJyZW50VXNlcn1cclxuICAgICAgICAgICAgICAgICAgb25VcGRhdGVQcm9maWxlPXsodXBkYXRlZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRVc2VyKChwcmV2KSA9PiAocHJldiA/IHsgLi4ucHJldiwgLi4udXBkYXRlZCB9IDogcHJldikpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ2RhdGUtY2hhbmdlLXJlcXVlc3RzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8RGF0ZUNoYW5nZVJlcXVlc3RWaWV3XHJcbiAgICAgICAgICAgICAgICAgIGRhdGVDaGFuZ2VSZXF1ZXN0cz17ZGlzcGxheURhdGVDaGFuZ2VSZXF1ZXN0c31cclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbnM9e2Rpc3BsYXlTZXNzaW9uc31cclxuICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VySWQ9e2N1cnJlbnRVc2VyLmlkIHx8ICcnfVxyXG4gICAgICAgICAgICAgICAgICBjdXJyZW50VXNlckNsdXN0ZXJJZD17Y3VycmVudFVzZXJDbHVzdGVySWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uU3VibWl0UmVxdWVzdD17aGFuZGxlU3VibWl0RGF0ZUNoYW5nZVJlcXVlc3R9XHJcbiAgICAgICAgICAgICAgICAgIG9uUmV2aWV3UmVxdWVzdD17aGFuZGxlUmV2aWV3RGF0ZUNoYW5nZVJlcXVlc3R9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtjdXJyZW50VGFiID09PSAnc2Vzc2lvbi1yZXBvcnRzJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U2Vzc2lvblJlcG9ydFZpZXdcclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvblJlcG9ydHM9e2Rpc3BsYXlTZXNzaW9uUmVwb3J0c31cclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbnM9e2Rpc3BsYXlTZXNzaW9uc31cclxuICAgICAgICAgICAgICAgICAgY2x1c3RlcnM9e2NsdXN0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjdXJyZW50VXNlclJvbGU9e2N1cnJlbnRVc2VyUm9sZX1cclxuICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJDbHVzdGVySWQ9e2N1cnJlbnRVc2VyQ2x1c3RlcklkfVxyXG4gICAgICAgICAgICAgICAgICBvblNhdmVSZXBvcnQ9e2hhbmRsZVNhdmVTZXNzaW9uUmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZVJlcG9ydD17aGFuZGxlRGVsZXRlU2Vzc2lvblJlcG9ydH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYWIgPT09ICdzZXNzaW9uLXN1Ym1pc3Npb25zJyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8U2Vzc2lvblN1Ym1pc3Npb25WaWV3XHJcbiAgICAgICAgICAgICAgICAgIHNlc3Npb25TdWJtaXNzaW9ucz17ZGlzcGxheVNlc3Npb25TdWJtaXNzaW9uc31cclxuICAgICAgICAgICAgICAgICAgc2Vzc2lvbnM9e2Rpc3BsYXlTZXNzaW9uc31cclxuICAgICAgICAgICAgICAgICAgY2x1c3RlcnM9e2NsdXN0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjdXJyZW50VXNlclJvbGU9e2N1cnJlbnRVc2VyUm9sZX1cclxuICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJJZD17Y3VycmVudFVzZXIuaWQgfHwgJyd9XHJcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyQ2x1c3RlcklkPXtjdXJyZW50VXNlckNsdXN0ZXJJZH1cclxuICAgICAgICAgICAgICAgICAgb25TdWJtaXRTZXNzaW9uPXtoYW5kbGVTdWJtaXRTZXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICBvblJldmlld1N1Ym1pc3Npb249e2hhbmRsZVJldmlld1N1Ym1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgIG9uUmVzdWJtaXQ9e2hhbmRsZVJlc3VibWl0U2Vzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgb25OYXZpZ2F0ZVRvVGFiPXsodGFiKSA9PiBzZXRDdXJyZW50VGFiKHRhYiBhcyBUYWJUeXBlKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhYiA9PT0gJ21vZHVsZS1saWJyYXJ5JyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8TW9kdWxlTGlicmFyeVZpZXdcclxuICAgICAgICAgICAgICAgICAgbW9kdWxlcz17bW9kdWxlc31cclxuICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJSb2xlPXtjdXJyZW50VXNlclJvbGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ3JlYXRlTW9kdWxlPXtoYW5kbGVDcmVhdGVNb2R1bGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uVXBkYXRlTW9kdWxlPXtoYW5kbGVVcGRhdGVNb2R1bGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uRGVsZXRlTW9kdWxlPXtoYW5kbGVEZWxldGVNb2R1bGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uVXBsb2FkUmVzb3VyY2U9e2hhbmRsZVVwbG9hZE1vZHVsZVJlc291cmNlfVxyXG4gICAgICAgICAgICAgICAgICBvbkRvd25sb2FkUmVzb3VyY2U9e2hhbmRsZURvd25sb2FkTW9kdWxlUmVzb3VyY2V9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5cclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9BcHAudHN4In0=