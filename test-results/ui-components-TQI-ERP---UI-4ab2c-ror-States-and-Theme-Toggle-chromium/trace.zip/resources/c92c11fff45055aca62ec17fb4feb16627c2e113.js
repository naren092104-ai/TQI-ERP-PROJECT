import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\ui\\table.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport1_react);
import { cn } from "/src/lib/utils.ts";
const Table = React.forwardRef(
  _c = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("div", { className: "relative w-full overflow-auto", children: /* @__PURE__ */ jsxDEV("table", { ref, className: cn("w-full caption-bottom text-sm", className), ...props }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
    lineNumber: 8,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
    lineNumber: 7,
    columnNumber: 1
  }, this)
);
_c2 = Table;
Table.displayName = "Table";
const TableHeader = React.forwardRef(_c3 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("thead", { ref, className: cn(className), ...props }, void 0, false, {
  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
  lineNumber: 17,
  columnNumber: 35
}, this));
_c4 = TableHeader;
TableHeader.displayName = "TableHeader";
const TableBody = React.forwardRef(
  _c5 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("tbody", { ref, className: cn("[&_tr:last-child]:border-0", className), ...props }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
    lineNumber: 24,
    columnNumber: 1
  }, this)
);
_c6 = TableBody;
TableBody.displayName = "TableBody";
const TableFooter = React.forwardRef(
  _c7 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tfoot",
    {
      ref,
      className: cn(
        "border-t border-border bg-muted/50 font-medium [&>tr]:last:border-b-0",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
      lineNumber: 32,
      columnNumber: 1
    },
    this
  )
);
_c8 = TableFooter;
TableFooter.displayName = "TableFooter";
const TableRow = React.forwardRef(
  _c9 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "tr",
    {
      ref,
      className: cn(
        "border-b border-border transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
      lineNumber: 45,
      columnNumber: 1
    },
    this
  )
);
_c0 = TableRow;
TableRow.displayName = "TableRow";
const TableHead = React.forwardRef(
  _c1 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "th",
    {
      ref,
      className: cn(
        "h-10 px-3 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:w-px [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-0.5",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
      lineNumber: 61,
      columnNumber: 1
    },
    this
  )
);
_c10 = TableHead;
TableHead.displayName = "TableHead";
const TableCell = React.forwardRef(_c11 = ({ className, isHeader, ...props }, ref) => {
  if (isHeader) {
    return /* @__PURE__ */ jsxDEV(
      "th",
      {
        ref,
        className: cn(
          "h-10 px-3 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:w-px [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-0.5",
          className
        ),
        ...props
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
        lineNumber: 82,
        columnNumber: 7
      },
      this
    );
  }
  return /* @__PURE__ */ jsxDEV(
    "td",
    {
      ref,
      className: cn(
        "p-3 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-0.5",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
      lineNumber: 93,
      columnNumber: 5
    },
    this
  );
});
_c12 = TableCell;
TableCell.displayName = "TableCell";
const TableCaption = React.forwardRef(
  _c13 = ({ className, ...props }, ref) => /* @__PURE__ */ jsxDEV("caption", { ref, className: cn("mt-4 text-sm text-muted-foreground", className), ...props }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx",
    lineNumber: 109,
    columnNumber: 1
  }, this)
);
_c14 = TableCaption;
TableCaption.displayName = "TableCaption";
export { Table, TableBody, TableCaption, TableCell, TableFooter, TableHead, TableHeader, TableRow };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "Table$React.forwardRef");
$RefreshReg$(_c2, "Table");
$RefreshReg$(_c3, "TableHeader$React.forwardRef");
$RefreshReg$(_c4, "TableHeader");
$RefreshReg$(_c5, "TableBody$React.forwardRef");
$RefreshReg$(_c6, "TableBody");
$RefreshReg$(_c7, "TableFooter$React.forwardRef");
$RefreshReg$(_c8, "TableFooter");
$RefreshReg$(_c9, "TableRow$React.forwardRef");
$RefreshReg$(_c0, "TableRow");
$RefreshReg$(_c1, "TableHead$React.forwardRef");
$RefreshReg$(_c10, "TableHead");
$RefreshReg$(_c11, "TableCell$React.forwardRef");
$RefreshReg$(_c12, "TableCell");
$RefreshReg$(_c13, "TableCaption$React.forwardRef");
$RefreshReg$(_c14, "TableCaption");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/table.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTixZQUFZQSxXQUFXO0FBRXZCLFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsUUFBUUYsTUFBTUc7QUFBQUEsRUFBb0VDLEtBQ3RGQSxDQUFDLEVBQUVDLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUN4Qix1QkFBQyxTQUFJLFdBQVUsaUNBQ2IsaUNBQUMsV0FBTSxLQUFVLFdBQVdOLEdBQUcsaUNBQWlDSSxTQUFTLEdBQUcsR0FBSUMsU0FBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzRixLQUR4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFFRSxNQU5JTjtBQU9OQSxNQUFNTyxjQUFjO0FBRXBCLE1BQU1DLGNBQWNWLE1BQU1HLFdBR3pCUSxNQUFDQSxDQUFDLEVBQUVOLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUFRLHVCQUFDLFdBQU0sS0FBVSxXQUFXTixHQUFHSSxTQUFTLEdBQUcsR0FBSUMsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFxRCxDQUFHO0FBQUVNLE1BSHhGRjtBQUlOQSxZQUFZRCxjQUFjO0FBRTFCLE1BQU1JLFlBQVliLE1BQU1HO0FBQUFBLEVBR3ZCVyxNQUFDQSxDQUFDLEVBQUVULFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQix1QkFBQyxXQUFNLEtBQVUsV0FBV04sR0FBRyw4QkFBOEJJLFNBQVMsR0FBRyxHQUFJQyxTQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1GO0FBQ3BGO0FBQUVTLE1BTEdGO0FBTU5BLFVBQVVKLGNBQWM7QUFFeEIsTUFBTU8sY0FBY2hCLE1BQU1HO0FBQUFBLEVBR3pCYyxNQUFDQSxDQUFDLEVBQUVaLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdOO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBSTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJQztBQUFBQTtBQUFBQSxJQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1ZO0FBRWI7QUFBRVksTUFaR0Y7QUFhTkEsWUFBWVAsY0FBYztBQUUxQixNQUFNVSxXQUFXbkIsTUFBTUc7QUFBQUEsRUFBMEVpQixNQUMvRkEsQ0FBQyxFQUFFZixXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDeEI7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXTjtBQUFBQSxRQUNUO0FBQUEsUUFDQUk7QUFBQUEsTUFDRjtBQUFBLE1BQ0EsR0FBSUM7QUFBQUE7QUFBQUEsSUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNWTtBQUdoQjtBQUFFZSxNQVhJRjtBQVlOQSxTQUFTVixjQUFjO0FBRXZCLE1BQU1hLFlBQVl0QixNQUFNRztBQUFBQSxFQUd2Qm9CLE1BQUNBLENBQUMsRUFBRWxCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdOO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBSTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJQztBQUFBQTtBQUFBQSxJQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1ZO0FBRWI7QUFBRWtCLE9BWkdGO0FBYU5BLFVBQVViLGNBQWM7QUFNeEIsTUFBTWdCLFlBQVl6QixNQUFNRyxXQUd2QnVCLE9BQUNBLENBQUMsRUFBRXJCLFdBQVdzQixVQUFVLEdBQUdyQixNQUFNLEdBQUdDLFFBQVE7QUFDNUMsTUFBSW9CLFVBQVU7QUFDWixXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsV0FBVzFCO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBSTtBQUFBQSxRQUNGO0FBQUEsUUFDQSxHQUFLQztBQUFBQTtBQUFBQSxNQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1xQjtBQUFBLEVBR3pCO0FBQ0EsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVdMO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBSTtBQUFBQSxNQUNGO0FBQUEsTUFDQSxHQUFJQztBQUFBQTtBQUFBQSxJQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1ZO0FBR2hCLENBQUM7QUFBRXNCLE9BMUJHSDtBQTJCTkEsVUFBVWhCLGNBQWM7QUFFeEIsTUFBTW9CLGVBQWU3QixNQUFNRztBQUFBQSxFQUcxQjJCLE9BQUNBLENBQUMsRUFBRXpCLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUMxQix1QkFBQyxhQUFRLEtBQVUsV0FBV04sR0FBRyxzQ0FBc0NJLFNBQVMsR0FBRyxHQUFJQyxTQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZGO0FBQzlGO0FBQUV5QixPQUxHRjtBQU1OQSxhQUFhcEIsY0FBYztBQUUzQixTQUFTUCxPQUFPVyxXQUFXZ0IsY0FBY0osV0FBV1QsYUFBYU0sV0FBV1osYUFBYVM7QUFBVyxJQUFBZixJQUFBSSxLQUFBRyxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxLQUFBRSxLQUFBQyxNQUFBRSxNQUFBRSxNQUFBRSxNQUFBQztBQUFBLGFBQUEzQixJQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFHLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBRSxNQUFBO0FBQUEsYUFBQUUsTUFBQTtBQUFBLGFBQUFFLE1BQUE7QUFBQSxhQUFBQyxNQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJjbiIsIlRhYmxlIiwiZm9yd2FyZFJlZiIsIl9jIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJyZWYiLCJfYzIiLCJkaXNwbGF5TmFtZSIsIlRhYmxlSGVhZGVyIiwiX2MzIiwiX2M0IiwiVGFibGVCb2R5IiwiX2M1IiwiX2M2IiwiVGFibGVGb290ZXIiLCJfYzciLCJfYzgiLCJUYWJsZVJvdyIsIl9jOSIsIl9jMCIsIlRhYmxlSGVhZCIsIl9jMSIsIl9jMTAiLCJUYWJsZUNlbGwiLCJfYzExIiwiaXNIZWFkZXIiLCJfYzEyIiwiVGFibGVDYXB0aW9uIiwiX2MxMyIsIl9jMTQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuXG5jb25zdCBUYWJsZSA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTFRhYmxlRWxlbWVudCwgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlRWxlbWVudD4+KFxuICAoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG92ZXJmbG93LWF1dG9cIj5cbiAgICAgIDx0YWJsZSByZWY9e3JlZn0gY2xhc3NOYW1lPXtjbihcInctZnVsbCBjYXB0aW9uLWJvdHRvbSB0ZXh0LXNtXCIsIGNsYXNzTmFtZSl9IHsuLi5wcm9wc30gLz5cbiAgICA8L2Rpdj5cbiAgKSxcbik7XG5UYWJsZS5kaXNwbGF5TmFtZSA9IFwiVGFibGVcIjtcblxuY29uc3QgVGFibGVIZWFkZXIgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVTZWN0aW9uRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiA8dGhlYWQgcmVmPXtyZWZ9IGNsYXNzTmFtZT17Y24oY2xhc3NOYW1lKX0gey4uLnByb3BzfSAvPik7XG5UYWJsZUhlYWRlci5kaXNwbGF5TmFtZSA9IFwiVGFibGVIZWFkZXJcIjtcblxuY29uc3QgVGFibGVCb2R5ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dGJvZHkgcmVmPXtyZWZ9IGNsYXNzTmFtZT17Y24oXCJbJl90cjpsYXN0LWNoaWxkXTpib3JkZXItMFwiLCBjbGFzc05hbWUpfSB7Li4ucHJvcHN9IC8+XG4pKTtcblRhYmxlQm9keS5kaXNwbGF5TmFtZSA9IFwiVGFibGVCb2R5XCI7XG5cbmNvbnN0IFRhYmxlRm9vdGVyID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlU2VjdGlvbkVsZW1lbnQsXG4gIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZVNlY3Rpb25FbGVtZW50PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8dGZvb3RcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJib3JkZXItdCBib3JkZXItYm9yZGVyIGJnLW11dGVkLzUwIGZvbnQtbWVkaXVtIFsmPnRyXTpsYXN0OmJvcmRlci1iLTBcIixcbiAgICAgIGNsYXNzTmFtZSxcbiAgICApfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpO1xuVGFibGVGb290ZXIuZGlzcGxheU5hbWUgPSBcIlRhYmxlRm9vdGVyXCI7XG5cbmNvbnN0IFRhYmxlUm93ID0gUmVhY3QuZm9yd2FyZFJlZjxIVE1MVGFibGVSb3dFbGVtZW50LCBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MVGFibGVSb3dFbGVtZW50Pj4oXG4gICh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gICAgPHRyXG4gICAgICByZWY9e3JlZn1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiYm9yZGVyLWIgYm9yZGVyLWJvcmRlciB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1tdXRlZC81MCBkYXRhLVtzdGF0ZT1zZWxlY3RlZF06YmctbXV0ZWRcIixcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApLFxuKTtcblRhYmxlUm93LmRpc3BsYXlOYW1lID0gXCJUYWJsZVJvd1wiO1xuXG5jb25zdCBUYWJsZUhlYWQgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVDZWxsRWxlbWVudCxcbiAgUmVhY3QuVGhIVE1MQXR0cmlidXRlczxIVE1MVGFibGVDZWxsRWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPHRoXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwiaC0xMCBweC0zIHRleHQtbGVmdCBhbGlnbi1taWRkbGUgZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIFsmOmhhcyhbcm9sZT1jaGVja2JveF0pXTp3LXB4IFsmOmhhcyhbcm9sZT1jaGVja2JveF0pXTpwci0wIFsmPltyb2xlPWNoZWNrYm94XV06dHJhbnNsYXRlLXktMC41XCIsXG4gICAgICBjbGFzc05hbWUsXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKTtcblRhYmxlSGVhZC5kaXNwbGF5TmFtZSA9IFwiVGFibGVIZWFkXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGFibGVDZWxsUHJvcHMgZXh0ZW5kcyBSZWFjdC5UZEhUTUxBdHRyaWJ1dGVzPEhUTUxUYWJsZUNlbGxFbGVtZW50PiB7XG4gIGlzSGVhZGVyPzogYm9vbGVhbjtcbn1cblxuY29uc3QgVGFibGVDZWxsID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgSFRNTFRhYmxlQ2VsbEVsZW1lbnQsXG4gIFRhYmxlQ2VsbFByb3BzXG4+KCh7IGNsYXNzTmFtZSwgaXNIZWFkZXIsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xuICBpZiAoaXNIZWFkZXIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPHRoXG4gICAgICAgIHJlZj17cmVmfVxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwiaC0xMCBweC0zIHRleHQtbGVmdCBhbGlnbi1taWRkbGUgZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIFsmOmhhcyhbcm9sZT1jaGVja2JveF0pXTp3LXB4IFsmOmhhcyhbcm9sZT1jaGVja2JveF0pXTpwci0wIFsmPltyb2xlPWNoZWNrYm94XV06dHJhbnNsYXRlLXktMC41XCIsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHsuLi4ocHJvcHMgYXMgYW55KX1cbiAgICAgIC8+XG4gICAgKTtcbiAgfVxuICByZXR1cm4gKFxuICAgIDx0ZFxuICAgICAgcmVmPXtyZWZ9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInAtMyBhbGlnbi1taWRkbGUgWyY6aGFzKFtyb2xlPWNoZWNrYm94XSldOnByLTAgWyY+W3JvbGU9Y2hlY2tib3hdXTp0cmFuc2xhdGUteS0wLjVcIixcbiAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufSk7XG5UYWJsZUNlbGwuZGlzcGxheU5hbWUgPSBcIlRhYmxlQ2VsbFwiO1xuXG5jb25zdCBUYWJsZUNhcHRpb24gPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MVGFibGVDYXB0aW9uRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFRhYmxlQ2FwdGlvbkVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxjYXB0aW9uIHJlZj17cmVmfSBjbGFzc05hbWU9e2NuKFwibXQtNCB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiLCBjbGFzc05hbWUpfSB7Li4ucHJvcHN9IC8+XG4pKTtcblRhYmxlQ2FwdGlvbi5kaXNwbGF5TmFtZSA9IFwiVGFibGVDYXB0aW9uXCI7XG5cbmV4cG9ydCB7IFRhYmxlLCBUYWJsZUJvZHksIFRhYmxlQ2FwdGlvbiwgVGFibGVDZWxsLCBUYWJsZUZvb3RlciwgVGFibGVIZWFkLCBUYWJsZUhlYWRlciwgVGFibGVSb3cgfTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS90YWJsZS50c3gifQ==