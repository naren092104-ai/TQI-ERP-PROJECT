import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ClustersView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import {
  Building2,
  MapPin,
  Users,
  GraduationCap,
  Plus,
  Search,
  ArrowRight,
  X,
  School,
  CheckCircle2,
  AlertCircle,
  Trash2
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import Badge from "/src/components/ui/badge.tsx";
export const ClustersView = ({
  clusters = [],
  userRole = "Super Admin",
  onNavigate,
  onAddCluster,
  onDeleteCluster
}) => {
  _s();
  const isSuperAdmin = !userRole || userRole === "Super Admin" || userRole.toLowerCase().includes("super");
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [clusterToDelete, setClusterToDelete] = useState(null);
  const [newCollegeName, setNewCollegeName] = useState("");
  const [newClusterDistrict, setNewClusterDistrict] = useState("");
  const [newSpocName, setNewSpocName] = useState("");
  const [newSpocMobile, setNewSpocMobile] = useState("");
  const [newSpocEmail, setNewSpocEmail] = useState("");
  const filteredClusters = clusters.filter(
    (c) => (c.name || "").toLowerCase().includes(searchTerm.toLowerCase()) || (c.district || "").toLowerCase().includes(searchTerm.toLowerCase()) || (c.collegeName || "").toLowerCase().includes(searchTerm.toLowerCase()) || (c.spocName || "").toLowerCase().includes(searchTerm.toLowerCase()) || (c.adminName || "").toLowerCase().includes(searchTerm.toLowerCase()) || (c.code || "").toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleCreateCluster = async (e) => {
    e.preventDefault();
    setFormError("");
    if (!newCollegeName.trim() || !newClusterDistrict.trim() || !newSpocName.trim() || !newSpocMobile.trim() || !newSpocEmail.trim()) {
      setFormError("Please fill in all required fields marked with *.");
      return;
    }
    setIsSubmitting(true);
    try {
      if (onAddCluster) {
        const res = await onAddCluster({
          collegeName: newCollegeName.trim(),
          district: newClusterDistrict.trim(),
          name: `${newCollegeName.trim()} (${newClusterDistrict.trim()})`,
          spocName: newSpocName.trim(),
          spocMobile: newSpocMobile.trim(),
          adminName: newSpocName.trim(),
          adminEmail: newSpocEmail.trim().toLowerCase(),
          adminPhone: newSpocMobile.trim(),
          status: "Active"
        });
        if (res === false) {
          setIsSubmitting(false);
          return;
        }
      }
      setIsAddModalOpen(false);
      setNewCollegeName("");
      setNewClusterDistrict("");
      setNewSpocName("");
      setNewSpocMobile("");
      setNewSpocEmail("");
      setFormError("");
    } catch (err) {
      setFormError(err?.message || "Failed to onboard college cluster.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Clusters & College Onboarding" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 116,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            clusters.length,
            " Onboarded"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 119,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Manage partner colleges, district hubs, SPOC coordinators, and regional administrators." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 114,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setIsAddModalOpen(true);
            setFormError("");
          },
          className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-sm font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition shrink-0",
          children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 136,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Onboard New College" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 137,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 128,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Onboarded Colleges" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 145,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(School, { className: "h-5 w-5 text-brand-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 146,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 144,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-900 dark:text-white", children: clusters.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 149,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: "Active" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 150,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 148,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 143,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Panchayats" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 156,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(MapPin, { className: "h-5 w-5 text-success-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 157,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 155,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-900 dark:text-white", children: clusters.reduce((acc, c) => acc + (c.activePanchayats || 0), 0) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 160,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "success", size: "sm", children: "Mapped" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 163,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 159,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 154,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Enrolled Students" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 169,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(GraduationCap, { className: "h-5 w-5 text-theme-purple-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 170,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-900 dark:text-white", children: clusters.reduce((acc, c) => acc + (c.totalStudents || 0), 0) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 173,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "info", size: "sm", children: "Enrolled" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 176,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 172,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 167,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Active Volunteers" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 182,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Users, { className: "h-5 w-5 text-warning-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 183,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 181,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-baseline justify-between", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-900 dark:text-white", children: clusters.reduce((acc, c) => acc + (c.totalVolunteers || 0), 0) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 186,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: "Mentors" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 189,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 185,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 180,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-md", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 197,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          placeholder: "Search by college, district, or SPOC...",
          value: searchTerm,
          onChange: (e) => setSearchTerm(e.target.value),
          className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 198,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 196,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    filteredClusters.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-16 text-center", children: [
      /* @__PURE__ */ jsxDEV(Building2, { className: "mx-auto h-12 w-12 text-gray-300 dark:text-gray-600" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 211,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "mt-3 text-base font-semibold text-gray-800 dark:text-white", children: "No partner colleges found" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 212,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: searchTerm ? "Try adjusting your search terms." : 'Click "Onboard New College" to register a college and assign its SPOC coordinator.' }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 213,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 210,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5", children: filteredClusters.map((cluster) => {
      const completionRate = Math.round(
        (cluster.completedSessions || 0) / (cluster.totalSessions || 48) * 100
      );
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "group rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition-all hover:border-brand-300 dark:border-gray-800 dark:bg-white/[0.02] dark:hover:border-brand-800 flex flex-col justify-between",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white truncate group-hover:text-brand-500 transition-colors", children: cluster.collegeName || cluster.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 233,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(MapPin, { className: "h-3.5 w-3.5 text-gray-400 shrink-0" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 237,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    cluster.district,
                    ", Tamil Nadu"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 238,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 236,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 232,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 231,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1.5 pt-1", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs font-medium text-gray-600 dark:text-gray-400", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Curriculum Progress" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 246,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-brand-500 dark:text-brand-400", children: [
                    completionRate,
                    "% (",
                    cluster.completedSessions || 0,
                    "/",
                    cluster.totalSessions || 48,
                    ")"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 247,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 245,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "h-1.5 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "h-full rounded-full bg-brand-500 transition-all duration-500",
                    style: { width: `${completionRate}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 252,
                    columnNumber: 23
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 251,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 244,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2 rounded-xl bg-gray-50/70 p-2.5 text-center dark:bg-white/[0.02]", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-medium block", children: "Panchayats" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 262,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800 dark:text-white", children: cluster.activePanchayats || 0 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 263,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 261,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-medium block", children: "Students" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 266,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800 dark:text-white", children: cluster.totalStudents || 0 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 267,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 265,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-medium block", children: "Volunteers" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 270,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800 dark:text-white", children: cluster.totalVolunteers || 0 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 271,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 269,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 260,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-gray-100 p-3 space-y-1 text-xs dark:border-gray-800/80", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between font-semibold text-gray-800 dark:text-gray-200", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: cluster.spocName || cluster.adminName || "SPOC Admin" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 278,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-gray-500 dark:text-gray-400 shrink-0", children: cluster.spocMobile || cluster.adminPhone }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                    lineNumber: 279,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 277,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-400 truncate font-mono", children: cluster.adminEmail }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 281,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 276,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 229,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between", children: [
              isSuperAdmin && onDeleteCluster ? /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setClusterToDelete(cluster),
                  className: "inline-flex items-center gap-1 text-xs font-semibold text-error-500 hover:text-error-600 hover:bg-error-50 dark:hover:bg-error-500/10 px-2 py-1 rounded-lg transition-colors",
                  title: "Delete Cluster",
                  children: [
                    /* @__PURE__ */ jsxDEV(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                      lineNumber: 296,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Delete" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                      lineNumber: 297,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 290,
                  columnNumber: 17
                },
                this
              ) : /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 299,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate("panchayats", cluster.id),
                  className: "inline-flex items-center gap-1.5 text-xs font-bold text-brand-500 hover:text-brand-600 dark:text-brand-400 transition-colors",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "View Panchayats & Scope" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                      lineNumber: 305,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                      lineNumber: 306,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 300,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 288,
              columnNumber: 17
            }, this)
          ]
        },
        cluster.id,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 225,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 218,
      columnNumber: 7
    }, this),
    isAddModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900 dark:text-white", children: "Onboard Partner College" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 321,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 mt-0.5", children: "Register institution and provision SPOC cluster admin credentials." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 324,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 320,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setIsAddModalOpen(false),
            className: "inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-white transition",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 333,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 328,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 319,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreateCluster, className: "mt-5 space-y-4 text-xs", children: [
        formError && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-error-200 bg-error-50 p-3 text-xs text-error-600 dark:border-error-900/40 dark:bg-error-500/10 dark:text-error-400 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(AlertCircle, { className: "h-4 w-4 shrink-0" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 340,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: formError }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 341,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 339,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "College / Institution Name *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 347,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                placeholder: "e.g. Government Arts College",
                value: newCollegeName,
                onChange: (e) => setNewCollegeName(e.target.value),
                className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 350,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 346,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "District *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 361,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                placeholder: "e.g. Dharmapuri",
                value: newClusterDistrict,
                onChange: (e) => setNewClusterDistrict(e.target.value),
                className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 364,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 360,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 345,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 dark:border-gray-800 space-y-3", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold uppercase tracking-wider text-brand-500 dark:text-brand-400", children: "College SPOC & Regional Administrator" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1", children: "SPOC Full Name *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 382,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  required: true,
                  placeholder: "e.g. Dr. M. Vignesh",
                  value: newSpocName,
                  onChange: (e) => setNewSpocName(e.target.value),
                  className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 385,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 381,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1", children: "SPOC Mobile Number *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 395,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "tel",
                  required: true,
                  placeholder: "e.g. +91 98765 43210",
                  value: newSpocMobile,
                  onChange: (e) => setNewSpocMobile(e.target.value),
                  className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                  lineNumber: 398,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 394,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 380,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1", children: "SPOC Official Email *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 410,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "email",
                required: true,
                placeholder: "e.g. vignesh.m@gac-dpi.edu.in",
                value: newSpocEmail,
                onChange: (e) => setNewSpocEmail(e.target.value),
                className: "w-full rounded-lg border border-gray-300 bg-transparent px-3.5 py-2 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-800 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
                lineNumber: 413,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 409,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 375,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-blue-light-200 bg-blue-light-50/70 p-3 text-xs text-blue-light-900 dark:border-blue-light-900/40 dark:bg-blue-light-500/10 dark:text-blue-light-300", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "font-semibold flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-blue-light-500 shrink-0" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 426,
              columnNumber: 19
            }, this),
            "Automated Credentials Email"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 425,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-[11px] opacity-90", children: [
            "The SPOC will be provisioned as Regional Cluster Admin. Login credentials will be dispatched to ",
            /* @__PURE__ */ jsxDEV("strong", { children: newSpocEmail || "their email" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 430,
              columnNumber: 115
            }, this),
            "."
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 429,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 424,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              disabled: isSubmitting,
              onClick: () => setIsAddModalOpen(false),
              className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 435,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isSubmitting,
              className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition disabled:opacity-50",
              children: isSubmitting ? "Onboarding College..." : "Onboard College & Send Credentials"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
              lineNumber: 443,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 434,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 337,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 318,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 317,
      columnNumber: 7
    }, this),
    clusterToDelete && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center overflow-y-auto bg-gray-900/75 p-4 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-md rounded-2xl border border-gray-200 bg-white p-6 shadow-theme-xl dark:border-gray-800 dark:bg-gray-900 animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-error-500 mb-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex h-10 w-10 items-center justify-center rounded-xl bg-error-50 dark:bg-error-500/10", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 462,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 461,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Delete Cluster" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 465,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400", children: "This action cannot be undone." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 466,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 464,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 460,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-600 dark:text-gray-300 mb-5 leading-relaxed", children: [
        "Are you sure you want to permanently delete ",
        /* @__PURE__ */ jsxDEV("strong", { children: clusterToDelete.collegeName || clusterToDelete.name }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
          lineNumber: 470,
          columnNumber: 59
        }, this),
        " (",
        clusterToDelete.district,
        ")? Associated local operational mapping will be unassigned."
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 469,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2.5", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setClusterToDelete(null),
            className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 473,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: async () => {
              if (onDeleteCluster && clusterToDelete) {
                await onDeleteCluster(clusterToDelete.id);
                setClusterToDelete(null);
              }
            },
            className: "rounded-xl bg-error-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-error-600 transition",
            children: "Confirm Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
            lineNumber: 480,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
        lineNumber: 472,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 459,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
      lineNumber: 458,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
};
_s(ClustersView, "pXopUit6kBROhzHMKFOEivSenP8=");
_c = ClustersView;
var _c;
$RefreshReg$(_c, "ClustersView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ClustersView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhZOztBQW5IWixTQUFnQkEsZ0JBQWdCO0FBQ2hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFHQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE9BQU9DLFdBQVc7QUFXWCxhQUFNQyxlQUE0Q0EsQ0FBQztBQUFBLEVBQ3hEQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUFBLEVBQ1hDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsZUFBZSxDQUFDTCxZQUFZQSxhQUFhLGlCQUFpQkEsU0FBU00sWUFBWSxFQUFFQyxTQUFTLE9BQU87QUFDdkcsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl6QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUM0QixjQUFjQyxlQUFlLElBQUk3QixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDOEIsV0FBV0MsWUFBWSxJQUFJL0IsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2dDLGlCQUFpQkMsa0JBQWtCLElBQUlqQyxTQUF5QixJQUFJO0FBRTNFLFFBQU0sQ0FBQ2tDLGdCQUFnQkMsaUJBQWlCLElBQUluQyxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDb0Msb0JBQW9CQyxxQkFBcUIsSUFBSXJDLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUNzQyxhQUFhQyxjQUFjLElBQUl2QyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDd0MsZUFBZUMsZ0JBQWdCLElBQUl6QyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDMEMsY0FBY0MsZUFBZSxJQUFJM0MsU0FBUyxFQUFFO0FBRW5ELFFBQU00QyxtQkFBbUI3QixTQUFTOEI7QUFBQUEsSUFDaEMsQ0FBQ0MsT0FDRUEsRUFBRUMsUUFBUSxJQUFJekIsWUFBWSxFQUFFQyxTQUFTQyxXQUFXRixZQUFZLENBQUMsTUFDN0R3QixFQUFFRSxZQUFZLElBQUkxQixZQUFZLEVBQUVDLFNBQVNDLFdBQVdGLFlBQVksQ0FBQyxNQUNqRXdCLEVBQUVHLGVBQWUsSUFBSTNCLFlBQVksRUFBRUMsU0FBU0MsV0FBV0YsWUFBWSxDQUFDLE1BQ3BFd0IsRUFBRUksWUFBWSxJQUFJNUIsWUFBWSxFQUFFQyxTQUFTQyxXQUFXRixZQUFZLENBQUMsTUFDakV3QixFQUFFSyxhQUFhLElBQUk3QixZQUFZLEVBQUVDLFNBQVNDLFdBQVdGLFlBQVksQ0FBQyxNQUNsRXdCLEVBQUVNLFFBQVEsSUFBSTlCLFlBQVksRUFBRUMsU0FBU0MsV0FBV0YsWUFBWSxDQUFDO0FBQUEsRUFDbEU7QUFFQSxRQUFNK0Isc0JBQXNCLE9BQU9DLE1BQXVCO0FBQ3hEQSxNQUFFQyxlQUFlO0FBQ2pCeEIsaUJBQWEsRUFBRTtBQUVmLFFBQ0UsQ0FBQ0csZUFBZXNCLEtBQUssS0FDckIsQ0FBQ3BCLG1CQUFtQm9CLEtBQUssS0FDekIsQ0FBQ2xCLFlBQVlrQixLQUFLLEtBQ2xCLENBQUNoQixjQUFjZ0IsS0FBSyxLQUNwQixDQUFDZCxhQUFhYyxLQUFLLEdBQ25CO0FBQ0F6QixtQkFBYSxtREFBbUQ7QUFDaEU7QUFBQSxJQUNGO0FBRUFGLG9CQUFnQixJQUFJO0FBQ3BCLFFBQUk7QUFDRixVQUFJWCxjQUFjO0FBQ2hCLGNBQU11QyxNQUFNLE1BQU12QyxhQUFhO0FBQUEsVUFDN0IrQixhQUFhZixlQUFlc0IsS0FBSztBQUFBLFVBQ2pDUixVQUFVWixtQkFBbUJvQixLQUFLO0FBQUEsVUFDbENULE1BQU0sR0FBR2IsZUFBZXNCLEtBQUssQ0FBQyxLQUFLcEIsbUJBQW1Cb0IsS0FBSyxDQUFDO0FBQUEsVUFDNUROLFVBQVVaLFlBQVlrQixLQUFLO0FBQUEsVUFDM0JFLFlBQVlsQixjQUFjZ0IsS0FBSztBQUFBLFVBQy9CTCxXQUFXYixZQUFZa0IsS0FBSztBQUFBLFVBQzVCRyxZQUFZakIsYUFBYWMsS0FBSyxFQUFFbEMsWUFBWTtBQUFBLFVBQzVDc0MsWUFBWXBCLGNBQWNnQixLQUFLO0FBQUEsVUFDL0JLLFFBQVE7QUFBQSxRQUNWLENBQUM7QUFFRCxZQUFJSixRQUFRLE9BQU87QUFDakI1QiwwQkFBZ0IsS0FBSztBQUNyQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUFGLHdCQUFrQixLQUFLO0FBQ3ZCUSx3QkFBa0IsRUFBRTtBQUNwQkUsNEJBQXNCLEVBQUU7QUFDeEJFLHFCQUFlLEVBQUU7QUFDakJFLHVCQUFpQixFQUFFO0FBQ25CRSxzQkFBZ0IsRUFBRTtBQUNsQlosbUJBQWEsRUFBRTtBQUFBLElBQ2pCLFNBQVMrQixLQUFVO0FBQ2pCL0IsbUJBQWErQixLQUFLQyxXQUFXLG9DQUFvQztBQUFBLElBQ25FLFVBQUM7QUFDQ2xDLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDhFQUE0RSw2Q0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QmQ7QUFBQUEscUJBQVNpRDtBQUFBQSxZQUFPO0FBQUEsZUFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQStDLHVHQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUNickMsOEJBQWtCLElBQUk7QUFDdEJJLHlCQUFhLEVBQUU7QUFBQSxVQUNqQjtBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxRQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6Qix1QkFBQyxVQUFLLG1DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUE7QUFBQTtBQUFBLFFBVDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1GQUFrRixrQ0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0g7QUFBQSxVQUNwSCx1QkFBQyxVQUFPLFdBQVUsNEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsYUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsb0RBQW9EaEIsbUJBQVNpRCxVQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLFVBQ3BGLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBSyxzQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxhQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLG1GQUFrRixnQ0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0g7QUFBQSxVQUNsSCx1QkFBQyxVQUFPLFdBQVUsOEJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsYUFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsb0RBQ2JqRCxtQkFBU2tELE9BQU8sQ0FBQ0MsS0FBS3BCLE1BQU1vQixPQUFPcEIsRUFBRXFCLG9CQUFvQixJQUFJLENBQUMsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUFLLHNCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLGFBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLGlDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLFVBQ25ILHVCQUFDLGlCQUFjLFdBQVUsbUNBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsb0RBQ2JwRCxtQkFBU2tELE9BQU8sQ0FBQ0MsS0FBS3BCLE1BQU1vQixPQUFPcEIsRUFBRXNCLGlCQUFpQixJQUFJLENBQUMsS0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFFBQU8sTUFBSyxNQUFLLHdCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLGFBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUZBQWtGLGlDQUFsRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLFVBQ25ILHVCQUFDLFNBQU0sV0FBVSw4QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxhQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxvREFDYnJELG1CQUFTa0QsT0FBTyxDQUFDQyxLQUFLcEIsTUFBTW9CLE9BQU9wQixFQUFFdUIsbUJBQW1CLElBQUksQ0FBQyxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQUssdUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDO0FBQUEsYUFKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0RBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsNkJBQUMsVUFBTyxXQUFVLDBGQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdHO0FBQUEsTUFDeEc7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGFBQVk7QUFBQSxVQUNaLE9BQU83QztBQUFBQSxVQUNQLFVBQVUsQ0FBQzhCLE1BQU03QixjQUFjNkIsRUFBRWdCLE9BQU9DLEtBQUs7QUFBQSxVQUM3QyxXQUFVO0FBQUE7QUFBQSxRQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtxVDtBQUFBLFNBUHZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLElBR0MzQixpQkFBaUJvQixXQUFXLElBQzNCLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDZCQUFDLGFBQVUsV0FBVSx3REFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQseUNBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0c7QUFBQSxNQUNwRyx1QkFBQyxPQUFFLFdBQVUsaURBQ1Z4Qyx1QkFBYSxxQ0FBcUMsd0ZBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLElBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNab0IsMkJBQWlCNEIsSUFBSSxDQUFDQyxZQUFZO0FBQ2pDLFlBQU1DLGlCQUFpQkMsS0FBS0M7QUFBQUEsU0FDeEJILFFBQVFJLHFCQUFxQixNQUFNSixRQUFRSyxpQkFBaUIsTUFBTztBQUFBLE1BQ3ZFO0FBRUEsYUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsMkdBQ1hMLGtCQUFReEIsZUFBZXdCLFFBQVExQixRQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG9FQUNYO0FBQUEseUNBQUMsVUFBTyxXQUFVLHdDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRDtBQUFBLGtCQUN0RCx1QkFBQyxVQUFNMEI7QUFBQUEsNEJBQVF6QjtBQUFBQSxvQkFBUztBQUFBLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLHFCQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLHlDQUFDLFVBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUI7QUFBQSxrQkFDekIsdUJBQUMsVUFBSyxXQUFVLGdEQUNiMEI7QUFBQUE7QUFBQUEsb0JBQWU7QUFBQSxvQkFBSUQsUUFBUUkscUJBQXFCO0FBQUEsb0JBQUU7QUFBQSxvQkFBRUosUUFBUUssaUJBQWlCO0FBQUEsb0JBQUc7QUFBQSx1QkFEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU8sRUFBRUMsT0FBTyxHQUFHTCxjQUFjLElBQUk7QUFBQTtBQUFBLGtCQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXlDLEtBSDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsVUFBSyxXQUFVLCtDQUE4QywwQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0U7QUFBQSxrQkFDeEUsdUJBQUMsVUFBSyxXQUFVLG1EQUFtREQsa0JBQVFOLG9CQUFvQixLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRztBQUFBLHFCQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFVBQUssV0FBVSwrQ0FBOEMsd0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNFO0FBQUEsa0JBQ3RFLHVCQUFDLFVBQUssV0FBVSxtREFBbURNLGtCQUFRTCxpQkFBaUIsS0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEY7QUFBQSxxQkFGaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsK0NBQThDLDBCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RTtBQUFBLGtCQUN4RSx1QkFBQyxVQUFLLFdBQVUsbURBQW1ESyxrQkFBUUosbUJBQW1CLEtBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdHO0FBQUEscUJBRmxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsWUFBWUksa0JBQVF2QixZQUFZdUIsUUFBUXRCLGFBQWEsZ0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtGO0FBQUEsa0JBQ2xGLHVCQUFDLFVBQUssV0FBVSwrREFBK0RzQixrQkFBUWYsY0FBY2UsUUFBUWIsY0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0g7QUFBQSxxQkFGMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxnREFDWmEsa0JBQVFkLGNBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3REE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw2RkFDWnRDO0FBQUFBLDhCQUFnQkYsa0JBQ2Y7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTWMsbUJBQW1Cd0MsT0FBTztBQUFBLGtCQUN6QyxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUVOO0FBQUEsMkNBQUMsVUFBTyxXQUFVLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLG9CQUMvQix1QkFBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVk7QUFBQTtBQUFBO0FBQUEsZ0JBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUUEsSUFDRSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQUk7QUFBQSxjQUNSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU14RCxXQUFXLGNBQWN3RCxRQUFRTyxFQUFFO0FBQUEsa0JBQ2xELFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFVBQUssdUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDN0IsdUJBQUMsY0FBVyxXQUFVLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBO0FBQUE7QUFBQSxnQkFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQTtBQUFBO0FBQUEsUUFsRktQLFFBQVFPO0FBQUFBLFFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW9GQTtBQUFBLElBRUosQ0FBQyxLQTdGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEZBO0FBQUEsSUFJRHRELGtCQUNDLHVCQUFDLFNBQUksV0FBVSxnSEFDYixpQ0FBQyxTQUFJLFdBQVUsa0tBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1EQUFpRCx1Q0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLG1EQUFpRCxrRkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNQyxrQkFBa0IsS0FBSztBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUE7QUFBQSxVQUx4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVMEIscUJBQXFCLFdBQVUsMEJBQzVDdkI7QUFBQUEscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHVLQUNiO0FBQUEsaUNBQUMsZUFBWSxXQUFVLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLFVBQ3pDLHVCQUFDLFVBQU1BLHVCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsYUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0dBQThGLDRDQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPSTtBQUFBQSxnQkFDUCxVQUFVLENBQUNvQixNQUFNbkIsa0JBQWtCbUIsRUFBRWdCLE9BQU9DLEtBQUs7QUFBQSxnQkFDakQsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNd1E7QUFBQSxlQVYxUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdHQUE4RiwwQkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osT0FBT25DO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2tCLE1BQU1qQixzQkFBc0JpQixFQUFFZ0IsT0FBT0MsS0FBSztBQUFBLGdCQUNyRCxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU13UTtBQUFBLGVBVjFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsaUZBQStFLHFEQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLHFFQUFtRSxnQ0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLE9BQU9qQztBQUFBQSxrQkFDUCxVQUFVLENBQUNnQixNQUFNZixlQUFlZSxFQUFFZ0IsT0FBT0MsS0FBSztBQUFBLGtCQUM5QyxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNc1E7QUFBQSxpQkFWeFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxxRUFBbUUsb0NBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixPQUFPL0I7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDYyxNQUFNYixpQkFBaUJhLEVBQUVnQixPQUFPQyxLQUFLO0FBQUEsa0JBQ2hELFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1zUTtBQUFBLGlCQVZ4UTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUVBQW1FLHFDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPN0I7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDWSxNQUFNWCxnQkFBZ0JXLEVBQUVnQixPQUFPQyxLQUFLO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTXNRO0FBQUEsZUFWeFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLGFBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxnTEFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSwyQ0FDWDtBQUFBLG1DQUFDLGdCQUFhLFdBQVUsMENBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThEO0FBQUE7QUFBQSxlQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQTZCO0FBQUE7QUFBQSxZQUN3RCx1QkFBQyxZQUFRN0IsMEJBQWdCLGlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQVM7QUFBQSxlQURsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVZDtBQUFBQSxjQUNWLFNBQVMsTUFBTUQsa0JBQWtCLEtBQUs7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FBcU07QUFBQTtBQUFBLFlBSmpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVUM7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FFVEEseUJBQWUsMEJBQTBCO0FBQUE7QUFBQSxZQUw1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFdBakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrSEE7QUFBQSxTQXJJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0lBLEtBdklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3SUE7QUFBQSxJQUlESSxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0hBQ2IsaUNBQUMsU0FBSSxXQUFVLGtLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLFVBQU8sV0FBVSxhQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxxREFBb0QsOEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsT0FBRSxXQUFVLDRDQUEyQyw2Q0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxhQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLGlFQUErRDtBQUFBO0FBQUEsUUFDOUIsdUJBQUMsWUFBUUEsMEJBQWdCaUIsZUFBZWpCLGdCQUFnQmUsUUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQVM7QUFBQSxRQUFHZixnQkFBZ0JnQjtBQUFBQSxRQUFTO0FBQUEsV0FEaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNZixtQkFBbUIsSUFBSTtBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUFxTTtBQUFBO0FBQUEsVUFIak47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLFlBQVk7QUFDbkIsa0JBQUlkLG1CQUFtQmEsaUJBQWlCO0FBQ3RDLHNCQUFNYixnQkFBZ0JhLGdCQUFnQmdELEVBQUU7QUFDeEMvQyxtQ0FBbUIsSUFBSTtBQUFBLGNBQ3pCO0FBQUEsWUFDRjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQWtIO0FBQUE7QUFBQSxVQVI5SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQS9YSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaVlBO0FBRUo7QUFBRWIsR0FwZFdOLGNBQXlDO0FBQUEsS0FBekNBO0FBQXlDLElBQUFtRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkJ1aWxkaW5nMiIsIk1hcFBpbiIsIlVzZXJzIiwiR3JhZHVhdGlvbkNhcCIsIlBsdXMiLCJTZWFyY2giLCJBcnJvd1JpZ2h0IiwiWCIsIlNjaG9vbCIsIkNoZWNrQ2lyY2xlMiIsIkFsZXJ0Q2lyY2xlIiwiVHJhc2gyIiwiQmFkZ2UiLCJDbHVzdGVyc1ZpZXciLCJjbHVzdGVycyIsInVzZXJSb2xlIiwib25OYXZpZ2F0ZSIsIm9uQWRkQ2x1c3RlciIsIm9uRGVsZXRlQ2x1c3RlciIsIl9zIiwiaXNTdXBlckFkbWluIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwiaXNBZGRNb2RhbE9wZW4iLCJzZXRJc0FkZE1vZGFsT3BlbiIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImZvcm1FcnJvciIsInNldEZvcm1FcnJvciIsImNsdXN0ZXJUb0RlbGV0ZSIsInNldENsdXN0ZXJUb0RlbGV0ZSIsIm5ld0NvbGxlZ2VOYW1lIiwic2V0TmV3Q29sbGVnZU5hbWUiLCJuZXdDbHVzdGVyRGlzdHJpY3QiLCJzZXROZXdDbHVzdGVyRGlzdHJpY3QiLCJuZXdTcG9jTmFtZSIsInNldE5ld1Nwb2NOYW1lIiwibmV3U3BvY01vYmlsZSIsInNldE5ld1Nwb2NNb2JpbGUiLCJuZXdTcG9jRW1haWwiLCJzZXROZXdTcG9jRW1haWwiLCJmaWx0ZXJlZENsdXN0ZXJzIiwiZmlsdGVyIiwiYyIsIm5hbWUiLCJkaXN0cmljdCIsImNvbGxlZ2VOYW1lIiwic3BvY05hbWUiLCJhZG1pbk5hbWUiLCJjb2RlIiwiaGFuZGxlQ3JlYXRlQ2x1c3RlciIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJyZXMiLCJzcG9jTW9iaWxlIiwiYWRtaW5FbWFpbCIsImFkbWluUGhvbmUiLCJzdGF0dXMiLCJlcnIiLCJtZXNzYWdlIiwibGVuZ3RoIiwicmVkdWNlIiwiYWNjIiwiYWN0aXZlUGFuY2hheWF0cyIsInRvdGFsU3R1ZGVudHMiLCJ0b3RhbFZvbHVudGVlcnMiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsImNsdXN0ZXIiLCJjb21wbGV0aW9uUmF0ZSIsIk1hdGgiLCJyb3VuZCIsImNvbXBsZXRlZFNlc3Npb25zIiwidG90YWxTZXNzaW9ucyIsIndpZHRoIiwiaWQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDbHVzdGVyc1ZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBCdWlsZGluZzIsIFxuICBNYXBQaW4sIFxuICBVc2VycywgXG4gIEdyYWR1YXRpb25DYXAsIFxuICBQbHVzLCBcbiAgU2VhcmNoLCBcbiAgQXJyb3dSaWdodCwgXG4gIFgsIFxuICBQaG9uZSwgXG4gIE1haWwsXG4gIFNjaG9vbCxcbiAgQ2hlY2tDaXJjbGUyLFxuICBBbGVydENpcmNsZSxcbiAgVHJhc2gyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBDbHVzdGVyLCBUYWJUeXBlIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IEJhZGdlIGZyb20gJy4vdWkvYmFkZ2UnO1xuaW1wb3J0IHsgQWN0aW9uQnV0dG9uIH0gZnJvbSAnLi91aS9hY3Rpb24tYnV0dG9uJztcblxuaW50ZXJmYWNlIENsdXN0ZXJzVmlld1Byb3BzIHtcbiAgY2x1c3RlcnM6IENsdXN0ZXJbXTtcbiAgdXNlclJvbGU/OiBzdHJpbmc7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkFkZENsdXN0ZXI/OiAoY2x1c3RlcjogUGFydGlhbDxDbHVzdGVyPikgPT4gdm9pZCB8IFByb21pc2U8dm9pZCB8IGJvb2xlYW4+O1xuICBvbkRlbGV0ZUNsdXN0ZXI/OiAoaWQ6IHN0cmluZykgPT4gdm9pZCB8IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCBjb25zdCBDbHVzdGVyc1ZpZXc6IFJlYWN0LkZDPENsdXN0ZXJzVmlld1Byb3BzPiA9ICh7XG4gIGNsdXN0ZXJzID0gW10sXG4gIHVzZXJSb2xlID0gJ1N1cGVyIEFkbWluJyxcbiAgb25OYXZpZ2F0ZSxcbiAgb25BZGRDbHVzdGVyLFxuICBvbkRlbGV0ZUNsdXN0ZXIsXG59KSA9PiB7XG4gIGNvbnN0IGlzU3VwZXJBZG1pbiA9ICF1c2VyUm9sZSB8fCB1c2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJyB8fCB1c2VyUm9sZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdzdXBlcicpO1xuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc0FkZE1vZGFsT3Blbiwgc2V0SXNBZGRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZm9ybUVycm9yLCBzZXRGb3JtRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY2x1c3RlclRvRGVsZXRlLCBzZXRDbHVzdGVyVG9EZWxldGVdID0gdXNlU3RhdGU8Q2x1c3RlciB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IFtuZXdDb2xsZWdlTmFtZSwgc2V0TmV3Q29sbGVnZU5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3Q2x1c3RlckRpc3RyaWN0LCBzZXROZXdDbHVzdGVyRGlzdHJpY3RdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3U3BvY05hbWUsIHNldE5ld1Nwb2NOYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld1Nwb2NNb2JpbGUsIHNldE5ld1Nwb2NNb2JpbGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3U3BvY0VtYWlsLCBzZXROZXdTcG9jRW1haWxdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGZpbHRlcmVkQ2x1c3RlcnMgPSBjbHVzdGVycy5maWx0ZXIoXG4gICAgKGMpID0+XG4gICAgICAoYy5uYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIChjLmRpc3RyaWN0IHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIChjLmNvbGxlZ2VOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIChjLnNwb2NOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIChjLmFkbWluTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAoYy5jb2RlIHx8ICcnKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSlcbiAgKTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVDbHVzdGVyID0gYXN5bmMgKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRGb3JtRXJyb3IoJycpO1xuXG4gICAgaWYgKFxuICAgICAgIW5ld0NvbGxlZ2VOYW1lLnRyaW0oKSB8fFxuICAgICAgIW5ld0NsdXN0ZXJEaXN0cmljdC50cmltKCkgfHxcbiAgICAgICFuZXdTcG9jTmFtZS50cmltKCkgfHxcbiAgICAgICFuZXdTcG9jTW9iaWxlLnRyaW0oKSB8fFxuICAgICAgIW5ld1Nwb2NFbWFpbC50cmltKClcbiAgICApIHtcbiAgICAgIHNldEZvcm1FcnJvcignUGxlYXNlIGZpbGwgaW4gYWxsIHJlcXVpcmVkIGZpZWxkcyBtYXJrZWQgd2l0aCAqLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgaWYgKG9uQWRkQ2x1c3Rlcikge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBvbkFkZENsdXN0ZXIoe1xuICAgICAgICAgIGNvbGxlZ2VOYW1lOiBuZXdDb2xsZWdlTmFtZS50cmltKCksXG4gICAgICAgICAgZGlzdHJpY3Q6IG5ld0NsdXN0ZXJEaXN0cmljdC50cmltKCksXG4gICAgICAgICAgbmFtZTogYCR7bmV3Q29sbGVnZU5hbWUudHJpbSgpfSAoJHtuZXdDbHVzdGVyRGlzdHJpY3QudHJpbSgpfSlgLFxuICAgICAgICAgIHNwb2NOYW1lOiBuZXdTcG9jTmFtZS50cmltKCksXG4gICAgICAgICAgc3BvY01vYmlsZTogbmV3U3BvY01vYmlsZS50cmltKCksXG4gICAgICAgICAgYWRtaW5OYW1lOiBuZXdTcG9jTmFtZS50cmltKCksXG4gICAgICAgICAgYWRtaW5FbWFpbDogbmV3U3BvY0VtYWlsLnRyaW0oKS50b0xvd2VyQ2FzZSgpLFxuICAgICAgICAgIGFkbWluUGhvbmU6IG5ld1Nwb2NNb2JpbGUudHJpbSgpLFxuICAgICAgICAgIHN0YXR1czogJ0FjdGl2ZScsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChyZXMgPT09IGZhbHNlKSB7XG4gICAgICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc2V0SXNBZGRNb2RhbE9wZW4oZmFsc2UpO1xuICAgICAgc2V0TmV3Q29sbGVnZU5hbWUoJycpO1xuICAgICAgc2V0TmV3Q2x1c3RlckRpc3RyaWN0KCcnKTtcbiAgICAgIHNldE5ld1Nwb2NOYW1lKCcnKTtcbiAgICAgIHNldE5ld1Nwb2NNb2JpbGUoJycpO1xuICAgICAgc2V0TmV3U3BvY0VtYWlsKCcnKTtcbiAgICAgIHNldEZvcm1FcnJvcignJyk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEZvcm1FcnJvcihlcnI/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBvbmJvYXJkIGNvbGxlZ2UgY2x1c3Rlci4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTZcIj5cbiAgICAgIHsvKiAxLiBDYXJkbGVzcyBQYWdlIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgQ2x1c3RlcnMgJiBDb2xsZWdlIE9uYm9hcmRpbmdcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIHtjbHVzdGVycy5sZW5ndGh9IE9uYm9hcmRlZFxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgIE1hbmFnZSBwYXJ0bmVyIGNvbGxlZ2VzLCBkaXN0cmljdCBodWJzLCBTUE9DIGNvb3JkaW5hdG9ycywgYW5kIHJlZ2lvbmFsIGFkbWluaXN0cmF0b3JzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHNldElzQWRkTW9kYWxPcGVuKHRydWUpO1xuICAgICAgICAgICAgc2V0Rm9ybUVycm9yKCcnKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gc2hyaW5rLTBcIlxuICAgICAgICA+XG4gICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgPHNwYW4+T25ib2FyZCBOZXcgQ29sbGVnZTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDIuIENvbXBhY3QgTWV0cmljIENhcmRzIChmb3IgY291bnQgYW5kIHN0YXR1cykgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPk9uYm9hcmRlZCBDb2xsZWdlczwvc3Bhbj5cbiAgICAgICAgICAgIDxTY2hvb2wgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWJyYW5kLTUwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtYmFzZWxpbmUganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3RlcnMubGVuZ3RofTwvc3Bhbj5cbiAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cInByaW1hcnlcIiBzaXplPVwic21cIj5BY3RpdmU8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+VG90YWwgUGFuY2hheWF0czwvc3Bhbj5cbiAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LXN1Y2Nlc3MtNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICB7Y2x1c3RlcnMucmVkdWNlKChhY2MsIGMpID0+IGFjYyArIChjLmFjdGl2ZVBhbmNoYXlhdHMgfHwgMCksIDApfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwic3VjY2Vzc1wiIHNpemU9XCJzbVwiPk1hcHBlZDwvQmFkZ2U+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5FbnJvbGxlZCBTdHVkZW50czwvc3Bhbj5cbiAgICAgICAgICAgIDxHcmFkdWF0aW9uQ2FwIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC10aGVtZS1wdXJwbGUtNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICB7Y2x1c3RlcnMucmVkdWNlKChhY2MsIGMpID0+IGFjYyArIChjLnRvdGFsU3R1ZGVudHMgfHwgMCksIDApfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwiaW5mb1wiIHNpemU9XCJzbVwiPkVucm9sbGVkPC9CYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkFjdGl2ZSBWb2x1bnRlZXJzPC9zcGFuPlxuICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC13YXJuaW5nLTUwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtYmFzZWxpbmUganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAge2NsdXN0ZXJzLnJlZHVjZSgoYWNjLCBjKSA9PiBhY2MgKyAoYy50b3RhbFZvbHVudGVlcnMgfHwgMCksIDApfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPk1lbnRvcnM8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogMy4gQ2FyZGxlc3MgU2VhcmNoICYgRmlsdGVyIEJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZ3JheS00MDAgYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgY29sbGVnZSwgZGlzdHJpY3QsIG9yIFNQT0MuLi5cIlxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwbC0xMCBwci00IHB5LTIuNSB0ZXh0LXNtIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwLzEwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXI6dGV4dC1ncmF5LTUwMFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIDQuIENhcmRsZXNzIEdyaWQgTGlzdCAqL31cbiAgICAgIHtmaWx0ZXJlZENsdXN0ZXJzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxCdWlsZGluZzIgY2xhc3NOYW1lPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTMwMCBkYXJrOnRleHQtZ3JheS02MDBcIiAvPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtdC0zIHRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+Tm8gcGFydG5lciBjb2xsZWdlcyBmb3VuZDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICB7c2VhcmNoVGVybSA/ICdUcnkgYWRqdXN0aW5nIHlvdXIgc2VhcmNoIHRlcm1zLicgOiAnQ2xpY2sgXCJPbmJvYXJkIE5ldyBDb2xsZWdlXCIgdG8gcmVnaXN0ZXIgYSBjb2xsZWdlIGFuZCBhc3NpZ24gaXRzIFNQT0MgY29vcmRpbmF0b3IuJ31cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC01XCI+XG4gICAgICAgICAge2ZpbHRlcmVkQ2x1c3RlcnMubWFwKChjbHVzdGVyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjb21wbGV0aW9uUmF0ZSA9IE1hdGgucm91bmQoXG4gICAgICAgICAgICAgICgoY2x1c3Rlci5jb21wbGV0ZWRTZXNzaW9ucyB8fCAwKSAvIChjbHVzdGVyLnRvdGFsU2Vzc2lvbnMgfHwgNDgpKSAqIDEwMFxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17Y2x1c3Rlci5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ym9yZGVyLWJyYW5kLTMwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBkYXJrOmhvdmVyOmJvcmRlci1icmFuZC04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBDb2xsZWdlIEluZm8gKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIGZsZXgtMSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGUgZ3JvdXAtaG92ZXI6dGV4dC1icmFuZC01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjbHVzdGVyLmNvbGxlZ2VOYW1lIHx8IGNsdXN0ZXIubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1ncmF5LTQwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Y2x1c3Rlci5kaXN0cmljdH0sIFRhbWlsIE5hZHU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkN1cnJpY3VsdW0gUHJvZ3Jlc3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC1icmFuZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb21wbGV0aW9uUmF0ZX0lICh7Y2x1c3Rlci5jb21wbGV0ZWRTZXNzaW9ucyB8fCAwfS97Y2x1c3Rlci50b3RhbFNlc3Npb25zIHx8IDQ4fSlcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMS41IHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGRhcms6YmctZ3JheS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIGJnLWJyYW5kLTUwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke2NvbXBsZXRpb25SYXRlfSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEtleSBTdGF0cyBSb3cgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgcm91bmRlZC14bCBiZy1ncmF5LTUwLzcwIHAtMi41IHRleHQtY2VudGVyIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bSBibG9ja1wiPlBhbmNoYXlhdHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3Rlci5hY3RpdmVQYW5jaGF5YXRzIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtIGJsb2NrXCI+U3R1ZGVudHM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3Rlci50b3RhbFN0dWRlbnRzIHx8IDB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtIGJsb2NrXCI+Vm9sdW50ZWVyczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPntjbHVzdGVyLnRvdGFsVm9sdW50ZWVycyB8fCAwfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFNQT0MgRGV0YWlscyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtMyBzcGFjZS15LTEgdGV4dC14cyBkYXJrOmJvcmRlci1ncmF5LTgwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57Y2x1c3Rlci5zcG9jTmFtZSB8fCBjbHVzdGVyLmFkbWluTmFtZSB8fCAnU1BPQyBBZG1pbid9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHNocmluay0wXCI+e2NsdXN0ZXIuc3BvY01vYmlsZSB8fCBjbHVzdGVyLmFkbWluUGhvbmV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIHRydW5jYXRlIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtjbHVzdGVyLmFkbWluRW1haWx9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogRm9vdGVyIEFjdGlvbiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICB7aXNTdXBlckFkbWluICYmIG9uRGVsZXRlQ2x1c3RlciA/IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENsdXN0ZXJUb0RlbGV0ZShjbHVzdGVyKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZXJyb3ItNTAwIGhvdmVyOnRleHQtZXJyb3ItNjAwIGhvdmVyOmJnLWVycm9yLTUwIGRhcms6aG92ZXI6YmctZXJyb3ItNTAwLzEwIHB4LTIgcHktMSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZSBDbHVzdGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkRlbGV0ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogPGRpdiAvPn1cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ3BhbmNoYXlhdHMnLCBjbHVzdGVyLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgaG92ZXI6dGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlZpZXcgUGFuY2hheWF0cyAmIFNjb3BlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBPbmJvYXJkIE5ldyBDb2xsZWdlIE1vZGFsICovfVxuICAgICAge2lzQWRkTW9kYWxPcGVuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy15LWF1dG8gYmctZ3JheS05MDAvNzUgcC00IGJhY2tkcm9wLWJsdXItc21cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3ctdGhlbWUteGwgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBhbmltYXRlLWluIGZhZGUtaW4tMCB6b29tLWluLTk1XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgT25ib2FyZCBQYXJ0bmVyIENvbGxlZ2VcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICBSZWdpc3RlciBpbnN0aXR1dGlvbiBhbmQgcHJvdmlzaW9uIFNQT0MgY2x1c3RlciBhZG1pbiBjcmVkZW50aWFscy5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6aG92ZXI6YmctZ3JheS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGVDbHVzdGVyfSBjbGFzc05hbWU9XCJtdC01IHNwYWNlLXktNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIHtmb3JtRXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWVycm9yLTIwMCBiZy1lcnJvci01MCBwLTMgdGV4dC14cyB0ZXh0LWVycm9yLTYwMCBkYXJrOmJvcmRlci1lcnJvci05MDAvNDAgZGFyazpiZy1lcnJvci01MDAvMTAgZGFyazp0ZXh0LWVycm9yLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1FcnJvcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIENvbGxlZ2UgLyBJbnN0aXR1dGlvbiBOYW1lICpcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gR292ZXJubWVudCBBcnRzIENvbGxlZ2VcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Q29sbGVnZU5hbWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3Q29sbGVnZU5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yLjUgdGV4dC14cyB0ZXh0LWdyYXktODAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwLzEwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIERpc3RyaWN0ICpcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gRGhhcm1hcHVyaVwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdDbHVzdGVyRGlzdHJpY3R9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3Q2x1c3RlckRpc3RyaWN0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMi41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1icmFuZC01MDAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgQ29sbGVnZSBTUE9DICYgUmVnaW9uYWwgQWRtaW5pc3RyYXRvclxuICAgICAgICAgICAgICAgIDwvaDQ+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFNQT0MgRnVsbCBOYW1lICpcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIERyLiBNLiBWaWduZXNoXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3U3BvY05hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdTcG9jTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTUE9DIE1vYmlsZSBOdW1iZXIgKlxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiArOTEgOTg3NjUgNDMyMTBcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdTcG9jTW9iaWxlfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3U3BvY01vYmlsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMiB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAvMTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIFNQT0MgT2ZmaWNpYWwgRW1haWwgKlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gdmlnbmVzaC5tQGdhYy1kcGkuZWR1LmluXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Nwb2NFbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdTcG9jRW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yIHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLWxpZ2h0LTIwMCBiZy1ibHVlLWxpZ2h0LTUwLzcwIHAtMyB0ZXh0LXhzIHRleHQtYmx1ZS1saWdodC05MDAgZGFyazpib3JkZXItYmx1ZS1saWdodC05MDAvNDAgZGFyazpiZy1ibHVlLWxpZ2h0LTUwMC8xMCBkYXJrOnRleHQtYmx1ZS1saWdodC0zMDBcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWJsdWUtbGlnaHQtNTAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIEF1dG9tYXRlZCBDcmVkZW50aWFscyBFbWFpbFxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzExcHhdIG9wYWNpdHktOTBcIj5cbiAgICAgICAgICAgICAgICAgIFRoZSBTUE9DIHdpbGwgYmUgcHJvdmlzaW9uZWQgYXMgUmVnaW9uYWwgQ2x1c3RlciBBZG1pbi4gTG9naW4gY3JlZGVudGlhbHMgd2lsbCBiZSBkaXNwYXRjaGVkIHRvIDxzdHJvbmc+e25ld1Nwb2NFbWFpbCB8fCAndGhlaXIgZW1haWwnfTwvc3Ryb25nPi5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBZGRNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAnT25ib2FyZGluZyBDb2xsZWdlLi4uJyA6ICdPbmJvYXJkIENvbGxlZ2UgJiBTZW5kIENyZWRlbnRpYWxzJ31cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIERlbGV0ZSBDb25maXJtYXRpb24gTW9kYWwgKi99XG4gICAgICB7Y2x1c3RlclRvRGVsZXRlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy15LWF1dG8gYmctZ3JheS05MDAvNzUgcC00IGJhY2tkcm9wLWJsdXItc21cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3ctdGhlbWUteGwgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBhbmltYXRlLWluIGZhZGUtaW4tMCB6b29tLWluLTk1XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtZXJyb3ItNTAwIG1iLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1lcnJvci01MCBkYXJrOmJnLWVycm9yLTUwMC8xMFwiPlxuICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+RGVsZXRlIENsdXN0ZXI8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5UaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDAgbWItNSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHBlcm1hbmVudGx5IGRlbGV0ZSA8c3Ryb25nPntjbHVzdGVyVG9EZWxldGUuY29sbGVnZU5hbWUgfHwgY2x1c3RlclRvRGVsZXRlLm5hbWV9PC9zdHJvbmc+ICh7Y2x1c3RlclRvRGVsZXRlLmRpc3RyaWN0fSk/IEFzc29jaWF0ZWQgbG9jYWwgb3BlcmF0aW9uYWwgbWFwcGluZyB3aWxsIGJlIHVuYXNzaWduZWQuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2x1c3RlclRvRGVsZXRlKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAob25EZWxldGVDbHVzdGVyICYmIGNsdXN0ZXJUb0RlbGV0ZSkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBvbkRlbGV0ZUNsdXN0ZXIoY2x1c3RlclRvRGVsZXRlLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2x1c3RlclRvRGVsZXRlKG51bGwpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1lcnJvci01MDAgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1lcnJvci02MDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDb25maXJtIERlbGV0ZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQ2x1c3RlcnNWaWV3LnRzeCJ9