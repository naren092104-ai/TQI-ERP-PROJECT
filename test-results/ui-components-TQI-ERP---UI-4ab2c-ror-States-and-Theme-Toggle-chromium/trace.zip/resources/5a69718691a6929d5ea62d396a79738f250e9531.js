import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AcademicSetupView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
import {
  Edit3,
  Save,
  Search,
  BookOpen,
  MapPin,
  CheckCircle2
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { Button } from "/src/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "/src/components/ui/card.tsx";
import { apiUrl } from "/src/utils/api.ts";
export const AcademicSetupView = ({ authToken, onSetupSaved }) => {
  _s();
  const [modules, setModules] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState(null);
  const [academicYear, setAcademicYear] = useState("2026-2027");
  const [sessionNames, setSessionNames] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const defaultSuggestedNames = {
    1: {
      name: "Spoken English & Goal Setting",
      month: "February",
      description: "Foundational conversational drills, student goal setting and self-confidence building.",
      topic: "Communication & Life Skills",
      location: "Panchayat Community Centers"
    },
    2: {
      name: "Basic Arithmetic & Logic Puzzles",
      month: "February",
      description: "Mental math drills, interactive logic puzzles and practical number operations.",
      topic: "Quantitative & Logical Aptitude",
      location: "Village Study Hubs"
    },
    3: {
      name: "Hands-on Science & Daily Observation",
      month: "March",
      description: "Simple science experiments, natural observation and curiosity-driven inquiry.",
      topic: "Applied Physical & Nature Sciences",
      location: "Panchayat Community Centers"
    },
    4: {
      name: "Life Skills, Health & Hygiene",
      month: "March",
      description: "Personal wellness, sanitation awareness, peer teamwork and emotional resilience.",
      topic: "Health, Sanitation & Teamwork",
      location: "Village Study Hubs"
    },
    5: {
      name: "Creative Arts & Expression",
      month: "March",
      description: "Artistic crafts, expressive storytelling, drawing and collaborative group drama.",
      topic: "Creative & Expressive Arts",
      location: "Panchayat Community Centers"
    },
    6: {
      name: "Digital Literacy & Computer Basics",
      month: "April",
      description: "Computer fundamentals, typing practice, basic tools and cyber safety habits.",
      topic: "Digital & Technology Literacy",
      location: "Cluster Digital Centers"
    },
    7: {
      name: "Environment & Community Action",
      month: "April",
      description: "Tree plantation drives, local water conservation and clean village initiatives.",
      topic: "Environmental & Social Responsibility",
      location: "Village Open Grounds"
    },
    8: {
      name: "Culmination Showcase & Feedback",
      month: "April",
      description: "Student project exhibitions, recognition certificates and academic cycle review.",
      topic: "Showcase & Term Review",
      location: "Main Cluster Hall"
    }
  };
  useEffect(() => {
    const controller = new AbortController();
    fetch(apiUrl("/api/modules"), {
      signal: controller.signal,
      headers: authToken ? { Authorization: `Bearer ${authToken}` } : {}
    }).then(async (response) => {
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.error || "Unable to load academic term.");
      const loadedModules = Array.isArray(data.modules) ? data.modules : [];
      setModules(loadedModules);
      const firstYear = loadedModules.find((module) => module.academicYear)?.academicYear;
      if (firstYear) setAcademicYear(firstYear);
      const setupResponse = await fetch(apiUrl("/api/academic-setup"), {
        headers: authToken ? { Authorization: `Bearer ${authToken}` } : {}
      });
      const setupData = await setupResponse.json().catch(() => null);
      if (!setupResponse.ok || !setupData?.success) throw new Error(setupData?.error || `Unable to load session data (${setupResponse.status}).`);
      const setup = Array.isArray(setupData.setup) ? setupData.setup : [];
      const firstSetupYear = setup.find((day) => day.academic_year)?.academic_year;
      if (firstSetupYear) setAcademicYear(firstSetupYear);
      const initialMap = {};
      for (let i = 1; i <= 8; i++) {
        const found = setup.find((day) => day.day_number === i);
        initialMap[i] = found?.session_name || defaultSuggestedNames[i].name;
      }
      setSessionNames(initialMap);
    }).catch((error) => {
      if (error.name !== "AbortError") setErrorMessage(error instanceof Error ? error.message : "Unable to load academic term.");
    }).finally(() => setIsLoading(false));
    return () => controller.abort();
  }, [authToken]);
  const saveSetup = async () => {
    setIsSaving(true);
    setSaveMessage(null);
    setErrorMessage(null);
    try {
      const response = await fetch(apiUrl("/api/academic-setup"), {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          ...authToken ? { Authorization: `Bearer ${authToken}` } : {}
        },
        body: JSON.stringify({
          academicYear,
          days: Array.from({ length: 8 }, (_, index) => ({
            dayNumber: index + 1,
            sessionName: sessionNames[index + 1] || defaultSuggestedNames[index + 1].name
          }))
        })
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data?.success) throw new Error(data?.error || `Unable to save academic term (${response.status}).`);
      setSaveMessage("Academic term saved successfully.");
      setIsEditing(false);
      onSetupSaved?.();
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Unable to save academic term.");
    } finally {
      setIsSaving(false);
    }
  };
  const updateSessionName = (dayNumber, sessionName) => {
    setSessionNames((current) => ({ ...current, [dayNumber]: sessionName }));
    setSaveMessage(null);
  };
  const filteredDays = Array.from({ length: 8 }, (_, i) => i + 1).filter((dayNum) => {
    const meta = defaultSuggestedNames[dayNum];
    const name = sessionNames[dayNum] || meta.name;
    const query = searchQuery.toLowerCase();
    return name.toLowerCase().includes(query) || meta.month.toLowerCase().includes(query) || meta.topic.toLowerCase().includes(query) || meta.location.toLowerCase().includes(query) || `day ${dayNum}`.includes(query);
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between border-b border-border/50 pb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold tracking-tight text-foreground sm:text-3xl", children: "Academic Term" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 186,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground mt-1", children: [
          academicYear,
          " Academic Term • 8 Curriculum Milestones (Feb – Apr)"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 189,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 185,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: isEditing ? /* @__PURE__ */ jsxDEV(
        Button,
        {
          onClick: saveSetup,
          disabled: isLoading || isSaving,
          size: "sm",
          children: [
            /* @__PURE__ */ jsxDEV(Save, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 201,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: isSaving ? "Saving..." : "Save Term" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 202,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 196,
          columnNumber: 11
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "outline",
          size: "sm",
          onClick: () => {
            setIsEditing(true);
            setSaveMessage(null);
          },
          disabled: isLoading,
          children: [
            /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 211,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Edit Term" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 212,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 205,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 194,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
      lineNumber: 184,
      columnNumber: 7
    }, this),
    errorMessage && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-destructive/20 bg-destructive/10 p-4 text-xs font-medium text-destructive", children: errorMessage }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
      lineNumber: 220,
      columnNumber: 7
    }, this),
    saveMessage && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-emerald-500/20 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-xs font-medium text-emerald-800 dark:text-emerald-300 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 227,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: saveMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 228,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
      lineNumber: 226,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-muted-foreground absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 235,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search sessions, topics, locations...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full bg-transparent border border-border/70 rounded-xl pl-10 pr-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 236,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 234,
        columnNumber: 9
      }, this),
      isEditing && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-muted-foreground", children: "Academic Year:" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 247,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            className: "bg-transparent border border-border/70 rounded-lg px-3 py-1.5 text-sm font-semibold text-foreground outline-none focus:border-primary",
            value: academicYear,
            placeholder: "2026-2027",
            onChange: (e) => {
              setAcademicYear(e.target.value);
              setSaveMessage(null);
            }
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 248,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 246,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
      lineNumber: 233,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-4", children: filteredDays.map((dayNumber) => {
      const meta = defaultSuggestedNames[dayNumber];
      const sessionName = sessionNames[dayNumber] || meta.name;
      const linkedModule = modules.find((m) => m.dayNumber === dayNumber || m.moduleName.toLowerCase().includes(sessionName.toLowerCase()));
      return /* @__PURE__ */ jsxDEV(Card, { className: "flex flex-col justify-between p-6 space-y-4 hover:border-primary/50 transition-colors", children: [
        /* @__PURE__ */ jsxDEV(CardHeader, { className: "p-0 space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs font-bold uppercase tracking-wider text-muted-foreground", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Day 0",
              dayNumber
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 270,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-semibold", children: meta.month }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 271,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 269,
            columnNumber: 17
          }, this),
          isEditing ? /* @__PURE__ */ jsxDEV(
            "input",
            {
              className: "w-full rounded-md border border-border bg-background px-3 py-2 text-sm font-bold text-foreground outline-none focus:border-primary",
              value: sessionNames[dayNumber] || "",
              placeholder: meta.name,
              onChange: (e) => updateSessionName(dayNumber, e.target.value)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 276,
              columnNumber: 17
            },
            this
          ) : /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-base font-bold text-foreground leading-snug", children: sessionName }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 283,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(CardDescription, { className: "text-sm text-muted-foreground leading-relaxed", children: meta.description }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 289,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 267,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(CardContent, { className: "p-0 pt-3 space-y-2.5 border-t border-border/40", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxDEV(BookOpen, { className: "h-4 w-4 text-primary shrink-0" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 298,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "truncate font-medium", children: linkedModule?.topic || meta.topic }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 299,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 297,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsxDEV(MapPin, { className: "h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 304,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: meta.location }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
              lineNumber: 305,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
            lineNumber: 303,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
          lineNumber: 295,
          columnNumber: 15
        }, this)
      ] }, dayNumber, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
        lineNumber: 266,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
      lineNumber: 259,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx",
    lineNumber: 182,
    columnNumber: 5
  }, this);
};
_s(AcademicSetupView, "NYwY+w51dpv3VuE+f/9FhVKbl+w=");
_c = AcademicSetupView;
var _c;
$RefreshReg$(_c, "AcademicSetupView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AcademicSetupView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUxVOztBQXpMVixTQUFnQkEsV0FBV0MsZ0JBQWdCO0FBQzNDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGNBQWM7QUFDdkI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsU0FBU0MsY0FBYztBQU9oQixhQUFNQyxvQkFBc0RBLENBQUMsRUFBRUMsV0FBV0MsYUFBYSxNQUFNO0FBQUFDLEtBQUE7QUFDbEcsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUluQixTQUFzQixFQUFFO0FBQ3RELFFBQU0sQ0FBQ29CLFdBQVdDLFlBQVksSUFBSXJCLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNzQixjQUFjQyxlQUFlLElBQUl2QixTQUF3QixJQUFJO0FBQ3BFLFFBQU0sQ0FBQ3dCLGNBQWNDLGVBQWUsSUFBSXpCLFNBQVMsV0FBVztBQUM1RCxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQixTQUFpQyxDQUFDLENBQUM7QUFDM0UsUUFBTSxDQUFDNEIsVUFBVUMsV0FBVyxJQUFJN0IsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzhCLGFBQWFDLGNBQWMsSUFBSS9CLFNBQXdCLElBQUk7QUFDbEUsUUFBTSxDQUFDZ0MsV0FBV0MsWUFBWSxJQUFJakMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2tDLGFBQWFDLGNBQWMsSUFBSW5DLFNBQVMsRUFBRTtBQUVqRCxRQUFNb0Msd0JBQStIO0FBQUEsSUFDbkksR0FBRztBQUFBLE1BQ0RDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0RKLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFFQTFDLFlBQVUsTUFBTTtBQUNkLFVBQU0yQyxhQUFhLElBQUlDLGdCQUFnQjtBQUN2Q0MsVUFBTS9CLE9BQU8sY0FBYyxHQUFHO0FBQUEsTUFDNUJnQyxRQUFRSCxXQUFXRztBQUFBQSxNQUNuQkMsU0FBUy9CLFlBQVksRUFBRWdDLGVBQWUsVUFBVWhDLFNBQVMsR0FBRyxJQUFJLENBQUM7QUFBQSxJQUNuRSxDQUFDLEVBQ0VpQyxLQUFLLE9BQU9DLGFBQWE7QUFDeEIsWUFBTUMsT0FBTyxNQUFNRCxTQUFTRSxLQUFLO0FBQ2pDLFVBQUksQ0FBQ0YsU0FBU0csTUFBTSxDQUFDRixLQUFLRyxRQUFTLE9BQU0sSUFBSUMsTUFBTUosS0FBS0ssU0FBUywrQkFBK0I7QUFDaEcsWUFBTUMsZ0JBQTZCQyxNQUFNQyxRQUFRUixLQUFLaEMsT0FBTyxJQUFJZ0MsS0FBS2hDLFVBQVU7QUFDaEZDLGlCQUFXcUMsYUFBYTtBQUN4QixZQUFNRyxZQUFZSCxjQUFjSSxLQUFLLENBQUNDLFdBQVdBLE9BQU9yQyxZQUFZLEdBQUdBO0FBQ3ZFLFVBQUltQyxVQUFXbEMsaUJBQWdCa0MsU0FBUztBQUN4QyxZQUFNRyxnQkFBZ0IsTUFBTWxCLE1BQU0vQixPQUFPLHFCQUFxQixHQUFHO0FBQUEsUUFDL0RpQyxTQUFTL0IsWUFBWSxFQUFFZ0MsZUFBZSxVQUFVaEMsU0FBUyxHQUFHLElBQUksQ0FBQztBQUFBLE1BQ25FLENBQUM7QUFDRCxZQUFNZ0QsWUFBWSxNQUFNRCxjQUFjWCxLQUFLLEVBQUVhLE1BQU0sTUFBTSxJQUFJO0FBQzdELFVBQUksQ0FBQ0YsY0FBY1YsTUFBTSxDQUFDVyxXQUFXVixRQUFTLE9BQU0sSUFBSUMsTUFBTVMsV0FBV1IsU0FBUyxnQ0FBZ0NPLGNBQWNHLE1BQU0sSUFBSTtBQUMxSSxZQUFNQyxRQUFRVCxNQUFNQyxRQUFRSyxVQUFVRyxLQUFLLElBQUlILFVBQVVHLFFBQVE7QUFDakUsWUFBTUMsaUJBQWlCRCxNQUFNTixLQUFLLENBQUNRLFFBQW9DQSxJQUFJQyxhQUFhLEdBQUdBO0FBQzNGLFVBQUlGLGVBQWdCMUMsaUJBQWdCMEMsY0FBYztBQUVsRCxZQUFNRyxhQUFxQyxDQUFDO0FBQzVDLGVBQVNDLElBQUksR0FBR0EsS0FBSyxHQUFHQSxLQUFLO0FBQzNCLGNBQU1DLFFBQVFOLE1BQU1OLEtBQUssQ0FBQ1EsUUFBZ0NBLElBQUlLLGVBQWVGLENBQUM7QUFDOUVELG1CQUFXQyxDQUFDLElBQUlDLE9BQU9FLGdCQUFnQnRDLHNCQUFzQm1DLENBQUMsRUFBRWxDO0FBQUFBLE1BQ2xFO0FBQ0FWLHNCQUFnQjJDLFVBQVU7QUFBQSxJQUM1QixDQUFDLEVBQ0FOLE1BQU0sQ0FBQ1QsVUFBVTtBQUNoQixVQUFJQSxNQUFNbEIsU0FBUyxhQUFjZCxpQkFBZ0JnQyxpQkFBaUJELFFBQVFDLE1BQU1vQixVQUFVLCtCQUErQjtBQUFBLElBQzNILENBQUMsRUFDQUMsUUFBUSxNQUFNdkQsYUFBYSxLQUFLLENBQUM7QUFDcEMsV0FBTyxNQUFNcUIsV0FBV21DLE1BQU07QUFBQSxFQUNoQyxHQUFHLENBQUM5RCxTQUFTLENBQUM7QUFFZCxRQUFNK0QsWUFBWSxZQUFZO0FBQzVCakQsZ0JBQVksSUFBSTtBQUNoQkUsbUJBQWUsSUFBSTtBQUNuQlIsb0JBQWdCLElBQUk7QUFDcEIsUUFBSTtBQUNGLFlBQU0wQixXQUFXLE1BQU1MLE1BQU0vQixPQUFPLHFCQUFxQixHQUFHO0FBQUEsUUFDMURrRSxRQUFRO0FBQUEsUUFDUmpDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCLEdBQUkvQixZQUFZLEVBQUVnQyxlQUFlLFVBQVVoQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0FBQUEsUUFDOUQ7QUFBQSxRQUNBaUUsTUFBTUMsS0FBS0MsVUFBVTtBQUFBLFVBQ25CMUQ7QUFBQUEsVUFDQTJELE1BQU0xQixNQUFNMkIsS0FBSyxFQUFFQyxRQUFRLEVBQUUsR0FBRyxDQUFDQyxHQUFHQyxXQUFXO0FBQUEsWUFDN0NDLFdBQVdELFFBQVE7QUFBQSxZQUNuQkUsYUFBYS9ELGFBQWE2RCxRQUFRLENBQUMsS0FBS25ELHNCQUFzQm1ELFFBQVEsQ0FBQyxFQUFFbEQ7QUFBQUEsVUFDM0UsRUFBRTtBQUFBLFFBQ0osQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUNELFlBQU1hLE9BQU8sTUFBTUQsU0FBU0UsS0FBSyxFQUFFYSxNQUFNLE1BQU0sSUFBSTtBQUNuRCxVQUFJLENBQUNmLFNBQVNHLE1BQU0sQ0FBQ0YsTUFBTUcsUUFBUyxPQUFNLElBQUlDLE1BQU1KLE1BQU1LLFNBQVMsaUNBQWlDTixTQUFTZ0IsTUFBTSxJQUFJO0FBQ3ZIbEMscUJBQWUsbUNBQW1DO0FBQ2xERSxtQkFBYSxLQUFLO0FBQ2xCakIscUJBQWU7QUFBQSxJQUNqQixTQUFTdUMsT0FBTztBQUNkaEMsc0JBQWdCZ0MsaUJBQWlCRCxRQUFRQyxNQUFNb0IsVUFBVSwrQkFBK0I7QUFBQSxJQUMxRixVQUFDO0FBQ0M5QyxrQkFBWSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBRUEsUUFBTTZELG9CQUFvQkEsQ0FBQ0YsV0FBbUJDLGdCQUF3QjtBQUNwRTlELG9CQUFnQixDQUFDZ0UsYUFBYSxFQUFFLEdBQUdBLFNBQVMsQ0FBQ0gsU0FBUyxHQUFHQyxZQUFZLEVBQUU7QUFDdkUxRCxtQkFBZSxJQUFJO0FBQUEsRUFDckI7QUFFQSxRQUFNNkQsZUFBZW5DLE1BQU0yQixLQUFLLEVBQUVDLFFBQVEsRUFBRSxHQUFHLENBQUNDLEdBQUdmLE1BQU1BLElBQUksQ0FBQyxFQUFFc0IsT0FBTyxDQUFDQyxXQUFXO0FBQ2pGLFVBQU1DLE9BQU8zRCxzQkFBc0IwRCxNQUFNO0FBQ3pDLFVBQU16RCxPQUFPWCxhQUFhb0UsTUFBTSxLQUFLQyxLQUFLMUQ7QUFDMUMsVUFBTTJELFFBQVE5RCxZQUFZK0QsWUFBWTtBQUN0QyxXQUNFNUQsS0FBSzRELFlBQVksRUFBRUMsU0FBU0YsS0FBSyxLQUNqQ0QsS0FBS3pELE1BQU0yRCxZQUFZLEVBQUVDLFNBQVNGLEtBQUssS0FDdkNELEtBQUt2RCxNQUFNeUQsWUFBWSxFQUFFQyxTQUFTRixLQUFLLEtBQ3ZDRCxLQUFLdEQsU0FBU3dELFlBQVksRUFBRUMsU0FBU0YsS0FBSyxLQUMxQyxPQUFPRixNQUFNLEdBQUdJLFNBQVNGLEtBQUs7QUFBQSxFQUVsQyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlFQUErRCw2QkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsc0NBQ1Z4RTtBQUFBQTtBQUFBQSxVQUFhO0FBQUEsYUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWlEsc0JBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVM4QztBQUFBQSxVQUNULFVBQVUxRCxhQUFhUTtBQUFBQSxVQUN2QixNQUFLO0FBQUEsVUFFTDtBQUFBLG1DQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QjtBQUFBLFlBQ3pCLHVCQUFDLFVBQU1BLHFCQUFXLGNBQWMsZUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQTtBQUFBO0FBQUEsUUFOOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0EsSUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQUVLLHlCQUFhLElBQUk7QUFBR0YsMkJBQWUsSUFBSTtBQUFBLFVBQUc7QUFBQSxVQUMzRCxVQUFVWDtBQUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCO0FBQUEsWUFDMUIsdUJBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUE7QUFBQTtBQUFBLFFBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBLEtBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBQUEsSUFHQ0UsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHNHQUNaQSwwQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdEUSxlQUNDLHVCQUFDLFNBQUksV0FBVSx1S0FDYjtBQUFBLDZCQUFDLGdCQUFhLFdBQVUsNkRBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUY7QUFBQSxNQUNqRix1QkFBQyxVQUFNQSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CO0FBQUEsU0FGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsa0dBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0g7QUFBQSxRQUNoSDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT0k7QUFBQUEsWUFDUCxVQUFVLENBQUNpRSxNQUFNaEUsZUFBZWdFLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUM5QyxXQUFVO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUt3TDtBQUFBLFdBUDFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUNyRSxhQUNDLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSwrQ0FBOEMsOEJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBT1I7QUFBQUEsWUFDUCxhQUFZO0FBQUEsWUFDWixVQUFVLENBQUMyRSxNQUFNO0FBQUUxRSw4QkFBZ0IwRSxFQUFFQyxPQUFPQyxLQUFLO0FBQUd0RSw2QkFBZSxJQUFJO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFKNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSThFO0FBQUEsV0FOaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0FyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNaNkQsdUJBQWFVLElBQUksQ0FBQ2QsY0FBYztBQUMvQixZQUFNTyxPQUFPM0Qsc0JBQXNCb0QsU0FBUztBQUM1QyxZQUFNQyxjQUFjL0QsYUFBYThELFNBQVMsS0FBS08sS0FBSzFEO0FBQ3BELFlBQU1rRSxlQUFlckYsUUFBUTBDLEtBQUssQ0FBQzRDLE1BQU1BLEVBQUVoQixjQUFjQSxhQUFhZ0IsRUFBRUMsV0FBV1IsWUFBWSxFQUFFQyxTQUFTVCxZQUFZUSxZQUFZLENBQUMsQ0FBQztBQUVwSSxhQUNFLHVCQUFDLFFBQXFCLFdBQVUseUZBQzlCO0FBQUEsK0JBQUMsY0FBVyxXQUFVLGlCQUVwQjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLG1DQUFDLFVBQUs7QUFBQTtBQUFBLGNBQU1UO0FBQUFBLGlCQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsWUFDdEIsdUJBQUMsVUFBSyxXQUFVLDhCQUE4Qk8sZUFBS3pELFNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsZUFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0NOLFlBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU9OLGFBQWE4RCxTQUFTLEtBQUs7QUFBQSxjQUNsQyxhQUFhTyxLQUFLMUQ7QUFBQUEsY0FDbEIsVUFBVSxDQUFDOEQsTUFBTVQsa0JBQWtCRixXQUFXVyxFQUFFQyxPQUFPQyxLQUFLO0FBQUE7QUFBQSxZQUo5RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJZ0UsSUFHaEUsdUJBQUMsYUFBVSxXQUFVLG9EQUNsQloseUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBSUYsdUJBQUMsbUJBQWdCLFdBQVUsaURBQ3hCTSxlQUFLeEQsZUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBR0EsdUJBQUMsZUFBWSxXQUFVLGtEQUVyQjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBLG1DQUFDLFlBQVMsV0FBVSxtQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxVQUFLLFdBQVUsd0JBQXdCZ0Usd0JBQWMvRCxTQUFTdUQsS0FBS3ZELFNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUEsbUNBQUMsVUFBTyxXQUFVLDZEQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLFVBQUssV0FBVSxZQUFZdUQsZUFBS3RELFlBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsZUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0F6Q1MrQyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQ0E7QUFBQSxJQUVKLENBQUMsS0FuREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLE9BaklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrSUE7QUFFSjtBQUFFdkUsR0FoU1dILG1CQUFtRDtBQUFBLEtBQW5EQTtBQUFtRCxJQUFBNEY7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJFZGl0MyIsIlNhdmUiLCJTZWFyY2giLCJCb29rT3BlbiIsIk1hcFBpbiIsIkNoZWNrQ2lyY2xlMiIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmREZXNjcmlwdGlvbiIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJhcGlVcmwiLCJBY2FkZW1pY1NldHVwVmlldyIsImF1dGhUb2tlbiIsIm9uU2V0dXBTYXZlZCIsIl9zIiwibW9kdWxlcyIsInNldE1vZHVsZXMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJlcnJvck1lc3NhZ2UiLCJzZXRFcnJvck1lc3NhZ2UiLCJhY2FkZW1pY1llYXIiLCJzZXRBY2FkZW1pY1llYXIiLCJzZXNzaW9uTmFtZXMiLCJzZXRTZXNzaW9uTmFtZXMiLCJpc1NhdmluZyIsInNldElzU2F2aW5nIiwic2F2ZU1lc3NhZ2UiLCJzZXRTYXZlTWVzc2FnZSIsImlzRWRpdGluZyIsInNldElzRWRpdGluZyIsInNlYXJjaFF1ZXJ5Iiwic2V0U2VhcmNoUXVlcnkiLCJkZWZhdWx0U3VnZ2VzdGVkTmFtZXMiLCJuYW1lIiwibW9udGgiLCJkZXNjcmlwdGlvbiIsInRvcGljIiwibG9jYXRpb24iLCJjb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwiZmV0Y2giLCJzaWduYWwiLCJoZWFkZXJzIiwiQXV0aG9yaXphdGlvbiIsInRoZW4iLCJyZXNwb25zZSIsImRhdGEiLCJqc29uIiwib2siLCJzdWNjZXNzIiwiRXJyb3IiLCJlcnJvciIsImxvYWRlZE1vZHVsZXMiLCJBcnJheSIsImlzQXJyYXkiLCJmaXJzdFllYXIiLCJmaW5kIiwibW9kdWxlIiwic2V0dXBSZXNwb25zZSIsInNldHVwRGF0YSIsImNhdGNoIiwic3RhdHVzIiwic2V0dXAiLCJmaXJzdFNldHVwWWVhciIsImRheSIsImFjYWRlbWljX3llYXIiLCJpbml0aWFsTWFwIiwiaSIsImZvdW5kIiwiZGF5X251bWJlciIsInNlc3Npb25fbmFtZSIsIm1lc3NhZ2UiLCJmaW5hbGx5IiwiYWJvcnQiLCJzYXZlU2V0dXAiLCJtZXRob2QiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRheXMiLCJmcm9tIiwibGVuZ3RoIiwiXyIsImluZGV4IiwiZGF5TnVtYmVyIiwic2Vzc2lvbk5hbWUiLCJ1cGRhdGVTZXNzaW9uTmFtZSIsImN1cnJlbnQiLCJmaWx0ZXJlZERheXMiLCJmaWx0ZXIiLCJkYXlOdW0iLCJtZXRhIiwicXVlcnkiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwibGlua2VkTW9kdWxlIiwibSIsIm1vZHVsZU5hbWUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBY2FkZW1pY1NldHVwVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgRWRpdDMsIFxuICBTYXZlLCBcbiAgU2VhcmNoLFxuICBCb29rT3BlbixcbiAgTWFwUGluLFxuICBDaGVja0NpcmNsZTJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQge1xuICBDYXJkLFxuICBDYXJkQ29udGVudCxcbiAgQ2FyZERlc2NyaXB0aW9uLFxuICBDYXJkSGVhZGVyLFxuICBDYXJkVGl0bGUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvY2FyZFwiO1xuaW1wb3J0IHsgVHFpTW9kdWxlIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgYXBpVXJsIH0gZnJvbSAnLi4vdXRpbHMvYXBpJztcblxuaW50ZXJmYWNlIEFjYWRlbWljU2V0dXBWaWV3UHJvcHMge1xuICBhdXRoVG9rZW4/OiBzdHJpbmc7XG4gIG9uU2V0dXBTYXZlZD86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBBY2FkZW1pY1NldHVwVmlldzogUmVhY3QuRkM8QWNhZGVtaWNTZXR1cFZpZXdQcm9wcz4gPSAoeyBhdXRoVG9rZW4sIG9uU2V0dXBTYXZlZCB9KSA9PiB7XG4gIGNvbnN0IFttb2R1bGVzLCBzZXRNb2R1bGVzXSA9IHVzZVN0YXRlPFRxaU1vZHVsZVtdPihbXSk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYWNhZGVtaWNZZWFyLCBzZXRBY2FkZW1pY1llYXJdID0gdXNlU3RhdGUoJzIwMjYtMjAyNycpO1xuICBjb25zdCBbc2Vzc2lvbk5hbWVzLCBzZXRTZXNzaW9uTmFtZXNdID0gdXNlU3RhdGU8UmVjb3JkPG51bWJlciwgc3RyaW5nPj4oe30pO1xuICBjb25zdCBbaXNTYXZpbmcsIHNldElzU2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NhdmVNZXNzYWdlLCBzZXRTYXZlTWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzRWRpdGluZywgc2V0SXNFZGl0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgZGVmYXVsdFN1Z2dlc3RlZE5hbWVzOiBSZWNvcmQ8bnVtYmVyLCB7IG5hbWU6IHN0cmluZzsgbW9udGg6IHN0cmluZzsgZGVzY3JpcHRpb246IHN0cmluZzsgdG9waWM6IHN0cmluZzsgbG9jYXRpb246IHN0cmluZyB9PiA9IHtcbiAgICAxOiB7IFxuICAgICAgbmFtZTogJ1Nwb2tlbiBFbmdsaXNoICYgR29hbCBTZXR0aW5nJywgXG4gICAgICBtb250aDogJ0ZlYnJ1YXJ5JywgXG4gICAgICBkZXNjcmlwdGlvbjogJ0ZvdW5kYXRpb25hbCBjb252ZXJzYXRpb25hbCBkcmlsbHMsIHN0dWRlbnQgZ29hbCBzZXR0aW5nIGFuZCBzZWxmLWNvbmZpZGVuY2UgYnVpbGRpbmcuJyxcbiAgICAgIHRvcGljOiAnQ29tbXVuaWNhdGlvbiAmIExpZmUgU2tpbGxzJyxcbiAgICAgIGxvY2F0aW9uOiAnUGFuY2hheWF0IENvbW11bml0eSBDZW50ZXJzJ1xuICAgIH0sXG4gICAgMjogeyBcbiAgICAgIG5hbWU6ICdCYXNpYyBBcml0aG1ldGljICYgTG9naWMgUHV6emxlcycsIFxuICAgICAgbW9udGg6ICdGZWJydWFyeScsIFxuICAgICAgZGVzY3JpcHRpb246ICdNZW50YWwgbWF0aCBkcmlsbHMsIGludGVyYWN0aXZlIGxvZ2ljIHB1enpsZXMgYW5kIHByYWN0aWNhbCBudW1iZXIgb3BlcmF0aW9ucy4nLFxuICAgICAgdG9waWM6ICdRdWFudGl0YXRpdmUgJiBMb2dpY2FsIEFwdGl0dWRlJyxcbiAgICAgIGxvY2F0aW9uOiAnVmlsbGFnZSBTdHVkeSBIdWJzJ1xuICAgIH0sXG4gICAgMzogeyBcbiAgICAgIG5hbWU6ICdIYW5kcy1vbiBTY2llbmNlICYgRGFpbHkgT2JzZXJ2YXRpb24nLCBcbiAgICAgIG1vbnRoOiAnTWFyY2gnLCBcbiAgICAgIGRlc2NyaXB0aW9uOiAnU2ltcGxlIHNjaWVuY2UgZXhwZXJpbWVudHMsIG5hdHVyYWwgb2JzZXJ2YXRpb24gYW5kIGN1cmlvc2l0eS1kcml2ZW4gaW5xdWlyeS4nLFxuICAgICAgdG9waWM6ICdBcHBsaWVkIFBoeXNpY2FsICYgTmF0dXJlIFNjaWVuY2VzJyxcbiAgICAgIGxvY2F0aW9uOiAnUGFuY2hheWF0IENvbW11bml0eSBDZW50ZXJzJ1xuICAgIH0sXG4gICAgNDogeyBcbiAgICAgIG5hbWU6ICdMaWZlIFNraWxscywgSGVhbHRoICYgSHlnaWVuZScsIFxuICAgICAgbW9udGg6ICdNYXJjaCcsIFxuICAgICAgZGVzY3JpcHRpb246ICdQZXJzb25hbCB3ZWxsbmVzcywgc2FuaXRhdGlvbiBhd2FyZW5lc3MsIHBlZXIgdGVhbXdvcmsgYW5kIGVtb3Rpb25hbCByZXNpbGllbmNlLicsXG4gICAgICB0b3BpYzogJ0hlYWx0aCwgU2FuaXRhdGlvbiAmIFRlYW13b3JrJyxcbiAgICAgIGxvY2F0aW9uOiAnVmlsbGFnZSBTdHVkeSBIdWJzJ1xuICAgIH0sXG4gICAgNTogeyBcbiAgICAgIG5hbWU6ICdDcmVhdGl2ZSBBcnRzICYgRXhwcmVzc2lvbicsIFxuICAgICAgbW9udGg6ICdNYXJjaCcsIFxuICAgICAgZGVzY3JpcHRpb246ICdBcnRpc3RpYyBjcmFmdHMsIGV4cHJlc3NpdmUgc3Rvcnl0ZWxsaW5nLCBkcmF3aW5nIGFuZCBjb2xsYWJvcmF0aXZlIGdyb3VwIGRyYW1hLicsXG4gICAgICB0b3BpYzogJ0NyZWF0aXZlICYgRXhwcmVzc2l2ZSBBcnRzJyxcbiAgICAgIGxvY2F0aW9uOiAnUGFuY2hheWF0IENvbW11bml0eSBDZW50ZXJzJ1xuICAgIH0sXG4gICAgNjogeyBcbiAgICAgIG5hbWU6ICdEaWdpdGFsIExpdGVyYWN5ICYgQ29tcHV0ZXIgQmFzaWNzJywgXG4gICAgICBtb250aDogJ0FwcmlsJywgXG4gICAgICBkZXNjcmlwdGlvbjogJ0NvbXB1dGVyIGZ1bmRhbWVudGFscywgdHlwaW5nIHByYWN0aWNlLCBiYXNpYyB0b29scyBhbmQgY3liZXIgc2FmZXR5IGhhYml0cy4nLFxuICAgICAgdG9waWM6ICdEaWdpdGFsICYgVGVjaG5vbG9neSBMaXRlcmFjeScsXG4gICAgICBsb2NhdGlvbjogJ0NsdXN0ZXIgRGlnaXRhbCBDZW50ZXJzJ1xuICAgIH0sXG4gICAgNzogeyBcbiAgICAgIG5hbWU6ICdFbnZpcm9ubWVudCAmIENvbW11bml0eSBBY3Rpb24nLCBcbiAgICAgIG1vbnRoOiAnQXByaWwnLCBcbiAgICAgIGRlc2NyaXB0aW9uOiAnVHJlZSBwbGFudGF0aW9uIGRyaXZlcywgbG9jYWwgd2F0ZXIgY29uc2VydmF0aW9uIGFuZCBjbGVhbiB2aWxsYWdlIGluaXRpYXRpdmVzLicsXG4gICAgICB0b3BpYzogJ0Vudmlyb25tZW50YWwgJiBTb2NpYWwgUmVzcG9uc2liaWxpdHknLFxuICAgICAgbG9jYXRpb246ICdWaWxsYWdlIE9wZW4gR3JvdW5kcydcbiAgICB9LFxuICAgIDg6IHsgXG4gICAgICBuYW1lOiAnQ3VsbWluYXRpb24gU2hvd2Nhc2UgJiBGZWVkYmFjaycsIFxuICAgICAgbW9udGg6ICdBcHJpbCcsIFxuICAgICAgZGVzY3JpcHRpb246ICdTdHVkZW50IHByb2plY3QgZXhoaWJpdGlvbnMsIHJlY29nbml0aW9uIGNlcnRpZmljYXRlcyBhbmQgYWNhZGVtaWMgY3ljbGUgcmV2aWV3LicsXG4gICAgICB0b3BpYzogJ1Nob3djYXNlICYgVGVybSBSZXZpZXcnLFxuICAgICAgbG9jYXRpb246ICdNYWluIENsdXN0ZXIgSGFsbCdcbiAgICB9LFxuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBmZXRjaChhcGlVcmwoJy9hcGkvbW9kdWxlcycpLCB7XG4gICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgaGVhZGVyczogYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9LFxuICAgIH0pXG4gICAgICAudGhlbihhc3luYyAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YS5zdWNjZXNzKSB0aHJvdyBuZXcgRXJyb3IoZGF0YS5lcnJvciB8fCAnVW5hYmxlIHRvIGxvYWQgYWNhZGVtaWMgdGVybS4nKTtcbiAgICAgICAgY29uc3QgbG9hZGVkTW9kdWxlczogVHFpTW9kdWxlW10gPSBBcnJheS5pc0FycmF5KGRhdGEubW9kdWxlcykgPyBkYXRhLm1vZHVsZXMgOiBbXTtcbiAgICAgICAgc2V0TW9kdWxlcyhsb2FkZWRNb2R1bGVzKTtcbiAgICAgICAgY29uc3QgZmlyc3RZZWFyID0gbG9hZGVkTW9kdWxlcy5maW5kKChtb2R1bGUpID0+IG1vZHVsZS5hY2FkZW1pY1llYXIpPy5hY2FkZW1pY1llYXI7XG4gICAgICAgIGlmIChmaXJzdFllYXIpIHNldEFjYWRlbWljWWVhcihmaXJzdFllYXIpO1xuICAgICAgICBjb25zdCBzZXR1cFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL2FjYWRlbWljLXNldHVwJyksIHsgXG4gICAgICAgICAgaGVhZGVyczogYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9IFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgc2V0dXBEYXRhID0gYXdhaXQgc2V0dXBSZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG4gICAgICAgIGlmICghc2V0dXBSZXNwb25zZS5vayB8fCAhc2V0dXBEYXRhPy5zdWNjZXNzKSB0aHJvdyBuZXcgRXJyb3Ioc2V0dXBEYXRhPy5lcnJvciB8fCBgVW5hYmxlIHRvIGxvYWQgc2Vzc2lvbiBkYXRhICgke3NldHVwUmVzcG9uc2Uuc3RhdHVzfSkuYCk7XG4gICAgICAgIGNvbnN0IHNldHVwID0gQXJyYXkuaXNBcnJheShzZXR1cERhdGEuc2V0dXApID8gc2V0dXBEYXRhLnNldHVwIDogW107XG4gICAgICAgIGNvbnN0IGZpcnN0U2V0dXBZZWFyID0gc2V0dXAuZmluZCgoZGF5OiB7IGFjYWRlbWljX3llYXI/OiBzdHJpbmcgfSkgPT4gZGF5LmFjYWRlbWljX3llYXIpPy5hY2FkZW1pY195ZWFyO1xuICAgICAgICBpZiAoZmlyc3RTZXR1cFllYXIpIHNldEFjYWRlbWljWWVhcihmaXJzdFNldHVwWWVhcik7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBpbml0aWFsTWFwOiBSZWNvcmQ8bnVtYmVyLCBzdHJpbmc+ID0ge307XG4gICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDw9IDg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGZvdW5kID0gc2V0dXAuZmluZCgoZGF5OiB7IGRheV9udW1iZXI6IG51bWJlciB9KSA9PiBkYXkuZGF5X251bWJlciA9PT0gaSk7XG4gICAgICAgICAgaW5pdGlhbE1hcFtpXSA9IGZvdW5kPy5zZXNzaW9uX25hbWUgfHwgZGVmYXVsdFN1Z2dlc3RlZE5hbWVzW2ldLm5hbWU7XG4gICAgICAgIH1cbiAgICAgICAgc2V0U2Vzc2lvbk5hbWVzKGluaXRpYWxNYXApO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgaWYgKGVycm9yLm5hbWUgIT09ICdBYm9ydEVycm9yJykgc2V0RXJyb3JNZXNzYWdlKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1VuYWJsZSB0byBsb2FkIGFjYWRlbWljIHRlcm0uJyk7XG4gICAgICB9KVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0SXNMb2FkaW5nKGZhbHNlKSk7XG4gICAgcmV0dXJuICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgfSwgW2F1dGhUb2tlbl0pO1xuXG4gIGNvbnN0IHNhdmVTZXR1cCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc1NhdmluZyh0cnVlKTtcbiAgICBzZXRTYXZlTWVzc2FnZShudWxsKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL2FjYWRlbWljLXNldHVwJyksIHtcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgLi4uKGF1dGhUb2tlbiA/IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke2F1dGhUb2tlbn1gIH0gOiB7fSksXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgXG4gICAgICAgICAgYWNhZGVtaWNZZWFyLCBcbiAgICAgICAgICBkYXlzOiBBcnJheS5mcm9tKHsgbGVuZ3RoOiA4IH0sIChfLCBpbmRleCkgPT4gKHsgXG4gICAgICAgICAgICBkYXlOdW1iZXI6IGluZGV4ICsgMSwgXG4gICAgICAgICAgICBzZXNzaW9uTmFtZTogc2Vzc2lvbk5hbWVzW2luZGV4ICsgMV0gfHwgZGVmYXVsdFN1Z2dlc3RlZE5hbWVzW2luZGV4ICsgMV0ubmFtZSBcbiAgICAgICAgICB9KSkgXG4gICAgICAgIH0pLFxuICAgICAgfSk7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgICAgaWYgKCFyZXNwb25zZS5vayB8fCAhZGF0YT8uc3VjY2VzcykgdGhyb3cgbmV3IEVycm9yKGRhdGE/LmVycm9yIHx8IGBVbmFibGUgdG8gc2F2ZSBhY2FkZW1pYyB0ZXJtICgke3Jlc3BvbnNlLnN0YXR1c30pLmApO1xuICAgICAgc2V0U2F2ZU1lc3NhZ2UoJ0FjYWRlbWljIHRlcm0gc2F2ZWQgc3VjY2Vzc2Z1bGx5LicpO1xuICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcbiAgICAgIG9uU2V0dXBTYXZlZD8uKCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZShlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmFibGUgdG8gc2F2ZSBhY2FkZW1pYyB0ZXJtLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1NhdmluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHVwZGF0ZVNlc3Npb25OYW1lID0gKGRheU51bWJlcjogbnVtYmVyLCBzZXNzaW9uTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2Vzc2lvbk5hbWVzKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBbZGF5TnVtYmVyXTogc2Vzc2lvbk5hbWUgfSkpO1xuICAgIHNldFNhdmVNZXNzYWdlKG51bGwpO1xuICB9O1xuXG4gIGNvbnN0IGZpbHRlcmVkRGF5cyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IDggfSwgKF8sIGkpID0+IGkgKyAxKS5maWx0ZXIoKGRheU51bSkgPT4ge1xuICAgIGNvbnN0IG1ldGEgPSBkZWZhdWx0U3VnZ2VzdGVkTmFtZXNbZGF5TnVtXTtcbiAgICBjb25zdCBuYW1lID0gc2Vzc2lvbk5hbWVzW2RheU51bV0gfHwgbWV0YS5uYW1lO1xuICAgIGNvbnN0IHF1ZXJ5ID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gKFxuICAgICAgbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxuICAgICAgbWV0YS5tb250aC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxuICAgICAgbWV0YS50b3BpYy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxuICAgICAgbWV0YS5sb2NhdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxuICAgICAgYGRheSAke2RheU51bX1gLmluY2x1ZGVzKHF1ZXJ5KVxuICAgICk7XG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS04XCI+XG4gICAgICB7LyogVG9wIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCBzbTpmbGV4LXJvdyBzbTppdGVtcy1lbmQgc206anVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ib3JkZXIvNTAgcGItNlwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kIHNtOnRleHQtM3hsXCI+XG4gICAgICAgICAgICBBY2FkZW1pYyBUZXJtXG4gICAgICAgICAgPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0xXCI+XG4gICAgICAgICAgICB7YWNhZGVtaWNZZWFyfSBBY2FkZW1pYyBUZXJtIOKAoiA4IEN1cnJpY3VsdW0gTWlsZXN0b25lcyAoRmViIOKAkyBBcHIpXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgIDxCdXR0b24gXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3NhdmVTZXR1cH0gXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgaXNTYXZpbmd9XG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTYXZlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57aXNTYXZpbmcgPyAnU2F2aW5nLi4uJyA6ICdTYXZlIFRlcm0nfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8QnV0dG9uIFxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiIFxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldElzRWRpdGluZyh0cnVlKTsgc2V0U2F2ZU1lc3NhZ2UobnVsbCk7IH19IFxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RWRpdDMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkVkaXQgVGVybTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNZXNzYWdlcyAqL31cbiAgICAgIHtlcnJvck1lc3NhZ2UgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1kZXN0cnVjdGl2ZS8yMCBiZy1kZXN0cnVjdGl2ZS8xMCBwLTQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWRlc3RydWN0aXZlXCI+XG4gICAgICAgICAge2Vycm9yTWVzc2FnZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7c2F2ZU1lc3NhZ2UgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvMzAgcC00IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgIDxzcGFuPntzYXZlTWVzc2FnZX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFNlYXJjaCBCYXIgJiBFZGl0IENvbnRyb2xzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBzZXNzaW9ucywgdG9waWNzLCBsb2NhdGlvbnMuLi5cIlxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgYm9yZGVyIGJvcmRlci1ib3JkZXIvNzAgcm91bmRlZC14bCBwbC0xMCBwci00IHB5LTIgdGV4dC1zbSB0ZXh0LWZvcmVncm91bmQgcGxhY2Vob2xkZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItcHJpbWFyeVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2lzRWRpdGluZyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkFjYWRlbWljIFllYXI6PC9zcGFuPlxuICAgICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCBib3JkZXIgYm9yZGVyLWJvcmRlci83MCByb3VuZGVkLWxnIHB4LTMgcHktMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmQgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1wcmltYXJ5XCIgXG4gICAgICAgICAgICAgIHZhbHVlPXthY2FkZW1pY1llYXJ9IFxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjIwMjYtMjAyN1wiIFxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHsgc2V0QWNhZGVtaWNZZWFyKGUudGFyZ2V0LnZhbHVlKTsgc2V0U2F2ZU1lc3NhZ2UobnVsbCk7IH19IFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ2xlYW4gR3JpZCBvZiBDYXJkcyB3aXRoIFByb3BlciBUZXh0IFNwYWNpbmcgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAge2ZpbHRlcmVkRGF5cy5tYXAoKGRheU51bWJlcikgPT4ge1xuICAgICAgICAgIGNvbnN0IG1ldGEgPSBkZWZhdWx0U3VnZ2VzdGVkTmFtZXNbZGF5TnVtYmVyXTtcbiAgICAgICAgICBjb25zdCBzZXNzaW9uTmFtZSA9IHNlc3Npb25OYW1lc1tkYXlOdW1iZXJdIHx8IG1ldGEubmFtZTtcbiAgICAgICAgICBjb25zdCBsaW5rZWRNb2R1bGUgPSBtb2R1bGVzLmZpbmQoKG0pID0+IG0uZGF5TnVtYmVyID09PSBkYXlOdW1iZXIgfHwgbS5tb2R1bGVOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2Vzc2lvbk5hbWUudG9Mb3dlckNhc2UoKSkpO1xuXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxDYXJkIGtleT17ZGF5TnVtYmVyfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTYgc3BhY2UteS00IGhvdmVyOmJvcmRlci1wcmltYXJ5LzUwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInAtMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICB7LyogSGVhZGVyIFRhZyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5EYXkgMHtkYXlOdW1iZXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGZvbnQtc2VtaWJvbGRcIj57bWV0YS5tb250aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogVGl0bGUgKi99XG4gICAgICAgICAgICAgICAge2lzRWRpdGluZyA/IChcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHB4LTMgcHktMiB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgb3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nlc3Npb25OYW1lc1tkYXlOdW1iZXJdIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17bWV0YS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZVNlc3Npb25OYW1lKGRheU51bWJlciwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCBsZWFkaW5nLXNudWdcIj5cbiAgICAgICAgICAgICAgICAgICAge3Nlc3Npb25OYW1lfVxuICAgICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBEZXNjcmlwdGlvbiAqL31cbiAgICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAge21ldGEuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cblxuICAgICAgICAgICAgICB7LyogQ29udGVudCAvIE1ldGFkYXRhIHdpdGggUHJvcGVyIFNwYWNpbmcgKi99XG4gICAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJwLTAgcHQtMyBzcGFjZS15LTIuNSBib3JkZXItdCBib3JkZXItYm9yZGVyLzQwXCI+XG4gICAgICAgICAgICAgICAgey8qIFRvcGljICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgPEJvb2tPcGVuIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5IHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtbWVkaXVtXCI+e2xpbmtlZE1vZHVsZT8udG9waWMgfHwgbWV0YS50b3BpY308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogTG9jYXRpb24gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57bWV0YS5sb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQWNhZGVtaWNTZXR1cFZpZXcudHN4In0=