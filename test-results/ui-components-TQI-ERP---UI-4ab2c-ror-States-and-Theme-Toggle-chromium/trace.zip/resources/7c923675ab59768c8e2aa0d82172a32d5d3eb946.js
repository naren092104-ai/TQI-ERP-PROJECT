import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LessonPlanView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Search, CheckCircle2, AlertTriangle, X } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const LessonPlanView = ({
  lessonPlans = [],
  sessions = [],
  panchayats = [],
  volunteers = [],
  selectedLessonPlanId,
  onNavigate,
  onAddLessonPlan,
  onUpdateLessonPlan,
  onDeleteLessonPlan
}) => {
  _s();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPanchayat, setSelectedPanchayat] = useState("all");
  const [selectedVillage, setSelectedVillage] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [selectedVolunteer, setSelectedVolunteer] = useState("all");
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [activePlanDetail, setActivePlanDetail] = useState(() => {
    if (selectedLessonPlanId) {
      const found = lessonPlans.find((lp) => lp.id === selectedLessonPlanId || lp.sessionId === selectedLessonPlanId);
      return found || lessonPlans[0] || null;
    }
    return null;
  });
  const [isCorrectionModalOpen, setIsCorrectionModalOpen] = useState(false);
  const [correctionReasonInput, setCorrectionReasonInput] = useState("");
  const [formData, setFormData] = useState({
    id: "",
    topic: "",
    moduleName: "Spoken English",
    moduleId: "M-103",
    targetStandard: "6th - 8th Standard",
    duration: "90 Mins",
    panchayatId: panchayats[0]?.id || "vedakkattamaduvu",
    panchayatName: panchayats[0]?.name || "Vedakkattamaduvu",
    villageName: panchayats[0]?.villages[0]?.name || "Ammapettai",
    volunteerId: volunteers[0]?.id || "vol-1",
    volunteerName: volunteers[0]?.name || "Bala",
    date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    dayOfSession: "Saturday",
    objective: "",
    learningOutcomesText: "",
    introduction: "",
    activity: "",
    activitiesListText: "",
    teachingMethod: "",
    materialsText: "",
    assessmentTask: "",
    notes: "",
    status: "Draft"
  });
  const [formErrors, setFormErrors] = useState({});
  const currentFilterVillages = useMemo(() => {
    if (selectedPanchayat === "all") {
      const allVillages = [];
      panchayats.forEach((p) => {
        p.villages?.forEach((v) => {
          if (!allVillages.some((existing) => existing.name === v.name)) {
            allVillages.push({ id: v.id, name: v.name });
          }
        });
      });
      return allVillages;
    }
    const found = panchayats.find((p) => p.id === selectedPanchayat);
    return found?.villages || [];
  }, [selectedPanchayat, panchayats]);
  const modalVillages = useMemo(() => {
    const found = panchayats.find((p) => p.id === formData.panchayatId);
    return found?.villages || [];
  }, [formData.panchayatId, panchayats]);
  const getPlanTopic = (lp) => {
    return lp.topic || lp.title || lp.sessionName || "Untitled Lesson Plan";
  };
  const getPlanModule = (lp) => {
    return lp.moduleName || lp.moduleId || "General Curriculum";
  };
  const filteredPlans = useMemo(() => {
    return lessonPlans.filter((lp) => {
      const topic = getPlanTopic(lp).toLowerCase();
      const mod = getPlanModule(lp).toLowerCase();
      const vill = (lp.villageName || "").toLowerCase();
      const vol = (lp.volunteerName || "").toLowerCase();
      const pan = (lp.panchayatName || "").toLowerCase();
      const search = searchTerm.toLowerCase().trim();
      const matchSearch = !search || topic.includes(search) || mod.includes(search) || vill.includes(search) || vol.includes(search) || pan.includes(search) || (lp.objective || "").toLowerCase().includes(search);
      const matchPanchayat = selectedPanchayat === "all" || lp.panchayatId === selectedPanchayat;
      const matchVillage = selectedVillage === "all" || (lp.villageName || "").toLowerCase() === selectedVillage.toLowerCase();
      const matchStatus = selectedStatus === "all" || (lp.status || "").toLowerCase() === selectedStatus.toLowerCase();
      const matchVolunteer = selectedVolunteer === "all" || lp.volunteerId === selectedVolunteer || (lp.volunteerName || "").toLowerCase() === selectedVolunteer.toLowerCase();
      return matchSearch && matchPanchayat && matchVillage && matchStatus && matchVolunteer;
    });
  }, [lessonPlans, searchTerm, selectedPanchayat, selectedVillage, selectedStatus, selectedVolunteer]);
  const totalCount = lessonPlans.length;
  const approvedCount = lessonPlans.filter(
    (lp) => lp.status === "Approved" || lp.status === "Completed" || lp.status === "Active"
  ).length;
  const submittedCount = lessonPlans.filter(
    (lp) => lp.status === "Submitted" || lp.status === "Resubmitted" || lp.status === "Upcoming"
  ).length;
  const correctionCount = lessonPlans.filter(
    (lp) => lp.status === "Correction Requested"
  ).length;
  const handleClearFilters = () => {
    setSearchTerm("");
    setSelectedPanchayat("all");
    setSelectedVillage("all");
    setSelectedStatus("all");
    setSelectedVolunteer("all");
  };
  const handleOpenNewModal = () => {
    setIsEditMode(false);
    setFormErrors({});
    const defaultP = panchayats[0];
    setFormData({
      id: "",
      topic: "",
      moduleName: "Spoken English",
      moduleId: "M-103",
      targetStandard: "6th - 8th Standard",
      duration: "90 Mins",
      panchayatId: defaultP?.id || "vedakkattamaduvu",
      panchayatName: defaultP?.name || "Vedakkattamaduvu",
      villageName: defaultP?.villages[0]?.name || "Ammapettai",
      volunteerId: volunteers[0]?.id || "vol-1",
      volunteerName: volunteers[0]?.name || "Bala",
      date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      dayOfSession: "Saturday",
      objective: "",
      learningOutcomesText: "1. Recognize core vocabulary words in real dialogue\n2. Form 3-5 full sentences independently\n3. Participate in group roleplay challenge",
      introduction: "10-minute warm-up game and review of previous module concepts.",
      activity: "Interactive group worksheets and structured role-play drills in pairs.",
      activitiesListText: "Warm-up & Icebreaker (15 mins)\nConcept Demonstration on Whiteboard (25 mins)\nGroup Activity & Worksheets (30 mins)\nExit Slip & Vocabulary Quiz (20 mins)",
      teachingMethod: "Visual demonstration, peer group problem solving, interactive worksheets.",
      materialsText: "Flashcards, Worksheets (30 copies), Whiteboard markers, Student reward stickers",
      assessmentTask: "Exit slip quiz with 3 short conceptual questions evaluated in peer pairs.",
      notes: "Keep extra craft kits in center bag.",
      status: "Draft"
    });
    setIsNewModalOpen(true);
  };
  const handleOpenEditModal = (plan) => {
    setIsEditMode(true);
    setFormErrors({});
    setFormData({
      id: plan.id,
      topic: plan.topic || plan.title || plan.sessionName || "",
      moduleName: plan.moduleName || "Spoken English",
      moduleId: plan.moduleId || "M-103",
      targetStandard: plan.targetStandard || "6th - 8th Standard",
      duration: plan.duration || "90 Mins",
      panchayatId: plan.panchayatId || panchayats[0]?.id || "",
      panchayatName: plan.panchayatName || panchayats[0]?.name || "",
      villageName: plan.villageName || "",
      volunteerId: plan.volunteerId || volunteers[0]?.id || "",
      volunteerName: plan.volunteerName || "Bala",
      date: plan.date || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      dayOfSession: plan.dayOfSession || "Saturday",
      objective: plan.objective || "",
      learningOutcomesText: plan.learningOutcomes?.join("\n") || "",
      introduction: plan.introduction || "",
      activity: plan.activity || "",
      activitiesListText: plan.activitiesList?.join("\n") || "",
      teachingMethod: plan.teachingMethod || "",
      materialsText: Array.isArray(plan.materials) ? plan.materials.join(", ") : plan.materialsList?.join("\n") || plan.materials || "",
      assessmentTask: plan.assessmentTask || "",
      notes: plan.notes || "",
      status: plan.status || "Draft"
    });
    setIsNewModalOpen(true);
  };
  const handleFormSubmit = (targetStatus) => {
    const errors = {};
    if (!formData.topic.trim()) errors.topic = "Topic / Title is required.";
    if (!formData.objective.trim()) errors.objective = "Objective is required.";
    if (!formData.villageName.trim()) errors.villageName = "Please select a village center.";
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    const learningOutcomes = formData.learningOutcomesText.split("\n").map((s) => s.trim()).filter(Boolean);
    const activitiesList = formData.activitiesListText.split("\n").map((s) => s.trim()).filter(Boolean);
    const materialsList = formData.materialsText.split("\n").map((s) => s.trim()).filter(Boolean);
    const payload = {
      topic: formData.topic.trim(),
      title: formData.topic.trim(),
      moduleName: formData.moduleName,
      moduleId: formData.moduleId,
      targetStandard: formData.targetStandard,
      duration: formData.duration,
      panchayatId: formData.panchayatId,
      panchayatName: formData.panchayatName,
      villageName: formData.villageName,
      volunteerId: formData.volunteerId,
      volunteerName: formData.volunteerName,
      date: formData.date,
      dayOfSession: formData.dayOfSession,
      objective: formData.objective.trim(),
      learningOutcomes: learningOutcomes.length > 0 ? learningOutcomes : [formData.objective.trim()],
      introduction: formData.introduction,
      activity: formData.activity,
      activitiesList: activitiesList.length > 0 ? activitiesList : [formData.activity],
      teachingMethod: formData.teachingMethod,
      materials: formData.materialsText,
      materialsList,
      assessmentTask: formData.assessmentTask,
      notes: formData.notes,
      status: targetStatus,
      lastUpdated: `${(/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}, ${(/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    };
    if (isEditMode && formData.id) {
      onUpdateLessonPlan(formData.id, payload);
      if (activePlanDetail?.id === formData.id) {
        setActivePlanDetail((prev) => prev ? { ...prev, ...payload } : null);
      }
    } else {
      const newPlan = {
        ...payload,
        sessionName: formData.topic.trim(),
        volunteersCount: 3,
        cluster: "Dharmapuri",
        spoc: formData.volunteerName,
        financer: "Cluster Fund"
      };
      onAddLessonPlan(newPlan);
    }
    setIsNewModalOpen(false);
  };
  const handleApprovePlan = (planId) => {
    onUpdateLessonPlan(planId, {
      status: "Approved",
      correctionReason: void 0,
      correctionRequestedBy: void 0,
      lastUpdated: "Just now by Cluster Admin"
    });
    if (activePlanDetail?.id === planId) {
      setActivePlanDetail((prev) => prev ? { ...prev, status: "Approved", correctionReason: void 0 } : null);
    }
  };
  const handleSubmitCorrection = () => {
    if (!activePlanDetail || !correctionReasonInput.trim()) return;
    onUpdateLessonPlan(activePlanDetail.id, {
      status: "Correction Requested",
      correctionReason: correctionReasonInput.trim(),
      correctionRequestedBy: "Cluster Admin",
      correctionDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      lastUpdated: "Correction requested"
    });
    setActivePlanDetail(
      (prev) => prev ? {
        ...prev,
        status: "Correction Requested",
        correctionReason: correctionReasonInput.trim(),
        correctionRequestedBy: "Cluster Admin",
        correctionDate: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
      } : null
    );
    setIsCorrectionModalOpen(false);
    setCorrectionReasonInput("");
  };
  const handlePrintPDF = (plan) => {
    const target = plan || activePlanDetail || filteredPlans[0];
    if (!target) {
      alert("No lesson plan available to export.");
      return;
    }
    window.print();
  };
  const renderStatusBadge = (status) => {
    switch (status) {
      case "Approved":
      case "Active":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 377,
            columnNumber: 13
          }, this),
          "Approved"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 376,
          columnNumber: 11
        }, this);
      case "Submitted":
      case "Resubmitted":
      case "Upcoming":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 386,
            columnNumber: 13
          }, this),
          status === "Resubmitted" ? "Resubmitted" : "Submitted"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 385,
          columnNumber: 11
        }, this);
      case "Correction Requested":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-amber-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 393,
            columnNumber: 13
          }, this),
          "Correction Requested"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 392,
          columnNumber: 11
        }, this);
      case "Completed":
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-slate-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 400,
            columnNumber: 13
          }, this),
          "Completed"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 399,
          columnNumber: 11
        }, this);
      case "Draft":
      default:
        return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-slate-400" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 408,
            columnNumber: 13
          }, this),
          "Draft"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 407,
          columnNumber: 11
        }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Lesson Plans" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 420,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Manage, review, and track curriculum lesson plans and learning activities across clusters." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 423,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 419,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 self-start sm:self-auto", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => handlePrintPDF(),
            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Export PDF" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 434,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 429,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleOpenNewModal,
            className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-3.5 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "New Lesson Plan" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 441,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 436,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 428,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 418,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Plans" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 449,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: totalCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 450,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 448,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-success-500", children: "Approved" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 454,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: approvedCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 455,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 453,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-brand-500", children: "Submitted / Review" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 459,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: submittedCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 460,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 458,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-warning-500", children: "Needs Correction" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 464,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: correctionCount }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 465,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 463,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 447,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative sm:col-span-2 lg:col-span-2", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 473,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            placeholder: "Search by topic, module, volunteer or village...",
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-8 py-2 text-xs text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 474,
            columnNumber: 11
          },
          this
        ),
        searchTerm && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setSearchTerm(""),
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 487,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 482,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 472,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          value: selectedPanchayat || "all",
          onValueChange: (val) => {
            setSelectedPanchayat(val);
            setSelectedVillage("all");
          },
          children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Panchayats" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 502,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 501,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: [
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Panchayats" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 505,
                columnNumber: 17
              }, this),
              panchayats.map(
                (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 507,
                  columnNumber: 15
                }, this)
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 504,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 494,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 493,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          value: selectedVillage || "all",
          onValueChange: (val) => setSelectedVillage(val),
          children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Villages" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 522,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 521,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: [
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Villages" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 525,
                columnNumber: 17
              }, this),
              currentFilterVillages.map(
                (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 527,
                  columnNumber: 15
                }, this)
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 524,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 517,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 516,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          value: selectedStatus || "all",
          onValueChange: (val) => setSelectedStatus(val),
          children: [
            /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Statuses" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 542,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 541,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(SelectContent, { children: [
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Statuses" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 545,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Approved", children: "Approved" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 546,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Submitted", children: "Submitted" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 547,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Correction Requested", children: "Correction Requested" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 548,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Resubmitted", children: "Resubmitted" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 549,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Draft", children: "Draft" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 550,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(SelectItem, { value: "Completed", children: "Completed" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 551,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 544,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 537,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 536,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 470,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md shadow-xs overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-xs", children: [
      /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]", children: [
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Date & Module" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 563,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Topic & Learning Objective" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 564,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Panchayat & Village" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 565,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Volunteer" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 566,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5", children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 567,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3.5 text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 568,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 562,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 561,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-100 text-slate-700", children: filteredPlans.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 6, className: "py-10 text-center text-slate-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[32px] text-slate-300", children: "menu_book" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 576,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-sm text-slate-700", children: "No lesson plans found" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 579,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 max-w-sm", children: "Try adjusting your filters or create a new lesson plan." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 580,
          columnNumber: 23
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleClearFilters,
            className: "mt-1 px-3 py-1 text-xs font-semibold text-[#0B3D91] bg-blue-50 rounded-md hover:bg-blue-100 transition-colors",
            children: "Reset Filters"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 583,
            columnNumber: 23
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 575,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 574,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 573,
        columnNumber: 15
      }, this) : filteredPlans.map((plan) => {
        const isCorrectionReq = plan.status === "Correction Requested";
        return /* @__PURE__ */ jsxDEV(
          "tr",
          {
            className: `hover:bg-slate-50/80 transition-colors group ${isCorrectionReq ? "bg-amber-50/30" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5 whitespace-nowrap", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-slate-900", children: plan.date || "28 Aug 2026" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 605,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500 flex items-center gap-1 mt-0.5", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-slate-600 bg-slate-100 px-1 py-0.2 rounded text-[10px]", children: plan.moduleId || "M-103" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 607,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "•" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 610,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: getPlanModule(plan) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 611,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 606,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 604,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5 max-w-xs", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-slate-900 group-hover:text-[#0B3D91] transition-colors", children: getPlanTopic(plan) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 617,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500 line-clamp-1 mt-0.5", children: plan.objective || plan.description || "Core curriculum learning objective" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 620,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 616,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-slate-800", children: plan.panchayatName || "Vedakkattamaduvu" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 627,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500", children: plan.villageName || "Ammapettai" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 628,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 626,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5", children: /* @__PURE__ */ jsxDEV("div", { className: "font-medium text-slate-900 flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-5 h-5 rounded-full bg-[#0B3D91]/10 text-[#0B3D91] text-[10px] font-bold flex items-center justify-center", children: (plan.volunteerName || "B").charAt(0) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 634,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: plan.volunteerName || "Bala" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 637,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 633,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 632,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5 whitespace-nowrap", children: renderStatusBadge(plan.status) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 642,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "py-3 px-3.5 text-right whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-end gap-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setActivePlanDetail(plan),
                    className: "px-2.5 py-1 bg-white border border-slate-300 text-slate-700 hover:text-[#0B3D91] hover:bg-slate-50 rounded text-xs font-semibold shadow-2xs transition-colors cursor-pointer",
                    children: "View Plan"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 649,
                    columnNumber: 27
                  },
                  this
                ),
                plan.status === "Submitted" || plan.status === "Resubmitted" ? /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleApprovePlan(plan.id),
                    className: "px-2 py-1 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded text-xs font-semibold transition-colors cursor-pointer",
                    title: "Approve Lesson Plan",
                    children: "Approve"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 658,
                    columnNumber: 25
                  },
                  this
                ) : null,
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleOpenEditModal(plan),
                    className: "p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition-colors cursor-pointer",
                    title: "Edit Lesson Plan",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 672,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 667,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 648,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 647,
                columnNumber: 23
              }, this)
            ]
          },
          plan.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 597,
            columnNumber: 19
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 571,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 560,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 559,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 558,
      columnNumber: 7
    }, this),
    activePlanDetail && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-gray-900/70 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-3xl w-full max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-slate-200 bg-slate-50/70 rounded-t-xl flex items-start justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono font-bold bg-[#0B3D91]/10 text-[#0B3D91] px-2 py-0.5 rounded", children: activePlanDetail.moduleId || "M-103" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 693,
              columnNumber: 19
            }, this),
            renderStatusBadge(activePlanDetail.status),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 font-medium", children: [
              "Duration: ",
              activePlanDetail.duration || "90 Mins"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 697,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 692,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-slate-900", children: getPlanTopic(activePlanDetail) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 701,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: [
            getPlanModule(activePlanDetail),
            " • Standard: ",
            activePlanDetail.targetStandard || "6th - 8th Standard",
            " • ",
            activePlanDetail.panchayatName,
            " (",
            activePlanDetail.villageName,
            ")"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 704,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 691,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handlePrintPDF(activePlanDetail),
              className: "px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-md transition-colors flex items-center gap-1 cursor-pointer",
              title: "Print / Save PDF",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "print" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 715,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "Print" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                  lineNumber: 716,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 710,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActivePlanDetail(null),
              className: "text-slate-400 hover:text-slate-600 p-1.5 rounded-md hover:bg-slate-200 transition-colors",
              children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 722,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 718,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 709,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 690,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto space-y-5 text-xs", children: [
        activePlanDetail.status === "Correction Requested" && activePlanDetail.correctionReason && /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 border border-amber-300 rounded-md p-3.5 space-y-1.5 text-amber-900", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 font-bold text-xs text-amber-900", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-amber-700", children: "warning" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 734,
                columnNumber: 23
              }, this),
              "Correction Requested by ",
              activePlanDetail.correctionRequestedBy || "Cluster Admin",
              " (",
              activePlanDetail.correctionDate || "Recent",
              ")"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 733,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  const p = activePlanDetail;
                  setActivePlanDetail(null);
                  handleOpenEditModal(p);
                },
                className: "px-2.5 py-1 bg-amber-700 hover:bg-amber-800 text-white font-semibold rounded text-[11px] shadow-2xs",
                children: "Edit & Resubmit Plan"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 737,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 732,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-amber-800 leading-relaxed font-medium pl-5", children: [
            '"',
            activePlanDetail.correctionReason,
            '"'
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 748,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 731,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-slate-200 rounded-md p-4 space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-slate-900 uppercase tracking-wider text-[11px]", children: "Primary Objective" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 757,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-800 font-medium text-xs mt-1", children: activePlanDetail.objective || activePlanDetail.description || "Students will understand key foundational concepts through hands-on exercises." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 760,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 756,
            columnNumber: 17
          }, this),
          activePlanDetail.learningOutcomes && activePlanDetail.learningOutcomes.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "border-t border-slate-100 pt-2.5", children: [
            /* @__PURE__ */ jsxDEV("h5", { className: "text-[11px] font-bold text-slate-600 mb-1.5", children: "Expected Learning Outcomes:" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 767,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1 pl-4 list-disc text-slate-700", children: activePlanDetail.learningOutcomes.map(
              (item, idx) => /* @__PURE__ */ jsxDEV("li", { className: "leading-normal", children: item }, idx, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 772,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 770,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 766,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 755,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50/70 border border-slate-200 rounded-md p-4 space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-slate-900 uppercase tracking-wider text-[11px]", children: "Session Activity & Time Breakdown (90 Mins)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 782,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold text-slate-500", children: [
              "Method: ",
              activePlanDetail.teachingMethod || "Interactive Peer Practice"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 785,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 781,
            columnNumber: 17
          }, this),
          activePlanDetail.activitiesList && activePlanDetail.activitiesList.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: activePlanDetail.activitiesList.map(
            (step, idx) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "p-2.5 bg-white border border-slate-200 rounded-md text-slate-700 flex items-start gap-2.5",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 rounded-full bg-[#0B3D91]/10 text-[#0B3D91] font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5", children: idx + 1 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 797,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "leading-relaxed", children: step }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 800,
                    columnNumber: 25
                  }, this)
                ]
              },
              idx,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 793,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 791,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-white border border-slate-200 rounded-md text-slate-700", children: activePlanDetail.activity || "Structured group worksheets, interactive drills, and presentation." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 805,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 780,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border border-slate-200 rounded-md p-3.5 bg-white space-y-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-800 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-[#0B3D91]", children: "inventory_2" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 816,
                columnNumber: 21
              }, this),
              "Materials & Teaching Aids"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 815,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-slate-600 space-y-1", children: activePlanDetail.materialsList && activePlanDetail.materialsList.length > 0 ? /* @__PURE__ */ jsxDEV("ul", { className: "list-disc pl-4 space-y-0.5", children: activePlanDetail.materialsList.map(
              (m, i) => /* @__PURE__ */ jsxDEV("li", { children: m }, i, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 825,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 823,
              columnNumber: 19
            }, this) : /* @__PURE__ */ jsxDEV("p", { children: Array.isArray(activePlanDetail.materials) ? activePlanDetail.materials.join(", ") : activePlanDetail.materials || "Standard classroom stationery kit and worksheets." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 829,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 821,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 814,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border border-slate-200 rounded-md p-3.5 bg-white space-y-2", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-800 flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px] text-emerald-600", children: "fact_check" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 837,
                columnNumber: 21
              }, this),
              "Evaluation & Exit Assessment"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 836,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 leading-relaxed", children: activePlanDetail.assessmentTask || "Exit slip quiz with 3 short conceptual questions evaluated in peer pairs." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 842,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 835,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 812,
          columnNumber: 15
        }, this),
        activePlanDetail.notes && /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-md p-3 space-y-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold uppercase text-slate-500 tracking-wider", children: "Volunteer Guidance & Center Logistics" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 851,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: activePlanDetail.notes }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 854,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 850,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 728,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-2 rounded-b-xl", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActivePlanDetail(null),
            className: "px-4 py-1.5 border border-slate-300 text-slate-700 hover:bg-white text-xs font-semibold rounded-md transition-colors cursor-pointer",
            children: "Close Preview"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 862,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 861,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                const p = activePlanDetail;
                setActivePlanDetail(null);
                handleOpenEditModal(p);
              },
              className: "px-3.5 py-1.5 border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer",
              children: "Edit Plan"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 871,
              columnNumber: 17
            },
            this
          ),
          activePlanDetail.status !== "Approved" && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setCorrectionReasonInput("");
                setIsCorrectionModalOpen(true);
              },
              className: "px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: "Request Correction"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 883,
              columnNumber: 15
            },
            this
          ),
          activePlanDetail.status !== "Approved" && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => handleApprovePlan(activePlanDetail.id),
              className: "px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: "Approve Plan"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 895,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 870,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 860,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 688,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 687,
      columnNumber: 7
    }, this),
    isNewModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-gray-900/70 backdrop-blur-sm overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-2xl w-full max-h-[92vh] flex flex-col my-auto animate-in fade-in zoom-in-95 duration-150", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50 rounded-t-xl", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-slate-900", children: isEditMode ? "Edit Lesson Plan" : "Create New Lesson Plan" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 915,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Prepare curriculum, activities, and resources for upcoming sessions." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 918,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 914,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsNewModalOpen(false),
            className: "text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-100 transition-colors cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 926,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 922,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 913,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 overflow-y-auto space-y-4 text-xs", children: [
        isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || "") && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-xl p-3 flex items-center gap-2 text-sm text-gray-700", children: [
          /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 text-success-500" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 934,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "This lesson plan has been ",
            activePlanDetail?.status.toLowerCase(),
            " and cannot be edited."
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 935,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 933,
          columnNumber: 13
        }, this),
        isEditMode && activePlanDetail?.status === "Correction Requested" && /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center gap-2 text-sm text-amber-800", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-5 h-5 text-amber-600" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 940,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Correction Requested: ",
            activePlanDetail.correctionReason
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 941,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 939,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Lesson Topic / Title ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 949,
                columnNumber: 42
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 948,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: formData.topic,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onChange: (e) => {
                  setFormData({ ...formData, topic: e.target.value });
                  if (formErrors.topic) setFormErrors({ ...formErrors, topic: "" });
                },
                placeholder: "e.g. Basic Conversation & Dialogue Drills",
                className: `w-full px-3 py-2 border rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50 ${formErrors.topic ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 951,
                columnNumber: 19
              },
              this
            ),
            formErrors.topic && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.topic }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 965,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 947,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Curriculum Module" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 970,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.moduleName,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onValueChange: (mod) => {
                  let modId = "M-103";
                  if (mod === "Basic Math") modId = "M-301";
                  if (mod === "Life Skills") modId = "M-102";
                  if (mod === "Digital Literacy") modId = "D-004";
                  if (mod === "Science") modId = "S-201";
                  if (mod === "Financial Literacy") modId = "F-101";
                  setFormData({ ...formData, moduleName: mod, moduleId: modId });
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Module" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 987,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 986,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Spoken English", children: "Spoken English (M-103)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 990,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Basic Math", children: "Basic Math (M-301)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 991,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Life Skills", children: "Life Skills (M-102)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 992,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Digital Literacy", children: "Digital Literacy (D-004)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 993,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Science", children: "Science (S-201)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 994,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "Financial Literacy", children: "Financial Literacy (F-101)" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 995,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 989,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 973,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 969,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 946,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Target Standard / Grade" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1004,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.targetStandard,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onValueChange: (val) => setFormData({ ...formData, targetStandard: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-9 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Target Standard" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1013,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1012,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "4th - 5th Standard", children: "4th - 5th Standard" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1016,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "6th - 8th Standard", children: "6th - 8th Standard" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1017,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "9th - 10th Standard", children: "9th - 10th Standard" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1018,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1015,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1007,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1003,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Duration" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1024,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: formData.duration,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onChange: (e) => setFormData({ ...formData, duration: e.target.value }),
                placeholder: "90 Mins",
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1027,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1023,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Session Date" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1038,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: formData.date,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onChange: (e) => setFormData({ ...formData, date: e.target.value }),
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1041,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1037,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1002,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3.5 bg-slate-50/70 p-3 rounded-md border border-slate-200", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Panchayat ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1055,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1054,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.panchayatId,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onValueChange: (val) => {
                  const found = panchayats.find((p) => p.id === val);
                  if (found) {
                    setFormData({
                      ...formData,
                      panchayatId: found.id,
                      panchayatName: found.name,
                      villageName: found.villages[0]?.name || "Main Center"
                    });
                  }
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-8 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1073,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1072,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1077,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1075,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1057,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1053,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
              "Village Center ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1087,
                columnNumber: 36
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1086,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.villageName,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onValueChange: (val) => {
                  setFormData({ ...formData, villageName: val });
                  if (formErrors.villageName) setFormErrors({ ...formErrors, villageName: "" });
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: `w-full h-8 text-xs ${formErrors.villageName ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`, children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Village Center" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1100,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1097,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: modalVillages.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1104,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1102,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1089,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1085,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Volunteer Lead" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1113,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.volunteerId,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onValueChange: (val) => {
                  const found = volunteers.find((v) => v.id === val);
                  if (found) {
                    setFormData({ ...formData, volunteerId: found.id, volunteerName: found.name });
                  }
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-8 text-xs border-slate-300", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Volunteer" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1127,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1126,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: volunteers.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.id, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                      lineNumber: 1131,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                    lineNumber: 1129,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1116,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1112,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1052,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
            "Primary Learning Objective ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1143,
              columnNumber: 46
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1142,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 2,
              value: formData.objective,
              disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
              onChange: (e) => {
                setFormData({ ...formData, objective: e.target.value });
                if (formErrors.objective) setFormErrors({ ...formErrors, objective: "" });
              },
              placeholder: "State the core outcome students will achieve by the end of 90 minutes...",
              className: `w-full px-3 py-2 border rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50 ${formErrors.objective ? "border-rose-400 bg-rose-50/30" : "border-slate-300"}`
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1145,
              columnNumber: 17
            },
            this
          ),
          formErrors.objective && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-rose-600 mt-1", children: formErrors.objective }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1159,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1141,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Activities & Time Breakdown (one per line)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1165,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 3,
              value: formData.activitiesListText,
              disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
              onChange: (e) => setFormData({ ...formData, activitiesListText: e.target.value }),
              placeholder: "Warm-up & Icebreaker (15 mins)\nConcept Demonstration (25 mins)\nGroup Activity & Practice (30 mins)\nExit Assessment & Quiz (20 mins)",
              className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] font-mono text-[11px] disabled:opacity-50"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1168,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1164,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Materials & Kits Required" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1181,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 2,
                value: formData.materialsText,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onChange: (e) => setFormData({ ...formData, materialsText: e.target.value }),
                placeholder: "Flashcards, 30 Printed Worksheets, Markers, Reward stickers",
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1184,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1180,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Exit Assessment Task" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1195,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 2,
                value: formData.assessmentTask,
                disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
                onChange: (e) => setFormData({ ...formData, assessmentTask: e.target.value }),
                placeholder: "5-question visual fraction puzzle worksheet evaluated in pairs.",
                className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
                lineNumber: 1198,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1194,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1179,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "Remarks / Notes" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1211,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 2,
              value: formData.notes,
              disabled: isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || ""),
              onChange: (e) => setFormData({ ...formData, notes: e.target.value }),
              placeholder: "Volunteer Guidance & Center Logistics...",
              className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91] disabled:opacity-50"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1214,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1210,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 931,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between rounded-b-xl", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setIsNewModalOpen(false),
            className: "px-3.5 py-1.5 border border-slate-300 text-slate-700 hover:bg-white text-xs font-semibold rounded-md transition-colors cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1227,
            columnNumber: 15
          },
          this
        ),
        !(isEditMode && ["Submitted", "Approved", "Completed"].includes(activePlanDetail?.status || "")) && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleFormSubmit("Draft"),
              className: "px-3.5 py-1.5 border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-md transition-colors cursor-pointer",
              children: "Save Draft"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1237,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => handleFormSubmit("Submitted"),
              className: "px-4 py-1.5 bg-[#0B3D91] hover:bg-[#082a66] text-white text-xs font-semibold rounded-md shadow-xs transition-colors cursor-pointer",
              children: isEditMode ? "Save & Submit Plan" : "Submit for Review"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
              lineNumber: 1244,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1236,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 1226,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 911,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 910,
      columnNumber: 7
    }, this),
    isCorrectionModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-gray-900/70 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md border border-slate-200 shadow-sm max-w-md w-full p-5 space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "feedback" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1264,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1263,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-sm font-bold text-slate-900", children: "Request Lesson Plan Correction" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1267,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Provide actionable feedback to the volunteer." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1268,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1266,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 1262,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: [
          "Feedback & Required Revisions ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-rose-500", children: "*" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1274,
            columnNumber: 51
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
          lineNumber: 1273,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 4,
            value: correctionReasonInput,
            onChange: (e) => setCorrectionReasonInput(e.target.value),
            placeholder: "e.g. Please add specific safety instructions for outdoor nature collection and include time breakdown for the second 30-minute block...",
            className: "w-full px-3 py-2 border border-slate-300 rounded-md text-xs focus:outline-none focus:border-[#0B3D91]"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1276,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 1272,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsCorrectionModalOpen(false),
            className: "px-3.5 py-1.5 border border-slate-300 text-slate-700 text-xs font-semibold rounded-md hover:bg-slate-50",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1286,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            disabled: !correctionReasonInput.trim(),
            onClick: handleSubmitCorrection,
            className: "px-4 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-semibold rounded-md shadow-xs",
            children: "Send Request"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
            lineNumber: 1292,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
        lineNumber: 1285,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 1261,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
      lineNumber: 1260,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx",
    lineNumber: 416,
    columnNumber: 5
  }, this);
};
_s(LessonPlanView, "pVzqSU+DGEmgpUUZ/y3/Svq0eUU=");
_c = LessonPlanView;
var _c;
$RefreshReg$(_c, "LessonPlanView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/LessonPlanView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd1hZOztBQXhYWixTQUFnQkEsVUFBVUMsZUFBZTtBQUV6QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxTQUFlQyxRQUFrQkMsY0FBcUJDLGVBQXlCQyxTQUFTO0FBY2pGLGFBQU1DLGlCQUFnREEsQ0FBQztBQUFBLEVBQzVEQyxjQUFjO0FBQUEsRUFDZEMsV0FBVztBQUFBLEVBQ1hDLGFBQWE7QUFBQSxFQUNiQyxhQUFhO0FBQUEsRUFDYkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFFSixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSXZCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN3QixtQkFBbUJDLG9CQUFvQixJQUFJekIsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzBCLGlCQUFpQkMsa0JBQWtCLElBQUkzQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTdCLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUM4QixtQkFBbUJDLG9CQUFvQixJQUFJL0IsU0FBUyxLQUFLO0FBR2hFLFFBQU0sQ0FBQ2dDLGdCQUFnQkMsaUJBQWlCLElBQUlqQyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDa0MsWUFBWUMsYUFBYSxJQUFJbkMsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ29DLGtCQUFrQkMsbUJBQW1CLElBQUlyQyxTQUE0QixNQUFNO0FBQ2hGLFFBQUlnQixzQkFBc0I7QUFDeEIsWUFBTXNCLFFBQVExQixZQUFZMkIsS0FBSyxDQUFDQyxPQUFPQSxHQUFHQyxPQUFPekIsd0JBQXdCd0IsR0FBR0UsY0FBYzFCLG9CQUFvQjtBQUM5RyxhQUFPc0IsU0FBUzFCLFlBQVksQ0FBQyxLQUFLO0FBQUEsSUFDcEM7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDK0IsdUJBQXVCQyx3QkFBd0IsSUFBSTVDLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUM2Qyx1QkFBdUJDLHdCQUF3QixJQUFJOUMsU0FBUyxFQUFFO0FBR3JFLFFBQU0sQ0FBQytDLFVBQVVDLFdBQVcsSUFBSWhELFNBQVM7QUFBQSxJQUN2Q3lDLElBQUk7QUFBQSxJQUNKUSxPQUFPO0FBQUEsSUFDUEMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsVUFBVTtBQUFBLElBQ1ZDLGFBQWF4QyxXQUFXLENBQUMsR0FBRzJCLE1BQU07QUFBQSxJQUNsQ2MsZUFBZXpDLFdBQVcsQ0FBQyxHQUFHMEMsUUFBUTtBQUFBLElBQ3RDQyxhQUFhM0MsV0FBVyxDQUFDLEdBQUc0QyxTQUFTLENBQUMsR0FBR0YsUUFBUTtBQUFBLElBQ2pERyxhQUFhNUMsV0FBVyxDQUFDLEdBQUcwQixNQUFNO0FBQUEsSUFDbENtQixlQUFlN0MsV0FBVyxDQUFDLEdBQUd5QyxRQUFRO0FBQUEsSUFDdENLLE9BQU0sb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDM0NDLGNBQWM7QUFBQSxJQUNkQyxXQUFXO0FBQUEsSUFDWEMsc0JBQXNCO0FBQUEsSUFDdEJDLGNBQWM7QUFBQSxJQUNkQyxVQUFVO0FBQUEsSUFDVkMsb0JBQW9CO0FBQUEsSUFDcEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLE9BQU87QUFBQSxJQUNQQyxRQUFRO0FBQUEsRUFDVixDQUFDO0FBRUQsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUk3RSxTQUFpQyxDQUFDLENBQUM7QUFHdkUsUUFBTThFLHdCQUF3QjdFLFFBQVEsTUFBTTtBQUMxQyxRQUFJdUIsc0JBQXNCLE9BQU87QUFDL0IsWUFBTXVELGNBQThDO0FBQ3BEakUsaUJBQVdrRSxRQUFRLENBQUNDLE1BQU07QUFDeEJBLFVBQUV2QixVQUFVc0IsUUFBUSxDQUFDRSxNQUFNO0FBQ3pCLGNBQUksQ0FBQ0gsWUFBWUksS0FBSyxDQUFDQyxhQUFhQSxTQUFTNUIsU0FBUzBCLEVBQUUxQixJQUFJLEdBQUc7QUFDN0R1Qix3QkFBWU0sS0FBSyxFQUFFNUMsSUFBSXlDLEVBQUV6QyxJQUFJZSxNQUFNMEIsRUFBRTFCLEtBQUssQ0FBQztBQUFBLFVBQzdDO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQ0QsYUFBT3VCO0FBQUFBLElBQ1Q7QUFDQSxVQUFNekMsUUFBUXhCLFdBQVd5QixLQUFLLENBQUMwQyxNQUFNQSxFQUFFeEMsT0FBT2pCLGlCQUFpQjtBQUMvRCxXQUFPYyxPQUFPb0IsWUFBWTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ2xDLG1CQUFtQlYsVUFBVSxDQUFDO0FBR2xDLFFBQU13RSxnQkFBZ0JyRixRQUFRLE1BQU07QUFDbEMsVUFBTXFDLFFBQVF4QixXQUFXeUIsS0FBSyxDQUFDMEMsTUFBTUEsRUFBRXhDLE9BQU9NLFNBQVNPLFdBQVc7QUFDbEUsV0FBT2hCLE9BQU9vQixZQUFZO0FBQUEsRUFDNUIsR0FBRyxDQUFDWCxTQUFTTyxhQUFheEMsVUFBVSxDQUFDO0FBR3JDLFFBQU15RSxlQUFlQSxDQUFDL0MsT0FBMkI7QUFDL0MsV0FBT0EsR0FBR1MsU0FBU1QsR0FBR2dELFNBQVNoRCxHQUFHaUQsZUFBZTtBQUFBLEVBQ25EO0FBRUEsUUFBTUMsZ0JBQWdCQSxDQUFDbEQsT0FBMkI7QUFDaEQsV0FBT0EsR0FBR1UsY0FBY1YsR0FBR1csWUFBWTtBQUFBLEVBQ3pDO0FBR0EsUUFBTXdDLGdCQUFnQjFGLFFBQVEsTUFBTTtBQUNsQyxXQUFPVyxZQUFZZ0YsT0FBTyxDQUFDcEQsT0FBTztBQUNoQyxZQUFNUyxRQUFRc0MsYUFBYS9DLEVBQUUsRUFBRXFELFlBQVk7QUFDM0MsWUFBTUMsTUFBTUosY0FBY2xELEVBQUUsRUFBRXFELFlBQVk7QUFDMUMsWUFBTUUsUUFBUXZELEdBQUdpQixlQUFlLElBQUlvQyxZQUFZO0FBQ2hELFlBQU1HLE9BQU94RCxHQUFHb0IsaUJBQWlCLElBQUlpQyxZQUFZO0FBQ2pELFlBQU1JLE9BQU96RCxHQUFHZSxpQkFBaUIsSUFBSXNDLFlBQVk7QUFDakQsWUFBTUssU0FBUzVFLFdBQVd1RSxZQUFZLEVBQUVNLEtBQUs7QUFFN0MsWUFBTUMsY0FDSixDQUFDRixVQUNEakQsTUFBTW9ELFNBQVNILE1BQU0sS0FDckJKLElBQUlPLFNBQVNILE1BQU0sS0FDbkJILEtBQUtNLFNBQVNILE1BQU0sS0FDcEJGLElBQUlLLFNBQVNILE1BQU0sS0FDbkJELElBQUlJLFNBQVNILE1BQU0sTUFDbEIxRCxHQUFHMEIsYUFBYSxJQUFJMkIsWUFBWSxFQUFFUSxTQUFTSCxNQUFNO0FBRXBELFlBQU1JLGlCQUNKOUUsc0JBQXNCLFNBQVNnQixHQUFHYyxnQkFBZ0I5QjtBQUVwRCxZQUFNK0UsZUFDSjdFLG9CQUFvQixVQUNuQmMsR0FBR2lCLGVBQWUsSUFBSW9DLFlBQVksTUFBTW5FLGdCQUFnQm1FLFlBQVk7QUFFdkUsWUFBTVcsY0FDSjVFLG1CQUFtQixVQUNsQlksR0FBR21DLFVBQVUsSUFBSWtCLFlBQVksTUFBTWpFLGVBQWVpRSxZQUFZO0FBRWpFLFlBQU1ZLGlCQUNKM0Usc0JBQXNCLFNBQ3RCVSxHQUFHbUIsZ0JBQWdCN0Isc0JBQ2xCVSxHQUFHb0IsaUJBQWlCLElBQUlpQyxZQUFZLE1BQU0vRCxrQkFBa0IrRCxZQUFZO0FBRTNFLGFBQU9PLGVBQWVFLGtCQUFrQkMsZ0JBQWdCQyxlQUFlQztBQUFBQSxJQUN6RSxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUM3RixhQUFhVSxZQUFZRSxtQkFBbUJFLGlCQUFpQkUsZ0JBQWdCRSxpQkFBaUIsQ0FBQztBQUduRyxRQUFNNEUsYUFBYTlGLFlBQVkrRjtBQUMvQixRQUFNQyxnQkFBZ0JoRyxZQUFZZ0Y7QUFBQUEsSUFDaEMsQ0FBQ3BELE9BQU9BLEdBQUdtQyxXQUFXLGNBQWNuQyxHQUFHbUMsV0FBVyxlQUFlbkMsR0FBR21DLFdBQVc7QUFBQSxFQUNqRixFQUFFZ0M7QUFDRixRQUFNRSxpQkFBaUJqRyxZQUFZZ0Y7QUFBQUEsSUFDakMsQ0FBQ3BELE9BQU9BLEdBQUdtQyxXQUFXLGVBQWVuQyxHQUFHbUMsV0FBVyxpQkFBaUJuQyxHQUFHbUMsV0FBVztBQUFBLEVBQ3BGLEVBQUVnQztBQUNGLFFBQU1HLGtCQUFrQmxHLFlBQVlnRjtBQUFBQSxJQUNsQyxDQUFDcEQsT0FBT0EsR0FBR21DLFdBQVc7QUFBQSxFQUN4QixFQUFFZ0M7QUFHRixRQUFNSSxxQkFBcUJBLE1BQU07QUFDL0J4RixrQkFBYyxFQUFFO0FBQ2hCRSx5QkFBcUIsS0FBSztBQUMxQkUsdUJBQW1CLEtBQUs7QUFDeEJFLHNCQUFrQixLQUFLO0FBQ3ZCRSx5QkFBcUIsS0FBSztBQUFBLEVBQzVCO0FBR0EsUUFBTWlGLHFCQUFxQkEsTUFBTTtBQUMvQjdFLGtCQUFjLEtBQUs7QUFDbkIwQyxrQkFBYyxDQUFDLENBQUM7QUFDaEIsVUFBTW9DLFdBQVduRyxXQUFXLENBQUM7QUFDN0JrQyxnQkFBWTtBQUFBLE1BQ1ZQLElBQUk7QUFBQSxNQUNKUSxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLFVBQVU7QUFBQSxNQUNWQyxnQkFBZ0I7QUFBQSxNQUNoQkMsVUFBVTtBQUFBLE1BQ1ZDLGFBQWEyRCxVQUFVeEUsTUFBTTtBQUFBLE1BQzdCYyxlQUFlMEQsVUFBVXpELFFBQVE7QUFBQSxNQUNqQ0MsYUFBYXdELFVBQVV2RCxTQUFTLENBQUMsR0FBR0YsUUFBUTtBQUFBLE1BQzVDRyxhQUFhNUMsV0FBVyxDQUFDLEdBQUcwQixNQUFNO0FBQUEsTUFDbENtQixlQUFlN0MsV0FBVyxDQUFDLEdBQUd5QyxRQUFRO0FBQUEsTUFDdENLLE9BQU0sb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDM0NDLGNBQWM7QUFBQSxNQUNkQyxXQUFXO0FBQUEsTUFDWEMsc0JBQXNCO0FBQUEsTUFDdEJDLGNBQWM7QUFBQSxNQUNkQyxVQUFVO0FBQUEsTUFDVkMsb0JBQW9CO0FBQUEsTUFDcEJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxlQUFlO0FBQUEsTUFDZkMsZ0JBQWdCO0FBQUEsTUFDaEJDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsSUFDVixDQUFDO0FBQ0QxQyxzQkFBa0IsSUFBSTtBQUFBLEVBQ3hCO0FBR0EsUUFBTWlGLHNCQUFzQkEsQ0FBQ0MsU0FBcUI7QUFDaERoRixrQkFBYyxJQUFJO0FBQ2xCMEMsa0JBQWMsQ0FBQyxDQUFDO0FBQ2hCN0IsZ0JBQVk7QUFBQSxNQUNWUCxJQUFJMEUsS0FBSzFFO0FBQUFBLE1BQ1RRLE9BQU9rRSxLQUFLbEUsU0FBU2tFLEtBQUszQixTQUFTMkIsS0FBSzFCLGVBQWU7QUFBQSxNQUN2RHZDLFlBQVlpRSxLQUFLakUsY0FBYztBQUFBLE1BQy9CQyxVQUFVZ0UsS0FBS2hFLFlBQVk7QUFBQSxNQUMzQkMsZ0JBQWdCK0QsS0FBSy9ELGtCQUFrQjtBQUFBLE1BQ3ZDQyxVQUFVOEQsS0FBSzlELFlBQVk7QUFBQSxNQUMzQkMsYUFBYTZELEtBQUs3RCxlQUFnQnhDLFdBQVcsQ0FBQyxHQUFHMkIsTUFBTTtBQUFBLE1BQ3ZEYyxlQUFlNEQsS0FBSzVELGlCQUFrQnpDLFdBQVcsQ0FBQyxHQUFHMEMsUUFBUTtBQUFBLE1BQzdEQyxhQUFhMEQsS0FBSzFELGVBQWU7QUFBQSxNQUNqQ0UsYUFBYXdELEtBQUt4RCxlQUFnQjVDLFdBQVcsQ0FBQyxHQUFHMEIsTUFBTTtBQUFBLE1BQ3ZEbUIsZUFBZXVELEtBQUt2RCxpQkFBaUI7QUFBQSxNQUNyQ0MsTUFBTXNELEtBQUt0RCxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3hEQyxjQUFja0QsS0FBS2xELGdCQUFnQjtBQUFBLE1BQ25DQyxXQUFXaUQsS0FBS2pELGFBQWE7QUFBQSxNQUM3QkMsc0JBQXNCZ0QsS0FBS0Msa0JBQWtCQyxLQUFLLElBQUksS0FBSztBQUFBLE1BQzNEakQsY0FBYytDLEtBQUsvQyxnQkFBZ0I7QUFBQSxNQUNuQ0MsVUFBVThDLEtBQUs5QyxZQUFZO0FBQUEsTUFDM0JDLG9CQUFvQjZDLEtBQUtHLGdCQUFnQkQsS0FBSyxJQUFJLEtBQUs7QUFBQSxNQUN2RDlDLGdCQUFnQjRDLEtBQUs1QyxrQkFBa0I7QUFBQSxNQUN2Q0MsZUFBZStDLE1BQU1DLFFBQVFMLEtBQUtNLFNBQVMsSUFDdkNOLEtBQUtNLFVBQVVKLEtBQUssSUFBSSxJQUN2QkYsS0FBS08sZUFBZUwsS0FBSyxJQUFJLEtBQU1GLEtBQUtNLGFBQXdCO0FBQUEsTUFDckVoRCxnQkFBZ0IwQyxLQUFLMUMsa0JBQWtCO0FBQUEsTUFDdkNDLE9BQU95QyxLQUFLekMsU0FBUztBQUFBLE1BQ3JCQyxRQUFRd0MsS0FBS3hDLFVBQVU7QUFBQSxJQUN6QixDQUFDO0FBQ0QxQyxzQkFBa0IsSUFBSTtBQUFBLEVBQ3hCO0FBR0EsUUFBTTBGLG1CQUFtQkEsQ0FBQ0MsaUJBQXVDO0FBQy9ELFVBQU1DLFNBQWlDLENBQUM7QUFDeEMsUUFBSSxDQUFDOUUsU0FBU0UsTUFBTWtELEtBQUssRUFBRzBCLFFBQU81RSxRQUFRO0FBQzNDLFFBQUksQ0FBQ0YsU0FBU21CLFVBQVVpQyxLQUFLLEVBQUcwQixRQUFPM0QsWUFBWTtBQUNuRCxRQUFJLENBQUNuQixTQUFTVSxZQUFZMEMsS0FBSyxFQUFHMEIsUUFBT3BFLGNBQWM7QUFFdkQsUUFBSXFFLE9BQU9DLEtBQUtGLE1BQU0sRUFBRWxCLFNBQVMsR0FBRztBQUNsQzlCLG9CQUFjZ0QsTUFBTTtBQUNwQjtBQUFBLElBQ0Y7QUFFQSxVQUFNVCxtQkFBbUJyRSxTQUFTb0IscUJBQy9CSCxNQUFNLElBQUksRUFDVmdFLElBQUksQ0FBQ0MsTUFBTUEsRUFBRTlCLEtBQUssQ0FBQyxFQUNuQlAsT0FBT3NDLE9BQU87QUFFakIsVUFBTVosaUJBQWlCdkUsU0FBU3VCLG1CQUM3Qk4sTUFBTSxJQUFJLEVBQ1ZnRSxJQUFJLENBQUNDLE1BQU1BLEVBQUU5QixLQUFLLENBQUMsRUFDbkJQLE9BQU9zQyxPQUFPO0FBRWpCLFVBQU1SLGdCQUFnQjNFLFNBQVN5QixjQUM1QlIsTUFBTSxJQUFJLEVBQ1ZnRSxJQUFJLENBQUNDLE1BQU1BLEVBQUU5QixLQUFLLENBQUMsRUFDbkJQLE9BQU9zQyxPQUFPO0FBRWpCLFVBQU1DLFVBQStCO0FBQUEsTUFDbkNsRixPQUFPRixTQUFTRSxNQUFNa0QsS0FBSztBQUFBLE1BQzNCWCxPQUFPekMsU0FBU0UsTUFBTWtELEtBQUs7QUFBQSxNQUMzQmpELFlBQVlILFNBQVNHO0FBQUFBLE1BQ3JCQyxVQUFVSixTQUFTSTtBQUFBQSxNQUNuQkMsZ0JBQWdCTCxTQUFTSztBQUFBQSxNQUN6QkMsVUFBVU4sU0FBU007QUFBQUEsTUFDbkJDLGFBQWFQLFNBQVNPO0FBQUFBLE1BQ3RCQyxlQUFlUixTQUFTUTtBQUFBQSxNQUN4QkUsYUFBYVYsU0FBU1U7QUFBQUEsTUFDdEJFLGFBQWFaLFNBQVNZO0FBQUFBLE1BQ3RCQyxlQUFlYixTQUFTYTtBQUFBQSxNQUN4QkMsTUFBTWQsU0FBU2M7QUFBQUEsTUFDZkksY0FBY2xCLFNBQVNrQjtBQUFBQSxNQUN2QkMsV0FBV25CLFNBQVNtQixVQUFVaUMsS0FBSztBQUFBLE1BQ25DaUIsa0JBQWtCQSxpQkFBaUJULFNBQVMsSUFBSVMsbUJBQW1CLENBQUNyRSxTQUFTbUIsVUFBVWlDLEtBQUssQ0FBQztBQUFBLE1BQzdGL0IsY0FBY3JCLFNBQVNxQjtBQUFBQSxNQUN2QkMsVUFBVXRCLFNBQVNzQjtBQUFBQSxNQUNuQmlELGdCQUFnQkEsZUFBZVgsU0FBUyxJQUFJVyxpQkFBaUIsQ0FBQ3ZFLFNBQVNzQixRQUFRO0FBQUEsTUFDL0VFLGdCQUFnQnhCLFNBQVN3QjtBQUFBQSxNQUN6QmtELFdBQVcxRSxTQUFTeUI7QUFBQUEsTUFDcEJrRDtBQUFBQSxNQUNBakQsZ0JBQWdCMUIsU0FBUzBCO0FBQUFBLE1BQ3pCQyxPQUFPM0IsU0FBUzJCO0FBQUFBLE1BQ2hCQyxRQUFRaUQ7QUFBQUEsTUFDUlEsYUFBYSxJQUFHLG9CQUFJdEUsS0FBSyxHQUFFdUUsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFNBQVNDLE1BQU0sVUFBVSxDQUFDLENBQUMsTUFBSyxvQkFBSTFFLEtBQUssR0FBRTJFLG1CQUFtQixJQUFJLEVBQUVDLE1BQU0sV0FBV0MsUUFBUSxVQUFVLENBQUMsQ0FBQztBQUFBLElBQzNMO0FBRUEsUUFBSXpHLGNBQWNhLFNBQVNOLElBQUk7QUFDN0J0Qix5QkFBbUI0QixTQUFTTixJQUFJMEYsT0FBTztBQUN2QyxVQUFJL0Ysa0JBQWtCSyxPQUFPTSxTQUFTTixJQUFJO0FBQ3hDSiw0QkFBb0IsQ0FBQ3VHLFNBQVVBLE9BQU8sRUFBRSxHQUFHQSxNQUFNLEdBQUdULFFBQVEsSUFBSSxJQUFLO0FBQUEsTUFDdkU7QUFBQSxJQUNGLE9BQU87QUFDTCxZQUFNVSxVQUFrQztBQUFBLFFBQ3RDLEdBQUdWO0FBQUFBLFFBQ0gxQyxhQUFhMUMsU0FBU0UsTUFBTWtELEtBQUs7QUFBQSxRQUNqQzJDLGlCQUFpQjtBQUFBLFFBQ2pCQyxTQUFTO0FBQUEsUUFDVEMsTUFBTWpHLFNBQVNhO0FBQUFBLFFBQ2ZxRixVQUFVO0FBQUEsTUFDWjtBQUNBL0gsc0JBQWdCMkgsT0FBTztBQUFBLElBQ3pCO0FBRUE1RyxzQkFBa0IsS0FBSztBQUFBLEVBQ3pCO0FBR0EsUUFBTWlILG9CQUFvQkEsQ0FBQ0MsV0FBbUI7QUFDNUNoSSx1QkFBbUJnSSxRQUFRO0FBQUEsTUFDekJ4RSxRQUFRO0FBQUEsTUFDUnlFLGtCQUFrQkM7QUFBQUEsTUFDbEJDLHVCQUF1QkQ7QUFBQUEsTUFDdkJqQixhQUFhO0FBQUEsSUFDZixDQUFDO0FBQ0QsUUFBSWhHLGtCQUFrQkssT0FBTzBHLFFBQVE7QUFDbkM5RywwQkFBb0IsQ0FBQ3VHLFNBQVVBLE9BQU8sRUFBRSxHQUFHQSxNQUFNakUsUUFBUSxZQUFZeUUsa0JBQWtCQyxPQUFVLElBQUksSUFBSztBQUFBLElBQzVHO0FBQUEsRUFDRjtBQUdBLFFBQU1FLHlCQUF5QkEsTUFBTTtBQUNuQyxRQUFJLENBQUNuSCxvQkFBb0IsQ0FBQ1Msc0JBQXNCc0QsS0FBSyxFQUFHO0FBRXhEaEYsdUJBQW1CaUIsaUJBQWlCSyxJQUFJO0FBQUEsTUFDdENrQyxRQUFRO0FBQUEsTUFDUnlFLGtCQUFrQnZHLHNCQUFzQnNELEtBQUs7QUFBQSxNQUM3Q21ELHVCQUF1QjtBQUFBLE1BQ3ZCRSxpQkFBZ0Isb0JBQUkxRixLQUFLLEdBQUV1RSxtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sU0FBU0MsTUFBTSxVQUFVLENBQUM7QUFBQSxNQUMxR0osYUFBYTtBQUFBLElBQ2YsQ0FBQztBQUVEL0Y7QUFBQUEsTUFBb0IsQ0FBQ3VHLFNBQ25CQSxPQUNJO0FBQUEsUUFDRSxHQUFHQTtBQUFBQSxRQUNIakUsUUFBUTtBQUFBLFFBQ1J5RSxrQkFBa0J2RyxzQkFBc0JzRCxLQUFLO0FBQUEsUUFDN0NtRCx1QkFBdUI7QUFBQSxRQUN2QkUsaUJBQWdCLG9CQUFJMUYsS0FBSyxHQUFFdUUsbUJBQW1CLFNBQVMsRUFBRUMsS0FBSyxXQUFXQyxPQUFPLFNBQVNDLE1BQU0sVUFBVSxDQUFDO0FBQUEsTUFDNUcsSUFDQTtBQUFBLElBQ047QUFFQTVGLDZCQUF5QixLQUFLO0FBQzlCRSw2QkFBeUIsRUFBRTtBQUFBLEVBQzdCO0FBR0EsUUFBTTJHLGlCQUFpQkEsQ0FBQ3RDLFNBQXNCO0FBQzVDLFVBQU11QyxTQUFTdkMsUUFBUS9FLG9CQUFvQnVELGNBQWMsQ0FBQztBQUMxRCxRQUFJLENBQUMrRCxRQUFRO0FBQ1hDLFlBQU0scUNBQXFDO0FBQzNDO0FBQUEsSUFDRjtBQUNBQyxXQUFPQyxNQUFNO0FBQUEsRUFDZjtBQUdBLFFBQU1DLG9CQUFvQkEsQ0FBQ25GLFdBQW9CO0FBQzdDLFlBQVFBLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFDSCxlQUNFLHVCQUFDLFVBQUssV0FBVSw4SUFDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSw2Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUFPO0FBQUEsYUFEbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFFSixLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQ0gsZUFDRSx1QkFBQyxVQUFLLFdBQVUscUlBQ2Q7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFDdERBLFdBQVcsZ0JBQWdCLGdCQUFnQjtBQUFBLGFBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLE1BRUosS0FBSztBQUNILGVBQ0UsdUJBQUMsVUFBSyxXQUFVLHdJQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQU87QUFBQSxhQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxNQUVKLEtBQUs7QUFDSCxlQUNFLHVCQUFDLFVBQUssV0FBVSx5SUFDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSwyQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUFPO0FBQUEsYUFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFFSixLQUFLO0FBQUEsTUFDTDtBQUNFLGVBQ0UsdUJBQUMsVUFBSyxXQUFVLHlJQUNkO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQU87QUFBQSxhQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxJQUVOO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw4RUFBNkUsNEJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRCwwR0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU04RSxlQUFlO0FBQUEsWUFDOUIsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBO0FBQUEsVUFMbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTekM7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUE7QUFBQSxVQUx2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1GQUFrRiwyQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RztBQUFBLFFBQzVHLHVCQUFDLFNBQUksV0FBVSx5REFBeUROLHdCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUVBQWtFLHdCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlGO0FBQUEsUUFDekYsdUJBQUMsU0FBSSxXQUFVLHlEQUF5REUsMkJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxXQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpRUFBZ0Usa0NBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxRQUNqRyx1QkFBQyxTQUFJLFdBQVUseURBQXlEQyw0QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFdBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG1FQUFrRSxnQ0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRztBQUFBLFFBQ2pHLHVCQUFDLFNBQUksV0FBVSx5REFBeURDLDZCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdGO0FBQUEsV0FGMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdDQUNiO0FBQUEsK0JBQUMsVUFBTyxXQUFVLDBGQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdHO0FBQUEsUUFDeEc7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU94RjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3lJLE1BQU14SSxjQUFjd0ksRUFBRUwsT0FBT00sS0FBSztBQUFBLFlBQzdDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQTtBQUFBLFVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSytPO0FBQUEsUUFFOU8xSSxjQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1DLGNBQWMsRUFBRTtBQUFBLFlBQy9CLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsV0FBVSxpQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQjtBQUFBO0FBQUEsVUFMNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFHRSx1QkFBQyxTQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPQyxxQkFBcUI7QUFBQSxVQUM1QixlQUFlLENBQUN5SSxRQUFRO0FBQ3RCeEksaUNBQXFCd0ksR0FBRztBQUN4QnRJLCtCQUFtQixLQUFLO0FBQUEsVUFDMUI7QUFBQSxVQUVBO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGlCQUNDO0FBQUEscUNBQUMsY0FBVyxPQUFNLE9BQU0sOEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FDckNiLFdBQVdrSDtBQUFBQSxnQkFBSSxDQUFDL0MsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFeEMsSUFDN0J3QyxZQUFFekIsUUFEWXlCLEVBQUV4QyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBLGlCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQTtBQUFBO0FBQUEsUUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUdBLHVCQUFDLFNBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU9mLG1CQUFtQjtBQUFBLFVBQzFCLGVBQWUsQ0FBQ3VJLFFBQVF0SSxtQkFBbUJzSSxHQUFHO0FBQUEsVUFFOUM7QUFBQSxtQ0FBQyxpQkFBYyxXQUFVLGVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsaUJBQ0M7QUFBQSxxQ0FBQyxjQUFXLE9BQU0sT0FBTSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQSxjQUNuQ25GLHNCQUFzQmtEO0FBQUFBLGdCQUFJLENBQUM5QyxNQUMxQix1QkFBQyxjQUFzQixPQUFPQSxFQUFFMUIsTUFDN0IwQixZQUFFMUIsUUFEWTBCLEVBQUV6QyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBLGlCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQTtBQUFBO0FBQUEsUUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFHQSx1QkFBQyxTQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPYixrQkFBa0I7QUFBQSxVQUN6QixlQUFlLENBQUNxSSxRQUFRcEksa0JBQWtCb0ksR0FBRztBQUFBLFVBRTdDO0FBQUEsbUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLGlCQUNDO0FBQUEscUNBQUMsY0FBVyxPQUFNLE9BQU0sNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsY0FBVyxPQUFNLFlBQVcsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FDckMsdUJBQUMsY0FBVyxPQUFNLGFBQVkseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdkMsdUJBQUMsY0FBVyxPQUFNLHdCQUF1QixvQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxjQUFXLE9BQU0sZUFBYywyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzQyx1QkFBQyxjQUFXLE9BQU0sU0FBUSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxjQUMvQix1QkFBQyxjQUFXLE9BQU0sYUFBWSx5QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxpQkFQekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBO0FBQUE7QUFBQSxRQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0FwRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFGRTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsNENBQ2Y7QUFBQSw2QkFBQyxXQUNDLGlDQUFDLFFBQUcsV0FBVSwyR0FDWjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMvQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLDBDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsUUFDNUQsdUJBQUMsUUFBRyxXQUFVLGlCQUFnQixtQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBQ3JELHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxRQUN2Qyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQix1QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLDRDQUNkdEUsd0JBQWNnQixXQUFXLElBQ3hCLHVCQUFDLFFBQ0MsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSxvQ0FDeEIsaUNBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHdEQUF1RCx5QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsd0NBQXVDLHFDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlFO0FBQUEsUUFDekUsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyx1RUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU0k7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBK0c7QUFBQTtBQUFBLFVBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkEsSUFFQXBCLGNBQWNxQyxJQUFJLENBQUNiLFNBQVM7QUFDMUIsY0FBTStDLGtCQUFrQi9DLEtBQUt4QyxXQUFXO0FBRXhDLGVBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVcsZ0RBQ1R1RixrQkFBa0IsbUJBQW1CLEVBQUU7QUFBQSxZQUl6QztBQUFBLHFDQUFDLFFBQUcsV0FBVSxpQ0FDWjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0QkFBNEIvQyxlQUFLdEQsUUFBUSxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxnQkFDdEUsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlFQUNic0QsZUFBS2hFLFlBQVksV0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBTztBQUFBLGtCQUNQLHVCQUFDLFVBQU11Qyx3QkFBY3lCLElBQUksS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxxQkFMN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUdBLHVCQUFDLFFBQUcsV0FBVSx3QkFDWjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2RUFDWjVCLHVCQUFhNEIsSUFBSSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNaQSxlQUFLakQsYUFBYWlELEtBQUtnRCxlQUFlLHdDQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBR0EsdUJBQUMsUUFBRyxXQUFVLGVBQ1o7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOEJBQThCaEQsZUFBSzVELGlCQUFpQixzQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Y7QUFBQSxnQkFDdEYsdUJBQUMsU0FBSSxXQUFVLDhCQUE4QjRELGVBQUsxRCxlQUFlLGdCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RTtBQUFBLG1CQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FHQSx1QkFBQyxRQUFHLFdBQVUsZUFDWixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOEdBQ1gwRCxnQkFBS3ZELGlCQUFpQixLQUFLd0csT0FBTyxDQUFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFNakQsZUFBS3ZELGlCQUFpQixVQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLG1CQUp0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBR0EsdUJBQUMsUUFBRyxXQUFVLGlDQUNYa0csNEJBQWtCM0MsS0FBS3hDLE1BQU0sS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBR0EsdUJBQUMsUUFBRyxXQUFVLDRDQUNaLGlDQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXRDLG9CQUFvQjhFLElBQUk7QUFBQSxvQkFDdkMsV0FBVTtBQUFBLG9CQUE4SztBQUFBO0FBQUEsa0JBRjFMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUdDQSxLQUFLeEMsV0FBVyxlQUFld0MsS0FBS3hDLFdBQVcsZ0JBQzlDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXVFLGtCQUFrQi9CLEtBQUsxRSxFQUFFO0FBQUEsb0JBQ3hDLFdBQVU7QUFBQSxvQkFDVixPQUFNO0FBQUEsb0JBQXFCO0FBQUE7QUFBQSxrQkFIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BLElBQ0U7QUFBQSxnQkFFSjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU15RSxvQkFBb0JDLElBQUk7QUFBQSxvQkFDdkMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLG9CQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0RDtBQUFBO0FBQUEsa0JBTDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQTtBQUFBO0FBQUE7QUFBQSxVQTdFS0EsS0FBSzFFO0FBQUFBLFVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQStFQTtBQUFBLE1BRUosQ0FBQyxLQTNHTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkdBO0FBQUEsU0F4SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlIQSxLQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkhBLEtBNUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2SEE7QUFBQSxJQUdDTCxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsdUhBQ2IsaUNBQUMsU0FBSSxXQUFVLHdKQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBHQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzRkFDYkEsMkJBQWlCZSxZQUFZLFdBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDMkcsa0JBQWtCMUgsaUJBQWlCdUMsTUFBTTtBQUFBLFlBQzFDLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGNBQ3hDdkMsaUJBQWlCaUIsWUFBWTtBQUFBLGlCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQ1hrQyx1QkFBYW5ELGdCQUFnQixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMEJBQ1ZzRDtBQUFBQSwwQkFBY3RELGdCQUFnQjtBQUFBLFlBQUU7QUFBQSxZQUFjQSxpQkFBaUJnQixrQkFBa0I7QUFBQSxZQUFxQjtBQUFBLFlBQUloQixpQkFBaUJtQjtBQUFBQSxZQUFjO0FBQUEsWUFBR25CLGlCQUFpQnFCO0FBQUFBLFlBQVk7QUFBQSxlQUQ1SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNZ0csZUFBZXJILGdCQUFnQjtBQUFBLGNBQzlDLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUVOO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkQ7QUFBQSxnQkFDN0QsdUJBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFXO0FBQUE7QUFBQTtBQUFBLFlBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1DLG9CQUFvQixJQUFJO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQTtBQUFBLFlBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBRVpEO0FBQUFBLHlCQUFpQnVDLFdBQVcsMEJBQTBCdkMsaUJBQWlCZ0gsb0JBQ3RFLHVCQUFDLFNBQUksV0FBVSxtRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSx3REFBdUQsdUJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThFO0FBQUEsY0FBTztBQUFBLGNBQzVEaEgsaUJBQWlCa0gseUJBQXlCO0FBQUEsY0FBZ0I7QUFBQSxjQUFHbEgsaUJBQWlCb0gsa0JBQWtCO0FBQUEsY0FBUztBQUFBLGlCQUZwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiLHdCQUFNdkUsSUFBSTdDO0FBQ1ZDLHNDQUFvQixJQUFJO0FBQ3hCNkUsc0NBQW9CakMsQ0FBQztBQUFBLGdCQUN2QjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFBcUc7QUFBQTtBQUFBLGNBTmpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMkRBQTBEO0FBQUE7QUFBQSxZQUM5RDdDLGlCQUFpQmdIO0FBQUFBLFlBQWlCO0FBQUEsZUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUseUVBQXdFLGlDQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsMkNBQ1ZoSCwyQkFBaUI4QixhQUFhOUIsaUJBQWlCK0gsZUFBZSxvRkFEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUMvSCxpQkFBaUJnRixvQkFBb0JoRixpQkFBaUJnRixpQkFBaUJULFNBQVMsS0FDL0UsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLCtDQUE4QywyQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDJDQUNYdkUsMkJBQWlCZ0YsaUJBQWlCWTtBQUFBQSxjQUFJLENBQUNxQyxNQUFNQyxRQUM1Qyx1QkFBQyxRQUFhLFdBQVUsa0JBQWtCRCxrQkFBakNDLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxZQUNoRCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUseUVBQXdFLDJEQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsNENBQTJDO0FBQUE7QUFBQSxjQUNoRGxJLGlCQUFpQm1DLGtCQUFrQjtBQUFBLGlCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQ25DLGlCQUFpQmtGLGtCQUFrQmxGLGlCQUFpQmtGLGVBQWVYLFNBQVMsSUFDM0UsdUJBQUMsU0FBSSxXQUFVLGFBQ1p2RSwyQkFBaUJrRixlQUFlVTtBQUFBQSxZQUFJLENBQUN1QyxNQUFNRCxRQUMxQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUVDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFVBQUssV0FBVSw4SEFDYkEsZ0JBQU0sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG1CQUFtQkMsa0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUE7QUFBQTtBQUFBLGNBTmhDRDtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLFVBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtFQUNabEksMkJBQWlCaUMsWUFBWSx3RUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxzREFDWjtBQUFBLHFDQUFDLFVBQUssV0FBVSx3REFBdUQsMkJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUFPO0FBQUEsaUJBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNaakMsMkJBQWlCc0YsaUJBQWlCdEYsaUJBQWlCc0YsY0FBY2YsU0FBUyxJQUN6RSx1QkFBQyxRQUFHLFdBQVUsOEJBQ1h2RSwyQkFBaUJzRixjQUFjTTtBQUFBQSxjQUFJLENBQUN3QyxHQUFHQyxNQUN0Qyx1QkFBQyxRQUFZRCxlQUFKQyxHQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxZQUNoQixLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUEsSUFFQSx1QkFBQyxPQUFHbEQsZ0JBQU1DLFFBQVFwRixpQkFBaUJxRixTQUFTLElBQUlyRixpQkFBaUJxRixVQUFVSixLQUFLLElBQUksSUFBS2pGLGlCQUFpQnFGLGFBQWEsdURBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRLLEtBUmhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLCtEQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHNEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLDBEQUF5RCwwQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQU87QUFBQSxpQkFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZyRiwyQkFBaUJxQyxrQkFBa0IsK0VBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsUUFHQ3JDLGlCQUFpQnNDLFNBQ2hCLHVCQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxRUFBb0UscURBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQkFBa0J0QywyQkFBaUJzQyxTQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBL0hKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpSUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxvSEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNckMsb0JBQW9CLElBQUk7QUFBQSxZQUN2QyxXQUFVO0FBQUEsWUFBcUk7QUFBQTtBQUFBLFVBRmpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2Isc0JBQU00QyxJQUFJN0M7QUFDVkMsb0NBQW9CLElBQUk7QUFDeEI2RSxvQ0FBb0JqQyxDQUFDO0FBQUEsY0FDdkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFvSjtBQUFBO0FBQUEsWUFOaEs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxVQUVDN0MsaUJBQWlCdUMsV0FBVyxjQUMzQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2I3Qix5Q0FBeUIsRUFBRTtBQUMzQkYseUNBQXlCLElBQUk7QUFBQSxjQUMvQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQXNJO0FBQUE7QUFBQSxZQUxsSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBR0RSLGlCQUFpQnVDLFdBQVcsY0FDM0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTXVFLGtCQUFrQjlHLGlCQUFpQkssRUFBRTtBQUFBLGNBQ3BELFdBQVU7QUFBQSxjQUF3STtBQUFBO0FBQUEsWUFGcEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJDQTtBQUFBLFNBdk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3TkEsS0F6TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBOQTtBQUFBLElBSURULGtCQUNDLHVCQUFDLFNBQUksV0FBVSx1SEFDYixpQ0FBQyxTQUFJLFdBQVUsd0pBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHNDQUNYRSx1QkFBYSxxQkFBcUIsNEJBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsb0ZBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUQsa0JBQWtCLEtBQUs7QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNaQztBQUFBQSxzQkFBYyxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUVtRSxTQUFTakUsa0JBQWtCdUMsVUFBVSxFQUFFLEtBQzNGLHVCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLGlDQUFDLGdCQUFhLFdBQVUsOEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBMkJ2QyxrQkFBa0J1QyxPQUFPa0IsWUFBWTtBQUFBLFlBQUU7QUFBQSxlQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLGFBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUQzRCxjQUFjRSxrQkFBa0J1QyxXQUFXLDBCQUMxQyx1QkFBQyxTQUFJLFdBQVUscUdBQ2I7QUFBQSxpQ0FBQyxpQkFBYyxXQUFVLDRCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLFVBQ2pELHVCQUFDLFVBQUs7QUFBQTtBQUFBLFlBQXVCdkMsaUJBQWlCZ0g7QUFBQUEsZUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0Q7QUFBQSxhQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUM1Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPckcsU0FBU0U7QUFBQUEsZ0JBQ2hCLFVBQVVmLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGdCQUN0RyxVQUFVLENBQUNvRixNQUFNO0FBQ2YvRyw4QkFBWSxFQUFFLEdBQUdELFVBQVVFLE9BQU84RyxFQUFFTCxPQUFPTSxNQUFNLENBQUM7QUFDbEQsc0JBQUlwRixXQUFXM0IsTUFBTzRCLGVBQWMsRUFBRSxHQUFHRCxZQUFZM0IsT0FBTyxHQUFHLENBQUM7QUFBQSxnQkFDbEU7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osV0FBVyw0R0FDVDJCLFdBQVczQixRQUFRLGtDQUFrQyxrQkFBa0I7QUFBQTtBQUFBLGNBVjNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdLO0FBQUEsWUFFSjJCLFdBQVczQixTQUNWLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0MyQixxQkFBVzNCLFNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsZUFsQnBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCxpQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPRixTQUFTRztBQUFBQSxnQkFDaEIsVUFBVWhCLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGdCQUN0RyxlQUFlLENBQUNtQixRQUFRO0FBQ3RCLHNCQUFJNEUsUUFBUTtBQUNaLHNCQUFJNUUsUUFBUSxhQUFjNEUsU0FBUTtBQUNsQyxzQkFBSTVFLFFBQVEsY0FBZTRFLFNBQVE7QUFDbkMsc0JBQUk1RSxRQUFRLG1CQUFvQjRFLFNBQVE7QUFDeEMsc0JBQUk1RSxRQUFRLFVBQVc0RSxTQUFRO0FBQy9CLHNCQUFJNUUsUUFBUSxxQkFBc0I0RSxTQUFRO0FBQzFDMUgsOEJBQVksRUFBRSxHQUFHRCxVQUFVRyxZQUFZNEMsS0FBSzNDLFVBQVV1SCxNQUFNLENBQUM7QUFBQSxnQkFDL0Q7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsdUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxtQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLGtCQUFpQixzQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsY0FBVyxPQUFNLGNBQWEsa0NBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlEO0FBQUEsb0JBQ2pELHVCQUFDLGNBQVcsT0FBTSxlQUFjLG1DQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRDtBQUFBLG9CQUNuRCx1QkFBQyxjQUFXLE9BQU0sb0JBQW1CLHdDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLG9CQUM3RCx1QkFBQyxjQUFXLE9BQU0sV0FBVSwrQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkM7QUFBQSxvQkFDM0MsdUJBQUMsY0FBVyxPQUFNLHNCQUFxQiwwQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSx1QkFObkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBO0FBQUE7QUFBQSxjQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLGFBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxREE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELHVDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8zSCxTQUFTSztBQUFBQSxnQkFDaEIsVUFBVWxCLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGdCQUN0RyxlQUFlLENBQUNzRixRQUFRakgsWUFBWSxFQUFFLEdBQUdELFVBQVVLLGdCQUFnQjZHLElBQUksQ0FBQztBQUFBLGdCQUV4RTtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsdUNBQ3ZCLGlDQUFDLGVBQVksYUFBWSxxQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLHNCQUFxQixrQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsY0FBVyxPQUFNLHNCQUFxQixrQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUQ7QUFBQSxvQkFDekQsdUJBQUMsY0FBVyxPQUFNLHVCQUFzQixtQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkQ7QUFBQSx1QkFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBO0FBQUE7QUFBQSxjQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELHdCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPbEgsU0FBU007QUFBQUEsZ0JBQ2hCLFVBQVVuQixjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxnQkFDdEcsVUFBVSxDQUFDb0YsTUFBTS9HLFlBQVksRUFBRSxHQUFHRCxVQUFVTSxVQUFVMEcsRUFBRUwsT0FBT00sTUFBTSxDQUFDO0FBQUEsZ0JBQ3RFLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11STtBQUFBLGVBVnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELDRCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPakgsU0FBU2M7QUFBQUEsZ0JBQ2hCLFVBQVUzQixjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxnQkFDdEcsVUFBVSxDQUFDb0YsTUFBTS9HLFlBQVksRUFBRSxHQUFHRCxVQUFVYyxNQUFNa0csRUFBRUwsT0FBT00sTUFBTSxDQUFDO0FBQUEsZ0JBQ2xFLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VJO0FBQUEsZUFUekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxpR0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtEO0FBQUE7QUFBQSxjQUN2RCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9qSCxTQUFTTztBQUFBQSxnQkFDaEIsVUFBVXBCLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGdCQUN0RyxlQUFlLENBQUNzRixRQUFRO0FBQ3RCLHdCQUFNM0gsUUFBUXhCLFdBQVd5QixLQUFLLENBQUMwQyxNQUFNQSxFQUFFeEMsT0FBT3dILEdBQUc7QUFDakQsc0JBQUkzSCxPQUFPO0FBQ1RVLGdDQUFZO0FBQUEsc0JBQ1YsR0FBR0Q7QUFBQUEsc0JBQ0hPLGFBQWFoQixNQUFNRztBQUFBQSxzQkFDbkJjLGVBQWVqQixNQUFNa0I7QUFBQUEsc0JBQ3JCQyxhQUFhbkIsTUFBTW9CLFNBQVMsQ0FBQyxHQUFHRixRQUFRO0FBQUEsb0JBQzFDLENBQUM7QUFBQSxrQkFDSDtBQUFBLGdCQUNGO0FBQUEsZ0JBRUE7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLHVDQUN2QixpQ0FBQyxlQUFZLGFBQVksc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDRTFDLHFCQUFXa0g7QUFBQUEsb0JBQUksQ0FBQy9DLE1BQ2YsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRXhDLElBQzdCd0MsWUFBRXpCLFFBRFl5QixFQUFFeEMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF5QkE7QUFBQSxlQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThCQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0Q7QUFBQTtBQUFBLGNBQ2xELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsaUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT00sU0FBU1U7QUFBQUEsZ0JBQ2hCLFVBQVV2QixjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxnQkFDdEcsZUFBZSxDQUFDc0YsUUFBUTtBQUN0QmpILDhCQUFZLEVBQUUsR0FBR0QsVUFBVVUsYUFBYXdHLElBQUksQ0FBQztBQUM3QyxzQkFBSXJGLFdBQVduQixZQUFhb0IsZUFBYyxFQUFFLEdBQUdELFlBQVluQixhQUFhLEdBQUcsQ0FBQztBQUFBLGdCQUM5RTtBQUFBLGdCQUVBO0FBQUEseUNBQUMsaUJBQWMsV0FBVyxzQkFDeEJtQixXQUFXbkIsY0FBYyxrQ0FBa0Msa0JBQWtCLElBRTdFLGlDQUFDLGVBQVksYUFBWSwyQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0QsS0FIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFNkIsd0JBQWMwQztBQUFBQSxvQkFBSSxDQUFDOUMsTUFDbEIsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRTFCLE1BQzdCMEIsWUFBRTFCLFFBRFkwQixFQUFFekMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvQkE7QUFBQSxlQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0QsOEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT00sU0FBU1k7QUFBQUEsZ0JBQ2hCLFVBQVV6QixjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxnQkFDdEcsZUFBZSxDQUFDc0YsUUFBUTtBQUN0Qix3QkFBTTNILFFBQVF2QixXQUFXd0IsS0FBSyxDQUFDMkMsTUFBTUEsRUFBRXpDLE9BQU93SCxHQUFHO0FBQ2pELHNCQUFJM0gsT0FBTztBQUNUVSxnQ0FBWSxFQUFFLEdBQUdELFVBQVVZLGFBQWFyQixNQUFNRyxJQUFJbUIsZUFBZXRCLE1BQU1rQixLQUFLLENBQUM7QUFBQSxrQkFDL0U7QUFBQSxnQkFDRjtBQUFBLGdCQUVBO0FBQUEseUNBQUMsaUJBQWMsV0FBVSx1Q0FDdkIsaUNBQUMsZUFBWSxhQUFZLHNCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsaUJBQ0V6QyxxQkFBV2lIO0FBQUFBLG9CQUFJLENBQUM5QyxNQUNmLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUV6QyxJQUM3QnlDLFlBQUUxQixRQURZMEIsRUFBRXpDLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQTtBQUFBO0FBQUEsY0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxhQXJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0ZBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRDtBQUFBO0FBQUEsWUFDdEMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGNBQ04sT0FBT00sU0FBU21CO0FBQUFBLGNBQ2hCLFVBQVVoQyxjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxjQUN0RyxVQUFVLENBQUNvRixNQUFNO0FBQ2YvRyw0QkFBWSxFQUFFLEdBQUdELFVBQVVtQixXQUFXNkYsRUFBRUwsT0FBT00sTUFBTSxDQUFDO0FBQ3RELG9CQUFJcEYsV0FBV1YsVUFBV1csZUFBYyxFQUFFLEdBQUdELFlBQVlWLFdBQVcsR0FBRyxDQUFDO0FBQUEsY0FDMUU7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLFdBQVcsNEdBQ1RVLFdBQVdWLFlBQVksa0NBQWtDLGtCQUFrQjtBQUFBO0FBQUEsWUFWL0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0s7QUFBQSxVQUVKVSxXQUFXVixhQUNWLHVCQUFDLE9BQUUsV0FBVSxrQ0FBa0NVLHFCQUFXVixhQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLGFBbEJ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCwwREFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxjQUNOLE9BQU9uQixTQUFTdUI7QUFBQUEsY0FDaEIsVUFBVXBDLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGNBQ3RHLFVBQVUsQ0FBQ29GLE1BQU0vRyxZQUFZLEVBQUUsR0FBR0QsVUFBVXVCLG9CQUFvQnlGLEVBQUVMLE9BQU9NLE1BQU0sQ0FBQztBQUFBLGNBQ2hGLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQTtBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTZKO0FBQUEsYUFWL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx5Q0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNO0FBQUEsZ0JBQ04sT0FBT2pILFNBQVN5QjtBQUFBQSxnQkFDaEIsVUFBVXRDLGNBQWMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFbUUsU0FBU2pFLGtCQUFrQnVDLFVBQVUsRUFBRTtBQUFBLGdCQUN0RyxVQUFVLENBQUNvRixNQUFNL0csWUFBWSxFQUFFLEdBQUdELFVBQVV5QixlQUFldUYsRUFBRUwsT0FBT00sTUFBTSxDQUFDO0FBQUEsZ0JBQzNFLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11STtBQUFBLGVBVnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELG9DQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU07QUFBQSxnQkFDTixPQUFPakgsU0FBUzBCO0FBQUFBLGdCQUNoQixVQUFVdkMsY0FBYyxDQUFDLGFBQWEsWUFBWSxXQUFXLEVBQUVtRSxTQUFTakUsa0JBQWtCdUMsVUFBVSxFQUFFO0FBQUEsZ0JBQ3RHLFVBQVUsQ0FBQ29GLE1BQU0vRyxZQUFZLEVBQUUsR0FBR0QsVUFBVTBCLGdCQUFnQnNGLEVBQUVMLE9BQU9NLE1BQU0sQ0FBQztBQUFBLGdCQUM1RSxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNdUk7QUFBQSxlQVZ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsK0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsY0FDTixPQUFPakgsU0FBUzJCO0FBQUFBLGNBQ2hCLFVBQVV4QyxjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUU7QUFBQSxjQUN0RyxVQUFVLENBQUNvRixNQUFNL0csWUFBWSxFQUFFLEdBQUdELFVBQVUyQixPQUFPcUYsRUFBRUwsT0FBT00sTUFBTSxDQUFDO0FBQUEsY0FDbkUsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBO0FBQUEsWUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNdUk7QUFBQSxhQVZ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQW5TRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb1NBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNL0gsa0JBQWtCLEtBQUs7QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFBdUk7QUFBQTtBQUFBLFVBSG5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFFQyxFQUFFQyxjQUFjLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRW1FLFNBQVNqRSxrQkFBa0J1QyxVQUFVLEVBQUUsTUFDN0YsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTWdELGlCQUFpQixPQUFPO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBQW9KO0FBQUE7QUFBQSxZQUhoSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUEsaUJBQWlCLFdBQVc7QUFBQSxjQUMzQyxXQUFVO0FBQUEsY0FFVHpGLHVCQUFhLHVCQUF1QjtBQUFBO0FBQUEsWUFMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxTQXRWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdVZBLEtBeFZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5VkE7QUFBQSxJQUlEUyx5QkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2IsaUNBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0Msd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9DQUFtQyw4Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUMvRSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCLDZEQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxXQUFVLG1EQUFrRDtBQUFBO0FBQUEsVUFDL0IsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUM7QUFBQSxhQURyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNO0FBQUEsWUFDTixPQUFPRTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2tILE1BQU1qSCx5QkFBeUJpSCxFQUFFTCxPQUFPTSxLQUFLO0FBQUEsWUFDeEQsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLbUg7QUFBQSxXQVRySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1wSCx5QkFBeUIsS0FBSztBQUFBLFlBQzdDLFdBQVU7QUFBQSxZQUF5RztBQUFBO0FBQUEsVUFGckg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxVQUFVLENBQUNDLHNCQUFzQnNELEtBQUs7QUFBQSxZQUN0QyxTQUFTb0Q7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBdUg7QUFBQTtBQUFBLFVBSG5JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBLEtBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5Q0E7QUFBQSxPQXIzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXUzQkE7QUFFSjtBQUFFbEksR0Fod0NXVixnQkFBNkM7QUFBQSxLQUE3Q0E7QUFBNkMsSUFBQWdLO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlTWVtbyIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiU2VhcmNoIiwiQ2hlY2tDaXJjbGUyIiwiQWxlcnRUcmlhbmdsZSIsIlgiLCJMZXNzb25QbGFuVmlldyIsImxlc3NvblBsYW5zIiwic2Vzc2lvbnMiLCJwYW5jaGF5YXRzIiwidm9sdW50ZWVycyIsInNlbGVjdGVkTGVzc29uUGxhbklkIiwib25OYXZpZ2F0ZSIsIm9uQWRkTGVzc29uUGxhbiIsIm9uVXBkYXRlTGVzc29uUGxhbiIsIm9uRGVsZXRlTGVzc29uUGxhbiIsIl9zIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzZWxlY3RlZFBhbmNoYXlhdCIsInNldFNlbGVjdGVkUGFuY2hheWF0Iiwic2VsZWN0ZWRWaWxsYWdlIiwic2V0U2VsZWN0ZWRWaWxsYWdlIiwic2VsZWN0ZWRTdGF0dXMiLCJzZXRTZWxlY3RlZFN0YXR1cyIsInNlbGVjdGVkVm9sdW50ZWVyIiwic2V0U2VsZWN0ZWRWb2x1bnRlZXIiLCJpc05ld01vZGFsT3BlbiIsInNldElzTmV3TW9kYWxPcGVuIiwiaXNFZGl0TW9kZSIsInNldElzRWRpdE1vZGUiLCJhY3RpdmVQbGFuRGV0YWlsIiwic2V0QWN0aXZlUGxhbkRldGFpbCIsImZvdW5kIiwiZmluZCIsImxwIiwiaWQiLCJzZXNzaW9uSWQiLCJpc0NvcnJlY3Rpb25Nb2RhbE9wZW4iLCJzZXRJc0NvcnJlY3Rpb25Nb2RhbE9wZW4iLCJjb3JyZWN0aW9uUmVhc29uSW5wdXQiLCJzZXRDb3JyZWN0aW9uUmVhc29uSW5wdXQiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwidG9waWMiLCJtb2R1bGVOYW1lIiwibW9kdWxlSWQiLCJ0YXJnZXRTdGFuZGFyZCIsImR1cmF0aW9uIiwicGFuY2hheWF0SWQiLCJwYW5jaGF5YXROYW1lIiwibmFtZSIsInZpbGxhZ2VOYW1lIiwidmlsbGFnZXMiLCJ2b2x1bnRlZXJJZCIsInZvbHVudGVlck5hbWUiLCJkYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJkYXlPZlNlc3Npb24iLCJvYmplY3RpdmUiLCJsZWFybmluZ091dGNvbWVzVGV4dCIsImludHJvZHVjdGlvbiIsImFjdGl2aXR5IiwiYWN0aXZpdGllc0xpc3RUZXh0IiwidGVhY2hpbmdNZXRob2QiLCJtYXRlcmlhbHNUZXh0IiwiYXNzZXNzbWVudFRhc2siLCJub3RlcyIsInN0YXR1cyIsImZvcm1FcnJvcnMiLCJzZXRGb3JtRXJyb3JzIiwiY3VycmVudEZpbHRlclZpbGxhZ2VzIiwiYWxsVmlsbGFnZXMiLCJmb3JFYWNoIiwicCIsInYiLCJzb21lIiwiZXhpc3RpbmciLCJwdXNoIiwibW9kYWxWaWxsYWdlcyIsImdldFBsYW5Ub3BpYyIsInRpdGxlIiwic2Vzc2lvbk5hbWUiLCJnZXRQbGFuTW9kdWxlIiwiZmlsdGVyZWRQbGFucyIsImZpbHRlciIsInRvTG93ZXJDYXNlIiwibW9kIiwidmlsbCIsInZvbCIsInBhbiIsInNlYXJjaCIsInRyaW0iLCJtYXRjaFNlYXJjaCIsImluY2x1ZGVzIiwibWF0Y2hQYW5jaGF5YXQiLCJtYXRjaFZpbGxhZ2UiLCJtYXRjaFN0YXR1cyIsIm1hdGNoVm9sdW50ZWVyIiwidG90YWxDb3VudCIsImxlbmd0aCIsImFwcHJvdmVkQ291bnQiLCJzdWJtaXR0ZWRDb3VudCIsImNvcnJlY3Rpb25Db3VudCIsImhhbmRsZUNsZWFyRmlsdGVycyIsImhhbmRsZU9wZW5OZXdNb2RhbCIsImRlZmF1bHRQIiwiaGFuZGxlT3BlbkVkaXRNb2RhbCIsInBsYW4iLCJsZWFybmluZ091dGNvbWVzIiwiam9pbiIsImFjdGl2aXRpZXNMaXN0IiwiQXJyYXkiLCJpc0FycmF5IiwibWF0ZXJpYWxzIiwibWF0ZXJpYWxzTGlzdCIsImhhbmRsZUZvcm1TdWJtaXQiLCJ0YXJnZXRTdGF0dXMiLCJlcnJvcnMiLCJPYmplY3QiLCJrZXlzIiwibWFwIiwicyIsIkJvb2xlYW4iLCJwYXlsb2FkIiwibGFzdFVwZGF0ZWQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJob3VyIiwibWludXRlIiwicHJldiIsIm5ld1BsYW4iLCJ2b2x1bnRlZXJzQ291bnQiLCJjbHVzdGVyIiwic3BvYyIsImZpbmFuY2VyIiwiaGFuZGxlQXBwcm92ZVBsYW4iLCJwbGFuSWQiLCJjb3JyZWN0aW9uUmVhc29uIiwidW5kZWZpbmVkIiwiY29ycmVjdGlvblJlcXVlc3RlZEJ5IiwiaGFuZGxlU3VibWl0Q29ycmVjdGlvbiIsImNvcnJlY3Rpb25EYXRlIiwiaGFuZGxlUHJpbnRQREYiLCJ0YXJnZXQiLCJhbGVydCIsIndpbmRvdyIsInByaW50IiwicmVuZGVyU3RhdHVzQmFkZ2UiLCJlIiwidmFsdWUiLCJ2YWwiLCJpc0NvcnJlY3Rpb25SZXEiLCJkZXNjcmlwdGlvbiIsImNoYXJBdCIsIml0ZW0iLCJpZHgiLCJzdGVwIiwibSIsImkiLCJtb2RJZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxlc3NvblBsYW5WaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFRhYlR5cGUsIExlc3NvblBsYW4sIFBhbmNoYXlhdCwgVm9sdW50ZWVyLCBTZXNzaW9uIH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBTZWxlY3RDb250ZW50LFxyXG4gIFNlbGVjdEl0ZW0sXHJcbiAgU2VsZWN0VHJpZ2dlcixcclxuICBTZWxlY3RWYWx1ZSxcclxufSBmcm9tICcuL3VpL3NlbGVjdCc7XHJcbmltcG9ydCB7IEFjdGlvbkJ1dHRvbiB9IGZyb20gJy4vdWkvYWN0aW9uLWJ1dHRvbic7XHJcbmltcG9ydCB7IFBsdXMsIFNlYXJjaCwgQm9va09wZW4sIENoZWNrQ2lyY2xlMiwgQ2xvY2ssIEFsZXJ0VHJpYW5nbGUsIEZpbGVUZXh0LCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuXHJcbmludGVyZmFjZSBMZXNzb25QbGFuVmlld1Byb3BzIHtcclxuICBsZXNzb25QbGFuczogTGVzc29uUGxhbltdO1xyXG4gIHNlc3Npb25zOiBTZXNzaW9uW107XHJcbiAgcGFuY2hheWF0czogUGFuY2hheWF0W107XHJcbiAgdm9sdW50ZWVyczogVm9sdW50ZWVyW107XHJcbiAgc2VsZWN0ZWRMZXNzb25QbGFuSWQ/OiBzdHJpbmc7XHJcbiAgb25OYXZpZ2F0ZTogKHRhYjogVGFiVHlwZSwgdGFyZ2V0SWQ/OiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgb25BZGRMZXNzb25QbGFuOiAocGxhbjogT21pdDxMZXNzb25QbGFuLCAnaWQnPikgPT4gdm9pZDtcclxuICBvblVwZGF0ZUxlc3NvblBsYW46IChpZDogc3RyaW5nLCB1cGRhdGVkOiBQYXJ0aWFsPExlc3NvblBsYW4+KSA9PiB2b2lkO1xyXG4gIG9uRGVsZXRlTGVzc29uUGxhbj86IChpZDogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTGVzc29uUGxhblZpZXc6IFJlYWN0LkZDPExlc3NvblBsYW5WaWV3UHJvcHM+ID0gKHtcclxuICBsZXNzb25QbGFucyA9IFtdLFxyXG4gIHNlc3Npb25zID0gW10sXHJcbiAgcGFuY2hheWF0cyA9IFtdLFxyXG4gIHZvbHVudGVlcnMgPSBbXSxcclxuICBzZWxlY3RlZExlc3NvblBsYW5JZCxcclxuICBvbk5hdmlnYXRlLFxyXG4gIG9uQWRkTGVzc29uUGxhbixcclxuICBvblVwZGF0ZUxlc3NvblBsYW4sXHJcbiAgb25EZWxldGVMZXNzb25QbGFuLFxyXG59KSA9PiB7XHJcbiAgLy8gRmlsdGVyIFN0YXRlc1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXQsIHNldFNlbGVjdGVkUGFuY2hheWF0XSA9IHVzZVN0YXRlKCdhbGwnKTtcclxuICBjb25zdCBbc2VsZWN0ZWRWaWxsYWdlLCBzZXRTZWxlY3RlZFZpbGxhZ2VdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFN0YXR1cywgc2V0U2VsZWN0ZWRTdGF0dXNdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFZvbHVudGVlciwgc2V0U2VsZWN0ZWRWb2x1bnRlZXJdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG5cclxuICAvLyBNb2RhbHMgJiBBY3RpdmUgVmlldyBTdGF0ZXNcclxuICBjb25zdCBbaXNOZXdNb2RhbE9wZW4sIHNldElzTmV3TW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNFZGl0TW9kZSwgc2V0SXNFZGl0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVBsYW5EZXRhaWwsIHNldEFjdGl2ZVBsYW5EZXRhaWxdID0gdXNlU3RhdGU8TGVzc29uUGxhbiB8IG51bGw+KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZExlc3NvblBsYW5JZCkge1xyXG4gICAgICBjb25zdCBmb3VuZCA9IGxlc3NvblBsYW5zLmZpbmQoKGxwKSA9PiBscC5pZCA9PT0gc2VsZWN0ZWRMZXNzb25QbGFuSWQgfHwgbHAuc2Vzc2lvbklkID09PSBzZWxlY3RlZExlc3NvblBsYW5JZCk7XHJcbiAgICAgIHJldHVybiBmb3VuZCB8fCBsZXNzb25QbGFuc1swXSB8fCBudWxsO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfSk7XHJcbiAgY29uc3QgW2lzQ29ycmVjdGlvbk1vZGFsT3Blbiwgc2V0SXNDb3JyZWN0aW9uTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29ycmVjdGlvblJlYXNvbklucHV0LCBzZXRDb3JyZWN0aW9uUmVhc29uSW5wdXRdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICAvLyBGb3JtIFN0YXRlIGZvciBDcmVhdGUgLyBFZGl0XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBpZDogJycsXHJcbiAgICB0b3BpYzogJycsXHJcbiAgICBtb2R1bGVOYW1lOiAnU3Bva2VuIEVuZ2xpc2gnLFxyXG4gICAgbW9kdWxlSWQ6ICdNLTEwMycsXHJcbiAgICB0YXJnZXRTdGFuZGFyZDogJzZ0aCAtIDh0aCBTdGFuZGFyZCcsXHJcbiAgICBkdXJhdGlvbjogJzkwIE1pbnMnLFxyXG4gICAgcGFuY2hheWF0SWQ6IHBhbmNoYXlhdHNbMF0/LmlkIHx8ICd2ZWRha2thdHRhbWFkdXZ1JyxcclxuICAgIHBhbmNoYXlhdE5hbWU6IHBhbmNoYXlhdHNbMF0/Lm5hbWUgfHwgJ1ZlZGFra2F0dGFtYWR1dnUnLFxyXG4gICAgdmlsbGFnZU5hbWU6IHBhbmNoYXlhdHNbMF0/LnZpbGxhZ2VzWzBdPy5uYW1lIHx8ICdBbW1hcGV0dGFpJyxcclxuICAgIHZvbHVudGVlcklkOiB2b2x1bnRlZXJzWzBdPy5pZCB8fCAndm9sLTEnLFxyXG4gICAgdm9sdW50ZWVyTmFtZTogdm9sdW50ZWVyc1swXT8ubmFtZSB8fCAnQmFsYScsXHJcbiAgICBkYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSxcclxuICAgIGRheU9mU2Vzc2lvbjogJ1NhdHVyZGF5JyxcclxuICAgIG9iamVjdGl2ZTogJycsXHJcbiAgICBsZWFybmluZ091dGNvbWVzVGV4dDogJycsXHJcbiAgICBpbnRyb2R1Y3Rpb246ICcnLFxyXG4gICAgYWN0aXZpdHk6ICcnLFxyXG4gICAgYWN0aXZpdGllc0xpc3RUZXh0OiAnJyxcclxuICAgIHRlYWNoaW5nTWV0aG9kOiAnJyxcclxuICAgIG1hdGVyaWFsc1RleHQ6ICcnLFxyXG4gICAgYXNzZXNzbWVudFRhc2s6ICcnLFxyXG4gICAgbm90ZXM6ICcnLFxyXG4gICAgc3RhdHVzOiAnRHJhZnQnIGFzIExlc3NvblBsYW5bJ3N0YXR1cyddLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZm9ybUVycm9ycywgc2V0Rm9ybUVycm9yc10gPSB1c2VTdGF0ZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+Pih7fSk7XHJcblxyXG4gIC8vIER5bmFtaWMgbGlzdCBvZiB2aWxsYWdlcyBiYXNlZCBvbiBzZWxlY3RlZCBwYW5jaGF5YXQgaW4gZmlsdGVyXHJcbiAgY29uc3QgY3VycmVudEZpbHRlclZpbGxhZ2VzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRQYW5jaGF5YXQgPT09ICdhbGwnKSB7XHJcbiAgICAgIGNvbnN0IGFsbFZpbGxhZ2VzOiB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9W10gPSBbXTtcclxuICAgICAgcGFuY2hheWF0cy5mb3JFYWNoKChwKSA9PiB7XHJcbiAgICAgICAgcC52aWxsYWdlcz8uZm9yRWFjaCgodikgPT4ge1xyXG4gICAgICAgICAgaWYgKCFhbGxWaWxsYWdlcy5zb21lKChleGlzdGluZykgPT4gZXhpc3RpbmcubmFtZSA9PT0gdi5uYW1lKSkge1xyXG4gICAgICAgICAgICBhbGxWaWxsYWdlcy5wdXNoKHsgaWQ6IHYuaWQsIG5hbWU6IHYubmFtZSB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiBhbGxWaWxsYWdlcztcclxuICAgIH1cclxuICAgIGNvbnN0IGZvdW5kID0gcGFuY2hheWF0cy5maW5kKChwKSA9PiBwLmlkID09PSBzZWxlY3RlZFBhbmNoYXlhdCk7XHJcbiAgICByZXR1cm4gZm91bmQ/LnZpbGxhZ2VzIHx8IFtdO1xyXG4gIH0sIFtzZWxlY3RlZFBhbmNoYXlhdCwgcGFuY2hheWF0c10pO1xyXG5cclxuICAvLyBEeW5hbWljIGxpc3Qgb2YgdmlsbGFnZXMgZm9yIG1vZGFsXHJcbiAgY29uc3QgbW9kYWxWaWxsYWdlcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZm91bmQgPSBwYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IGZvcm1EYXRhLnBhbmNoYXlhdElkKTtcclxuICAgIHJldHVybiBmb3VuZD8udmlsbGFnZXMgfHwgW107XHJcbiAgfSwgW2Zvcm1EYXRhLnBhbmNoYXlhdElkLCBwYW5jaGF5YXRzXSk7XHJcblxyXG4gIC8vIEV4dHJhY3QgaGVscGVyIHRvcGljXHJcbiAgY29uc3QgZ2V0UGxhblRvcGljID0gKGxwOiBMZXNzb25QbGFuKTogc3RyaW5nID0+IHtcclxuICAgIHJldHVybiBscC50b3BpYyB8fCBscC50aXRsZSB8fCBscC5zZXNzaW9uTmFtZSB8fCAnVW50aXRsZWQgTGVzc29uIFBsYW4nO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFBsYW5Nb2R1bGUgPSAobHA6IExlc3NvblBsYW4pOiBzdHJpbmcgPT4ge1xyXG4gICAgcmV0dXJuIGxwLm1vZHVsZU5hbWUgfHwgbHAubW9kdWxlSWQgfHwgJ0dlbmVyYWwgQ3VycmljdWx1bSc7XHJcbiAgfTtcclxuXHJcbiAgLy8gRmlsdGVyZWQgTGVzc29uIFBsYW5zXHJcbiAgY29uc3QgZmlsdGVyZWRQbGFucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGxlc3NvblBsYW5zLmZpbHRlcigobHApID0+IHtcclxuICAgICAgY29uc3QgdG9waWMgPSBnZXRQbGFuVG9waWMobHApLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IG1vZCA9IGdldFBsYW5Nb2R1bGUobHApLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IHZpbGwgPSAobHAudmlsbGFnZU5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IHZvbCA9IChscC52b2x1bnRlZXJOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBwYW4gPSAobHAucGFuY2hheWF0TmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgY29uc3Qgc2VhcmNoID0gc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoU2VhcmNoID1cclxuICAgICAgICAhc2VhcmNoIHx8XHJcbiAgICAgICAgdG9waWMuaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIG1vZC5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgdmlsbC5pbmNsdWRlcyhzZWFyY2gpIHx8XHJcbiAgICAgICAgdm9sLmluY2x1ZGVzKHNlYXJjaCkgfHxcclxuICAgICAgICBwYW4uaW5jbHVkZXMoc2VhcmNoKSB8fFxyXG4gICAgICAgIChscC5vYmplY3RpdmUgfHwgJycpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoUGFuY2hheWF0ID1cclxuICAgICAgICBzZWxlY3RlZFBhbmNoYXlhdCA9PT0gJ2FsbCcgfHwgbHAucGFuY2hheWF0SWQgPT09IHNlbGVjdGVkUGFuY2hheWF0O1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hWaWxsYWdlID1cclxuICAgICAgICBzZWxlY3RlZFZpbGxhZ2UgPT09ICdhbGwnIHx8XHJcbiAgICAgICAgKGxwLnZpbGxhZ2VOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFZpbGxhZ2UudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgIGNvbnN0IG1hdGNoU3RhdHVzID1cclxuICAgICAgICBzZWxlY3RlZFN0YXR1cyA9PT0gJ2FsbCcgfHxcclxuICAgICAgICAobHAuc3RhdHVzIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFN0YXR1cy50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hWb2x1bnRlZXIgPVxyXG4gICAgICAgIHNlbGVjdGVkVm9sdW50ZWVyID09PSAnYWxsJyB8fFxyXG4gICAgICAgIGxwLnZvbHVudGVlcklkID09PSBzZWxlY3RlZFZvbHVudGVlciB8fFxyXG4gICAgICAgIChscC52b2x1bnRlZXJOYW1lIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFZvbHVudGVlci50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgcmV0dXJuIG1hdGNoU2VhcmNoICYmIG1hdGNoUGFuY2hheWF0ICYmIG1hdGNoVmlsbGFnZSAmJiBtYXRjaFN0YXR1cyAmJiBtYXRjaFZvbHVudGVlcjtcclxuICAgIH0pO1xyXG4gIH0sIFtsZXNzb25QbGFucywgc2VhcmNoVGVybSwgc2VsZWN0ZWRQYW5jaGF5YXQsIHNlbGVjdGVkVmlsbGFnZSwgc2VsZWN0ZWRTdGF0dXMsIHNlbGVjdGVkVm9sdW50ZWVyXSk7XHJcblxyXG4gIC8vIENvdW50c1xyXG4gIGNvbnN0IHRvdGFsQ291bnQgPSBsZXNzb25QbGFucy5sZW5ndGg7XHJcbiAgY29uc3QgYXBwcm92ZWRDb3VudCA9IGxlc3NvblBsYW5zLmZpbHRlcihcclxuICAgIChscCkgPT4gbHAuc3RhdHVzID09PSAnQXBwcm92ZWQnIHx8IGxwLnN0YXR1cyA9PT0gJ0NvbXBsZXRlZCcgfHwgbHAuc3RhdHVzID09PSAnQWN0aXZlJ1xyXG4gICkubGVuZ3RoO1xyXG4gIGNvbnN0IHN1Ym1pdHRlZENvdW50ID0gbGVzc29uUGxhbnMuZmlsdGVyKFxyXG4gICAgKGxwKSA9PiBscC5zdGF0dXMgPT09ICdTdWJtaXR0ZWQnIHx8IGxwLnN0YXR1cyA9PT0gJ1Jlc3VibWl0dGVkJyB8fCBscC5zdGF0dXMgPT09ICdVcGNvbWluZydcclxuICApLmxlbmd0aDtcclxuICBjb25zdCBjb3JyZWN0aW9uQ291bnQgPSBsZXNzb25QbGFucy5maWx0ZXIoXHJcbiAgICAobHApID0+IGxwLnN0YXR1cyA9PT0gJ0NvcnJlY3Rpb24gUmVxdWVzdGVkJ1xyXG4gICkubGVuZ3RoO1xyXG5cclxuICAvLyBDbGVhciBmaWx0ZXJzXHJcbiAgY29uc3QgaGFuZGxlQ2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGVybSgnJyk7XHJcbiAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdCgnYWxsJyk7XHJcbiAgICBzZXRTZWxlY3RlZFZpbGxhZ2UoJ2FsbCcpO1xyXG4gICAgc2V0U2VsZWN0ZWRTdGF0dXMoJ2FsbCcpO1xyXG4gICAgc2V0U2VsZWN0ZWRWb2x1bnRlZXIoJ2FsbCcpO1xyXG4gIH07XHJcblxyXG4gIC8vIE9wZW4gQ3JlYXRlIEZvcm1cclxuICBjb25zdCBoYW5kbGVPcGVuTmV3TW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0VkaXRNb2RlKGZhbHNlKTtcclxuICAgIHNldEZvcm1FcnJvcnMoe30pO1xyXG4gICAgY29uc3QgZGVmYXVsdFAgPSBwYW5jaGF5YXRzWzBdO1xyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBpZDogJycsXHJcbiAgICAgIHRvcGljOiAnJyxcclxuICAgICAgbW9kdWxlTmFtZTogJ1Nwb2tlbiBFbmdsaXNoJyxcclxuICAgICAgbW9kdWxlSWQ6ICdNLTEwMycsXHJcbiAgICAgIHRhcmdldFN0YW5kYXJkOiAnNnRoIC0gOHRoIFN0YW5kYXJkJyxcclxuICAgICAgZHVyYXRpb246ICc5MCBNaW5zJyxcclxuICAgICAgcGFuY2hheWF0SWQ6IGRlZmF1bHRQPy5pZCB8fCAndmVkYWtrYXR0YW1hZHV2dScsXHJcbiAgICAgIHBhbmNoYXlhdE5hbWU6IGRlZmF1bHRQPy5uYW1lIHx8ICdWZWRha2thdHRhbWFkdXZ1JyxcclxuICAgICAgdmlsbGFnZU5hbWU6IGRlZmF1bHRQPy52aWxsYWdlc1swXT8ubmFtZSB8fCAnQW1tYXBldHRhaScsXHJcbiAgICAgIHZvbHVudGVlcklkOiB2b2x1bnRlZXJzWzBdPy5pZCB8fCAndm9sLTEnLFxyXG4gICAgICB2b2x1bnRlZXJOYW1lOiB2b2x1bnRlZXJzWzBdPy5uYW1lIHx8ICdCYWxhJyxcclxuICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF0sXHJcbiAgICAgIGRheU9mU2Vzc2lvbjogJ1NhdHVyZGF5JyxcclxuICAgICAgb2JqZWN0aXZlOiAnJyxcclxuICAgICAgbGVhcm5pbmdPdXRjb21lc1RleHQ6ICcxLiBSZWNvZ25pemUgY29yZSB2b2NhYnVsYXJ5IHdvcmRzIGluIHJlYWwgZGlhbG9ndWVcXG4yLiBGb3JtIDMtNSBmdWxsIHNlbnRlbmNlcyBpbmRlcGVuZGVudGx5XFxuMy4gUGFydGljaXBhdGUgaW4gZ3JvdXAgcm9sZXBsYXkgY2hhbGxlbmdlJyxcclxuICAgICAgaW50cm9kdWN0aW9uOiAnMTAtbWludXRlIHdhcm0tdXAgZ2FtZSBhbmQgcmV2aWV3IG9mIHByZXZpb3VzIG1vZHVsZSBjb25jZXB0cy4nLFxyXG4gICAgICBhY3Rpdml0eTogJ0ludGVyYWN0aXZlIGdyb3VwIHdvcmtzaGVldHMgYW5kIHN0cnVjdHVyZWQgcm9sZS1wbGF5IGRyaWxscyBpbiBwYWlycy4nLFxyXG4gICAgICBhY3Rpdml0aWVzTGlzdFRleHQ6ICdXYXJtLXVwICYgSWNlYnJlYWtlciAoMTUgbWlucylcXG5Db25jZXB0IERlbW9uc3RyYXRpb24gb24gV2hpdGVib2FyZCAoMjUgbWlucylcXG5Hcm91cCBBY3Rpdml0eSAmIFdvcmtzaGVldHMgKDMwIG1pbnMpXFxuRXhpdCBTbGlwICYgVm9jYWJ1bGFyeSBRdWl6ICgyMCBtaW5zKScsXHJcbiAgICAgIHRlYWNoaW5nTWV0aG9kOiAnVmlzdWFsIGRlbW9uc3RyYXRpb24sIHBlZXIgZ3JvdXAgcHJvYmxlbSBzb2x2aW5nLCBpbnRlcmFjdGl2ZSB3b3Jrc2hlZXRzLicsXHJcbiAgICAgIG1hdGVyaWFsc1RleHQ6ICdGbGFzaGNhcmRzLCBXb3Jrc2hlZXRzICgzMCBjb3BpZXMpLCBXaGl0ZWJvYXJkIG1hcmtlcnMsIFN0dWRlbnQgcmV3YXJkIHN0aWNrZXJzJyxcclxuICAgICAgYXNzZXNzbWVudFRhc2s6ICdFeGl0IHNsaXAgcXVpeiB3aXRoIDMgc2hvcnQgY29uY2VwdHVhbCBxdWVzdGlvbnMgZXZhbHVhdGVkIGluIHBlZXIgcGFpcnMuJyxcclxuICAgICAgbm90ZXM6ICdLZWVwIGV4dHJhIGNyYWZ0IGtpdHMgaW4gY2VudGVyIGJhZy4nLFxyXG4gICAgICBzdGF0dXM6ICdEcmFmdCcsXHJcbiAgICB9KTtcclxuICAgIHNldElzTmV3TW9kYWxPcGVuKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIE9wZW4gRWRpdCBGb3JtXHJcbiAgY29uc3QgaGFuZGxlT3BlbkVkaXRNb2RhbCA9IChwbGFuOiBMZXNzb25QbGFuKSA9PiB7XHJcbiAgICBzZXRJc0VkaXRNb2RlKHRydWUpO1xyXG4gICAgc2V0Rm9ybUVycm9ycyh7fSk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIGlkOiBwbGFuLmlkLFxyXG4gICAgICB0b3BpYzogcGxhbi50b3BpYyB8fCBwbGFuLnRpdGxlIHx8IHBsYW4uc2Vzc2lvbk5hbWUgfHwgJycsXHJcbiAgICAgIG1vZHVsZU5hbWU6IHBsYW4ubW9kdWxlTmFtZSB8fCAnU3Bva2VuIEVuZ2xpc2gnLFxyXG4gICAgICBtb2R1bGVJZDogcGxhbi5tb2R1bGVJZCB8fCAnTS0xMDMnLFxyXG4gICAgICB0YXJnZXRTdGFuZGFyZDogcGxhbi50YXJnZXRTdGFuZGFyZCB8fCAnNnRoIC0gOHRoIFN0YW5kYXJkJyxcclxuICAgICAgZHVyYXRpb246IHBsYW4uZHVyYXRpb24gfHwgJzkwIE1pbnMnLFxyXG4gICAgICBwYW5jaGF5YXRJZDogcGxhbi5wYW5jaGF5YXRJZCB8fCAocGFuY2hheWF0c1swXT8uaWQgfHwgJycpLFxyXG4gICAgICBwYW5jaGF5YXROYW1lOiBwbGFuLnBhbmNoYXlhdE5hbWUgfHwgKHBhbmNoYXlhdHNbMF0/Lm5hbWUgfHwgJycpLFxyXG4gICAgICB2aWxsYWdlTmFtZTogcGxhbi52aWxsYWdlTmFtZSB8fCAnJyxcclxuICAgICAgdm9sdW50ZWVySWQ6IHBsYW4udm9sdW50ZWVySWQgfHwgKHZvbHVudGVlcnNbMF0/LmlkIHx8ICcnKSxcclxuICAgICAgdm9sdW50ZWVyTmFtZTogcGxhbi52b2x1bnRlZXJOYW1lIHx8ICdCYWxhJyxcclxuICAgICAgZGF0ZTogcGxhbi5kYXRlIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdLFxyXG4gICAgICBkYXlPZlNlc3Npb246IHBsYW4uZGF5T2ZTZXNzaW9uIHx8ICdTYXR1cmRheScsXHJcbiAgICAgIG9iamVjdGl2ZTogcGxhbi5vYmplY3RpdmUgfHwgJycsXHJcbiAgICAgIGxlYXJuaW5nT3V0Y29tZXNUZXh0OiBwbGFuLmxlYXJuaW5nT3V0Y29tZXM/LmpvaW4oJ1xcbicpIHx8ICcnLFxyXG4gICAgICBpbnRyb2R1Y3Rpb246IHBsYW4uaW50cm9kdWN0aW9uIHx8ICcnLFxyXG4gICAgICBhY3Rpdml0eTogcGxhbi5hY3Rpdml0eSB8fCAnJyxcclxuICAgICAgYWN0aXZpdGllc0xpc3RUZXh0OiBwbGFuLmFjdGl2aXRpZXNMaXN0Py5qb2luKCdcXG4nKSB8fCAnJyxcclxuICAgICAgdGVhY2hpbmdNZXRob2Q6IHBsYW4udGVhY2hpbmdNZXRob2QgfHwgJycsXHJcbiAgICAgIG1hdGVyaWFsc1RleHQ6IEFycmF5LmlzQXJyYXkocGxhbi5tYXRlcmlhbHMpXHJcbiAgICAgICAgPyBwbGFuLm1hdGVyaWFscy5qb2luKCcsICcpXHJcbiAgICAgICAgOiAocGxhbi5tYXRlcmlhbHNMaXN0Py5qb2luKCdcXG4nKSB8fCAocGxhbi5tYXRlcmlhbHMgYXMgc3RyaW5nKSB8fCAnJyksXHJcbiAgICAgIGFzc2Vzc21lbnRUYXNrOiBwbGFuLmFzc2Vzc21lbnRUYXNrIHx8ICcnLFxyXG4gICAgICBub3RlczogcGxhbi5ub3RlcyB8fCAnJyxcclxuICAgICAgc3RhdHVzOiBwbGFuLnN0YXR1cyB8fCAnRHJhZnQnLFxyXG4gICAgfSk7XHJcbiAgICBzZXRJc05ld01vZGFsT3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyBGb3JtIFN1Ym1pdFxyXG4gIGNvbnN0IGhhbmRsZUZvcm1TdWJtaXQgPSAodGFyZ2V0U3RhdHVzOiBMZXNzb25QbGFuWydzdGF0dXMnXSkgPT4ge1xyXG4gICAgY29uc3QgZXJyb3JzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XHJcbiAgICBpZiAoIWZvcm1EYXRhLnRvcGljLnRyaW0oKSkgZXJyb3JzLnRvcGljID0gJ1RvcGljIC8gVGl0bGUgaXMgcmVxdWlyZWQuJztcclxuICAgIGlmICghZm9ybURhdGEub2JqZWN0aXZlLnRyaW0oKSkgZXJyb3JzLm9iamVjdGl2ZSA9ICdPYmplY3RpdmUgaXMgcmVxdWlyZWQuJztcclxuICAgIGlmICghZm9ybURhdGEudmlsbGFnZU5hbWUudHJpbSgpKSBlcnJvcnMudmlsbGFnZU5hbWUgPSAnUGxlYXNlIHNlbGVjdCBhIHZpbGxhZ2UgY2VudGVyLic7XHJcblxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGVycm9ycykubGVuZ3RoID4gMCkge1xyXG4gICAgICBzZXRGb3JtRXJyb3JzKGVycm9ycyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBsZWFybmluZ091dGNvbWVzID0gZm9ybURhdGEubGVhcm5pbmdPdXRjb21lc1RleHRcclxuICAgICAgLnNwbGl0KCdcXG4nKVxyXG4gICAgICAubWFwKChzKSA9PiBzLnRyaW0oKSlcclxuICAgICAgLmZpbHRlcihCb29sZWFuKTtcclxuXHJcbiAgICBjb25zdCBhY3Rpdml0aWVzTGlzdCA9IGZvcm1EYXRhLmFjdGl2aXRpZXNMaXN0VGV4dFxyXG4gICAgICAuc3BsaXQoJ1xcbicpXHJcbiAgICAgIC5tYXAoKHMpID0+IHMudHJpbSgpKVxyXG4gICAgICAuZmlsdGVyKEJvb2xlYW4pO1xyXG5cclxuICAgIGNvbnN0IG1hdGVyaWFsc0xpc3QgPSBmb3JtRGF0YS5tYXRlcmlhbHNUZXh0XHJcbiAgICAgIC5zcGxpdCgnXFxuJylcclxuICAgICAgLm1hcCgocykgPT4gcy50cmltKCkpXHJcbiAgICAgIC5maWx0ZXIoQm9vbGVhbik7XHJcblxyXG4gICAgY29uc3QgcGF5bG9hZDogUGFydGlhbDxMZXNzb25QbGFuPiA9IHtcclxuICAgICAgdG9waWM6IGZvcm1EYXRhLnRvcGljLnRyaW0oKSxcclxuICAgICAgdGl0bGU6IGZvcm1EYXRhLnRvcGljLnRyaW0oKSxcclxuICAgICAgbW9kdWxlTmFtZTogZm9ybURhdGEubW9kdWxlTmFtZSxcclxuICAgICAgbW9kdWxlSWQ6IGZvcm1EYXRhLm1vZHVsZUlkLFxyXG4gICAgICB0YXJnZXRTdGFuZGFyZDogZm9ybURhdGEudGFyZ2V0U3RhbmRhcmQsXHJcbiAgICAgIGR1cmF0aW9uOiBmb3JtRGF0YS5kdXJhdGlvbixcclxuICAgICAgcGFuY2hheWF0SWQ6IGZvcm1EYXRhLnBhbmNoYXlhdElkLFxyXG4gICAgICBwYW5jaGF5YXROYW1lOiBmb3JtRGF0YS5wYW5jaGF5YXROYW1lLFxyXG4gICAgICB2aWxsYWdlTmFtZTogZm9ybURhdGEudmlsbGFnZU5hbWUsXHJcbiAgICAgIHZvbHVudGVlcklkOiBmb3JtRGF0YS52b2x1bnRlZXJJZCxcclxuICAgICAgdm9sdW50ZWVyTmFtZTogZm9ybURhdGEudm9sdW50ZWVyTmFtZSxcclxuICAgICAgZGF0ZTogZm9ybURhdGEuZGF0ZSxcclxuICAgICAgZGF5T2ZTZXNzaW9uOiBmb3JtRGF0YS5kYXlPZlNlc3Npb24sXHJcbiAgICAgIG9iamVjdGl2ZTogZm9ybURhdGEub2JqZWN0aXZlLnRyaW0oKSxcclxuICAgICAgbGVhcm5pbmdPdXRjb21lczogbGVhcm5pbmdPdXRjb21lcy5sZW5ndGggPiAwID8gbGVhcm5pbmdPdXRjb21lcyA6IFtmb3JtRGF0YS5vYmplY3RpdmUudHJpbSgpXSxcclxuICAgICAgaW50cm9kdWN0aW9uOiBmb3JtRGF0YS5pbnRyb2R1Y3Rpb24sXHJcbiAgICAgIGFjdGl2aXR5OiBmb3JtRGF0YS5hY3Rpdml0eSxcclxuICAgICAgYWN0aXZpdGllc0xpc3Q6IGFjdGl2aXRpZXNMaXN0Lmxlbmd0aCA+IDAgPyBhY3Rpdml0aWVzTGlzdCA6IFtmb3JtRGF0YS5hY3Rpdml0eV0sXHJcbiAgICAgIHRlYWNoaW5nTWV0aG9kOiBmb3JtRGF0YS50ZWFjaGluZ01ldGhvZCxcclxuICAgICAgbWF0ZXJpYWxzOiBmb3JtRGF0YS5tYXRlcmlhbHNUZXh0LFxyXG4gICAgICBtYXRlcmlhbHNMaXN0OiBtYXRlcmlhbHNMaXN0LFxyXG4gICAgICBhc3Nlc3NtZW50VGFzazogZm9ybURhdGEuYXNzZXNzbWVudFRhc2ssXHJcbiAgICAgIG5vdGVzOiBmb3JtRGF0YS5ub3RlcyxcclxuICAgICAgc3RhdHVzOiB0YXJnZXRTdGF0dXMsXHJcbiAgICAgIGxhc3RVcGRhdGVkOiBgJHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tR0InLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0JywgeWVhcjogJ251bWVyaWMnIH0pfSwgJHtuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfWAsXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChpc0VkaXRNb2RlICYmIGZvcm1EYXRhLmlkKSB7XHJcbiAgICAgIG9uVXBkYXRlTGVzc29uUGxhbihmb3JtRGF0YS5pZCwgcGF5bG9hZCk7XHJcbiAgICAgIGlmIChhY3RpdmVQbGFuRGV0YWlsPy5pZCA9PT0gZm9ybURhdGEuaWQpIHtcclxuICAgICAgICBzZXRBY3RpdmVQbGFuRGV0YWlsKChwcmV2KSA9PiAocHJldiA/IHsgLi4ucHJldiwgLi4ucGF5bG9hZCB9IDogbnVsbCkpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBuZXdQbGFuOiBPbWl0PExlc3NvblBsYW4sICdpZCc+ID0ge1xyXG4gICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgc2Vzc2lvbk5hbWU6IGZvcm1EYXRhLnRvcGljLnRyaW0oKSxcclxuICAgICAgICB2b2x1bnRlZXJzQ291bnQ6IDMsXHJcbiAgICAgICAgY2x1c3RlcjogJ0RoYXJtYXB1cmknLFxyXG4gICAgICAgIHNwb2M6IGZvcm1EYXRhLnZvbHVudGVlck5hbWUsXHJcbiAgICAgICAgZmluYW5jZXI6ICdDbHVzdGVyIEZ1bmQnLFxyXG4gICAgICB9O1xyXG4gICAgICBvbkFkZExlc3NvblBsYW4obmV3UGxhbik7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNOZXdNb2RhbE9wZW4oZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIFN0YXR1cyBBY3Rpb246IEFwcHJvdmVcclxuICBjb25zdCBoYW5kbGVBcHByb3ZlUGxhbiA9IChwbGFuSWQ6IHN0cmluZykgPT4ge1xyXG4gICAgb25VcGRhdGVMZXNzb25QbGFuKHBsYW5JZCwge1xyXG4gICAgICBzdGF0dXM6ICdBcHByb3ZlZCcsXHJcbiAgICAgIGNvcnJlY3Rpb25SZWFzb246IHVuZGVmaW5lZCxcclxuICAgICAgY29ycmVjdGlvblJlcXVlc3RlZEJ5OiB1bmRlZmluZWQsXHJcbiAgICAgIGxhc3RVcGRhdGVkOiAnSnVzdCBub3cgYnkgQ2x1c3RlciBBZG1pbicsXHJcbiAgICB9KTtcclxuICAgIGlmIChhY3RpdmVQbGFuRGV0YWlsPy5pZCA9PT0gcGxhbklkKSB7XHJcbiAgICAgIHNldEFjdGl2ZVBsYW5EZXRhaWwoKHByZXYpID0+IChwcmV2ID8geyAuLi5wcmV2LCBzdGF0dXM6ICdBcHByb3ZlZCcsIGNvcnJlY3Rpb25SZWFzb246IHVuZGVmaW5lZCB9IDogbnVsbCkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIFN0YXR1cyBBY3Rpb246IFN1Ym1pdCBDb3JyZWN0aW9uIFJlcXVlc3RcclxuICBjb25zdCBoYW5kbGVTdWJtaXRDb3JyZWN0aW9uID0gKCkgPT4ge1xyXG4gICAgaWYgKCFhY3RpdmVQbGFuRGV0YWlsIHx8ICFjb3JyZWN0aW9uUmVhc29uSW5wdXQudHJpbSgpKSByZXR1cm47XHJcblxyXG4gICAgb25VcGRhdGVMZXNzb25QbGFuKGFjdGl2ZVBsYW5EZXRhaWwuaWQsIHtcclxuICAgICAgc3RhdHVzOiAnQ29ycmVjdGlvbiBSZXF1ZXN0ZWQnLFxyXG4gICAgICBjb3JyZWN0aW9uUmVhc29uOiBjb3JyZWN0aW9uUmVhc29uSW5wdXQudHJpbSgpLFxyXG4gICAgICBjb3JyZWN0aW9uUmVxdWVzdGVkQnk6ICdDbHVzdGVyIEFkbWluJyxcclxuICAgICAgY29ycmVjdGlvbkRhdGU6IG5ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnc2hvcnQnLCB5ZWFyOiAnbnVtZXJpYycgfSksXHJcbiAgICAgIGxhc3RVcGRhdGVkOiAnQ29ycmVjdGlvbiByZXF1ZXN0ZWQnLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0QWN0aXZlUGxhbkRldGFpbCgocHJldikgPT5cclxuICAgICAgcHJldlxyXG4gICAgICAgID8ge1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBzdGF0dXM6ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCcsXHJcbiAgICAgICAgICAgIGNvcnJlY3Rpb25SZWFzb246IGNvcnJlY3Rpb25SZWFzb25JbnB1dC50cmltKCksXHJcbiAgICAgICAgICAgIGNvcnJlY3Rpb25SZXF1ZXN0ZWRCeTogJ0NsdXN0ZXIgQWRtaW4nLFxyXG4gICAgICAgICAgICBjb3JyZWN0aW9uRGF0ZTogbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJywgeyBkYXk6ICcyLWRpZ2l0JywgbW9udGg6ICdzaG9ydCcsIHllYXI6ICdudW1lcmljJyB9KSxcclxuICAgICAgICAgIH1cclxuICAgICAgICA6IG51bGxcclxuICAgICk7XHJcblxyXG4gICAgc2V0SXNDb3JyZWN0aW9uTW9kYWxPcGVuKGZhbHNlKTtcclxuICAgIHNldENvcnJlY3Rpb25SZWFzb25JbnB1dCgnJyk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRXhwb3J0IFBERiBvciBQcmludCBQcmV2aWV3XHJcbiAgY29uc3QgaGFuZGxlUHJpbnRQREYgPSAocGxhbj86IExlc3NvblBsYW4pID0+IHtcclxuICAgIGNvbnN0IHRhcmdldCA9IHBsYW4gfHwgYWN0aXZlUGxhbkRldGFpbCB8fCBmaWx0ZXJlZFBsYW5zWzBdO1xyXG4gICAgaWYgKCF0YXJnZXQpIHtcclxuICAgICAgYWxlcnQoJ05vIGxlc3NvbiBwbGFuIGF2YWlsYWJsZSB0byBleHBvcnQuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHdpbmRvdy5wcmludCgpO1xyXG4gIH07XHJcblxyXG4gIC8vIFN0YXR1cyBCYWRnZSBIZWxwZXJcclxuICBjb25zdCByZW5kZXJTdGF0dXNCYWRnZSA9IChzdGF0dXM/OiBzdHJpbmcpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbiAgICAgIGNhc2UgJ0FwcHJvdmVkJzpcclxuICAgICAgY2FzZSAnQWN0aXZlJzpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTYwMFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgQXBwcm92ZWRcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlICdTdWJtaXR0ZWQnOlxyXG4gICAgICBjYXNlICdSZXN1Ym1pdHRlZCc6XHJcbiAgICAgIGNhc2UgJ1VwY29taW5nJzpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTYwMFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAge3N0YXR1cyA9PT0gJ1Jlc3VibWl0dGVkJyA/ICdSZXN1Ym1pdHRlZCcgOiAnU3VibWl0dGVkJ31cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlICdDb3JyZWN0aW9uIFJlcXVlc3RlZCc6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTgwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTMwMFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctYW1iZXItNjAwXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICBDb3JyZWN0aW9uIFJlcXVlc3RlZFxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgJ0NvbXBsZXRlZCc6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTYwMFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgQ29tcGxldGVkXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgICAgY2FzZSAnRHJhZnQnOlxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS00MDBcIj48L3NwYW4+XHJcbiAgICAgICAgICAgIERyYWZ0XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiAxLiBDYXJkbGVzcyBQYWdlIEhlYWRlciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgIExlc3NvbiBQbGFuc1xyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICBNYW5hZ2UsIHJldmlldywgYW5kIHRyYWNrIGN1cnJpY3VsdW0gbGVzc29uIHBsYW5zIGFuZCBsZWFybmluZyBhY3Rpdml0aWVzIGFjcm9zcyBjbHVzdGVycy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHNlbGYtc3RhcnQgc206c2VsZi1hdXRvXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmludFBERigpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5FeHBvcnQgUERGPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuTmV3TW9kYWx9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5OZXcgTGVzc29uIFBsYW48L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogMi4gQ29tcGFjdCBNZXRyaWMgQ2FyZHMgKGNvdW50cyAmIHN0YXR1cyBvbmx5KSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlRvdGFsIFBsYW5zPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3RvdGFsQ291bnR9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zdWNjZXNzLTUwMFwiPkFwcHJvdmVkPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2FwcHJvdmVkQ291bnR9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1icmFuZC01MDBcIj5TdWJtaXR0ZWQgLyBSZXZpZXc8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57c3VibWl0dGVkQ291bnR9PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC13YXJuaW5nLTUwMFwiPk5lZWRzIENvcnJlY3Rpb248L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y29ycmVjdGlvbkNvdW50fTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiAzLiBDYXJkbGVzcyBTZWFyY2ggJiBGaWx0ZXIgUm93ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTNcIj5cclxuICAgICAgICB7LyogU2VhcmNoIGJhciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHNtOmNvbC1zcGFuLTIgbGc6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZ3JheS00MDAgYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IHRvcGljLCBtb2R1bGUsIHZvbHVudGVlciBvciB2aWxsYWdlLi4uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwbC0xMCBwci04IHB5LTIgdGV4dC14cyB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICB7c2VhcmNoVGVybSAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hUZXJtKCcnKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUGFuY2hheWF0IGZpbHRlciAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQYW5jaGF5YXQgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdCh2YWwpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRWaWxsYWdlKCdhbGwnKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBQYW5jaGF5YXRzXCIgLz5cclxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbCBQYW5jaGF5YXRzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAge3BhbmNoYXlhdHMubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cC5pZH0gdmFsdWU9e3AuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogVmlsbGFnZSBmaWx0ZXIgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVmlsbGFnZSB8fCBcImFsbFwifVxyXG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkVmlsbGFnZSh2YWwpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBWaWxsYWdlc1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgVmlsbGFnZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudEZpbHRlclZpbGxhZ2VzLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2Lm5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt2Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU3RhdHVzIGZpbHRlciAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRTdGF0dXMgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZFN0YXR1cyh2YWwpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC04IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBTdGF0dXNlc1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkFwcHJvdmVkXCI+QXBwcm92ZWQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlN1Ym1pdHRlZFwiPlN1Ym1pdHRlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQ29ycmVjdGlvbiBSZXF1ZXN0ZWRcIj5Db3JyZWN0aW9uIFJlcXVlc3RlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiUmVzdWJtaXR0ZWRcIj5SZXN1Ym1pdHRlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiRHJhZnRcIj5EcmFmdDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQ29tcGxldGVkXCI+Q29tcGxldGVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBMRVNTT04gUExBTiBUQUJMRSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHNoYWRvdy14cyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQteHNcIj5cclxuICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNjAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMuNVwiPkRhdGUgJmFtcDsgTW9kdWxlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+VG9waWMgJmFtcDsgTGVhcm5pbmcgT2JqZWN0aXZlPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMy41XCI+UGFuY2hheWF0ICZhbXA7IFZpbGxhZ2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5Wb2x1bnRlZXI8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjVcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zLjUgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkUGxhbnMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Nn0gY2xhc3NOYW1lPVwicHktMTAgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzMycHhdIHRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lbnVfYm9va1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtNzAwXCI+Tm8gbGVzc29uIHBsYW5zIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtYXgtdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUcnkgYWRqdXN0aW5nIHlvdXIgZmlsdGVycyBvciBjcmVhdGUgYSBuZXcgbGVzc29uIHBsYW4uXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFyRmlsdGVyc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMwQjNEOTFdIGJnLWJsdWUtNTAgcm91bmRlZC1tZCBob3ZlcjpiZy1ibHVlLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlc2V0IEZpbHRlcnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRQbGFucy5tYXAoKHBsYW4pID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDb3JyZWN0aW9uUmVxID0gcGxhbi5zdGF0dXMgPT09ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCc7XHJcblxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtwbGFuLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaG92ZXI6Ymctc2xhdGUtNTAvODAgdHJhbnNpdGlvbi1jb2xvcnMgZ3JvdXAgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNDb3JyZWN0aW9uUmVxID8gJ2JnLWFtYmVyLTUwLzMwJyA6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogRGF0ZSAmIE1vZHVsZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMuNSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPntwbGFuLmRhdGUgfHwgJzI4IEF1ZyAyMDI2J308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbGF0ZS02MDAgYmctc2xhdGUtMTAwIHB4LTEgcHktMC4yIHJvdW5kZWQgdGV4dC1bMTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFuLm1vZHVsZUlkIHx8ICdNLTEwMyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Z2V0UGxhbk1vZHVsZShwbGFuKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogVG9waWMgJiBPYmplY3RpdmUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zLjUgbWF4LXcteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGdyb3VwLWhvdmVyOnRleHQtWyMwQjNEOTFdIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dldFBsYW5Ub3BpYyhwbGFuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbGluZS1jbGFtcC0xIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwbGFuLm9iamVjdGl2ZSB8fCBwbGFuLmRlc2NyaXB0aW9uIHx8ICdDb3JlIGN1cnJpY3VsdW0gbGVhcm5pbmcgb2JqZWN0aXZlJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYW5jaGF5YXQgJiBWaWxsYWdlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMy41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDBcIj57cGxhbi5wYW5jaGF5YXROYW1lIHx8ICdWZWRha2thdHRhbWFkdXZ1J308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPntwbGFuLnZpbGxhZ2VOYW1lIHx8ICdBbW1hcGV0dGFpJ308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFZvbHVudGVlciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLVsjMEIzRDkxXS8xMCB0ZXh0LVsjMEIzRDkxXSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsocGxhbi52b2x1bnRlZXJOYW1lIHx8ICdCJykuY2hhckF0KDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwbGFuLnZvbHVudGVlck5hbWUgfHwgJ0JhbGEnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zLjUgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlclN0YXR1c0JhZGdlKHBsYW4uc3RhdHVzKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zLjUgdGV4dC1yaWdodCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVBsYW5EZXRhaWwocGxhbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBob3Zlcjp0ZXh0LVsjMEIzRDkxXSBob3ZlcjpiZy1zbGF0ZS01MCByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctMnhzIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IFBsYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFF1aWNrIEFkbWluIEFjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3BsYW4uc3RhdHVzID09PSAnU3VibWl0dGVkJyB8fCBwbGFuLnN0YXR1cyA9PT0gJ1Jlc3VibWl0dGVkJyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQXBwcm92ZVBsYW4ocGxhbi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LWVtZXJhbGQtNzAwIGJnLWVtZXJhbGQtNTAgaG92ZXI6YmctZW1lcmFsZC0xMDAgcm91bmRlZCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFwcHJvdmUgTGVzc29uIFBsYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHByb3ZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3BlbkVkaXRNb2RhbChwbGFuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXQgTGVzc29uIFBsYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5lZGl0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEZVTEwgTEVTU09OIFBMQU4gREVUQUlMIE1PREFMIC8gRFJBV0VSICovfVxyXG4gICAgICB7YWN0aXZlUGxhbkRldGFpbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTMgc206cC00IGJnLWdyYXktOTAwLzcwIGJhY2tkcm9wLWJsdXItc20gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtIG1heC13LTN4bCB3LWZ1bGwgbWF4LWgtWzkydmhdIGZsZXggZmxleC1jb2wgbXktYXV0byBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTBcIj5cclxuICAgICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MC83MCByb3VuZGVkLXQteGwgZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyBmb250LWJvbGQgYmctWyMwQjNEOTFdLzEwIHRleHQtWyMwQjNEOTFdIHB4LTIgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5tb2R1bGVJZCB8fCAnTS0xMDMnfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtyZW5kZXJTdGF0dXNCYWRnZShhY3RpdmVQbGFuRGV0YWlsLnN0YXR1cyl9XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICBEdXJhdGlvbjoge2FjdGl2ZVBsYW5EZXRhaWwuZHVyYXRpb24gfHwgJzkwIE1pbnMnfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Z2V0UGxhblRvcGljKGFjdGl2ZVBsYW5EZXRhaWwpfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2dldFBsYW5Nb2R1bGUoYWN0aXZlUGxhbkRldGFpbCl9IOKAoiBTdGFuZGFyZDoge2FjdGl2ZVBsYW5EZXRhaWwudGFyZ2V0U3RhbmRhcmQgfHwgJzZ0aCAtIDh0aCBTdGFuZGFyZCd9IOKAoiB7YWN0aXZlUGxhbkRldGFpbC5wYW5jaGF5YXROYW1lfSAoe2FjdGl2ZVBsYW5EZXRhaWwudmlsbGFnZU5hbWV9KVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnRQREYoYWN0aXZlUGxhbkRldGFpbCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTUwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlByaW50IC8gU2F2ZSBQREZcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+cHJpbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPlByaW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVBsYW5EZXRhaWwobnVsbCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIHAtMS41IHJvdW5kZWQtbWQgaG92ZXI6Ymctc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMHB4XVwiPmNsb3NlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEJvZHkgQ29udGVudCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgey8qIENvcnJlY3Rpb24gUmVxdWVzdGVkIEJhbm5lciBpZiBhcHBsaWNhYmxlICovfVxyXG4gICAgICAgICAgICAgIHthY3RpdmVQbGFuRGV0YWlsLnN0YXR1cyA9PT0gJ0NvcnJlY3Rpb24gUmVxdWVzdGVkJyAmJiBhY3RpdmVQbGFuRGV0YWlsLmNvcnJlY3Rpb25SZWFzb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBib3JkZXIgYm9yZGVyLWFtYmVyLTMwMCByb3VuZGVkLW1kIHAtMy41IHNwYWNlLXktMS41IHRleHQtYW1iZXItOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtYW1iZXItOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdIHRleHQtYW1iZXItNzAwXCI+d2FybmluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIENvcnJlY3Rpb24gUmVxdWVzdGVkIGJ5IHthY3RpdmVQbGFuRGV0YWlsLmNvcnJlY3Rpb25SZXF1ZXN0ZWRCeSB8fCAnQ2x1c3RlciBBZG1pbid9ICh7YWN0aXZlUGxhbkRldGFpbC5jb3JyZWN0aW9uRGF0ZSB8fCAnUmVjZW50J30pXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwID0gYWN0aXZlUGxhbkRldGFpbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlUGxhbkRldGFpbChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlT3BlbkVkaXRNb2RhbChwKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1hbWJlci03MDAgaG92ZXI6YmctYW1iZXItODAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkIHRleHQtWzExcHhdIHNoYWRvdy0yeHNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEVkaXQgJmFtcDsgUmVzdWJtaXQgUGxhblxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTgwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW0gcGwtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICZxdW90O3thY3RpdmVQbGFuRGV0YWlsLmNvcnJlY3Rpb25SZWFzb259JnF1b3Q7XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBPYmplY3RpdmUgJiBFeHBlY3RlZCBMZWFybmluZyBPdXRjb21lcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC00IHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFByaW1hcnkgT2JqZWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtODAwIGZvbnQtbWVkaXVtIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVQbGFuRGV0YWlsLm9iamVjdGl2ZSB8fCBhY3RpdmVQbGFuRGV0YWlsLmRlc2NyaXB0aW9uIHx8ICdTdHVkZW50cyB3aWxsIHVuZGVyc3RhbmQga2V5IGZvdW5kYXRpb25hbCBjb25jZXB0cyB0aHJvdWdoIGhhbmRzLW9uIGV4ZXJjaXNlcy4nfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5sZWFybmluZ091dGNvbWVzICYmIGFjdGl2ZVBsYW5EZXRhaWwubGVhcm5pbmdPdXRjb21lcy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIHB0LTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDAgbWItMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFeHBlY3RlZCBMZWFybmluZyBPdXRjb21lczpcclxuICAgICAgICAgICAgICAgICAgICA8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEgcGwtNCBsaXN0LWRpc2MgdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVQbGFuRGV0YWlsLmxlYXJuaW5nT3V0Y29tZXMubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aWR4fSBjbGFzc05hbWU9XCJsZWFkaW5nLW5vcm1hbFwiPntpdGVtfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA5MC1NaW51dGUgU3RydWN0dXJlZCBTZXNzaW9uIFRpbWVsaW5lICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAvNzAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2Vzc2lvbiBBY3Rpdml0eSAmYW1wOyBUaW1lIEJyZWFrZG93biAoOTAgTWlucylcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE1ldGhvZDoge2FjdGl2ZVBsYW5EZXRhaWwudGVhY2hpbmdNZXRob2QgfHwgJ0ludGVyYWN0aXZlIFBlZXIgUHJhY3RpY2UnfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5hY3Rpdml0aWVzTGlzdCAmJiBhY3RpdmVQbGFuRGV0YWlsLmFjdGl2aXRpZXNMaXN0Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVBsYW5EZXRhaWwuYWN0aXZpdGllc0xpc3QubWFwKChzdGVwLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgdGV4dC1zbGF0ZS03MDAgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgYmctWyMwQjNEOTFdLzEwIHRleHQtWyMwQjNEOTFdIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aWR4ICsgMX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj57c3RlcH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVBsYW5EZXRhaWwuYWN0aXZpdHkgfHwgJ1N0cnVjdHVyZWQgZ3JvdXAgd29ya3NoZWV0cywgaW50ZXJhY3RpdmUgZHJpbGxzLCBhbmQgcHJlc2VudGF0aW9uLid9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIE1hdGVyaWFscyBDaGVja2xpc3QgJiBBc3Nlc3NtZW50IFRhc2sgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zLjVcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBNYXRlcmlhbHMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zLjUgYmctd2hpdGUgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF0gdGV4dC1bIzBCM0Q5MV1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIGludmVudG9yeV8yXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIE1hdGVyaWFscyAmYW1wOyBUZWFjaGluZyBBaWRzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVBsYW5EZXRhaWwubWF0ZXJpYWxzTGlzdCAmJiBhY3RpdmVQbGFuRGV0YWlsLm1hdGVyaWFsc0xpc3QubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJsaXN0LWRpc2MgcGwtNCBzcGFjZS15LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5tYXRlcmlhbHNMaXN0Lm1hcCgobSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9PnttfTwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHA+e0FycmF5LmlzQXJyYXkoYWN0aXZlUGxhbkRldGFpbC5tYXRlcmlhbHMpID8gYWN0aXZlUGxhbkRldGFpbC5tYXRlcmlhbHMuam9pbignLCAnKSA6IChhY3RpdmVQbGFuRGV0YWlsLm1hdGVyaWFscyB8fCAnU3RhbmRhcmQgY2xhc3Nyb29tIHN0YXRpb25lcnkga2l0IGFuZCB3b3Jrc2hlZXRzLicpfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBBc3Nlc3NtZW50IFRhc2sgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgcC0zLjUgYmctd2hpdGUgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF0gdGV4dC1lbWVyYWxkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmFjdF9jaGVja1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBFdmFsdWF0aW9uICZhbXA7IEV4aXQgQXNzZXNzbWVudFxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5hc3Nlc3NtZW50VGFzayB8fCAnRXhpdCBzbGlwIHF1aXogd2l0aCAzIHNob3J0IGNvbmNlcHR1YWwgcXVlc3Rpb25zIGV2YWx1YXRlZCBpbiBwZWVyIHBhaXJzLid9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogTm90ZXMgLyBSZW1hcmtzICovfVxyXG4gICAgICAgICAgICAgIHthY3RpdmVQbGFuRGV0YWlsLm5vdGVzICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTMgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVm9sdW50ZWVyIEd1aWRhbmNlICZhbXA7IENlbnRlciBMb2dpc3RpY3NcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPnthY3RpdmVQbGFuRGV0YWlsLm5vdGVzfTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIERldGFpbCBGb290ZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHJvdW5kZWQtYi14bFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlUGxhbkRldGFpbChudWxsKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDbG9zZSBQcmV2aWV3XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcCA9IGFjdGl2ZVBsYW5EZXRhaWw7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlUGxhbkRldGFpbChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVPcGVuRWRpdE1vZGFsKHApO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGJnLXdoaXRlIGhvdmVyOmJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgUGxhblxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAge2FjdGl2ZVBsYW5EZXRhaWwuc3RhdHVzICE9PSAnQXBwcm92ZWQnICYmIChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldENvcnJlY3Rpb25SZWFzb25JbnB1dCgnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc0NvcnJlY3Rpb25Nb2RhbE9wZW4odHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJnLWFtYmVyLTYwMCBob3ZlcjpiZy1hbWJlci03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBDb3JyZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7YWN0aXZlUGxhbkRldGFpbC5zdGF0dXMgIT09ICdBcHByb3ZlZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQXBwcm92ZVBsYW4oYWN0aXZlUGxhbkRldGFpbC5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQXBwcm92ZSBQbGFuXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBDUkVBVEUgLyBFRElUIExFU1NPTiBQTEFOIE1PREFMICovfVxyXG4gICAgICB7aXNOZXdNb2RhbE9wZW4gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBiZy1ncmF5LTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBtYXgtdy0yeGwgdy1mdWxsIG1heC1oLVs5MnZoXSBmbGV4IGZsZXgtY29sIG15LWF1dG8gYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc2xhdGUtNTAvNTAgcm91bmRlZC10LXhsXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpc0VkaXRNb2RlID8gJ0VkaXQgTGVzc29uIFBsYW4nIDogJ0NyZWF0ZSBOZXcgTGVzc29uIFBsYW4nfVxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgUHJlcGFyZSBjdXJyaWN1bHVtLCBhY3Rpdml0aWVzLCBhbmQgcmVzb3VyY2VzIGZvciB1cGNvbWluZyBzZXNzaW9ucy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc05ld01vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBwLTEgcm91bmRlZC1tZCBob3ZlcjpiZy1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRm9ybSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAge2lzRWRpdE1vZGUgJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlUGxhbkRldGFpbD8uc3RhdHVzIHx8ICcnKSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc3VjY2Vzcy01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5UaGlzIGxlc3NvbiBwbGFuIGhhcyBiZWVuIHthY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMudG9Mb3dlckNhc2UoKX0gYW5kIGNhbm5vdCBiZSBlZGl0ZWQuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7aXNFZGl0TW9kZSAmJiBhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgPT09ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLXhsIHAtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtYW1iZXItODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Db3JyZWN0aW9uIFJlcXVlc3RlZDoge2FjdGl2ZVBsYW5EZXRhaWwuY29ycmVjdGlvblJlYXNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogUm93IDE6IFRvcGljICYgTW9kdWxlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMy41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBMZXNzb24gVG9waWMgLyBUaXRsZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50b3BpY31cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdG9waWM6IGUudGFyZ2V0LnZhbHVlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGZvcm1FcnJvcnMudG9waWMpIHNldEZvcm1FcnJvcnMoeyAuLi5mb3JtRXJyb3JzLCB0b3BpYzogJycgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gQmFzaWMgQ29udmVyc2F0aW9uICYgRGlhbG9ndWUgRHJpbGxzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV0gZGlzYWJsZWQ6b3BhY2l0eS01MCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybUVycm9ycy50b3BpYyA/ICdib3JkZXItcm9zZS00MDAgYmctcm9zZS01MC8zMCcgOiAnYm9yZGVyLXNsYXRlLTMwMCdcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1FcnJvcnMudG9waWMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPntmb3JtRXJyb3JzLnRvcGljfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEN1cnJpY3VsdW0gTW9kdWxlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubW9kdWxlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyhtb2QpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGxldCBtb2RJZCA9ICdNLTEwMyc7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobW9kID09PSAnQmFzaWMgTWF0aCcpIG1vZElkID0gJ00tMzAxJztcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChtb2QgPT09ICdMaWZlIFNraWxscycpIG1vZElkID0gJ00tMTAyJztcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChtb2QgPT09ICdEaWdpdGFsIExpdGVyYWN5JykgbW9kSWQgPSAnRC0wMDQnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKG1vZCA9PT0gJ1NjaWVuY2UnKSBtb2RJZCA9ICdTLTIwMSc7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobW9kID09PSAnRmluYW5jaWFsIExpdGVyYWN5JykgbW9kSWQgPSAnRi0xMDEnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbW9kdWxlTmFtZTogbW9kLCBtb2R1bGVJZDogbW9kSWQgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTkgdGV4dC14cyBib3JkZXItc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9kdWxlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlNwb2tlbiBFbmdsaXNoXCI+U3Bva2VuIEVuZ2xpc2ggKE0tMTAzKTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQmFzaWMgTWF0aFwiPkJhc2ljIE1hdGggKE0tMzAxKTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiTGlmZSBTa2lsbHNcIj5MaWZlIFNraWxscyAoTS0xMDIpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJEaWdpdGFsIExpdGVyYWN5XCI+RGlnaXRhbCBMaXRlcmFjeSAoRC0wMDQpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJTY2llbmNlXCI+U2NpZW5jZSAoUy0yMDEpPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJGaW5hbmNpYWwgTGl0ZXJhY3lcIj5GaW5hbmNpYWwgTGl0ZXJhY3kgKEYtMTAxKTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb3cgMjogU3RhbmRhcmQgJiBEdXJhdGlvbiAmIERhdGUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zLjVcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRhcmdldCBTdGFuZGFyZCAvIEdyYWRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudGFyZ2V0U3RhbmRhcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRWRpdE1vZGUgJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlUGxhbkRldGFpbD8uc3RhdHVzIHx8ICcnKX1cclxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCB0YXJnZXRTdGFuZGFyZDogdmFsIH0pfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOSB0ZXh0LXhzIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlRhcmdldCBTdGFuZGFyZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCI0dGggLSA1dGggU3RhbmRhcmRcIj40dGggLSA1dGggU3RhbmRhcmQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIjZ0aCAtIDh0aCBTdGFuZGFyZFwiPjZ0aCAtIDh0aCBTdGFuZGFyZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiOXRoIC0gMTB0aCBTdGFuZGFyZFwiPjl0aCAtIDEwdGggU3RhbmRhcmQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIER1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZHVyYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRWRpdE1vZGUgJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlUGxhbkRldGFpbD8uc3RhdHVzIHx8ICcnKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGR1cmF0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjkwIE1pbnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1tZCB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2Vzc2lvbiBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZGF0ZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV0gZGlzYWJsZWQ6b3BhY2l0eS01MFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJvdyAzOiBIaWVyYXJjaHkgTG9jYXRpb24gJiBWb2x1bnRlZXIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zLjUgYmctc2xhdGUtNTAvNzAgcC0zIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBhbmNoYXlhdCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYW5jaGF5YXRJZH1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gcGFuY2hheWF0cy5maW5kKChwKSA9PiBwLmlkID09PSB2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYW5jaGF5YXRJZDogZm91bmQuaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGFuY2hheWF0TmFtZTogZm91bmQubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWxsYWdlTmFtZTogZm91bmQudmlsbGFnZXNbMF0/Lm5hbWUgfHwgJ01haW4gQ2VudGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTggdGV4dC14cyBib3JkZXItc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGFuY2hheWF0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGFuY2hheWF0cy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3AubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFZpbGxhZ2UgQ2VudGVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnZpbGxhZ2VOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0VkaXRNb2RlICYmIFsnU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGFjdGl2ZVBsYW5EZXRhaWw/LnN0YXR1cyB8fCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdmlsbGFnZU5hbWU6IHZhbCB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChmb3JtRXJyb3JzLnZpbGxhZ2VOYW1lKSBzZXRGb3JtRXJyb3JzKHsgLi4uZm9ybUVycm9ycywgdmlsbGFnZU5hbWU6ICcnIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9e2B3LWZ1bGwgaC04IHRleHQteHMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1FcnJvcnMudmlsbGFnZU5hbWUgPyAnYm9yZGVyLXJvc2UtNDAwIGJnLXJvc2UtNTAvMzAnIDogJ2JvcmRlci1zbGF0ZS0zMDAnXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFZpbGxhZ2UgQ2VudGVyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bW9kYWxWaWxsYWdlcy5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVm9sdW50ZWVyIExlYWRcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS52b2x1bnRlZXJJZH1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvdW5kID0gdm9sdW50ZWVycy5maW5kKCh2KSA9PiB2LmlkID09PSB2YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGZvdW5kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHZvbHVudGVlcklkOiBmb3VuZC5pZCwgdm9sdW50ZWVyTmFtZTogZm91bmQubmFtZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtOCB0ZXh0LXhzIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlNlbGVjdCBWb2x1bnRlZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2b2x1bnRlZXJzLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2LmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb3cgNDogUHJpbWFyeSBPYmplY3RpdmUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBQcmltYXJ5IExlYXJuaW5nIE9iamVjdGl2ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm9iamVjdGl2ZX1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRWRpdE1vZGUgJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlUGxhbkRldGFpbD8uc3RhdHVzIHx8ICcnKX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgb2JqZWN0aXZlOiBlLnRhcmdldC52YWx1ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybUVycm9ycy5vYmplY3RpdmUpIHNldEZvcm1FcnJvcnMoeyAuLi5mb3JtRXJyb3JzLCBvYmplY3RpdmU6ICcnIH0pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlN0YXRlIHRoZSBjb3JlIG91dGNvbWUgc3R1ZGVudHMgd2lsbCBhY2hpZXZlIGJ5IHRoZSBlbmQgb2YgOTAgbWludXRlcy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMEIzRDkxXSBkaXNhYmxlZDpvcGFjaXR5LTUwICR7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybUVycm9ycy5vYmplY3RpdmUgPyAnYm9yZGVyLXJvc2UtNDAwIGJnLXJvc2UtNTAvMzAnIDogJ2JvcmRlci1zbGF0ZS0zMDAnXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtmb3JtRXJyb3JzLm9iamVjdGl2ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPntmb3JtRXJyb3JzLm9iamVjdGl2ZX08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUm93IDU6IFRpbWUgQnJlYWtkb3duICYgQWN0aXZpdGllcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFjdGl2aXRpZXMgJmFtcDsgVGltZSBCcmVha2Rvd24gKG9uZSBwZXIgbGluZSlcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFjdGl2aXRpZXNMaXN0VGV4dH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRWRpdE1vZGUgJiYgWydTdWJtaXR0ZWQnLCAnQXBwcm92ZWQnLCAnQ29tcGxldGVkJ10uaW5jbHVkZXMoYWN0aXZlUGxhbkRldGFpbD8uc3RhdHVzIHx8ICcnKX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBhY3Rpdml0aWVzTGlzdFRleHQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIldhcm0tdXAgJmFtcDsgSWNlYnJlYWtlciAoMTUgbWlucykmIzEwO0NvbmNlcHQgRGVtb25zdHJhdGlvbiAoMjUgbWlucykmIzEwO0dyb3VwIEFjdGl2aXR5ICZhbXA7IFByYWN0aWNlICgzMCBtaW5zKSYjMTA7RXhpdCBBc3Nlc3NtZW50ICZhbXA7IFF1aXogKDIwIG1pbnMpXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV0gZm9udC1tb25vIHRleHQtWzExcHhdIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJvdyA2OiBNYXRlcmlhbHMgUmVxdWlyZWQgJiBBc3Nlc3NtZW50ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMy41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBNYXRlcmlhbHMgJmFtcDsgS2l0cyBSZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5tYXRlcmlhbHNUZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0VkaXRNb2RlICYmIFsnU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGFjdGl2ZVBsYW5EZXRhaWw/LnN0YXR1cyB8fCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBtYXRlcmlhbHNUZXh0OiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZsYXNoY2FyZHMsIDMwIFByaW50ZWQgV29ya3NoZWV0cywgTWFya2VycywgUmV3YXJkIHN0aWNrZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbWQgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMEIzRDkxXSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEV4aXQgQXNzZXNzbWVudCBUYXNrXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFzc2Vzc21lbnRUYXNrfVxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0VkaXRNb2RlICYmIFsnU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGFjdGl2ZVBsYW5EZXRhaWw/LnN0YXR1cyB8fCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBhc3Nlc3NtZW50VGFzazogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI1LXF1ZXN0aW9uIHZpc3VhbCBmcmFjdGlvbiBwdXp6bGUgd29ya3NoZWV0IGV2YWx1YXRlZCBpbiBwYWlycy5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1tZCB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBSb3cgNzogUmVtYXJrcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlbWFya3MgLyBOb3Rlc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZXN9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0VkaXRNb2RlICYmIFsnU3VibWl0dGVkJywgJ0FwcHJvdmVkJywgJ0NvbXBsZXRlZCddLmluY2x1ZGVzKGFjdGl2ZVBsYW5EZXRhaWw/LnN0YXR1cyB8fCAnJyl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbm90ZXM6IGUudGFyZ2V0LnZhbHVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlZvbHVudGVlciBHdWlkYW5jZSAmIENlbnRlciBMb2dpc3RpY3MuLi5cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbWQgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMEIzRDkxXSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEZvb3RlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHB5LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1iLXhsXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc05ld01vZGFsT3BlbihmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgeyEoaXNFZGl0TW9kZSAmJiBbJ1N1Ym1pdHRlZCcsICdBcHByb3ZlZCcsICdDb21wbGV0ZWQnXS5pbmNsdWRlcyhhY3RpdmVQbGFuRGV0YWlsPy5zdGF0dXMgfHwgJycpKSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVGb3JtU3VibWl0KCdEcmFmdCcpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhdmUgRHJhZnRcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVGb3JtU3VibWl0KCdTdWJtaXR0ZWQnKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSBiZy1bIzBCM0Q5MV0gaG92ZXI6YmctWyMwODJhNjZdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbWQgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc0VkaXRNb2RlID8gJ1NhdmUgJiBTdWJtaXQgUGxhbicgOiAnU3VibWl0IGZvciBSZXZpZXcnfVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogUkVRVUVTVCBDT1JSRUNUSU9OIE1PREFMICovfVxyXG4gICAgICB7aXNDb3JyZWN0aW9uTW9kYWxPcGVuICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ncmF5LTkwMC83MCBiYWNrZHJvcC1ibHVyLXNtXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtIG1heC13LW1kIHctZnVsbCBwLTUgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+ZmVlZGJhY2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlJlcXVlc3QgTGVzc29uIFBsYW4gQ29ycmVjdGlvbjwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+UHJvdmlkZSBhY3Rpb25hYmxlIGZlZWRiYWNrIHRvIHRoZSB2b2x1bnRlZXIuPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBGZWVkYmFjayAmYW1wOyBSZXF1aXJlZCBSZXZpc2lvbnMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y29ycmVjdGlvblJlYXNvbklucHV0fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb3JyZWN0aW9uUmVhc29uSW5wdXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFBsZWFzZSBhZGQgc3BlY2lmaWMgc2FmZXR5IGluc3RydWN0aW9ucyBmb3Igb3V0ZG9vciBuYXR1cmUgY29sbGVjdGlvbiBhbmQgaW5jbHVkZSB0aW1lIGJyZWFrZG93biBmb3IgdGhlIHNlY29uZCAzMC1taW51dGUgYmxvY2suLi5cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV1cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNDb3JyZWN0aW9uTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbWQgaG92ZXI6Ymctc2xhdGUtNTBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshY29ycmVjdGlvblJlYXNvbklucHV0LnRyaW0oKX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdENvcnJlY3Rpb259XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSBiZy1hbWJlci02MDAgaG92ZXI6YmctYW1iZXItNzAwIGRpc2FibGVkOm9wYWNpdHktNTAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1tZCBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFNlbmQgUmVxdWVzdFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTGVzc29uUGxhblZpZXcudHN4In0=