import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import {
  CheckCircle2,
  AlertCircle,
  Calendar,
  Info,
  Check,
  ArrowRight
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { LottieIllustration } from "/src/components/LottieIllustration.tsx";
export const NotificationsView = ({
  notifications,
  onNavigate,
  onMarkAsRead,
  onMarkAllAsRead
}) => {
  _s();
  const [filter, setFilter] = useState("all");
  const filtered = notifications.filter((n) => {
    if (filter === "unread") return !n.isRead;
    if (filter === "correction") return n.type === "correction";
    if (filter === "approval") return n.type === "approval";
    return true;
  });
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const tabs = [
    { key: "all", label: "All", count: notifications.length },
    { key: "unread", label: "Unread", count: unreadCount },
    { key: "correction", label: "Corrections", count: notifications.filter((n) => n.type === "correction").length },
    { key: "approval", label: "Approvals", count: notifications.filter((n) => n.type === "approval").length }
  ];
  const getIcon = (type) => {
    switch (type) {
      case "correction":
        return /* @__PURE__ */ jsxDEV(AlertCircle, { className: "h-5 w-5 text-amber-600" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 47,
          columnNumber: 16
        }, this);
      case "approval":
        return /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-5 w-5 text-emerald-600" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 49,
          columnNumber: 16
        }, this);
      case "session":
        return /* @__PURE__ */ jsxDEV(Calendar, { className: "h-5 w-5 text-blue-600" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 51,
          columnNumber: 16
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV(Info, { className: "h-5 w-5 text-muted-foreground" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 53,
          columnNumber: 16
        }, this);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between border-b border-border/50 pb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold tracking-tight text-foreground sm:text-3xl", children: "Notifications" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground mt-1", children: unreadCount > 0 ? `${unreadCount} unread updates require your attention` : "All caught up • No pending notifications" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 65,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      unreadCount > 0 && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onMarkAllAsRead,
          className: "inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors",
          children: [
            /* @__PURE__ */ jsxDEV(Check, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 76,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Mark all as read" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 77,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 71,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-8 border-b border-border/40 text-sm font-medium", children: tabs.map((t) => {
      const isActive = filter === t.key;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setFilter(t.key),
          className: `relative pb-3.5 transition-colors ${isActive ? "text-foreground font-semibold" : "text-muted-foreground hover:text-foreground"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: t.label }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                lineNumber: 98,
                columnNumber: 17
              }, this),
              t.count > 0 && /* @__PURE__ */ jsxDEV("span", { className: `text-xs ${isActive ? "text-foreground font-bold" : "text-muted-foreground"}`, children: [
                "(",
                t.count,
                ")"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                lineNumber: 100,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 97,
              columnNumber: 15
            }, this),
            isActive && /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-0 left-0 right-0 h-0.5 bg-foreground" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 106,
              columnNumber: 15
            }, this)
          ]
        },
        t.key,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 87,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-24 text-center", children: [
      /* @__PURE__ */ jsxDEV(LottieIllustration, { type: "empty-notifications", size: 96, className: "mb-4" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
        lineNumber: 117,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-foreground", children: "No notifications here" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
        lineNumber: 118,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground mt-1 max-w-md", children: filter === "unread" ? "You have no unread notifications." : "There are no notifications matching this category at this time." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
        lineNumber: 119,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
      lineNumber: 116,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-border/40", children: filtered.map(
      (item) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `group flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-5 px-3 transition-colors hover:bg-muted/30 ${!item.isRead ? "bg-muted/10" : ""}`,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 shrink-0", children: getIcon(item.type) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                lineNumber: 135,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: `text-sm ${!item.isRead ? "font-bold text-foreground" : "font-medium text-foreground"}`, children: item.title }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                    lineNumber: 140,
                    columnNumber: 23
                  }, this),
                  !item.isRead && /* @__PURE__ */ jsxDEV("span", { className: "h-2 w-2 rounded-full bg-blue-600" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                    lineNumber: 144,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                  lineNumber: 139,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-muted-foreground", children: item.message }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                  lineNumber: 147,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted-foreground/70 block pt-0.5", children: item.timeAgo }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                  lineNumber: 150,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                lineNumber: 138,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 134,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 shrink-0 self-end sm:self-center", children: [
              item.actionTab && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => onNavigate(item.actionTab, item.targetId),
                  className: "inline-flex items-center gap-1.5 text-sm font-semibold text-foreground hover:underline",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: item.actionLabel || "View Record" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                      lineNumber: 163,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                      lineNumber: 164,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                  lineNumber: 158,
                  columnNumber: 15
                },
                this
              ),
              !item.isRead && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => onMarkAsRead(item.id),
                  title: "Mark as read",
                  className: "text-sm text-muted-foreground hover:text-foreground transition-colors p-1",
                  children: /* @__PURE__ */ jsxDEV(Check, { className: "h-4 w-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                    lineNumber: 174,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
                  lineNumber: 168,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
              lineNumber: 156,
              columnNumber: 17
            }, this)
          ]
        },
        item.id,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
          lineNumber: 128,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
      lineNumber: 126,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
};
_s(NotificationsView, "W/UjwQokI5qYZ80z+yO8skpbfNg=");
_c = NotificationsView;
var _c;
$RefreshReg$(_c, "NotificationsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/NotificationsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOENlOztBQTlDZixTQUFnQkEsZ0JBQWdCO0FBQ2hDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLDBCQUEwQjtBQVM1QixhQUFNQyxvQkFBc0RBLENBQUM7QUFBQSxFQUNsRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWYsU0FBdUQsS0FBSztBQUV4RixRQUFNZ0IsV0FBV1AsY0FBY0ssT0FBTyxDQUFDRyxNQUFNO0FBQzNDLFFBQUlILFdBQVcsU0FBVSxRQUFPLENBQUNHLEVBQUVDO0FBQ25DLFFBQUlKLFdBQVcsYUFBYyxRQUFPRyxFQUFFRSxTQUFTO0FBQy9DLFFBQUlMLFdBQVcsV0FBWSxRQUFPRyxFQUFFRSxTQUFTO0FBQzdDLFdBQU87QUFBQSxFQUNULENBQUM7QUFFRCxRQUFNQyxjQUFjWCxjQUFjSyxPQUFPLENBQUNHLE1BQU0sQ0FBQ0EsRUFBRUMsTUFBTSxFQUFFRztBQUUzRCxRQUFNQyxPQUFPO0FBQUEsSUFDWCxFQUFFQyxLQUFLLE9BQU9DLE9BQU8sT0FBT0MsT0FBT2hCLGNBQWNZLE9BQU87QUFBQSxJQUN4RCxFQUFFRSxLQUFLLFVBQVVDLE9BQU8sVUFBVUMsT0FBT0wsWUFBWTtBQUFBLElBQ3JELEVBQUVHLEtBQUssY0FBY0MsT0FBTyxlQUFlQyxPQUFPaEIsY0FBY0ssT0FBTyxDQUFDRyxNQUFNQSxFQUFFRSxTQUFTLFlBQVksRUFBRUUsT0FBTztBQUFBLElBQzlHLEVBQUVFLEtBQUssWUFBWUMsT0FBTyxhQUFhQyxPQUFPaEIsY0FBY0ssT0FBTyxDQUFDRyxNQUFNQSxFQUFFRSxTQUFTLFVBQVUsRUFBRUUsT0FBTztBQUFBLEVBQUM7QUFHM0csUUFBTUssVUFBVUEsQ0FBQ1AsU0FBbUM7QUFDbEQsWUFBUUEsTUFBSTtBQUFBLE1BQ1YsS0FBSztBQUNILGVBQU8sdUJBQUMsZUFBWSxXQUFVLDRCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsTUFDeEQsS0FBSztBQUNILGVBQU8sdUJBQUMsZ0JBQWEsV0FBVSw4QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLE1BQzNELEtBQUs7QUFDSCxlQUFPLHVCQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQztBQUFBLE1BQ3BEO0FBQ0UsZUFBTyx1QkFBQyxRQUFLLFdBQVUsbUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxJQUMxRDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsaUVBQStELDZCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FDVkMsd0JBQWMsSUFBSSxHQUFHQSxXQUFXLDJDQUEyQyw4Q0FEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVDQSxjQUFjLEtBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVNSO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEI7QUFBQSxZQUMxQix1QkFBQyxVQUFLLGdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUE7QUFBQTtBQUFBLFFBTnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlFQUNaVSxlQUFLSyxJQUFJLENBQUNDLE1BQU07QUFDZixZQUFNQyxXQUFXZixXQUFXYyxFQUFFTDtBQUM5QixhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1SLFVBQVVhLEVBQUVMLEdBQUc7QUFBQSxVQUM5QixXQUFXLHFDQUNUTSxXQUNJLGtDQUNBLDZDQUE2QztBQUFBLFVBR25EO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEscUNBQUMsVUFBTUQsWUFBRUosU0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FDZEksRUFBRUgsUUFBUSxLQUNULHVCQUFDLFVBQUssV0FBVyxXQUFXSSxXQUFXLDhCQUE4Qix1QkFBdUIsSUFBRztBQUFBO0FBQUEsZ0JBQzNGRCxFQUFFSDtBQUFBQSxnQkFBTTtBQUFBLG1CQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQ0ksWUFDQyx1QkFBQyxVQUFLLFdBQVUsMERBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUE7QUFBQTtBQUFBLFFBbEJuRUQsRUFBRUw7QUFBQUEsUUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUJBO0FBQUEsSUFFSixDQUFDLEtBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxVQUNaUCxtQkFBU0ssV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSw2QkFBQyxzQkFBbUIsTUFBSyx1QkFBc0IsTUFBTSxJQUFJLFdBQVUsVUFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MscUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxNQUN6RSx1QkFBQyxPQUFFLFdBQVUsK0NBQ1ZQLHFCQUFXLFdBQ1Isc0NBQ0EscUVBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1pFLG1CQUFTVztBQUFBQSxNQUFJLENBQUNHLFNBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVcsdUhBQ1QsQ0FBQ0EsS0FBS1osU0FBUyxnQkFBZ0IsRUFBRTtBQUFBLFVBR25DO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1CQUNaUSxrQkFBUUksS0FBS1gsSUFBSSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVyxXQUFXLENBQUNXLEtBQUtaLFNBQVMsOEJBQThCLDZCQUE2QixJQUNuR1ksZUFBS0MsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0MsQ0FBQ0QsS0FBS1osVUFDTCx1QkFBQyxVQUFLLFdBQVUsc0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEscUJBTHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQ1ZZLGVBQUtFLFdBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxpREFDYkYsZUFBS0csV0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNaSDtBQUFBQSxtQkFBS0ksYUFDSjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNeEIsV0FBV29CLEtBQUtJLFdBQVlKLEtBQUtLLFFBQVE7QUFBQSxrQkFDeEQsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsVUFBTUwsZUFBS00sZUFBZSxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUM7QUFBQSxvQkFDekMsdUJBQUMsY0FBVyxXQUFVLGlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBO0FBQUE7QUFBQSxnQkFOckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUVELENBQUNOLEtBQUtaLFVBQ0w7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTVAsYUFBYW1CLEtBQUtPLEVBQUU7QUFBQSxrQkFDbkMsT0FBTTtBQUFBLGtCQUNOLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQTtBQUFBLGdCQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLGlCQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBO0FBQUE7QUFBQSxRQWhES1AsS0FBS087QUFBQUEsUUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0RBO0FBQUEsSUFDRCxLQXJESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBLEtBbEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRUE7QUFBQSxPQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkhBO0FBRUo7QUFBRXhCLEdBcktXTCxtQkFBbUQ7QUFBQSxLQUFuREE7QUFBbUQsSUFBQThCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ2hlY2tDaXJjbGUyIiwiQWxlcnRDaXJjbGUiLCJDYWxlbmRhciIsIkluZm8iLCJDaGVjayIsIkFycm93UmlnaHQiLCJMb3R0aWVJbGx1c3RyYXRpb24iLCJOb3RpZmljYXRpb25zVmlldyIsIm5vdGlmaWNhdGlvbnMiLCJvbk5hdmlnYXRlIiwib25NYXJrQXNSZWFkIiwib25NYXJrQWxsQXNSZWFkIiwiX3MiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJmaWx0ZXJlZCIsIm4iLCJpc1JlYWQiLCJ0eXBlIiwidW5yZWFkQ291bnQiLCJsZW5ndGgiLCJ0YWJzIiwia2V5IiwibGFiZWwiLCJjb3VudCIsImdldEljb24iLCJtYXAiLCJ0IiwiaXNBY3RpdmUiLCJpdGVtIiwidGl0bGUiLCJtZXNzYWdlIiwidGltZUFnbyIsImFjdGlvblRhYiIsInRhcmdldElkIiwiYWN0aW9uTGFiZWwiLCJpZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbnNWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQWxlcnRDaXJjbGUsIFxuICBDYWxlbmRhciwgXG4gIEluZm8sIFxuICBDaGVjaywgXG4gIEFycm93UmlnaHRcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFRhYlR5cGUsIE5vdGlmaWNhdGlvbkl0ZW0gfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBMb3R0aWVJbGx1c3RyYXRpb24gfSBmcm9tICcuL0xvdHRpZUlsbHVzdHJhdGlvbic7XG5cbmludGVyZmFjZSBOb3RpZmljYXRpb25zVmlld1Byb3BzIHtcbiAgbm90aWZpY2F0aW9uczogTm90aWZpY2F0aW9uSXRlbVtdO1xuICBvbk5hdmlnYXRlOiAodGFiOiBUYWJUeXBlLCB0YXJnZXRJZD86IHN0cmluZykgPT4gdm9pZDtcbiAgb25NYXJrQXNSZWFkOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25NYXJrQWxsQXNSZWFkOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgTm90aWZpY2F0aW9uc1ZpZXc6IFJlYWN0LkZDPE5vdGlmaWNhdGlvbnNWaWV3UHJvcHM+ID0gKHtcbiAgbm90aWZpY2F0aW9ucyxcbiAgb25OYXZpZ2F0ZSxcbiAgb25NYXJrQXNSZWFkLFxuICBvbk1hcmtBbGxBc1JlYWQsXG59KSA9PiB7XG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZTwnYWxsJyB8ICd1bnJlYWQnIHwgJ2NvcnJlY3Rpb24nIHwgJ2FwcHJvdmFsJz4oJ2FsbCcpO1xuXG4gIGNvbnN0IGZpbHRlcmVkID0gbm90aWZpY2F0aW9ucy5maWx0ZXIoKG4pID0+IHtcbiAgICBpZiAoZmlsdGVyID09PSAndW5yZWFkJykgcmV0dXJuICFuLmlzUmVhZDtcbiAgICBpZiAoZmlsdGVyID09PSAnY29ycmVjdGlvbicpIHJldHVybiBuLnR5cGUgPT09ICdjb3JyZWN0aW9uJztcbiAgICBpZiAoZmlsdGVyID09PSAnYXBwcm92YWwnKSByZXR1cm4gbi50eXBlID09PSAnYXBwcm92YWwnO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcblxuICBjb25zdCB1bnJlYWRDb3VudCA9IG5vdGlmaWNhdGlvbnMuZmlsdGVyKChuKSA9PiAhbi5pc1JlYWQpLmxlbmd0aDtcblxuICBjb25zdCB0YWJzID0gW1xuICAgIHsga2V5OiAnYWxsJywgbGFiZWw6ICdBbGwnLCBjb3VudDogbm90aWZpY2F0aW9ucy5sZW5ndGggfSxcbiAgICB7IGtleTogJ3VucmVhZCcsIGxhYmVsOiAnVW5yZWFkJywgY291bnQ6IHVucmVhZENvdW50IH0sXG4gICAgeyBrZXk6ICdjb3JyZWN0aW9uJywgbGFiZWw6ICdDb3JyZWN0aW9ucycsIGNvdW50OiBub3RpZmljYXRpb25zLmZpbHRlcigobikgPT4gbi50eXBlID09PSAnY29ycmVjdGlvbicpLmxlbmd0aCB9LFxuICAgIHsga2V5OiAnYXBwcm92YWwnLCBsYWJlbDogJ0FwcHJvdmFscycsIGNvdW50OiBub3RpZmljYXRpb25zLmZpbHRlcigobikgPT4gbi50eXBlID09PSAnYXBwcm92YWwnKS5sZW5ndGggfSxcbiAgXSBhcyBjb25zdDtcblxuICBjb25zdCBnZXRJY29uID0gKHR5cGU6IE5vdGlmaWNhdGlvbkl0ZW1bJ3R5cGUnXSkgPT4ge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSAnY29ycmVjdGlvbic6XG4gICAgICAgIHJldHVybiA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWFtYmVyLTYwMFwiIC8+O1xuICAgICAgY2FzZSAnYXBwcm92YWwnOlxuICAgICAgICByZXR1cm4gPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtZW1lcmFsZC02MDBcIiAvPjtcbiAgICAgIGNhc2UgJ3Nlc3Npb24nOlxuICAgICAgICByZXR1cm4gPENhbGVuZGFyIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1ibHVlLTYwMFwiIC8+O1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIDxJbmZvIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz47XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS04XCI+XG4gICAgICB7LyogVG9wIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCBzbTpmbGV4LXJvdyBzbTppdGVtcy1lbmQgc206anVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ib3JkZXIvNTAgcGItNlwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kIHNtOnRleHQtM3hsXCI+XG4gICAgICAgICAgICBOb3RpZmljYXRpb25zXG4gICAgICAgICAgPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0xXCI+XG4gICAgICAgICAgICB7dW5yZWFkQ291bnQgPiAwID8gYCR7dW5yZWFkQ291bnR9IHVucmVhZCB1cGRhdGVzIHJlcXVpcmUgeW91ciBhdHRlbnRpb25gIDogJ0FsbCBjYXVnaHQgdXAg4oCiIE5vIHBlbmRpbmcgbm90aWZpY2F0aW9ucyd9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7dW5yZWFkQ291bnQgPiAwICYmIChcbiAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk1hcmtBbGxBc1JlYWR9IFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5NYXJrIGFsbCBhcyByZWFkPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUYWJzIEZpbHRlciBCYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC04IGJvcmRlci1iIGJvcmRlci1ib3JkZXIvNDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICB7dGFicy5tYXAoKHQpID0+IHtcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGZpbHRlciA9PT0gdC5rZXk7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXt0LmtleX1cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcih0LmtleSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHBiLTMuNSB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgIGlzQWN0aXZlIFxuICAgICAgICAgICAgICAgICAgPyAndGV4dC1mb3JlZ3JvdW5kIGZvbnQtc2VtaWJvbGQnIFxuICAgICAgICAgICAgICAgICAgOiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3QubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIHt0LmNvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzICR7aXNBY3RpdmUgPyAndGV4dC1mb3JlZ3JvdW5kIGZvbnQtYm9sZCcgOiAndGV4dC1tdXRlZC1mb3JlZ3JvdW5kJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgKHt0LmNvdW50fSlcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIHtpc0FjdGl2ZSAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHJpZ2h0LTAgaC0wLjUgYmctZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTm90aWZpY2F0aW9ucyBMaXN0IC8gQmVhdXRpZnVsIENlbnRlcmVkIEVtcHR5IFN0YXRlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAge2ZpbHRlcmVkLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTI0IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8TG90dGllSWxsdXN0cmF0aW9uIHR5cGU9XCJlbXB0eS1ub3RpZmljYXRpb25zXCIgc2l6ZT17OTZ9IGNsYXNzTmFtZT1cIm1iLTRcIiAvPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+Tm8gbm90aWZpY2F0aW9ucyBoZXJlPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG10LTEgbWF4LXctbWRcIj5cbiAgICAgICAgICAgICAge2ZpbHRlciA9PT0gJ3VucmVhZCdcbiAgICAgICAgICAgICAgICA/ICdZb3UgaGF2ZSBubyB1bnJlYWQgbm90aWZpY2F0aW9ucy4nXG4gICAgICAgICAgICAgICAgOiAnVGhlcmUgYXJlIG5vIG5vdGlmaWNhdGlvbnMgbWF0Y2hpbmcgdGhpcyBjYXRlZ29yeSBhdCB0aGlzIHRpbWUuJ31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ib3JkZXIvNDBcIj5cbiAgICAgICAgICAgIHtmaWx0ZXJlZC5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bncm91cCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcHktNSBweC0zIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLW11dGVkLzMwICR7XG4gICAgICAgICAgICAgICAgICAhaXRlbS5pc1JlYWQgPyAnYmctbXV0ZWQvMTAnIDogJydcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0wLjUgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAge2dldEljb24oaXRlbS50eXBlKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gJHshaXRlbS5pc1JlYWQgPyAnZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCcgOiAnZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7IWl0ZW0uaXNSZWFkICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLWJsdWUtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kLzcwIGJsb2NrIHB0LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpbWVBZ299XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBzaHJpbmstMCBzZWxmLWVuZCBzbTpzZWxmLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uYWN0aW9uVGFiICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoaXRlbS5hY3Rpb25UYWIhLCBpdGVtLnRhcmdldElkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5hY3Rpb25MYWJlbCB8fCAnVmlldyBSZWNvcmQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHshaXRlbS5pc1JlYWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25NYXJrQXNSZWFkKGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTWFyayBhcyByZWFkXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgcC0xXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbnNWaWV3LnRzeCJ9