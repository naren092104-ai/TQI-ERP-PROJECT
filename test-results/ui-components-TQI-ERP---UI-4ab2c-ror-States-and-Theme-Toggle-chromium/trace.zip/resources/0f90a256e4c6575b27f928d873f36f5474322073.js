import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\ui\\badge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=8975830d";
import { cn } from "/src/lib/utils.ts";
const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-brand-500 text-white hover:bg-brand-600",
        secondary: "border-transparent bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200",
        destructive: "border-transparent bg-error-500 text-white hover:bg-error-600",
        outline: "text-foreground border-gray-200 dark:border-gray-800",
        success: "border-transparent bg-success-50 text-success-700 border-success-200 dark:bg-success-950/40 dark:text-success-400",
        warning: "border-transparent bg-warning-50 text-warning-700 border-warning-200 dark:bg-warning-950/40 dark:text-warning-400",
        error: "border-transparent bg-error-50 text-error-700 border-error-200 dark:bg-error-950/40 dark:text-error-400",
        info: "border-transparent bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/40 dark:text-blue-400"
      },
      size: {
        sm: "px-2 py-0.5 text-[10px]",
        md: "px-2.5 py-0.5 text-[11px]",
        lg: "px-3 py-1 text-xs"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "md"
    }
  }
);
function Badge({ className, variant, color, size, ...props }) {
  let resolvedVariant = variant;
  if (!resolvedVariant && color) {
    if (color === "success") resolvedVariant = "success";
    else if (color === "warning") resolvedVariant = "warning";
    else if (color === "error" || color === "destructive") resolvedVariant = "destructive";
    else if (color === "info" || color === "primary") resolvedVariant = "default";
    else
      resolvedVariant = "secondary";
  }
  const resolvedSize = size === "sm" || size === "md" || size === "lg" ? size : "md";
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: cn(badgeVariants({ variant: resolvedVariant, size: resolvedSize }), className),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/badge.tsx",
      lineNumber: 58,
      columnNumber: 5
    },
    this
  );
}
_c = Badge;
export default Badge;
export { Badge, badgeVariants };
var _c;
$RefreshReg$(_c, "Badge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/badge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/badge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/badge.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURJO0FBeERKLFNBQVNBLFdBQThCO0FBRXZDLFNBQVNDLFVBQVU7QUFFbkIsTUFBTUMsZ0JBQWdCRjtBQUFBQSxFQUNwQjtBQUFBLEVBQ0E7QUFBQSxJQUNFRyxVQUFVO0FBQUEsTUFDUkMsU0FBUztBQUFBLFFBQ1BDLFNBQ0U7QUFBQSxRQUNGQyxXQUNFO0FBQUEsUUFDRkMsYUFDRTtBQUFBLFFBQ0ZDLFNBQVM7QUFBQSxRQUNUQyxTQUFTO0FBQUEsUUFDVEMsU0FBUztBQUFBLFFBQ1RDLE9BQU87QUFBQSxRQUNQQyxNQUFNO0FBQUEsTUFDUjtBQUFBLE1BQ0FDLE1BQU07QUFBQSxRQUNKQyxJQUFJO0FBQUEsUUFDSkMsSUFBSTtBQUFBLFFBQ0pDLElBQUk7QUFBQSxNQUNOO0FBQUEsSUFDRjtBQUFBLElBQ0FDLGlCQUFpQjtBQUFBLE1BQ2ZiLFNBQVM7QUFBQSxNQUNUUyxNQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFDRjtBQVVBLFNBQVNLLE1BQU0sRUFBRUMsV0FBV2YsU0FBU2dCLE9BQU9QLE1BQU0sR0FBR1EsTUFBa0IsR0FBRztBQUV4RSxNQUFJQyxrQkFBa0JsQjtBQUN0QixNQUFJLENBQUNrQixtQkFBbUJGLE9BQU87QUFDN0IsUUFBSUEsVUFBVSxVQUFXRSxtQkFBa0I7QUFBQSxhQUNsQ0YsVUFBVSxVQUFXRSxtQkFBa0I7QUFBQSxhQUN2Q0YsVUFBVSxXQUFXQSxVQUFVLGNBQWVFLG1CQUFrQjtBQUFBLGFBQ2hFRixVQUFVLFVBQVVBLFVBQVUsVUFBV0UsbUJBQWtCO0FBQUE7QUFDL0RBLHdCQUFrQjtBQUFBLEVBQ3pCO0FBRUEsUUFBTUMsZUFBZVYsU0FBUyxRQUFRQSxTQUFTLFFBQVFBLFNBQVMsT0FBT0EsT0FBTztBQUU5RSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXWixHQUFHQyxjQUFjLEVBQUVFLFNBQVNrQixpQkFBaUJULE1BQU1VLGFBQWEsQ0FBQyxHQUFHSixTQUFTO0FBQUEsTUFDeEYsR0FBSUU7QUFBQUE7QUFBQUEsSUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFFWTtBQUdoQjtBQUFDRyxLQW5CUU47QUFxQlQsZUFBZUE7QUFDZixTQUFTQSxPQUFPaEI7QUFBZ0IsSUFBQXNCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImN2YSIsImNuIiwiYmFkZ2VWYXJpYW50cyIsInZhcmlhbnRzIiwidmFyaWFudCIsImRlZmF1bHQiLCJzZWNvbmRhcnkiLCJkZXN0cnVjdGl2ZSIsIm91dGxpbmUiLCJzdWNjZXNzIiwid2FybmluZyIsImVycm9yIiwiaW5mbyIsInNpemUiLCJzbSIsIm1kIiwibGciLCJkZWZhdWx0VmFyaWFudHMiLCJCYWRnZSIsImNsYXNzTmFtZSIsImNvbG9yIiwicHJvcHMiLCJyZXNvbHZlZFZhcmlhbnQiLCJyZXNvbHZlZFNpemUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJiYWRnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjdmEsIHR5cGUgVmFyaWFudFByb3BzIH0gZnJvbSBcImNsYXNzLXZhcmlhbmNlLWF1dGhvcml0eVwiO1xuXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuXG5jb25zdCBiYWRnZVZhcmlhbnRzID0gY3ZhKFxuICBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyIHB4LTIuNSBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcmluZyBmb2N1czpyaW5nLW9mZnNldC0yXCIsXG4gIHtcbiAgICB2YXJpYW50czoge1xuICAgICAgdmFyaWFudDoge1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWJyYW5kLTYwMFwiLFxuICAgICAgICBzZWNvbmRhcnk6XG4gICAgICAgICAgXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMFwiLFxuICAgICAgICBkZXN0cnVjdGl2ZTpcbiAgICAgICAgICBcImJvcmRlci10cmFuc3BhcmVudCBiZy1lcnJvci01MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1lcnJvci02MDBcIixcbiAgICAgICAgb3V0bGluZTogXCJ0ZXh0LWZvcmVncm91bmQgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCIsXG4gICAgICAgIHN1Y2Nlc3M6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXN1Y2Nlc3MtNTAgdGV4dC1zdWNjZXNzLTcwMCBib3JkZXItc3VjY2Vzcy0yMDAgZGFyazpiZy1zdWNjZXNzLTk1MC80MCBkYXJrOnRleHQtc3VjY2Vzcy00MDBcIixcbiAgICAgICAgd2FybmluZzogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctd2FybmluZy01MCB0ZXh0LXdhcm5pbmctNzAwIGJvcmRlci13YXJuaW5nLTIwMCBkYXJrOmJnLXdhcm5pbmctOTUwLzQwIGRhcms6dGV4dC13YXJuaW5nLTQwMFwiLFxuICAgICAgICBlcnJvcjogXCJib3JkZXItdHJhbnNwYXJlbnQgYmctZXJyb3ItNTAgdGV4dC1lcnJvci03MDAgYm9yZGVyLWVycm9yLTIwMCBkYXJrOmJnLWVycm9yLTk1MC80MCBkYXJrOnRleHQtZXJyb3ItNDAwXCIsXG4gICAgICAgIGluZm86IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLWJsdWUtNTAgdGV4dC1ibHVlLTcwMCBib3JkZXItYmx1ZS0yMDAgZGFyazpiZy1ibHVlLTk1MC80MCBkYXJrOnRleHQtYmx1ZS00MDBcIixcbiAgICAgIH0sXG4gICAgICBzaXplOiB7XG4gICAgICAgIHNtOiBcInB4LTIgcHktMC41IHRleHQtWzEwcHhdXCIsXG4gICAgICAgIG1kOiBcInB4LTIuNSBweS0wLjUgdGV4dC1bMTFweF1cIixcbiAgICAgICAgbGc6IFwicHgtMyBweS0xIHRleHQteHNcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICBkZWZhdWx0VmFyaWFudHM6IHtcbiAgICAgIHZhcmlhbnQ6IFwiZGVmYXVsdFwiLFxuICAgICAgc2l6ZTogXCJtZFwiLFxuICAgIH0sXG4gIH0sXG4pO1xuXG5leHBvcnQgaW50ZXJmYWNlIEJhZGdlUHJvcHNcbiAgZXh0ZW5kcyBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4sXG4gICAgVmFyaWFudFByb3BzPHR5cGVvZiBiYWRnZVZhcmlhbnRzPiB7XG4gIGNvbG9yPzogc3RyaW5nO1xuICBzaXplPzogXCJzbVwiIHwgXCJtZFwiIHwgXCJsZ1wiIHwgYW55O1xuICB2YXJpYW50PzogYW55O1xufVxuXG5mdW5jdGlvbiBCYWRnZSh7IGNsYXNzTmFtZSwgdmFyaWFudCwgY29sb3IsIHNpemUsIC4uLnByb3BzIH06IEJhZGdlUHJvcHMpIHtcbiAgLy8gSWYgY29sb3IgaXMgcGFzc2VkLCBtYXAgaXQgdG8gbWF0Y2hpbmcgdmFyaWFudFxuICBsZXQgcmVzb2x2ZWRWYXJpYW50ID0gdmFyaWFudDtcbiAgaWYgKCFyZXNvbHZlZFZhcmlhbnQgJiYgY29sb3IpIHtcbiAgICBpZiAoY29sb3IgPT09IFwic3VjY2Vzc1wiKSByZXNvbHZlZFZhcmlhbnQgPSBcInN1Y2Nlc3NcIjtcbiAgICBlbHNlIGlmIChjb2xvciA9PT0gXCJ3YXJuaW5nXCIpIHJlc29sdmVkVmFyaWFudCA9IFwid2FybmluZ1wiO1xuICAgIGVsc2UgaWYgKGNvbG9yID09PSBcImVycm9yXCIgfHwgY29sb3IgPT09IFwiZGVzdHJ1Y3RpdmVcIikgcmVzb2x2ZWRWYXJpYW50ID0gXCJkZXN0cnVjdGl2ZVwiO1xuICAgIGVsc2UgaWYgKGNvbG9yID09PSBcImluZm9cIiB8fCBjb2xvciA9PT0gXCJwcmltYXJ5XCIpIHJlc29sdmVkVmFyaWFudCA9IFwiZGVmYXVsdFwiO1xuICAgIGVsc2UgcmVzb2x2ZWRWYXJpYW50ID0gXCJzZWNvbmRhcnlcIjtcbiAgfVxuXG4gIGNvbnN0IHJlc29sdmVkU2l6ZSA9IHNpemUgPT09IFwic21cIiB8fCBzaXplID09PSBcIm1kXCIgfHwgc2l6ZSA9PT0gXCJsZ1wiID8gc2l6ZSA6IFwibWRcIjtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17Y24oYmFkZ2VWYXJpYW50cyh7IHZhcmlhbnQ6IHJlc29sdmVkVmFyaWFudCwgc2l6ZTogcmVzb2x2ZWRTaXplIH0pLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEJhZGdlO1xuZXhwb3J0IHsgQmFkZ2UsIGJhZGdlVmFyaWFudHMgfTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9iYWRnZS50c3gifQ==