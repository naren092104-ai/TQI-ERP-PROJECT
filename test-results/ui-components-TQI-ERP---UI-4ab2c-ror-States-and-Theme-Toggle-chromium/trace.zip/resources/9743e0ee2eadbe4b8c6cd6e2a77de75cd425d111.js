import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ModuleLibraryView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import { Plus, Search, FileText, Download, Upload, Trash2, X, Edit3 } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const ModuleLibraryView = ({
  modules,
  currentUserRole,
  onCreateModule,
  onUpdateModule,
  onDeleteModule,
  onUploadResource,
  onDownloadResource
}) => {
  _s();
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingModule, setEditingModule] = useState(null);
  const [formData, setFormData] = useState({
    moduleNumber: "",
    moduleName: "",
    topic: "",
    description: "",
    academicYear: "2023-2024",
    dayNumber: 1
  });
  const filteredModules = modules.filter(
    (m) => m.moduleName.toLowerCase().includes(searchTerm.toLowerCase()) || m.topic.toLowerCase().includes(searchTerm.toLowerCase()) || m.moduleNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleOpenModal = (mod) => {
    if (mod) {
      setEditingModule(mod);
      setFormData({
        moduleNumber: mod.moduleNumber,
        moduleName: mod.moduleName,
        topic: mod.topic,
        description: mod.description || "",
        academicYear: mod.academicYear,
        dayNumber: mod.dayNumber || 1
      });
    } else {
      setEditingModule(null);
      setFormData({
        moduleNumber: "",
        moduleName: "",
        topic: "",
        description: "",
        academicYear: "2023-2024",
        dayNumber: 1
      });
    }
    setIsModalOpen(true);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editingModule && onUpdateModule) {
      await onUpdateModule(editingModule.id, formData);
    } else if (onCreateModule) {
      await onCreateModule(formData);
    }
    setIsModalOpen(false);
  };
  const handleUpload = async (moduleId) => {
    if (!onUploadResource) return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".pdf,.ppt,.pptx";
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (file) {
        await onUploadResource(moduleId, file);
      }
    };
    input.click();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Module Library" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Manage curriculum modules and download learning resources." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 106,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: currentUserRole === "Super Admin" && /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => handleOpenModal(),
          className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
          children: [
            /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 116,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Create Module" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 117,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 112,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: searchTerm,
          onChange: (e) => setSearchTerm(e.target.value),
          placeholder: "Search modules...",
          className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 125,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4", children: [
      filteredModules.map(
        (module) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2 py-1 rounded text-xs font-bold bg-brand-50 text-brand-600 dark:bg-brand-500/10 dark:text-brand-400", children: module.moduleNumber }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 139,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2 py-1 rounded text-[10px] font-bold bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400", children: [
                "Day ",
                module.dayNumber
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 142,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 138,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: currentUserRole === "Super Admin" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: () => handleOpenModal(module), className: "p-1.5 text-gray-400 hover:text-brand-500 hover:bg-brand-50 rounded-lg transition", children: /* @__PURE__ */ jsxDEV(Edit3, { className: "w-4 h-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 150,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 149,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => onDeleteModule && onDeleteModule(module.id), className: "p-1.5 text-gray-400 hover:text-error-500 hover:bg-error-50 rounded-lg transition", children: /* @__PURE__ */ jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 153,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 152,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 148,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 146,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 137,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mt-2", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: module.moduleName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 161,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: `text-[10px] px-2 py-1 rounded font-bold ${module.status === "Active" ? "bg-success-50 text-success-600 dark:bg-success-500/10 dark:text-success-400" : "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"}`, children: module.status || "Active" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 162,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 160,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 dark:text-gray-400 mt-1", children: module.topic }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 165,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-600 dark:text-gray-400 mt-3 line-clamp-3 flex-1", children: module.description }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 166,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-center justify-between text-xs text-gray-500 dark:text-gray-400", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 bg-gray-100 rounded dark:bg-gray-800", children: module.academicYear }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 169,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 168,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-100 dark:border-gray-800 space-y-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-500", children: [
                "Resources (",
                module.resources?.length || 0,
                ")"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 174,
                columnNumber: 17
              }, this),
              currentUserRole === "Super Admin" && /* @__PURE__ */ jsxDEV("button", { onClick: () => handleUpload(module.id), className: "text-brand-500 font-semibold hover:underline flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(Upload, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                  lineNumber: 177,
                  columnNumber: 21
                }, this),
                " Upload"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 176,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 173,
              columnNumber: 15
            }, this),
            module.resources?.map(
              (res) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-2 bg-gray-50 dark:bg-white/[0.02] rounded-lg border border-gray-100 dark:border-gray-800 text-xs", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 truncate", children: [
                  /* @__PURE__ */ jsxDEV(FileText, { className: "w-3.5 h-3.5 text-brand-500 shrink-0" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                    lineNumber: 184,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "truncate text-gray-700 dark:text-gray-300", children: res.fileName }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                    lineNumber: 185,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                  lineNumber: 183,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("button", { onClick: () => onDownloadResource && onDownloadResource(module.id, res.id), className: "text-gray-500 hover:text-brand-500 p-1", children: /* @__PURE__ */ jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                  lineNumber: 188,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                  lineNumber: 187,
                  columnNumber: 19
                }, this)
              ] }, res.id, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 182,
                columnNumber: 13
              }, this)
            ),
            (!module.resources || module.resources.length === 0) && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400 text-center py-2 bg-gray-50 dark:bg-white/[0.02] rounded-lg", children: "No resources attached" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 193,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 172,
            columnNumber: 13
          }, this)
        ] }, module.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 136,
          columnNumber: 9
        }, this)
      ),
      filteredModules.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-12 text-center text-sm text-gray-500 border border-dashed border-gray-200 rounded-xl dark:border-gray-800", children: "No modules found matching your search." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 199,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
      lineNumber: 134,
      columnNumber: 7
    }, this),
    isModalOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-gray-900/60 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md bg-white dark:bg-gray-900 rounded-2xl shadow-xl overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-bold text-gray-900 dark:text-white", children: editingModule ? "Edit Module" : "Create Module" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 209,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsModalOpen(false), className: "text-gray-400 hover:text-gray-600", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 213,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 212,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 208,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "p-4 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", htmlFor: "mod-num", children: "Module Number" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 219,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { id: "mod-num", required: true, value: formData.moduleNumber, onChange: (e) => setFormData({ ...formData, moduleNumber: e.target.value }), className: "w-full text-xs rounded-xl border border-gray-300 p-2 dark:bg-gray-800 dark:border-gray-700 dark:text-white", placeholder: "e.g. M-101" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 220,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 218,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", children: "Day Number (1-8)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
              lineNumber: 223,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: String(formData.dayNumber),
                onValueChange: (val) => setFormData({ ...formData, dayNumber: Number(val) }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full text-xs h-9 rounded-xl border border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:text-white", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Day" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                    lineNumber: 229,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                    lineNumber: 228,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [1, 2, 3, 4, 5, 6, 7, 8].map(
                    (d) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(d), children: [
                      "Day ",
                      d
                    ] }, d, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                      lineNumber: 233,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                    lineNumber: 231,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
                lineNumber: 224,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 222,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 217,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", htmlFor: "mod-name", children: "Module Name" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 242,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { id: "mod-name", required: true, value: formData.moduleName, onChange: (e) => setFormData({ ...formData, moduleName: e.target.value }), className: "w-full text-xs rounded-xl border border-gray-300 p-2 dark:bg-gray-800 dark:border-gray-700 dark:text-white" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 243,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 241,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", htmlFor: "mod-topic", children: "Topic" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 246,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { id: "mod-topic", required: true, value: formData.topic, onChange: (e) => setFormData({ ...formData, topic: e.target.value }), className: "w-full text-xs rounded-xl border border-gray-300 p-2 dark:bg-gray-800 dark:border-gray-700 dark:text-white" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 247,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 245,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", htmlFor: "mod-year", children: "Academic Year" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 250,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { id: "mod-year", required: true, value: formData.academicYear, onChange: (e) => setFormData({ ...formData, academicYear: e.target.value }), className: "w-full text-xs rounded-xl border border-gray-300 p-2 dark:bg-gray-800 dark:border-gray-700 dark:text-white" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 251,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 249,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1", htmlFor: "mod-desc", children: "Description" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 254,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { id: "mod-desc", rows: 3, value: formData.description, onChange: (e) => setFormData({ ...formData, description: e.target.value }), className: "w-full text-xs rounded-xl border border-gray-300 p-2 dark:bg-gray-800 dark:border-gray-700 dark:text-white" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 255,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 253,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-4 flex justify-end gap-2 border-t border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setIsModalOpen(false), className: "px-4 py-2 text-xs font-semibold text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300", children: "Cancel" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 258,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-4 py-2 text-xs font-semibold text-white bg-brand-500 rounded-xl hover:bg-brand-600", children: "Save Module" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
            lineNumber: 259,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
          lineNumber: 257,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
        lineNumber: 216,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
      lineNumber: 207,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
      lineNumber: 206,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx",
    lineNumber: 100,
    columnNumber: 5
  }, this);
};
_s(ModuleLibraryView, "BIVPXmshSTHIQD2gVKFlLUgJrn8=");
_c = ModuleLibraryView;
var _c;
$RefreshReg$(_c, "ModuleLibraryView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ModuleLibraryView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dVLFNBNkNRLFVBN0NSOztBQXRHVixTQUFnQkEsZ0JBQWdCO0FBRWhDLFNBQVNDLE1BQU1DLFFBQVFDLFVBQVVDLFVBQVVDLFFBQVFDLFFBQVFDLEdBQUdDLGFBQWE7QUFDM0U7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBWUEsYUFBTUMsb0JBQXNEQSxDQUFDO0FBQUEsRUFDbEVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl4QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDeUIsYUFBYUMsY0FBYyxJQUFJMUIsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBMkIsSUFBSTtBQUV6RSxRQUFNLENBQUM2QixVQUFVQyxXQUFXLElBQUk5QixTQUFTO0FBQUEsSUFDdkMrQixjQUFjO0FBQUEsSUFDZEMsWUFBWTtBQUFBLElBQ1pDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsY0FBYztBQUFBLElBQ2RDLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFFRCxRQUFNQyxrQkFBa0J0QixRQUFRdUI7QUFBQUEsSUFBTyxDQUFBQyxNQUNyQ0EsRUFBRVAsV0FBV1EsWUFBWSxFQUFFQyxTQUFTbEIsV0FBV2lCLFlBQVksQ0FBQyxLQUM1REQsRUFBRU4sTUFBTU8sWUFBWSxFQUFFQyxTQUFTbEIsV0FBV2lCLFlBQVksQ0FBQyxLQUN2REQsRUFBRVIsYUFBYVMsWUFBWSxFQUFFQyxTQUFTbEIsV0FBV2lCLFlBQVksQ0FBQztBQUFBLEVBQ2hFO0FBRUEsUUFBTUUsa0JBQWtCQSxDQUFDQyxRQUFvQjtBQUMzQyxRQUFJQSxLQUFLO0FBQ1BmLHVCQUFpQmUsR0FBRztBQUNwQmIsa0JBQVk7QUFBQSxRQUNWQyxjQUFjWSxJQUFJWjtBQUFBQSxRQUNsQkMsWUFBWVcsSUFBSVg7QUFBQUEsUUFDaEJDLE9BQU9VLElBQUlWO0FBQUFBLFFBQ1hDLGFBQWFTLElBQUlULGVBQWU7QUFBQSxRQUNoQ0MsY0FBY1EsSUFBSVI7QUFBQUEsUUFDbEJDLFdBQVdPLElBQUlQLGFBQWE7QUFBQSxNQUM5QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0xSLHVCQUFpQixJQUFJO0FBQ3JCRSxrQkFBWTtBQUFBLFFBQ1ZDLGNBQWM7QUFBQSxRQUNkQyxZQUFZO0FBQUEsUUFDWkMsT0FBTztBQUFBLFFBQ1BDLGFBQWE7QUFBQSxRQUNiQyxjQUFjO0FBQUEsUUFDZEMsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUFBLElBQ0g7QUFDQVYsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTWtCLGVBQWUsT0FBT0MsTUFBdUI7QUFDakRBLE1BQUVDLGVBQWU7QUFDakIsUUFBSW5CLGlCQUFpQlQsZ0JBQWdCO0FBQ25DLFlBQU1BLGVBQWVTLGNBQWNvQixJQUFJbEIsUUFBUTtBQUFBLElBQ2pELFdBQVdaLGdCQUFnQjtBQUN6QixZQUFNQSxlQUFlWSxRQUFRO0FBQUEsSUFDL0I7QUFDQUgsbUJBQWUsS0FBSztBQUFBLEVBQ3RCO0FBRUEsUUFBTXNCLGVBQWUsT0FBT0MsYUFBcUI7QUFDL0MsUUFBSSxDQUFDN0IsaUJBQWtCO0FBQ3ZCLFVBQU04QixRQUFRQyxTQUFTQyxjQUFjLE9BQU87QUFDNUNGLFVBQU1HLE9BQU87QUFDYkgsVUFBTUksU0FBUztBQUNmSixVQUFNSyxXQUFXLE9BQU9WLE1BQVc7QUFDakMsWUFBTVcsT0FBT1gsRUFBRVksT0FBT0MsTUFBTSxDQUFDO0FBQzdCLFVBQUlGLE1BQU07QUFDUixjQUFNcEMsaUJBQWlCNkIsVUFBVU8sSUFBSTtBQUFBLE1BQ3ZDO0FBQUEsSUFDRjtBQUNBTixVQUFNUyxNQUFNO0FBQUEsRUFDZDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw4RUFBNEUsOEJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLGlEQUErQywwRUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWjNDLDhCQUFvQixpQkFDbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTTBCLGdCQUFnQjtBQUFBLFVBQy9CLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCO0FBQUEsWUFDekIsdUJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBO0FBQUE7QUFBQSxRQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQSxLQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsNkJBQUMsVUFBTyxXQUFVLDBGQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdHO0FBQUEsTUFDeEc7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9uQjtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3NCLE1BQU1yQixjQUFjcUIsRUFBRVksT0FBT0csS0FBSztBQUFBLFVBQzdDLGFBQVk7QUFBQSxVQUNaLFdBQVU7QUFBQTtBQUFBLFFBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2lQO0FBQUEsU0FQblA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1p2QjtBQUFBQSxzQkFBZ0J3QjtBQUFBQSxRQUFJLENBQUNDLFdBQ3BCLHVCQUFDLFNBQW9CLFdBQVUsMkhBQzdCO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLG9JQUNiQSxpQkFBTy9CLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSxrSUFBZ0k7QUFBQTtBQUFBLGdCQUN6SStCLE9BQU8xQjtBQUFBQSxtQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNacEIsOEJBQW9CLGlCQUNuQixtQ0FDRTtBQUFBLHFDQUFDLFlBQU8sU0FBUyxNQUFNMEIsZ0JBQWdCb0IsTUFBTSxHQUFHLFdBQVUsb0ZBQ3hELGlDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQixLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTTNDLGtCQUFrQkEsZUFBZTJDLE9BQU9mLEVBQUUsR0FBRyxXQUFVLG9GQUM1RSxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0EsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxxREFBcURlLGlCQUFPOUIsY0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRix1QkFBQyxVQUFLLFdBQVcsMkNBQTJDOEIsT0FBT0MsV0FBVyxXQUFXLGdGQUFnRiwrREFBK0QsSUFBS0QsaUJBQU9DLFVBQVUsWUFBOVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdVE7QUFBQSxlQUZ6UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsK0RBQStERCxpQkFBTzdCLFNBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlGO0FBQUEsVUFDekYsdUJBQUMsT0FBRSxXQUFVLHFFQUFxRTZCLGlCQUFPNUIsZUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUc7QUFBQSxVQUVyRyx1QkFBQyxTQUFJLFdBQVUsbUZBQ2IsaUNBQUMsVUFBSyxXQUFVLGtEQUFrRDRCLGlCQUFPM0IsZ0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGLEtBRHhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwrQkFBOEI7QUFBQTtBQUFBLGdCQUFZMkIsT0FBT0UsV0FBV0MsVUFBVTtBQUFBLGdCQUFFO0FBQUEsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlGO0FBQUEsY0FDeEZqRCxvQkFBb0IsaUJBQ25CLHVCQUFDLFlBQU8sU0FBUyxNQUFNZ0MsYUFBYWMsT0FBT2YsRUFBRSxHQUFHLFdBQVUsd0VBQ3hEO0FBQUEsdUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsZ0JBQUc7QUFBQSxtQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNDZSxPQUFPRSxXQUFXSDtBQUFBQSxjQUFJLENBQUFLLFFBQ3JCLHVCQUFDLFNBQWlCLFdBQVUsd0lBQzFCO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEseUNBQUMsWUFBUyxXQUFVLHlDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxVQUFLLFdBQVUsNkNBQTZDQSxjQUFJQyxZQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRTtBQUFBLHFCQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU05QyxzQkFBc0JBLG1CQUFtQnlDLE9BQU9mLElBQUltQixJQUFJbkIsRUFBRSxHQUFHLFdBQVUsMENBQzVGLGlDQUFDLFlBQVMsV0FBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUMsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVBRbUIsSUFBSW5CLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLFlBQ0Q7QUFBQSxhQUNDLENBQUNlLE9BQU9FLGFBQWFGLE9BQU9FLFVBQVVDLFdBQVcsTUFDakQsdUJBQUMsU0FBSSxXQUFVLHFGQUFvRixxQ0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0g7QUFBQSxlQXJCNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQTNEUUgsT0FBT2YsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTREQTtBQUFBLE1BQ0Q7QUFBQSxNQUNBVixnQkFBZ0I0QixXQUFXLEtBQzFCLHVCQUFDLFNBQUksV0FBVSw4SEFBNEgsc0RBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBbkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRUE7QUFBQSxJQUVDeEMsZUFDQyx1QkFBQyxTQUFJLFdBQVUsMEVBQ2IsaUNBQUMsU0FBSSxXQUFVLG1GQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDJDQUNYRSwwQkFBZ0IsZ0JBQWdCLG1CQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sU0FBUyxNQUFNRCxlQUFlLEtBQUssR0FBRyxXQUFVLHFDQUN0RCxpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNCLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFVBQVVrQixjQUFjLFdBQVUsaUJBQ3RDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxRUFBb0UsU0FBUSxXQUFVLDZCQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSDtBQUFBLFlBQ3BILHVCQUFDLFdBQU0sSUFBRyxXQUFVLFVBQVEsTUFBQyxPQUFPZixTQUFTRSxjQUFjLFVBQVUsQ0FBQWMsTUFBS2YsWUFBWSxFQUFDLEdBQUdELFVBQVVFLGNBQWNjLEVBQUVZLE9BQU9HLE1BQUssQ0FBQyxHQUFHLFdBQVUsOEdBQTZHLGFBQVksZ0JBQXZRO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1SO0FBQUEsZUFGclI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxRUFBb0UsZ0NBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFHO0FBQUEsWUFDckc7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPUSxPQUFPdkMsU0FBU08sU0FBUztBQUFBLGdCQUNoQyxlQUFlLENBQUNpQyxRQUFRdkMsWUFBWSxFQUFFLEdBQUdELFVBQVVPLFdBQVdrQyxPQUFPRCxHQUFHLEVBQUUsQ0FBQztBQUFBLGdCQUUzRTtBQUFBLHlDQUFDLGlCQUFjLFdBQVUsOEdBQ3ZCLGlDQUFDLGVBQVksYUFBWSxnQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFLFdBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUVSO0FBQUFBLG9CQUFJLENBQUNVLE1BQzdCLHVCQUFDLGNBQW1CLE9BQU9ILE9BQU9HLENBQUMsR0FBRTtBQUFBO0FBQUEsc0JBQzlCQTtBQUFBQSx5QkFEVUEsR0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFFQUFvRSxTQUFRLFlBQVcsMkJBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1IO0FBQUEsVUFDbkgsdUJBQUMsV0FBTSxJQUFHLFlBQVcsVUFBUSxNQUFDLE9BQU8xQyxTQUFTRyxZQUFZLFVBQVUsQ0FBQWEsTUFBS2YsWUFBWSxFQUFDLEdBQUdELFVBQVVHLFlBQVlhLEVBQUVZLE9BQU9HLE1BQUssQ0FBQyxHQUFHLFdBQVUsZ0hBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVQO0FBQUEsYUFGelA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFFQUFvRSxTQUFRLGFBQVkscUJBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThHO0FBQUEsVUFDOUcsdUJBQUMsV0FBTSxJQUFHLGFBQVksVUFBUSxNQUFDLE9BQU8vQixTQUFTSSxPQUFPLFVBQVUsQ0FBQVksTUFBS2YsWUFBWSxFQUFDLEdBQUdELFVBQVVJLE9BQU9ZLEVBQUVZLE9BQU9HLE1BQUssQ0FBQyxHQUFHLFdBQVUsZ0hBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThPO0FBQUEsYUFGaFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFFQUFvRSxTQUFRLFlBQVcsNkJBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsVUFDckgsdUJBQUMsV0FBTSxJQUFHLFlBQVcsVUFBUSxNQUFDLE9BQU8vQixTQUFTTSxjQUFjLFVBQVUsQ0FBQVUsTUFBS2YsWUFBWSxFQUFDLEdBQUdELFVBQVVNLGNBQWNVLEVBQUVZLE9BQU9HLE1BQUssQ0FBQyxHQUFHLFdBQVUsZ0hBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJQO0FBQUEsYUFGN1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFFQUFvRSxTQUFRLFlBQVcsMkJBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1IO0FBQUEsVUFDbkgsdUJBQUMsY0FBUyxJQUFHLFlBQVcsTUFBTSxHQUFHLE9BQU8vQixTQUFTSyxhQUFhLFVBQVUsQ0FBQVcsTUFBS2YsWUFBWSxFQUFDLEdBQUdELFVBQVVLLGFBQWFXLEVBQUVZLE9BQU9HLE1BQUssQ0FBQyxHQUFHLFdBQVUsZ0hBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRQO0FBQUEsYUFGOVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkVBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1sQyxlQUFlLEtBQUssR0FBRyxXQUFVLDhIQUE2SCxzQkFBbk07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeU07QUFBQSxVQUN6TSx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLHlGQUF3RiwyQkFBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUk7QUFBQSxhQUZySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBO0FBQUEsU0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQSxLQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeURBO0FBQUEsT0FuS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFLQTtBQUVKO0FBQUVKLEdBclBXUixtQkFBbUQ7QUFBQSxLQUFuREE7QUFBbUQsSUFBQTBEO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUGx1cyIsIlNlYXJjaCIsIkZpbGVUZXh0IiwiRG93bmxvYWQiLCJVcGxvYWQiLCJUcmFzaDIiLCJYIiwiRWRpdDMiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIk1vZHVsZUxpYnJhcnlWaWV3IiwibW9kdWxlcyIsImN1cnJlbnRVc2VyUm9sZSIsIm9uQ3JlYXRlTW9kdWxlIiwib25VcGRhdGVNb2R1bGUiLCJvbkRlbGV0ZU1vZHVsZSIsIm9uVXBsb2FkUmVzb3VyY2UiLCJvbkRvd25sb2FkUmVzb3VyY2UiLCJfcyIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwiaXNNb2RhbE9wZW4iLCJzZXRJc01vZGFsT3BlbiIsImVkaXRpbmdNb2R1bGUiLCJzZXRFZGl0aW5nTW9kdWxlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm1vZHVsZU51bWJlciIsIm1vZHVsZU5hbWUiLCJ0b3BpYyIsImRlc2NyaXB0aW9uIiwiYWNhZGVtaWNZZWFyIiwiZGF5TnVtYmVyIiwiZmlsdGVyZWRNb2R1bGVzIiwiZmlsdGVyIiwibSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJoYW5kbGVPcGVuTW9kYWwiLCJtb2QiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJpZCIsImhhbmRsZVVwbG9hZCIsIm1vZHVsZUlkIiwiaW5wdXQiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJ0eXBlIiwiYWNjZXB0Iiwib25jaGFuZ2UiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJjbGljayIsInZhbHVlIiwibWFwIiwibW9kdWxlIiwic3RhdHVzIiwicmVzb3VyY2VzIiwibGVuZ3RoIiwicmVzIiwiZmlsZU5hbWUiLCJTdHJpbmciLCJ2YWwiLCJOdW1iZXIiLCJkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9kdWxlTGlicmFyeVZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRxaU1vZHVsZSwgVXNlclJvbGUgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBQbHVzLCBTZWFyY2gsIEZpbGVUZXh0LCBEb3dubG9hZCwgVXBsb2FkLCBUcmFzaDIsIFgsIEVkaXQzIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gJy4vdWkvc2VsZWN0JztcblxuaW50ZXJmYWNlIE1vZHVsZUxpYnJhcnlWaWV3UHJvcHMge1xuICBtb2R1bGVzOiBUcWlNb2R1bGVbXTtcbiAgY3VycmVudFVzZXJSb2xlOiBVc2VyUm9sZTtcbiAgb25DcmVhdGVNb2R1bGU/OiAobW9kdWxlOiB7IG1vZHVsZU51bWJlcjogc3RyaW5nOyBtb2R1bGVOYW1lOiBzdHJpbmc7IHRvcGljOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmc7IGFjYWRlbWljWWVhcjogc3RyaW5nOyBkYXlOdW1iZXI6IG51bWJlciB9KSA9PiBQcm9taXNlPHZvaWQ+O1xuICBvblVwZGF0ZU1vZHVsZT86IChpZDogc3RyaW5nLCBtb2R1bGU6IGFueSkgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25EZWxldGVNb2R1bGU/OiAoaWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25VcGxvYWRSZXNvdXJjZT86IChtb2R1bGVJZDogc3RyaW5nLCBmaWxlOiBGaWxlKSA9PiBQcm9taXNlPHZvaWQ+O1xuICBvbkRvd25sb2FkUmVzb3VyY2U/OiAobW9kdWxlSWQ6IHN0cmluZywgcmVzb3VyY2VJZDogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgTW9kdWxlTGlicmFyeVZpZXc6IFJlYWN0LkZDPE1vZHVsZUxpYnJhcnlWaWV3UHJvcHM+ID0gKHtcbiAgbW9kdWxlcyxcbiAgY3VycmVudFVzZXJSb2xlLFxuICBvbkNyZWF0ZU1vZHVsZSxcbiAgb25VcGRhdGVNb2R1bGUsXG4gIG9uRGVsZXRlTW9kdWxlLFxuICBvblVwbG9hZFJlc291cmNlLFxuICBvbkRvd25sb2FkUmVzb3VyY2Vcbn0pID0+IHtcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNNb2RhbE9wZW4sIHNldElzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2VkaXRpbmdNb2R1bGUsIHNldEVkaXRpbmdNb2R1bGVdID0gdXNlU3RhdGU8VHFpTW9kdWxlIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XG4gICAgbW9kdWxlTnVtYmVyOiAnJyxcbiAgICBtb2R1bGVOYW1lOiAnJyxcbiAgICB0b3BpYzogJycsXG4gICAgZGVzY3JpcHRpb246ICcnLFxuICAgIGFjYWRlbWljWWVhcjogJzIwMjMtMjAyNCcsXG4gICAgZGF5TnVtYmVyOiAxXG4gIH0pO1xuXG4gIGNvbnN0IGZpbHRlcmVkTW9kdWxlcyA9IG1vZHVsZXMuZmlsdGVyKG0gPT4gXG4gICAgbS5tb2R1bGVOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fCBcbiAgICBtLnRvcGljLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgIG0ubW9kdWxlTnVtYmVyLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZU9wZW5Nb2RhbCA9IChtb2Q/OiBUcWlNb2R1bGUpID0+IHtcbiAgICBpZiAobW9kKSB7XG4gICAgICBzZXRFZGl0aW5nTW9kdWxlKG1vZCk7XG4gICAgICBzZXRGb3JtRGF0YSh7XG4gICAgICAgIG1vZHVsZU51bWJlcjogbW9kLm1vZHVsZU51bWJlcixcbiAgICAgICAgbW9kdWxlTmFtZTogbW9kLm1vZHVsZU5hbWUsXG4gICAgICAgIHRvcGljOiBtb2QudG9waWMsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBtb2QuZGVzY3JpcHRpb24gfHwgJycsXG4gICAgICAgIGFjYWRlbWljWWVhcjogbW9kLmFjYWRlbWljWWVhcixcbiAgICAgICAgZGF5TnVtYmVyOiBtb2QuZGF5TnVtYmVyIHx8IDFcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRFZGl0aW5nTW9kdWxlKG51bGwpO1xuICAgICAgc2V0Rm9ybURhdGEoe1xuICAgICAgICBtb2R1bGVOdW1iZXI6ICcnLFxuICAgICAgICBtb2R1bGVOYW1lOiAnJyxcbiAgICAgICAgdG9waWM6ICcnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICAgIGFjYWRlbWljWWVhcjogJzIwMjMtMjAyNCcsXG4gICAgICAgIGRheU51bWJlcjogMVxuICAgICAgfSk7XG4gICAgfVxuICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKGVkaXRpbmdNb2R1bGUgJiYgb25VcGRhdGVNb2R1bGUpIHtcbiAgICAgIGF3YWl0IG9uVXBkYXRlTW9kdWxlKGVkaXRpbmdNb2R1bGUuaWQsIGZvcm1EYXRhKTtcbiAgICB9IGVsc2UgaWYgKG9uQ3JlYXRlTW9kdWxlKSB7XG4gICAgICBhd2FpdCBvbkNyZWF0ZU1vZHVsZShmb3JtRGF0YSk7XG4gICAgfVxuICAgIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVVcGxvYWQgPSBhc3luYyAobW9kdWxlSWQ6IHN0cmluZykgPT4ge1xuICAgIGlmICghb25VcGxvYWRSZXNvdXJjZSkgcmV0dXJuO1xuICAgIGNvbnN0IGlucHV0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKTtcbiAgICBpbnB1dC50eXBlID0gJ2ZpbGUnO1xuICAgIGlucHV0LmFjY2VwdCA9ICcucGRmLC5wcHQsLnBwdHgnO1xuICAgIGlucHV0Lm9uY2hhbmdlID0gYXN5bmMgKGU6IGFueSkgPT4ge1xuICAgICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xuICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgYXdhaXQgb25VcGxvYWRSZXNvdXJjZShtb2R1bGVJZCwgZmlsZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBpbnB1dC5jbGljaygpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgTW9kdWxlIExpYnJhcnlcbiAgICAgICAgICA8L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgTWFuYWdlIGN1cnJpY3VsdW0gbW9kdWxlcyBhbmQgZG93bmxvYWQgbGVhcm5pbmcgcmVzb3VyY2VzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7Y3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+Q3JlYXRlIE1vZHVsZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZ3JheS00MDAgYWJzb2x1dGUgbGVmdC0zLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBtb2R1bGVzLi4uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTEwIHByLTQgcHktMi41IHRleHQtc20gdGV4dC1ncmF5LTgwMCBzaGFkb3ctdGhlbWUteHMgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgIHtmaWx0ZXJlZE1vZHVsZXMubWFwKChtb2R1bGUpID0+IChcbiAgICAgICAgICA8ZGl2IGtleT17bW9kdWxlLmlkfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0xIHJvdW5kZWQgdGV4dC14cyBmb250LWJvbGQgYmctYnJhbmQtNTAgdGV4dC1icmFuZC02MDAgZGFyazpiZy1icmFuZC01MDAvMTAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiPlxuICAgICAgICAgICAgICAgICAge21vZHVsZS5tb2R1bGVOdW1iZXJ9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTYwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgRGF5IHttb2R1bGUuZGF5TnVtYmVyfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICB7Y3VycmVudFVzZXJSb2xlID09PSAnU3VwZXIgQWRtaW4nICYmIChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKG1vZHVsZSl9IGNsYXNzTmFtZT1cInAtMS41IHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1icmFuZC01MDAgaG92ZXI6YmctYnJhbmQtNTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZU1vZHVsZSAmJiBvbkRlbGV0ZU1vZHVsZShtb2R1bGUuaWQpfSBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZXJyb3ItNTAwIGhvdmVyOmJnLWVycm9yLTUwIHJvdW5kZWQtbGcgdHJhbnNpdGlvblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbXQtMlwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPnttb2R1bGUubW9kdWxlTmFtZX08L2gzPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBweC0yIHB5LTEgcm91bmRlZCBmb250LWJvbGQgJHttb2R1bGUuc3RhdHVzID09PSAnQWN0aXZlJyA/ICdiZy1zdWNjZXNzLTUwIHRleHQtc3VjY2Vzcy02MDAgZGFyazpiZy1zdWNjZXNzLTUwMC8xMCBkYXJrOnRleHQtc3VjY2Vzcy00MDAnIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS01MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS00MDAnfWB9Pnttb2R1bGUuc3RhdHVzIHx8ICdBY3RpdmUnfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPnttb2R1bGUudG9waWN9PC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0zIGxpbmUtY2xhbXAtMyBmbGV4LTFcIj57bW9kdWxlLmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1ncmF5LTEwMCByb3VuZGVkIGRhcms6YmctZ3JheS04MDBcIj57bW9kdWxlLmFjYWRlbWljWWVhcn08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5SZXNvdXJjZXMgKHttb2R1bGUucmVzb3VyY2VzPy5sZW5ndGggfHwgMH0pPC9zcGFuPlxuICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbicgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGxvYWQobW9kdWxlLmlkKX0gY2xhc3NOYW1lPVwidGV4dC1icmFuZC01MDAgZm9udC1zZW1pYm9sZCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz4gVXBsb2FkXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge21vZHVsZS5yZXNvdXJjZXM/Lm1hcChyZXMgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyZXMuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgYmctZ3JheS01MCBkYXJrOmJnLXdoaXRlL1swLjAyXSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1icmFuZC01MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPntyZXMuZmlsZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uRG93bmxvYWRSZXNvdXJjZSAmJiBvbkRvd25sb2FkUmVzb3VyY2UobW9kdWxlLmlkLCByZXMuaWQpfSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtYnJhbmQtNTAwIHAtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICB7KCFtb2R1bGUucmVzb3VyY2VzIHx8IG1vZHVsZS5yZXNvdXJjZXMubGVuZ3RoID09PSAwKSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgdGV4dC1jZW50ZXIgcHktMiBiZy1ncmF5LTUwIGRhcms6Ymctd2hpdGUvWzAuMDJdIHJvdW5kZWQtbGdcIj5ObyByZXNvdXJjZXMgYXR0YWNoZWQ8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgICAge2ZpbHRlcmVkTW9kdWxlcy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tZnVsbCBweS0xMiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtZ3JheS01MDAgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgIE5vIG1vZHVsZXMgZm91bmQgbWF0Y2hpbmcgeW91ciBzZWFyY2guXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2lzTW9kYWxPcGVuICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctZ3JheS05MDAvNjAgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgYmctd2hpdGUgZGFyazpiZy1ncmF5LTkwMCByb3VuZGVkLTJ4bCBzaGFkb3cteGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7ZWRpdGluZ01vZHVsZSA/ICdFZGl0IE1vZHVsZScgOiAnQ3JlYXRlIE1vZHVsZSd9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0SXNNb2RhbE9wZW4oZmFsc2UpfSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDBcIj5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInAtNCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiIGh0bWxGb3I9XCJtb2QtbnVtXCI+TW9kdWxlIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJtb2QtbnVtXCIgcmVxdWlyZWQgdmFsdWU9e2Zvcm1EYXRhLm1vZHVsZU51bWJlcn0gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCBtb2R1bGVOdW1iZXI6IGUudGFyZ2V0LnZhbHVlfSl9IGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTIgZGFyazpiZy1ncmF5LTgwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGVcIiBwbGFjZWhvbGRlcj1cImUuZy4gTS0xMDFcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5EYXkgTnVtYmVyICgxLTgpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1N0cmluZyhmb3JtRGF0YS5kYXlOdW1iZXIpfVxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkYXlOdW1iZXI6IE51bWJlcih2YWwpIH0pfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14cyBoLTkgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGRhcms6YmctZ3JheS04MDAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERheVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2LCA3LCA4XS5tYXAoKGQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17ZH0gdmFsdWU9e1N0cmluZyhkKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIERheSB7ZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiIGh0bWxGb3I9XCJtb2QtbmFtZVwiPk1vZHVsZSBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgaWQ9XCJtb2QtbmFtZVwiIHJlcXVpcmVkIHZhbHVlPXtmb3JtRGF0YS5tb2R1bGVOYW1lfSBvbkNoYW5nZT17ZSA9PiBzZXRGb3JtRGF0YSh7Li4uZm9ybURhdGEsIG1vZHVsZU5hbWU6IGUudGFyZ2V0LnZhbHVlfSl9IGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTIgZGFyazpiZy1ncmF5LTgwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIiBodG1sRm9yPVwibW9kLXRvcGljXCI+VG9waWM8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cIm1vZC10b3BpY1wiIHJlcXVpcmVkIHZhbHVlPXtmb3JtRGF0YS50b3BpY30gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCB0b3BpYzogZS50YXJnZXQudmFsdWV9KX0gY2xhc3NOYW1lPVwidy1mdWxsIHRleHQteHMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHAtMiBkYXJrOmJnLWdyYXktODAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMVwiIGh0bWxGb3I9XCJtb2QteWVhclwiPkFjYWRlbWljIFllYXI8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cIm1vZC15ZWFyXCIgcmVxdWlyZWQgdmFsdWU9e2Zvcm1EYXRhLmFjYWRlbWljWWVhcn0gb25DaGFuZ2U9e2UgPT4gc2V0Rm9ybURhdGEoey4uLmZvcm1EYXRhLCBhY2FkZW1pY1llYXI6IGUudGFyZ2V0LnZhbHVlfSl9IGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTIgZGFyazpiZy1ncmF5LTgwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIiBodG1sRm9yPVwibW9kLWRlc2NcIj5EZXNjcmlwdGlvbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhIGlkPVwibW9kLWRlc2NcIiByb3dzPXszfSB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb259IG9uQ2hhbmdlPXtlID0+IHNldEZvcm1EYXRhKHsuLi5mb3JtRGF0YSwgZGVzY3JpcHRpb246IGUudGFyZ2V0LnZhbHVlfSl9IGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXhzIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTIgZGFyazpiZy1ncmF5LTgwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGZsZXgganVzdGlmeS1lbmQgZ2FwLTIgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0SXNNb2RhbE9wZW4oZmFsc2UpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgYmctZ3JheS0xMDAgcm91bmRlZC14bCBob3ZlcjpiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPkNhbmNlbDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy1icmFuZC01MDAgcm91bmRlZC14bCBob3ZlcjpiZy1icmFuZC02MDBcIj5TYXZlIE1vZHVsZTwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Nb2R1bGVMaWJyYXJ5Vmlldy50c3gifQ==