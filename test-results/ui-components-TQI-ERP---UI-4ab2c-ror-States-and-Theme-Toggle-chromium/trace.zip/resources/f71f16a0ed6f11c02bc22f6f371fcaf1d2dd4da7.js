import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SessionPhotosView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useRef = __vite__cjsImport1_react["useRef"];
import { apiUrl } from "/src/utils/api.ts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const SessionPhotosView = ({
  panchayats = [],
  clusters = [],
  authToken,
  userRole = "Cluster Admin",
  currentCluster = "Dharmapuri",
  onNavigate,
  onRoleChange
}) => {
  _s();
  const [activeRole, setActiveRole] = useState(userRole);
  const [selectedCluster, setSelectedCluster] = useState(
    userRole === "Cluster Admin" ? "Dharmapuri" : "all"
  );
  const [selectedDayTab, setSelectedDayTab] = useState("all");
  const [expandedDay, setExpandedDay] = useState(null);
  const [selectedPanchayat, setSelectedPanchayat] = useState("all");
  const [selectedVillage, setSelectedVillage] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [photos, setPhotos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadDayTarget, setUploadDayTarget] = useState(1);
  const [viewDayModal, setViewDayModal] = useState(null);
  const [photoToDelete, setPhotoToDelete] = useState(null);
  const [downloadingZipKey, setDownloadingZipKey] = useState(null);
  const [completedZipKey, setCompletedZipKey] = useState(null);
  const [zipProgress, setZipProgress] = useState({
    stage: "idle",
    message: "",
    progressPercent: 0
  });
  const [uploadFiles, setUploadFiles] = useState([]);
  const [uploadTitle, setUploadTitle] = useState("Interactive Learning Workshop");
  const [uploadDay, setUploadDay] = useState(1);
  const [uploadPanchayat, setUploadPanchayat] = useState(panchayats[0]?.id || "vedakkattamaduvu");
  const [uploadVillage, setUploadVillage] = useState("Ammapettai");
  const [uploadDate, setUploadDate] = useState((/* @__PURE__ */ new Date()).toISOString().split("T")[0]);
  const [uploadUploader, setUploadUploader] = useState("Rahul K.");
  const [uploadCaption, setUploadCaption] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const fileInputRef = useRef(null);
  const showClusterLanding = activeRole === "Super Admin" && selectedCluster === "all";
  const photoClusters = useMemo(() => {
    const known = clusters.map((cluster) => ({ id: cluster.id, name: cluster.name }));
    const knownIds = new Set(known.map((cluster) => cluster.id.toLowerCase()));
    photos.forEach((photo) => {
      if (!knownIds.has(photo.clusterId.toLowerCase())) {
        known.push({ id: photo.clusterId, name: photo.clusterName || photo.clusterId });
        knownIds.add(photo.clusterId.toLowerCase());
      }
    });
    return known;
  }, [clusters, photos]);
  useEffect(() => {
    setActiveRole(userRole);
    if (userRole === "Cluster Admin") {
      setSelectedCluster("Dharmapuri");
    } else {
      setSelectedCluster("all");
    }
  }, [userRole]);
  const fetchPhotos = async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const clusterParam = activeRole === "Cluster Admin" ? "dharmapuri" : selectedCluster.toLowerCase();
      const res = await fetch(apiUrl(`/api/session-photos?cluster=${clusterParam}&role=${encodeURIComponent(activeRole)}`), {
        cache: "no-store",
        headers: authToken ? { Authorization: `Bearer ${authToken}` } : {}
      });
      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }
      const data = await res.json();
      if (data.success && Array.isArray(data.photos)) {
        setPhotos(data.photos);
      } else {
        setPhotos([]);
      }
    } catch (err) {
      console.error("Failed to load photos:", err);
      setLoadError("Failed to connect to backend server for photos. Retrying...");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchPhotos();
  }, [activeRole, selectedCluster, authToken]);
  const currentFilterVillages = useMemo(() => {
    if (selectedPanchayat === "all") {
      const allVillages = [];
      panchayats.forEach((p) => {
        p.villages?.forEach((v) => {
          if (!allVillages.some((existing) => existing.name === v.name)) {
            allVillages.push({ id: v.id, name: v.name });
          }
        });
      });
      return allVillages;
    }
    const found = panchayats.find((p) => p.id === selectedPanchayat || p.name === selectedPanchayat);
    return found?.villages || [];
  }, [selectedPanchayat, panchayats]);
  useEffect(() => {
    const selectedP = panchayats.find((p) => p.id === uploadPanchayat || p.name === uploadPanchayat);
    if (selectedP && selectedP.villages && selectedP.villages.length > 0) {
      setUploadVillage(selectedP.villages[0].name);
    }
  }, [uploadPanchayat, panchayats]);
  const daySummaries = useMemo(() => {
    const targetClusterPhotos = photos.filter(
      (p) => activeRole === "Cluster Admin" || selectedCluster === "all" || p.clusterId.toLowerCase() === selectedCluster.toLowerCase()
    );
    const summaries = [];
    for (let day = 1; day <= 8; day++) {
      const dayPhotos = targetClusterPhotos.filter((p) => p.dayNumber === day);
      const uniquePanchayats = new Set(dayPhotos.map((p) => p.panchayatId)).size;
      const targetCount = 50;
      summaries.push({
        dayNumber: day,
        dayLabel: `Day ${day}`,
        date: `2026-08-${15 + day}`,
        photosCount: dayPhotos.length,
        targetCount,
        panchayatCoverage: uniquePanchayats,
        featuredPhotos: dayPhotos.slice(0, 4)
      });
    }
    return summaries;
  }, [photos, selectedCluster, activeRole]);
  const filteredPhotos = useMemo(() => {
    return photos.filter((p) => {
      const matchCluster = activeRole === "Cluster Admin" ? p.clusterId.toLowerCase() === "dharmapuri" : selectedCluster === "all" || p.clusterId.toLowerCase() === selectedCluster.toLowerCase();
      const matchDay = selectedDayTab === "all" || p.dayNumber === selectedDayTab;
      const matchPanchayat = selectedPanchayat === "all" || p.panchayatId.toLowerCase() === selectedPanchayat.toLowerCase() || p.panchayatName.toLowerCase() === selectedPanchayat.toLowerCase();
      const matchVillage = selectedVillage === "all" || (p.villageName || "").toLowerCase() === selectedVillage.toLowerCase();
      const q = searchQuery.toLowerCase().trim();
      const matchSearch = !q || p.sessionTitle.toLowerCase().includes(q) || p.panchayatName.toLowerCase().includes(q) || p.villageName.toLowerCase().includes(q) || p.uploadedBy.toLowerCase().includes(q) || p.originalFilename.toLowerCase().includes(q);
      return matchCluster && matchDay && matchPanchayat && matchVillage && matchSearch;
    });
  }, [photos, selectedCluster, activeRole, selectedDayTab, selectedPanchayat, selectedVillage, searchQuery]);
  const handleDownloadZip = async (type, dayNumber) => {
    const key = type === "day" ? `day-${dayNumber}` : type === "cluster-all-days" ? `cluster-${selectedCluster}` : type === "all-clusters" ? "all-clusters" : "filtered";
    if (downloadingZipKey) {
      console.warn("Another ZIP download is already in progress.");
      return;
    }
    setDownloadingZipKey(key);
    setCompletedZipKey(null);
    setZipProgress({
      stage: "preparing",
      message: "Preparing ZIP request...",
      progressPercent: 15
    });
    try {
      await new Promise((r) => setTimeout(r, 250));
      setZipProgress({
        stage: "collecting",
        message: "Collecting original session photos from storage...",
        progressPercent: 40
      });
      await new Promise((r) => setTimeout(r, 300));
      setZipProgress({
        stage: "creating",
        message: "Generating compressed ZIP archive on backend...",
        progressPercent: 70
      });
      const params = new URLSearchParams();
      params.append("type", type);
      params.append(
        "cluster",
        activeRole === "Cluster Admin" ? "dharmapuri" : selectedCluster
      );
      params.append("userRole", activeRole);
      if (type === "day" && dayNumber) {
        params.append("dayNumber", String(dayNumber));
      } else if (type === "filtered") {
        if (selectedDayTab !== "all") params.append("dayNumber", String(selectedDayTab));
        if (selectedPanchayat !== "all") params.append("panchayatId", selectedPanchayat);
        if (selectedVillage !== "all") params.append("village", selectedVillage);
      }
      const zipUrl = apiUrl(`/api/session-photos/download-zip?${params.toString()}`);
      setZipProgress({
        stage: "downloading",
        message: "Streaming ZIP package to your device...",
        progressPercent: 90
      });
      const response = await fetch(zipUrl);
      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(
          errorJson.error || "Unable to create the ZIP file. Please try again."
        );
      }
      let downloadFilename = "TQI_Session_Photos.zip";
      const disposition = response.headers.get("Content-Disposition");
      if (disposition && disposition.includes("filename=")) {
        const match = disposition.match(/filename="?([^"]+)"?/);
        if (match && match[1]) {
          downloadFilename = match[1];
        }
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = downloadFilename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
      setZipProgress({
        stage: "completed",
        message: "ZIP downloaded successfully.",
        progressPercent: 100,
        zipFilename: downloadFilename
      });
      setCompletedZipKey(key);
      setTimeout(() => {
        setZipProgress({
          stage: "idle",
          message: "",
          progressPercent: 0
        });
      }, 4e3);
    } catch (err) {
      console.error("ZIP download failed:", err);
      setZipProgress({
        stage: "error",
        message: err.message || "Unable to create the ZIP file. Please try again.",
        progressPercent: 0,
        errorMessage: err.message || "Unable to create the ZIP file. Please try again."
      });
    } finally {
      setDownloadingZipKey(null);
    }
  };
  const handleDownloadSinglePhoto = (photo) => {
    const downloadUrl = apiUrl(`/api/session-photos/${photo.id}/download`);
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.download = photo.originalFilename || `Photo_${photo.id}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleDeletePhoto = async (photo) => {
    try {
      const res = await fetch(apiUrl(`/api/session-photos/${photo.id}`), {
        method: "DELETE",
        headers: authToken ? { Authorization: `Bearer ${authToken}` } : {}
      });
      if (!res.ok) {
        throw new Error("Failed to delete photo.");
      }
      setPhotos((prev) => prev.filter((p) => p.id !== photo.id));
      setPhotoToDelete(null);
      if (selectedPhoto && selectedPhoto.id === photo.id) {
        setSelectedPhoto(null);
      }
    } catch (err) {
      alert("Failed to delete photo. Please try again.");
    }
  };
  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (uploadFiles.length === 0) {
      setUploadError("Please select at least one photograph to upload.");
      return;
    }
    setIsUploading(true);
    setUploadError(null);
    const formData = new FormData();
    formData.append("clusterId", selectedCluster.toLowerCase());
    formData.append("clusterName", selectedCluster);
    formData.append("sessionTitle", uploadTitle);
    formData.append("dayNumber", String(uploadDay));
    formData.append("date", uploadDate);
    formData.append("panchayatId", uploadPanchayat);
    const foundP = panchayats.find((p) => p.id === uploadPanchayat || p.name === uploadPanchayat);
    formData.append("panchayatName", foundP ? foundP.name : uploadPanchayat);
    formData.append("villageName", uploadVillage);
    formData.append("uploadedBy", uploadUploader);
    formData.append("uploadedRole", activeRole);
    formData.append("caption", uploadCaption);
    uploadFiles.forEach((file) => {
      formData.append("photos", file);
    });
    try {
      const res = await fetch(apiUrl("/api/session-photos/upload"), {
        method: "POST",
        headers: authToken ? { Authorization: `Bearer ${authToken}` } : {},
        body: formData
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "Upload failed.");
      }
      if (data.photos && Array.isArray(data.photos)) {
        setPhotos((prev) => [...data.photos, ...prev]);
      }
      setShowUploadModal(false);
      setUploadFiles([]);
      setUploadCaption("");
    } catch (err) {
      console.error("Upload failed:", err);
      setUploadError(err.message || "Failed to upload photographs.");
    } finally {
      setIsUploading(false);
    }
  };
  const handleOpenUploadForDay = (day) => {
    setUploadDay(day);
    setShowUploadModal(true);
  };
  if (activeRole === "Super Admin" && selectedCluster !== "all" && selectedDayTab !== "all") {
    const selectedDayPhotos = photos.filter(
      (photo) => photo.clusterId.toLowerCase() === selectedCluster.toLowerCase() && photo.dayNumber === selectedDayTab
    );
    return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-7xl mx-auto pb-16 font-sans", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3 border-b border-slate-200 pb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-slate-500 font-medium mb-2", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setSelectedCluster("all"), className: "hover:text-[#0B3D91]", children: "Session Photos" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 474,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 475,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: selectedCluster }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 475,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 475,
              columnNumber: 59
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-[#0B3D91]", children: [
              "Day ",
              selectedDayTab
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 475,
              columnNumber: 73
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 473,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-slate-900", children: [
            selectedCluster,
            " - Day ",
            selectedDayTab,
            " Photos"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 477,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1", children: "Review the real photo records submitted for this day." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 478,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 472,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => {
          setSelectedDayTab("all");
          setExpandedDay(null);
        }, className: "px-3 py-2 rounded-md bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700", children: "Back to Days" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 480,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 471,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-sm text-slate-600", children: [
        /* @__PURE__ */ jsxDEV("span", { children: [
          selectedDayPhotos.length,
          " photo records"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 484,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", disabled: !selectedDayPhotos.length, onClick: () => handleDownloadZip("day", selectedDayTab), className: "px-3 py-2 rounded-md bg-[#0B3D91] text-white text-xs font-bold disabled:bg-slate-200 disabled:text-slate-400", children: [
          "Download Day ",
          selectedDayTab,
          " ZIP"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 485,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 483,
        columnNumber: 9
      }, this),
      selectedDayPhotos.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-20 text-center bg-white border border-slate-200 rounded-md text-sm text-slate-500", children: [
        "No photos are available for Day ",
        selectedDayTab,
        "."
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 489,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: selectedDayPhotos.map(
        (photo) => /* @__PURE__ */ jsxDEV("article", { className: "bg-white border border-slate-200 rounded-md p-4 shadow-xs", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-bold text-slate-900 truncate", children: photo.originalFilename }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 495,
                columnNumber: 44
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 mt-1", children: photo.caption || photo.sessionTitle }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 495,
                columnNumber: 131
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 495,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold px-2 py-1 rounded bg-blue-50 text-[#0B3D91]", children: [
              "Day ",
              photo.dayNumber
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 496,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 494,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500", children: [
            "Uploaded by ",
            photo.uploadedBy || "Cluster Admin"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 498,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 mt-3", children: [
            /* @__PURE__ */ jsxDEV("a", { href: photo.fileUrl, target: "_blank", rel: "noreferrer", className: "flex-1 text-center px-3 py-2 rounded-md bg-[#0B3D91] text-white text-xs font-bold", children: "View Photos" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 499,
              columnNumber: 50
            }, this),
            /* @__PURE__ */ jsxDEV("a", { href: photo.fileUrl, target: "_blank", rel: "noreferrer", download: true, className: "px-3 py-2 rounded-md bg-slate-100 text-slate-700 text-xs font-bold", children: "Download" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 499,
              columnNumber: 216
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 499,
            columnNumber: 17
          }, this)
        ] }, photo.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 493,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 491,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 470,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6 pb-16 font-sans", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Session Photographs & ZIP Archives" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 516,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-brand-50 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-brand-600 border border-brand-200 dark:bg-brand-950/40 dark:text-brand-400 dark:border-brand-800", children: selectedCluster }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 519,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 515,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 514,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5 self-start sm:self-auto", children: [
        activeRole === "Super Admin" && /* @__PURE__ */ jsxDEV(
          "button",
          {
            id: "download-all-clusters-zip-btn",
            disabled: downloadingZipKey !== null,
            onClick: () => handleDownloadZip("all-clusters"),
            className: `inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold shadow-theme-xs transition cursor-pointer ${downloadingZipKey === "all-clusters" ? "bg-gray-200 text-gray-500 cursor-not-allowed" : "bg-success-600 hover:bg-success-700 text-white active:scale-[0.98]"}`,
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: downloadingZipKey === "all-clusters" ? "sync" : "folder_zip" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 539,
                columnNumber: 15
              }, this),
              downloadingZipKey === "all-clusters" ? "Creating ZIP..." : completedZipKey === "all-clusters" ? "Download All Clusters Again" : "Download All Clusters (ZIP)"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 529,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            id: "download-all-8-days-zip-btn",
            disabled: downloadingZipKey !== null,
            onClick: () => handleDownloadZip("cluster-all-days"),
            className: `inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold shadow-theme-xs transition cursor-pointer ${downloadingZipKey === `cluster-${selectedCluster}` ? "bg-gray-200 text-gray-500 cursor-not-allowed" : "bg-brand-500 hover:bg-brand-600 text-white active:scale-[0.98]"}`,
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: downloadingZipKey === `cluster-${selectedCluster}` ? "sync" : "cloud_download" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 561,
                columnNumber: 13
              }, this),
              downloadingZipKey === `cluster-${selectedCluster}` ? "Creating ZIP..." : completedZipKey === `cluster-${selectedCluster}` ? `Download ${selectedCluster} Again` : `Download All 8 Days (${selectedCluster})`
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 551,
            columnNumber: 11
          },
          this
        ),
        activeRole !== "Super Admin" && /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowUploadModal(true),
            className: "inline-flex items-center gap-2 rounded-xl bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-3.5 py-2 text-xs font-semibold shadow-theme-xs hover:opacity-90 transition active:scale-[0.98] cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "add_photo_alternate" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 577,
                columnNumber: 15
              }, this),
              "Upload Photos"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 573,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 526,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 513,
      columnNumber: 7
    }, this),
    !showClusterLanding && zipProgress.stage !== "idle" && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `rounded-2xl p-4 border transition-all ${zipProgress.stage === "error" ? "bg-rose-50 border-rose-200 text-rose-900" : zipProgress.stage === "completed" ? "bg-emerald-50 border-emerald-200 text-emerald-900" : "bg-blue-50/90 border-blue-200 text-blue-950"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `material-symbols-outlined text-[24px] ${zipProgress.stage === "error" ? "text-rose-600" : zipProgress.stage === "completed" ? "text-emerald-600" : "text-brand-500 animate-spin"}`,
                  children: zipProgress.stage === "error" ? "error" : zipProgress.stage === "completed" ? "check_circle" : "progress_activity"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 599,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-sm", children: zipProgress.message }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 615,
                  columnNumber: 17
                }, this),
                zipProgress.zipFilename && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-600 mt-0.5", children: [
                  "Saved as ",
                  /* @__PURE__ */ jsxDEV("span", { className: "font-mono font-semibold", children: zipProgress.zipFilename }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 618,
                    columnNumber: 30
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 617,
                  columnNumber: 15
                }, this),
                zipProgress.errorMessage && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-rose-700 mt-0.5 font-medium", children: zipProgress.errorMessage }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 622,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 614,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 598,
              columnNumber: 13
            }, this),
            zipProgress.stage === "completed" && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-1 rounded-md", children: "Complete" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 630,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 597,
            columnNumber: 11
          }, this),
          zipProgress.stage !== "error" && zipProgress.stage !== "completed" && /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-blue-100/80 h-1.5 rounded-full overflow-hidden mt-3", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "bg-brand-500 h-full transition-all duration-300 rounded-full",
              style: { width: `${zipProgress.progressPercent}%` }
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 639,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 638,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 588,
        columnNumber: 7
      },
      this
    ),
    activeRole === "Super Admin" && /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-theme-xs dark:border-gray-800 dark:bg-gray-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold uppercase tracking-wider text-gray-400", children: "Super Admin Multi-Cluster View" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 654,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-gray-900 dark:text-white", children: "Select Cluster to Inspect or Download:" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 657,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 653,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: ["Dharmapuri", "Salem", "Krishnagiri"].map(
        (cName) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setSelectedCluster(cName),
            className: `px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${selectedCluster.toLowerCase() === cName.toLowerCase() ? "bg-brand-500 text-white shadow-theme-xs" : "bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200"}`,
            children: [
              cName,
              " Cluster"
            ]
          },
          cName,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 663,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 661,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 652,
      columnNumber: 7
    }, this),
    showClusterLanding && /* @__PURE__ */ jsxDEV("section", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Session Photos - Clusters" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 682,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 681,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", children: photoClusters.map((cluster) => {
        const clusterPhotos = photos.filter((photo) => photo.clusterId.toLowerCase() === cluster.id.toLowerCase());
        const days = new Set(clusterPhotos.map((photo) => photo.dayNumber)).size;
        return /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setSelectedCluster(cluster.id);
              setSelectedDayTab("all");
            },
            className: "text-left rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs hover:border-brand-500 hover:shadow-theme-sm transition-all dark:border-gray-800 dark:bg-white/[0.03]",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/40 text-brand-500 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined", children: "hub" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 696,
                  columnNumber: 140
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 696,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-brand-500", children: "View cluster" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 697,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 695,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "mt-5 text-base font-bold text-gray-900 dark:text-white", children: cluster.name }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 699,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-gray-100 dark:border-gray-800 text-xs", children: [
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { className: "block text-gray-900 dark:text-white", children: [
                    days,
                    "/8"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 701,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("em", { className: "not-italic text-gray-500", children: "Days" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 701,
                    columnNumber: 100
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 701,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { className: "block text-gray-900 dark:text-white", children: clusterPhotos.length }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 702,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("em", { className: "not-italic text-gray-500", children: "Photos" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 702,
                    columnNumber: 114
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 702,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  /* @__PURE__ */ jsxDEV("strong", { className: "block text-gray-900 dark:text-white", children: new Set(clusterPhotos.map((photo) => photo.panchayatId).filter(Boolean)).size }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 703,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("em", { className: "not-italic text-gray-500", children: "Panchayats" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 703,
                    columnNumber: 171
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 703,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 700,
                columnNumber: 19
              }, this)
            ]
          },
          cluster.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 689,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 684,
        columnNumber: 11
      }, this),
      photoClusters.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "py-14 text-center bg-white border border-gray-200 rounded-2xl text-sm text-gray-500", children: "No session photo clusters found in MySQL." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 709,
        columnNumber: 42
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 680,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: showClusterLanding ? "hidden" : "space-y-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900 dark:text-white", children: [
          "Daily Session Albums (",
          selectedCluster,
          ")"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 718,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-500 dark:text-gray-400", children: [
          "Total Photos: ",
          /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-900 dark:text-white", children: photos.length }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 722,
            columnNumber: 27
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 721,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 717,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4", children: daySummaries.map((daySummary) => {
        const isDayDownloading = downloadingZipKey === `day-${daySummary.dayNumber}`;
        const isDayCompleted = completedZipKey === `day-${daySummary.dayNumber}`;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-theme-xs hover:border-brand-500/40 transition-all flex flex-col justify-between dark:border-gray-800 dark:bg-white/[0.03]",
            children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2.5", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setExpandedDay(expandedDay === daySummary.dayNumber ? null : daySummary.dayNumber);
                          setSelectedDayTab(daySummary.dayNumber);
                        },
                        className: "font-bold text-sm text-gray-900 dark:text-white text-left hover:text-brand-500 transition-colors",
                        children: daySummary.dayLabel
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 740,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 font-medium", children: daySummary.date }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 747,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 739,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `text-[11px] font-semibold px-2 py-0.5 rounded-full ${daySummary.photosCount > 0 ? "bg-success-50 text-success-700 border border-success-200 dark:bg-success-950/40 dark:text-success-400" : "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"}`,
                      children: [
                        daySummary.photosCount,
                        " Photos"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 752,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 738,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-1.5 my-3", children: daySummary.featuredPhotos.length > 0 ? daySummary.featuredPhotos.map(
                  (p, pIdx) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      onClick: () => setSelectedPhoto(p),
                      className: "aspect-square rounded-lg overflow-hidden bg-gray-100 border border-gray-200 cursor-pointer hover:opacity-85 transition-opacity dark:border-gray-800",
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: p.fileUrl,
                          alt: p.originalFilename,
                          className: "w-full h-full object-cover",
                          referrerPolicy: "no-referrer"
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 772,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    p.id || pIdx,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 767,
                      columnNumber: 21
                    },
                    this
                  )
                ) : /* @__PURE__ */ jsxDEV("div", { className: "col-span-4 py-4 text-center text-xs text-gray-400 bg-gray-50 dark:bg-gray-900/50 rounded-xl border border-dashed border-gray-200 dark:border-gray-800", children: "No photos yet for this day" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 781,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 764,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-gray-500 dark:text-gray-400 mb-3 flex items-center justify-between font-medium", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Coverage: ",
                    daySummary.panchayatCoverage,
                    " Panchayats"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 788,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Target: ",
                    daySummary.targetCount
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 789,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 787,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 736,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pt-2.5 border-t border-gray-100 dark:border-gray-800 flex flex-col gap-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => {
                        setExpandedDay(daySummary.dayNumber);
                        setSelectedDayTab(daySummary.dayNumber);
                        const element = document.getElementById("gallery-section");
                        element?.scrollIntoView({ behavior: "smooth" });
                      },
                      className: "px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "grid_view" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 805,
                          columnNumber: 23
                        }, this),
                        "View"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 796,
                      columnNumber: 21
                    },
                    this
                  ),
                  activeRole !== "Super Admin" && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => handleOpenUploadForDay(daySummary.dayNumber),
                      className: "px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 transition cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "upload" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 814,
                          columnNumber: 25
                        }, this),
                        "Upload"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 810,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 795,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    id: `download-day-${daySummary.dayNumber}-zip-btn`,
                    disabled: downloadingZipKey !== null || daySummary.photosCount === 0,
                    onClick: () => handleDownloadZip("day", daySummary.dayNumber),
                    className: `w-full py-1.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-theme-xs transition-all cursor-pointer ${daySummary.photosCount === 0 ? "bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed" : isDayDownloading ? "bg-brand-100 text-brand-700 cursor-wait" : "bg-brand-500 hover:bg-brand-600 text-white active:scale-[0.98]"}`,
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: isDayDownloading ? "sync" : "folder_zip" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 833,
                        columnNumber: 21
                      }, this),
                      isDayDownloading ? "Creating ZIP..." : isDayCompleted ? "Download Again" : `Download Day ${daySummary.dayNumber} ZIP`
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 821,
                    columnNumber: 19
                  },
                  this
                ),
                expandedDay === daySummary.dayNumber && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-gray-100 dark:border-gray-800 space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold uppercase tracking-wide text-gray-400", children: [
                      "Day ",
                      daySummary.dayNumber,
                      " photo list"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 846,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setExpandedDay(null), className: "text-[11px] font-semibold text-gray-500 hover:text-gray-900 dark:hover:text-white", children: "Close" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 847,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 845,
                    columnNumber: 23
                  }, this),
                  daySummary.featuredPhotos.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl bg-gray-50 dark:bg-gray-900 border border-dashed border-gray-200 dark:border-gray-800 px-3 py-3 text-xs text-gray-500", children: "No photos or folders are available for this day." }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 850,
                    columnNumber: 21
                  }, this) : daySummary.featuredPhotos.map(
                    (photo) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-2 rounded-xl bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 px-2.5 py-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold text-gray-800 dark:text-gray-200 truncate", children: photo.originalFilename }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 854,
                          columnNumber: 54
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400 truncate", children: photo.caption || photo.sessionTitle }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 854,
                          columnNumber: 165
                        }, this)
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 854,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("a", { href: photo.fileUrl, target: "_blank", rel: "noreferrer", className: "shrink-0 px-2 py-1 rounded-lg bg-brand-500 text-white text-[10px] font-semibold", children: "View" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 855,
                        columnNumber: 29
                      }, this)
                    ] }, photo.id, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 853,
                      columnNumber: 21
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 844,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 794,
                columnNumber: 17
              }, this)
            ]
          },
          daySummary.dayNumber,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 732,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 726,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 716,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { id: "gallery-section", className: `${showClusterLanding ? "hidden " : ""}space-y-4 pt-2`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Photo Gallery" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 874,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 873,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 dark:text-gray-400 font-medium", children: [
            "Showing ",
            /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-900 dark:text-white", children: filteredPhotos.length }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 880,
              columnNumber: 23
            }, this),
            " photos"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 879,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              id: "download-filtered-zip-btn",
              disabled: downloadingZipKey !== null || filteredPhotos.length === 0,
              onClick: () => handleDownloadZip("filtered"),
              className: `px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-theme-xs transition-all cursor-pointer ${filteredPhotos.length === 0 ? "bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed" : downloadingZipKey === "filtered" ? "bg-gray-200 text-gray-600" : "bg-success-600 hover:bg-success-700 text-white"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: downloadingZipKey === "filtered" ? "sync" : "download" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 895,
                  columnNumber: 15
                }, this),
                downloadingZipKey === "filtered" ? "Creating ZIP..." : "Download Filtered ZIP"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 883,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 878,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 872,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 overflow-x-auto pb-1", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setSelectedDayTab("all"),
            className: `px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${selectedDayTab === "all" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
            children: [
              "All Days (",
              photos.length,
              ")"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 905,
            columnNumber: 11
          },
          this
        ),
        [1, 2, 3, 4, 5, 6, 7, 8].map((dNum) => {
          const count = photos.filter((p) => p.dayNumber === dNum).length;
          return /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setSelectedDayTab(dNum),
              className: `px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${selectedDayTab === dNum ? "bg-[#0B3D91] text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`,
              children: [
                "Day ",
                dNum,
                " (",
                count,
                ")"
              ]
            },
            dNum,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 918,
              columnNumber: 15
            },
            this
          );
        })
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 904,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold text-gray-500 uppercase mb-1", children: "Panchayat" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 936,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedPanchayat || "all",
              onValueChange: (val) => {
                setSelectedPanchayat(val);
                setSelectedVillage("all");
              },
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Panchayats" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 947,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 946,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Panchayats" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 950,
                    columnNumber: 17
                  }, this),
                  panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 952,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 949,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 939,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 935,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold text-gray-500 uppercase mb-1", children: "Village Center" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 961,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedVillage || "all",
              onValueChange: (val) => setSelectedVillage(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Villages" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 969,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 968,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Villages" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 972,
                    columnNumber: 17
                  }, this),
                  currentFilterVillages.map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 974,
                      columnNumber: 17
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 971,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 964,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 960,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-bold text-slate-500 uppercase mb-1", children: "Search by Topic, Village or Volunteer" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 983,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 987,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value),
                placeholder: "Search session title, volunteer name, file...",
                className: "w-full rounded-xl border border-gray-200 bg-white pl-9 pr-8 py-2 text-xs text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 988,
                columnNumber: 15
              },
              this
            ),
            searchQuery && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setSearchQuery(""),
                className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600",
                children: /* @__PURE__ */ jsxDEV(X, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1001,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 996,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 986,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 982,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 934,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 871,
      columnNumber: 7
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "py-20 text-center text-slate-500 bg-white rounded-md border border-slate-200", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[32px] animate-spin text-[#0B3D91]", children: "progress_activity" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1015,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold mt-2", children: "Loading high-resolution session photos..." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1018,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1014,
      columnNumber: 7
    }, this) : filteredPhotos.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "py-16 text-center bg-white rounded-md border border-slate-200 p-6", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[42px] text-slate-300 mb-2", children: "image_not_supported" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1022,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-slate-800 text-sm", children: "No Photographs Match Your Filter" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1025,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 mt-1 max-w-sm mx-auto", children: "Try adjusting your search criteria, selecting another Day or uploading new session photos." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1026,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => {
            setSelectedDayTab("all");
            setSelectedPanchayat("all");
            setSelectedVillage("all");
            setSearchQuery("");
          },
          className: "mt-3 px-3 py-1.5 text-xs font-bold text-[#0B3D91] bg-blue-50 rounded-md hover:bg-blue-100 transition-colors",
          children: "Reset Filters"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1029,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1021,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4", children: filteredPhotos.map(
      (photo) => /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "group bg-white rounded-md border border-slate-200 overflow-hidden shadow-xs hover:shadow-sm transition-all flex flex-col",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative aspect-[4/3] bg-slate-900 overflow-hidden cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: photo.fileUrl,
                  alt: photo.sessionTitle,
                  className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-300",
                  referrerPolicy: "no-referrer",
                  onClick: () => setSelectedPhoto(photo)
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1050,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70  text-white text-[10px] font-bold", children: [
                "Day ",
                photo.dayNumber
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1059,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-2 right-2 px-2 py-0.5 rounded bg-black/70  text-white text-[10px] font-mono", children: [
                Math.round((photo.fileSize || 5e4) / 1024),
                " KB"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1064,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0  from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3 text-white", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold leading-tight line-clamp-1", children: photo.sessionTitle }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1070,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-200 mt-0.5", children: [
                  photo.panchayatName,
                  " â€¢ ",
                  photo.villageName
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1071,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: (e) => {
                        e.stopPropagation();
                        setSelectedPhoto(photo);
                      },
                      className: "px-2 py-1 bg-white20 hover:bg-white30  rounded text-[11px] font-semibold flex items-center gap-1 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "visibility" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 1082,
                          columnNumber: 23
                        }, this),
                        "View"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1075,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: (e) => {
                        e.stopPropagation();
                        handleDownloadSinglePhoto(photo);
                      },
                      className: "px-2 py-1 bg-[#0B3D91] hover:bg-[#082a66] rounded text-[11px] font-semibold flex items-center gap-1 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "download" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 1092,
                          columnNumber: 23
                        }, this),
                        "Download"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1085,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1074,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1069,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1049,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-3 flex-1 flex flex-col justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-xs text-slate-900 line-clamp-1", children: photo.sessionTitle }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1102,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-slate-500 mt-0.5", children: [
                  photo.panchayatName,
                  " â€¢ ",
                  photo.villageName
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1105,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-400 mt-1 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "By ",
                    photo.uploadedBy
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1109,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: photo.date }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1110,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1108,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1101,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-2.5 border-t border-slate-100 grid grid-cols-3 gap-1 text-[11px] font-semibold", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setSelectedPhoto(photo),
                    className: "py-1 px-1.5 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded flex items-center justify-center gap-1 transition-colors cursor-pointer",
                    title: "View Full Resolution",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "visibility" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 1121,
                        columnNumber: 21
                      }, this),
                      "View"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1116,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleDownloadSinglePhoto(photo),
                    className: "py-1 px-1.5 text-[#0B3D91] bg-blue-50 hover:bg-blue-100 rounded flex items-center justify-center gap-1 transition-colors cursor-pointer",
                    title: "Download Original File",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "download" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 1130,
                        columnNumber: 21
                      }, this),
                      "Download"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1125,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setPhotoToDelete(photo),
                    className: "py-1 px-1.5 text-rose-700 bg-rose-50 hover:bg-rose-100 rounded flex items-center justify-center gap-1 transition-colors cursor-pointer",
                    title: "Delete Photo",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "delete" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 1139,
                        columnNumber: 21
                      }, this),
                      "Delete"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1134,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1115,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1100,
              columnNumber: 15
            }, this)
          ]
        },
        photo.id,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1044,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1042,
      columnNumber: 7
    }, this),
    selectedPhoto && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 bg-gray-950/90 backdrop-blur-sm z-[99999] flex items-center justify-center p-4",
        onClick: () => setSelectedPhoto(null),
        children: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "relative max-w-5xl w-full bg-slate-900 border border-slate-700 rounded-md overflow-hidden shadow-sm animate-[fadeIn_0.2s_ease-out] flex flex-col",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-slate-950/80 border-b border-slate-800 flex justify-between items-center text-white", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-0.5 bg-[#0B3D91] rounded text-[10px] font-bold", children: [
                      "Day ",
                      selectedPhoto.dayNumber
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1165,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-sm sm:text-base font-bold", children: selectedPhoto.sessionTitle }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1168,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1164,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400 mt-0.5", children: [
                    selectedPhoto.panchayatName,
                    " â€¢ ",
                    selectedPhoto.villageName,
                    " â€¢ ",
                    selectedPhoto.date
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1170,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1163,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => handleDownloadSinglePhoto(selectedPhoto),
                      className: "px-3 py-1.5 bg-[#0B3D91] hover:bg-[#082a66] text-white rounded-md text-xs font-bold flex items-center gap-1.5 cursor-pointer",
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "download" }, void 0, false, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                          lineNumber: 1180,
                          columnNumber: 19
                        }, this),
                        "Download Original"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1176,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setSelectedPhoto(null),
                      className: "p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 1187,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1183,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1175,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1162,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "max-h-[68vh] bg-black/90 flex items-center justify-center p-2", children: /* @__PURE__ */ jsxDEV(
                "img",
                {
                  src: selectedPhoto.fileUrl,
                  alt: selectedPhoto.sessionTitle,
                  className: "max-h-[65vh] w-auto max-w-full object-contain rounded",
                  referrerPolicy: "no-referrer"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1194,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1193,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-slate-950 border-t border-slate-800 text-xs text-slate-300 flex flex-wrap items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Uploaded by: ",
                    /* @__PURE__ */ jsxDEV("strong", { className: "text-white", children: selectedPhoto.uploadedBy }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1206,
                      columnNumber: 32
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1205,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Filename: ",
                    /* @__PURE__ */ jsxDEV("strong", { className: "text-white font-mono", children: selectedPhoto.originalFilename }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1209,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1208,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Size: ",
                    /* @__PURE__ */ jsxDEV("strong", { className: "text-white font-mono", children: [
                      Math.round((selectedPhoto.fileSize || 5e4) / 1024),
                      " KB"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1212,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1211,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1204,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => {
                      setPhotoToDelete(selectedPhoto);
                    },
                    className: "text-rose-400 hover:text-rose-300 font-semibold flex items-center gap-1 cursor-pointer",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "delete" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                        lineNumber: 1222,
                        columnNumber: 17
                      }, this),
                      "Delete Photo"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1216,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1203,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1157,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1153,
        columnNumber: 7
      },
      this
    ),
    showUploadModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md shadow-sm w-full max-w-xl overflow-hidden animate-[fadeIn_0.2s_ease-out]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-slate-200 bg-slate-50 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-slate-900", children: "Upload Session Photographs" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1238,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: "Upload original high-resolution camera images for session archiving." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1239,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1237,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowUploadModal(false),
            className: "p-1.5 text-slate-400 hover:text-slate-600 rounded-full",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1247,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1243,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1236,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleUploadSubmit, className: "p-6 space-y-4 text-xs", children: [
        uploadError && /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-rose-50 text-rose-800 border border-rose-200 rounded-md font-medium", children: uploadError }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1253,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Session Day *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1261,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: String(uploadDay),
                onValueChange: (val) => setUploadDay(parseInt(val, 10)),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs font-semibold bg-slate-50 border-slate-200", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Day" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1267,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1266,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [1, 2, 3, 4, 5, 6, 7, 8].map(
                    (d) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(d), children: [
                      "Day ",
                      d
                    ] }, d, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1271,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1269,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1262,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1260,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Session Title *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1280,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: uploadTitle,
                onChange: (e) => setUploadTitle(e.target.value),
                placeholder: "e.g. Spoken English Dialogue Workshop",
                className: "w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1281,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1279,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1259,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Panchayat *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1295,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: uploadPanchayat,
                onValueChange: (val) => setUploadPanchayat(val),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs bg-slate-50 border-slate-200", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1301,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1300,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                      lineNumber: 1305,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                    lineNumber: 1303,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1296,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1294,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Village Center *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1314,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: uploadVillage,
                onChange: (e) => setUploadVillage(e.target.value),
                className: "w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1315,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1313,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1293,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Date *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1328,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                required: true,
                value: uploadDate,
                onChange: (e) => setUploadDate(e.target.value),
                className: "w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1329,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1327,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Uploader Name *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1339,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                value: uploadUploader,
                onChange: (e) => setUploadUploader(e.target.value),
                className: "w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-[#0B3D91]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1340,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1338,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1326,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block font-bold text-slate-700 mb-1", children: "Select Photographs *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1352,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              id: "session-photo-file-input",
              type: "file",
              ref: fileInputRef,
              multiple: true,
              accept: "image/jpeg,image/png,image/webp",
              onChange: (e) => {
                if (e.target.files) {
                  setUploadFiles(Array.from(e.target.files));
                }
              },
              className: "hidden"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1353,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              htmlFor: "session-photo-file-input",
              className: "border-2 border-dashed border-slate-300 hover:border-[#0B3D91] rounded-md p-6 text-center cursor-pointer bg-slate-50 hover:bg-blue-50/40 transition-colors",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[32px] text-slate-400 mb-1", children: "cloud_upload" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1371,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-slate-800", children: "Click to choose image files" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1374,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-500 mt-0.5", children: "Supports JPG, PNG, WEBP high-resolution photos." }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1375,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1367,
              columnNumber: 17
            },
            this
          ),
          uploadFiles.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-2.5 space-y-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-700", children: [
              "Selected ",
              uploadFiles.length,
              " file(s):"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1382,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "max-h-24 overflow-y-auto space-y-1 bg-slate-50 p-2 rounded-md border border-slate-200", children: uploadFiles.map(
              (f, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[11px] text-slate-600", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "truncate max-w-[300px] font-mono", children: f.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1388,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-400", children: [
                  Math.round(f.size / 1024),
                  " KB"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1389,
                  columnNumber: 27
                }, this)
              ] }, i, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                lineNumber: 1387,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1385,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1381,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1351,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-slate-200 flex justify-end gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowUploadModal(false),
              className: "px-4 py-2 border border-slate-300 text-slate-700 rounded-md font-semibold hover:bg-slate-50",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1399,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isUploading || uploadFiles.length === 0,
              className: `px-5 py-2 rounded-md font-bold text-white transition-all shadow-xs flex items-center gap-2 ${isUploading || uploadFiles.length === 0 ? "bg-slate-400 cursor-not-allowed" : "bg-[#0B3D91] hover:bg-[#082a66]"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: isUploading ? "sync" : "upload" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
                  lineNumber: 1415,
                  columnNumber: 19
                }, this),
                isUploading ? "Uploading Photos..." : `Upload ${uploadFiles.length} Photos`
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
              lineNumber: 1406,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1398,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1251,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1235,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1234,
      columnNumber: 7
    }, this),
    photoToDelete && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md shadow-sm w-full max-w-sm p-5 text-center space-y-3", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[38px] text-rose-600", children: "warning" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1432,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-base text-slate-900", children: "Delete Photo?" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1435,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-600", children: [
        "Are you sure you want to permanently remove ",
        /* @__PURE__ */ jsxDEV("strong", { className: "text-slate-900", children: photoToDelete.originalFilename }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
          lineNumber: 1437,
          columnNumber: 59
        }, this),
        "? This action cannot be undone."
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1436,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-2 flex items-center justify-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setPhotoToDelete(null),
            className: "px-3.5 py-1.5 border border-slate-300 rounded-md text-xs font-semibold text-slate-700 hover:bg-slate-50",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1440,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleDeletePhoto(photoToDelete),
            className: "px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-xs font-bold shadow-xs",
            children: "Confirm Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
            lineNumber: 1446,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
        lineNumber: 1439,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1431,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
      lineNumber: 1430,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx",
    lineNumber: 509,
    columnNumber: 5
  }, this);
};
_s(SessionPhotosView, "7K0+18K++vyhFJo8g5z7Nh3PUXA=");
_c = SessionPhotosView;
var _c;
$RefreshReg$(_c, "SessionPhotosView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionPhotosView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeWRjOztBQXpkZCxTQUFnQkEsVUFBVUMsV0FBV0MsU0FBU0MsY0FBYztBQVU1RCxTQUFTQyxjQUFjO0FBQ3ZCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFFBQVFDLFNBQVM7QUFhbkIsYUFBTUMsb0JBQXNEQSxDQUFDO0FBQUEsRUFDbEVDLGFBQWE7QUFBQSxFQUNiQyxXQUFXO0FBQUEsRUFDWEM7QUFBQUEsRUFDQUMsV0FBVztBQUFBLEVBQ1hDLGlCQUFpQjtBQUFBLEVBQ2pCQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUVKLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJdEIsU0FBMENnQixRQUFRO0FBQ3RGLFFBQU0sQ0FBQ08saUJBQWlCQyxrQkFBa0IsSUFBSXhCO0FBQUFBLElBQzVDZ0IsYUFBYSxrQkFBa0IsZUFBZTtBQUFBLEVBQ2hEO0FBQ0EsUUFBTSxDQUFDUyxnQkFBZ0JDLGlCQUFpQixJQUFJMUIsU0FBeUIsS0FBSztBQUMxRSxRQUFNLENBQUMyQixhQUFhQyxjQUFjLElBQUk1QixTQUF3QixJQUFJO0FBQ2xFLFFBQU0sQ0FBQzZCLG1CQUFtQkMsb0JBQW9CLElBQUk5QixTQUFpQixLQUFLO0FBQ3hFLFFBQU0sQ0FBQytCLGlCQUFpQkMsa0JBQWtCLElBQUloQyxTQUFpQixLQUFLO0FBQ3BFLFFBQU0sQ0FBQ2lDLGFBQWFDLGNBQWMsSUFBSWxDLFNBQWlCLEVBQUU7QUFHekQsUUFBTSxDQUFDbUMsUUFBUUMsU0FBUyxJQUFJcEMsU0FBNkIsRUFBRTtBQUMzRCxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFrQixJQUFJO0FBQ3hELFFBQU0sQ0FBQ3VDLFdBQVdDLFlBQVksSUFBSXhDLFNBQXdCLElBQUk7QUFHOUQsUUFBTSxDQUFDeUMsZUFBZUMsZ0JBQWdCLElBQUkxQyxTQUFrQyxJQUFJO0FBQ2hGLFFBQU0sQ0FBQzJDLGlCQUFpQkMsa0JBQWtCLElBQUk1QyxTQUFrQixLQUFLO0FBQ3JFLFFBQU0sQ0FBQzZDLGlCQUFpQkMsa0JBQWtCLElBQUk5QyxTQUFpQixDQUFDO0FBQ2hFLFFBQU0sQ0FBQytDLGNBQWNDLGVBQWUsSUFBSWhELFNBQXdCLElBQUk7QUFDcEUsUUFBTSxDQUFDaUQsZUFBZUMsZ0JBQWdCLElBQUlsRCxTQUFrQyxJQUFJO0FBR2hGLFFBQU0sQ0FBQ21ELG1CQUFtQkMsb0JBQW9CLElBQUlwRCxTQUF3QixJQUFJO0FBQzlFLFFBQU0sQ0FBQ3FELGlCQUFpQkMsa0JBQWtCLElBQUl0RCxTQUF3QixJQUFJO0FBQzFFLFFBQU0sQ0FBQ3VELGFBQWFDLGNBQWMsSUFBSXhELFNBQTJCO0FBQUEsSUFDL0R5RCxPQUFPO0FBQUEsSUFDUEMsU0FBUztBQUFBLElBQ1RDLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFHRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSTdELFNBQWlCLEVBQUU7QUFDekQsUUFBTSxDQUFDOEQsYUFBYUMsY0FBYyxJQUFJL0QsU0FBaUIsK0JBQStCO0FBQ3RGLFFBQU0sQ0FBQ2dFLFdBQVdDLFlBQVksSUFBSWpFLFNBQWlCLENBQUM7QUFDcEQsUUFBTSxDQUFDa0UsaUJBQWlCQyxrQkFBa0IsSUFBSW5FLFNBQWlCYSxXQUFXLENBQUMsR0FBR3VELE1BQU0sa0JBQWtCO0FBQ3RHLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUl0RSxTQUFpQixZQUFZO0FBQ3ZFLFFBQU0sQ0FBQ3VFLFlBQVlDLGFBQWEsSUFBSXhFLFVBQWlCLG9CQUFJeUUsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUMzRixRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUk3RSxTQUFpQixVQUFVO0FBQ3ZFLFFBQU0sQ0FBQzhFLGVBQWVDLGdCQUFnQixJQUFJL0UsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNnRixhQUFhQyxjQUFjLElBQUlqRixTQUFrQixLQUFLO0FBQzdELFFBQU0sQ0FBQ2tGLGFBQWFDLGNBQWMsSUFBSW5GLFNBQXdCLElBQUk7QUFDbEUsUUFBTW9GLGVBQWVqRixPQUF5QixJQUFJO0FBQ2xELFFBQU1rRixxQkFBcUJoRSxlQUFlLGlCQUFpQkUsb0JBQW9CO0FBQy9FLFFBQU0rRCxnQkFBZ0JwRixRQUFRLE1BQU07QUFDbEMsVUFBTXFGLFFBQVF6RSxTQUFTMEUsSUFBSSxDQUFDQyxhQUFhLEVBQUVyQixJQUFJcUIsUUFBUXJCLElBQUlzQixNQUFNRCxRQUFRQyxLQUFLLEVBQUU7QUFDaEYsVUFBTUMsV0FBVyxJQUFJQyxJQUFJTCxNQUFNQyxJQUFJLENBQUNDLFlBQVlBLFFBQVFyQixHQUFHeUIsWUFBWSxDQUFDLENBQUM7QUFDekUxRCxXQUFPMkQsUUFBUSxDQUFDQyxVQUFVO0FBQ3hCLFVBQUksQ0FBQ0osU0FBU0ssSUFBSUQsTUFBTUUsVUFBVUosWUFBWSxDQUFDLEdBQUc7QUFDaEROLGNBQU1XLEtBQUssRUFBRTlCLElBQUkyQixNQUFNRSxXQUFXUCxNQUFNSyxNQUFNSSxlQUFlSixNQUFNRSxVQUFVLENBQUM7QUFDOUVOLGlCQUFTUyxJQUFJTCxNQUFNRSxVQUFVSixZQUFZLENBQUM7QUFBQSxNQUM1QztBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9OO0FBQUFBLEVBQ1QsR0FBRyxDQUFDekUsVUFBVXFCLE1BQU0sQ0FBQztBQUdyQmxDLFlBQVUsTUFBTTtBQUNkcUIsa0JBQWNOLFFBQVE7QUFDdEIsUUFBSUEsYUFBYSxpQkFBaUI7QUFDaENRLHlCQUFtQixZQUFZO0FBQUEsSUFDakMsT0FBTztBQUNMQSx5QkFBbUIsS0FBSztBQUFBLElBQzFCO0FBQUEsRUFDRixHQUFHLENBQUNSLFFBQVEsQ0FBQztBQUdiLFFBQU1xRixjQUFjLFlBQVk7QUFDOUIvRCxpQkFBYSxJQUFJO0FBQ2pCRSxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNOEQsZUFBZWpGLGVBQWUsa0JBQWtCLGVBQWVFLGdCQUFnQnNFLFlBQVk7QUFDakcsWUFBTVUsTUFBTSxNQUFNQyxNQUFNcEcsT0FBTywrQkFBK0JrRyxZQUFZLFNBQVNHLG1CQUFtQnBGLFVBQVUsQ0FBQyxFQUFFLEdBQUc7QUFBQSxRQUNwSHFGLE9BQU87QUFBQSxRQUNQQyxTQUFTNUYsWUFBWSxFQUFFNkYsZUFBZSxVQUFVN0YsU0FBUyxHQUFHLElBQUksQ0FBQztBQUFBLE1BQ25FLENBQUM7QUFDRCxVQUFJLENBQUN3RixJQUFJTSxJQUFJO0FBQ1gsY0FBTSxJQUFJQyxNQUFNLG1CQUFtQlAsSUFBSVEsTUFBTSxFQUFFO0FBQUEsTUFDakQ7QUFDQSxZQUFNQyxPQUFPLE1BQU1ULElBQUlVLEtBQUs7QUFFNUIsVUFBSUQsS0FBS0UsV0FBV0MsTUFBTUMsUUFBUUosS0FBSzdFLE1BQU0sR0FBRztBQUM5Q0Msa0JBQVU0RSxLQUFLN0UsTUFBTTtBQUFBLE1BQ3ZCLE9BQU87QUFDTEMsa0JBQVUsRUFBRTtBQUFBLE1BQ2Q7QUFBQSxJQUNGLFNBQVNpRixLQUFVO0FBQ2pCQyxjQUFRQyxNQUFNLDBCQUEwQkYsR0FBRztBQUMzQzdFLG1CQUFhLDZEQUE2RDtBQUFBLElBQzVFLFVBQUM7QUFDQ0YsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBckMsWUFBVSxNQUFNO0FBQ2RvRyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDaEYsWUFBWUUsaUJBQWlCUixTQUFTLENBQUM7QUFHM0MsUUFBTXlHLHdCQUF3QnRILFFBQVEsTUFBTTtBQUMxQyxRQUFJMkIsc0JBQXNCLE9BQU87QUFDL0IsWUFBTTRGLGNBQThDO0FBQ3BENUcsaUJBQVdpRixRQUFRLENBQUM0QixNQUFNO0FBQ3hCQSxVQUFFQyxVQUFVN0IsUUFBUSxDQUFDOEIsTUFBTTtBQUN6QixjQUFJLENBQUNILFlBQVlJLEtBQUssQ0FBQ0MsYUFBYUEsU0FBU3BDLFNBQVNrQyxFQUFFbEMsSUFBSSxHQUFHO0FBQzdEK0Isd0JBQVl2QixLQUFLLEVBQUU5QixJQUFJd0QsRUFBRXhELElBQUlzQixNQUFNa0MsRUFBRWxDLEtBQUssQ0FBQztBQUFBLFVBQzdDO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQ0QsYUFBTytCO0FBQUFBLElBQ1Q7QUFDQSxVQUFNTSxRQUFRbEgsV0FBV21ILEtBQUssQ0FBQ04sTUFBTUEsRUFBRXRELE9BQU92QyxxQkFBcUI2RixFQUFFaEMsU0FBUzdELGlCQUFpQjtBQUMvRixXQUFPa0csT0FBT0osWUFBWTtBQUFBLEVBQzVCLEdBQUcsQ0FBQzlGLG1CQUFtQmhCLFVBQVUsQ0FBQztBQUdsQ1osWUFBVSxNQUFNO0FBQ2QsVUFBTWdJLFlBQVlwSCxXQUFXbUgsS0FBSyxDQUFDTixNQUFNQSxFQUFFdEQsT0FBT0YsbUJBQW1Cd0QsRUFBRWhDLFNBQVN4QixlQUFlO0FBQy9GLFFBQUkrRCxhQUFhQSxVQUFVTixZQUFZTSxVQUFVTixTQUFTTyxTQUFTLEdBQUc7QUFDcEU1RCx1QkFBaUIyRCxVQUFVTixTQUFTLENBQUMsRUFBRWpDLElBQUk7QUFBQSxJQUM3QztBQUFBLEVBQ0YsR0FBRyxDQUFDeEIsaUJBQWlCckQsVUFBVSxDQUFDO0FBR2hDLFFBQU1zSCxlQUFrQ2pJLFFBQVEsTUFBTTtBQUNwRCxVQUFNa0ksc0JBQXNCakcsT0FBT2tHO0FBQUFBLE1BQ2pDLENBQUNYLE1BQ0NyRyxlQUFlLG1CQUNmRSxvQkFBb0IsU0FDcEJtRyxFQUFFekIsVUFBVUosWUFBWSxNQUFNdEUsZ0JBQWdCc0UsWUFBWTtBQUFBLElBQzlEO0FBRUEsVUFBTXlDLFlBQStCO0FBRXJDLGFBQVNDLE1BQU0sR0FBR0EsT0FBTyxHQUFHQSxPQUFPO0FBQ2pDLFlBQU1DLFlBQVlKLG9CQUFvQkMsT0FBTyxDQUFDWCxNQUFNQSxFQUFFZSxjQUFjRixHQUFHO0FBQ3ZFLFlBQU1HLG1CQUFtQixJQUFJOUMsSUFBSTRDLFVBQVVoRCxJQUFJLENBQUNrQyxNQUFNQSxFQUFFaUIsV0FBVyxDQUFDLEVBQUVDO0FBQ3RFLFlBQU1DLGNBQWM7QUFFcEJQLGdCQUFVcEMsS0FBSztBQUFBLFFBQ2J1QyxXQUFXRjtBQUFBQSxRQUNYTyxVQUFVLE9BQU9QLEdBQUc7QUFBQSxRQUNwQlEsTUFBTSxXQUFXLEtBQUtSLEdBQUc7QUFBQSxRQUN6QlMsYUFBYVIsVUFBVU47QUFBQUEsUUFDdkJXO0FBQUFBLFFBQ0FJLG1CQUFtQlA7QUFBQUEsUUFDbkJRLGdCQUFnQlYsVUFBVVcsTUFBTSxHQUFHLENBQUM7QUFBQSxNQUN0QyxDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU9iO0FBQUFBLEVBQ1QsR0FBRyxDQUFDbkcsUUFBUVosaUJBQWlCRixVQUFVLENBQUM7QUFHeEMsUUFBTStILGlCQUFpQmxKLFFBQVEsTUFBTTtBQUNuQyxXQUFPaUMsT0FBT2tHLE9BQU8sQ0FBQ1gsTUFBTTtBQUUxQixZQUFNMkIsZUFDSmhJLGVBQWUsa0JBQ1hxRyxFQUFFekIsVUFBVUosWUFBWSxNQUFNLGVBQzlCdEUsb0JBQW9CLFNBQVNtRyxFQUFFekIsVUFBVUosWUFBWSxNQUFNdEUsZ0JBQWdCc0UsWUFBWTtBQUc3RixZQUFNeUQsV0FBVzdILG1CQUFtQixTQUFTaUcsRUFBRWUsY0FBY2hIO0FBRzdELFlBQU04SCxpQkFDSjFILHNCQUFzQixTQUN0QjZGLEVBQUVpQixZQUFZOUMsWUFBWSxNQUFNaEUsa0JBQWtCZ0UsWUFBWSxLQUM5RDZCLEVBQUU4QixjQUFjM0QsWUFBWSxNQUFNaEUsa0JBQWtCZ0UsWUFBWTtBQUdsRSxZQUFNNEQsZUFDSjFILG9CQUFvQixVQUNuQjJGLEVBQUVnQyxlQUFlLElBQUk3RCxZQUFZLE1BQU05RCxnQkFBZ0I4RCxZQUFZO0FBR3RFLFlBQU04RCxJQUFJMUgsWUFBWTRELFlBQVksRUFBRStELEtBQUs7QUFDekMsWUFBTUMsY0FDSixDQUFDRixLQUNEakMsRUFBRW9DLGFBQWFqRSxZQUFZLEVBQUVrRSxTQUFTSixDQUFDLEtBQ3ZDakMsRUFBRThCLGNBQWMzRCxZQUFZLEVBQUVrRSxTQUFTSixDQUFDLEtBQ3hDakMsRUFBRWdDLFlBQVk3RCxZQUFZLEVBQUVrRSxTQUFTSixDQUFDLEtBQ3RDakMsRUFBRXNDLFdBQVduRSxZQUFZLEVBQUVrRSxTQUFTSixDQUFDLEtBQ3JDakMsRUFBRXVDLGlCQUFpQnBFLFlBQVksRUFBRWtFLFNBQVNKLENBQUM7QUFFN0MsYUFBT04sZ0JBQWdCQyxZQUFZQyxrQkFBa0JFLGdCQUFnQkk7QUFBQUEsSUFDdkUsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDMUgsUUFBUVosaUJBQWlCRixZQUFZSSxnQkFBZ0JJLG1CQUFtQkUsaUJBQWlCRSxXQUFXLENBQUM7QUFLekcsUUFBTWlJLG9CQUFvQixPQUN4QkMsTUFDQTFCLGNBQ0c7QUFFSCxVQUFNMkIsTUFDSkQsU0FBUyxRQUNMLE9BQU8xQixTQUFTLEtBQ2hCMEIsU0FBUyxxQkFDVCxXQUFXNUksZUFBZSxLQUMxQjRJLFNBQVMsaUJBQ1QsaUJBQ0E7QUFFTixRQUFJaEgsbUJBQW1CO0FBQ3JCbUUsY0FBUStDLEtBQUssOENBQThDO0FBQzNEO0FBQUEsSUFDRjtBQUVBakgseUJBQXFCZ0gsR0FBRztBQUN4QjlHLHVCQUFtQixJQUFJO0FBR3ZCRSxtQkFBZTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsaUJBQWlCO0FBQUEsSUFDbkIsQ0FBQztBQUVELFFBQUk7QUFDRixZQUFNLElBQUkyRyxRQUFRLENBQUNDLE1BQU1DLFdBQVdELEdBQUcsR0FBRyxDQUFDO0FBRTNDL0cscUJBQWU7QUFBQSxRQUNiQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLGlCQUFpQjtBQUFBLE1BQ25CLENBQUM7QUFFRCxZQUFNLElBQUkyRyxRQUFRLENBQUNDLE1BQU1DLFdBQVdELEdBQUcsR0FBRyxDQUFDO0FBRTNDL0cscUJBQWU7QUFBQSxRQUNiQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLGlCQUFpQjtBQUFBLE1BQ25CLENBQUM7QUFHRCxZQUFNOEcsU0FBUyxJQUFJQyxnQkFBZ0I7QUFDbkNELGFBQU9FLE9BQU8sUUFBUVIsSUFBSTtBQUMxQk0sYUFBT0U7QUFBQUEsUUFDTDtBQUFBLFFBQ0F0SixlQUFlLGtCQUFrQixlQUFlRTtBQUFBQSxNQUNsRDtBQUNBa0osYUFBT0UsT0FBTyxZQUFZdEosVUFBVTtBQUVwQyxVQUFJOEksU0FBUyxTQUFTMUIsV0FBVztBQUMvQmdDLGVBQU9FLE9BQU8sYUFBYUMsT0FBT25DLFNBQVMsQ0FBQztBQUFBLE1BQzlDLFdBQVcwQixTQUFTLFlBQVk7QUFDOUIsWUFBSTFJLG1CQUFtQixNQUFPZ0osUUFBT0UsT0FBTyxhQUFhQyxPQUFPbkosY0FBYyxDQUFDO0FBQy9FLFlBQUlJLHNCQUFzQixNQUFPNEksUUFBT0UsT0FBTyxlQUFlOUksaUJBQWlCO0FBQy9FLFlBQUlFLG9CQUFvQixNQUFPMEksUUFBT0UsT0FBTyxXQUFXNUksZUFBZTtBQUFBLE1BQ3pFO0FBRUEsWUFBTThJLFNBQVN6SyxPQUFPLG9DQUFvQ3FLLE9BQU9LLFNBQVMsQ0FBQyxFQUFFO0FBRTdFdEgscUJBQWU7QUFBQSxRQUNiQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLGlCQUFpQjtBQUFBLE1BQ25CLENBQUM7QUFHRCxZQUFNb0gsV0FBVyxNQUFNdkUsTUFBTXFFLE1BQU07QUFDbkMsVUFBSSxDQUFDRSxTQUFTbEUsSUFBSTtBQUNoQixjQUFNbUUsWUFBWSxNQUFNRCxTQUFTOUQsS0FBSyxFQUFFZ0UsTUFBTSxPQUFPLENBQUMsRUFBRTtBQUN4RCxjQUFNLElBQUluRTtBQUFBQSxVQUNSa0UsVUFBVXpELFNBQVM7QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFHQSxVQUFJMkQsbUJBQW1CO0FBQ3ZCLFlBQU1DLGNBQWNKLFNBQVNwRSxRQUFReUUsSUFBSSxxQkFBcUI7QUFDOUQsVUFBSUQsZUFBZUEsWUFBWXBCLFNBQVMsV0FBVyxHQUFHO0FBQ3BELGNBQU1zQixRQUFRRixZQUFZRSxNQUFNLHNCQUFzQjtBQUN0RCxZQUFJQSxTQUFTQSxNQUFNLENBQUMsR0FBRztBQUNyQkgsNkJBQW1CRyxNQUFNLENBQUM7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNQyxPQUFPLE1BQU1QLFNBQVNPLEtBQUs7QUFDakMsWUFBTUMsVUFBVUMsT0FBT0MsSUFBSUMsZ0JBQWdCSixJQUFJO0FBQy9DLFlBQU1LLE9BQU9DLFNBQVNDLGNBQWMsR0FBRztBQUN2Q0YsV0FBS0csT0FBT1A7QUFDWkksV0FBS0ksV0FBV2I7QUFDaEJVLGVBQVNJLEtBQUtDLFlBQVlOLElBQUk7QUFDOUJBLFdBQUtPLE1BQU07QUFDWE4sZUFBU0ksS0FBS0csWUFBWVIsSUFBSTtBQUM5QkgsYUFBT0MsSUFBSVcsZ0JBQWdCYixPQUFPO0FBR2xDL0gscUJBQWU7QUFBQSxRQUNiQyxPQUFPO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLGlCQUFpQjtBQUFBLFFBQ2pCMEksYUFBYW5CO0FBQUFBLE1BQ2YsQ0FBQztBQUNENUgseUJBQW1COEcsR0FBRztBQUd0QkksaUJBQVcsTUFBTTtBQUNmaEgsdUJBQWU7QUFBQSxVQUNiQyxPQUFPO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLGlCQUFpQjtBQUFBLFFBQ25CLENBQUM7QUFBQSxNQUNILEdBQUcsR0FBSTtBQUFBLElBQ1QsU0FBUzBELEtBQVU7QUFDakJDLGNBQVFDLE1BQU0sd0JBQXdCRixHQUFHO0FBQ3pDN0QscUJBQWU7QUFBQSxRQUNiQyxPQUFPO0FBQUEsUUFDUEMsU0FBUzJELElBQUkzRCxXQUFXO0FBQUEsUUFDeEJDLGlCQUFpQjtBQUFBLFFBQ2pCMkksY0FBY2pGLElBQUkzRCxXQUFXO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDTiwyQkFBcUIsSUFBSTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUtBLFFBQU1tSiw0QkFBNEJBLENBQUN4RyxVQUE0QjtBQUM3RCxVQUFNeUcsY0FBY3BNLE9BQU8sdUJBQXVCMkYsTUFBTTNCLEVBQUUsV0FBVztBQUNyRSxVQUFNdUgsT0FBT0MsU0FBU0MsY0FBYyxHQUFHO0FBQ3ZDRixTQUFLRyxPQUFPVTtBQUNaYixTQUFLSSxXQUFXaEcsTUFBTWtFLG9CQUFvQixTQUFTbEUsTUFBTTNCLEVBQUU7QUFDM0R3SCxhQUFTSSxLQUFLQyxZQUFZTixJQUFJO0FBQzlCQSxTQUFLTyxNQUFNO0FBQ1hOLGFBQVNJLEtBQUtHLFlBQVlSLElBQUk7QUFBQSxFQUNoQztBQUVBLFFBQU1jLG9CQUFvQixPQUFPMUcsVUFBNEI7QUFDM0QsUUFBSTtBQUNGLFlBQU1RLE1BQU0sTUFBTUMsTUFBTXBHLE9BQU8sdUJBQXVCMkYsTUFBTTNCLEVBQUUsRUFBRSxHQUFHO0FBQUEsUUFDakVzSSxRQUFRO0FBQUEsUUFDUi9GLFNBQVM1RixZQUFZLEVBQUU2RixlQUFlLFVBQVU3RixTQUFTLEdBQUcsSUFBSSxDQUFDO0FBQUEsTUFDbkUsQ0FBQztBQUNELFVBQUksQ0FBQ3dGLElBQUlNLElBQUk7QUFDWCxjQUFNLElBQUlDLE1BQU0seUJBQXlCO0FBQUEsTUFDM0M7QUFDQTFFLGdCQUFVLENBQUN1SyxTQUFTQSxLQUFLdEUsT0FBTyxDQUFDWCxNQUFNQSxFQUFFdEQsT0FBTzJCLE1BQU0zQixFQUFFLENBQUM7QUFDekRsQix1QkFBaUIsSUFBSTtBQUNyQixVQUFJVCxpQkFBaUJBLGNBQWMyQixPQUFPMkIsTUFBTTNCLElBQUk7QUFDbEQxQix5QkFBaUIsSUFBSTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRixTQUFTMkUsS0FBSztBQUNadUYsWUFBTSwyQ0FBMkM7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFLQSxRQUFNQyxxQkFBcUIsT0FBT0MsTUFBdUI7QUFDdkRBLE1BQUVDLGVBQWU7QUFDakIsUUFBSW5KLFlBQVlzRSxXQUFXLEdBQUc7QUFDNUIvQyxxQkFBZSxrREFBa0Q7QUFDakU7QUFBQSxJQUNGO0FBRUFGLG1CQUFlLElBQUk7QUFDbkJFLG1CQUFlLElBQUk7QUFFbkIsVUFBTTZILFdBQVcsSUFBSUMsU0FBUztBQUM5QkQsYUFBU3JDLE9BQU8sYUFBYXBKLGdCQUFnQnNFLFlBQVksQ0FBQztBQUMxRG1ILGFBQVNyQyxPQUFPLGVBQWVwSixlQUFlO0FBQzlDeUwsYUFBU3JDLE9BQU8sZ0JBQWdCN0csV0FBVztBQUMzQ2tKLGFBQVNyQyxPQUFPLGFBQWFDLE9BQU81RyxTQUFTLENBQUM7QUFDOUNnSixhQUFTckMsT0FBTyxRQUFRcEcsVUFBVTtBQUNsQ3lJLGFBQVNyQyxPQUFPLGVBQWV6RyxlQUFlO0FBRTlDLFVBQU1nSixTQUFTck0sV0FBV21ILEtBQUssQ0FBQ04sTUFBTUEsRUFBRXRELE9BQU9GLG1CQUFtQndELEVBQUVoQyxTQUFTeEIsZUFBZTtBQUM1RjhJLGFBQVNyQyxPQUFPLGlCQUFpQnVDLFNBQVNBLE9BQU94SCxPQUFPeEIsZUFBZTtBQUN2RThJLGFBQVNyQyxPQUFPLGVBQWV0RyxhQUFhO0FBQzVDMkksYUFBU3JDLE9BQU8sY0FBYy9GLGNBQWM7QUFDNUNvSSxhQUFTckMsT0FBTyxnQkFBZ0J0SixVQUFVO0FBQzFDMkwsYUFBU3JDLE9BQU8sV0FBVzdGLGFBQWE7QUFFeENsQixnQkFBWWtDLFFBQVEsQ0FBQ3FILFNBQVM7QUFDNUJILGVBQVNyQyxPQUFPLFVBQVV3QyxJQUFJO0FBQUEsSUFDaEMsQ0FBQztBQUVELFFBQUk7QUFDRixZQUFNNUcsTUFBTSxNQUFNQyxNQUFNcEcsT0FBTyw0QkFBNEIsR0FBRztBQUFBLFFBQzVEc00sUUFBUTtBQUFBLFFBQ1IvRixTQUFTNUYsWUFBWSxFQUFFNkYsZUFBZSxVQUFVN0YsU0FBUyxHQUFHLElBQUksQ0FBQztBQUFBLFFBQ2pFaUwsTUFBTWdCO0FBQUFBLE1BQ1IsQ0FBQztBQUVELFlBQU1oRyxPQUFPLE1BQU1ULElBQUlVLEtBQUs7QUFDNUIsVUFBSSxDQUFDVixJQUFJTSxNQUFNLENBQUNHLEtBQUtFLFNBQVM7QUFDNUIsY0FBTSxJQUFJSixNQUFNRSxLQUFLTyxTQUFTLGdCQUFnQjtBQUFBLE1BQ2hEO0FBSUEsVUFBSVAsS0FBSzdFLFVBQVVnRixNQUFNQyxRQUFRSixLQUFLN0UsTUFBTSxHQUFHO0FBQzdDQyxrQkFBVSxDQUFDdUssU0FBUyxDQUFDLEdBQUczRixLQUFLN0UsUUFBUSxHQUFHd0ssSUFBSSxDQUFDO0FBQUEsTUFDL0M7QUFFQS9KLHlCQUFtQixLQUFLO0FBQ3hCaUIscUJBQWUsRUFBRTtBQUNqQmtCLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsU0FBU3NDLEtBQVU7QUFDakJDLGNBQVFDLE1BQU0sa0JBQWtCRixHQUFHO0FBQ25DbEMscUJBQWVrQyxJQUFJM0QsV0FBVywrQkFBK0I7QUFBQSxJQUMvRCxVQUFDO0FBQ0N1QixxQkFBZSxLQUFLO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBR0EsUUFBTW1JLHlCQUF5QkEsQ0FBQzdFLFFBQWdCO0FBQzlDdEUsaUJBQWFzRSxHQUFHO0FBQ2hCM0YsdUJBQW1CLElBQUk7QUFBQSxFQUN6QjtBQUVBLE1BQUl2QixlQUFlLGlCQUFpQkUsb0JBQW9CLFNBQVNFLG1CQUFtQixPQUFPO0FBQ3pGLFVBQU00TCxvQkFBb0JsTCxPQUFPa0c7QUFBQUEsTUFDL0IsQ0FBQ3RDLFVBQVVBLE1BQU1FLFVBQVVKLFlBQVksTUFBTXRFLGdCQUFnQnNFLFlBQVksS0FBS0UsTUFBTTBDLGNBQWNoSDtBQUFBQSxJQUNwRztBQUVBLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLG1DQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUQsbUJBQW1CLEtBQUssR0FBRyxXQUFVLHdCQUF1Qiw4QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0c7QUFBQSxZQUMvRyx1QkFBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQU87QUFBQSxZQUFPLHVCQUFDLFVBQU1ELDZCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVCO0FBQUEsWUFBTyx1QkFBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQU87QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBVSxnQ0FBK0I7QUFBQTtBQUFBLGNBQUtFO0FBQUFBLGlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRi9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSxxQ0FBcUNGO0FBQUFBO0FBQUFBLFlBQWdCO0FBQUEsWUFBUUU7QUFBQUEsWUFBZTtBQUFBLGVBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlHO0FBQUEsVUFDakcsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixxRUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxhQU5sRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTtBQUFFQyw0QkFBa0IsS0FBSztBQUFHRSx5QkFBZSxJQUFJO0FBQUEsUUFBRyxHQUFHLFdBQVUseUZBQXdGLDRCQUE1TDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdNO0FBQUEsV0FUMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSwrQkFBQyxVQUFNeUw7QUFBQUEsNEJBQWtCbkY7QUFBQUEsVUFBTztBQUFBLGFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxZQUFPLE1BQUssVUFBUyxVQUFVLENBQUNtRixrQkFBa0JuRixRQUFRLFNBQVMsTUFBTWdDLGtCQUFrQixPQUFPekksY0FBYyxHQUFHLFdBQVUsZ0hBQStHO0FBQUE7QUFBQSxVQUFjQTtBQUFBQSxVQUFlO0FBQUEsYUFBMVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4UTtBQUFBLFdBRmhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUM0TCxrQkFBa0JuRixXQUFXLElBQzVCLHVCQUFDLFNBQUksV0FBVSx3RkFBdUY7QUFBQTtBQUFBLFFBQWlDekc7QUFBQUEsUUFBZTtBQUFBLFdBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUosSUFFdkosdUJBQUMsU0FBSSxXQUFVLHdEQUNaNEwsNEJBQWtCN0g7QUFBQUEsUUFBSSxDQUFDTyxVQUN0Qix1QkFBQyxhQUF1QixXQUFVLDZEQUNoQztBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxXQUFVO0FBQUEscUNBQUMsUUFBRyxXQUFVLDZDQUE2Q0EsZ0JBQU1rRSxvQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUFLLHVCQUFDLE9BQUUsV0FBVSwrQkFBK0JsRSxnQkFBTXVILFdBQVd2SCxNQUFNK0QsZ0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdGO0FBQUEsaUJBQWhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9NO0FBQUEsWUFDcE0sdUJBQUMsVUFBSyxXQUFVLHFFQUFvRTtBQUFBO0FBQUEsY0FBSy9ELE1BQU0wQztBQUFBQSxpQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUc7QUFBQSxlQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsOERBQTZEO0FBQUE7QUFBQSxZQUFhMUMsTUFBTWlFLGNBQWM7QUFBQSxlQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2SDtBQUFBLFVBQzdILHVCQUFDLFNBQUksV0FBVSxtQkFBa0I7QUFBQSxtQ0FBQyxPQUFFLE1BQU1qRSxNQUFNd0gsU0FBUyxRQUFPLFVBQVMsS0FBSSxjQUFhLFdBQVUscUZBQW9GLDJCQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSztBQUFBLFlBQUksdUJBQUMsT0FBRSxNQUFNeEgsTUFBTXdILFNBQVMsUUFBTyxVQUFTLEtBQUksY0FBYSxVQUFRLE1BQUMsV0FBVSxzRUFBcUUsd0JBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlKO0FBQUEsZUFBaFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb1c7QUFBQSxhQU54VnhILE1BQU0zQixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxNQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FoQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvQ0FJYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDhFQUE2RSxrREFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsOExBQ2I3Qyw2QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLCtEQUVaRjtBQUFBQSx1QkFBZSxpQkFDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsVUFBVThCLHNCQUFzQjtBQUFBLFlBQ2hDLFNBQVMsTUFBTStHLGtCQUFrQixjQUFjO0FBQUEsWUFDL0MsV0FBVyx5SEFDVC9HLHNCQUFzQixpQkFDbEIsaURBQ0Esb0VBQW9FO0FBQUEsWUFHMUU7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUNBQ2JBLGdDQUFzQixpQkFBaUIsU0FBUyxnQkFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0NBLHNCQUFzQixpQkFDbkIsb0JBQ0FFLG9CQUFvQixpQkFDcEIsZ0NBQ0E7QUFBQTtBQUFBO0FBQUEsVUFqQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JBO0FBQUEsUUFJRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsVUFBVUYsc0JBQXNCO0FBQUEsWUFDaEMsU0FBUyxNQUFNK0csa0JBQWtCLGtCQUFrQjtBQUFBLFlBQ25ELFdBQVcseUhBQ1QvRyxzQkFBc0IsV0FBVzVCLGVBQWUsS0FDNUMsaURBQ0EsZ0VBQWdFO0FBQUEsWUFHdEU7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUNBQ2I0QixnQ0FBc0IsV0FBVzVCLGVBQWUsS0FBSyxTQUFTLG9CQURqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQzRCLHNCQUFzQixXQUFXNUIsZUFBZSxLQUM3QyxvQkFDQThCLG9CQUFvQixXQUFXOUIsZUFBZSxLQUM5QyxZQUFZQSxlQUFlLFdBQzNCLHdCQUF3QkEsZUFBZTtBQUFBO0FBQUE7QUFBQSxVQWpCN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JBO0FBQUEsUUFHQ0YsZUFBZSxpQkFDZDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNdUIsbUJBQW1CLElBQUk7QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FBd0MsbUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJFO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQUpwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REE7QUFBQSxTQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBO0FBQUEsSUFLQyxDQUFDeUMsc0JBQXNCOUIsWUFBWUUsVUFBVSxVQUM1QztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVyx5Q0FDVEYsWUFBWUUsVUFBVSxVQUNsQiw2Q0FDQUYsWUFBWUUsVUFBVSxjQUN0QixzREFDQSw2Q0FBNkM7QUFBQSxRQUduRDtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcseUNBQ1RGLFlBQVlFLFVBQVUsVUFDbEIsa0JBQ0FGLFlBQVlFLFVBQVUsY0FDdEIscUJBQ0EsNkJBQTZCO0FBQUEsa0JBR2xDRixzQkFBWUUsVUFBVSxVQUNuQixVQUNBRixZQUFZRSxVQUFVLGNBQ3RCLGlCQUNBO0FBQUE7QUFBQSxnQkFiTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxxQkFBcUJGLHNCQUFZRyxXQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUN2REgsWUFBWThJLGVBQ1gsdUJBQUMsU0FBSSxXQUFVLGdDQUErQjtBQUFBO0FBQUEsa0JBQ25DLHVCQUFDLFVBQUssV0FBVSwyQkFBMkI5SSxzQkFBWThJLGVBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1FO0FBQUEscUJBRDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFRDlJLFlBQVkrSSxnQkFDWCx1QkFBQyxTQUFJLFdBQVUsNENBQ1ovSSxzQkFBWStJLGdCQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFFQy9JLFlBQVlFLFVBQVUsZUFDckIsdUJBQUMsVUFBSyxXQUFVLCtFQUE4RSx3QkFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsVUFHQ0YsWUFBWUUsVUFBVSxXQUFXRixZQUFZRSxVQUFVLGVBQ3RELHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFK0osT0FBTyxHQUFHakssWUFBWUksZUFBZSxJQUFJO0FBQUE7QUFBQSxZQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFc0QsS0FIeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBO0FBQUE7QUFBQSxNQXZESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5REE7QUFBQSxJQU1EdEMsZUFBZSxpQkFDZCx1QkFBQyxTQUFJLFdBQVUseUtBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdFQUErRCw4Q0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsdURBQXNELHNEQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNaLFdBQUMsY0FBYyxTQUFTLGFBQWEsRUFBRW1FO0FBQUFBLFFBQUksQ0FBQ2lJLFVBQzNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU1qTSxtQkFBbUJpTSxLQUFLO0FBQUEsWUFDdkMsV0FBVyxpRkFDVGxNLGdCQUFnQnNFLFlBQVksTUFBTTRILE1BQU01SCxZQUFZLElBQ2hELDRDQUNBLGlGQUFpRjtBQUFBLFlBR3RGNEg7QUFBQUE7QUFBQUEsY0FBTTtBQUFBO0FBQUE7QUFBQSxVQVJGQTtBQUFBQSxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVQTtBQUFBLE1BQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsSUFHRHBJLHNCQUNDLHVCQUFDLGFBQVEsV0FBVSxhQUNqQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxxQ0FDYixpQ0FBQyxRQUFHLFdBQVUscURBQW9ELHlDQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJGLEtBRDdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNaQyx3QkFBY0UsSUFBSSxDQUFDQyxZQUFZO0FBQzlCLGNBQU1pSSxnQkFBZ0J2TCxPQUFPa0csT0FBTyxDQUFDdEMsVUFBVUEsTUFBTUUsVUFBVUosWUFBWSxNQUFNSixRQUFRckIsR0FBR3lCLFlBQVksQ0FBQztBQUN6RyxjQUFNOEgsT0FBTyxJQUFJL0gsSUFBSThILGNBQWNsSSxJQUFJLENBQUNPLFVBQVVBLE1BQU0wQyxTQUFTLENBQUMsRUFBRUc7QUFDcEUsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNO0FBQUVwSCxpQ0FBbUJpRSxRQUFRckIsRUFBRTtBQUFHMUMsZ0NBQWtCLEtBQUs7QUFBQSxZQUFHO0FBQUEsWUFDM0UsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUseUdBQXdHLGlDQUFDLFVBQUssV0FBVSw2QkFBNEIsbUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDLEtBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZLO0FBQUEsZ0JBQzdLLHVCQUFDLFVBQUssV0FBVSxvQ0FBbUMsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsbUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSwwREFBMEQrRCxrQkFBUUMsUUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx1Q0FBQyxVQUFLO0FBQUEseUNBQUMsWUFBTyxXQUFVLHVDQUF1Q2lJO0FBQUFBO0FBQUFBLG9CQUFLO0FBQUEsdUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdFO0FBQUEsa0JBQVMsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQixvQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkM7QUFBQSxxQkFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUk7QUFBQSxnQkFDakksdUJBQUMsVUFBSztBQUFBLHlDQUFDLFlBQU8sV0FBVSx1Q0FBdUNELHdCQUFjeEYsVUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEU7QUFBQSxrQkFBUyx1QkFBQyxRQUFHLFdBQVUsNEJBQTJCLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLHFCQUE1STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpSjtBQUFBLGdCQUNqSix1QkFBQyxVQUFLO0FBQUEseUNBQUMsWUFBTyxXQUFVLHVDQUF1QyxjQUFJdEMsSUFBSThILGNBQWNsSSxJQUFJLENBQUNPLFVBQVVBLE1BQU00QyxXQUFXLEVBQUVOLE9BQU91RixPQUFPLENBQUMsRUFBRWhGLFFBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVJO0FBQUEsa0JBQVMsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUQ7QUFBQSxxQkFBek07QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOE07QUFBQSxtQkFIaE47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBO0FBQUE7QUFBQSxVQWRLbkQsUUFBUXJCO0FBQUFBLFVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWdCQTtBQUFBLE1BRUosQ0FBQyxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFDQ2tCLGNBQWM0QyxXQUFXLEtBQUssdUJBQUMsU0FBSSxXQUFVLHVGQUFzRix5REFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4STtBQUFBLFNBN0IvSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsSUFNRix1QkFBQyxTQUFJLFdBQVc3QyxxQkFBcUIsV0FBVyxhQUM5QztBQUFBLDZCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxREFBb0Q7QUFBQTtBQUFBLFVBQ3pDOUQ7QUFBQUEsVUFBZ0I7QUFBQSxhQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVSwwREFBeUQ7QUFBQTtBQUFBLFVBQ3pELHVCQUFDLFlBQU8sV0FBVSxpQ0FBaUNZLGlCQUFPK0YsVUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNaQyx1QkFBYTNDLElBQUksQ0FBQ3FJLGVBQWU7QUFDaEMsY0FBTUMsbUJBQW1CM0ssc0JBQXNCLE9BQU8wSyxXQUFXcEYsU0FBUztBQUMxRSxjQUFNc0YsaUJBQWlCMUssb0JBQW9CLE9BQU93SyxXQUFXcEYsU0FBUztBQUV0RSxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFNBRUM7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsU0FBUyxNQUFNO0FBQUU3Ryx5Q0FBZUQsZ0JBQWdCa00sV0FBV3BGLFlBQVksT0FBT29GLFdBQVdwRixTQUFTO0FBQUcvRyw0Q0FBa0JtTSxXQUFXcEYsU0FBUztBQUFBLHdCQUFHO0FBQUEsd0JBQzlJLFdBQVU7QUFBQSx3QkFFVG9GLHFCQUFXL0U7QUFBQUE7QUFBQUEsc0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHlDQUNiK0UscUJBQVc5RSxRQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxzREFDVDhFLFdBQVc3RSxjQUFjLElBQ3JCLDBHQUNBLCtEQUErRDtBQUFBLHNCQUdwRTZFO0FBQUFBLG1DQUFXN0U7QUFBQUEsd0JBQVk7QUFBQTtBQUFBO0FBQUEsb0JBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRQTtBQUFBLHFCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxpQ0FDWjZFLHFCQUFXM0UsZUFBZWhCLFNBQVMsSUFDbEMyRixXQUFXM0UsZUFBZTFEO0FBQUFBLGtCQUFJLENBQUNrQyxHQUFHc0csU0FDaEM7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsU0FBUyxNQUFNdEwsaUJBQWlCZ0YsQ0FBQztBQUFBLHNCQUNqQyxXQUFVO0FBQUEsc0JBRVY7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsS0FBS0EsRUFBRTZGO0FBQUFBLDBCQUNQLEtBQUs3RixFQUFFdUM7QUFBQUEsMEJBQ1AsV0FBVTtBQUFBLDBCQUNWLGdCQUFlO0FBQUE7QUFBQSx3QkFKakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUk4QjtBQUFBO0FBQUEsb0JBUnpCdkMsRUFBRXRELE1BQU00SjtBQUFBQSxvQkFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdBO0FBQUEsZ0JBQ0QsSUFFRCx1QkFBQyxTQUFJLFdBQVUseUpBQXdKLDBDQUF2SztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUJBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEseUNBQUMsVUFBSztBQUFBO0FBQUEsb0JBQVdILFdBQVc1RTtBQUFBQSxvQkFBa0I7QUFBQSx1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUQ7QUFBQSxrQkFDekQsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQVM0RSxXQUFXaEY7QUFBQUEsdUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEscUJBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1REE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTTtBQUNiakgsdUNBQWVpTSxXQUFXcEYsU0FBUztBQUNuQy9HLDBDQUFrQm1NLFdBQVdwRixTQUFTO0FBQ3RDLDhCQUFNd0YsVUFBVXJDLFNBQVNzQyxlQUFlLGlCQUFpQjtBQUN6REQsaUNBQVNFLGVBQWUsRUFBRUMsVUFBVSxTQUFTLENBQUM7QUFBQSxzQkFDaEQ7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpRTtBQUFBLHdCQUFPO0FBQUE7QUFBQTtBQUFBLG9CQVQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxrQkFFQy9NLGVBQWUsaUJBQ2Q7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNK0wsdUJBQXVCUyxXQUFXcEYsU0FBUztBQUFBLHNCQUMxRCxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4RDtBQUFBLHdCQUFPO0FBQUE7QUFBQTtBQUFBLG9CQUp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1QkE7QUFBQSxnQkFHQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFJLGdCQUFnQm9GLFdBQVdwRixTQUFTO0FBQUEsb0JBQ3hDLFVBQVV0RixzQkFBc0IsUUFBUTBLLFdBQVc3RSxnQkFBZ0I7QUFBQSxvQkFDbkUsU0FBUyxNQUFNa0Isa0JBQWtCLE9BQU8yRCxXQUFXcEYsU0FBUztBQUFBLG9CQUM1RCxXQUFXLDhJQUNUb0YsV0FBVzdFLGdCQUFnQixJQUN2QixrRUFDQThFLG1CQUNBLDRDQUNBLGdFQUFnRTtBQUFBLG9CQUd0RTtBQUFBLDZDQUFDLFVBQUssV0FBVSx5Q0FDYkEsNkJBQW1CLFNBQVMsZ0JBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQ0EsbUJBQ0csb0JBQ0FDLGlCQUNBLG1CQUNBLGdCQUFnQkYsV0FBV3BGLFNBQVM7QUFBQTtBQUFBO0FBQUEsa0JBbkIxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBb0JBO0FBQUEsZ0JBRUM5RyxnQkFBZ0JrTSxXQUFXcEYsYUFDMUIsdUJBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLCtEQUE4RDtBQUFBO0FBQUEsc0JBQUtvRixXQUFXcEY7QUFBQUEsc0JBQVU7QUFBQSx5QkFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUg7QUFBQSxvQkFDbkgsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNN0csZUFBZSxJQUFJLEdBQUcsV0FBVSxxRkFBb0YscUJBQXpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThKO0FBQUEsdUJBRmhLO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQ2lNLFdBQVczRSxlQUFlaEIsV0FBVyxJQUNwQyx1QkFBQyxTQUFJLFdBQVUsb0lBQW1JLGdFQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrTSxJQUVsTTJGLFdBQVczRSxlQUFlMUQ7QUFBQUEsb0JBQUksQ0FBQ08sVUFDN0IsdUJBQUMsU0FBbUIsV0FBVSwwSUFDNUI7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsV0FBVTtBQUFBLCtDQUFDLFNBQUksV0FBVSxtRUFBbUVBLGdCQUFNa0Usb0JBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXlHO0FBQUEsd0JBQU0sdUJBQUMsU0FBSSxXQUFVLHNDQUFzQ2xFLGdCQUFNdUgsV0FBV3ZILE1BQU0rRCxnQkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUY7QUFBQSwyQkFBak87QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdU87QUFBQSxzQkFDdk8sdUJBQUMsT0FBRSxNQUFNL0QsTUFBTXdILFNBQVMsUUFBTyxVQUFTLEtBQUksY0FBYSxXQUFVLG1GQUFrRixvQkFBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUo7QUFBQSx5QkFGakp4SCxNQUFNM0IsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLGtCQUNEO0FBQUEscUJBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLG1CQWpFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1FQTtBQUFBO0FBQUE7QUFBQSxVQWhJS3lKLFdBQVdwRjtBQUFBQSxVQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0lBO0FBQUEsTUFFSixDQUFDLEtBMUlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEySUE7QUFBQSxTQXJKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0pBO0FBQUEsSUFLQSx1QkFBQyxTQUFJLElBQUcsbUJBQWtCLFdBQVcsR0FBR3BELHFCQUFxQixZQUFZLEVBQUUsa0JBQ3pFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsK0JBQUMsU0FDQyxpQ0FBQyxRQUFHLFdBQVUscURBQW9ELDZCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFLEtBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHdEQUF1RDtBQUFBO0FBQUEsWUFDN0QsdUJBQUMsWUFBTyxXQUFVLGlDQUFpQytELHlCQUFlbEIsVUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUFTO0FBQUEsZUFENUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILFVBQVUvRSxzQkFBc0IsUUFBUWlHLGVBQWVsQixXQUFXO0FBQUEsY0FDbEUsU0FBUyxNQUFNZ0Msa0JBQWtCLFVBQVU7QUFBQSxjQUMzQyxXQUFXLDBIQUNUZCxlQUFlbEIsV0FBVyxJQUN0QixrRUFDQS9FLHNCQUFzQixhQUN0Qiw4QkFDQSxnREFBZ0Q7QUFBQSxjQUd0RDtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FDYkEsZ0NBQXNCLGFBQWEsU0FBUyxjQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NBLHNCQUFzQixhQUFhLG9CQUFvQjtBQUFBO0FBQUE7QUFBQSxZQWYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTXpCLGtCQUFrQixLQUFLO0FBQUEsWUFDdEMsV0FBVyxtR0FDVEQsbUJBQW1CLFFBQ2YsNEJBQ0EsZ0RBQWdEO0FBQUEsWUFDbkQ7QUFBQTtBQUFBLGNBRVFVLE9BQU8rRjtBQUFBQSxjQUFPO0FBQUE7QUFBQTtBQUFBLFVBUjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsUUFDQyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFMUMsSUFBSSxDQUFDNkksU0FBUztBQUN0QyxnQkFBTUMsUUFBUW5NLE9BQU9rRyxPQUFPLENBQUNYLE1BQU1BLEVBQUVlLGNBQWM0RixJQUFJLEVBQUVuRztBQUN6RCxpQkFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNeEcsa0JBQWtCMk0sSUFBSTtBQUFBLGNBQ3JDLFdBQVcsbUdBQ1Q1TSxtQkFBbUI0TSxPQUNmLDRCQUNBLGdEQUFnRDtBQUFBLGNBQ25EO0FBQUE7QUFBQSxnQkFFRUE7QUFBQUEsZ0JBQUs7QUFBQSxnQkFBR0M7QUFBQUEsZ0JBQU07QUFBQTtBQUFBO0FBQUEsWUFSZEQ7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUVKLENBQUM7QUFBQSxXQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdFQUErRCx5QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU94TSxxQkFBcUI7QUFBQSxjQUM1QixlQUFlLENBQUMwTSxRQUFRO0FBQ3RCek0scUNBQXFCeU0sR0FBRztBQUN4QnZNLG1DQUFtQixLQUFLO0FBQUEsY0FDMUI7QUFBQSxjQUVBO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDQztBQUFBLHlDQUFDLGNBQVcsT0FBTSxPQUFNLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUNyQ25CLFdBQVcyRTtBQUFBQSxvQkFBSSxDQUFDa0MsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFdEQsSUFDN0JzRCxZQUFFaEMsUUFEWWdDLEVBQUV0RCxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQSxxQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUE7QUFBQTtBQUFBLFlBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtCQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0VBQStELDhCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3JDLG1CQUFtQjtBQUFBLGNBQzFCLGVBQWUsQ0FBQ3dNLFFBQVF2TSxtQkFBbUJ1TSxHQUFHO0FBQUEsY0FFOUM7QUFBQSx1Q0FBQyxpQkFBYyxXQUFVLGVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxrQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLGlCQUNDO0FBQUEseUNBQUMsY0FBVyxPQUFNLE9BQU0sNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ25DL0csc0JBQXNCaEM7QUFBQUEsb0JBQUksQ0FBQ29DLE1BQzFCLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUVsQyxNQUM3QmtDLFlBQUVsQyxRQURZa0MsRUFBRXhELElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBLHFCQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQTtBQUFBO0FBQUEsWUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFlQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw2REFBNEQscURBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsbUNBQUMsVUFBTyxXQUFVLHdGQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRztBQUFBLFlBQ3RHO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9uQztBQUFBQSxnQkFDUCxVQUFVLENBQUM2SyxNQUFNNUssZUFBZTRLLEVBQUUwQixPQUFPQyxLQUFLO0FBQUEsZ0JBQzlDLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs4TztBQUFBLFlBRTdPeE0sZUFDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1DLGVBQWUsRUFBRTtBQUFBLGdCQUNoQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsS0FBRSxXQUFVLGlCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUE7QUFBQSxjQUw1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFdBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RUE7QUFBQSxTQXZJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0lBO0FBQUEsSUFNQ0csWUFDQyx1QkFBQyxTQUFJLFdBQVUsZ0ZBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUscUVBQW9FLGlDQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIseURBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxTQUpyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsSUFDRStHLGVBQWVsQixXQUFXLElBQzVCLHVCQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSw2REFBNEQsbUNBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQyxnREFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQ2pGLHVCQUFDLE9BQUUsV0FBVSxnREFBK0MsMEdBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTTtBQUNieEcsOEJBQWtCLEtBQUs7QUFDdkJJLGlDQUFxQixLQUFLO0FBQzFCRSwrQkFBbUIsS0FBSztBQUN4QkUsMkJBQWUsRUFBRTtBQUFBLFVBQ25CO0FBQUEsVUFDQSxXQUFVO0FBQUEsVUFBNkc7QUFBQTtBQUFBLFFBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1RUFDWmtILHlCQUFlNUQ7QUFBQUEsTUFBSSxDQUFDTyxVQUNuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsV0FBVTtBQUFBLFVBR1Y7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxLQUFLQSxNQUFNd0g7QUFBQUEsa0JBQ1gsS0FBS3hILE1BQU0rRDtBQUFBQSxrQkFDWCxXQUFVO0FBQUEsa0JBQ1YsZ0JBQWU7QUFBQSxrQkFDZixTQUFTLE1BQU1wSCxpQkFBaUJxRCxLQUFLO0FBQUE7QUFBQSxnQkFMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS3lDO0FBQUEsY0FJekMsdUJBQUMsU0FBSSxXQUFVLDJGQUEwRjtBQUFBO0FBQUEsZ0JBQ2xHQSxNQUFNMEM7QUFBQUEsbUJBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDRGQUNaaUc7QUFBQUEscUJBQUtDLE9BQU81SSxNQUFNNkksWUFBWSxPQUFTLElBQUk7QUFBQSxnQkFBRTtBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNkpBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsZ0RBQWdEN0ksZ0JBQU0rRCxnQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Y7QUFBQSxnQkFDaEYsdUJBQUMsT0FBRSxXQUFVLHFDQUNWL0Q7QUFBQUEsd0JBQU15RDtBQUFBQSxrQkFBYztBQUFBLGtCQUFNekQsTUFBTTJEO0FBQUFBLHFCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxDQUFDb0QsTUFBTTtBQUNkQSwwQkFBRStCLGdCQUFnQjtBQUNsQm5NLHlDQUFpQnFELEtBQUs7QUFBQSxzQkFDeEI7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBRVY7QUFBQSwrQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrRTtBQUFBLHdCQUFPO0FBQUE7QUFBQTtBQUFBLG9CQVAzRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLENBQUMrRyxNQUFNO0FBQ2RBLDBCQUFFK0IsZ0JBQWdCO0FBQ2xCdEMsa0RBQTBCeEcsS0FBSztBQUFBLHNCQUNqQztBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFVBQUssV0FBVSx5Q0FBd0Msd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdFO0FBQUEsd0JBQU87QUFBQTtBQUFBO0FBQUEsb0JBUHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLHFCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBLG1CQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGlCQS9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdEQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSxpREFDWkEsZ0JBQU0rRCxnQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNaL0Q7QUFBQUEsd0JBQU15RDtBQUFBQSxrQkFBYztBQUFBLGtCQUFNekQsTUFBTTJEO0FBQUFBLHFCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEseUNBQUMsVUFBSztBQUFBO0FBQUEsb0JBQUkzRCxNQUFNaUU7QUFBQUEsdUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzNCLHVCQUFDLFVBQU1qRSxnQkFBTWdELFFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0I7QUFBQSxxQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXJHLGlCQUFpQnFELEtBQUs7QUFBQSxvQkFDckMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5Q0FBd0MsMEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtFO0FBQUEsc0JBQU87QUFBQTtBQUFBO0FBQUEsa0JBTDNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXdHLDBCQUEwQnhHLEtBQUs7QUFBQSxvQkFDOUMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5Q0FBd0Msd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdFO0FBQUEsc0JBQU87QUFBQTtBQUFBO0FBQUEsa0JBTHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTdDLGlCQUFpQjZDLEtBQUs7QUFBQSxvQkFDckMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5Q0FBd0Msc0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThEO0FBQUEsc0JBQU87QUFBQTtBQUFBO0FBQUEsa0JBTHZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGlCQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJDQTtBQUFBO0FBQUE7QUFBQSxRQWxHS0EsTUFBTTNCO0FBQUFBLFFBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW9HQTtBQUFBLElBQ0QsS0F2R0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdHQTtBQUFBLElBTUQzQixpQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNQyxpQkFBaUIsSUFBSTtBQUFBLFFBRXBDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLENBQUNvSyxNQUFNQSxFQUFFK0IsZ0JBQWdCO0FBQUEsWUFHbEM7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDBEQUF5RDtBQUFBO0FBQUEsc0JBQ2xFcE0sY0FBY2dHO0FBQUFBLHlCQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtDQUFrQ2hHLHdCQUFjcUgsZ0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJFO0FBQUEsdUJBSjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQ1ZySDtBQUFBQSxrQ0FBYytHO0FBQUFBLG9CQUFjO0FBQUEsb0JBQU0vRyxjQUFjaUg7QUFBQUEsb0JBQVk7QUFBQSxvQkFBTWpILGNBQWNzRztBQUFBQSx1QkFEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU13RCwwQkFBMEI5SixhQUFhO0FBQUEsc0JBQ3RELFdBQVU7QUFBQSxzQkFFVjtBQUFBLCtDQUFDLFVBQUssV0FBVSx5Q0FBd0Msd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdFO0FBQUEsd0JBQU87QUFBQTtBQUFBO0FBQUEsb0JBSnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTUMsaUJBQWlCLElBQUk7QUFBQSxzQkFDcEMsV0FBVTtBQUFBLHNCQUVWLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZEO0FBQUE7QUFBQSxvQkFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLEtBQUtELGNBQWM4SztBQUFBQSxrQkFDbkIsS0FBSzlLLGNBQWNxSDtBQUFBQSxrQkFDbkIsV0FBVTtBQUFBLGtCQUNWLGdCQUFlO0FBQUE7QUFBQSxnQkFKakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSThCLEtBTGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSx1SEFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFVBQUs7QUFBQTtBQUFBLG9CQUNTLHVCQUFDLFlBQU8sV0FBVSxjQUFjckgsd0JBQWN1SCxjQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RDtBQUFBLHVCQUR4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQ00sdUJBQUMsWUFBTyxXQUFVLHdCQUF3QnZILHdCQUFjd0gsb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlFO0FBQUEsdUJBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLO0FBQUE7QUFBQSxvQkFDRSx1QkFBQyxZQUFPLFdBQVUsd0JBQXdCeUU7QUFBQUEsMkJBQUtDLE9BQU9sTSxjQUFjbU0sWUFBWSxPQUFTLElBQUk7QUFBQSxzQkFBRTtBQUFBLHlCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRztBQUFBLHVCQUQxRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUNiMUwsdUNBQWlCVCxhQUFhO0FBQUEsb0JBQ2hDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHlDQUF3QyxzQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEQ7QUFBQSxzQkFBTztBQUFBO0FBQUE7QUFBQSxrQkFOdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUE7QUFBQTtBQUFBLFVBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXFFQTtBQUFBO0FBQUEsTUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMEVBO0FBQUEsSUFNREUsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSxnR0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0NBQXFDLDBDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsb0ZBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxZQUN2QyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVaUssb0JBQW9CLFdBQVUseUJBQzNDM0g7QUFBQUEsdUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDhFQUNaQSx5QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsdUNBQXNDLDZCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzBGLE9BQU81RyxTQUFTO0FBQUEsZ0JBQ3ZCLGVBQWUsQ0FBQ3VLLFFBQVF0SyxhQUFhNkssU0FBU1AsS0FBSyxFQUFFLENBQUM7QUFBQSxnQkFFdEQ7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLGtFQUN2QixpQ0FBQyxlQUFZLGFBQVksZ0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxpQkFDRSxXQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQyxFQUFFL0k7QUFBQUEsb0JBQUksQ0FBQ3VKLE1BQzdCLHVCQUFDLGNBQW1CLE9BQU9uRSxPQUFPbUUsQ0FBQyxHQUFHO0FBQUE7QUFBQSxzQkFDL0JBO0FBQUFBLHlCQURVQSxHQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQTtBQUFBLGNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHVDQUFzQywrQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLE9BQU9qTDtBQUFBQSxnQkFDUCxVQUFVLENBQUNnSixNQUFNL0ksZUFBZStJLEVBQUUwQixPQUFPQyxLQUFLO0FBQUEsZ0JBQzlDLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11SDtBQUFBLGVBUnpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHVDQUFzQywyQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU92SztBQUFBQSxnQkFDUCxlQUFlLENBQUNxSyxRQUFRcEssbUJBQW1Cb0ssR0FBRztBQUFBLGdCQUU5QztBQUFBLHlDQUFDLGlCQUFjLFdBQVUsb0RBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFMU4scUJBQVcyRTtBQUFBQSxvQkFBSSxDQUFDa0MsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFdEQsSUFDN0JzRCxZQUFFaEMsUUFEWWdDLEVBQUV0RCxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQTtBQUFBLGNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSx1Q0FBc0MsZ0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxPQUFPQztBQUFBQSxnQkFDUCxVQUFVLENBQUN5SSxNQUFNeEksaUJBQWlCd0ksRUFBRTBCLE9BQU9DLEtBQUs7QUFBQSxnQkFDaEQsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLdUg7QUFBQSxlQVB6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSx1Q0FBc0Msc0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxPQUFPbEs7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDdUksTUFBTXRJLGNBQWNzSSxFQUFFMEIsT0FBT0MsS0FBSztBQUFBLGdCQUM3QyxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt1SDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsdUNBQXNDLCtCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3RFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsT0FBTzdKO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ2tJLE1BQU1qSSxrQkFBa0JpSSxFQUFFMEIsT0FBT0MsS0FBSztBQUFBLGdCQUNqRCxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt1SDtBQUFBLGVBUHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHVDQUFzQyxvQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkU7QUFBQSxVQUMzRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsS0FBS3JKO0FBQUFBLGNBQ0w7QUFBQSxjQUNBLFFBQU87QUFBQSxjQUNQLFVBQVUsQ0FBQzBILE1BQU07QUFDZixvQkFBSUEsRUFBRTBCLE9BQU9RLE9BQU87QUFDbEJuTCxpQ0FBZXNELE1BQU04SCxLQUFLbkMsRUFBRTBCLE9BQU9RLEtBQUssQ0FBQztBQUFBLGdCQUMzQztBQUFBLGNBQ0Y7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV29CO0FBQUEsVUFHcEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDZEQUE0RCw0QkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsMkNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsZ0JBQ3JFLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0MsK0RBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFVBRUNwTCxZQUFZc0UsU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZ0NBQStCO0FBQUE7QUFBQSxjQUNuQ3RFLFlBQVlzRTtBQUFBQSxjQUFPO0FBQUEsaUJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx5RkFDWnRFLHNCQUFZNEI7QUFBQUEsY0FBSSxDQUFDMEosR0FBR0MsTUFDbkIsdUJBQUMsU0FBWSxXQUFVLGdFQUNyQjtBQUFBLHVDQUFDLFVBQUssV0FBVSxvQ0FBb0NELFlBQUV4SixRQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGdCQUMzRCx1QkFBQyxVQUFLLFdBQVUsa0JBQWtCZ0o7QUFBQUEsdUJBQUtDLE1BQU1PLEVBQUV0RyxPQUFPLElBQUk7QUFBQSxrQkFBRTtBQUFBLHFCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRDtBQUFBLG1CQUZ2RHVHLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLFlBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUExQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXZNLG1CQUFtQixLQUFLO0FBQUEsY0FDdkMsV0FBVTtBQUFBLGNBQTZGO0FBQUE7QUFBQSxZQUh6RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVVvQyxlQUFlcEIsWUFBWXNFLFdBQVc7QUFBQSxjQUNoRCxXQUFXLDhGQUNUbEQsZUFBZXBCLFlBQVlzRSxXQUFXLElBQ2xDLG9DQUNBLGlDQUFpQztBQUFBLGNBR3ZDO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHlDQUNibEQsd0JBQWMsU0FBUyxZQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NBLGNBQWMsd0JBQXdCLFVBQVVwQixZQUFZc0UsTUFBTTtBQUFBO0FBQUE7QUFBQSxZQVpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQXpLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEtBO0FBQUEsU0ExTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJMQSxLQTVMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkxBO0FBQUEsSUFNRGpGLGlCQUNDLHVCQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxTQUFJLFdBQVUsMkVBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsdURBQXNELHVCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxzQ0FBcUMsNkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUNoRSx1QkFBQyxPQUFFLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxRQUNRLHVCQUFDLFlBQU8sV0FBVSxrQkFBa0JBLHdCQUFjZ0gsb0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUU7QUFBQSxRQUFTO0FBQUEsV0FEMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNL0csaUJBQWlCLElBQUk7QUFBQSxZQUNwQyxXQUFVO0FBQUEsWUFBeUc7QUFBQTtBQUFBLFVBRnJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNdUosa0JBQWtCeEosYUFBYTtBQUFBLFlBQzlDLFdBQVU7QUFBQSxZQUE2RjtBQUFBO0FBQUEsVUFGekc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLE9BajdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbTdCQTtBQUVKO0FBQUU3QixHQWw1Q1dSLG1CQUFtRDtBQUFBLEtBQW5EQTtBQUFtRCxJQUFBd087QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlUmVmIiwiYXBpVXJsIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJTZWFyY2giLCJYIiwiU2Vzc2lvblBob3Rvc1ZpZXciLCJwYW5jaGF5YXRzIiwiY2x1c3RlcnMiLCJhdXRoVG9rZW4iLCJ1c2VyUm9sZSIsImN1cnJlbnRDbHVzdGVyIiwib25OYXZpZ2F0ZSIsIm9uUm9sZUNoYW5nZSIsIl9zIiwiYWN0aXZlUm9sZSIsInNldEFjdGl2ZVJvbGUiLCJzZWxlY3RlZENsdXN0ZXIiLCJzZXRTZWxlY3RlZENsdXN0ZXIiLCJzZWxlY3RlZERheVRhYiIsInNldFNlbGVjdGVkRGF5VGFiIiwiZXhwYW5kZWREYXkiLCJzZXRFeHBhbmRlZERheSIsInNlbGVjdGVkUGFuY2hheWF0Iiwic2V0U2VsZWN0ZWRQYW5jaGF5YXQiLCJzZWxlY3RlZFZpbGxhZ2UiLCJzZXRTZWxlY3RlZFZpbGxhZ2UiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwicGhvdG9zIiwic2V0UGhvdG9zIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwibG9hZEVycm9yIiwic2V0TG9hZEVycm9yIiwic2VsZWN0ZWRQaG90byIsInNldFNlbGVjdGVkUGhvdG8iLCJzaG93VXBsb2FkTW9kYWwiLCJzZXRTaG93VXBsb2FkTW9kYWwiLCJ1cGxvYWREYXlUYXJnZXQiLCJzZXRVcGxvYWREYXlUYXJnZXQiLCJ2aWV3RGF5TW9kYWwiLCJzZXRWaWV3RGF5TW9kYWwiLCJwaG90b1RvRGVsZXRlIiwic2V0UGhvdG9Ub0RlbGV0ZSIsImRvd25sb2FkaW5nWmlwS2V5Iiwic2V0RG93bmxvYWRpbmdaaXBLZXkiLCJjb21wbGV0ZWRaaXBLZXkiLCJzZXRDb21wbGV0ZWRaaXBLZXkiLCJ6aXBQcm9ncmVzcyIsInNldFppcFByb2dyZXNzIiwic3RhZ2UiLCJtZXNzYWdlIiwicHJvZ3Jlc3NQZXJjZW50IiwidXBsb2FkRmlsZXMiLCJzZXRVcGxvYWRGaWxlcyIsInVwbG9hZFRpdGxlIiwic2V0VXBsb2FkVGl0bGUiLCJ1cGxvYWREYXkiLCJzZXRVcGxvYWREYXkiLCJ1cGxvYWRQYW5jaGF5YXQiLCJzZXRVcGxvYWRQYW5jaGF5YXQiLCJpZCIsInVwbG9hZFZpbGxhZ2UiLCJzZXRVcGxvYWRWaWxsYWdlIiwidXBsb2FkRGF0ZSIsInNldFVwbG9hZERhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInVwbG9hZFVwbG9hZGVyIiwic2V0VXBsb2FkVXBsb2FkZXIiLCJ1cGxvYWRDYXB0aW9uIiwic2V0VXBsb2FkQ2FwdGlvbiIsImlzVXBsb2FkaW5nIiwic2V0SXNVcGxvYWRpbmciLCJ1cGxvYWRFcnJvciIsInNldFVwbG9hZEVycm9yIiwiZmlsZUlucHV0UmVmIiwic2hvd0NsdXN0ZXJMYW5kaW5nIiwicGhvdG9DbHVzdGVycyIsImtub3duIiwibWFwIiwiY2x1c3RlciIsIm5hbWUiLCJrbm93bklkcyIsIlNldCIsInRvTG93ZXJDYXNlIiwiZm9yRWFjaCIsInBob3RvIiwiaGFzIiwiY2x1c3RlcklkIiwicHVzaCIsImNsdXN0ZXJOYW1lIiwiYWRkIiwiZmV0Y2hQaG90b3MiLCJjbHVzdGVyUGFyYW0iLCJyZXMiLCJmZXRjaCIsImVuY29kZVVSSUNvbXBvbmVudCIsImNhY2hlIiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJvayIsIkVycm9yIiwic3RhdHVzIiwiZGF0YSIsImpzb24iLCJzdWNjZXNzIiwiQXJyYXkiLCJpc0FycmF5IiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiY3VycmVudEZpbHRlclZpbGxhZ2VzIiwiYWxsVmlsbGFnZXMiLCJwIiwidmlsbGFnZXMiLCJ2Iiwic29tZSIsImV4aXN0aW5nIiwiZm91bmQiLCJmaW5kIiwic2VsZWN0ZWRQIiwibGVuZ3RoIiwiZGF5U3VtbWFyaWVzIiwidGFyZ2V0Q2x1c3RlclBob3RvcyIsImZpbHRlciIsInN1bW1hcmllcyIsImRheSIsImRheVBob3RvcyIsImRheU51bWJlciIsInVuaXF1ZVBhbmNoYXlhdHMiLCJwYW5jaGF5YXRJZCIsInNpemUiLCJ0YXJnZXRDb3VudCIsImRheUxhYmVsIiwiZGF0ZSIsInBob3Rvc0NvdW50IiwicGFuY2hheWF0Q292ZXJhZ2UiLCJmZWF0dXJlZFBob3RvcyIsInNsaWNlIiwiZmlsdGVyZWRQaG90b3MiLCJtYXRjaENsdXN0ZXIiLCJtYXRjaERheSIsIm1hdGNoUGFuY2hheWF0IiwicGFuY2hheWF0TmFtZSIsIm1hdGNoVmlsbGFnZSIsInZpbGxhZ2VOYW1lIiwicSIsInRyaW0iLCJtYXRjaFNlYXJjaCIsInNlc3Npb25UaXRsZSIsImluY2x1ZGVzIiwidXBsb2FkZWRCeSIsIm9yaWdpbmFsRmlsZW5hbWUiLCJoYW5kbGVEb3dubG9hZFppcCIsInR5cGUiLCJrZXkiLCJ3YXJuIiwiUHJvbWlzZSIsInIiLCJzZXRUaW1lb3V0IiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwiU3RyaW5nIiwiemlwVXJsIiwidG9TdHJpbmciLCJyZXNwb25zZSIsImVycm9ySnNvbiIsImNhdGNoIiwiZG93bmxvYWRGaWxlbmFtZSIsImRpc3Bvc2l0aW9uIiwiZ2V0IiwibWF0Y2giLCJibG9iIiwiYmxvYlVybCIsIndpbmRvdyIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImxpbmsiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJocmVmIiwiZG93bmxvYWQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJjbGljayIsInJlbW92ZUNoaWxkIiwicmV2b2tlT2JqZWN0VVJMIiwiemlwRmlsZW5hbWUiLCJlcnJvck1lc3NhZ2UiLCJoYW5kbGVEb3dubG9hZFNpbmdsZVBob3RvIiwiZG93bmxvYWRVcmwiLCJoYW5kbGVEZWxldGVQaG90byIsIm1ldGhvZCIsInByZXYiLCJhbGVydCIsImhhbmRsZVVwbG9hZFN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImZvcm1EYXRhIiwiRm9ybURhdGEiLCJmb3VuZFAiLCJmaWxlIiwiaGFuZGxlT3BlblVwbG9hZEZvckRheSIsInNlbGVjdGVkRGF5UGhvdG9zIiwiY2FwdGlvbiIsImZpbGVVcmwiLCJ3aWR0aCIsImNOYW1lIiwiY2x1c3RlclBob3RvcyIsImRheXMiLCJCb29sZWFuIiwiZGF5U3VtbWFyeSIsImlzRGF5RG93bmxvYWRpbmciLCJpc0RheUNvbXBsZXRlZCIsInBJZHgiLCJlbGVtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiZE51bSIsImNvdW50IiwidmFsIiwidGFyZ2V0IiwidmFsdWUiLCJNYXRoIiwicm91bmQiLCJmaWxlU2l6ZSIsInN0b3BQcm9wYWdhdGlvbiIsInBhcnNlSW50IiwiZCIsImZpbGVzIiwiZnJvbSIsImYiLCJpIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2Vzc2lvblBob3Rvc1ZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7XHJcbiAgU2Vzc2lvblBob3RvSXRlbSxcclxuICBEYXlQaG90b1N1bW1hcnksXHJcbiAgUGFuY2hheWF0LFxyXG4gIFppcFByb2dyZXNzU3RhdGUsXHJcbiAgWmlwR2VuZXJhdGlvblN0YWdlLFxyXG4gIFRhYlR5cGUsXHJcbiAgQ2x1c3RlcixcclxufSBmcm9tICcuLi90eXBlcyc7XHJcbmltcG9ydCB7IGFwaVVybCB9IGZyb20gJy4uL3V0aWxzL2FwaSc7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIFNlbGVjdENvbnRlbnQsXHJcbiAgU2VsZWN0SXRlbSxcclxuICBTZWxlY3RUcmlnZ2VyLFxyXG4gIFNlbGVjdFZhbHVlLFxyXG59IGZyb20gJy4vdWkvc2VsZWN0JztcclxuaW1wb3J0IHsgU2VhcmNoLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuXHJcbmludGVyZmFjZSBTZXNzaW9uUGhvdG9zVmlld1Byb3BzIHtcclxuICBwYW5jaGF5YXRzOiBQYW5jaGF5YXRbXTtcclxuICBjbHVzdGVycz86IENsdXN0ZXJbXTtcclxuICBhdXRoVG9rZW4/OiBzdHJpbmc7XHJcbiAgdXNlclJvbGU/OiAnQ2x1c3RlciBBZG1pbicgfCAnU3VwZXIgQWRtaW4nO1xyXG4gIGN1cnJlbnRDbHVzdGVyPzogc3RyaW5nO1xyXG4gIG9uTmF2aWdhdGU/OiAodGFiOiBUYWJUeXBlLCB0YXJnZXRJZD86IHN0cmluZykgPT4gdm9pZDtcclxuICBvblJvbGVDaGFuZ2U/OiAocm9sZTogJ0NsdXN0ZXIgQWRtaW4nIHwgJ1N1cGVyIEFkbWluJykgPT4gdm9pZDtcclxufVxyXG5cclxuXHJcbmV4cG9ydCBjb25zdCBTZXNzaW9uUGhvdG9zVmlldzogUmVhY3QuRkM8U2Vzc2lvblBob3Rvc1ZpZXdQcm9wcz4gPSAoe1xyXG4gIHBhbmNoYXlhdHMgPSBbXSxcclxuICBjbHVzdGVycyA9IFtdLFxyXG4gIGF1dGhUb2tlbixcclxuICB1c2VyUm9sZSA9ICdDbHVzdGVyIEFkbWluJyxcclxuICBjdXJyZW50Q2x1c3RlciA9ICdEaGFybWFwdXJpJyxcclxuICBvbk5hdmlnYXRlLFxyXG4gIG9uUm9sZUNoYW5nZSxcclxufSkgPT4ge1xyXG4gIC8vIFN0YXRlXHJcbiAgY29uc3QgW2FjdGl2ZVJvbGUsIHNldEFjdGl2ZVJvbGVdID0gdXNlU3RhdGU8J0NsdXN0ZXIgQWRtaW4nIHwgJ1N1cGVyIEFkbWluJz4odXNlclJvbGUpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZENsdXN0ZXIsIHNldFNlbGVjdGVkQ2x1c3Rlcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxyXG4gICAgdXNlclJvbGUgPT09ICdDbHVzdGVyIEFkbWluJyA/ICdEaGFybWFwdXJpJyA6ICdhbGwnXHJcbiAgKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXlUYWIsIHNldFNlbGVjdGVkRGF5VGFiXSA9IHVzZVN0YXRlPG51bWJlciB8ICdhbGwnPignYWxsJyk7XHJcbiAgY29uc3QgW2V4cGFuZGVkRGF5LCBzZXRFeHBhbmRlZERheV0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXQsIHNldFNlbGVjdGVkUGFuY2hheWF0XSA9IHVzZVN0YXRlPHN0cmluZz4oJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFZpbGxhZ2UsIHNldFNlbGVjdGVkVmlsbGFnZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdhbGwnKTtcclxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xyXG5cclxuICAvLyBQaG90b3MgQ29sbGVjdGlvbiAoRmV0Y2hlZCBmcm9tIEJhY2tlbmQgQVBJKVxyXG4gIGNvbnN0IFtwaG90b3MsIHNldFBob3Rvc10gPSB1c2VTdGF0ZTxTZXNzaW9uUGhvdG9JdGVtW10+KFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XHJcbiAgY29uc3QgW2xvYWRFcnJvciwgc2V0TG9hZEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvLyBNb2RhbHMgJiBBY3RpdmUgU2VsZWN0aW9uc1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBob3RvLCBzZXRTZWxlY3RlZFBob3RvXSA9IHVzZVN0YXRlPFNlc3Npb25QaG90b0l0ZW0gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2hvd1VwbG9hZE1vZGFsLCBzZXRTaG93VXBsb2FkTW9kYWxdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xyXG4gIGNvbnN0IFt1cGxvYWREYXlUYXJnZXQsIHNldFVwbG9hZERheVRhcmdldF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEpO1xyXG4gIGNvbnN0IFt2aWV3RGF5TW9kYWwsIHNldFZpZXdEYXlNb2RhbF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbcGhvdG9Ub0RlbGV0ZSwgc2V0UGhvdG9Ub0RlbGV0ZV0gPSB1c2VTdGF0ZTxTZXNzaW9uUGhvdG9JdGVtIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIC8vIFpJUCBHZW5lcmF0aW9uICYgRG93bmxvYWQgU3RhdGVcclxuICBjb25zdCBbZG93bmxvYWRpbmdaaXBLZXksIHNldERvd25sb2FkaW5nWmlwS2V5XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtjb21wbGV0ZWRaaXBLZXksIHNldENvbXBsZXRlZFppcEtleV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbemlwUHJvZ3Jlc3MsIHNldFppcFByb2dyZXNzXSA9IHVzZVN0YXRlPFppcFByb2dyZXNzU3RhdGU+KHtcclxuICAgIHN0YWdlOiAnaWRsZScsXHJcbiAgICBtZXNzYWdlOiAnJyxcclxuICAgIHByb2dyZXNzUGVyY2VudDogMCxcclxuICB9KTtcclxuXHJcbiAgLy8gVXBsb2FkIEZvcm0gU3RhdGVcclxuICBjb25zdCBbdXBsb2FkRmlsZXMsIHNldFVwbG9hZEZpbGVzXSA9IHVzZVN0YXRlPEZpbGVbXT4oW10pO1xyXG4gIGNvbnN0IFt1cGxvYWRUaXRsZSwgc2V0VXBsb2FkVGl0bGVdID0gdXNlU3RhdGU8c3RyaW5nPignSW50ZXJhY3RpdmUgTGVhcm5pbmcgV29ya3Nob3AnKTtcclxuICBjb25zdCBbdXBsb2FkRGF5LCBzZXRVcGxvYWREYXldID0gdXNlU3RhdGU8bnVtYmVyPigxKTtcclxuICBjb25zdCBbdXBsb2FkUGFuY2hheWF0LCBzZXRVcGxvYWRQYW5jaGF5YXRdID0gdXNlU3RhdGU8c3RyaW5nPihwYW5jaGF5YXRzWzBdPy5pZCB8fCAndmVkYWtrYXR0YW1hZHV2dScpO1xyXG4gIGNvbnN0IFt1cGxvYWRWaWxsYWdlLCBzZXRVcGxvYWRWaWxsYWdlXSA9IHVzZVN0YXRlPHN0cmluZz4oJ0FtbWFwZXR0YWknKTtcclxuICBjb25zdCBbdXBsb2FkRGF0ZSwgc2V0VXBsb2FkRGF0ZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdKTtcclxuICBjb25zdCBbdXBsb2FkVXBsb2FkZXIsIHNldFVwbG9hZFVwbG9hZGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oJ1JhaHVsIEsuJyk7XHJcbiAgY29uc3QgW3VwbG9hZENhcHRpb24sIHNldFVwbG9hZENhcHRpb25dID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XHJcbiAgY29uc3QgW2lzVXBsb2FkaW5nLCBzZXRJc1VwbG9hZGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XHJcbiAgY29uc3QgW3VwbG9hZEVycm9yLCBzZXRVcGxvYWRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XHJcbiAgY29uc3Qgc2hvd0NsdXN0ZXJMYW5kaW5nID0gYWN0aXZlUm9sZSA9PT0gJ1N1cGVyIEFkbWluJyAmJiBzZWxlY3RlZENsdXN0ZXIgPT09ICdhbGwnO1xyXG4gIGNvbnN0IHBob3RvQ2x1c3RlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGtub3duID0gY2x1c3RlcnMubWFwKChjbHVzdGVyKSA9PiAoeyBpZDogY2x1c3Rlci5pZCwgbmFtZTogY2x1c3Rlci5uYW1lIH0pKTtcclxuICAgIGNvbnN0IGtub3duSWRzID0gbmV3IFNldChrbm93bi5tYXAoKGNsdXN0ZXIpID0+IGNsdXN0ZXIuaWQudG9Mb3dlckNhc2UoKSkpO1xyXG4gICAgcGhvdG9zLmZvckVhY2goKHBob3RvKSA9PiB7XHJcbiAgICAgIGlmICgha25vd25JZHMuaGFzKHBob3RvLmNsdXN0ZXJJZC50b0xvd2VyQ2FzZSgpKSkge1xyXG4gICAgICAgIGtub3duLnB1c2goeyBpZDogcGhvdG8uY2x1c3RlcklkLCBuYW1lOiBwaG90by5jbHVzdGVyTmFtZSB8fCBwaG90by5jbHVzdGVySWQgfSk7XHJcbiAgICAgICAga25vd25JZHMuYWRkKHBob3RvLmNsdXN0ZXJJZC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4ga25vd247XHJcbiAgfSwgW2NsdXN0ZXJzLCBwaG90b3NdKTtcclxuXHJcbiAgLy8gU3luYyByb2xlIGNoYW5nZXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0QWN0aXZlUm9sZSh1c2VyUm9sZSk7XHJcbiAgICBpZiAodXNlclJvbGUgPT09ICdDbHVzdGVyIEFkbWluJykge1xyXG4gICAgICBzZXRTZWxlY3RlZENsdXN0ZXIoJ0RoYXJtYXB1cmknKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQ2x1c3RlcignYWxsJyk7XHJcbiAgICB9XHJcbiAgfSwgW3VzZXJSb2xlXSk7XHJcblxyXG4gIC8vIEZldGNoIHBob3RvcyBmcm9tIHNlcnZlclxyXG4gIGNvbnN0IGZldGNoUGhvdG9zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0TG9hZEVycm9yKG51bGwpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY2x1c3RlclBhcmFtID0gYWN0aXZlUm9sZSA9PT0gJ0NsdXN0ZXIgQWRtaW4nID8gJ2RoYXJtYXB1cmknIDogc2VsZWN0ZWRDbHVzdGVyLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGFwaVVybChgL2FwaS9zZXNzaW9uLXBob3Rvcz9jbHVzdGVyPSR7Y2x1c3RlclBhcmFtfSZyb2xlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGFjdGl2ZVJvbGUpfWApLCB7XHJcbiAgICAgICAgY2FjaGU6ICduby1zdG9yZScsXHJcbiAgICAgICAgaGVhZGVyczogYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9LFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKCFyZXMub2spIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFNlcnZlciByZXR1cm5lZCAke3Jlcy5zdGF0dXN9YCk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcblxyXG4gICAgICBpZiAoZGF0YS5zdWNjZXNzICYmIEFycmF5LmlzQXJyYXkoZGF0YS5waG90b3MpKSB7XHJcbiAgICAgICAgc2V0UGhvdG9zKGRhdGEucGhvdG9zKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRQaG90b3MoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gbG9hZCBwaG90b3M6JywgZXJyKTtcclxuICAgICAgc2V0TG9hZEVycm9yKCdGYWlsZWQgdG8gY29ubmVjdCB0byBiYWNrZW5kIHNlcnZlciBmb3IgcGhvdG9zLiBSZXRyeWluZy4uLicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hQaG90b3MoKTtcclxuICB9LCBbYWN0aXZlUm9sZSwgc2VsZWN0ZWRDbHVzdGVyLCBhdXRoVG9rZW5dKTtcclxuXHJcbiAgLy8gRHluYW1pYyB2aWxsYWdlcyBmb3IgZmlsdGVyXHJcbiAgY29uc3QgY3VycmVudEZpbHRlclZpbGxhZ2VzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRQYW5jaGF5YXQgPT09ICdhbGwnKSB7XHJcbiAgICAgIGNvbnN0IGFsbFZpbGxhZ2VzOiB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9W10gPSBbXTtcclxuICAgICAgcGFuY2hheWF0cy5mb3JFYWNoKChwKSA9PiB7XHJcbiAgICAgICAgcC52aWxsYWdlcz8uZm9yRWFjaCgodikgPT4ge1xyXG4gICAgICAgICAgaWYgKCFhbGxWaWxsYWdlcy5zb21lKChleGlzdGluZykgPT4gZXhpc3RpbmcubmFtZSA9PT0gdi5uYW1lKSkge1xyXG4gICAgICAgICAgICBhbGxWaWxsYWdlcy5wdXNoKHsgaWQ6IHYuaWQsIG5hbWU6IHYubmFtZSB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiBhbGxWaWxsYWdlcztcclxuICAgIH1cclxuICAgIGNvbnN0IGZvdW5kID0gcGFuY2hheWF0cy5maW5kKChwKSA9PiBwLmlkID09PSBzZWxlY3RlZFBhbmNoYXlhdCB8fCBwLm5hbWUgPT09IHNlbGVjdGVkUGFuY2hheWF0KTtcclxuICAgIHJldHVybiBmb3VuZD8udmlsbGFnZXMgfHwgW107XHJcbiAgfSwgW3NlbGVjdGVkUGFuY2hheWF0LCBwYW5jaGF5YXRzXSk7XHJcblxyXG4gIC8vIFVwZGF0ZSB1cGxvYWQgdmlsbGFnZSB3aGVuIHVwbG9hZCBwYW5jaGF5YXQgY2hhbmdlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZFAgPSBwYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IHVwbG9hZFBhbmNoYXlhdCB8fCBwLm5hbWUgPT09IHVwbG9hZFBhbmNoYXlhdCk7XHJcbiAgICBpZiAoc2VsZWN0ZWRQICYmIHNlbGVjdGVkUC52aWxsYWdlcyAmJiBzZWxlY3RlZFAudmlsbGFnZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICBzZXRVcGxvYWRWaWxsYWdlKHNlbGVjdGVkUC52aWxsYWdlc1swXS5uYW1lKTtcclxuICAgIH1cclxuICB9LCBbdXBsb2FkUGFuY2hheWF0LCBwYW5jaGF5YXRzXSk7XHJcblxyXG4gIC8vIERheXMgMSB0aHJvdWdoIDggU3VtbWFyeVxyXG4gIGNvbnN0IGRheVN1bW1hcmllczogRGF5UGhvdG9TdW1tYXJ5W10gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHRhcmdldENsdXN0ZXJQaG90b3MgPSBwaG90b3MuZmlsdGVyKFxyXG4gICAgICAocCkgPT5cclxuICAgICAgICBhY3RpdmVSb2xlID09PSAnQ2x1c3RlciBBZG1pbicgfHxcclxuICAgICAgICBzZWxlY3RlZENsdXN0ZXIgPT09ICdhbGwnIHx8XHJcbiAgICAgICAgcC5jbHVzdGVySWQudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRDbHVzdGVyLnRvTG93ZXJDYXNlKClcclxuICAgICk7XHJcblxyXG4gICAgY29uc3Qgc3VtbWFyaWVzOiBEYXlQaG90b1N1bW1hcnlbXSA9IFtdO1xyXG5cclxuICAgIGZvciAobGV0IGRheSA9IDE7IGRheSA8PSA4OyBkYXkrKykge1xyXG4gICAgICBjb25zdCBkYXlQaG90b3MgPSB0YXJnZXRDbHVzdGVyUGhvdG9zLmZpbHRlcigocCkgPT4gcC5kYXlOdW1iZXIgPT09IGRheSk7XHJcbiAgICAgIGNvbnN0IHVuaXF1ZVBhbmNoYXlhdHMgPSBuZXcgU2V0KGRheVBob3Rvcy5tYXAoKHApID0+IHAucGFuY2hheWF0SWQpKS5zaXplO1xyXG4gICAgICBjb25zdCB0YXJnZXRDb3VudCA9IDUwO1xyXG5cclxuICAgICAgc3VtbWFyaWVzLnB1c2goe1xyXG4gICAgICAgIGRheU51bWJlcjogZGF5LFxyXG4gICAgICAgIGRheUxhYmVsOiBgRGF5ICR7ZGF5fWAsXHJcbiAgICAgICAgZGF0ZTogYDIwMjYtMDgtJHsxNSArIGRheX1gLFxyXG4gICAgICAgIHBob3Rvc0NvdW50OiBkYXlQaG90b3MubGVuZ3RoLFxyXG4gICAgICAgIHRhcmdldENvdW50LFxyXG4gICAgICAgIHBhbmNoYXlhdENvdmVyYWdlOiB1bmlxdWVQYW5jaGF5YXRzLFxyXG4gICAgICAgIGZlYXR1cmVkUGhvdG9zOiBkYXlQaG90b3Muc2xpY2UoMCwgNCksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBzdW1tYXJpZXM7XHJcbiAgfSwgW3Bob3Rvcywgc2VsZWN0ZWRDbHVzdGVyLCBhY3RpdmVSb2xlXSk7XHJcblxyXG4gIC8vIEZpbHRlcmVkIFBob3RvcyBmb3IgR2FsbGVyeSBWaWV3XHJcbiAgY29uc3QgZmlsdGVyZWRQaG90b3MgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBwaG90b3MuZmlsdGVyKChwKSA9PiB7XHJcbiAgICAgIC8vIENsdXN0ZXIgZmlsdGVyXHJcbiAgICAgIGNvbnN0IG1hdGNoQ2x1c3RlciA9XHJcbiAgICAgICAgYWN0aXZlUm9sZSA9PT0gJ0NsdXN0ZXIgQWRtaW4nXHJcbiAgICAgICAgICA/IHAuY2x1c3RlcklkLnRvTG93ZXJDYXNlKCkgPT09ICdkaGFybWFwdXJpJ1xyXG4gICAgICAgICAgOiBzZWxlY3RlZENsdXN0ZXIgPT09ICdhbGwnIHx8IHAuY2x1c3RlcklkLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkQ2x1c3Rlci50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgLy8gRGF5IFRhYiBmaWx0ZXJcclxuICAgICAgY29uc3QgbWF0Y2hEYXkgPSBzZWxlY3RlZERheVRhYiA9PT0gJ2FsbCcgfHwgcC5kYXlOdW1iZXIgPT09IHNlbGVjdGVkRGF5VGFiO1xyXG5cclxuICAgICAgLy8gUGFuY2hheWF0IGZpbHRlclxyXG4gICAgICBjb25zdCBtYXRjaFBhbmNoYXlhdCA9XHJcbiAgICAgICAgc2VsZWN0ZWRQYW5jaGF5YXQgPT09ICdhbGwnIHx8XHJcbiAgICAgICAgcC5wYW5jaGF5YXRJZC50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFBhbmNoYXlhdC50b0xvd2VyQ2FzZSgpIHx8XHJcbiAgICAgICAgcC5wYW5jaGF5YXROYW1lLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkUGFuY2hheWF0LnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAvLyBWaWxsYWdlIGZpbHRlclxyXG4gICAgICBjb25zdCBtYXRjaFZpbGxhZ2UgPVxyXG4gICAgICAgIHNlbGVjdGVkVmlsbGFnZSA9PT0gJ2FsbCcgfHxcclxuICAgICAgICAocC52aWxsYWdlTmFtZSB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRWaWxsYWdlLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAvLyBTZWFyY2ggUXVlcnlcclxuICAgICAgY29uc3QgcSA9IHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkudHJpbSgpO1xyXG4gICAgICBjb25zdCBtYXRjaFNlYXJjaCA9XHJcbiAgICAgICAgIXEgfHxcclxuICAgICAgICBwLnNlc3Npb25UaXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpIHx8XHJcbiAgICAgICAgcC5wYW5jaGF5YXROYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcclxuICAgICAgICBwLnZpbGxhZ2VOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcclxuICAgICAgICBwLnVwbG9hZGVkQnkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSB8fFxyXG4gICAgICAgIHAub3JpZ2luYWxGaWxlbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpO1xyXG5cclxuICAgICAgcmV0dXJuIG1hdGNoQ2x1c3RlciAmJiBtYXRjaERheSAmJiBtYXRjaFBhbmNoYXlhdCAmJiBtYXRjaFZpbGxhZ2UgJiYgbWF0Y2hTZWFyY2g7XHJcbiAgICB9KTtcclxuICB9LCBbcGhvdG9zLCBzZWxlY3RlZENsdXN0ZXIsIGFjdGl2ZVJvbGUsIHNlbGVjdGVkRGF5VGFiLCBzZWxlY3RlZFBhbmNoYXlhdCwgc2VsZWN0ZWRWaWxsYWdlLCBzZWFyY2hRdWVyeV0pO1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBaSVAgRE9XTkxPQUQgSEFORExFUiBXSVRIIFJFQUwgUFJPR1JFU1NcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBoYW5kbGVEb3dubG9hZFppcCA9IGFzeW5jIChcclxuICAgIHR5cGU6ICdkYXknIHwgJ2NsdXN0ZXItYWxsLWRheXMnIHwgJ2FsbC1jbHVzdGVycycgfCAnZmlsdGVyZWQnLFxyXG4gICAgZGF5TnVtYmVyPzogbnVtYmVyXHJcbiAgKSA9PiB7XHJcbiAgICAvLyBVbmlxdWUga2V5IHRvIHRyYWNrIGJ1dHRvbiBzdGF0ZSBhbmQgcHJldmVudCBkb3VibGUtY2xpY2tzXHJcbiAgICBjb25zdCBrZXkgPVxyXG4gICAgICB0eXBlID09PSAnZGF5J1xyXG4gICAgICAgID8gYGRheS0ke2RheU51bWJlcn1gXHJcbiAgICAgICAgOiB0eXBlID09PSAnY2x1c3Rlci1hbGwtZGF5cydcclxuICAgICAgICA/IGBjbHVzdGVyLSR7c2VsZWN0ZWRDbHVzdGVyfWBcclxuICAgICAgICA6IHR5cGUgPT09ICdhbGwtY2x1c3RlcnMnXHJcbiAgICAgICAgPyAnYWxsLWNsdXN0ZXJzJ1xyXG4gICAgICAgIDogJ2ZpbHRlcmVkJztcclxuXHJcbiAgICBpZiAoZG93bmxvYWRpbmdaaXBLZXkpIHtcclxuICAgICAgY29uc29sZS53YXJuKCdBbm90aGVyIFpJUCBkb3dubG9hZCBpcyBhbHJlYWR5IGluIHByb2dyZXNzLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RG93bmxvYWRpbmdaaXBLZXkoa2V5KTtcclxuICAgIHNldENvbXBsZXRlZFppcEtleShudWxsKTtcclxuXHJcbiAgICAvLyBTdGVwcGVkIFByb2dyZXNzIFNpbXVsYXRpb25cclxuICAgIHNldFppcFByb2dyZXNzKHtcclxuICAgICAgc3RhZ2U6ICdwcmVwYXJpbmcnLFxyXG4gICAgICBtZXNzYWdlOiAnUHJlcGFyaW5nIFpJUCByZXF1ZXN0Li4uJyxcclxuICAgICAgcHJvZ3Jlc3NQZXJjZW50OiAxNSxcclxuICAgIH0pO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDI1MCkpO1xyXG5cclxuICAgICAgc2V0WmlwUHJvZ3Jlc3Moe1xyXG4gICAgICAgIHN0YWdlOiAnY29sbGVjdGluZycsXHJcbiAgICAgICAgbWVzc2FnZTogJ0NvbGxlY3Rpbmcgb3JpZ2luYWwgc2Vzc2lvbiBwaG90b3MgZnJvbSBzdG9yYWdlLi4uJyxcclxuICAgICAgICBwcm9ncmVzc1BlcmNlbnQ6IDQwLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDMwMCkpO1xyXG5cclxuICAgICAgc2V0WmlwUHJvZ3Jlc3Moe1xyXG4gICAgICAgIHN0YWdlOiAnY3JlYXRpbmcnLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdHZW5lcmF0aW5nIGNvbXByZXNzZWQgWklQIGFyY2hpdmUgb24gYmFja2VuZC4uLicsXHJcbiAgICAgICAgcHJvZ3Jlc3NQZXJjZW50OiA3MCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBDb25zdHJ1Y3QgVVJMIHBhcmFtZXRlcnNcclxuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKCd0eXBlJywgdHlwZSk7XHJcbiAgICAgIHBhcmFtcy5hcHBlbmQoXHJcbiAgICAgICAgJ2NsdXN0ZXInLFxyXG4gICAgICAgIGFjdGl2ZVJvbGUgPT09ICdDbHVzdGVyIEFkbWluJyA/ICdkaGFybWFwdXJpJyA6IHNlbGVjdGVkQ2x1c3RlclxyXG4gICAgICApO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKCd1c2VyUm9sZScsIGFjdGl2ZVJvbGUpO1xyXG5cclxuICAgICAgaWYgKHR5cGUgPT09ICdkYXknICYmIGRheU51bWJlcikge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoJ2RheU51bWJlcicsIFN0cmluZyhkYXlOdW1iZXIpKTtcclxuICAgICAgfSBlbHNlIGlmICh0eXBlID09PSAnZmlsdGVyZWQnKSB7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkRGF5VGFiICE9PSAnYWxsJykgcGFyYW1zLmFwcGVuZCgnZGF5TnVtYmVyJywgU3RyaW5nKHNlbGVjdGVkRGF5VGFiKSk7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkUGFuY2hheWF0ICE9PSAnYWxsJykgcGFyYW1zLmFwcGVuZCgncGFuY2hheWF0SWQnLCBzZWxlY3RlZFBhbmNoYXlhdCk7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkVmlsbGFnZSAhPT0gJ2FsbCcpIHBhcmFtcy5hcHBlbmQoJ3ZpbGxhZ2UnLCBzZWxlY3RlZFZpbGxhZ2UpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB6aXBVcmwgPSBhcGlVcmwoYC9hcGkvc2Vzc2lvbi1waG90b3MvZG93bmxvYWQtemlwPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCk7XHJcblxyXG4gICAgICBzZXRaaXBQcm9ncmVzcyh7XHJcbiAgICAgICAgc3RhZ2U6ICdkb3dubG9hZGluZycsXHJcbiAgICAgICAgbWVzc2FnZTogJ1N0cmVhbWluZyBaSVAgcGFja2FnZSB0byB5b3VyIGRldmljZS4uLicsXHJcbiAgICAgICAgcHJvZ3Jlc3NQZXJjZW50OiA5MCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBQZXJmb3JtIEZldGNoIHRvIHRyaWdnZXIgZG93bmxvYWRcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh6aXBVcmwpO1xyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JKc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+ICh7fSkpO1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgIGVycm9ySnNvbi5lcnJvciB8fCAnVW5hYmxlIHRvIGNyZWF0ZSB0aGUgWklQIGZpbGUuIFBsZWFzZSB0cnkgYWdhaW4uJ1xyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEV4dHJhY3QgZmlsZW5hbWUgZnJvbSBoZWFkZXJcclxuICAgICAgbGV0IGRvd25sb2FkRmlsZW5hbWUgPSAnVFFJX1Nlc3Npb25fUGhvdG9zLnppcCc7XHJcbiAgICAgIGNvbnN0IGRpc3Bvc2l0aW9uID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ0NvbnRlbnQtRGlzcG9zaXRpb24nKTtcclxuICAgICAgaWYgKGRpc3Bvc2l0aW9uICYmIGRpc3Bvc2l0aW9uLmluY2x1ZGVzKCdmaWxlbmFtZT0nKSkge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoID0gZGlzcG9zaXRpb24ubWF0Y2goL2ZpbGVuYW1lPVwiPyhbXlwiXSspXCI/Lyk7XHJcbiAgICAgICAgaWYgKG1hdGNoICYmIG1hdGNoWzFdKSB7XHJcbiAgICAgICAgICBkb3dubG9hZEZpbGVuYW1lID0gbWF0Y2hbMV07XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcG9uc2UuYmxvYigpO1xyXG4gICAgICBjb25zdCBibG9iVXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgIGxpbmsuaHJlZiA9IGJsb2JVcmw7XHJcbiAgICAgIGxpbmsuZG93bmxvYWQgPSBkb3dubG9hZEZpbGVuYW1lO1xyXG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xyXG4gICAgICBsaW5rLmNsaWNrKCk7XHJcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XHJcbiAgICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKGJsb2JVcmwpO1xyXG5cclxuICAgICAgLy8gU3VjY2VzcyBTdGF0ZVxyXG4gICAgICBzZXRaaXBQcm9ncmVzcyh7XHJcbiAgICAgICAgc3RhZ2U6ICdjb21wbGV0ZWQnLFxyXG4gICAgICAgIG1lc3NhZ2U6ICdaSVAgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkuJyxcclxuICAgICAgICBwcm9ncmVzc1BlcmNlbnQ6IDEwMCxcclxuICAgICAgICB6aXBGaWxlbmFtZTogZG93bmxvYWRGaWxlbmFtZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldENvbXBsZXRlZFppcEtleShrZXkpO1xyXG5cclxuICAgICAgLy8gQXV0byBjbGVhciBwcm9ncmVzcyBiYW5uZXIgYWZ0ZXIgNCBzZWNvbmRzXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldFppcFByb2dyZXNzKHtcclxuICAgICAgICAgIHN0YWdlOiAnaWRsZScsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnJyxcclxuICAgICAgICAgIHByb2dyZXNzUGVyY2VudDogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgfSwgNDAwMCk7XHJcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdaSVAgZG93bmxvYWQgZmFpbGVkOicsIGVycik7XHJcbiAgICAgIHNldFppcFByb2dyZXNzKHtcclxuICAgICAgICBzdGFnZTogJ2Vycm9yJyxcclxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSB8fCAnVW5hYmxlIHRvIGNyZWF0ZSB0aGUgWklQIGZpbGUuIFBsZWFzZSB0cnkgYWdhaW4uJyxcclxuICAgICAgICBwcm9ncmVzc1BlcmNlbnQ6IDAsXHJcbiAgICAgICAgZXJyb3JNZXNzYWdlOiBlcnIubWVzc2FnZSB8fCAnVW5hYmxlIHRvIGNyZWF0ZSB0aGUgWklQIGZpbGUuIFBsZWFzZSB0cnkgYWdhaW4uJyxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXREb3dubG9hZGluZ1ppcEtleShudWxsKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBTSU5HTEUgUEhPVE8gQUNUSU9OU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkU2luZ2xlUGhvdG8gPSAocGhvdG86IFNlc3Npb25QaG90b0l0ZW0pID0+IHtcclxuICAgIGNvbnN0IGRvd25sb2FkVXJsID0gYXBpVXJsKGAvYXBpL3Nlc3Npb24tcGhvdG9zLyR7cGhvdG8uaWR9L2Rvd25sb2FkYCk7XHJcbiAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgbGluay5ocmVmID0gZG93bmxvYWRVcmw7XHJcbiAgICBsaW5rLmRvd25sb2FkID0gcGhvdG8ub3JpZ2luYWxGaWxlbmFtZSB8fCBgUGhvdG9fJHtwaG90by5pZH0uanBnYDtcclxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XHJcbiAgICBsaW5rLmNsaWNrKCk7XHJcbiAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVBob3RvID0gYXN5bmMgKHBob3RvOiBTZXNzaW9uUGhvdG9JdGVtKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChhcGlVcmwoYC9hcGkvc2Vzc2lvbi1waG90b3MvJHtwaG90by5pZH1gKSwge1xyXG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgaGVhZGVyczogYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9LFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKCFyZXMub2spIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBkZWxldGUgcGhvdG8uJyk7XHJcbiAgICAgIH1cclxuICAgICAgc2V0UGhvdG9zKChwcmV2KSA9PiBwcmV2LmZpbHRlcigocCkgPT4gcC5pZCAhPT0gcGhvdG8uaWQpKTtcclxuICAgICAgc2V0UGhvdG9Ub0RlbGV0ZShudWxsKTtcclxuICAgICAgaWYgKHNlbGVjdGVkUGhvdG8gJiYgc2VsZWN0ZWRQaG90by5pZCA9PT0gcGhvdG8uaWQpIHtcclxuICAgICAgICBzZXRTZWxlY3RlZFBob3RvKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoJ0ZhaWxlZCB0byBkZWxldGUgcGhvdG8uIFBsZWFzZSB0cnkgYWdhaW4uJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gUEhPVE8gVVBMT0FEIEhBTkRMRVJcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBjb25zdCBoYW5kbGVVcGxvYWRTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAodXBsb2FkRmlsZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHNldFVwbG9hZEVycm9yKCdQbGVhc2Ugc2VsZWN0IGF0IGxlYXN0IG9uZSBwaG90b2dyYXBoIHRvIHVwbG9hZC4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzVXBsb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0VXBsb2FkRXJyb3IobnVsbCk7XHJcblxyXG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnY2x1c3RlcklkJywgc2VsZWN0ZWRDbHVzdGVyLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdjbHVzdGVyTmFtZScsIHNlbGVjdGVkQ2x1c3Rlcik7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3Nlc3Npb25UaXRsZScsIHVwbG9hZFRpdGxlKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnZGF5TnVtYmVyJywgU3RyaW5nKHVwbG9hZERheSkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdkYXRlJywgdXBsb2FkRGF0ZSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3BhbmNoYXlhdElkJywgdXBsb2FkUGFuY2hheWF0KTtcclxuXHJcbiAgICBjb25zdCBmb3VuZFAgPSBwYW5jaGF5YXRzLmZpbmQoKHApID0+IHAuaWQgPT09IHVwbG9hZFBhbmNoYXlhdCB8fCBwLm5hbWUgPT09IHVwbG9hZFBhbmNoYXlhdCk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3BhbmNoYXlhdE5hbWUnLCBmb3VuZFAgPyBmb3VuZFAubmFtZSA6IHVwbG9hZFBhbmNoYXlhdCk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3ZpbGxhZ2VOYW1lJywgdXBsb2FkVmlsbGFnZSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3VwbG9hZGVkQnknLCB1cGxvYWRVcGxvYWRlcik7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ3VwbG9hZGVkUm9sZScsIGFjdGl2ZVJvbGUpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKCdjYXB0aW9uJywgdXBsb2FkQ2FwdGlvbik7XHJcblxyXG4gICAgdXBsb2FkRmlsZXMuZm9yRWFjaCgoZmlsZSkgPT4ge1xyXG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3Bob3RvcycsIGZpbGUpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYXBpVXJsKCcvYXBpL3Nlc3Npb24tcGhvdG9zL3VwbG9hZCcpLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogYXV0aFRva2VuID8geyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7YXV0aFRva2VufWAgfSA6IHt9LFxyXG4gICAgICAgIGJvZHk6IGZvcm1EYXRhLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICBpZiAoIXJlcy5vayB8fCAhZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGRhdGEuZXJyb3IgfHwgJ1VwbG9hZCBmYWlsZWQuJyk7XHJcbiAgICAgIH1cclxuXHJcblxyXG4gICAgICAvLyBBZGQgbmV3IHBob3RvcyB0byBsb2NhbCBzdGF0ZVxyXG4gICAgICBpZiAoZGF0YS5waG90b3MgJiYgQXJyYXkuaXNBcnJheShkYXRhLnBob3RvcykpIHtcclxuICAgICAgICBzZXRQaG90b3MoKHByZXYpID0+IFsuLi5kYXRhLnBob3RvcywgLi4ucHJldl0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRVcGxvYWRGaWxlcyhbXSk7XHJcbiAgICAgIHNldFVwbG9hZENhcHRpb24oJycpO1xyXG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignVXBsb2FkIGZhaWxlZDonLCBlcnIpO1xyXG4gICAgICBzZXRVcGxvYWRFcnJvcihlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIHVwbG9hZCBwaG90b2dyYXBocy4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzVXBsb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBRdWljayBPcGVuIFVwbG9hZCBmb3Igc3BlY2lmaWMgZGF5XHJcbiAgY29uc3QgaGFuZGxlT3BlblVwbG9hZEZvckRheSA9IChkYXk6IG51bWJlcikgPT4ge1xyXG4gICAgc2V0VXBsb2FkRGF5KGRheSk7XHJcbiAgICBzZXRTaG93VXBsb2FkTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgaWYgKGFjdGl2ZVJvbGUgPT09ICdTdXBlciBBZG1pbicgJiYgc2VsZWN0ZWRDbHVzdGVyICE9PSAnYWxsJyAmJiBzZWxlY3RlZERheVRhYiAhPT0gJ2FsbCcpIHtcclxuICAgIGNvbnN0IHNlbGVjdGVkRGF5UGhvdG9zID0gcGhvdG9zLmZpbHRlcihcclxuICAgICAgKHBob3RvKSA9PiBwaG90by5jbHVzdGVySWQudG9Mb3dlckNhc2UoKSA9PT0gc2VsZWN0ZWRDbHVzdGVyLnRvTG93ZXJDYXNlKCkgJiYgcGhvdG8uZGF5TnVtYmVyID09PSBzZWxlY3RlZERheVRhYixcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbWF4LXctN3hsIG14LWF1dG8gcGItMTYgZm9udC1zYW5zXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBwYi01XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRDbHVzdGVyKCdhbGwnKX0gY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1bIzBCM0Q5MV1cIj5TZXNzaW9uIFBob3RvczwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxzcGFuPi88L3NwYW4+PHNwYW4+e3NlbGVjdGVkQ2x1c3Rlcn08L3NwYW4+PHNwYW4+Lzwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyMwQjNEOTFdXCI+RGF5IHtzZWxlY3RlZERheVRhYn08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e3NlbGVjdGVkQ2x1c3Rlcn0gLSBEYXkge3NlbGVjdGVkRGF5VGFifSBQaG90b3M8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIG10LTFcIj5SZXZpZXcgdGhlIHJlYWwgcGhvdG8gcmVjb3JkcyBzdWJtaXR0ZWQgZm9yIHRoaXMgZGF5LjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4geyBzZXRTZWxlY3RlZERheVRhYignYWxsJyk7IHNldEV4cGFuZGVkRGF5KG51bGwpOyB9fSBjbGFzc05hbWU9XCJweC0zIHB5LTIgcm91bmRlZC1tZCBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwXCI+QmFjayB0byBEYXlzPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgIDxzcGFuPntzZWxlY3RlZERheVBob3Rvcy5sZW5ndGh9IHBob3RvIHJlY29yZHM8L3NwYW4+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17IXNlbGVjdGVkRGF5UGhvdG9zLmxlbmd0aH0gb25DbGljaz17KCkgPT4gaGFuZGxlRG93bmxvYWRaaXAoJ2RheScsIHNlbGVjdGVkRGF5VGFiKX0gY2xhc3NOYW1lPVwicHgtMyBweS0yIHJvdW5kZWQtbWQgYmctWyMwQjNEOTFdIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgZGlzYWJsZWQ6Ymctc2xhdGUtMjAwIGRpc2FibGVkOnRleHQtc2xhdGUtNDAwXCI+RG93bmxvYWQgRGF5IHtzZWxlY3RlZERheVRhYn0gWklQPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtzZWxlY3RlZERheVBob3Rvcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTIwIHRleHQtY2VudGVyIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPk5vIHBob3RvcyBhcmUgYXZhaWxhYmxlIGZvciBEYXkge3NlbGVjdGVkRGF5VGFifS48L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgIHtzZWxlY3RlZERheVBob3Rvcy5tYXAoKHBob3RvKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGFydGljbGUga2V5PXtwaG90by5pZH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBwLTQgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPjxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB0cnVuY2F0ZVwiPntwaG90by5vcmlnaW5hbEZpbGVuYW1lfTwvaDI+PHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xXCI+e3Bob3RvLmNhcHRpb24gfHwgcGhvdG8uc2Vzc2lvblRpdGxlfTwvcD48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMSByb3VuZGVkIGJnLWJsdWUtNTAgdGV4dC1bIzBCM0Q5MV1cIj5EYXkge3Bob3RvLmRheU51bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlVwbG9hZGVkIGJ5IHtwaG90by51cGxvYWRlZEJ5IHx8ICdDbHVzdGVyIEFkbWluJ308L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBtdC0zXCI+PGEgaHJlZj17cGhvdG8uZmlsZVVybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LWNlbnRlciBweC0zIHB5LTIgcm91bmRlZC1tZCBiZy1bIzBCM0Q5MV0gdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZFwiPlZpZXcgUGhvdG9zPC9hPjxhIGhyZWY9e3Bob3RvLmZpbGVVcmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIiBkb3dubG9hZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgcm91bmRlZC1tZCBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGRcIj5Eb3dubG9hZDwvYT48L2Rpdj5cclxuICAgICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktNiBwYi0xNiBmb250LXNhbnNcIj5cclxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgMS4gQ0FSRExFU1MgUEFHRSBIRUFERVIgKE1BSU4gSEVBRElORyBPTkxZKVxyXG4gICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIFNlc3Npb24gUGhvdG9ncmFwaHMgJmFtcDsgWklQIEFyY2hpdmVzXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1icmFuZC01MCBweC0yLjUgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWJyYW5kLTYwMCBib3JkZXIgYm9yZGVyLWJyYW5kLTIwMCBkYXJrOmJnLWJyYW5kLTk1MC80MCBkYXJrOnRleHQtYnJhbmQtNDAwIGRhcms6Ym9yZGVyLWJyYW5kLTgwMFwiPlxyXG4gICAgICAgICAgICAgIHtzZWxlY3RlZENsdXN0ZXJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogSGVhZGVyIEFjdGlvbiBCdXR0b25zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yLjUgc2VsZi1zdGFydCBzbTpzZWxmLWF1dG9cIj5cclxuICAgICAgICAgIHsvKiBTdXBlciBBZG1pbjogRG93bmxvYWQgQWxsIENsdXN0ZXJzIFpJUCAqL31cclxuICAgICAgICAgIHthY3RpdmVSb2xlID09PSAnU3VwZXIgQWRtaW4nICYmIChcclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGlkPVwiZG93bmxvYWQtYWxsLWNsdXN0ZXJzLXppcC1idG5cIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtkb3dubG9hZGluZ1ppcEtleSAhPT0gbnVsbH1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb3dubG9hZFppcCgnYWxsLWNsdXN0ZXJzJyl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHNoYWRvdy10aGVtZS14cyB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICBkb3dubG9hZGluZ1ppcEtleSA9PT0gJ2FsbC1jbHVzdGVycydcclxuICAgICAgICAgICAgICAgICAgPyAnYmctZ3JheS0yMDAgdGV4dC1ncmF5LTUwMCBjdXJzb3Itbm90LWFsbG93ZWQnXHJcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXN1Y2Nlc3MtNjAwIGhvdmVyOmJnLXN1Y2Nlc3MtNzAwIHRleHQtd2hpdGUgYWN0aXZlOnNjYWxlLVswLjk4XSdcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMThweF1cIj5cclxuICAgICAgICAgICAgICAgIHtkb3dubG9hZGluZ1ppcEtleSA9PT0gJ2FsbC1jbHVzdGVycycgPyAnc3luYycgOiAnZm9sZGVyX3ppcCd9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIHtkb3dubG9hZGluZ1ppcEtleSA9PT0gJ2FsbC1jbHVzdGVycydcclxuICAgICAgICAgICAgICAgID8gJ0NyZWF0aW5nIFpJUC4uLidcclxuICAgICAgICAgICAgICAgIDogY29tcGxldGVkWmlwS2V5ID09PSAnYWxsLWNsdXN0ZXJzJ1xyXG4gICAgICAgICAgICAgICAgPyAnRG93bmxvYWQgQWxsIENsdXN0ZXJzIEFnYWluJ1xyXG4gICAgICAgICAgICAgICAgOiAnRG93bmxvYWQgQWxsIENsdXN0ZXJzIChaSVApJ31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBDbHVzdGVyIExldmVsOiBEb3dubG9hZCBBbGwgOCBEYXlzIFpJUCAqL31cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgaWQ9XCJkb3dubG9hZC1hbGwtOC1kYXlzLXppcC1idG5cIlxyXG4gICAgICAgICAgICBkaXNhYmxlZD17ZG93bmxvYWRpbmdaaXBLZXkgIT09IG51bGx9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvd25sb2FkWmlwKCdjbHVzdGVyLWFsbC1kYXlzJyl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctdGhlbWUteHMgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xyXG4gICAgICAgICAgICAgIGRvd25sb2FkaW5nWmlwS2V5ID09PSBgY2x1c3Rlci0ke3NlbGVjdGVkQ2x1c3Rlcn1gXHJcbiAgICAgICAgICAgICAgICA/ICdiZy1ncmF5LTIwMCB0ZXh0LWdyYXktNTAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgICAgIDogJ2JnLWJyYW5kLTUwMCBob3ZlcjpiZy1icmFuZC02MDAgdGV4dC13aGl0ZSBhY3RpdmU6c2NhbGUtWzAuOThdJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxOHB4XVwiPlxyXG4gICAgICAgICAgICAgIHtkb3dubG9hZGluZ1ppcEtleSA9PT0gYGNsdXN0ZXItJHtzZWxlY3RlZENsdXN0ZXJ9YCA/ICdzeW5jJyA6ICdjbG91ZF9kb3dubG9hZCd9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAge2Rvd25sb2FkaW5nWmlwS2V5ID09PSBgY2x1c3Rlci0ke3NlbGVjdGVkQ2x1c3Rlcn1gXHJcbiAgICAgICAgICAgICAgPyAnQ3JlYXRpbmcgWklQLi4uJ1xyXG4gICAgICAgICAgICAgIDogY29tcGxldGVkWmlwS2V5ID09PSBgY2x1c3Rlci0ke3NlbGVjdGVkQ2x1c3Rlcn1gXHJcbiAgICAgICAgICAgICAgPyBgRG93bmxvYWQgJHtzZWxlY3RlZENsdXN0ZXJ9IEFnYWluYFxyXG4gICAgICAgICAgICAgIDogYERvd25sb2FkIEFsbCA4IERheXMgKCR7c2VsZWN0ZWRDbHVzdGVyfSlgfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgey8qIFVwbG9hZCBQaG90b3MgQnV0dG9uICovfVxyXG4gICAgICAgICAge2FjdGl2ZVJvbGUgIT09ICdTdXBlciBBZG1pbicgJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1VwbG9hZE1vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWdyYXktOTAwIGRhcms6Ymctd2hpdGUgdGV4dC13aGl0ZSBkYXJrOnRleHQtZ3JheS05MDAgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHNoYWRvdy10aGVtZS14cyBob3ZlcjpvcGFjaXR5LTkwIHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLVswLjk4XSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+YWRkX3Bob3RvX2FsdGVybmF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICBVcGxvYWQgUGhvdG9zXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBQUk9HUkVTUyAmIEZFRURCQUNLIEJBTk5FUlxyXG4gICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICB7IXNob3dDbHVzdGVyTGFuZGluZyAmJiB6aXBQcm9ncmVzcy5zdGFnZSAhPT0gJ2lkbGUnICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBwLTQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XHJcbiAgICAgICAgICAgIHppcFByb2dyZXNzLnN0YWdlID09PSAnZXJyb3InXHJcbiAgICAgICAgICAgICAgPyAnYmctcm9zZS01MCBib3JkZXItcm9zZS0yMDAgdGV4dC1yb3NlLTkwMCdcclxuICAgICAgICAgICAgICA6IHppcFByb2dyZXNzLnN0YWdlID09PSAnY29tcGxldGVkJ1xyXG4gICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgYm9yZGVyLWVtZXJhbGQtMjAwIHRleHQtZW1lcmFsZC05MDAnXHJcbiAgICAgICAgICAgICAgOiAnYmctYmx1ZS01MC85MCBib3JkZXItYmx1ZS0yMDAgdGV4dC1ibHVlLTk1MCdcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyNHB4XSAke1xyXG4gICAgICAgICAgICAgICAgICB6aXBQcm9ncmVzcy5zdGFnZSA9PT0gJ2Vycm9yJ1xyXG4gICAgICAgICAgICAgICAgICAgID8gJ3RleHQtcm9zZS02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgOiB6aXBQcm9ncmVzcy5zdGFnZSA9PT0gJ2NvbXBsZXRlZCdcclxuICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWVtZXJhbGQtNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogJ3RleHQtYnJhbmQtNTAwIGFuaW1hdGUtc3BpbidcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt6aXBQcm9ncmVzcy5zdGFnZSA9PT0gJ2Vycm9yJ1xyXG4gICAgICAgICAgICAgICAgICA/ICdlcnJvcidcclxuICAgICAgICAgICAgICAgICAgOiB6aXBQcm9ncmVzcy5zdGFnZSA9PT0gJ2NvbXBsZXRlZCdcclxuICAgICAgICAgICAgICAgICAgPyAnY2hlY2tfY2lyY2xlJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdwcm9ncmVzc19hY3Rpdml0eSd9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtXCI+e3ppcFByb2dyZXNzLm1lc3NhZ2V9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7emlwUHJvZ3Jlc3MuemlwRmlsZW5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICBTYXZlZCBhcyA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1zZW1pYm9sZFwiPnt6aXBQcm9ncmVzcy56aXBGaWxlbmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHt6aXBQcm9ncmVzcy5lcnJvck1lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yb3NlLTcwMCBtdC0wLjUgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7emlwUHJvZ3Jlc3MuZXJyb3JNZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge3ppcFByb2dyZXNzLnN0YWdlID09PSAnY29tcGxldGVkJyAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBiZy1lbWVyYWxkLTEwMC84MCBweC0yLjUgcHktMSByb3VuZGVkLW1kXCI+XHJcbiAgICAgICAgICAgICAgICBDb21wbGV0ZVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBQcm9ncmVzcyBCYXIgKi99XHJcbiAgICAgICAgICB7emlwUHJvZ3Jlc3Muc3RhZ2UgIT09ICdlcnJvcicgJiYgemlwUHJvZ3Jlc3Muc3RhZ2UgIT09ICdjb21wbGV0ZWQnICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctYmx1ZS0xMDAvODAgaC0xLjUgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlbiBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYnJhbmQtNTAwIGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgcm91bmRlZC1mdWxsXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHt6aXBQcm9ncmVzcy5wcm9ncmVzc1BlcmNlbnR9JWAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBTVVBFUiBBRE1JTiBDTFVTVEVSIFNFTEVDVE9SIChJRiBTVVBFUiBBRE1JTilcclxuICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge2FjdGl2ZVJvbGUgPT09ICdTdXBlciBBZG1pbicgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICBTdXBlciBBZG1pbiBNdWx0aS1DbHVzdGVyIFZpZXdcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIFNlbGVjdCBDbHVzdGVyIHRvIEluc3BlY3Qgb3IgRG93bmxvYWQ6XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIHtbJ0RoYXJtYXB1cmknLCAnU2FsZW0nLCAnS3Jpc2huYWdpcmknXS5tYXAoKGNOYW1lKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAga2V5PXtjTmFtZX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ2x1c3RlcihjTmFtZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZENsdXN0ZXIudG9Mb3dlckNhc2UoKSA9PT0gY05hbWUudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cydcclxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGhvdmVyOmJnLWdyYXktMjAwJ1xyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2NOYW1lfSBDbHVzdGVyXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7c2hvd0NsdXN0ZXJMYW5kaW5nICYmIChcclxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+U2Vzc2lvbiBQaG90b3MgLSBDbHVzdGVyczwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICB7cGhvdG9DbHVzdGVycy5tYXAoKGNsdXN0ZXIpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCBjbHVzdGVyUGhvdG9zID0gcGhvdG9zLmZpbHRlcigocGhvdG8pID0+IHBob3RvLmNsdXN0ZXJJZC50b0xvd2VyQ2FzZSgpID09PSBjbHVzdGVyLmlkLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGRheXMgPSBuZXcgU2V0KGNsdXN0ZXJQaG90b3MubWFwKChwaG90bykgPT4gcGhvdG8uZGF5TnVtYmVyKSkuc2l6ZTtcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2NsdXN0ZXIuaWR9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFNlbGVjdGVkQ2x1c3RlcihjbHVzdGVyLmlkKTsgc2V0U2VsZWN0ZWREYXlUYWIoJ2FsbCcpOyB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJvcmRlci1icmFuZC01MDAgaG92ZXI6c2hhZG93LXRoZW1lLXNtIHRyYW5zaXRpb24tYWxsIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWJyYW5kLTUwIGRhcms6YmctYnJhbmQtOTUwLzQwIHRleHQtYnJhbmQtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+PHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZFwiPmh1Yjwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPlZpZXcgY2x1c3Rlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtdC01IHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3Rlci5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMiBtdC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2RheXN9Lzg8L3N0cm9uZz48ZW0gY2xhc3NOYW1lPVwibm90LWl0YWxpYyB0ZXh0LWdyYXktNTAwXCI+RGF5czwvZW0+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmcgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3RlclBob3Rvcy5sZW5ndGh9PC9zdHJvbmc+PGVtIGNsYXNzTmFtZT1cIm5vdC1pdGFsaWMgdGV4dC1ncmF5LTUwMFwiPlBob3RvczwvZW0+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmcgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57bmV3IFNldChjbHVzdGVyUGhvdG9zLm1hcCgocGhvdG8pID0+IHBob3RvLnBhbmNoYXlhdElkKS5maWx0ZXIoQm9vbGVhbikpLnNpemV9PC9zdHJvbmc+PGVtIGNsYXNzTmFtZT1cIm5vdC1pdGFsaWMgdGV4dC1ncmF5LTUwMFwiPlBhbmNoYXlhdHM8L2VtPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3Bob3RvQ2x1c3RlcnMubGVuZ3RoID09PSAwICYmIDxkaXYgY2xhc3NOYW1lPVwicHktMTQgdGV4dC1jZW50ZXIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLTJ4bCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBzZXNzaW9uIHBob3RvIGNsdXN0ZXJzIGZvdW5kIGluIE15U1FMLjwvZGl2Pn1cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBTRUNUSU9OIDE6IERBWSAxIFRPIERBWSA4IEFMQlVNU1xyXG4gICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c2hvd0NsdXN0ZXJMYW5kaW5nID8gJ2hpZGRlbicgOiAnc3BhY2UteS00J30+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgIERhaWx5IFNlc3Npb24gQWxidW1zICh7c2VsZWN0ZWRDbHVzdGVyfSlcclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgVG90YWwgUGhvdG9zOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3Bob3Rvcy5sZW5ndGh9PC9zdHJvbmc+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAge2RheVN1bW1hcmllcy5tYXAoKGRheVN1bW1hcnkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgaXNEYXlEb3dubG9hZGluZyA9IGRvd25sb2FkaW5nWmlwS2V5ID09PSBgZGF5LSR7ZGF5U3VtbWFyeS5kYXlOdW1iZXJ9YDtcclxuICAgICAgICAgICAgY29uc3QgaXNEYXlDb21wbGV0ZWQgPSBjb21wbGV0ZWRaaXBLZXkgPT09IGBkYXktJHtkYXlTdW1tYXJ5LmRheU51bWJlcn1gO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e2RheVN1bW1hcnkuZGF5TnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTQgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJvcmRlci1icmFuZC01MDAvNDAgdHJhbnNpdGlvbi1hbGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBDYXJkIEhlYWRlciB3aXRoIFByb3BlciBHYXAgYmV0d2VlbiBEYXkgTGFiZWwgYW5kIERhdGUgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRFeHBhbmRlZERheShleHBhbmRlZERheSA9PT0gZGF5U3VtbWFyeS5kYXlOdW1iZXIgPyBudWxsIDogZGF5U3VtbWFyeS5kYXlOdW1iZXIpOyBzZXRTZWxlY3RlZERheVRhYihkYXlTdW1tYXJ5LmRheU51bWJlcik7IH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtbGVmdCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkYXlTdW1tYXJ5LmRheUxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkYXlTdW1tYXJ5LmRhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXlTdW1tYXJ5LnBob3Rvc0NvdW50ID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXN1Y2Nlc3MtNTAgdGV4dC1zdWNjZXNzLTcwMCBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MtMjAwIGRhcms6Ymctc3VjY2Vzcy05NTAvNDAgZGFyazp0ZXh0LXN1Y2Nlc3MtNDAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWdyYXktMTAwIHRleHQtZ3JheS01MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS00MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZGF5U3VtbWFyeS5waG90b3NDb3VudH0gUGhvdG9zXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQaG90byBUaHVtYm5haWxzIFByZXZpZXcgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMS41IG15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZGF5U3VtbWFyeS5mZWF0dXJlZFBob3Rvcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF5U3VtbWFyeS5mZWF0dXJlZFBob3Rvcy5tYXAoKHAsIHBJZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cC5pZCB8fCBwSWR4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUGhvdG8ocCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXNwZWN0LXNxdWFyZSByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODUgdHJhbnNpdGlvbi1vcGFjaXR5IGRhcms6Ym9yZGVyLWdyYXktODAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17cC5maWxlVXJsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtwLm9yaWdpbmFsRmlsZW5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWZlcnJlclBvbGljeT1cIm5vLXJlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tNCBweS00IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1ncmF5LTQwMCBiZy1ncmF5LTUwIGRhcms6YmctZ3JheS05MDAvNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gcGhvdG9zIHlldCBmb3IgdGhpcyBkYXlcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvdmVyYWdlOiB7ZGF5U3VtbWFyeS5wYW5jaGF5YXRDb3ZlcmFnZX0gUGFuY2hheWF0czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UYXJnZXQ6IHtkYXlTdW1tYXJ5LnRhcmdldENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ2FyZCBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMi41IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGZsZXgtY29sIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEV4cGFuZGVkRGF5KGRheVN1bW1hcnkuZGF5TnVtYmVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXlUYWIoZGF5U3VtbWFyeS5kYXlOdW1iZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dhbGxlcnktc2VjdGlvbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIGRhcms6YmctZ3JheS04MDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTIwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE0cHhdXCI+Z3JpZF92aWV3PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlUm9sZSAhPT0gJ1N1cGVyIEFkbWluJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5VcGxvYWRGb3JEYXkoZGF5U3VtbWFyeS5kYXlOdW1iZXIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIGRhcms6YmctZ3JheS04MDAgZGFyazpob3ZlcjpiZy1ncmF5LTcwMCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTIwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNHB4XVwiPnVwbG9hZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBEb3dubG9hZCBaSVAgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9e2Bkb3dubG9hZC1kYXktJHtkYXlTdW1tYXJ5LmRheU51bWJlcn0temlwLWJ0bmB9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rvd25sb2FkaW5nWmlwS2V5ICE9PSBudWxsIHx8IGRheVN1bW1hcnkucGhvdG9zQ291bnQgPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRG93bmxvYWRaaXAoJ2RheScsIGRheVN1bW1hcnkuZGF5TnVtYmVyKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHktMS41IHB4LTMgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBzaGFkb3ctdGhlbWUteHMgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGRheVN1bW1hcnkucGhvdG9zQ291bnQgPT09IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCB0ZXh0LWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBpc0RheURvd25sb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJyYW5kLTEwMCB0ZXh0LWJyYW5kLTcwMCBjdXJzb3Itd2FpdCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYnJhbmQtNTAwIGhvdmVyOmJnLWJyYW5kLTYwMCB0ZXh0LXdoaXRlIGFjdGl2ZTpzY2FsZS1bMC45OF0nXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXNEYXlEb3dubG9hZGluZyA/ICdzeW5jJyA6ICdmb2xkZXJfemlwJ31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzRGF5RG93bmxvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ0NyZWF0aW5nIFpJUC4uLidcclxuICAgICAgICAgICAgICAgICAgICAgIDogaXNEYXlDb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ0Rvd25sb2FkIEFnYWluJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgOiBgRG93bmxvYWQgRGF5ICR7ZGF5U3VtbWFyeS5kYXlOdW1iZXJ9IFpJUGB9XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2V4cGFuZGVkRGF5ID09PSBkYXlTdW1tYXJ5LmRheU51bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtZ3JheS00MDBcIj5EYXkge2RheVN1bW1hcnkuZGF5TnVtYmVyfSBwaG90byBsaXN0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZERheShudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCI+Q2xvc2U8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2RheVN1bW1hcnkuZmVhdHVyZWRQaG90b3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctZ3JheS01MCBkYXJrOmJnLWdyYXktOTAwIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBweC0zIHB5LTMgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Tm8gcGhvdG9zIG9yIGZvbGRlcnMgYXJlIGF2YWlsYWJsZSBmb3IgdGhpcyBkYXkuPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXlTdW1tYXJ5LmZlYXR1cmVkUGhvdG9zLm1hcCgocGhvdG8pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cGhvdG8uaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLXhsIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTkwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHB4LTIuNSBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj48ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTIwMCB0cnVuY2F0ZVwiPntwaG90by5vcmlnaW5hbEZpbGVuYW1lfTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ncmF5LTQwMCB0cnVuY2F0ZVwiPntwaG90by5jYXB0aW9uIHx8IHBob3RvLnNlc3Npb25UaXRsZX08L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3Bob3RvLmZpbGVVcmx9IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJzaHJpbmstMCBweC0yIHB5LTEgcm91bmRlZC1sZyBiZy1icmFuZC01MDAgdGV4dC13aGl0ZSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkXCI+VmlldzwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgIFNFQ1RJT04gMjogUEhPVE8gR0FMTEVSWVxyXG4gICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICA8ZGl2IGlkPVwiZ2FsbGVyeS1zZWN0aW9uXCIgY2xhc3NOYW1lPXtgJHtzaG93Q2x1c3RlckxhbmRpbmcgPyAnaGlkZGVuICcgOiAnJ31zcGFjZS15LTQgcHQtMmB9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlBob3RvIEdhbGxlcnk8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRlcmVkIFpJUCBEb3dubG9hZCBDVEEgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBTaG93aW5nIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57ZmlsdGVyZWRQaG90b3MubGVuZ3RofTwvc3Ryb25nPiBwaG90b3NcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIGlkPVwiZG93bmxvYWQtZmlsdGVyZWQtemlwLWJ0blwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rvd25sb2FkaW5nWmlwS2V5ICE9PSBudWxsIHx8IGZpbHRlcmVkUGhvdG9zLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb3dubG9hZFppcCgnZmlsdGVyZWQnKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zLjUgcHktMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hhZG93LXRoZW1lLXhzIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJlZFBob3Rvcy5sZW5ndGggPT09IDBcclxuICAgICAgICAgICAgICAgICAgPyAnYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCB0ZXh0LWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgICAgICAgOiBkb3dubG9hZGluZ1ppcEtleSA9PT0gJ2ZpbHRlcmVkJ1xyXG4gICAgICAgICAgICAgICAgICA/ICdiZy1ncmF5LTIwMCB0ZXh0LWdyYXktNjAwJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zdWNjZXNzLTYwMCBob3ZlcjpiZy1zdWNjZXNzLTcwMCB0ZXh0LXdoaXRlJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPlxyXG4gICAgICAgICAgICAgICAge2Rvd25sb2FkaW5nWmlwS2V5ID09PSAnZmlsdGVyZWQnID8gJ3N5bmMnIDogJ2Rvd25sb2FkJ31cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAge2Rvd25sb2FkaW5nWmlwS2V5ID09PSAnZmlsdGVyZWQnID8gJ0NyZWF0aW5nIFpJUC4uLicgOiAnRG93bmxvYWQgRmlsdGVyZWQgWklQJ31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIERheSBUYWJzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgb3ZlcmZsb3cteC1hdXRvIHBiLTFcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWREYXlUYWIoJ2FsbCcpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xyXG4gICAgICAgICAgICAgIHNlbGVjdGVkRGF5VGFiID09PSAnYWxsJ1xyXG4gICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTAwIHRleHQtd2hpdGUnXHJcbiAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwJ1xyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQWxsIERheXMgKHtwaG90b3MubGVuZ3RofSlcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAge1sxLCAyLCAzLCA0LCA1LCA2LCA3LCA4XS5tYXAoKGROdW0pID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY291bnQgPSBwaG90b3MuZmlsdGVyKChwKSA9PiBwLmRheU51bWJlciA9PT0gZE51bSkubGVuZ3RoO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIGtleT17ZE51bX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRGF5VGFiKGROdW0pfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC1tZCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcclxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWREYXlUYWIgPT09IGROdW1cclxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1bIzBCM0Q5MV0gdGV4dC13aGl0ZSdcclxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwJ1xyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRGF5IHtkTnVtfSAoe2NvdW50fSlcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRmlsdGVyIFNlbGVjdG9ycyBHcmlkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtMyBwdC0xXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgUGFuY2hheWF0XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQYW5jaGF5YXQgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdCh2YWwpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRWaWxsYWdlKCdhbGwnKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBQYW5jaGF5YXRzXCIgLz5cclxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFsbFwiPkFsbCBQYW5jaGF5YXRzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAge3BhbmNoYXlhdHMubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cC5pZH0gdmFsdWU9e3AuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgVmlsbGFnZSBDZW50ZXJcclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFZpbGxhZ2UgfHwgXCJhbGxcIn1cclxuICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZFZpbGxhZ2UodmFsKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOSB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgVmlsbGFnZXNcIiAvPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIFZpbGxhZ2VzPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRGaWx0ZXJWaWxsYWdlcy5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICBTZWFyY2ggYnkgVG9waWMsIFZpbGxhZ2Ugb3IgVm9sdW50ZWVyXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBzZXNzaW9uIHRpdGxlLCB2b2x1bnRlZXIgbmFtZSwgZmlsZS4uLlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTkgcHItOCBweS0yIHRleHQteHMgdGV4dC1ncmF5LTgwMCBzaGFkb3ctdGhlbWUteHMgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7c2VhcmNoUXVlcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoUXVlcnkoJycpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgU0VDVElPTiAzOiBQSE9UTyBHQUxMRVJZIEdSSURcclxuICAgICAgICAgIChFdmVyeSBQaG90byBoYXMgVmlldywgRG93bmxvYWQsIERlbGV0ZSlcclxuICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTIwIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIGJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMzJweF0gYW5pbWF0ZS1zcGluIHRleHQtWyMwQjNEOTFdXCI+XHJcbiAgICAgICAgICAgIHByb2dyZXNzX2FjdGl2aXR5XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgbXQtMlwiPkxvYWRpbmcgaGlnaC1yZXNvbHV0aW9uIHNlc3Npb24gcGhvdG9zLi4uPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogZmlsdGVyZWRQaG90b3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTYgdGV4dC1jZW50ZXIgYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTZcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bNDJweF0gdGV4dC1zbGF0ZS0zMDAgbWItMlwiPlxyXG4gICAgICAgICAgICBpbWFnZV9ub3Rfc3VwcG9ydGVkXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRleHQtc21cIj5ObyBQaG90b2dyYXBocyBNYXRjaCBZb3VyIEZpbHRlcjwvaDM+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG10LTEgbWF4LXctc20gbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICBUcnkgYWRqdXN0aW5nIHlvdXIgc2VhcmNoIGNyaXRlcmlhLCBzZWxlY3RpbmcgYW5vdGhlciBEYXkgb3IgdXBsb2FkaW5nIG5ldyBzZXNzaW9uIHBob3Rvcy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkRGF5VGFiKCdhbGwnKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdCgnYWxsJyk7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRWaWxsYWdlKCdhbGwnKTtcclxuICAgICAgICAgICAgICBzZXRTZWFyY2hRdWVyeSgnJyk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTMgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1bIzBCM0Q5MV0gYmctYmx1ZS01MCByb3VuZGVkLW1kIGhvdmVyOmJnLWJsdWUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgUmVzZXQgRmlsdGVyc1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICB7ZmlsdGVyZWRQaG90b3MubWFwKChwaG90bykgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAga2V5PXtwaG90by5pZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIG92ZXJmbG93LWhpZGRlbiBzaGFkb3cteHMgaG92ZXI6c2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2xcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgey8qIFBob3RvIERpc3BsYXkgd2l0aCBIb3ZlciBPdmVybGF5ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LVs0LzNdIGJnLXNsYXRlLTkwMCBvdmVyZmxvdy1oaWRkZW4gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgc3JjPXtwaG90by5maWxlVXJsfVxyXG4gICAgICAgICAgICAgICAgICBhbHQ9e3Bob3RvLnNlc3Npb25UaXRsZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFBob3RvKHBob3RvKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIERheSBCYWRnZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgbGVmdC0yIHB4LTIgcHktMC41IHJvdW5kZWQgYmctYmxhY2svNzAgIHRleHQtd2hpdGUgdGV4dC1bMTBweF0gZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIERheSB7cGhvdG8uZGF5TnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE9yaWdpbmFsIEZpbGUgU2l6ZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMiBweC0yIHB5LTAuNSByb3VuZGVkIGJnLWJsYWNrLzcwICB0ZXh0LXdoaXRlIHRleHQtWzEwcHhdIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICB7TWF0aC5yb3VuZCgocGhvdG8uZmlsZVNpemUgfHwgNTAwMDApIC8gMTAyNCl9IEtCXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogSG92ZXIgUXVpY2sgQWN0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCAgZnJvbS1ibGFjay84MCB2aWEtYmxhY2svMjAgdG8tdHJhbnNwYXJlbnQgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBmbGV4IGZsZXgtY29sIGp1c3RpZnktZW5kIHAtMyB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIGxlYWRpbmctdGlnaHQgbGluZS1jbGFtcC0xXCI+e3Bob3RvLnNlc3Npb25UaXRsZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtMjAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwaG90by5wYW5jaGF5YXROYW1lfSDDouKCrMKiIHtwaG90by52aWxsYWdlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBob3RvKHBob3RvKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgYmctd2hpdGUyMCBob3ZlcjpiZy13aGl0ZTMwICByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTRweF1cIj52aXNpYmlsaXR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURvd25sb2FkU2luZ2xlUGhvdG8ocGhvdG8pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1bIzBCM0Q5MV0gaG92ZXI6YmctWyMwODJhNjZdIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNHB4XVwiPmRvd25sb2FkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBob3RvIENhcmQgRm9vdGVyIERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgZmxleC0xIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGxpbmUtY2xhbXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwaG90by5zZXNzaW9uVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwaG90by5wYW5jaGF5YXROYW1lfSDDouKCrMKiIHtwaG90by52aWxsYWdlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CeSB7cGhvdG8udXBsb2FkZWRCeX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Bob3RvLmRhdGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiAzIEV4cGxpY2l0IEFjdGlvbiBCdXR0b25zOiBbVmlld10gW0Rvd25sb2FkXSBbRGVsZXRlXSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0yLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBncmlkIGdyaWQtY29scy0zIGdhcC0xIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUGhvdG8ocGhvdG8pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTEgcHgtMS41IHRleHQtc2xhdGUtNzAwIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgcm91bmRlZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJWaWV3IEZ1bGwgUmVzb2x1dGlvblwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE0cHhdXCI+dmlzaWJpbGl0eTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvd25sb2FkU2luZ2xlUGhvdG8ocGhvdG8pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTEgcHgtMS41IHRleHQtWyMwQjNEOTFdIGJnLWJsdWUtNTAgaG92ZXI6YmctYmx1ZS0xMDAgcm91bmRlZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBPcmlnaW5hbCBGaWxlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTRweF1cIj5kb3dubG9hZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQaG90b1RvRGVsZXRlKHBob3RvKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0xIHB4LTEuNSB0ZXh0LXJvc2UtNzAwIGJnLXJvc2UtNTAgaG92ZXI6Ymctcm9zZS0xMDAgcm91bmRlZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgUGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNHB4XVwiPmRlbGV0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgIE1PREFMIDE6IEhJR0ggUkVTT0xVVElPTiBMSUdIVEJPWCBNT0RBTFxyXG4gICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICB7c2VsZWN0ZWRQaG90byAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ncmF5LTk1MC85MCBiYWNrZHJvcC1ibHVyLXNtIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQaG90byhudWxsKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIG1heC13LTV4bCB3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbSBhbmltYXRlLVtmYWRlSW5fMC4yc19lYXNlLW91dF0gZmxleCBmbGV4LWNvbFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7LyogTW9kYWwgSGVhZGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05NTAvODAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLVsjMEIzRDkxXSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERheSB7c2VsZWN0ZWRQaG90by5kYXlOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gc206dGV4dC1iYXNlIGZvbnQtYm9sZFwiPntzZWxlY3RlZFBob3RvLnNlc3Npb25UaXRsZX08L2gzPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQaG90by5wYW5jaGF5YXROYW1lfSDDouKCrMKiIHtzZWxlY3RlZFBob3RvLnZpbGxhZ2VOYW1lfSDDouKCrMKiIHtzZWxlY3RlZFBob3RvLmRhdGV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRG93bmxvYWRTaW5nbGVQaG90byhzZWxlY3RlZFBob3RvKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctWyMwQjNEOTFdIGhvdmVyOmJnLVsjMDgyYTY2XSB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5kb3dubG9hZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgRG93bmxvYWQgT3JpZ2luYWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFBob3RvKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWZ1bGwgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogSGlnaC1yZXMgSW1hZ2UgUHJldmlldyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC1bNjh2aF0gYmctYmxhY2svOTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgc3JjPXtzZWxlY3RlZFBob3RvLmZpbGVVcmx9XHJcbiAgICAgICAgICAgICAgICBhbHQ9e3NlbGVjdGVkUGhvdG8uc2Vzc2lvblRpdGxlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzY1dmhdIHctYXV0byBtYXgtdy1mdWxsIG9iamVjdC1jb250YWluIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTW9kYWwgRm9vdGVyIE1ldGFkYXRhICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05NTAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgVXBsb2FkZWQgYnk6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPntzZWxlY3RlZFBob3RvLnVwbG9hZGVkQnl9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgRmlsZW5hbWU6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm9cIj57c2VsZWN0ZWRQaG90by5vcmlnaW5hbEZpbGVuYW1lfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgIFNpemU6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm9cIj57TWF0aC5yb3VuZCgoc2VsZWN0ZWRQaG90by5maWxlU2l6ZSB8fCA1MDAwMCkgLyAxMDI0KX0gS0I8L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRQaG90b1RvRGVsZXRlKHNlbGVjdGVkUGhvdG8pO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcm9zZS00MDAgaG92ZXI6dGV4dC1yb3NlLTMwMCBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZGVsZXRlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgRGVsZXRlIFBob3RvXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBNT0RBTCAyOiBVUExPQUQgTVVMVElQTEUgU0VTU0lPTiBQSE9UT1NcclxuICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge3Nob3dVcGxvYWRNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIHNoYWRvdy1zbSB3LWZ1bGwgbWF4LXcteGwgb3ZlcmZsb3ctaGlkZGVuIGFuaW1hdGUtW2ZhZGVJbl8wLjJzX2Vhc2Utb3V0XVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlVwbG9hZCBTZXNzaW9uIFBob3RvZ3JhcGhzPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVXBsb2FkIG9yaWdpbmFsIGhpZ2gtcmVzb2x1dGlvbiBjYW1lcmEgaW1hZ2VzIGZvciBzZXNzaW9uIGFyY2hpdmluZy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgcm91bmRlZC1mdWxsXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVVwbG9hZFN1Ym1pdH0gY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAge3VwbG9hZEVycm9yICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXJvc2UtNTAgdGV4dC1yb3NlLTgwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIHJvdW5kZWQtbWQgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAge3VwbG9hZEVycm9yfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIFRhcmdldCBEYXkgJiBTZXNzaW9uIFRpdGxlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+U2Vzc2lvbiBEYXkgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17U3RyaW5nKHVwbG9hZERheSl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0VXBsb2FkRGF5KHBhcnNlSW50KHZhbCwgMTApKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1zbGF0ZS01MCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGF5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7WzEsIDIsIDMsIDQsIDUsIDYsIDcsIDhdLm1hcCgoZCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e2R9IHZhbHVlPXtTdHJpbmcoZCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERheSB7ZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5TZXNzaW9uIFRpdGxlICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBsb2FkVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVcGxvYWRUaXRsZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFNwb2tlbiBFbmdsaXNoIERpYWxvZ3VlIFdvcmtzaG9wXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV1cIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBQYW5jaGF5YXQgJiBWaWxsYWdlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+UGFuY2hheWF0ICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwbG9hZFBhbmNoYXlhdH1cclxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRVcGxvYWRQYW5jaGF5YXQodmFsKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHRleHQteHMgYmctc2xhdGUtNTAgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBhbmNoYXlhdFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BhbmNoYXlhdHMubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17cC5pZH0gdmFsdWU9e3AuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5WaWxsYWdlIENlbnRlciAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwbG9hZFZpbGxhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVcGxvYWRWaWxsYWdlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1bIzBCM0Q5MV1cIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBEYXRlICYgVXBsb2FkZXIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5EYXRlICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBsb2FkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVwbG9hZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMEIzRDkxXVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5VcGxvYWRlciBOYW1lICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBsb2FkVXBsb2FkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVcGxvYWRVcGxvYWRlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwQjNEOTFdXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRmlsZSBEcm9wem9uZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+U2VsZWN0IFBob3RvZ3JhcGhzICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwic2Vzc2lvbi1waG90by1maWxlLWlucHV0XCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cclxuICAgICAgICAgICAgICAgICAgbXVsdGlwbGVcclxuICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvanBlZyxpbWFnZS9wbmcsaW1hZ2Uvd2VicFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlLnRhcmdldC5maWxlcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBsb2FkRmlsZXMoQXJyYXkuZnJvbShlLnRhcmdldC5maWxlcykpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJzZXNzaW9uLXBob3RvLWZpbGUtaW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgaG92ZXI6Ym9yZGVyLVsjMEIzRDkxXSByb3VuZGVkLW1kIHAtNiB0ZXh0LWNlbnRlciBjdXJzb3ItcG9pbnRlciBiZy1zbGF0ZS01MCBob3ZlcjpiZy1ibHVlLTUwLzQwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVszMnB4XSB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgY2xvdWRfdXBsb2FkXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5DbGljayB0byBjaG9vc2UgaW1hZ2UgZmlsZXM8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3VwcG9ydHMgSlBHLCBQTkcsIFdFQlAgaGlnaC1yZXNvbHV0aW9uIHBob3Rvcy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICB7dXBsb2FkRmlsZXMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMi41IHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdGVkIHt1cGxvYWRGaWxlcy5sZW5ndGh9IGZpbGUocyk6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtMjQgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktMSBiZy1zbGF0ZS01MCBwLTIgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VwbG9hZEZpbGVzLm1hcCgoZiwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWF4LXctWzMwMHB4XSBmb250LW1vbm9cIj57Zi5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPntNYXRoLnJvdW5kKGYuc2l6ZSAvIDEwMjQpfSBLQjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgcm91bmRlZC1tZCBmb250LXNlbWlib2xkIGhvdmVyOmJnLXNsYXRlLTUwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1VwbG9hZGluZyB8fCB1cGxvYWRGaWxlcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMiByb3VuZGVkLW1kIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tYWxsIHNoYWRvdy14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiAke1xyXG4gICAgICAgICAgICAgICAgICAgIGlzVXBsb2FkaW5nIHx8IHVwbG9hZEZpbGVzLmxlbmd0aCA9PT0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtNDAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjMEIzRDkxXSBob3ZlcjpiZy1bIzA4MmE2Nl0nXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzVXBsb2FkaW5nID8gJ3N5bmMnIDogJ3VwbG9hZCd9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge2lzVXBsb2FkaW5nID8gJ1VwbG9hZGluZyBQaG90b3MuLi4nIDogYFVwbG9hZCAke3VwbG9hZEZpbGVzLmxlbmd0aH0gUGhvdG9zYH1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgIE1PREFMIDM6IERFTEVURSBQSE9UTyBDT05GSVJNQVRJT05cclxuICAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge3Bob3RvVG9EZWxldGUgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ncmF5LTkwMC83NSBiYWNrZHJvcC1ibHVyLXNtIHotWzk5OTk5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctc20gdy1mdWxsIG1heC13LXNtIHAtNSB0ZXh0LWNlbnRlciBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVszOHB4XSB0ZXh0LXJvc2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgd2FybmluZ1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwXCI+RGVsZXRlIFBob3RvPzwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcGVybWFuZW50bHkgcmVtb3ZlIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDBcIj57cGhvdG9Ub0RlbGV0ZS5vcmlnaW5hbEZpbGVuYW1lfTwvc3Ryb25nPj8gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQaG90b1RvRGVsZXRlKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLW1kIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlUGhvdG8ocGhvdG9Ub0RlbGV0ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbWQgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDb25maXJtIERlbGV0ZVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvU2Vzc2lvblBob3Rvc1ZpZXcudHN4In0=