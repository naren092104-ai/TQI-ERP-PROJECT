import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserManagementView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"];
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { ActionButton } from "/src/components/ui/action-button.tsx";
import Badge from "/src/components/ui/badge.tsx";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "/src/components/ui/table.tsx";
import { Plus, Search, ShieldCheck, X, Edit3, Trash2, KeyRound } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const UserManagementView = ({
  users = [],
  clusters = [],
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onResetPassword
}) => {
  _s();
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [addError, setAddError] = useState("");
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [editingUser, setEditingUser] = useState(null);
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editError, setEditError] = useState("");
  const [editRole, setEditRole] = useState("Cluster Admin");
  const [editClusterId, setEditClusterId] = useState("");
  const [resettingUser, setResettingUser] = useState(null);
  const [resetPassword, setResetPassword] = useState("");
  const [resetPasswordConfirm, setResetPasswordConfirm] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const filteredUsers = users.filter(
    (u) => u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase()) || u.role.toLowerCase().includes(searchTerm.toLowerCase()) || u.clusterName && u.clusterName.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleCreateSuperAdmin = async (e) => {
    e.preventDefault();
    setAddError("");
    if (!newName.trim() || !newEmail.trim()) {
      setAddError("Full name and email address are required.");
      return;
    }
    setIsSubmitting(true);
    try {
      if (onAddUser) {
        const success = await onAddUser({
          name: newName.trim(),
          email: newEmail.trim(),
          role: "Super Admin",
          phone: newPhone.trim() || "+91 90000 00000",
          status: "Active"
        });
        if (success === false) {
          setIsSubmitting(false);
          return;
        }
      }
      setIsAddOpen(false);
      setNewName("");
      setNewEmail("");
      setNewPhone("");
      setAddError("");
    } catch (err) {
      setAddError(err?.message || "Failed to create Super Admin account.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "User & Role Management" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 104,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            users.length,
            " Authorized Accounts"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 107,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Centrally manage Super Admins (State Coordinators) and Regional Cluster Admins across Tamil Nadu." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        ActionButton,
        {
          onClick: () => {
            setIsAddOpen(true);
            setAddError("");
          },
          size: "sm",
          variant: "primary",
          icon: /* @__PURE__ */ jsxDEV(Plus, { size: 15 }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 123,
            columnNumber: 17
          }, this),
          children: "Add Super Admin"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 116,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
      /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 132,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          placeholder: "Search by name, email, or role...",
          value: searchTerm,
          onChange: (e) => setSearchTerm(e.target.value),
          className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 133,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 131,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 130,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "w-[280px]", children: "User Details" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 148,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Role Designation" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 149,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Regional Scope" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 150,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Contact Phone" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 151,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Account Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 152,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 153,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 147,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 146,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: filteredUsers.map(
        (u) => /* @__PURE__ */ jsxDEV(TableRow, { className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors", children: [
          /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-900 dark:text-white text-xs", children: u.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 161,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400 font-mono", children: u.email }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 162,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 160,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 159,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: `inline-block px-2.5 py-1 rounded-md text-[11px] font-bold ${u.role === "Super Admin" ? "bg-purple-100 text-purple-900 border border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800" : "bg-blue-100 text-blue-900 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800"}`,
              children: u.role
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 166,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 165,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium text-gray-700 dark:text-gray-300 text-xs", children: u.role === "Super Admin" ? /* @__PURE__ */ jsxDEV("span", { className: "text-purple-700 dark:text-purple-400 font-semibold", children: "State Central Authority (All)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 178,
            columnNumber: 17
          }, this) : u.clusterName || "Assigned College Cluster" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 176,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-500 dark:text-gray-400 font-mono text-xs", children: u.phone || "+91 90000 00000" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 183,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 flex-wrap", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300", children: u.status }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 188,
              columnNumber: 21
            }, this),
            u.mustChangePassword && /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800", children: "Pending Onboarding" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 192,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 187,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 186,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setEditingUser(u);
                  setEditName(u.name);
                  setEditEmail(u.email);
                  setEditPhone(u.phone || "");
                  setEditRole(u.role);
                  setEditClusterId(u.clusterId || clusters[0]?.id || "");
                  setEditError("");
                },
                className: "rounded-lg p-1.5 text-gray-500 hover:bg-gray-100 hover:text-brand-500 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-brand-400 transition cursor-pointer",
                title: "Edit User",
                children: /* @__PURE__ */ jsxDEV(Edit3, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 213,
                  columnNumber: 23
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 200,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setResettingUser(u);
                  setResetPassword("");
                  setResetPasswordConfirm("");
                },
                className: "rounded-lg p-1.5 text-gray-500 hover:bg-amber-50 hover:text-amber-600 dark:text-gray-400 dark:hover:bg-amber-500/10 dark:hover:text-amber-400 transition cursor-pointer",
                title: "Reset Password",
                children: /* @__PURE__ */ jsxDEV(KeyRound, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 224,
                  columnNumber: 23
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 215,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  if (window.confirm(`Are you sure you want to deactivate ${u.name}?`)) {
                    onDeleteUser?.(u.id);
                  }
                },
                className: "rounded-lg p-1.5 text-gray-500 hover:bg-error-50 hover:text-error-600 dark:text-gray-400 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition cursor-pointer",
                title: "Delete User",
                children: /* @__PURE__ */ jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 235,
                  columnNumber: 23
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 226,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 199,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 198,
            columnNumber: 17
          }, this)
        ] }, u.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 158,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 156,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 145,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    isAddOpen && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] bg-gray-900/75 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl w-full max-w-md shadow-theme-xl overflow-hidden animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex items-center justify-between border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Add Central Super Admin" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 250,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setIsAddOpen(false),
            className: "text-gray-400 hover:text-gray-700 dark:hover:text-white p-1 rounded-lg transition cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 255,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 251,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 249,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreateSuperAdmin, className: "p-5 space-y-4 text-xs", children: [
        addError && /* @__PURE__ */ jsxDEV("div", { className: "p-2.5 rounded-xl bg-error-50 border border-error-200 text-error-700 text-xs dark:bg-error-500/10 dark:border-error-500/20 dark:text-error-400", children: addError }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 261,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Full Name *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 267,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              required: true,
              placeholder: "e.g. S. Anand",
              value: newName,
              onChange: (e) => setNewName(e.target.value),
              className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 268,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 266,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Login Email Address *" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 279,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "email",
              required: true,
              placeholder: "e.g. anand.s@tqi.org",
              value: newEmail,
              onChange: (e) => setNewEmail(e.target.value),
              className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 280,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 278,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Contact Phone Number" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 291,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              placeholder: "e.g. +91 96291 55672",
              value: newPhone,
              onChange: (e) => setNewPhone(e.target.value),
              className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 292,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 290,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 bg-purple-50/70 dark:bg-purple-900/20 border border-purple-200/80 dark:border-purple-800/60 rounded-xl text-xs text-purple-900 dark:text-purple-300 space-y-1", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "font-bold flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-4 w-4 text-purple-600 dark:text-purple-400" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 303,
              columnNumber: 19
            }, this),
            "Central Super Admin Authority"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 302,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-purple-800 dark:text-purple-300/80 text-[11px]", children: "This account will have statewide authority across all college clusters, panchayats, modules, and financial approvals." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 306,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 301,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              disabled: isSubmitting,
              onClick: () => setIsAddOpen(false),
              className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 312,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isSubmitting,
              className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer disabled:opacity-50",
              children: isSubmitting ? "Creating Super Admin..." : "Create Super Admin"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 320,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 311,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 259,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 248,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 247,
      columnNumber: 7
    }, this),
    editingUser && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] bg-gray-900/75 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl w-full max-w-md shadow-theme-xl overflow-hidden animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex items-center justify-between border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Edit User Details" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 338,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setEditingUser(null),
            className: "text-gray-400 hover:text-gray-700 dark:hover:text-white p-1 rounded-lg transition cursor-pointer",
            children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 343,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
            lineNumber: 339,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 337,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          onSubmit: async (e) => {
            e.preventDefault();
            const selectedCluster = clusters.find((cluster) => cluster.id === editClusterId);
            const updated = await onUpdateUser?.(editingUser.id, {
              name: editName.trim(),
              email: editEmail.trim(),
              phone: editPhone.trim(),
              role: editRole,
              clusterId: editRole === "Cluster Admin" ? editClusterId : void 0,
              clusterName: editRole === "Cluster Admin" ? selectedCluster?.name : void 0
            });
            if (updated !== false) setEditingUser(null);
            else
              setEditError("Unable to save changes. Check the email or cluster assignment.");
          },
          className: "p-5 space-y-3.5 text-xs",
          children: [
            editError && /* @__PURE__ */ jsxDEV("div", { className: "p-2.5 rounded-xl bg-error-50 border border-error-200 text-error-700 text-xs dark:bg-error-500/10 dark:border-error-500/20 dark:text-error-400", children: editError }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 363,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Full Name *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 365,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { required: true, value: editName, onChange: (e) => setEditName(e.target.value), className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 366,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 364,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Email *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 369,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { required: true, type: "email", value: editEmail, onChange: (e) => setEditEmail(e.target.value), className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 370,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 368,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Phone" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 373,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { value: editPhone, onChange: (e) => setEditPhone(e.target.value), className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 374,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 372,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Role *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 377,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: editRole,
                  onValueChange: (val) => setEditRole(val),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Role" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 383,
                      columnNumber: 21
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 382,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "Cluster Admin", children: "Cluster Admin" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                        lineNumber: 386,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "Super Admin", children: "Super Admin" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                        lineNumber: 387,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 385,
                      columnNumber: 19
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 378,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 376,
              columnNumber: 15
            }, this),
            editRole === "Cluster Admin" && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Assigned College Cluster *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 393,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: editClusterId || (clusters[0]?.id ?? void 0),
                  onValueChange: (val) => setEditClusterId(val),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Cluster" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 399,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 398,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: clusters.map(
                      (cluster) => /* @__PURE__ */ jsxDEV(SelectItem, { value: cluster.id, children: [
                        cluster.collegeName || cluster.name,
                        " (",
                        cluster.district,
                        ")"
                      ] }, cluster.id, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                        lineNumber: 403,
                        columnNumber: 19
                      }, this)
                    ) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                      lineNumber: 401,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 394,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 392,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setEditingUser(null),
                  className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 412,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer",
                  children: "Save Changes"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                  lineNumber: 419,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 411,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 346,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 336,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 335,
      columnNumber: 7
    }, this),
    resettingUser && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] bg-gray-900/75 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl w-full max-w-md shadow-theme-xl overflow-hidden animate-in fade-in-0 zoom-in-95", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex items-center justify-between border-b border-gray-100 dark:border-gray-800", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white", children: "Reset User Password" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 436,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setResettingUser(null), className: "text-gray-400 hover:text-gray-700 dark:hover:text-white p-1 rounded-lg transition cursor-pointer", children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 438,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 437,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
        lineNumber: 435,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          onSubmit: async (e) => {
            e.preventDefault();
            if (resetPassword.length < 8 || resetPassword !== resetPasswordConfirm) return;
            setResetLoading(true);
            try {
              await onResetPassword?.(resettingUser.id, resetPassword);
              setResettingUser(null);
            } finally {
              setResetLoading(false);
            }
          },
          className: "p-5 space-y-4 text-xs",
          children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 dark:text-gray-400 text-xs", children: [
              "Set a new password for ",
              /* @__PURE__ */ jsxDEV("strong", { className: "text-gray-800 dark:text-white", children: resettingUser.name }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 456,
                columnNumber: 40
              }, this),
              " (",
              resettingUser.email,
              ")."
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 455,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "New Password *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 459,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { required: true, minLength: 8, type: "password", value: resetPassword, onChange: (e) => setResetPassword(e.target.value), placeholder: "Minimum 8 characters", className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 460,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 458,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-1.5", children: "Confirm Password *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 463,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { required: true, minLength: 8, type: "password", value: resetPasswordConfirm, onChange: (e) => setResetPasswordConfirm(e.target.value), placeholder: "Re-enter new password", className: "w-full rounded-xl border border-gray-300 bg-transparent px-3.5 py-2.5 text-xs text-gray-800 focus:border-brand-500 focus:outline-none dark:border-gray-700 dark:bg-gray-800 dark:text-white" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 464,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 462,
              columnNumber: 15
            }, this),
            resetPasswordConfirm && resetPassword !== resetPasswordConfirm && /* @__PURE__ */ jsxDEV("p", { className: "text-error-600 dark:text-error-400 font-semibold text-xs", children: "Passwords do not match." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 467,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-3 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-2.5", children: [
              /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setResettingUser(null), className: "rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 transition cursor-pointer", children: "Cancel" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 470,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("button", { type: "submit", disabled: resetLoading || resetPassword.length < 8 || resetPassword !== resetPasswordConfirm, className: "rounded-xl bg-brand-500 px-4 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition cursor-pointer disabled:opacity-50", children: resetLoading ? "Setting Password..." : "Set Password" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
                lineNumber: 471,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
              lineNumber: 469,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
          lineNumber: 441,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 434,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
      lineNumber: 433,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this);
};
_s(UserManagementView, "Z5BUe8nQgt7NAjFDERp4kK9ocgA=");
_c = UserManagementView;
var _c;
$RefreshReg$(_c, "UserManagementView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/UserManagementView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdZOztBQXZHWixTQUFnQkEsZ0JBQWdCO0FBRWhDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLE9BQU9DLGFBQWFDLFdBQVdDLFVBQVVDLGlCQUFpQjtBQUNuRSxTQUFTQyxNQUFNQyxRQUFRQyxhQUF3QkMsR0FBR0MsT0FBYUMsUUFBUUMsZ0JBQWdCO0FBV2hGLGFBQU1DLHFCQUF3REEsQ0FBQztBQUFBLEVBQ3BFQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUk3QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOEIsV0FBV0MsWUFBWSxJQUFJL0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2dDLGNBQWNDLGVBQWUsSUFBSWpDLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNrQyxVQUFVQyxXQUFXLElBQUluQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDb0MsU0FBU0MsVUFBVSxJQUFJckMsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ3NDLFVBQVVDLFdBQVcsSUFBSXZDLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN3QyxVQUFVQyxXQUFXLElBQUl6QyxTQUFTLEVBQUU7QUFFM0MsUUFBTSxDQUFDMEMsYUFBYUMsY0FBYyxJQUFJM0MsU0FBc0IsSUFBSTtBQUNoRSxRQUFNLENBQUM0QyxVQUFVQyxXQUFXLElBQUk3QyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDOEMsV0FBV0MsWUFBWSxJQUFJL0MsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2dELFdBQVdDLFlBQVksSUFBSWpELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNrRCxXQUFXQyxZQUFZLElBQUluRCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0QsVUFBVUMsV0FBVyxJQUFJckQsU0FBMEMsZUFBZTtBQUN6RixRQUFNLENBQUNzRCxlQUFlQyxnQkFBZ0IsSUFBSXZELFNBQVMsRUFBRTtBQUVyRCxRQUFNLENBQUN3RCxlQUFlQyxnQkFBZ0IsSUFBSXpELFNBQXNCLElBQUk7QUFDcEUsUUFBTSxDQUFDMEQsZUFBZUMsZ0JBQWdCLElBQUkzRCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNEQsc0JBQXNCQyx1QkFBdUIsSUFBSTdELFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUM4RCxjQUFjQyxlQUFlLElBQUkvRCxTQUFTLEtBQUs7QUFFdEQsUUFBTWdFLGdCQUFnQjNDLE1BQU00QztBQUFBQSxJQUMxQixDQUFDQyxNQUNDQSxFQUFFQyxLQUFLQyxZQUFZLEVBQUVDLFNBQVN6QyxXQUFXd0MsWUFBWSxDQUFDLEtBQ3RERixFQUFFSSxNQUFNRixZQUFZLEVBQUVDLFNBQVN6QyxXQUFXd0MsWUFBWSxDQUFDLEtBQ3ZERixFQUFFSyxLQUFLSCxZQUFZLEVBQUVDLFNBQVN6QyxXQUFXd0MsWUFBWSxDQUFDLEtBQ3JERixFQUFFTSxlQUFlTixFQUFFTSxZQUFZSixZQUFZLEVBQUVDLFNBQVN6QyxXQUFXd0MsWUFBWSxDQUFDO0FBQUEsRUFDbkY7QUFFQSxRQUFNSyx5QkFBeUIsT0FBT0MsTUFBdUI7QUFDM0RBLE1BQUVDLGVBQWU7QUFDakJ4QyxnQkFBWSxFQUFFO0FBQ2QsUUFBSSxDQUFDQyxRQUFRd0MsS0FBSyxLQUFLLENBQUN0QyxTQUFTc0MsS0FBSyxHQUFHO0FBQ3ZDekMsa0JBQVksMkNBQTJDO0FBQ3ZEO0FBQUEsSUFDRjtBQUVBRixvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsVUFBSVYsV0FBVztBQUNiLGNBQU1zRCxVQUFVLE1BQU10RCxVQUFVO0FBQUEsVUFDOUI0QyxNQUFNL0IsUUFBUXdDLEtBQUs7QUFBQSxVQUNuQk4sT0FBT2hDLFNBQVNzQyxLQUFLO0FBQUEsVUFDckJMLE1BQU07QUFBQSxVQUNOTyxPQUFPdEMsU0FBU29DLEtBQUssS0FBSztBQUFBLFVBQzFCRyxRQUFRO0FBQUEsUUFDVixDQUFDO0FBRUQsWUFBSUYsWUFBWSxPQUFPO0FBQ3JCNUMsMEJBQWdCLEtBQUs7QUFDckI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBRixtQkFBYSxLQUFLO0FBQ2xCTSxpQkFBVyxFQUFFO0FBQ2JFLGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUNkTixrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBUzZDLEtBQVU7QUFDakI3QyxrQkFBWTZDLEtBQUtDLFdBQVcsdUNBQXVDO0FBQUEsSUFDckUsVUFBQztBQUNDaEQsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsOEVBQTRFLHNDQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCWjtBQUFBQSxrQkFBTTZEO0FBQUFBLFlBQU87QUFBQSxlQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxpREFBK0MsaUhBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNO0FBQ2JuRCx5QkFBYSxJQUFJO0FBQ2pCSSx3QkFBWSxFQUFFO0FBQUEsVUFDaEI7QUFBQSxVQUNBLE1BQUs7QUFBQSxVQUNMLFNBQVE7QUFBQSxVQUNSLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQUk7QUFBQTtBQUFBLFFBUDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDZCQUFDLFVBQU8sV0FBVSwwRkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RztBQUFBLE1BQ3hHO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixPQUFPUDtBQUFBQSxVQUNQLFVBQVUsQ0FBQzhDLE1BQU03QyxjQUFjNkMsRUFBRVMsT0FBT0MsS0FBSztBQUFBLFVBQzdDLFdBQVU7QUFBQTtBQUFBLFFBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS21UO0FBQUEsU0FQclQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUhBQ2IsaUNBQUMsU0FDQztBQUFBLDZCQUFDLGVBQ0MsaUNBQUMsWUFDQztBQUFBLCtCQUFDLGFBQVUsVUFBUSxNQUFDLFdBQVUsYUFBWSw0QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3RELHVCQUFDLGFBQVUsVUFBUSxNQUFDLGdDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsYUFBVSxVQUFRLE1BQUMsOEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxhQUFVLFVBQVEsTUFBQyw2QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLGFBQVUsVUFBUSxNQUFDLDhCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsYUFBVSxVQUFRLE1BQUMsV0FBVSxjQUFhLHVCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FOcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxhQUNFcEIsd0JBQWNxQjtBQUFBQSxRQUFJLENBQUNuQixNQUNsQix1QkFBQyxZQUFvQixXQUFVLG9FQUM3QjtBQUFBLGlDQUFDLGFBQ0MsaUNBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSx1REFBdURBLFlBQUVDLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsT0FBRSxXQUFVLDBEQUEwREQsWUFBRUksU0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxlQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsYUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyw2REFDVEosRUFBRUssU0FBUyxnQkFDUCw2SEFDQSw4R0FBOEc7QUFBQSxjQUduSEwsWUFBRUs7QUFBQUE7QUFBQUEsWUFQTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSx3REFDbEJMLFlBQUVLLFNBQVMsZ0JBQ1YsdUJBQUMsVUFBSyxXQUFVLHNEQUFxRCw2Q0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0csSUFFbEdMLEVBQUVNLGVBQWUsOEJBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxzREFDbEJOLFlBQUVZLFNBQVMscUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFDQyxpQ0FBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsOElBQ2JaLFlBQUVhLFVBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0NiLEVBQUVvQixzQkFDRCx1QkFBQyxVQUFLLFdBQVUsa0xBQWdMLGtDQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLGNBQ25CLGlDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2IzQyxpQ0FBZXVCLENBQUM7QUFDaEJyQiw4QkFBWXFCLEVBQUVDLElBQUk7QUFDbEJwQiwrQkFBYW1CLEVBQUVJLEtBQUs7QUFDcEJyQiwrQkFBYWlCLEVBQUVZLFNBQVMsRUFBRTtBQUMxQnpCLDhCQUFZYSxFQUFFSyxJQUFJO0FBQ2xCaEIsbUNBQWlCVyxFQUFFcUIsYUFBYWpFLFNBQVMsQ0FBQyxHQUFHa0UsTUFBTSxFQUFFO0FBQ3JEckMsK0JBQWEsRUFBRTtBQUFBLGdCQUNqQjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBRU4saUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUE7QUFBQSxjQWI1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFDYk0sbUNBQWlCUyxDQUFDO0FBQ2xCUCxtQ0FBaUIsRUFBRTtBQUNuQkUsMENBQXdCLEVBQUU7QUFBQSxnQkFDNUI7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQ1YsT0FBTTtBQUFBLGdCQUVOLGlDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBO0FBQUEsY0FUL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2Isc0JBQUk0QixPQUFPQyxRQUFRLHVDQUF1Q3hCLEVBQUVDLElBQUksR0FBRyxHQUFHO0FBQ3BFMUMsbUNBQWV5QyxFQUFFc0IsRUFBRTtBQUFBLGtCQUNyQjtBQUFBLGdCQUNGO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQTtBQUFBLGNBVDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQ0EsS0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxhQWhGYXRCLEVBQUVzQixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUZBO0FBQUEsTUFDRCxLQXBGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsU0FoR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlHQSxLQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUdBO0FBQUEsSUFHQzFELGFBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSxxS0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxREFBb0QsdUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUN6RjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQyxhQUFhLEtBQUs7QUFBQSxZQUNqQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBO0FBQUEsVUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVMEMsd0JBQXdCLFdBQVUseUJBQy9DdkM7QUFBQUEsb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGlKQUNaQSxzQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdGLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLDJCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySDtBQUFBLFVBQzNIO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osT0FBT0U7QUFBQUEsY0FDUCxVQUFVLENBQUNzQyxNQUFNckMsV0FBV3FDLEVBQUVTLE9BQU9DLEtBQUs7QUFBQSxjQUMxQyxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1tTztBQUFBLGFBUnJPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnR0FBK0YscUNBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFJO0FBQUEsVUFDckk7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixPQUFPOUM7QUFBQUEsY0FDUCxVQUFVLENBQUNvQyxNQUFNbkMsWUFBWW1DLEVBQUVTLE9BQU9DLEtBQUs7QUFBQSxjQUMzQyxXQUFVO0FBQUE7QUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1tTztBQUFBLGFBUnJPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnR0FBK0Ysb0NBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9JO0FBQUEsVUFDcEk7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLGFBQVk7QUFBQSxjQUNaLE9BQU81QztBQUFBQSxjQUNQLFVBQVUsQ0FBQ2tDLE1BQU1qQyxZQUFZaUMsRUFBRVMsT0FBT0MsS0FBSztBQUFBLGNBQzNDLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS21PO0FBQUEsYUFQck87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsdUtBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsdUNBQ1g7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsa0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUE7QUFBQSxlQUR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsdURBQXFELHFJQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVcEQ7QUFBQUEsY0FDVixTQUFTLE1BQU1ELGFBQWEsS0FBSztBQUFBLGNBQ2pDLFdBQVU7QUFBQSxjQUE4TDtBQUFBO0FBQUEsWUFKMU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxVQUFVQztBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVUQSx5QkFBZSw0QkFBNEI7QUFBQTtBQUFBLFlBTDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsV0FwRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFFQTtBQUFBLFNBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpRkEsS0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1GQTtBQUFBLElBSURVLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSxxS0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxREFBb0QsaUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxRQUNuRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQyxlQUFlLElBQUk7QUFBQSxZQUNsQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBO0FBQUEsVUFKeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFVBQVUsT0FBTytCLE1BQU07QUFDckJBLGNBQUVDLGVBQWU7QUFDakIsa0JBQU1nQixrQkFBa0JyRSxTQUFTc0UsS0FBSyxDQUFDQyxZQUFZQSxRQUFRTCxPQUFPbEMsYUFBYTtBQUMvRSxrQkFBTXdDLFVBQVUsTUFBTXRFLGVBQWVrQixZQUFZOEMsSUFBSTtBQUFBLGNBQ25EckIsTUFBTXZCLFNBQVNnQyxLQUFLO0FBQUEsY0FDcEJOLE9BQU94QixVQUFVOEIsS0FBSztBQUFBLGNBQ3RCRSxPQUFPOUIsVUFBVTRCLEtBQUs7QUFBQSxjQUN0QkwsTUFBTW5CO0FBQUFBLGNBQ05tQyxXQUFXbkMsYUFBYSxrQkFBa0JFLGdCQUFnQnlDO0FBQUFBLGNBQzFEdkIsYUFBYXBCLGFBQWEsa0JBQWtCdUMsaUJBQWlCeEIsT0FBTzRCO0FBQUFBLFlBQ3RFLENBQUM7QUFDRCxnQkFBSUQsWUFBWSxNQUFPbkQsZ0JBQWUsSUFBSTtBQUFBO0FBQ3JDUSwyQkFBYSxnRUFBZ0U7QUFBQSxVQUNwRjtBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBRVREO0FBQUFBLHlCQUFhLHVCQUFDLFNBQUksV0FBVSxpSkFBaUpBLHVCQUFoSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSztBQUFBLFlBQ3hMLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLDJCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEySDtBQUFBLGNBQzNILHVCQUFDLFdBQU0sVUFBUSxNQUFDLE9BQU9OLFVBQVUsVUFBVSxDQUFDOEIsTUFBTTdCLFlBQVk2QixFQUFFUyxPQUFPQyxLQUFLLEdBQUcsV0FBVSxpTUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc1I7QUFBQSxpQkFGeFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnR0FBK0YsdUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVIO0FBQUEsY0FDdkgsdUJBQUMsV0FBTSxVQUFRLE1BQUMsTUFBSyxTQUFRLE9BQU90QyxXQUFXLFVBQVUsQ0FBQzRCLE1BQU0zQixhQUFhMkIsRUFBRVMsT0FBT0MsS0FBSyxHQUFHLFdBQVUsaU1BQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFTO0FBQUEsaUJBRnZTO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLHFCQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxSDtBQUFBLGNBQ3JILHVCQUFDLFdBQU0sT0FBT3BDLFdBQVcsVUFBVSxDQUFDMEIsTUFBTXpCLGFBQWF5QixFQUFFUyxPQUFPQyxLQUFLLEdBQUcsV0FBVSxpTUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK1E7QUFBQSxpQkFGalI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnR0FBK0Ysc0JBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNIO0FBQUEsY0FDdEg7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT2hDO0FBQUFBLGtCQUNQLGVBQWUsQ0FBQzRDLFFBQWEzQyxZQUFZMkMsR0FBRztBQUFBLGtCQUU1QztBQUFBLDJDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSw2Q0FBQyxjQUFXLE9BQU0saUJBQWdCLDZCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUErQztBQUFBLHNCQUMvQyx1QkFBQyxjQUFXLE9BQU0sZUFBYywyQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMkM7QUFBQSx5QkFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBO0FBQUE7QUFBQSxnQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNDNUMsYUFBYSxtQkFDWix1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdHQUErRiwwQ0FBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEk7QUFBQSxjQUMxSTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPRSxrQkFBa0JoQyxTQUFTLENBQUMsR0FBR2tFLE1BQU1PO0FBQUFBLGtCQUM1QyxlQUFlLENBQUNDLFFBQVF6QyxpQkFBaUJ5QyxHQUFHO0FBQUEsa0JBRTVDO0FBQUEsMkNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxpQkFDRTFFLG1CQUFTK0Q7QUFBQUEsc0JBQUksQ0FBQ1EsWUFDYix1QkFBQyxjQUE0QixPQUFPQSxRQUFRTCxJQUN6Q0s7QUFBQUEsZ0NBQVFJLGVBQWVKLFFBQVExQjtBQUFBQSx3QkFBSztBQUFBLHdCQUFHMEIsUUFBUUs7QUFBQUEsd0JBQVM7QUFBQSwyQkFEMUNMLFFBQVFMLElBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU03QyxlQUFlLElBQUk7QUFBQSxrQkFDbEMsV0FBVTtBQUFBLGtCQUE4TDtBQUFBO0FBQUEsZ0JBSDFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUFpSTtBQUFBO0FBQUEsZ0JBRjdJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBO0FBQUE7QUFBQSxRQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnRkE7QUFBQSxTQTFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkZBLEtBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2RkE7QUFBQSxJQUlEYSxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2IsaUNBQUMsU0FBSSxXQUFVLHFLQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFEQUFvRCxtQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBQ3JGLHVCQUFDLFlBQU8sU0FBUyxNQUFNQyxpQkFBaUIsSUFBSSxHQUFHLFdBQVUsb0dBQ3ZELGlDQUFDLEtBQUUsV0FBVSxhQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVLE9BQU9pQixNQUFNO0FBQ3JCQSxjQUFFQyxlQUFlO0FBQ2pCLGdCQUFJakIsY0FBY3dCLFNBQVMsS0FBS3hCLGtCQUFrQkUscUJBQXNCO0FBQ3hFRyw0QkFBZ0IsSUFBSTtBQUNwQixnQkFBSTtBQUNGLG9CQUFNckMsa0JBQWtCOEIsY0FBY2dDLElBQUk5QixhQUFhO0FBQ3ZERCwrQkFBaUIsSUFBSTtBQUFBLFlBQ3ZCLFVBQUM7QUFDQ00sOEJBQWdCLEtBQUs7QUFBQSxZQUN2QjtBQUFBLFVBQ0Y7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDRDQUEwQztBQUFBO0FBQUEsY0FDOUIsdUJBQUMsWUFBTyxXQUFVLGlDQUFpQ1Asd0JBQWNXLFFBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FBUztBQUFBLGNBQUdYLGNBQWNjO0FBQUFBLGNBQU07QUFBQSxpQkFEL0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnR0FBK0YsOEJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThIO0FBQUEsY0FDOUgsdUJBQUMsV0FBTSxVQUFRLE1BQUMsV0FBVyxHQUFHLE1BQUssWUFBVyxPQUFPWixlQUFlLFVBQVUsQ0FBQ2dCLE1BQU1mLGlCQUFpQmUsRUFBRVMsT0FBT0MsS0FBSyxHQUFHLGFBQVksd0JBQXVCLFdBQVUsaU1BQXBLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlXO0FBQUEsaUJBRm5XO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0dBQStGLGtDQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrSTtBQUFBLGNBQ2xJLHVCQUFDLFdBQU0sVUFBUSxNQUFDLFdBQVcsR0FBRyxNQUFLLFlBQVcsT0FBT3hCLHNCQUFzQixVQUFVLENBQUNjLE1BQU1iLHdCQUF3QmEsRUFBRVMsT0FBT0MsS0FBSyxHQUFHLGFBQVkseUJBQXdCLFdBQVUsaU1BQW5MO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdYO0FBQUEsaUJBRmxYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNDeEIsd0JBQXdCRixrQkFBa0JFLHdCQUN6Qyx1QkFBQyxPQUFFLFdBQVUsNERBQTJELHVDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRjtBQUFBLFlBRWpHLHVCQUFDLFNBQUksV0FBVSwrRUFDYjtBQUFBLHFDQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTUgsaUJBQWlCLElBQUksR0FBRyxXQUFVLGdNQUErTCxzQkFBdFE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNFE7QUFBQSxjQUM1USx1QkFBQyxZQUFPLE1BQUssVUFBUyxVQUFVSyxnQkFBZ0JKLGNBQWN3QixTQUFTLEtBQUt4QixrQkFBa0JFLHNCQUFzQixXQUFVLHVKQUMzSEUseUJBQWUsd0JBQXdCLGtCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBO0FBQUE7QUFBQSxRQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQ0E7QUFBQSxTQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0Q0E7QUFBQSxPQTFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNFhBO0FBRUo7QUFBRW5DLEdBemNXUCxvQkFBcUQ7QUFBQSxLQUFyREE7QUFBcUQsSUFBQStFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJBY3Rpb25CdXR0b24iLCJCYWRnZSIsIlRhYmxlIiwiVGFibGVIZWFkZXIiLCJUYWJsZUJvZHkiLCJUYWJsZVJvdyIsIlRhYmxlQ2VsbCIsIlBsdXMiLCJTZWFyY2giLCJTaGllbGRDaGVjayIsIlgiLCJFZGl0MyIsIlRyYXNoMiIsIktleVJvdW5kIiwiVXNlck1hbmFnZW1lbnRWaWV3IiwidXNlcnMiLCJjbHVzdGVycyIsIm9uQWRkVXNlciIsIm9uVXBkYXRlVXNlciIsIm9uRGVsZXRlVXNlciIsIm9uUmVzZXRQYXNzd29yZCIsIl9zIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJpc0FkZE9wZW4iLCJzZXRJc0FkZE9wZW4iLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJhZGRFcnJvciIsInNldEFkZEVycm9yIiwibmV3TmFtZSIsInNldE5ld05hbWUiLCJuZXdFbWFpbCIsInNldE5ld0VtYWlsIiwibmV3UGhvbmUiLCJzZXROZXdQaG9uZSIsImVkaXRpbmdVc2VyIiwic2V0RWRpdGluZ1VzZXIiLCJlZGl0TmFtZSIsInNldEVkaXROYW1lIiwiZWRpdEVtYWlsIiwic2V0RWRpdEVtYWlsIiwiZWRpdFBob25lIiwic2V0RWRpdFBob25lIiwiZWRpdEVycm9yIiwic2V0RWRpdEVycm9yIiwiZWRpdFJvbGUiLCJzZXRFZGl0Um9sZSIsImVkaXRDbHVzdGVySWQiLCJzZXRFZGl0Q2x1c3RlcklkIiwicmVzZXR0aW5nVXNlciIsInNldFJlc2V0dGluZ1VzZXIiLCJyZXNldFBhc3N3b3JkIiwic2V0UmVzZXRQYXNzd29yZCIsInJlc2V0UGFzc3dvcmRDb25maXJtIiwic2V0UmVzZXRQYXNzd29yZENvbmZpcm0iLCJyZXNldExvYWRpbmciLCJzZXRSZXNldExvYWRpbmciLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyIiwidSIsIm5hbWUiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZW1haWwiLCJyb2xlIiwiY2x1c3Rlck5hbWUiLCJoYW5kbGVDcmVhdGVTdXBlckFkbWluIiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsInN1Y2Nlc3MiLCJwaG9uZSIsInN0YXR1cyIsImVyciIsIm1lc3NhZ2UiLCJsZW5ndGgiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm1hcCIsIm11c3RDaGFuZ2VQYXNzd29yZCIsImNsdXN0ZXJJZCIsImlkIiwid2luZG93IiwiY29uZmlybSIsInNlbGVjdGVkQ2x1c3RlciIsImZpbmQiLCJjbHVzdGVyIiwidXBkYXRlZCIsInVuZGVmaW5lZCIsInZhbCIsImNvbGxlZ2VOYW1lIiwiZGlzdHJpY3QiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyTWFuYWdlbWVudFZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVXNlciwgQ2x1c3RlciB9IGZyb20gXCIuLi90eXBlc1wiO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSBcIi4vdWkvc2VsZWN0XCI7XG5pbXBvcnQgeyBBY3Rpb25CdXR0b24gfSBmcm9tIFwiLi91aS9hY3Rpb24tYnV0dG9uXCI7XG5pbXBvcnQgQmFkZ2UgZnJvbSBcIi4vdWkvYmFkZ2VcIjtcbmltcG9ydCB7IFRhYmxlLCBUYWJsZUhlYWRlciwgVGFibGVCb2R5LCBUYWJsZVJvdywgVGFibGVDZWxsIH0gZnJvbSBcIi4vdWkvdGFibGVcIjtcbmltcG9ydCB7IFBsdXMsIFNlYXJjaCwgU2hpZWxkQ2hlY2ssIFVzZXJDaGVjaywgWCwgRWRpdDMsIExvY2ssIFRyYXNoMiwgS2V5Um91bmQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmludGVyZmFjZSBVc2VyTWFuYWdlbWVudFZpZXdQcm9wcyB7XG4gIHVzZXJzOiBVc2VyW107XG4gIGNsdXN0ZXJzOiBDbHVzdGVyW107XG4gIG9uQWRkVXNlcj86ICh1c2VyOiBQYXJ0aWFsPFVzZXI+KSA9PiBQcm9taXNlPGJvb2xlYW4+IHwgdm9pZDtcbiAgb25VcGRhdGVVc2VyPzogKGlkOiBzdHJpbmcsIHVzZXI6IFBhcnRpYWw8VXNlcj4pID0+IFByb21pc2U8Ym9vbGVhbj47XG4gIG9uRGVsZXRlVXNlcj86IChpZDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+O1xuICBvblJlc2V0UGFzc3dvcmQ/OiAoaWQ6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbn1cblxuZXhwb3J0IGNvbnN0IFVzZXJNYW5hZ2VtZW50VmlldzogUmVhY3QuRkM8VXNlck1hbmFnZW1lbnRWaWV3UHJvcHM+ID0gKHtcbiAgdXNlcnMgPSBbXSxcbiAgY2x1c3RlcnMgPSBbXSxcbiAgb25BZGRVc2VyLFxuICBvblVwZGF0ZVVzZXIsXG4gIG9uRGVsZXRlVXNlcixcbiAgb25SZXNldFBhc3N3b3JkLFxufSkgPT4ge1xuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2lzQWRkT3Blbiwgc2V0SXNBZGRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FkZEVycm9yLCBzZXRBZGRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW25ld05hbWUsIHNldE5ld05hbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtuZXdFbWFpbCwgc2V0TmV3RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtuZXdQaG9uZSwgc2V0TmV3UGhvbmVdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgW2VkaXRpbmdVc2VyLCBzZXRFZGl0aW5nVXNlcl0gPSB1c2VTdGF0ZTxVc2VyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtlZGl0TmFtZSwgc2V0RWRpdE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtlZGl0RW1haWwsIHNldEVkaXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2VkaXRQaG9uZSwgc2V0RWRpdFBob25lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZWRpdEVycm9yLCBzZXRFZGl0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtlZGl0Um9sZSwgc2V0RWRpdFJvbGVdID0gdXNlU3RhdGU8XCJTdXBlciBBZG1pblwiIHwgXCJDbHVzdGVyIEFkbWluXCI+KFwiQ2x1c3RlciBBZG1pblwiKTtcbiAgY29uc3QgW2VkaXRDbHVzdGVySWQsIHNldEVkaXRDbHVzdGVySWRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgW3Jlc2V0dGluZ1VzZXIsIHNldFJlc2V0dGluZ1VzZXJdID0gdXNlU3RhdGU8VXNlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcmVzZXRQYXNzd29yZCwgc2V0UmVzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Jlc2V0UGFzc3dvcmRDb25maXJtLCBzZXRSZXNldFBhc3N3b3JkQ29uZmlybV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Jlc2V0TG9hZGluZywgc2V0UmVzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlcnMuZmlsdGVyKFxuICAgICh1KSA9PlxuICAgICAgdS5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgdS5lbWFpbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIHUucm9sZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICh1LmNsdXN0ZXJOYW1lICYmIHUuY2x1c3Rlck5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpKVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZVN1cGVyQWRtaW4gPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEFkZEVycm9yKFwiXCIpO1xuICAgIGlmICghbmV3TmFtZS50cmltKCkgfHwgIW5ld0VtYWlsLnRyaW0oKSkge1xuICAgICAgc2V0QWRkRXJyb3IoXCJGdWxsIG5hbWUgYW5kIGVtYWlsIGFkZHJlc3MgYXJlIHJlcXVpcmVkLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChvbkFkZFVzZXIpIHtcbiAgICAgICAgY29uc3Qgc3VjY2VzcyA9IGF3YWl0IG9uQWRkVXNlcih7XG4gICAgICAgICAgbmFtZTogbmV3TmFtZS50cmltKCksXG4gICAgICAgICAgZW1haWw6IG5ld0VtYWlsLnRyaW0oKSxcbiAgICAgICAgICByb2xlOiBcIlN1cGVyIEFkbWluXCIsXG4gICAgICAgICAgcGhvbmU6IG5ld1Bob25lLnRyaW0oKSB8fCBcIis5MSA5MDAwMCAwMDAwMFwiLFxuICAgICAgICAgIHN0YXR1czogXCJBY3RpdmVcIixcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKHN1Y2Nlc3MgPT09IGZhbHNlKSB7XG4gICAgICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgc2V0SXNBZGRPcGVuKGZhbHNlKTtcbiAgICAgIHNldE5ld05hbWUoXCJcIik7XG4gICAgICBzZXROZXdFbWFpbChcIlwiKTtcbiAgICAgIHNldE5ld1Bob25lKFwiXCIpO1xuICAgICAgc2V0QWRkRXJyb3IoXCJcIik7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEFkZEVycm9yKGVycj8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBjcmVhdGUgU3VwZXIgQWRtaW4gYWNjb3VudC5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBVc2VyICYgUm9sZSBNYW5hZ2VtZW50XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwicHJpbWFyeVwiIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICB7dXNlcnMubGVuZ3RofSBBdXRob3JpemVkIEFjY291bnRzXG4gICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgQ2VudHJhbGx5IG1hbmFnZSBTdXBlciBBZG1pbnMgKFN0YXRlIENvb3JkaW5hdG9ycykgYW5kIFJlZ2lvbmFsIENsdXN0ZXIgQWRtaW5zIGFjcm9zcyBUYW1pbCBOYWR1LlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPEFjdGlvbkJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHNldElzQWRkT3Blbih0cnVlKTtcbiAgICAgICAgICAgIHNldEFkZEVycm9yKFwiXCIpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICB2YXJpYW50PVwicHJpbWFyeVwiXG4gICAgICAgICAgaWNvbj17PFBsdXMgc2l6ZT17MTV9IC8+fVxuICAgICAgICA+XG4gICAgICAgICAgQWRkIFN1cGVyIEFkbWluXG4gICAgICAgIDwvQWN0aW9uQnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGaWx0ZXIgLyBTZWFyY2ggQmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctc21cIj5cbiAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBuYW1lLCBlbWFpbCwgb3Igcm9sZS4uLlwiXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGVybX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHBsLTEwIHByLTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwLzEwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6cGxhY2Vob2xkZXI6dGV4dC1ncmF5LTUwMFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFRhYmxlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl1cIj5cbiAgICAgICAgPFRhYmxlPlxuICAgICAgICAgIDxUYWJsZUhlYWRlcj5cbiAgICAgICAgICAgIDxUYWJsZVJvdz5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlciBjbGFzc05hbWU9XCJ3LVsyODBweF1cIj5Vc2VyIERldGFpbHM8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5Sb2xlIERlc2lnbmF0aW9uPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+UmVnaW9uYWwgU2NvcGU8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5Db250YWN0IFBob25lPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+QWNjb3VudCBTdGF0dXM8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlciBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+QWN0aW9uczwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICA8L1RhYmxlSGVhZGVyPlxuICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKHUpID0+IChcbiAgICAgICAgICAgICAgPFRhYmxlUm93IGtleT17dS5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MC84MCBkYXJrOmhvdmVyOmJnLXdoaXRlL1swLjAyXSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQteHNcIj57dS5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZm9udC1tb25vXCI+e3UuZW1haWx9PC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgIHUucm9sZSA9PT0gXCJTdXBlciBBZG1pblwiXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS05MDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIGRhcms6YmctcHVycGxlLTkwMC8zMCBkYXJrOnRleHQtcHVycGxlLTMwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtOTAwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgZGFyazpiZy1ibHVlLTkwMC8zMCBkYXJrOnRleHQtYmx1ZS0zMDAgZGFyazpib3JkZXItYmx1ZS04MDBcIlxuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3Uucm9sZX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIHt1LnJvbGUgPT09IFwiU3VwZXIgQWRtaW5cIiA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNzAwIGRhcms6dGV4dC1wdXJwbGUtNDAwIGZvbnQtc2VtaWJvbGRcIj5TdGF0ZSBDZW50cmFsIEF1dGhvcml0eSAoQWxsKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIHUuY2x1c3Rlck5hbWUgfHwgXCJBc3NpZ25lZCBDb2xsZWdlIENsdXN0ZXJcIlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZvbnQtbW9ubyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICB7dS5waG9uZSB8fCBcIis5MSA5MDAwMCAwMDAwMFwifVxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTAuNXB4XSBmb250LWJvbGQgYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOmJnLWVtZXJhbGQtOTAwLzMwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt1LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7dS5tdXN0Q2hhbmdlUGFzc3dvcmQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTgwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJnLWFtYmVyLTkwMC8zMCBkYXJrOnRleHQtYW1iZXItMzAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZyBPbmJvYXJkaW5nXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nVXNlcih1KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXROYW1lKHUubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0RW1haWwodS5lbWFpbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0UGhvbmUodS5waG9uZSB8fCBcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRSb2xlKHUucm9sZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0Q2x1c3RlcklkKHUuY2x1c3RlcklkIHx8IGNsdXN0ZXJzWzBdPy5pZCB8fCBcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVkaXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IGRhcms6aG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IFVzZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEVkaXQzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlc2V0dGluZ1VzZXIodSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSZXNldFBhc3N3b3JkKFwiXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0UmVzZXRQYXNzd29yZENvbmZpcm0oXCJcIik7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMS41IHRleHQtZ3JheS01MDAgaG92ZXI6YmctYW1iZXItNTAgaG92ZXI6dGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6YmctYW1iZXItNTAwLzEwIGRhcms6aG92ZXI6dGV4dC1hbWJlci00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBQYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8S2V5Um91bmQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5jb25maXJtKGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVhY3RpdmF0ZSAke3UubmFtZX0/YCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25EZWxldGVVc2VyPy4odS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHAtMS41IHRleHQtZ3JheS01MDAgaG92ZXI6YmctZXJyb3ItNTAgaG92ZXI6dGV4dC1lcnJvci02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6YmctZXJyb3ItNTAwLzEwIGRhcms6aG92ZXI6dGV4dC1lcnJvci00MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgVXNlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9UYWJsZUJvZHk+XG4gICAgICAgIDwvVGFibGU+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFkZCBTdXBlciBBZG1pbiBNb2RhbCAqL31cbiAgICAgIHtpc0FkZE9wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDAgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LW1kIHNoYWRvdy10aGVtZS14bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiBmYWRlLWluLTAgem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPkFkZCBDZW50cmFsIFN1cGVyIEFkbWluPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQWRkT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBwLTEgcm91bmRlZC1sZyB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlU3VwZXJBZG1pbn0gY2xhc3NOYW1lPVwicC01IHNwYWNlLXktNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIHthZGRFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLXhsIGJnLWVycm9yLTUwIGJvcmRlciBib3JkZXItZXJyb3ItMjAwIHRleHQtZXJyb3ItNzAwIHRleHQteHMgZGFyazpiZy1lcnJvci01MDAvMTAgZGFyazpib3JkZXItZXJyb3ItNTAwLzIwIGRhcms6dGV4dC1lcnJvci00MDBcIj5cbiAgICAgICAgICAgICAgICAgIHthZGRFcnJvcn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPkZ1bGwgTmFtZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gUy4gQW5hbmRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld05hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld05hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMi41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPkxvZ2luIEVtYWlsIEFkZHJlc3MgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBhbmFuZC5zQHRxaS5vcmdcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0VtYWlsfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yLjUgdGV4dC14cyB0ZXh0LWdyYXktODAwIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41XCI+Q29udGFjdCBQaG9uZSBOdW1iZXI8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuICs5MSA5NjI5MSA1NTY3MlwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGhvbmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bob25lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXI6dGV4dC1ncmF5LTQwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1wdXJwbGUtNTAvNzAgZGFyazpiZy1wdXJwbGUtOTAwLzIwIGJvcmRlciBib3JkZXItcHVycGxlLTIwMC84MCBkYXJrOmJvcmRlci1wdXJwbGUtODAwLzYwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXB1cnBsZS05MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICBDZW50cmFsIFN1cGVyIEFkbWluIEF1dGhvcml0eVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS04MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDAvODAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIFRoaXMgYWNjb3VudCB3aWxsIGhhdmUgc3RhdGV3aWRlIGF1dGhvcml0eSBhY3Jvc3MgYWxsIGNvbGxlZ2UgY2x1c3RlcnMsIHBhbmNoYXlhdHMsIG1vZHVsZXMsIGFuZCBmaW5hbmNpYWwgYXBwcm92YWxzLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGp1c3RpZnktZW5kIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0FkZE9wZW4oZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYmctYnJhbmQtNTAwIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiQ3JlYXRpbmcgU3VwZXIgQWRtaW4uLi5cIiA6IFwiQ3JlYXRlIFN1cGVyIEFkbWluXCJ9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFZGl0IFVzZXIgTW9kYWwgKi99XG4gICAgICB7ZWRpdGluZ1VzZXIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDAgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LW1kIHNoYWRvdy10aGVtZS14bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiBmYWRlLWluLTAgem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPkVkaXQgVXNlciBEZXRhaWxzPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEVkaXRpbmdVc2VyKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgcC0xIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICAgIG9uU3VibWl0PXthc3luYyAoZSkgPT4ge1xuICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RlZENsdXN0ZXIgPSBjbHVzdGVycy5maW5kKChjbHVzdGVyKSA9PiBjbHVzdGVyLmlkID09PSBlZGl0Q2x1c3RlcklkKTtcbiAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgb25VcGRhdGVVc2VyPy4oZWRpdGluZ1VzZXIuaWQsIHtcbiAgICAgICAgICAgICAgICAgIG5hbWU6IGVkaXROYW1lLnRyaW0oKSxcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiBlZGl0RW1haWwudHJpbSgpLFxuICAgICAgICAgICAgICAgICAgcGhvbmU6IGVkaXRQaG9uZS50cmltKCksXG4gICAgICAgICAgICAgICAgICByb2xlOiBlZGl0Um9sZSxcbiAgICAgICAgICAgICAgICAgIGNsdXN0ZXJJZDogZWRpdFJvbGUgPT09IFwiQ2x1c3RlciBBZG1pblwiID8gZWRpdENsdXN0ZXJJZCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgIGNsdXN0ZXJOYW1lOiBlZGl0Um9sZSA9PT0gXCJDbHVzdGVyIEFkbWluXCIgPyBzZWxlY3RlZENsdXN0ZXI/Lm5hbWUgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgaWYgKHVwZGF0ZWQgIT09IGZhbHNlKSBzZXRFZGl0aW5nVXNlcihudWxsKTtcbiAgICAgICAgICAgICAgICBlbHNlIHNldEVkaXRFcnJvcihcIlVuYWJsZSB0byBzYXZlIGNoYW5nZXMuIENoZWNrIHRoZSBlbWFpbCBvciBjbHVzdGVyIGFzc2lnbm1lbnQuXCIpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTUgc3BhY2UteS0zLjUgdGV4dC14c1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtlZGl0RXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLXhsIGJnLWVycm9yLTUwIGJvcmRlciBib3JkZXItZXJyb3ItMjAwIHRleHQtZXJyb3ItNzAwIHRleHQteHMgZGFyazpiZy1lcnJvci01MDAvMTAgZGFyazpib3JkZXItZXJyb3ItNTAwLzIwIGRhcms6dGV4dC1lcnJvci00MDBcIj57ZWRpdEVycm9yfTwvZGl2Pn1cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5GdWxsIE5hbWUgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IHJlcXVpcmVkIHZhbHVlPXtlZGl0TmFtZX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0TmFtZShlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5FbWFpbCAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgcmVxdWlyZWQgdHlwZT1cImVtYWlsXCIgdmFsdWU9e2VkaXRFbWFpbH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0RW1haWwoZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXRyYW5zcGFyZW50IHB4LTMuNSBweS0yLjUgdGV4dC14cyB0ZXh0LWdyYXktODAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWItMS41XCI+UGhvbmU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB2YWx1ZT17ZWRpdFBob25lfSBvbkNoYW5nZT17KGUpID0+IHNldEVkaXRQaG9uZShlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5Sb2xlICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0Um9sZX1cbiAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWw6IGFueSkgPT4gc2V0RWRpdFJvbGUodmFsKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUm9sZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDbHVzdGVyIEFkbWluXCI+Q2x1c3RlciBBZG1pbjwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJTdXBlciBBZG1pblwiPlN1cGVyIEFkbWluPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge2VkaXRSb2xlID09PSBcIkNsdXN0ZXIgQWRtaW5cIiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPkFzc2lnbmVkIENvbGxlZ2UgQ2x1c3RlciAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRDbHVzdGVySWQgfHwgKGNsdXN0ZXJzWzBdPy5pZCA/PyB1bmRlZmluZWQpfVxuICAgICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRFZGl0Q2x1c3RlcklkKHZhbCl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IENsdXN0ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgIHtjbHVzdGVycy5tYXAoKGNsdXN0ZXIpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17Y2x1c3Rlci5pZH0gdmFsdWU9e2NsdXN0ZXIuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2x1c3Rlci5jb2xsZWdlTmFtZSB8fCBjbHVzdGVyLm5hbWV9ICh7Y2x1c3Rlci5kaXN0cmljdH0pXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RWRpdGluZ1VzZXIobnVsbCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBTYXZlIENoYW5nZXNcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJlc2V0IFBhc3N3b3JkIE1vZGFsICovfVxuICAgICAge3Jlc2V0dGluZ1VzZXIgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDAgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LW1kIHNoYWRvdy10aGVtZS14bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1pbiBmYWRlLWluLTAgem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlJlc2V0IFVzZXIgUGFzc3dvcmQ8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFJlc2V0dGluZ1VzZXIobnVsbCl9IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgcC0xIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgICAgb25TdWJtaXQ9e2FzeW5jIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIGlmIChyZXNldFBhc3N3b3JkLmxlbmd0aCA8IDggfHwgcmVzZXRQYXNzd29yZCAhPT0gcmVzZXRQYXNzd29yZENvbmZpcm0pIHJldHVybjtcbiAgICAgICAgICAgICAgICBzZXRSZXNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGF3YWl0IG9uUmVzZXRQYXNzd29yZD8uKHJlc2V0dGluZ1VzZXIuaWQsIHJlc2V0UGFzc3dvcmQpO1xuICAgICAgICAgICAgICAgICAgc2V0UmVzZXR0aW5nVXNlcihudWxsKTtcbiAgICAgICAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgc2V0UmVzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNSBzcGFjZS15LTQgdGV4dC14c1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICBTZXQgYSBuZXcgcGFzc3dvcmQgZm9yIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57cmVzZXR0aW5nVXNlci5uYW1lfTwvc3Ryb25nPiAoe3Jlc2V0dGluZ1VzZXIuZW1haWx9KS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPk5ldyBQYXNzd29yZCAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXQgcmVxdWlyZWQgbWluTGVuZ3RoPXs4fSB0eXBlPVwicGFzc3dvcmRcIiB2YWx1ZT17cmVzZXRQYXNzd29yZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJNaW5pbXVtIDggY2hhcmFjdGVyc1wiIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctdHJhbnNwYXJlbnQgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xLjVcIj5Db25maXJtIFBhc3N3b3JkICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCByZXF1aXJlZCBtaW5MZW5ndGg9ezh9IHR5cGU9XCJwYXNzd29yZFwiIHZhbHVlPXtyZXNldFBhc3N3b3JkQ29uZmlybX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXNldFBhc3N3b3JkQ29uZmlybShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiUmUtZW50ZXIgbmV3IHBhc3N3b3JkXCIgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBweC0zLjUgcHktMi41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7cmVzZXRQYXNzd29yZENvbmZpcm0gJiYgcmVzZXRQYXNzd29yZCAhPT0gcmVzZXRQYXNzd29yZENvbmZpcm0gJiYgKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZXJyb3ItNjAwIGRhcms6dGV4dC1lcnJvci00MDAgZm9udC1zZW1pYm9sZCB0ZXh0LXhzXCI+UGFzc3dvcmRzIGRvIG5vdCBtYXRjaC48L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0UmVzZXR0aW5nVXNlcihudWxsKX0gY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5DYW5jZWw8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17cmVzZXRMb2FkaW5nIHx8IHJlc2V0UGFzc3dvcmQubGVuZ3RoIDwgOCB8fCByZXNldFBhc3N3b3JkICE9PSByZXNldFBhc3N3b3JkQ29uZmlybX0gY2xhc3NOYW1lPVwicm91bmRlZC14bCBiZy1icmFuZC01MDAgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1icmFuZC02MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICAgICAgICB7cmVzZXRMb2FkaW5nID8gXCJTZXR0aW5nIFBhc3N3b3JkLi4uXCIgOiBcIlNldCBQYXNzd29yZFwifVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Vc2VyTWFuYWdlbWVudFZpZXcudHN4In0=