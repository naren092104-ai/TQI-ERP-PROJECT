import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/theme-provider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
const initialState = {
  theme: "system",
  setTheme: () => null
};
const ThemeProviderContext = createContext(initialState);
export function ThemeProvider({
  children,
  defaultTheme = "light",
  storageKey = "vite-ui-theme",
  ...props
}) {
  _s();
  const [theme, setTheme] = useState(
    () => localStorage.getItem(storageKey) || defaultTheme
  );
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.classList.add(systemTheme);
      return;
    }
    root.classList.add(theme);
  }, [theme]);
  const value = {
    theme,
    setTheme: (newTheme) => {
      localStorage.setItem(storageKey, newTheme);
      setTheme(newTheme);
    }
  };
  return /* @__PURE__ */ jsxDEV(ThemeProviderContext.Provider, { ...props, value, children }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/theme-provider.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
}
_s(ThemeProvider, "YkY4D08WntVjXLroWjAGi4sfNRs=");
_c = ThemeProvider;
export const useTheme = () => {
  _s2();
  const context = useContext(ThemeProviderContext);
  if (context === void 0)
    throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "ThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/theme-provider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/theme-provider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/theme-provider.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRJOztBQTNESixTQUFTQSxlQUFlQyxZQUFZQyxXQUFXQyxnQkFBZ0I7QUFlL0QsTUFBTUMsZUFBbUM7QUFBQSxFQUN2Q0MsT0FBTztBQUFBLEVBQ1BDLFVBQVVBLE1BQU07QUFDbEI7QUFFQSxNQUFNQyx1QkFBdUJQLGNBQWtDSSxZQUFZO0FBRXBFLGdCQUFTSSxjQUFjO0FBQUEsRUFDNUJDO0FBQUFBLEVBQ0FDLGVBQWU7QUFBQSxFQUNmQyxhQUFhO0FBQUEsRUFDYixHQUFHQztBQUNlLEdBQUc7QUFBQUMsS0FBQTtBQUNyQixRQUFNLENBQUNSLE9BQU9DLFFBQVEsSUFBSUg7QUFBQUEsSUFDeEIsTUFBT1csYUFBYUMsUUFBUUosVUFBVSxLQUFlRDtBQUFBQSxFQUN2RDtBQUVBUixZQUFVLE1BQU07QUFDZCxVQUFNYyxPQUFPQyxPQUFPQyxTQUFTQztBQUU3QkgsU0FBS0ksVUFBVUMsT0FBTyxTQUFTLE1BQU07QUFFckMsUUFBSWhCLFVBQVUsVUFBVTtBQUN0QixZQUFNaUIsY0FBY0wsT0FBT00sV0FBVyw4QkFBOEIsRUFDakVDLFVBQ0MsU0FDQTtBQUVKUixXQUFLSSxVQUFVSyxJQUFJSCxXQUFXO0FBQzlCO0FBQUEsSUFDRjtBQUVBTixTQUFLSSxVQUFVSyxJQUFJcEIsS0FBSztBQUFBLEVBQzFCLEdBQUcsQ0FBQ0EsS0FBSyxDQUFDO0FBRVYsUUFBTXFCLFFBQVE7QUFBQSxJQUNackI7QUFBQUEsSUFDQUMsVUFBVUEsQ0FBQ3FCLGFBQW9CO0FBQzdCYixtQkFBYWMsUUFBUWpCLFlBQVlnQixRQUFRO0FBQ3pDckIsZUFBU3FCLFFBQVE7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLHFCQUFxQixVQUFyQixFQUE4QixHQUFJZixPQUFPLE9BQ3ZDSCxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUNJLEdBekNlTCxlQUFhO0FBQUEsS0FBYkE7QUEyQ1QsYUFBTXFCLFdBQVdBLE1BQU07QUFBQUMsTUFBQTtBQUM1QixRQUFNQyxVQUFVOUIsV0FBV00sb0JBQW9CO0FBRS9DLE1BQUl3QixZQUFZQztBQUNkLFVBQU0sSUFBSUMsTUFBTSw4Q0FBOEM7QUFFaEUsU0FBT0Y7QUFDVDtBQUFFRCxJQVBXRCxVQUFRO0FBQUEsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImluaXRpYWxTdGF0ZSIsInRoZW1lIiwic2V0VGhlbWUiLCJUaGVtZVByb3ZpZGVyQ29udGV4dCIsIlRoZW1lUHJvdmlkZXIiLCJjaGlsZHJlbiIsImRlZmF1bHRUaGVtZSIsInN0b3JhZ2VLZXkiLCJwcm9wcyIsIl9zIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInJvb3QiLCJ3aW5kb3ciLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsImNsYXNzTGlzdCIsInJlbW92ZSIsInN5c3RlbVRoZW1lIiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJhZGQiLCJ2YWx1ZSIsIm5ld1RoZW1lIiwic2V0SXRlbSIsInVzZVRoZW1lIiwiX3MyIiwiY29udGV4dCIsInVuZGVmaW5lZCIsIkVycm9yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidGhlbWUtcHJvdmlkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxudHlwZSBUaGVtZSA9IFwiZGFya1wiIHwgXCJsaWdodFwiIHwgXCJzeXN0ZW1cIjtcblxudHlwZSBUaGVtZVByb3ZpZGVyUHJvcHMgPSB7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG4gIGRlZmF1bHRUaGVtZT86IFRoZW1lO1xuICBzdG9yYWdlS2V5Pzogc3RyaW5nO1xufTtcblxudHlwZSBUaGVtZVByb3ZpZGVyU3RhdGUgPSB7XG4gIHRoZW1lOiBUaGVtZTtcbiAgc2V0VGhlbWU6ICh0aGVtZTogVGhlbWUpID0+IHZvaWQ7XG59O1xuXG5jb25zdCBpbml0aWFsU3RhdGU6IFRoZW1lUHJvdmlkZXJTdGF0ZSA9IHtcbiAgdGhlbWU6IFwic3lzdGVtXCIsXG4gIHNldFRoZW1lOiAoKSA9PiBudWxsLFxufTtcblxuY29uc3QgVGhlbWVQcm92aWRlckNvbnRleHQgPSBjcmVhdGVDb250ZXh0PFRoZW1lUHJvdmlkZXJTdGF0ZT4oaW5pdGlhbFN0YXRlKTtcblxuZXhwb3J0IGZ1bmN0aW9uIFRoZW1lUHJvdmlkZXIoe1xuICBjaGlsZHJlbixcbiAgZGVmYXVsdFRoZW1lID0gXCJsaWdodFwiLFxuICBzdG9yYWdlS2V5ID0gXCJ2aXRlLXVpLXRoZW1lXCIsXG4gIC4uLnByb3BzXG59OiBUaGVtZVByb3ZpZGVyUHJvcHMpIHtcbiAgY29uc3QgW3RoZW1lLCBzZXRUaGVtZV0gPSB1c2VTdGF0ZTxUaGVtZT4oXG4gICAgKCkgPT4gKGxvY2FsU3RvcmFnZS5nZXRJdGVtKHN0b3JhZ2VLZXkpIGFzIFRoZW1lKSB8fCBkZWZhdWx0VGhlbWVcbiAgKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSB3aW5kb3cuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuXG4gICAgcm9vdC5jbGFzc0xpc3QucmVtb3ZlKFwibGlnaHRcIiwgXCJkYXJrXCIpO1xuXG4gICAgaWYgKHRoZW1lID09PSBcInN5c3RlbVwiKSB7XG4gICAgICBjb25zdCBzeXN0ZW1UaGVtZSA9IHdpbmRvdy5tYXRjaE1lZGlhKFwiKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKVwiKVxuICAgICAgICAubWF0Y2hlc1xuICAgICAgICA/IFwiZGFya1wiXG4gICAgICAgIDogXCJsaWdodFwiO1xuXG4gICAgICByb290LmNsYXNzTGlzdC5hZGQoc3lzdGVtVGhlbWUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHJvb3QuY2xhc3NMaXN0LmFkZCh0aGVtZSk7XG4gIH0sIFt0aGVtZV0pO1xuXG4gIGNvbnN0IHZhbHVlID0ge1xuICAgIHRoZW1lLFxuICAgIHNldFRoZW1lOiAobmV3VGhlbWU6IFRoZW1lKSA9PiB7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShzdG9yYWdlS2V5LCBuZXdUaGVtZSk7XG4gICAgICBzZXRUaGVtZShuZXdUaGVtZSk7XG4gICAgfSxcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxUaGVtZVByb3ZpZGVyQ29udGV4dC5Qcm92aWRlciB7Li4ucHJvcHN9IHZhbHVlPXt2YWx1ZX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9UaGVtZVByb3ZpZGVyQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHVzZVRoZW1lID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChUaGVtZVByb3ZpZGVyQ29udGV4dCk7XG5cbiAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZClcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VUaGVtZSBtdXN0IGJlIHVzZWQgd2l0aGluIGEgVGhlbWVQcm92aWRlclwiKTtcblxuICByZXR1cm4gY29udGV4dDtcbn07XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdGhlbWUtcHJvdmlkZXIudHN4In0=