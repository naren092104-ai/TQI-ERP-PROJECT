import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\ui\\action-button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport1_react);
import { ArrowUpRight } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { cn } from "/src/lib/utils.ts";
export const ActionButton = React.forwardRef(
  _c = ({ className, children, icon, variant = "primary", size = "default", ...props }, ref) => {
    const variantStyles = {
      primary: "bg-brand-500 hover:bg-brand-600 text-white shadow-lg shadow-brand-500/20 hover:shadow-brand-500/30 text-white",
      success: "bg-success-600 hover:bg-success-700 text-white shadow-lg shadow-success-600/20 hover:shadow-success-600/30 text-white",
      dark: "bg-gray-900 hover:bg-black text-white shadow-lg shadow-gray-900/20 hover:shadow-gray-900/30 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100",
      outline: "border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 shadow-theme-xs dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300"
    };
    const iconColorStyles = {
      primary: "text-brand-500",
      success: "text-success-600",
      dark: "text-gray-900 dark:text-white",
      outline: "text-gray-700 dark:text-gray-300"
    };
    const sizeStyles = {
      sm: "h-9 min-w-[130px] p-1 pl-4 pr-10 text-xs hover:pl-10 hover:pr-4",
      default: "h-10 min-w-[150px] p-1 pl-5 pr-11 text-xs hover:pl-11 hover:pr-5",
      lg: "h-12 min-w-[184px] p-1 pl-6 pr-14 text-sm hover:pl-14 hover:pr-6"
    };
    const iconCircleSizes = {
      sm: "h-7 w-7 group-hover:right-[calc(100%-32px)]",
      default: "h-8 w-8 group-hover:right-[calc(100%-36px)]",
      lg: "h-10 w-10 group-hover:right-[calc(100%-44px)]"
    };
    return /* @__PURE__ */ jsxDEV(
      "button",
      {
        ref,
        type: "button",
        className: cn(
          "group relative cursor-pointer overflow-hidden rounded-full border-0 font-semibold transition-all duration-500 active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 inline-flex items-center justify-center",
          variantStyles[variant],
          sizeStyles[size],
          className
        ),
        ...props,
        children: [
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: "pointer-events-none absolute inset-0 -translate-x-[130%] skew-x-[-20deg] bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-[130%]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx",
              lineNumber: 54,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "relative z-10 whitespace-nowrap font-medium transition-all duration-300", children }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx",
            lineNumber: 59,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: cn(
                "absolute right-1 top-1/2 z-10 grid -translate-y-1/2 place-items-center rounded-full bg-white shadow-sm transition-[right,transform] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:-translate-y-1/2 group-hover:rotate-45 shrink-0",
                iconCircleSizes[size],
                iconColorStyles[variant]
              ),
              children: icon || /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: size === "sm" ? 13 : size === "default" ? 15 : 17, strokeWidth: 2.2 }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx",
                lineNumber: 71,
                columnNumber: 20
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx",
              lineNumber: 64,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx",
        lineNumber: 42,
        columnNumber: 5
      },
      this
    );
  }
);
_c2 = ActionButton;
ActionButton.displayName = "ActionButton";
var _c, _c2;
$RefreshReg$(_c, "ActionButton$React.forwardRef");
$RefreshReg$(_c2, "ActionButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/action-button.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURRO0FBckRSLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFVBQVU7QUFVWixhQUFNQyxlQUFlSCxNQUFNSTtBQUFBQSxFQUFnREMsS0FDaEZBLENBQUMsRUFBRUMsV0FBV0MsVUFBVUMsTUFBTUMsVUFBVSxXQUFXQyxPQUFPLFdBQVcsR0FBR0MsTUFBTSxHQUFHQyxRQUFRO0FBQ3ZGLFVBQU1DLGdCQUFnQjtBQUFBLE1BQ3BCQyxTQUFTO0FBQUEsTUFDVEMsU0FBUztBQUFBLE1BQ1RDLE1BQU07QUFBQSxNQUNOQyxTQUFTO0FBQUEsSUFDWDtBQUVBLFVBQU1DLGtCQUFrQjtBQUFBLE1BQ3RCSixTQUFTO0FBQUEsTUFDVEMsU0FBUztBQUFBLE1BQ1RDLE1BQU07QUFBQSxNQUNOQyxTQUFTO0FBQUEsSUFDWDtBQUVBLFVBQU1FLGFBQWE7QUFBQSxNQUNqQkMsSUFBSTtBQUFBLE1BQ0pDLFNBQVM7QUFBQSxNQUNUQyxJQUFJO0FBQUEsSUFDTjtBQUVBLFVBQU1DLGtCQUFrQjtBQUFBLE1BQ3RCSCxJQUFJO0FBQUEsTUFDSkMsU0FBUztBQUFBLE1BQ1RDLElBQUk7QUFBQSxJQUNOO0FBRUEsV0FDRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLE1BQUs7QUFBQSxRQUNMLFdBQVdwQjtBQUFBQSxVQUNUO0FBQUEsVUFDQVcsY0FBY0osT0FBTztBQUFBLFVBQ3JCVSxXQUFXVCxJQUFJO0FBQUEsVUFDZko7QUFBQUEsUUFDRjtBQUFBLFFBQ0EsR0FBSUs7QUFBQUEsUUFHSjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUE7QUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUNxTjtBQUFBLFVBSXJOLHVCQUFDLFVBQUssV0FBVSwyRUFDYkosWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV0w7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQXFCLGdCQUFnQmIsSUFBSTtBQUFBLGdCQUNwQlEsZ0JBQWdCVCxPQUFPO0FBQUEsY0FDekI7QUFBQSxjQUVDRCxrQkFBUSx1QkFBQyxnQkFBYSxNQUFNRSxTQUFTLE9BQU8sS0FBS0EsU0FBUyxZQUFZLEtBQUssSUFBSSxhQUFhLE9BQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdGO0FBQUE7QUFBQSxZQVBuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBO0FBQUE7QUFBQSxNQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUErQkE7QUFBQSxFQUVKO0FBQ0Y7QUFBRWMsTUEvRFdyQjtBQWdFYkEsYUFBYXNCLGNBQWM7QUFBZSxJQUFBcEIsSUFBQW1CO0FBQUEsYUFBQW5CLElBQUE7QUFBQSxhQUFBbUIsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQXJyb3dVcFJpZ2h0IiwiY24iLCJBY3Rpb25CdXR0b24iLCJmb3J3YXJkUmVmIiwiX2MiLCJjbGFzc05hbWUiLCJjaGlsZHJlbiIsImljb24iLCJ2YXJpYW50Iiwic2l6ZSIsInByb3BzIiwicmVmIiwidmFyaWFudFN0eWxlcyIsInByaW1hcnkiLCJzdWNjZXNzIiwiZGFyayIsIm91dGxpbmUiLCJpY29uQ29sb3JTdHlsZXMiLCJzaXplU3R5bGVzIiwic20iLCJkZWZhdWx0IiwibGciLCJpY29uQ2lyY2xlU2l6ZXMiLCJfYzIiLCJkaXNwbGF5TmFtZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhY3Rpb24tYnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEFycm93VXBSaWdodCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQWN0aW9uQnV0dG9uUHJvcHNcbiAgZXh0ZW5kcyBSZWFjdC5CdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4ge1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICBpY29uPzogUmVhY3QuUmVhY3ROb2RlO1xuICB2YXJpYW50PzogXCJwcmltYXJ5XCIgfCBcInN1Y2Nlc3NcIiB8IFwiZGFya1wiIHwgXCJvdXRsaW5lXCI7XG4gIHNpemU/OiBcInNtXCIgfCBcImRlZmF1bHRcIiB8IFwibGdcIjtcbn1cblxuZXhwb3J0IGNvbnN0IEFjdGlvbkJ1dHRvbiA9IFJlYWN0LmZvcndhcmRSZWY8SFRNTEJ1dHRvbkVsZW1lbnQsIEFjdGlvbkJ1dHRvblByb3BzPihcbiAgKHsgY2xhc3NOYW1lLCBjaGlsZHJlbiwgaWNvbiwgdmFyaWFudCA9IFwicHJpbWFyeVwiLCBzaXplID0gXCJkZWZhdWx0XCIsIC4uLnByb3BzIH0sIHJlZikgPT4ge1xuICAgIGNvbnN0IHZhcmlhbnRTdHlsZXMgPSB7XG4gICAgICBwcmltYXJ5OiBcImJnLWJyYW5kLTUwMCBob3ZlcjpiZy1icmFuZC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LWJyYW5kLTUwMC8yMCBob3ZlcjpzaGFkb3ctYnJhbmQtNTAwLzMwIHRleHQtd2hpdGVcIixcbiAgICAgIHN1Y2Nlc3M6IFwiYmctc3VjY2Vzcy02MDAgaG92ZXI6Ymctc3VjY2Vzcy03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LXN1Y2Nlc3MtNjAwLzIwIGhvdmVyOnNoYWRvdy1zdWNjZXNzLTYwMC8zMCB0ZXh0LXdoaXRlXCIsXG4gICAgICBkYXJrOiBcImJnLWdyYXktOTAwIGhvdmVyOmJnLWJsYWNrIHRleHQtd2hpdGUgc2hhZG93LWxnIHNoYWRvdy1ncmF5LTkwMC8yMCBob3ZlcjpzaGFkb3ctZ3JheS05MDAvMzAgZGFyazpiZy13aGl0ZSBkYXJrOnRleHQtZ3JheS05MDAgZGFyazpob3ZlcjpiZy1ncmF5LTEwMFwiLFxuICAgICAgb3V0bGluZTogXCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDBcIixcbiAgICB9O1xuXG4gICAgY29uc3QgaWNvbkNvbG9yU3R5bGVzID0ge1xuICAgICAgcHJpbWFyeTogXCJ0ZXh0LWJyYW5kLTUwMFwiLFxuICAgICAgc3VjY2VzczogXCJ0ZXh0LXN1Y2Nlc3MtNjAwXCIsXG4gICAgICBkYXJrOiBcInRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCIsXG4gICAgICBvdXRsaW5lOiBcInRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwXCIsXG4gICAgfTtcblxuICAgIGNvbnN0IHNpemVTdHlsZXMgPSB7XG4gICAgICBzbTogXCJoLTkgbWluLXctWzEzMHB4XSBwLTEgcGwtNCBwci0xMCB0ZXh0LXhzIGhvdmVyOnBsLTEwIGhvdmVyOnByLTRcIixcbiAgICAgIGRlZmF1bHQ6IFwiaC0xMCBtaW4tdy1bMTUwcHhdIHAtMSBwbC01IHByLTExIHRleHQteHMgaG92ZXI6cGwtMTEgaG92ZXI6cHItNVwiLFxuICAgICAgbGc6IFwiaC0xMiBtaW4tdy1bMTg0cHhdIHAtMSBwbC02IHByLTE0IHRleHQtc20gaG92ZXI6cGwtMTQgaG92ZXI6cHItNlwiLFxuICAgIH07XG5cbiAgICBjb25zdCBpY29uQ2lyY2xlU2l6ZXMgPSB7XG4gICAgICBzbTogXCJoLTcgdy03IGdyb3VwLWhvdmVyOnJpZ2h0LVtjYWxjKDEwMCUtMzJweCldXCIsXG4gICAgICBkZWZhdWx0OiBcImgtOCB3LTggZ3JvdXAtaG92ZXI6cmlnaHQtW2NhbGMoMTAwJS0zNnB4KV1cIixcbiAgICAgIGxnOiBcImgtMTAgdy0xMCBncm91cC1ob3ZlcjpyaWdodC1bY2FsYygxMDAlLTQ0cHgpXVwiLFxuICAgIH07XG5cbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvblxuICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJncm91cCByZWxhdGl2ZSBjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJvcmRlci0wIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwIGFjdGl2ZTpzY2FsZS1bMC45OF0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1icmFuZC01MDAvNDAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGlzYWJsZWQ6b3BhY2l0eS01MCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIixcbiAgICAgICAgICB2YXJpYW50U3R5bGVzW3ZhcmlhbnRdLFxuICAgICAgICAgIHNpemVTdHlsZXNbc2l6ZV0sXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgID5cbiAgICAgICAgey8qIFNoaW1tZXIgT3ZlcmxheSAqL31cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LTAgLXRyYW5zbGF0ZS14LVsxMzAlXSBza2V3LXgtWy0yMGRlZ10gYmctZ3JhZGllbnQtdG8tciBmcm9tLXRyYW5zcGFyZW50IHZpYS13aGl0ZS8yNSB0by10cmFuc3BhcmVudCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi03MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtWzEzMCVdXCJcbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQnV0dG9uIFRleHQgKi99XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgd2hpdGVzcGFjZS1ub3dyYXAgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgey8qIFNsaWRpbmcgSWNvbiBDaXJjbGUgKi99XG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwiYWJzb2x1dGUgcmlnaHQtMSB0b3AtMS8yIHotMTAgZ3JpZCAtdHJhbnNsYXRlLXktMS8yIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGwgYmctd2hpdGUgc2hhZG93LXNtIHRyYW5zaXRpb24tW3JpZ2h0LHRyYW5zZm9ybV0gZHVyYXRpb24tNTAwIGVhc2UtW2N1YmljLWJlemllcigwLjIyLDEsMC4zNiwxKV0gZ3JvdXAtaG92ZXI6LXRyYW5zbGF0ZS15LTEvMiBncm91cC1ob3Zlcjpyb3RhdGUtNDUgc2hyaW5rLTBcIixcbiAgICAgICAgICAgIGljb25DaXJjbGVTaXplc1tzaXplXSxcbiAgICAgICAgICAgIGljb25Db2xvclN0eWxlc1t2YXJpYW50XVxuICAgICAgICAgICl9XG4gICAgICAgID5cbiAgICAgICAgICB7aWNvbiB8fCA8QXJyb3dVcFJpZ2h0IHNpemU9e3NpemUgPT09IFwic21cIiA/IDEzIDogc2l6ZSA9PT0gXCJkZWZhdWx0XCIgPyAxNSA6IDE3fSBzdHJva2VXaWR0aD17Mi4yfSAvPn1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9idXR0b24+XG4gICAgKTtcbiAgfVxuKTtcbkFjdGlvbkJ1dHRvbi5kaXNwbGF5TmFtZSA9IFwiQWN0aW9uQnV0dG9uXCI7XG4iXSwiZmlsZSI6IkQ6L1Byb2plY3QtTWFpbmZpbGVzL0NsaWVudC1Qcm9qZWN0L1RRSS1FUlAvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvYWN0aW9uLWJ1dHRvbi50c3gifQ==