import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SessionSubmissionView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  CheckCircle2,
  XCircle,
  ChevronRight,
  AlertCircle,
  Send,
  RotateCcw,
  Clock,
  Eye,
  FileText,
  Image,
  DollarSign,
  CalendarDays,
  Users
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
const SessionSubmissionView = ({
  sessionSubmissions,
  sessions,
  clusters,
  currentUserRole,
  currentUserId,
  currentUserClusterId,
  onSubmitSession,
  onReviewSubmission,
  onResubmit,
  onNavigateToTab
}) => {
  _s();
  const isSuperAdmin = currentUserRole === "Super Admin";
  const [selectedClusterId, setSelectedClusterId] = useState(isSuperAdmin ? "" : currentUserClusterId);
  const [selectedDay, setSelectedDay] = useState("");
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState(null);
  const [reviewAction, setReviewAction] = useState("approve");
  const [reviewRemarks, setReviewRemarks] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [missingItems, setMissingItems] = useState([]);
  const activeSession = useMemo(() => {
    if (!selectedClusterId || !selectedDay) return null;
    return sessions.find((s) => s.clusterId === selectedClusterId && s.dayNumber === selectedDay) || null;
  }, [sessions, selectedClusterId, selectedDay]);
  const currentSubmission = useMemo(() => {
    if (!activeSession) return null;
    return sessionSubmissions.find((s) => s.sessionId === activeSession.id) || null;
  }, [sessionSubmissions, activeSession]);
  const adminSubmissions = useMemo(() => {
    if (!isSuperAdmin) return [];
    return sessionSubmissions.sort((a, b) => {
      if (a.status === "PENDING_REVIEW" && b.status !== "PENDING_REVIEW") return -1;
      if (b.status === "PENDING_REVIEW" && a.status !== "PENDING_REVIEW") return 1;
      return new Date(b.submittedAt || "").getTime() - new Date(a.submittedAt || "").getTime();
    });
  }, [sessionSubmissions, isSuperAdmin]);
  const handleSubmit = async () => {
    if (!activeSession) return;
    setIsSubmitting(true);
    setSubmitError(null);
    setMissingItems([]);
    try {
      const res = await onSubmitSession(activeSession.id, selectedClusterId, selectedDay);
      if (!res.success) {
        setSubmitError(res.error || "Failed to submit session.");
        if (res.missingItems) setMissingItems(res.missingItems);
      }
    } catch (e) {
      setSubmitError("An unexpected error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleReviewSubmit = async () => {
    if (!selectedSubmission) return;
    setIsSubmitting(true);
    try {
      await onReviewSubmission(selectedSubmission.id, reviewAction, reviewRemarks);
      setShowReviewModal(false);
      setSelectedSubmission(null);
      setReviewRemarks("");
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleResubmit = async (submissionId) => {
    setIsSubmitting(true);
    try {
      await onResubmit(submissionId);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmitting(false);
    }
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "DRAFT":
        return "bg-gray-100 text-gray-800";
      case "SUBMITTED":
      case "PENDING_REVIEW":
        return "bg-blue-100 text-blue-800";
      case "APPROVED":
      case "COMPLETED":
        return "bg-green-100 text-green-800";
      case "RESUBMISSION_REQUIRED":
        return "bg-red-100 text-red-800";
      case "RESUBMITTED":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  const renderStepper = (status) => {
    const steps = ["Draft", "Submitted", "Pending Review", "Approved/Completed"];
    let currentStepIndex = 0;
    if (status === "SUBMITTED") currentStepIndex = 1;
    if (status === "PENDING_REVIEW" || status === "RESUBMISSION_REQUIRED" || status === "RESUBMITTED") currentStepIndex = 2;
    if (status === "APPROVED" || status === "COMPLETED") currentStepIndex = 3;
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center w-full my-6", children: steps.map(
      (step, idx) => /* @__PURE__ */ jsxDEV(React.Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center relative z-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm border-2 ${idx < currentStepIndex ? "bg-green-500 border-green-500 text-white" : idx === currentStepIndex ? "bg-brand-500 border-brand-500 text-white" : "bg-white border-gray-300 text-gray-400 dark:bg-gray-800 dark:border-gray-600"}`, children: idx < currentStepIndex ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 151,
            columnNumber: 43
          }, this) : idx + 1 }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 144,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: `text-xs mt-2 font-medium ${idx <= currentStepIndex ? "text-gray-900 dark:text-gray-100" : "text-gray-500 dark:text-gray-400"}`, children: step }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 153,
            columnNumber: 15
          }, this),
          status === "RESUBMISSION_REQUIRED" && idx === 2 && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-red-500 font-bold mt-1", children: "Needs Resubmission" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 159,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 143,
          columnNumber: 13
        }, this),
        idx < steps.length - 1 && /* @__PURE__ */ jsxDEV("div", { className: `flex-1 h-1 mx-2 ${idx < currentStepIndex ? "bg-green-500" : "bg-gray-200 dark:bg-gray-700"}` }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 163,
          columnNumber: 11
        }, this)
      ] }, step, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 142,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this);
  };
  const ValidationItem = ({ label, isComplete, tabRoute, icon: Icon }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-700 last:border-0 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: `p-2 rounded-lg ${isComplete ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 177,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 176,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-800 dark:text-gray-200", children: label }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 179,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 175,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
      isComplete ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm font-medium text-green-600 dark:text-green-400", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-5 h-5 mr-1" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 184,
          columnNumber: 13
        }, this),
        " Complete"
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 183,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm font-medium text-red-600 dark:text-red-400", children: [
        /* @__PURE__ */ jsxDEV(XCircle, { className: "w-5 h-5 mr-1" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 188,
          columnNumber: 13
        }, this),
        " Missing"
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 187,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onNavigateToTab(tabRoute),
          className: "text-brand-600 hover:text-brand-700 text-sm font-medium flex items-center",
          children: [
            "View ",
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 ml-0.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 195,
              columnNumber: 16
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 191,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 181,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
    lineNumber: 174,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 dark:text-white", children: "Session Submissions" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 205,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 dark:text-gray-400 mt-1", children: "Submit or review complete session packages" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 206,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 204,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 203,
      columnNumber: 7
    }, this),
    !isSuperAdmin ? (
      // CLUSTER ADMIN VIEW
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-1 space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 dark:text-white mb-4", children: "Select Session" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 215,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: "Session Day" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 219,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    value: selectedDay ? String(selectedDay) : "",
                    onValueChange: (val) => setSelectedDay(val ? Number(val) : ""),
                    children: [
                      /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-10 text-xs rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select a day" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                        lineNumber: 225,
                        columnNumber: 23
                      }, this) }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                        lineNumber: 224,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectContent, { children: [1, 2, 3, 4, 5, 6, 7, 8].map(
                        (day) => /* @__PURE__ */ jsxDEV(SelectItem, { value: String(day), children: [
                          "Day ",
                          day
                        ] }, day, true, {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                          lineNumber: 229,
                          columnNumber: 21
                        }, this)
                      ) }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                        lineNumber: 227,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 220,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 218,
                columnNumber: 17
              }, this),
              activeSession && /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-brand-50 dark:bg-brand-900/20 rounded-lg border border-brand-100 dark:border-brand-800", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-medium text-brand-800 dark:text-brand-300", children: activeSession.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 239,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-brand-600 dark:text-brand-400 mt-1", children: new Date(activeSession.date).toLocaleDateString() }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 240,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 238,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 217,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 214,
            columnNumber: 13
          }, this),
          currentSubmission && /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm p-5", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 dark:text-white mb-4", children: "Submission Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 248,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600 dark:text-gray-400", children: "Current Status:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 251,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(currentSubmission.status)}`, children: currentSubmission.status.replace(/_/g, " ") }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 252,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 250,
              columnNumber: 17
            }, this),
            currentSubmission.status === "RESUBMISSION_REQUIRED" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-5 h-5 text-red-600 mt-0.5" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 260,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-red-800 dark:text-red-300", children: "Resubmission Required" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 262,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-700 dark:text-red-400 mt-1", children: currentSubmission.resubmissionReason }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 263,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => handleResubmit(currentSubmission.id),
                    disabled: isSubmitting,
                    className: "mt-3 flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-sm transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                        lineNumber: 270,
                        columnNumber: 27
                      }, this),
                      " Edit & Resubmit"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 265,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 261,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 259,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 258,
              columnNumber: 13
            }, this),
            renderStepper(currentSubmission.status),
            ["PENDING_REVIEW", "APPROVED", "COMPLETED"].includes(currentSubmission.status) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg text-amber-800 dark:text-amber-300 text-sm flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(Clock, { className: "w-4 h-4 mt-0.5 shrink-0" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 281,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "This session is currently locked for review. You cannot edit these sections unless a resubmission is requested." }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 282,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 280,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 247,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 213,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: activeSession ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden flex flex-col h-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-5 border-b border-gray-200 dark:border-gray-700", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 dark:text-white", children: "Validation Checklist" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 293,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 dark:text-gray-400 mt-1", children: "All items must be completed before you can submit the session." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 294,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 292,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col", children: currentSubmission ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col divide-y divide-gray-100 dark:divide-gray-800", children: [
            /* @__PURE__ */ jsxDEV(ValidationItem, { label: "Attendance Complete", isComplete: currentSubmission.attendanceComplete, tabRoute: "attendance", icon: Users }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 300,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(ValidationItem, { label: "Lesson Plan Complete", isComplete: currentSubmission.lessonPlanComplete, tabRoute: "lesson-plan", icon: FileText }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 301,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(ValidationItem, { label: "Session Photos Uploaded", isComplete: currentSubmission.photosComplete, tabRoute: "session-photos", icon: Image }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 302,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(ValidationItem, { label: "Session Report Complete", isComplete: currentSubmission.reportComplete, tabRoute: "session-reports", icon: FileText }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 303,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(ValidationItem, { label: "Finance Statement Complete", isComplete: currentSubmission.financeComplete, tabRoute: "finance-statement", icon: DollarSign }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 304,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 299,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center text-gray-500 flex flex-col items-center", children: [
            /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-12 h-12 text-gray-300 mb-3" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 308,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "No submission data found for this session yet." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 309,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 307,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 297,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-5 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50", children: [
            submitError && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Error:" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 317,
                columnNumber: 23
              }, this),
              " ",
              submitError,
              missingItems.length > 0 && /* @__PURE__ */ jsxDEV("ul", { className: "list-disc ml-5 mt-1", children: missingItems.map((i) => /* @__PURE__ */ jsxDEV("li", { children: i }, i, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 320,
                columnNumber: 52
              }, this)) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 319,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 316,
              columnNumber: 15
            }, this),
            !currentSubmission || ["DRAFT", "RESUBMITTED"].includes(currentSubmission.status) ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 dark:text-gray-400", children: currentSubmission && currentSubmission.attendanceComplete && currentSubmission.lessonPlanComplete && currentSubmission.photosComplete && currentSubmission.reportComplete && currentSubmission.financeComplete ? "All items complete. Ready to submit." : "Complete all checklist items to unlock submission." }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 328,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: handleSubmit,
                  disabled: isSubmitting || !currentSubmission || !(currentSubmission.attendanceComplete && currentSubmission.lessonPlanComplete && currentSubmission.photosComplete && currentSubmission.reportComplete && currentSubmission.financeComplete),
                  className: "w-full sm:w-auto px-6 py-2.5 bg-green-500 hover:bg-green-600 disabled:bg-gray-300 disabled:text-gray-500 text-white rounded-xl font-medium transition-colors flex items-center justify-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                      lineNumber: 351,
                      columnNumber: 25
                    }, this),
                    "Submit Session for Review"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 338,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 327,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center p-2 text-sm font-medium text-gray-600", children: [
              "Submission is currently ",
              currentSubmission.status.replace(/_/g, " ")
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 356,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 314,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 291,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "h-full min-h-[400px] bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-dashed border-gray-300 dark:border-gray-700 flex flex-col items-center justify-center text-gray-500 dark:text-gray-400 p-8 text-center", children: [
          /* @__PURE__ */ jsxDEV(CalendarDays, { className: "w-16 h-16 text-gray-300 dark:text-gray-600 mb-4" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 364,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 dark:text-white mb-2", children: "No Session Selected" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 365,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "max-w-md", children: "Please select a session day from the panel to view its submission checklist and status." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 366,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 363,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 289,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 212,
        columnNumber: 7
      }, this)
    ) : (
      // SUPER ADMIN VIEW
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: [
        adminSubmissions.map((sub) => {
          const session = sessions.find((s) => s.id === sub.sessionId);
          const isPending = sub.status === "PENDING_REVIEW";
          return /* @__PURE__ */ jsxDEV("div", { className: `bg-white dark:bg-gray-800 rounded-2xl border ${isPending ? "border-brand-300 shadow-md ring-1 ring-brand-100" : "border-gray-200 dark:border-gray-700 shadow-sm"} p-5 transition-all`, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-900 dark:text-white", children: sub.clusterName }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 383,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: [
                  "Day ",
                  sub.dayNumber,
                  " • ",
                  session?.name
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 384,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 382,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-1 rounded-full text-xs font-bold ${getStatusColor(sub.status)}`, children: sub.status.replace(/_/g, " ") }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 386,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 381,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 mb-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600 dark:text-gray-400 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(Users, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 393,
                    columnNumber: 100
                  }, this),
                  " Attendance"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 393,
                  columnNumber: 23
                }, this),
                sub.attendanceComplete ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 394,
                  columnNumber: 49
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 394,
                  columnNumber: 103
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 392,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600 dark:text-gray-400 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(FileText, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 397,
                    columnNumber: 100
                  }, this),
                  " Lesson Plan"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 397,
                  columnNumber: 23
                }, this),
                sub.lessonPlanComplete ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 398,
                  columnNumber: 49
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 398,
                  columnNumber: 103
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 396,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600 dark:text-gray-400 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(Image, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 401,
                    columnNumber: 100
                  }, this),
                  " Photos"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 401,
                  columnNumber: 23
                }, this),
                sub.photosComplete ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 402,
                  columnNumber: 45
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 402,
                  columnNumber: 99
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 400,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600 dark:text-gray-400 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(FileText, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 405,
                    columnNumber: 100
                  }, this),
                  " Report"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 405,
                  columnNumber: 23
                }, this),
                sub.reportComplete ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 406,
                  columnNumber: 45
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 406,
                  columnNumber: 99
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 404,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-xs items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-600 dark:text-gray-400 flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxDEV(DollarSign, { className: "w-3.5 h-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 409,
                    columnNumber: 100
                  }, this),
                  " Finance"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 409,
                  columnNumber: 23
                }, this),
                sub.financeComplete ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 410,
                  columnNumber: 46
                }, this) : /* @__PURE__ */ jsxDEV(XCircle, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                  lineNumber: 410,
                  columnNumber: 100
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 408,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 391,
              columnNumber: 19
            }, this),
            isPending && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setSelectedSubmission(sub);
                  setShowReviewModal(true);
                  setReviewAction("approve");
                },
                className: "w-full py-2 bg-brand-50 hover:bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-300 rounded-lg text-sm font-medium transition-colors flex justify-center items-center gap-2",
                children: [
                  /* @__PURE__ */ jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 419,
                    columnNumber: 23
                  }, this),
                  " Review Submission"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 415,
                columnNumber: 17
              },
              this
            )
          ] }, sub.id, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 380,
            columnNumber: 15
          }, this);
        }),
        adminSubmissions.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-12 text-center text-gray-500", children: "No submissions found." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 426,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 374,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 373,
        columnNumber: 7
      }, this)
    ),
    showReviewModal && selectedSubmission && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 dark:text-white", children: "Review Session Submission" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 439,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowReviewModal(false), className: "text-gray-400 hover:text-gray-500", children: /* @__PURE__ */ jsxDEV(XCircle, { className: "h-5 w-5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 441,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 440,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 438,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-100 dark:border-gray-700", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 block mb-1", children: "Cluster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 449,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-900 dark:text-white", children: selectedSubmission.clusterName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 450,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 448,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 block mb-1", children: "Day" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 453,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-900 dark:text-white", children: [
              "Day ",
              selectedSubmission.dayNumber
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 454,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 452,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 block mb-1", children: "Submitted On" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 457,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-900 dark:text-white", children: selectedSubmission.submittedAt ? new Date(selectedSubmission.submittedAt).toLocaleString() : "N/A" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 458,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 456,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 447,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 446,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2", children: "Review Action" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 466,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setReviewAction("approve"),
                className: `flex-1 py-2 px-3 rounded-lg border-2 font-medium flex items-center justify-center gap-2 transition-colors ${reviewAction === "approve" ? "border-green-500 bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400" : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 477,
                    columnNumber: 21
                  }, this),
                  " Approve"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 468,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setReviewAction("resubmission"),
                className: `flex-1 py-2 px-3 rounded-lg border-2 font-medium flex items-center justify-center gap-2 transition-colors ${reviewAction === "resubmission" ? "border-red-500 bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400" : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400"}`,
                children: [
                  /* @__PURE__ */ jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                    lineNumber: 488,
                    columnNumber: 21
                  }, this),
                  " Request Resubmit"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 479,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 467,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 465,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1", children: reviewAction === "approve" ? "Remarks (Optional)" : "Reason for Resubmission (Required)" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 494,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: reviewRemarks,
              onChange: (e) => setReviewRemarks(e.target.value),
              rows: 3,
              required: reviewAction === "resubmission",
              className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-brand-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white",
              placeholder: reviewAction === "approve" ? "Add any notes here..." : "Explain what needs to be fixed..."
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
              lineNumber: 497,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
          lineNumber: 493,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 445,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex justify-end gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowReviewModal(false),
            className: "px-4 py-2 text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg dark:text-gray-300 dark:bg-gray-700 dark:border-gray-600 transition-colors",
            disabled: isSubmitting,
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 509,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleReviewSubmit,
            disabled: isSubmitting || reviewAction === "resubmission" && !reviewRemarks.trim(),
            className: `px-6 py-2 text-white rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50 ${reviewAction === "approve" ? "bg-green-500 hover:bg-green-600" : "bg-red-500 hover:bg-red-600"}`,
            children: [
              /* @__PURE__ */ jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
                lineNumber: 523,
                columnNumber: 17
              }, this),
              "Submit Decision"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
            lineNumber: 516,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
        lineNumber: 508,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 437,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
      lineNumber: 436,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx",
    lineNumber: 202,
    columnNumber: 5
  }, this);
};
_s(SessionSubmissionView, "uFZgiphwqE/Xm4zQnOVdWJVHEDM=");
_c = SessionSubmissionView;
export default SessionSubmissionView;
var _c;
$RefreshReg$(_c, "SessionSubmissionView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/SessionSubmissionView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0owQzs7QUF0SjFDLE9BQU9BLFNBQVNDLFVBQVVDLGVBQWU7QUFDekM7QUFBQSxFQUNFQztBQUFBQSxFQUFjQztBQUFBQSxFQUFzQkM7QUFBQUEsRUFBY0M7QUFBQUEsRUFDbERDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVdDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQUtDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVlDO0FBQUFBLEVBQWNDO0FBQUFBLE9BQ25FO0FBRVA7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBZVAsTUFBTUMsd0JBQThEQSxDQUFDO0FBQUEsRUFDbkVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsZUFBZVIsb0JBQW9CO0FBQ3pDLFFBQU0sQ0FBQ1MsbUJBQW1CQyxvQkFBb0IsSUFBSWxDLFNBQVNnQyxlQUFlLEtBQUtOLG9CQUFvQjtBQUNuRyxRQUFNLENBQUNTLGFBQWFDLGNBQWMsSUFBSXBDLFNBQXNCLEVBQUU7QUFHOUQsUUFBTSxDQUFDcUMsaUJBQWlCQyxrQkFBa0IsSUFBSXRDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN1QyxvQkFBb0JDLHFCQUFxQixJQUFJeEMsU0FBbUMsSUFBSTtBQUMzRixRQUFNLENBQUN5QyxjQUFjQyxlQUFlLElBQUkxQyxTQUFxQyxTQUFTO0FBQ3RGLFFBQU0sQ0FBQzJDLGVBQWVDLGdCQUFnQixJQUFJNUMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZDLGNBQWNDLGVBQWUsSUFBSTlDLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUMrQyxhQUFhQyxjQUFjLElBQUloRCxTQUF3QixJQUFJO0FBQ2xFLFFBQU0sQ0FBQ2lELGNBQWNDLGVBQWUsSUFBSWxELFNBQW1CLEVBQUU7QUFHN0QsUUFBTW1ELGdCQUFnQmxELFFBQVEsTUFBTTtBQUNsQyxRQUFJLENBQUNnQyxxQkFBcUIsQ0FBQ0UsWUFBYSxRQUFPO0FBQy9DLFdBQU9iLFNBQVM4QixLQUFLLENBQUFDLE1BQUtBLEVBQUVDLGNBQWNyQixxQkFBcUJvQixFQUFFRSxjQUFjcEIsV0FBVyxLQUFLO0FBQUEsRUFDakcsR0FBRyxDQUFDYixVQUFVVyxtQkFBbUJFLFdBQVcsQ0FBQztBQUU3QyxRQUFNcUIsb0JBQW9CdkQsUUFBUSxNQUFNO0FBQ3RDLFFBQUksQ0FBQ2tELGNBQWUsUUFBTztBQUMzQixXQUFPOUIsbUJBQW1CK0IsS0FBSyxDQUFBQyxNQUFLQSxFQUFFSSxjQUFjTixjQUFjTyxFQUFFLEtBQUs7QUFBQSxFQUMzRSxHQUFHLENBQUNyQyxvQkFBb0I4QixhQUFhLENBQUM7QUFFdEMsUUFBTVEsbUJBQW1CMUQsUUFBUSxNQUFNO0FBQ3JDLFFBQUksQ0FBQytCLGFBQWMsUUFBTztBQUMxQixXQUFPWCxtQkFBbUJ1QyxLQUFLLENBQUNDLEdBQUdDLE1BQU07QUFFdkMsVUFBSUQsRUFBRUUsV0FBVyxvQkFBb0JELEVBQUVDLFdBQVcsaUJBQWtCLFFBQU87QUFDM0UsVUFBSUQsRUFBRUMsV0FBVyxvQkFBb0JGLEVBQUVFLFdBQVcsaUJBQWtCLFFBQU87QUFDM0UsYUFBTyxJQUFJQyxLQUFLRixFQUFFRyxlQUFlLEVBQUUsRUFBRUMsUUFBUSxJQUFJLElBQUlGLEtBQUtILEVBQUVJLGVBQWUsRUFBRSxFQUFFQyxRQUFRO0FBQUEsSUFDekYsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDN0Msb0JBQW9CVyxZQUFZLENBQUM7QUFFckMsUUFBTW1DLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUNoQixjQUFlO0FBQ3BCTCxvQkFBZ0IsSUFBSTtBQUNwQkUsbUJBQWUsSUFBSTtBQUNuQkUsb0JBQWdCLEVBQUU7QUFDbEIsUUFBSTtBQUNGLFlBQU1rQixNQUFNLE1BQU16QyxnQkFBZ0J3QixjQUFjTyxJQUFJekIsbUJBQW1CRSxXQUFxQjtBQUM1RixVQUFJLENBQUNpQyxJQUFJQyxTQUFTO0FBQ2hCckIsdUJBQWVvQixJQUFJRSxTQUFTLDJCQUEyQjtBQUN2RCxZQUFJRixJQUFJbkIsYUFBY0MsaUJBQWdCa0IsSUFBSW5CLFlBQVk7QUFBQSxNQUN4RDtBQUFBLElBQ0YsU0FBU3NCLEdBQUc7QUFDVnZCLHFCQUFlLCtCQUErQjtBQUFBLElBQ2hELFVBQUM7QUFDQ0Ysc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEIscUJBQXFCLFlBQVk7QUFDckMsUUFBSSxDQUFDakMsbUJBQW9CO0FBQ3pCTyxvQkFBZ0IsSUFBSTtBQUNwQixRQUFJO0FBQ0YsWUFBTWxCLG1CQUFtQlcsbUJBQW1CbUIsSUFBSWpCLGNBQWNFLGFBQWE7QUFDM0VMLHlCQUFtQixLQUFLO0FBQ3hCRSw0QkFBc0IsSUFBSTtBQUMxQkksdUJBQWlCLEVBQUU7QUFBQSxJQUNyQixTQUFTMEIsT0FBTztBQUNkRyxjQUFRSCxNQUFNQSxLQUFLO0FBQUEsSUFDckIsVUFBQztBQUNDeEIsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIsaUJBQWlCLE9BQU9DLGlCQUF5QjtBQUNyRDdCLG9CQUFnQixJQUFJO0FBQ3BCLFFBQUk7QUFDRixZQUFNakIsV0FBVzhDLFlBQVk7QUFBQSxJQUMvQixTQUFTSixHQUFHO0FBQ1ZFLGNBQVFILE1BQU1DLENBQUM7QUFBQSxJQUNqQixVQUFDO0FBQ0N6QixzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU04QixpQkFBaUJBLENBQUNiLFdBQW1CO0FBQ3pDLFlBQU9BLFFBQU07QUFBQSxNQUNYLEtBQUs7QUFBUyxlQUFPO0FBQUEsTUFDckIsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFrQixlQUFPO0FBQUEsTUFDOUIsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFhLGVBQU87QUFBQSxNQUN6QixLQUFLO0FBQXlCLGVBQU87QUFBQSxNQUNyQyxLQUFLO0FBQWUsZUFBTztBQUFBLE1BQzNCO0FBQVMsZUFBTztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU1jLGdCQUFnQkEsQ0FBQ2QsV0FBbUI7QUFDeEMsVUFBTWUsUUFBUSxDQUFDLFNBQVMsYUFBYSxrQkFBa0Isb0JBQW9CO0FBQzNFLFFBQUlDLG1CQUFtQjtBQUV2QixRQUFJaEIsV0FBVyxZQUFhZ0Isb0JBQW1CO0FBQy9DLFFBQUloQixXQUFXLG9CQUFvQkEsV0FBVywyQkFBMkJBLFdBQVcsY0FBZWdCLG9CQUFtQjtBQUN0SCxRQUFJaEIsV0FBVyxjQUFjQSxXQUFXLFlBQWFnQixvQkFBbUI7QUFFeEUsV0FDRSx1QkFBQyxTQUFJLFdBQVUsaUNBQ1pELGdCQUFNRTtBQUFBQSxNQUFJLENBQUNDLE1BQU1DLFFBQ2hCLHVCQUFDLE1BQU0sVUFBTixFQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFXLG9GQUNkQSxNQUFNSCxtQkFDRiw2Q0FDQUcsUUFBUUgsbUJBQ04sNkNBQ0EsOEVBQThFLElBRW5GRyxnQkFBTUgsbUJBQW1CLHVCQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUMsSUFBTUcsTUFBTSxLQVB6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVcsNEJBQ2ZBLE9BQU9ILG1CQUFtQixxQ0FBcUMsa0NBQWtDLElBRWhHRSxrQkFISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQ2xCLFdBQVcsMkJBQTJCbUIsUUFBUSxLQUM3Qyx1QkFBQyxVQUFLLFdBQVUsMkNBQTBDLGtDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLGFBaEJoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFDQ0EsTUFBTUosTUFBTUssU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVcsbUJBQ2RELE1BQU1ILG1CQUFtQixpQkFBaUIsOEJBQThCLE1BRDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFRztBQUFBLFdBdkJjRSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsSUFDRCxLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkJBO0FBQUEsRUFFSjtBQUVBLFFBQU1HLGlCQUFpQkEsQ0FBQyxFQUFFQyxPQUFPQyxZQUFZQyxVQUFVQyxNQUFNQyxLQUEwRSxNQUNySSx1QkFBQyxTQUFJLFdBQVUsa0tBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVcsa0JBQWtCSCxhQUFhLHlFQUF5RSw4REFBOEQsSUFDcEwsaUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFLLFdBQVUsZ0RBQWdERCxtQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLFNBSnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNaQztBQUFBQSxtQkFDQyx1QkFBQyxVQUFLLFdBQVUsNEVBQ2Q7QUFBQSwrQkFBQyxnQkFBYSxXQUFVLGtCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFBRztBQUFBLFdBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSx3RUFDZDtBQUFBLCtCQUFDLFdBQVEsV0FBVSxrQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQUc7QUFBQSxXQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU14RCxnQkFBZ0J5RCxRQUFRO0FBQUEsVUFDdkMsV0FBVTtBQUFBLFVBQTJFO0FBQUE7QUFBQSxZQUVoRix1QkFBQyxnQkFBYSxXQUFVLG9CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QztBQUFBO0FBQUE7QUFBQSxRQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLCtFQUNiLGlDQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0RBQW1ELG1DQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GO0FBQUEsTUFDcEYsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRCwwREFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RztBQUFBLFNBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUMsQ0FBQ3ZEO0FBQUFBO0FBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCw4QkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUV2Rix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsbUVBQWtFLDJCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RjtBQUFBLGdCQUM5RjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPRyxjQUFjdUQsT0FBT3ZELFdBQVcsSUFBSTtBQUFBLG9CQUMzQyxlQUFlLENBQUN3RCxRQUFRdkQsZUFBZXVELE1BQU1DLE9BQU9ELEdBQUcsSUFBSSxFQUFFO0FBQUEsb0JBRTdEO0FBQUEsNkNBQUMsaUJBQWMsV0FBVSx3RkFDdkIsaUNBQUMsZUFBWSxhQUFZLGtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsaUJBQ0UsV0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRVg7QUFBQUEsd0JBQUksQ0FBQ2EsUUFDN0IsdUJBQUMsY0FBcUIsT0FBT0gsT0FBT0csR0FBRyxHQUFFO0FBQUE7QUFBQSwwQkFDbENBO0FBQUFBLDZCQURVQSxLQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU1BO0FBQUE7QUFBQTtBQUFBLGtCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjQTtBQUFBLG1CQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBRUMxQyxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUdBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMERBQTBEQSx3QkFBYzJDLFFBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRGO0FBQUEsZ0JBQzVGLHVCQUFDLFNBQUksV0FBVSxtREFBbUQsY0FBSTlCLEtBQUtiLGNBQWM0QyxJQUFJLEVBQUVDLG1CQUFtQixLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvSDtBQUFBLG1CQUZ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsZUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxVQUVDeEMscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCxpQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUUxRix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNENBQTJDLCtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRTtBQUFBLGNBQzFFLHVCQUFDLFVBQUssV0FBVyw0Q0FBNENvQixlQUFlcEIsa0JBQWtCTyxNQUFNLENBQUMsSUFDbEdQLDRCQUFrQk8sT0FBT2tDLFFBQVEsTUFBTSxHQUFHLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQ3pDLGtCQUFrQk8sV0FBVywyQkFDNUIsdUJBQUMsU0FBSSxXQUFVLDhGQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHFDQUFDLGVBQVksV0FBVSxpQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUNwRCx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUErQyxxQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0Y7QUFBQSxnQkFDbEYsdUJBQUMsT0FBRSxXQUFVLCtDQUErQ1AsNEJBQWtCMEMsc0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlHO0FBQUEsZ0JBRWpHO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXhCLGVBQWVsQixrQkFBa0JFLEVBQUU7QUFBQSxvQkFDbEQsVUFBVWI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThCO0FBQUEsc0JBQUc7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUdEZ0MsY0FBY3JCLGtCQUFrQk8sTUFBTTtBQUFBLFlBRXRDLENBQUMsa0JBQWtCLFlBQVksV0FBVyxFQUFFb0MsU0FBUzNDLGtCQUFrQk8sTUFBTSxLQUM1RSx1QkFBQyxTQUFJLFdBQVUsMEhBQ2I7QUFBQSxxQ0FBQyxTQUFNLFdBQVUsNkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBDO0FBQUEsY0FDMUMsdUJBQUMsT0FBRSwrSEFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrSDtBQUFBLGlCQUZwSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQ0E7QUFBQSxhQXhFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1paLDBCQUNDLHVCQUFDLFNBQUksV0FBVSxvSUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx1REFBc0Qsb0NBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsT0FBRSxXQUFVLGlEQUFnRCw4RUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkg7QUFBQSxlQUY3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1pLLDhCQUNDLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLG1DQUFDLGtCQUFlLE9BQU0sdUJBQXNCLFlBQVlBLGtCQUFrQjRDLG9CQUFvQixVQUFTLGNBQWEsTUFBTXRGLFNBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdJO0FBQUEsWUFDaEksdUJBQUMsa0JBQWUsT0FBTSx3QkFBdUIsWUFBWTBDLGtCQUFrQjZDLG9CQUFvQixVQUFTLGVBQWMsTUFBTTNGLFlBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFJO0FBQUEsWUFDckksdUJBQUMsa0JBQWUsT0FBTSwyQkFBMEIsWUFBWThDLGtCQUFrQjhDLGdCQUFnQixVQUFTLGtCQUFpQixNQUFNM0YsU0FBOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0k7QUFBQSxZQUNwSSx1QkFBQyxrQkFBZSxPQUFNLDJCQUEwQixZQUFZNkMsa0JBQWtCK0MsZ0JBQWdCLFVBQVMsbUJBQWtCLE1BQU03RixZQUEvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3STtBQUFBLFlBQ3hJLHVCQUFDLGtCQUFlLE9BQU0sOEJBQTZCLFlBQVk4QyxrQkFBa0JnRCxpQkFBaUIsVUFBUyxxQkFBb0IsTUFBTTVGLGNBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdKO0FBQUEsZUFMbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLG1DQUFDLGVBQVksV0FBVSxrQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxPQUFFLDhEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsZUFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxvRkFDWm1DO0FBQUFBLDJCQUNDLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBZ0Isc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDO0FBQUEsY0FBTztBQUFBLGNBQUVBO0FBQUFBLGNBQzlDRSxhQUFha0MsU0FBUyxLQUNyQix1QkFBQyxRQUFHLFdBQVUsdUJBQ1hsQyx1QkFBYStCLElBQUksQ0FBQXlCLE1BQUssdUJBQUMsUUFBWUEsZUFBSkEsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlLENBQUssS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUdELENBQUNqRCxxQkFBcUIsQ0FBQyxTQUFTLGFBQWEsRUFBRTJDLFNBQVMzQyxrQkFBa0JPLE1BQU0sSUFDL0UsdUJBQUMsU0FBSSxXQUFVLGdFQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLDRDQUNWUCwrQkFDQUEsa0JBQWtCNEMsc0JBQ2xCNUMsa0JBQWtCNkMsc0JBQ2xCN0Msa0JBQWtCOEMsa0JBQ2xCOUMsa0JBQWtCK0Msa0JBQ2xCL0Msa0JBQWtCZ0Qsa0JBQ2hCLHlDQUNBLHdEQVJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVNyQztBQUFBQSxrQkFDVCxVQUNFdEIsZ0JBQ0EsQ0FBQ1cscUJBQ0QsRUFBRUEsa0JBQWtCNEMsc0JBQ2xCNUMsa0JBQWtCNkMsc0JBQ2xCN0Msa0JBQWtCOEMsa0JBQ2xCOUMsa0JBQWtCK0Msa0JBQ2xCL0Msa0JBQWtCZ0Q7QUFBQUEsa0JBRXRCLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxREFBbUQ7QUFBQTtBQUFBLGNBQ3ZDaEQsa0JBQWtCTyxPQUFPa0MsUUFBUSxNQUFNLEdBQUc7QUFBQSxpQkFEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBNUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOENBO0FBQUEsYUFyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3TkFDYjtBQUFBLGlDQUFDLGdCQUFhLFdBQVUscURBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFO0FBQUEsVUFDekUsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxtQ0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxVQUMxRix1QkFBQyxPQUFFLFdBQVUsWUFBVyx1R0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0c7QUFBQSxhQUhqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUEsS0E5RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdGQTtBQUFBLFdBN0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4SkE7QUFBQTtBQUFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ1p0QztBQUFBQSx5QkFBaUJxQixJQUFJLENBQUEwQixRQUFPO0FBQzNCLGdCQUFNQyxVQUFVckYsU0FBUzhCLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUssT0FBT2dELElBQUlqRCxTQUFTO0FBQ3pELGdCQUFNbUQsWUFBWUYsSUFBSTNDLFdBQVc7QUFFakMsaUJBQ0UsdUJBQUMsU0FBaUIsV0FBVyxnREFBZ0Q2QyxZQUFZLHFEQUFxRCxnREFBZ0QsdUJBQzVMO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSwyQ0FBMkNGLGNBQUlHLGVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlFO0FBQUEsZ0JBQ3pFLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGtCQUFLSCxJQUFJbkQ7QUFBQUEsa0JBQVU7QUFBQSxrQkFBSW9ELFNBQVNiO0FBQUFBLHFCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVcsOENBQThDbEIsZUFBZThCLElBQUkzQyxNQUFNLENBQUMsSUFDdEYyQyxjQUFJM0MsT0FBT2tDLFFBQVEsTUFBTSxHQUFHLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsOERBQTZEO0FBQUEseUNBQUMsU0FBTSxXQUFVLGlCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QjtBQUFBLGtCQUFFO0FBQUEscUJBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdIO0FBQUEsZ0JBQ3ZIUyxJQUFJTixxQkFBcUIsdUJBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0QsSUFBTSx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsbUJBRjNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4REFBNkQ7QUFBQSx5Q0FBQyxZQUFTLFdBQVUsaUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEsa0JBQUU7QUFBQSxxQkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEg7QUFBQSxnQkFDM0hNLElBQUlMLHFCQUFxQix1QkFBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRCxJQUFNLHVCQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxtQkFGM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDhEQUE2RDtBQUFBLHlDQUFDLFNBQU0sV0FBVSxpQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFBRTtBQUFBLHFCQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvSDtBQUFBLGdCQUNuSEssSUFBSUosaUJBQWlCLHVCQUFDLGdCQUFhLFdBQVUsNEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdELElBQU0sdUJBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLG1CQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsOERBQTZEO0FBQUEseUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUFFO0FBQUEscUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVIO0FBQUEsZ0JBQ3RISSxJQUFJSCxpQkFBaUIsdUJBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0QsSUFBTSx1QkFBQyxXQUFRLFdBQVUsMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsbUJBRnZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw4REFBNkQ7QUFBQSx5Q0FBQyxjQUFXLFdBQVUsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1DO0FBQUEsa0JBQUU7QUFBQSxxQkFBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEg7QUFBQSxnQkFDekhHLElBQUlGLGtCQUFrQix1QkFBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRCxJQUFNLHVCQUFDLFdBQVEsV0FBVSwwQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxtQkFGeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRUNJLGFBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU07QUFBRXBFLHdDQUFzQmtFLEdBQUc7QUFBR3BFLHFDQUFtQixJQUFJO0FBQUdJLGtDQUFnQixTQUFTO0FBQUEsZ0JBQUc7QUFBQSxnQkFDbkcsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0I7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBeENNZ0UsSUFBSWhELElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQ0E7QUFBQSxRQUVKLENBQUM7QUFBQSxRQUNBQyxpQkFBaUJ3QixXQUFXLEtBQzNCLHVCQUFDLFNBQUksV0FBVSxpREFBK0MscUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3REEsS0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQTtBQUFBO0FBQUEsSUFJRDlDLG1CQUFtQkUsc0JBQ2xCLHVCQUFDLFNBQUksV0FBVSx3RkFDYixpQ0FBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdURBQXNELHlDQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZGO0FBQUEsUUFDN0YsdUJBQUMsWUFBTyxTQUFTLE1BQU1ELG1CQUFtQixLQUFLLEdBQUcsV0FBVSxxQ0FDMUQsaUNBQUMsV0FBUSxXQUFVLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSw2RkFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG9DQUFtQyx1QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxVQUFLLFdBQVUsNkNBQTZDQyw2QkFBbUJzRSxlQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RjtBQUFBLGVBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsb0NBQW1DLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFVBQUssV0FBVSw2Q0FBNEM7QUFBQTtBQUFBLGNBQUt0RSxtQkFBbUJnQjtBQUFBQSxpQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxlQUZoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxvQ0FBbUMsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsWUFDL0QsdUJBQUMsVUFBSyxXQUFVLDZDQUNiaEIsNkJBQW1CMEIsY0FBYyxJQUFJRCxLQUFLekIsbUJBQW1CMEIsV0FBVyxFQUFFNkMsZUFBZSxJQUFJLFNBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1FQUFrRSw2QkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxVQUNoRyx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXBFLGdCQUFnQixTQUFTO0FBQUEsZ0JBQ3hDLFdBQVcsNkdBQ1RELGlCQUFpQixZQUNiLHlGQUNBLGtIQUFrSDtBQUFBLGdCQUd4SDtBQUFBLHlDQUFDLGdCQUFhLFdBQVUsYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNQyxnQkFBZ0IsY0FBYztBQUFBLGdCQUM3QyxXQUFXLDZHQUNURCxpQkFBaUIsaUJBQ2IsK0VBQ0Esa0hBQWtIO0FBQUEsZ0JBR3hIO0FBQUEseUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FUbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsbUVBQ2RBLDJCQUFpQixZQUFZLHVCQUF1Qix3Q0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9FO0FBQUFBLGNBQ1AsVUFBVSxDQUFDNEIsTUFBTTNCLGlCQUFpQjJCLEVBQUV3QyxPQUFPQyxLQUFLO0FBQUEsY0FDaEQsTUFBTTtBQUFBLGNBQ04sVUFBVXZFLGlCQUFpQjtBQUFBLGNBQzNCLFdBQVU7QUFBQSxjQUNWLGFBQWFBLGlCQUFpQixZQUFZLDBCQUEwQjtBQUFBO0FBQUEsWUFOdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTBHO0FBQUEsYUFWNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsV0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZEQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDJHQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUgsbUJBQW1CLEtBQUs7QUFBQSxZQUN2QyxXQUFVO0FBQUEsWUFDVixVQUFVTztBQUFBQSxZQUFhO0FBQUE7QUFBQSxVQUh6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMyQjtBQUFBQSxZQUNULFVBQVUzQixnQkFBaUJKLGlCQUFpQixrQkFBa0IsQ0FBQ0UsY0FBY3NFLEtBQUs7QUFBQSxZQUNsRixXQUFXLGlHQUNUeEUsaUJBQWlCLFlBQVksb0NBQW9DLDZCQUE2QjtBQUFBLFlBR2hHO0FBQUEscUNBQUMsUUFBSyxXQUFVLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFQM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBGQSxLQTNGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEZBO0FBQUEsT0F0VUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdVQTtBQUVKO0FBQUVWLEdBeGZJWCx1QkFBMkQ7QUFBQSxLQUEzREE7QUEwZk4sZUFBZUE7QUFBc0IsSUFBQThGO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiQ2hlY2tDaXJjbGUyIiwiWENpcmNsZSIsIkNoZXZyb25SaWdodCIsIkFsZXJ0Q2lyY2xlIiwiU2VuZCIsIlJvdGF0ZUNjdyIsIkNsb2NrIiwiRXllIiwiRmlsZVRleHQiLCJJbWFnZSIsIkRvbGxhclNpZ24iLCJDYWxlbmRhckRheXMiLCJVc2VycyIsIlNlbGVjdCIsIlNlbGVjdENvbnRlbnQiLCJTZWxlY3RJdGVtIiwiU2VsZWN0VHJpZ2dlciIsIlNlbGVjdFZhbHVlIiwiU2Vzc2lvblN1Ym1pc3Npb25WaWV3Iiwic2Vzc2lvblN1Ym1pc3Npb25zIiwic2Vzc2lvbnMiLCJjbHVzdGVycyIsImN1cnJlbnRVc2VyUm9sZSIsImN1cnJlbnRVc2VySWQiLCJjdXJyZW50VXNlckNsdXN0ZXJJZCIsIm9uU3VibWl0U2Vzc2lvbiIsIm9uUmV2aWV3U3VibWlzc2lvbiIsIm9uUmVzdWJtaXQiLCJvbk5hdmlnYXRlVG9UYWIiLCJfcyIsImlzU3VwZXJBZG1pbiIsInNlbGVjdGVkQ2x1c3RlcklkIiwic2V0U2VsZWN0ZWRDbHVzdGVySWQiLCJzZWxlY3RlZERheSIsInNldFNlbGVjdGVkRGF5Iiwic2hvd1Jldmlld01vZGFsIiwic2V0U2hvd1Jldmlld01vZGFsIiwic2VsZWN0ZWRTdWJtaXNzaW9uIiwic2V0U2VsZWN0ZWRTdWJtaXNzaW9uIiwicmV2aWV3QWN0aW9uIiwic2V0UmV2aWV3QWN0aW9uIiwicmV2aWV3UmVtYXJrcyIsInNldFJldmlld1JlbWFya3MiLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJzdWJtaXRFcnJvciIsInNldFN1Ym1pdEVycm9yIiwibWlzc2luZ0l0ZW1zIiwic2V0TWlzc2luZ0l0ZW1zIiwiYWN0aXZlU2Vzc2lvbiIsImZpbmQiLCJzIiwiY2x1c3RlcklkIiwiZGF5TnVtYmVyIiwiY3VycmVudFN1Ym1pc3Npb24iLCJzZXNzaW9uSWQiLCJpZCIsImFkbWluU3VibWlzc2lvbnMiLCJzb3J0IiwiYSIsImIiLCJzdGF0dXMiLCJEYXRlIiwic3VibWl0dGVkQXQiLCJnZXRUaW1lIiwiaGFuZGxlU3VibWl0IiwicmVzIiwic3VjY2VzcyIsImVycm9yIiwiZSIsImhhbmRsZVJldmlld1N1Ym1pdCIsImNvbnNvbGUiLCJoYW5kbGVSZXN1Ym1pdCIsInN1Ym1pc3Npb25JZCIsImdldFN0YXR1c0NvbG9yIiwicmVuZGVyU3RlcHBlciIsInN0ZXBzIiwiY3VycmVudFN0ZXBJbmRleCIsIm1hcCIsInN0ZXAiLCJpZHgiLCJsZW5ndGgiLCJWYWxpZGF0aW9uSXRlbSIsImxhYmVsIiwiaXNDb21wbGV0ZSIsInRhYlJvdXRlIiwiaWNvbiIsIkljb24iLCJTdHJpbmciLCJ2YWwiLCJOdW1iZXIiLCJkYXkiLCJuYW1lIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInJlcGxhY2UiLCJyZXN1Ym1pc3Npb25SZWFzb24iLCJpbmNsdWRlcyIsImF0dGVuZGFuY2VDb21wbGV0ZSIsImxlc3NvblBsYW5Db21wbGV0ZSIsInBob3Rvc0NvbXBsZXRlIiwicmVwb3J0Q29tcGxldGUiLCJmaW5hbmNlQ29tcGxldGUiLCJpIiwic3ViIiwic2Vzc2lvbiIsImlzUGVuZGluZyIsImNsdXN0ZXJOYW1lIiwidG9Mb2NhbGVTdHJpbmciLCJ0YXJnZXQiLCJ2YWx1ZSIsInRyaW0iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXNzaW9uU3VibWlzc2lvblZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBDaGVja0NpcmNsZTIsIFhDaXJjbGUsIENoZXZyb25Eb3duLCBDaGV2cm9uUmlnaHQsIEFsZXJ0Q2lyY2xlLCBcbiAgU2VuZCwgUm90YXRlQ2N3LCBDbG9jaywgRXllLCBGaWxlVGV4dCwgSW1hZ2UsIERvbGxhclNpZ24sIENhbGVuZGFyRGF5cywgVXNlcnNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB0eXBlIHsgU2Vzc2lvblN1Ym1pc3Npb24sIFNlc3Npb24sIFVzZXJSb2xlIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSAnLi91aS9zZWxlY3QnO1xuXG5pbnRlcmZhY2UgU2Vzc2lvblN1Ym1pc3Npb25WaWV3UHJvcHMge1xuICBzZXNzaW9uU3VibWlzc2lvbnM6IFNlc3Npb25TdWJtaXNzaW9uW107XG4gIHNlc3Npb25zOiBTZXNzaW9uW107XG4gIGNsdXN0ZXJzOiB7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZyB9W107XG4gIGN1cnJlbnRVc2VyUm9sZTogVXNlclJvbGU7XG4gIGN1cnJlbnRVc2VySWQ6IHN0cmluZztcbiAgY3VycmVudFVzZXJDbHVzdGVySWQ6IHN0cmluZztcbiAgb25TdWJtaXRTZXNzaW9uOiAoc2Vzc2lvbklkOiBzdHJpbmcsIGNsdXN0ZXJJZDogc3RyaW5nLCBkYXlOdW1iZXI6IG51bWJlcikgPT4gUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGVycm9yPzogc3RyaW5nOyBtaXNzaW5nSXRlbXM/OiBzdHJpbmdbXSB9PjtcbiAgb25SZXZpZXdTdWJtaXNzaW9uOiAoc3VibWlzc2lvbklkOiBzdHJpbmcsIGFjdGlvbjogJ2FwcHJvdmUnIHwgJ3Jlc3VibWlzc2lvbicsIHJlbWFya3M6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgb25SZXN1Ym1pdDogKHN1Ym1pc3Npb25JZDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+O1xuICBvbk5hdmlnYXRlVG9UYWI6ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuY29uc3QgU2Vzc2lvblN1Ym1pc3Npb25WaWV3OiBSZWFjdC5GQzxTZXNzaW9uU3VibWlzc2lvblZpZXdQcm9wcz4gPSAoe1xuICBzZXNzaW9uU3VibWlzc2lvbnMsXG4gIHNlc3Npb25zLFxuICBjbHVzdGVycyxcbiAgY3VycmVudFVzZXJSb2xlLFxuICBjdXJyZW50VXNlcklkLFxuICBjdXJyZW50VXNlckNsdXN0ZXJJZCxcbiAgb25TdWJtaXRTZXNzaW9uLFxuICBvblJldmlld1N1Ym1pc3Npb24sXG4gIG9uUmVzdWJtaXQsXG4gIG9uTmF2aWdhdGVUb1RhYlxufSkgPT4ge1xuICBjb25zdCBpc1N1cGVyQWRtaW4gPSBjdXJyZW50VXNlclJvbGUgPT09ICdTdXBlciBBZG1pbic7XG4gIGNvbnN0IFtzZWxlY3RlZENsdXN0ZXJJZCwgc2V0U2VsZWN0ZWRDbHVzdGVySWRdID0gdXNlU3RhdGUoaXNTdXBlckFkbWluID8gJycgOiBjdXJyZW50VXNlckNsdXN0ZXJJZCk7XG4gIGNvbnN0IFtzZWxlY3RlZERheSwgc2V0U2VsZWN0ZWREYXldID0gdXNlU3RhdGU8bnVtYmVyIHwgJyc+KCcnKTtcbiAgXG4gIC8vIE1vZGFscyAvIFN0YXRlXG4gIGNvbnN0IFtzaG93UmV2aWV3TW9kYWwsIHNldFNob3dSZXZpZXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWxlY3RlZFN1Ym1pc3Npb24sIHNldFNlbGVjdGVkU3VibWlzc2lvbl0gPSB1c2VTdGF0ZTxTZXNzaW9uU3VibWlzc2lvbiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcmV2aWV3QWN0aW9uLCBzZXRSZXZpZXdBY3Rpb25dID0gdXNlU3RhdGU8J2FwcHJvdmUnIHwgJ3Jlc3VibWlzc2lvbic+KCdhcHByb3ZlJyk7XG4gIGNvbnN0IFtyZXZpZXdSZW1hcmtzLCBzZXRSZXZpZXdSZW1hcmtzXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N1Ym1pdEVycm9yLCBzZXRTdWJtaXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW21pc3NpbmdJdGVtcywgc2V0TWlzc2luZ0l0ZW1zXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG5cbiAgLy8gRGVyaXZlZCBkYXRhXG4gIGNvbnN0IGFjdGl2ZVNlc3Npb24gPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkQ2x1c3RlcklkIHx8ICFzZWxlY3RlZERheSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHNlc3Npb25zLmZpbmQocyA9PiBzLmNsdXN0ZXJJZCA9PT0gc2VsZWN0ZWRDbHVzdGVySWQgJiYgcy5kYXlOdW1iZXIgPT09IHNlbGVjdGVkRGF5KSB8fCBudWxsO1xuICB9LCBbc2Vzc2lvbnMsIHNlbGVjdGVkQ2x1c3RlcklkLCBzZWxlY3RlZERheV0pO1xuXG4gIGNvbnN0IGN1cnJlbnRTdWJtaXNzaW9uID0gdXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCFhY3RpdmVTZXNzaW9uKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gc2Vzc2lvblN1Ym1pc3Npb25zLmZpbmQocyA9PiBzLnNlc3Npb25JZCA9PT0gYWN0aXZlU2Vzc2lvbi5pZCkgfHwgbnVsbDtcbiAgfSwgW3Nlc3Npb25TdWJtaXNzaW9ucywgYWN0aXZlU2Vzc2lvbl0pO1xuXG4gIGNvbnN0IGFkbWluU3VibWlzc2lvbnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIWlzU3VwZXJBZG1pbikgcmV0dXJuIFtdO1xuICAgIHJldHVybiBzZXNzaW9uU3VibWlzc2lvbnMuc29ydCgoYSwgYikgPT4ge1xuICAgICAgLy8gUEVORElOR19SRVZJRVcgZmlyc3RcbiAgICAgIGlmIChhLnN0YXR1cyA9PT0gJ1BFTkRJTkdfUkVWSUVXJyAmJiBiLnN0YXR1cyAhPT0gJ1BFTkRJTkdfUkVWSUVXJykgcmV0dXJuIC0xO1xuICAgICAgaWYgKGIuc3RhdHVzID09PSAnUEVORElOR19SRVZJRVcnICYmIGEuc3RhdHVzICE9PSAnUEVORElOR19SRVZJRVcnKSByZXR1cm4gMTtcbiAgICAgIHJldHVybiBuZXcgRGF0ZShiLnN1Ym1pdHRlZEF0IHx8ICcnKS5nZXRUaW1lKCkgLSBuZXcgRGF0ZShhLnN1Ym1pdHRlZEF0IHx8ICcnKS5nZXRUaW1lKCk7XG4gICAgfSk7XG4gIH0sIFtzZXNzaW9uU3VibWlzc2lvbnMsIGlzU3VwZXJBZG1pbl0pO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWFjdGl2ZVNlc3Npb24pIHJldHVybjtcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG4gICAgc2V0U3VibWl0RXJyb3IobnVsbCk7XG4gICAgc2V0TWlzc2luZ0l0ZW1zKFtdKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgb25TdWJtaXRTZXNzaW9uKGFjdGl2ZVNlc3Npb24uaWQsIHNlbGVjdGVkQ2x1c3RlcklkLCBzZWxlY3RlZERheSBhcyBudW1iZXIpO1xuICAgICAgaWYgKCFyZXMuc3VjY2Vzcykge1xuICAgICAgICBzZXRTdWJtaXRFcnJvcihyZXMuZXJyb3IgfHwgJ0ZhaWxlZCB0byBzdWJtaXQgc2Vzc2lvbi4nKTtcbiAgICAgICAgaWYgKHJlcy5taXNzaW5nSXRlbXMpIHNldE1pc3NpbmdJdGVtcyhyZXMubWlzc2luZ0l0ZW1zKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRTdWJtaXRFcnJvcignQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmV2aWV3U3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRTdWJtaXNzaW9uKSByZXR1cm47XG4gICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBvblJldmlld1N1Ym1pc3Npb24oc2VsZWN0ZWRTdWJtaXNzaW9uLmlkLCByZXZpZXdBY3Rpb24sIHJldmlld1JlbWFya3MpO1xuICAgICAgc2V0U2hvd1Jldmlld01vZGFsKGZhbHNlKTtcbiAgICAgIHNldFNlbGVjdGVkU3VibWlzc2lvbihudWxsKTtcbiAgICAgIHNldFJldmlld1JlbWFya3MoJycpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVzdWJtaXQgPSBhc3luYyAoc3VibWlzc2lvbklkOiBzdHJpbmcpID0+IHtcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG9uUmVzdWJtaXQoc3VibWlzc2lvbklkKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBnZXRTdGF0dXNDb2xvciA9IChzdGF0dXM6IHN0cmluZykgPT4ge1xuICAgIHN3aXRjaChzdGF0dXMpIHtcbiAgICAgIGNhc2UgJ0RSQUZUJzogcmV0dXJuICdiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwJztcbiAgICAgIGNhc2UgJ1NVQk1JVFRFRCc6IFxuICAgICAgY2FzZSAnUEVORElOR19SRVZJRVcnOiByZXR1cm4gJ2JnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAnO1xuICAgICAgY2FzZSAnQVBQUk9WRUQnOiBcbiAgICAgIGNhc2UgJ0NPTVBMRVRFRCc6IHJldHVybiAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJztcbiAgICAgIGNhc2UgJ1JFU1VCTUlTU0lPTl9SRVFVSVJFRCc6IHJldHVybiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnO1xuICAgICAgY2FzZSAnUkVTVUJNSVRURUQnOiByZXR1cm4gJ2JnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtODAwJztcbiAgICAgIGRlZmF1bHQ6IHJldHVybiAnYmctZ3JheS0xMDAgdGV4dC1ncmF5LTgwMCc7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHJlbmRlclN0ZXBwZXIgPSAoc3RhdHVzOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzdGVwcyA9IFsnRHJhZnQnLCAnU3VibWl0dGVkJywgJ1BlbmRpbmcgUmV2aWV3JywgJ0FwcHJvdmVkL0NvbXBsZXRlZCddO1xuICAgIGxldCBjdXJyZW50U3RlcEluZGV4ID0gMDtcbiAgICBcbiAgICBpZiAoc3RhdHVzID09PSAnU1VCTUlUVEVEJykgY3VycmVudFN0ZXBJbmRleCA9IDE7XG4gICAgaWYgKHN0YXR1cyA9PT0gJ1BFTkRJTkdfUkVWSUVXJyB8fCBzdGF0dXMgPT09ICdSRVNVQk1JU1NJT05fUkVRVUlSRUQnIHx8IHN0YXR1cyA9PT0gJ1JFU1VCTUlUVEVEJykgY3VycmVudFN0ZXBJbmRleCA9IDI7XG4gICAgaWYgKHN0YXR1cyA9PT0gJ0FQUFJPVkVEJyB8fCBzdGF0dXMgPT09ICdDT01QTEVURUQnKSBjdXJyZW50U3RlcEluZGV4ID0gMztcblxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHctZnVsbCBteS02XCI+XG4gICAgICAgIHtzdGVwcy5tYXAoKHN0ZXAsIGlkeCkgPT4gKFxuICAgICAgICAgIDxSZWFjdC5GcmFnbWVudCBrZXk9e3N0ZXB9PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciByZWxhdGl2ZSB6LTEwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy04IGgtOCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtc20gYm9yZGVyLTIgJHtcbiAgICAgICAgICAgICAgICBpZHggPCBjdXJyZW50U3RlcEluZGV4IFxuICAgICAgICAgICAgICAgICAgPyAnYmctZ3JlZW4tNTAwIGJvcmRlci1ncmVlbi01MDAgdGV4dC13aGl0ZScgXG4gICAgICAgICAgICAgICAgICA6IGlkeCA9PT0gY3VycmVudFN0ZXBJbmRleFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1icmFuZC01MDAgYm9yZGVyLWJyYW5kLTUwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTQwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6Ym9yZGVyLWdyYXktNjAwJ1xuICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAge2lkeCA8IGN1cnJlbnRTdGVwSW5kZXggPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiA6IGlkeCArIDF9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXhzIG10LTIgZm9udC1tZWRpdW0gJHtcbiAgICAgICAgICAgICAgICBpZHggPD0gY3VycmVudFN0ZXBJbmRleCA/ICd0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTEwMCcgOiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICB7c3RlcH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICB7c3RhdHVzID09PSAnUkVTVUJNSVNTSU9OX1JFUVVJUkVEJyAmJiBpZHggPT09IDIgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtcmVkLTUwMCBmb250LWJvbGQgbXQtMVwiPk5lZWRzIFJlc3VibWlzc2lvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2lkeCA8IHN0ZXBzLmxlbmd0aCAtIDEgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXgtMSBoLTEgbXgtMiAke1xuICAgICAgICAgICAgICAgIGlkeCA8IGN1cnJlbnRTdGVwSW5kZXggPyAnYmctZ3JlZW4tNTAwJyA6ICdiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNzAwJ1xuICAgICAgICAgICAgICB9YH0gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9SZWFjdC5GcmFnbWVudD5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9O1xuXG4gIGNvbnN0IFZhbGlkYXRpb25JdGVtID0gKHsgbGFiZWwsIGlzQ29tcGxldGUsIHRhYlJvdXRlLCBpY29uOiBJY29uIH06IHsgbGFiZWw6IHN0cmluZywgaXNDb21wbGV0ZTogYm9vbGVhbiwgdGFiUm91dGU6IHN0cmluZywgaWNvbjogYW55IH0pID0+IChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmhvdmVyOmJnLWdyYXktODAwLzUwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgJHtpc0NvbXBsZXRlID8gJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTYwMCBkYXJrOmJnLWdyZWVuLTkwMC8zMCBkYXJrOnRleHQtZ3JlZW4tNDAwJyA6ICdiZy1yZWQtMTAwIHRleHQtcmVkLTYwMCBkYXJrOmJnLXJlZC05MDAvMzAgZGFyazp0ZXh0LXJlZC00MDAnfWB9PlxuICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0yMDBcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgIHtpc0NvbXBsZXRlID8gKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmVlbi02MDAgZGFyazp0ZXh0LWdyZWVuLTQwMFwiPlxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTUgaC01IG1yLTFcIiAvPiBDb21wbGV0ZVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMFwiPlxuICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwidy01IGgtNSBtci0xXCIgLz4gTWlzc2luZ1xuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgKX1cbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlVG9UYWIodGFiUm91dGUpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYnJhbmQtNjAwIGhvdmVyOnRleHQtYnJhbmQtNzAwIHRleHQtc20gZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAgVmlldyA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgbWwtMC41XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj5TZXNzaW9uIFN1Ym1pc3Npb25zPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIG10LTFcIj5TdWJtaXQgb3IgcmV2aWV3IGNvbXBsZXRlIHNlc3Npb24gcGFja2FnZXM8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHshaXNTdXBlckFkbWluID8gKFxuICAgICAgICAvLyBDTFVTVEVSIEFETUlOIFZJRVdcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0xIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktODAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgc2hhZG93LXNtIHAtNVwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj5TZWxlY3QgU2Vzc2lvbjwvaDM+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCBtYi0xXCI+U2Vzc2lvbiBEYXk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXkgPyBTdHJpbmcoc2VsZWN0ZWREYXkpIDogJyd9XG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkRGF5KHZhbCA/IE51bWJlcih2YWwpIDogJycpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCB0ZXh0LXhzIHJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6YmctZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYSBkYXlcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNSwgNiwgNywgOF0ubWFwKChkYXkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17ZGF5fSB2YWx1ZT17U3RyaW5nKGRheSl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBEYXkge2RheX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbiAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1icmFuZC01MCBkYXJrOmJnLWJyYW5kLTkwMC8yMCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYnJhbmQtMTAwIGRhcms6Ym9yZGVyLWJyYW5kLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1icmFuZC04MDAgZGFyazp0ZXh0LWJyYW5kLTMwMFwiPnthY3RpdmVTZXNzaW9uLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJyYW5kLTYwMCBkYXJrOnRleHQtYnJhbmQtNDAwIG10LTFcIj57bmV3IERhdGUoYWN0aXZlU2Vzc2lvbi5kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtjdXJyZW50U3VibWlzc2lvbiAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIHNoYWRvdy1zbSBwLTVcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj5TdWJtaXNzaW9uIFN0YXR1czwvaDM+XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkN1cnJlbnQgU3RhdHVzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgJHtnZXRTdGF0dXNDb2xvcihjdXJyZW50U3VibWlzc2lvbi5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFN1Ym1pc3Npb24uc3RhdHVzLnJlcGxhY2UoL18vZywgJyAnKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHtjdXJyZW50U3VibWlzc2lvbi5zdGF0dXMgPT09ICdSRVNVQk1JU1NJT05fUkVRVUlSRUQnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTQgYmctcmVkLTUwIGRhcms6YmctcmVkLTkwMC8yMCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgZGFyazpib3JkZXItcmVkLTgwMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcmVkLTYwMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC04MDAgZGFyazp0ZXh0LXJlZC0zMDBcIj5SZXN1Ym1pc3Npb24gUmVxdWlyZWQ8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC00MDAgbXQtMVwiPntjdXJyZW50U3VibWlzc2lvbi5yZXN1Ym1pc3Npb25SZWFzb259PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc3VibWl0KGN1cnJlbnRTdWJtaXNzaW9uLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1yZWQtNjAwIGhvdmVyOmJnLXJlZC03MDAgdGV4dC13aGl0ZSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQtc20gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBFZGl0ICYgUmVzdWJtaXRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICB7cmVuZGVyU3RlcHBlcihjdXJyZW50U3VibWlzc2lvbi5zdGF0dXMpfVxuXG4gICAgICAgICAgICAgICAge1snUEVORElOR19SRVZJRVcnLCAnQVBQUk9WRUQnLCAnQ09NUExFVEVEJ10uaW5jbHVkZXMoY3VycmVudFN1Ym1pc3Npb24uc3RhdHVzKSAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcC0zIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTAwLzIwIHJvdW5kZWQtbGcgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCB0ZXh0LXNtIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgbXQtMC41IHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHA+VGhpcyBzZXNzaW9uIGlzIGN1cnJlbnRseSBsb2NrZWQgZm9yIHJldmlldy4gWW91IGNhbm5vdCBlZGl0IHRoZXNlIHNlY3Rpb25zIHVubGVzcyBhIHJlc3VibWlzc2lvbiBpcyByZXF1ZXN0ZWQuPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICB7YWN0aXZlU2Vzc2lvbiA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktODAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIGgtZnVsbFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPlZhbGlkYXRpb24gQ2hlY2tsaXN0PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbXQtMVwiPkFsbCBpdGVtcyBtdXN0IGJlIGNvbXBsZXRlZCBiZWZvcmUgeW91IGNhbiBzdWJtaXQgdGhlIHNlc3Npb24uPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50U3VibWlzc2lvbiA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGRpdmlkZS15IGRpdmlkZS1ncmF5LTEwMCBkYXJrOmRpdmlkZS1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxWYWxpZGF0aW9uSXRlbSBsYWJlbD1cIkF0dGVuZGFuY2UgQ29tcGxldGVcIiBpc0NvbXBsZXRlPXtjdXJyZW50U3VibWlzc2lvbi5hdHRlbmRhbmNlQ29tcGxldGV9IHRhYlJvdXRlPVwiYXR0ZW5kYW5jZVwiIGljb249e1VzZXJzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxWYWxpZGF0aW9uSXRlbSBsYWJlbD1cIkxlc3NvbiBQbGFuIENvbXBsZXRlXCIgaXNDb21wbGV0ZT17Y3VycmVudFN1Ym1pc3Npb24ubGVzc29uUGxhbkNvbXBsZXRlfSB0YWJSb3V0ZT1cImxlc3Nvbi1wbGFuXCIgaWNvbj17RmlsZVRleHR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFZhbGlkYXRpb25JdGVtIGxhYmVsPVwiU2Vzc2lvbiBQaG90b3MgVXBsb2FkZWRcIiBpc0NvbXBsZXRlPXtjdXJyZW50U3VibWlzc2lvbi5waG90b3NDb21wbGV0ZX0gdGFiUm91dGU9XCJzZXNzaW9uLXBob3Rvc1wiIGljb249e0ltYWdlfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxWYWxpZGF0aW9uSXRlbSBsYWJlbD1cIlNlc3Npb24gUmVwb3J0IENvbXBsZXRlXCIgaXNDb21wbGV0ZT17Y3VycmVudFN1Ym1pc3Npb24ucmVwb3J0Q29tcGxldGV9IHRhYlJvdXRlPVwic2Vzc2lvbi1yZXBvcnRzXCIgaWNvbj17RmlsZVRleHR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPFZhbGlkYXRpb25JdGVtIGxhYmVsPVwiRmluYW5jZSBTdGF0ZW1lbnQgQ29tcGxldGVcIiBpc0NvbXBsZXRlPXtjdXJyZW50U3VibWlzc2lvbi5maW5hbmNlQ29tcGxldGV9IHRhYlJvdXRlPVwiZmluYW5jZS1zdGF0ZW1lbnRcIiBpY29uPXtEb2xsYXJTaWdufSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtZ3JheS01MDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHRleHQtZ3JheS0zMDAgbWItM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHA+Tm8gc3VibWlzc2lvbiBkYXRhIGZvdW5kIGZvciB0aGlzIHNlc3Npb24geWV0LjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTgwMC81MFwiPlxuICAgICAgICAgICAgICAgICAge3N1Ym1pdEVycm9yICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtMyBiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5FcnJvcjo8L3NwYW4+IHtzdWJtaXRFcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgICB7bWlzc2luZ0l0ZW1zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBtbC01IG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge21pc3NpbmdJdGVtcy5tYXAoaSA9PiA8bGkga2V5PXtpfT57aX08L2xpPil9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgeyFjdXJyZW50U3VibWlzc2lvbiB8fCBbJ0RSQUZUJywgJ1JFU1VCTUlUVEVEJ10uaW5jbHVkZXMoY3VycmVudFN1Ym1pc3Npb24uc3RhdHVzKSA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFN1Ym1pc3Npb24gJiYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFN1Ym1pc3Npb24uYXR0ZW5kYW5jZUNvbXBsZXRlICYmIFxuICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTdWJtaXNzaW9uLmxlc3NvblBsYW5Db21wbGV0ZSAmJiBcbiAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3VibWlzc2lvbi5waG90b3NDb21wbGV0ZSAmJiBcbiAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3VibWlzc2lvbi5yZXBvcnRDb21wbGV0ZSAmJiBcbiAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3VibWlzc2lvbi5maW5hbmNlQ29tcGxldGUgXG4gICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkFsbCBpdGVtcyBjb21wbGV0ZS4gUmVhZHkgdG8gc3VibWl0LlwiIFxuICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDb21wbGV0ZSBhbGwgY2hlY2tsaXN0IGl0ZW1zIHRvIHVubG9jayBzdWJtaXNzaW9uLlwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdWJtaXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3VibWl0dGluZyB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIWN1cnJlbnRTdWJtaXNzaW9uIHx8IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAhKGN1cnJlbnRTdWJtaXNzaW9uLmF0dGVuZGFuY2VDb21wbGV0ZSAmJiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U3VibWlzc2lvbi5sZXNzb25QbGFuQ29tcGxldGUgJiYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFN1Ym1pc3Npb24ucGhvdG9zQ29tcGxldGUgJiYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFN1Ym1pc3Npb24ucmVwb3J0Q29tcGxldGUgJiYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFN1Ym1pc3Npb24uZmluYW5jZUNvbXBsZXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctYXV0byBweC02IHB5LTIuNSBiZy1ncmVlbi01MDAgaG92ZXI6YmctZ3JlZW4tNjAwIGRpc2FibGVkOmJnLWdyYXktMzAwIGRpc2FibGVkOnRleHQtZ3JheS01MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFN1Ym1pdCBTZXNzaW9uIGZvciBSZXZpZXdcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTdWJtaXNzaW9uIGlzIGN1cnJlbnRseSB7Y3VycmVudFN1Ym1pc3Npb24uc3RhdHVzLnJlcGxhY2UoL18vZywgJyAnKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIG1pbi1oLVs0MDBweF0gYmctZ3JheS01MCBkYXJrOmJnLWdyYXktODAwLzUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBwLTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8Q2FsZW5kYXJEYXlzIGNsYXNzTmFtZT1cInctMTYgaC0xNiB0ZXh0LWdyYXktMzAwIGRhcms6dGV4dC1ncmF5LTYwMCBtYi00XCIgLz5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBtYi0yXCI+Tm8gU2Vzc2lvbiBTZWxlY3RlZDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWF4LXctbWRcIj5QbGVhc2Ugc2VsZWN0IGEgc2Vzc2lvbiBkYXkgZnJvbSB0aGUgcGFuZWwgdG8gdmlldyBpdHMgc3VibWlzc2lvbiBjaGVja2xpc3QgYW5kIHN0YXR1cy48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICAvLyBTVVBFUiBBRE1JTiBWSUVXXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgICB7YWRtaW5TdWJtaXNzaW9ucy5tYXAoc3ViID0+IHtcbiAgICAgICAgICAgICAgY29uc3Qgc2Vzc2lvbiA9IHNlc3Npb25zLmZpbmQocyA9PiBzLmlkID09PSBzdWIuc2Vzc2lvbklkKTtcbiAgICAgICAgICAgICAgY29uc3QgaXNQZW5kaW5nID0gc3ViLnN0YXR1cyA9PT0gJ1BFTkRJTkdfUkVWSUVXJztcbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e3N1Yi5pZH0gY2xhc3NOYW1lPXtgYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBib3JkZXIgJHtpc1BlbmRpbmcgPyAnYm9yZGVyLWJyYW5kLTMwMCBzaGFkb3ctbWQgcmluZy0xIHJpbmctYnJhbmQtMTAwJyA6ICdib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgc2hhZG93LXNtJ30gcC01IHRyYW5zaXRpb24tYWxsYH0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3N1Yi5jbHVzdGVyTmFtZX08L2gzPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPkRheSB7c3ViLmRheU51bWJlcn0g4oCiIHtzZXNzaW9uPy5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtYm9sZCAke2dldFN0YXR1c0NvbG9yKHN1Yi5zdGF0dXMpfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtzdWIuc3RhdHVzLnJlcGxhY2UoL18vZywgJyAnKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1iLTVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj48VXNlcnMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIi8+IEF0dGVuZGFuY2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge3N1Yi5hdHRlbmRhbmNlQ29tcGxldGUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDBcIiAvPiA6IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiLz4gTGVzc29uIFBsYW48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge3N1Yi5sZXNzb25QbGFuQ29tcGxldGUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDBcIiAvPiA6IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxJbWFnZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiLz4gUGhvdG9zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdWIucGhvdG9zQ29tcGxldGUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDBcIiAvPiA6IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiLz4gUmVwb3J0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdWIucmVwb3J0Q29tcGxldGUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDBcIiAvPiA6IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwXCIgLz59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxEb2xsYXJTaWduIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIvPiBGaW5hbmNlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdWIuZmluYW5jZUNvbXBsZXRlID8gPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JlZW4tNTAwXCIgLz4gOiA8WENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcmVkLTUwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7aXNQZW5kaW5nICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0U2VsZWN0ZWRTdWJtaXNzaW9uKHN1Yik7IHNldFNob3dSZXZpZXdNb2RhbCh0cnVlKTsgc2V0UmV2aWV3QWN0aW9uKCdhcHByb3ZlJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgYmctYnJhbmQtNTAgaG92ZXI6YmctYnJhbmQtMTAwIHRleHQtYnJhbmQtNzAwIGRhcms6YmctYnJhbmQtOTAwLzMwIGRhcms6dGV4dC1icmFuZC0zMDAgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFJldmlldyBTdWJtaXNzaW9uXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAge2FkbWluU3VibWlzc2lvbnMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsIHB5LTEyIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICBObyBzdWJtaXNzaW9ucyBmb3VuZC5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSZXZpZXcgTW9kYWwgZm9yIFN1cGVyIEFkbWluICovfVxuICAgICAge3Nob3dSZXZpZXdNb2RhbCAmJiBzZWxlY3RlZFN1Ym1pc3Npb24gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCByb3VuZGVkLTJ4bCBzaGFkb3cteGwgdy1mdWxsIG1heC13LWxnIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+UmV2aWV3IFNlc3Npb24gU3VibWlzc2lvbjwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd1Jldmlld01vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgZGFyazpiZy1ncmF5LTkwMC81MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgYmxvY2sgbWItMVwiPkNsdXN0ZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3NlbGVjdGVkU3VibWlzc2lvbi5jbHVzdGVyTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBibG9jayBtYi0xXCI+RGF5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPkRheSB7c2VsZWN0ZWRTdWJtaXNzaW9uLmRheU51bWJlcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgYmxvY2sgbWItMVwiPlN1Ym1pdHRlZCBPbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTdWJtaXNzaW9uLnN1Ym1pdHRlZEF0ID8gbmV3IERhdGUoc2VsZWN0ZWRTdWJtaXNzaW9uLnN1Ym1pdHRlZEF0KS50b0xvY2FsZVN0cmluZygpIDogJ04vQSd9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTJcIj5SZXZpZXcgQWN0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJldmlld0FjdGlvbignYXBwcm92ZScpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMiBweC0zIHJvdW5kZWQtbGcgYm9yZGVyLTIgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICByZXZpZXdBY3Rpb24gPT09ICdhcHByb3ZlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1ncmVlbi01MDAgYmctZ3JlZW4tNTAgdGV4dC1ncmVlbi03MDAgZGFyazpiZy1ncmVlbi05MDAvMjAgZGFyazp0ZXh0LWdyZWVuLTQwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktNDAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gQXBwcm92ZVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXZpZXdBY3Rpb24oJ3Jlc3VibWlzc2lvbicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMiBweC0zIHJvdW5kZWQtbGcgYm9yZGVyLTIgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICByZXZpZXdBY3Rpb24gPT09ICdyZXN1Ym1pc3Npb24nIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXJlZC01MDAgYmctcmVkLTUwIHRleHQtcmVkLTcwMCBkYXJrOmJnLXJlZC05MDAvMjAgZGFyazp0ZXh0LXJlZC00MDAnIFxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFJlcXVlc3QgUmVzdWJtaXRcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIHtyZXZpZXdBY3Rpb24gPT09ICdhcHByb3ZlJyA/ICdSZW1hcmtzIChPcHRpb25hbCknIDogJ1JlYXNvbiBmb3IgUmVzdWJtaXNzaW9uIChSZXF1aXJlZCknfVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cmV2aWV3UmVtYXJrc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmV2aWV3UmVtYXJrcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ9e3Jldmlld0FjdGlvbiA9PT0gJ3Jlc3VibWlzc2lvbid9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1icmFuZC01MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBkYXJrOmJnLWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktNjAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17cmV2aWV3QWN0aW9uID09PSAnYXBwcm92ZScgPyBcIkFkZCBhbnkgbm90ZXMgaGVyZS4uLlwiIDogXCJFeHBsYWluIHdoYXQgbmVlZHMgdG8gYmUgZml4ZWQuLi5cIn1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDAgYmctZ3JheS01MCBkYXJrOmJnLWdyYXktODAwLzUwIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dSZXZpZXdNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTUwIHJvdW5kZWQtbGcgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6YmctZ3JheS03MDAgZGFyazpib3JkZXItZ3JheS02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXZpZXdTdWJtaXR9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZyB8fCAocmV2aWV3QWN0aW9uID09PSAncmVzdWJtaXNzaW9uJyAmJiAhcmV2aWV3UmVtYXJrcy50cmltKCkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktMiB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS01MCAke1xuICAgICAgICAgICAgICAgICAgcmV2aWV3QWN0aW9uID09PSAnYXBwcm92ZScgPyAnYmctZ3JlZW4tNTAwIGhvdmVyOmJnLWdyZWVuLTYwMCcgOiAnYmctcmVkLTUwMCBob3ZlcjpiZy1yZWQtNjAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgU3VibWl0IERlY2lzaW9uXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNlc3Npb25TdWJtaXNzaW9uVmlldztcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9TZXNzaW9uU3VibWlzc2lvblZpZXcudHN4In0=