import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\TqiLogo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const TqiLogo = ({ size = 96, className = "" }) => {
  return /* @__PURE__ */ jsxDEV(
    "img",
    {
      src: "/logo.png",
      alt: "TQI Logo",
      width: size,
      height: size,
      className: `shrink-0 select-none object-contain ${className}`
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/TqiLogo.tsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  );
};
_c = TqiLogo;
var _c;
$RefreshReg$(_c, "TqiLogo");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/TqiLogo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/TqiLogo.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/TqiLogo.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0k7QUFGRyxhQUFNQSxVQUFrQ0EsQ0FBQyxFQUFFQyxPQUFPLElBQUlDLFlBQVksR0FBRyxNQUFNO0FBQ2hGLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEtBQUk7QUFBQSxNQUNKLEtBQUk7QUFBQSxNQUNKLE9BQU9EO0FBQUFBLE1BQ1AsUUFBUUE7QUFBQUEsTUFDUixXQUFXLHVDQUF1Q0MsU0FBUztBQUFBO0FBQUEsSUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2dFO0FBR3BFO0FBQUVDLEtBVldIO0FBQStCLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlRxaUxvZ28iLCJzaXplIiwiY2xhc3NOYW1lIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVHFpTG9nby50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbmludGVyZmFjZSBUcWlMb2dvUHJvcHMge1xyXG4gIHNpemU/OiBudW1iZXIgfCBzdHJpbmc7XHJcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgVHFpTG9nbzogUmVhY3QuRkM8VHFpTG9nb1Byb3BzPiA9ICh7IHNpemUgPSA5NiwgY2xhc3NOYW1lID0gJycgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8aW1nIFxyXG4gICAgICBzcmM9XCIvbG9nby5wbmdcIiBcclxuICAgICAgYWx0PVwiVFFJIExvZ29cIiBcclxuICAgICAgd2lkdGg9e3NpemV9IFxyXG4gICAgICBoZWlnaHQ9e3NpemV9IFxyXG4gICAgICBjbGFzc05hbWU9e2BzaHJpbmstMCBzZWxlY3Qtbm9uZSBvYmplY3QtY29udGFpbiAke2NsYXNzTmFtZX1gfSBcclxuICAgIC8+XHJcbiAgKTtcclxufTtcclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1RxaUxvZ28udHN4In0=