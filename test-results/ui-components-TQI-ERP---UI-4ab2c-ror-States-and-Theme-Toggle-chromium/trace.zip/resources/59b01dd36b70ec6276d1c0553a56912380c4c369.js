import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AuditLogView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import Badge from "/src/components/ui/badge.tsx";
import { Table, TableHeader, TableBody, TableRow, TableCell } from "/src/components/ui/table.tsx";
import { Search, Download } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const AuditLogView = ({ auditLogs = [], userRole }) => {
  _s();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedModule, setSelectedModule] = useState("all");
  const [selectedAction, setSelectedAction] = useState("all");
  const filteredLogs = useMemo(() => {
    return auditLogs.filter((log) => {
      if (selectedModule !== "all" && log.module !== selectedModule) return false;
      if (selectedAction !== "all" && !log.action.toLowerCase().includes(selectedAction.toLowerCase())) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return log.userName.toLowerCase().includes(q) || log.action.toLowerCase().includes(q) || log.module.toLowerCase().includes(q) || log.clusterName && log.clusterName.toLowerCase().includes(q) || log.details.toLowerCase().includes(q) || log.recordId.toLowerCase().includes(q);
      }
      return true;
    });
  }, [auditLogs, selectedModule, selectedAction, searchTerm]);
  const handleExportCSV = () => {
    window.open("/api/export/excel?module=audit-logs", "_blank");
  };
  const getActionBadge = (action) => {
    const act = action.toLowerCase();
    if (act.includes("approved")) return /* @__PURE__ */ jsxDEV(Badge, { color: "success", size: "sm", children: action }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 50,
      columnNumber: 42
    }, this);
    if (act.includes("correction") || act.includes("rejected")) return /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: action }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 51,
      columnNumber: 72
    }, this);
    if (act.includes("created") || act.includes("submitted")) return /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: action }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 52,
      columnNumber: 70
    }, this);
    if (act.includes("deleted")) return /* @__PURE__ */ jsxDEV(Badge, { color: "error", size: "sm", children: action }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 53,
      columnNumber: 41
    }, this);
    return /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: action }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 54,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Audit & Governance Trail" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            filteredLogs.length,
            " Events Logged"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 66,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Immutable chronological record of submissions, approvals, corrections, enrollments, and status modifications." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 70,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleExportCSV,
          className: "inline-flex items-center gap-2 rounded-xl border border-gray-300 bg-white px-4 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition cursor-pointer self-start sm:self-auto",
          children: [
            /* @__PURE__ */ jsxDEV(Download, { className: "h-4 w-4 text-emerald-600 dark:text-emerald-400" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
              lineNumber: 79,
              columnNumber: 11
            }, this),
            "Export CSV / Excel"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 75,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 87,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search by user, action, details...",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 88,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-48", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedModule || "all",
            onValueChange: (val) => setSelectedModule(val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Modules" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 104,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 103,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Modules" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 107,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Attendance", children: "Attendance" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 108,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Lesson Plan", children: "Lesson Plans" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 109,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Finance", children: "Finance" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 110,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Sessions", children: "Sessions" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 111,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Correction Request", children: "Correction Requests" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 112,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Students", children: "Students" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 113,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "Clusters", children: "Clusters" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 114,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 106,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 99,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-40", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedAction || "all",
            onValueChange: (val) => setSelectedAction(val),
            children: [
              /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Actions" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 125,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 124,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Actions" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 128,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "approved", children: "Approvals" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 129,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "correction", children: "Corrections" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 130,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "submitted", children: "Submissions" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 131,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectItem, { value: "created", children: "Creations" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                  lineNumber: 132,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
                lineNumber: 127,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 120,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 119,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV(Table, { children: [
      /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "w-[180px]", children: "Timestamp" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 144,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "User" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 145,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Role" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 146,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Action" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 147,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Module" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 148,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Cluster" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 149,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Event Details" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 150,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 143,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 142,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: filteredLogs.length === 0 ? /* @__PURE__ */ jsxDEV(TableRow, { children: /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 7, className: "text-center py-12 text-gray-400 dark:text-gray-500", children: "No matching audit log events found." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 156,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 155,
        columnNumber: 13
      }, this) : filteredLogs.map(
        (log) => /* @__PURE__ */ jsxDEV(TableRow, { className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors", children: [
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-500 dark:text-gray-400 font-mono text-xs whitespace-nowrap", children: log.timestamp }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 163,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "font-semibold text-gray-900 dark:text-white text-xs whitespace-nowrap", children: log.userName }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 166,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(Badge, { color: log.userRole === "Super Admin" ? "primary" : "light", size: "sm", children: log.userRole }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 170,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 169,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "whitespace-nowrap", children: getActionBadge(log.action) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 174,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "font-medium text-gray-700 dark:text-gray-300 text-xs whitespace-nowrap", children: log.module }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 177,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-500 dark:text-gray-400 text-xs whitespace-nowrap", children: log.clusterName || "Central" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 180,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-700 dark:text-gray-300 text-xs max-w-[340px]", children: /* @__PURE__ */ jsxDEV("div", { className: "truncate", title: log.details, children: log.details }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 184,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
            lineNumber: 183,
            columnNumber: 19
          }, this)
        ] }, log.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
          lineNumber: 162,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
        lineNumber: 153,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 141,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
      lineNumber: 140,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx",
    lineNumber: 58,
    columnNumber: 5
  }, this);
};
_s(AuditLogView, "865OCmi0TIcqXkeICv1wcCKzIx4=");
_c = AuditLogView;
var _c;
$RefreshReg$(_c, "AuditLogView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/AuditLogView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUR5Qzs7QUFqRHpDLFNBQWdCQSxVQUFVQyxlQUFlO0FBRXpDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsT0FBT0MsYUFBYUMsV0FBV0MsVUFBVUMsaUJBQWlCO0FBQ25FLFNBQVNDLFFBQVFDLGdCQUFnQjtBQU8xQixhQUFNQyxlQUE0Q0EsQ0FBQyxFQUFFQyxZQUFZLElBQUlDLFNBQVMsTUFBTTtBQUFBQyxLQUFBO0FBQ3pGLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJcEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FCLGdCQUFnQkMsaUJBQWlCLElBQUl0QixTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDdUIsZ0JBQWdCQyxpQkFBaUIsSUFBSXhCLFNBQVMsS0FBSztBQUUxRCxRQUFNeUIsZUFBZXhCLFFBQVEsTUFBTTtBQUNqQyxXQUFPZSxVQUFVVSxPQUFPLENBQUNDLFFBQVE7QUFDL0IsVUFBSU4sbUJBQW1CLFNBQVNNLElBQUlDLFdBQVdQLGVBQWdCLFFBQU87QUFDdEUsVUFBSUUsbUJBQW1CLFNBQVMsQ0FBQ0ksSUFBSUUsT0FBT0MsWUFBWSxFQUFFQyxTQUFTUixlQUFlTyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBRXpHLFVBQUlYLFlBQVk7QUFDZCxjQUFNYSxJQUFJYixXQUFXVyxZQUFZO0FBQ2pDLGVBQ0VILElBQUlNLFNBQVNILFlBQVksRUFBRUMsU0FBU0MsQ0FBQyxLQUNyQ0wsSUFBSUUsT0FBT0MsWUFBWSxFQUFFQyxTQUFTQyxDQUFDLEtBQ25DTCxJQUFJQyxPQUFPRSxZQUFZLEVBQUVDLFNBQVNDLENBQUMsS0FDbENMLElBQUlPLGVBQWVQLElBQUlPLFlBQVlKLFlBQVksRUFBRUMsU0FBU0MsQ0FBQyxLQUM1REwsSUFBSVEsUUFBUUwsWUFBWSxFQUFFQyxTQUFTQyxDQUFDLEtBQ3BDTCxJQUFJUyxTQUFTTixZQUFZLEVBQUVDLFNBQVNDLENBQUM7QUFBQSxNQUV6QztBQUNBLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ2hCLFdBQVdLLGdCQUFnQkUsZ0JBQWdCSixVQUFVLENBQUM7QUFFMUQsUUFBTWtCLGtCQUFrQkEsTUFBTTtBQUM1QkMsV0FBT0MsS0FBSyx1Q0FBdUMsUUFBUTtBQUFBLEVBQzdEO0FBRUEsUUFBTUMsaUJBQWlCQSxDQUFDWCxXQUFtQjtBQUN6QyxVQUFNWSxNQUFNWixPQUFPQyxZQUFZO0FBQy9CLFFBQUlXLElBQUlWLFNBQVMsVUFBVSxFQUFHLFFBQU8sdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUFNRixvQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUM5RSxRQUFJWSxJQUFJVixTQUFTLFlBQVksS0FBS1UsSUFBSVYsU0FBUyxVQUFVLEVBQUcsUUFBTyx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQU1GLG9CQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQzVHLFFBQUlZLElBQUlWLFNBQVMsU0FBUyxLQUFLVSxJQUFJVixTQUFTLFdBQVcsRUFBRyxRQUFPLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFBTUYsb0JBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFDMUcsUUFBSVksSUFBSVYsU0FBUyxTQUFTLEVBQUcsUUFBTyx1QkFBQyxTQUFNLE9BQU0sU0FBUSxNQUFLLE1BQU1GLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVDO0FBQzNFLFdBQU8sdUJBQUMsU0FBTSxPQUFNLFNBQVEsTUFBSyxNQUFNQSxvQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QztBQUFBLEVBQ2hEO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDhFQUE0RSx3Q0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6Qko7QUFBQUEseUJBQWFpQjtBQUFBQSxZQUFPO0FBQUEsZUFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQStDLDZIQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNMO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFTLFdBQVUsb0RBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFKdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUE7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwrQkFBQyxVQUFPLFdBQVUsMEZBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0c7QUFBQSxRQUN4RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osT0FBT2xCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDd0IsTUFBTXZCLGNBQWN1QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDN0MsV0FBVTtBQUFBO0FBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLbVQ7QUFBQSxXQVByVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPeEIsa0JBQWtCO0FBQUEsWUFDekIsZUFBZSxDQUFDeUIsUUFBUXhCLGtCQUFrQndCLEdBQUc7QUFBQSxZQUU3QztBQUFBLHFDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxpQkFDQztBQUFBLHVDQUFDLGNBQVcsT0FBTSxPQUFNLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyxjQUFXLE9BQU0sY0FBYSwwQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsY0FBVyxPQUFNLGVBQWMsNEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQzVDLHVCQUFDLGNBQVcsT0FBTSxXQUFVLHVCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxnQkFDckMsdUJBQUMsY0FBVyxPQUFNLHNCQUFxQixtQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQ7QUFBQSxnQkFDMUQsdUJBQUMsY0FBVyxPQUFNLFlBQVcsd0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQ3JDLHVCQUFDLGNBQVcsT0FBTSxZQUFXLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQztBQUFBLG1CQVJ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUE7QUFBQTtBQUFBLFVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT3ZCLGtCQUFrQjtBQUFBLFlBQ3pCLGVBQWUsQ0FBQ3VCLFFBQVF0QixrQkFBa0JzQixHQUFHO0FBQUEsWUFFN0M7QUFBQSxxQ0FBQyxpQkFBYyxXQUFVLGVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxpQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx1Q0FBQyxjQUFXLE9BQU0sT0FBTSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQSxnQkFDbkMsdUJBQUMsY0FBVyxPQUFNLFlBQVcseUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQ3RDLHVCQUFDLGNBQVcsT0FBTSxjQUFhLDJCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGdCQUMxQyx1QkFBQyxjQUFXLE9BQU0sYUFBWSwyQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsY0FBVyxPQUFNLFdBQVUseUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsbUJBTHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQTtBQUFBO0FBQUEsVUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsU0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9EQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlIQUNiLGlDQUFDLFNBQ0M7QUFBQSw2QkFBQyxlQUNDLGlDQUFDLFlBQ0M7QUFBQSwrQkFBQyxhQUFVLFVBQVEsTUFBQyxXQUFVLGFBQVkseUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUNuRCx1QkFBQyxhQUFVLFVBQVEsTUFBQyxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLGFBQVUsVUFBUSxNQUFDLG9CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDeEIsdUJBQUMsYUFBVSxVQUFRLE1BQUMsc0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUMxQix1QkFBQyxhQUFVLFVBQVEsTUFBQyxzQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQzFCLHVCQUFDLGFBQVUsVUFBUSxNQUFDLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDM0IsdUJBQUMsYUFBVSxVQUFRLE1BQUMsNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxXQVBuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0VyQix1QkFBYWlCLFdBQVcsSUFDdkIsdUJBQUMsWUFDQyxpQ0FBQyxhQUFVLFNBQVMsR0FBRyxXQUFVLHNEQUFvRCxtREFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBRUFqQixhQUFhc0I7QUFBQUEsUUFBSSxDQUFDcEIsUUFDaEIsdUJBQUMsWUFBc0IsV0FBVSxvRUFDL0I7QUFBQSxpQ0FBQyxhQUFVLFdBQVUsd0VBQ2xCQSxjQUFJcUIsYUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLFdBQVUseUVBQ2xCckIsY0FBSU0sWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLFdBQVUscUJBQ25CLGlDQUFDLFNBQU0sT0FBT04sSUFBSVYsYUFBYSxnQkFBZ0IsWUFBWSxTQUFTLE1BQUssTUFDdEVVLGNBQUlWLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSxxQkFDbEJ1Qix5QkFBZWIsSUFBSUUsTUFBTSxLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxhQUFVLFdBQVUsMEVBQ2xCRixjQUFJQyxVQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLGFBQVUsV0FBVSw4REFDbEJELGNBQUlPLGVBQWUsYUFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsYUFBVSxXQUFVLDBEQUNuQixpQ0FBQyxTQUFJLFdBQVUsWUFBVyxPQUFPUCxJQUFJUSxTQUNsQ1IsY0FBSVEsV0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBekJhUixJQUFJc0IsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLE1BQ0QsS0FwQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLFNBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtREEsS0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQTtBQUFBLE9BdklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SUE7QUFFSjtBQUFFL0IsR0FqTFdILGNBQXlDO0FBQUEsS0FBekNBO0FBQXlDLElBQUFtQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIkJhZGdlIiwiVGFibGUiLCJUYWJsZUhlYWRlciIsIlRhYmxlQm9keSIsIlRhYmxlUm93IiwiVGFibGVDZWxsIiwiU2VhcmNoIiwiRG93bmxvYWQiLCJBdWRpdExvZ1ZpZXciLCJhdWRpdExvZ3MiLCJ1c2VyUm9sZSIsIl9zIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzZWxlY3RlZE1vZHVsZSIsInNldFNlbGVjdGVkTW9kdWxlIiwic2VsZWN0ZWRBY3Rpb24iLCJzZXRTZWxlY3RlZEFjdGlvbiIsImZpbHRlcmVkTG9ncyIsImZpbHRlciIsImxvZyIsIm1vZHVsZSIsImFjdGlvbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJxIiwidXNlck5hbWUiLCJjbHVzdGVyTmFtZSIsImRldGFpbHMiLCJyZWNvcmRJZCIsImhhbmRsZUV4cG9ydENTViIsIndpbmRvdyIsIm9wZW4iLCJnZXRBY3Rpb25CYWRnZSIsImFjdCIsImxlbmd0aCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInZhbCIsIm1hcCIsInRpbWVzdGFtcCIsImlkIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVkaXRMb2dWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEF1ZGl0TG9nRW50cnkgfSBmcm9tIFwiLi4vdHlwZXNcIjtcbmltcG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0SXRlbSxcbiAgU2VsZWN0VHJpZ2dlcixcbiAgU2VsZWN0VmFsdWUsXG59IGZyb20gXCIuL3VpL3NlbGVjdFwiO1xuaW1wb3J0IEJhZGdlIGZyb20gXCIuL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBUYWJsZSwgVGFibGVIZWFkZXIsIFRhYmxlQm9keSwgVGFibGVSb3csIFRhYmxlQ2VsbCB9IGZyb20gXCIuL3VpL3RhYmxlXCI7XG5pbXBvcnQgeyBTZWFyY2gsIERvd25sb2FkIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgQXVkaXRMb2dWaWV3UHJvcHMge1xuICBhdWRpdExvZ3M6IEF1ZGl0TG9nRW50cnlbXTtcbiAgdXNlclJvbGU6IFwiU3VwZXIgQWRtaW5cIiB8IFwiQ2x1c3RlciBBZG1pblwiO1xufVxuXG5leHBvcnQgY29uc3QgQXVkaXRMb2dWaWV3OiBSZWFjdC5GQzxBdWRpdExvZ1ZpZXdQcm9wcz4gPSAoeyBhdWRpdExvZ3MgPSBbXSwgdXNlclJvbGUgfSkgPT4ge1xuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NlbGVjdGVkTW9kdWxlLCBzZXRTZWxlY3RlZE1vZHVsZV0gPSB1c2VTdGF0ZShcImFsbFwiKTtcbiAgY29uc3QgW3NlbGVjdGVkQWN0aW9uLCBzZXRTZWxlY3RlZEFjdGlvbl0gPSB1c2VTdGF0ZShcImFsbFwiKTtcblxuICBjb25zdCBmaWx0ZXJlZExvZ3MgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gYXVkaXRMb2dzLmZpbHRlcigobG9nKSA9PiB7XG4gICAgICBpZiAoc2VsZWN0ZWRNb2R1bGUgIT09IFwiYWxsXCIgJiYgbG9nLm1vZHVsZSAhPT0gc2VsZWN0ZWRNb2R1bGUpIHJldHVybiBmYWxzZTtcbiAgICAgIGlmIChzZWxlY3RlZEFjdGlvbiAhPT0gXCJhbGxcIiAmJiAhbG9nLmFjdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlbGVjdGVkQWN0aW9uLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gZmFsc2U7XG5cbiAgICAgIGlmIChzZWFyY2hUZXJtKSB7XG4gICAgICAgIGNvbnN0IHEgPSBzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgbG9nLnVzZXJOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcbiAgICAgICAgICBsb2cuYWN0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcbiAgICAgICAgICBsb2cubW9kdWxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcbiAgICAgICAgICAobG9nLmNsdXN0ZXJOYW1lICYmIGxvZy5jbHVzdGVyTmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpKSB8fFxuICAgICAgICAgIGxvZy5kZXRhaWxzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcbiAgICAgICAgICBsb2cucmVjb3JkSWQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSk7XG4gIH0sIFthdWRpdExvZ3MsIHNlbGVjdGVkTW9kdWxlLCBzZWxlY3RlZEFjdGlvbiwgc2VhcmNoVGVybV0pO1xuXG4gIGNvbnN0IGhhbmRsZUV4cG9ydENTViA9ICgpID0+IHtcbiAgICB3aW5kb3cub3BlbihcIi9hcGkvZXhwb3J0L2V4Y2VsP21vZHVsZT1hdWRpdC1sb2dzXCIsIFwiX2JsYW5rXCIpO1xuICB9O1xuXG4gIGNvbnN0IGdldEFjdGlvbkJhZGdlID0gKGFjdGlvbjogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgYWN0ID0gYWN0aW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGFjdC5pbmNsdWRlcyhcImFwcHJvdmVkXCIpKSByZXR1cm4gPEJhZGdlIGNvbG9yPVwic3VjY2Vzc1wiIHNpemU9XCJzbVwiPnthY3Rpb259PC9CYWRnZT47XG4gICAgaWYgKGFjdC5pbmNsdWRlcyhcImNvcnJlY3Rpb25cIikgfHwgYWN0LmluY2x1ZGVzKFwicmVqZWN0ZWRcIikpIHJldHVybiA8QmFkZ2UgY29sb3I9XCJ3YXJuaW5nXCIgc2l6ZT1cInNtXCI+e2FjdGlvbn08L0JhZGdlPjtcbiAgICBpZiAoYWN0LmluY2x1ZGVzKFwiY3JlYXRlZFwiKSB8fCBhY3QuaW5jbHVkZXMoXCJzdWJtaXR0ZWRcIikpIHJldHVybiA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+e2FjdGlvbn08L0JhZGdlPjtcbiAgICBpZiAoYWN0LmluY2x1ZGVzKFwiZGVsZXRlZFwiKSkgcmV0dXJuIDxCYWRnZSBjb2xvcj1cImVycm9yXCIgc2l6ZT1cInNtXCI+e2FjdGlvbn08L0JhZGdlPjtcbiAgICByZXR1cm4gPEJhZGdlIGNvbG9yPVwibGlnaHRcIiBzaXplPVwic21cIj57YWN0aW9ufTwvQmFkZ2U+O1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBBdWRpdCAmIEdvdmVybmFuY2UgVHJhaWxcbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZExvZ3MubGVuZ3RofSBFdmVudHMgTG9nZ2VkXG4gICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgSW1tdXRhYmxlIGNocm9ub2xvZ2ljYWwgcmVjb3JkIG9mIHN1Ym1pc3Npb25zLCBhcHByb3ZhbHMsIGNvcnJlY3Rpb25zLCBlbnJvbGxtZW50cywgYW5kIHN0YXR1cyBtb2RpZmljYXRpb25zLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydENTVn1cbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiXG4gICAgICAgID5cbiAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgRXhwb3J0IENTViAvIEV4Y2VsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGaWx0ZXIgQmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctc21cIj5cbiAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMCBhYnNvbHV0ZSBsZWZ0LTMuNSB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSB1c2VyLCBhY3Rpb24sIGRldGFpbHMuLi5cIlxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwbC0xMCBwci00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnBsYWNlaG9sZGVyOnRleHQtZ3JheS01MDBcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDhcIj5cbiAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTW9kdWxlIHx8IFwiYWxsXCJ9XG4gICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldFNlbGVjdGVkTW9kdWxlKHZhbCl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiQWxsIE1vZHVsZXNcIiAvPlxuICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIE1vZHVsZXM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJBdHRlbmRhbmNlXCI+QXR0ZW5kYW5jZTwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkxlc3NvbiBQbGFuXCI+TGVzc29uIFBsYW5zPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiRmluYW5jZVwiPkZpbmFuY2U8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJTZXNzaW9uc1wiPlNlc3Npb25zPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQ29ycmVjdGlvbiBSZXF1ZXN0XCI+Q29ycmVjdGlvbiBSZXF1ZXN0czwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIlN0dWRlbnRzXCI+U3R1ZGVudHM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJDbHVzdGVyc1wiPkNsdXN0ZXJzPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00MFwiPlxuICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBY3Rpb24gfHwgXCJhbGxcIn1cbiAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRBY3Rpb24odmFsKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgQWN0aW9uc1wiIC8+XG4gICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cbiAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgQWN0aW9uczwvU2VsZWN0SXRlbT5cbiAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFwcHJvdmVkXCI+QXBwcm92YWxzPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiY29ycmVjdGlvblwiPkNvcnJlY3Rpb25zPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwic3VibWl0dGVkXCI+U3VibWlzc2lvbnM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJjcmVhdGVkXCI+Q3JlYXRpb25zPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEF1ZGl0IExvZyBUYWJsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XG4gICAgICAgIDxUYWJsZT5cbiAgICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXIgY2xhc3NOYW1lPVwidy1bMTgwcHhdXCI+VGltZXN0YW1wPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+VXNlcjwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICA8VGFibGVDZWxsIGlzSGVhZGVyPlJvbGU8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5BY3Rpb248L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5Nb2R1bGU8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlcj5DbHVzdGVyPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+RXZlbnQgRGV0YWlsczwvVGFibGVDZWxsPlxuICAgICAgICAgICAgPC9UYWJsZVJvdz5cbiAgICAgICAgICA8L1RhYmxlSGVhZGVyPlxuICAgICAgICAgIDxUYWJsZUJvZHk+XG4gICAgICAgICAgICB7ZmlsdGVyZWRMb2dzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY29sU3Bhbj17N30gY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTIgdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIE5vIG1hdGNoaW5nIGF1ZGl0IGxvZyBldmVudHMgZm91bmQuXG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBmaWx0ZXJlZExvZ3MubWFwKChsb2cpID0+IChcbiAgICAgICAgICAgICAgICA8VGFibGVSb3cga2V5PXtsb2cuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTAvODAgZGFyazpob3ZlcjpiZy13aGl0ZS9bMC4wMl0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgZm9udC1tb25vIHRleHQteHMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvZy50aW1lc3RhbXB9XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXhzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtsb2cudXNlck5hbWV9XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPXtsb2cudXNlclJvbGUgPT09IFwiU3VwZXIgQWRtaW5cIiA/IFwicHJpbWFyeVwiIDogXCJsaWdodFwifSBzaXplPVwic21cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bG9nLnVzZXJSb2xlfVxuICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cIndoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtnZXRBY3Rpb25CYWRnZShsb2cuYWN0aW9uKX1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCB0ZXh0LXhzIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtsb2cubW9kdWxlfVxuICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIHRleHQteHMgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAge2xvZy5jbHVzdGVyTmFtZSB8fCBcIkNlbnRyYWxcIn1cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTMwMCB0ZXh0LXhzIG1heC13LVszNDBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiIHRpdGxlPXtsb2cuZGV0YWlsc30+XG4gICAgICAgICAgICAgICAgICAgICAge2xvZy5kZXRhaWxzfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgICkpXG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvVGFibGVCb2R5PlxuICAgICAgICA8L1RhYmxlPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0F1ZGl0TG9nVmlldy50c3gifQ==