import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=8975830d"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import App from "/src/App.tsx?t=1787665964082";
import { ThemeProvider } from "/src/components/theme-provider.tsx";
import "/src/index.css?t=1787665964082";
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(ThemeProvider, { defaultTheme: "light", storageKey: "tqi-ui-theme", children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/main.tsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/main.tsx",
    lineNumber: 9,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/main.tsx",
    lineNumber: 8,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTixTQUFRQSxrQkFBaUI7QUFDekIsU0FBUUMsa0JBQWlCO0FBQ3pCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MscUJBQXFCO0FBQzlCLE9BQU87QUFFUEYsV0FBV0csU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUM7QUFBQUEsRUFDM0MsdUJBQUMsY0FDQyxpQ0FBQyxpQkFBYyxjQUFhLFNBQVEsWUFBVyxnQkFDN0MsaUNBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQUksS0FETjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFDRiIsIm5hbWVzIjpbIlN0cmljdE1vZGUiLCJjcmVhdGVSb290IiwiQXBwIiwiVGhlbWVQcm92aWRlciIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtTdHJpY3RNb2RlfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7Y3JlYXRlUm9vdH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XHJcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAudHN4JztcclxuaW1wb3J0IHsgVGhlbWVQcm92aWRlciB9IGZyb20gJy4vY29tcG9uZW50cy90aGVtZS1wcm92aWRlci50c3gnO1xyXG5pbXBvcnQgJy4vaW5kZXguY3NzJztcclxuXHJcbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSEpLnJlbmRlcihcclxuICA8U3RyaWN0TW9kZT5cclxuICAgIDxUaGVtZVByb3ZpZGVyIGRlZmF1bHRUaGVtZT1cImxpZ2h0XCIgc3RvcmFnZUtleT1cInRxaS11aS10aGVtZVwiPlxyXG4gICAgICA8QXBwIC8+XHJcbiAgICA8L1RoZW1lUHJvdmlkZXI+XHJcbiAgPC9TdHJpY3RNb2RlPixcclxuKTtcclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9tYWluLnRzeCJ9