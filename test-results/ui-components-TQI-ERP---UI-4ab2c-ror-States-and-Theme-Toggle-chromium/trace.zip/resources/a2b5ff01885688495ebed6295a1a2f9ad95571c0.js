import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ApprovalCenterView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"];
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
export const ApprovalCenterView = ({
  approvals = [],
  clusters = [],
  userRole,
  onApprove,
  onRequestCorrection,
  onReject,
  onNavigate
}) => {
  _s();
  const [selectedModuleTab, setSelectedModuleTab] = useState("all");
  const [selectedClusterFilter, setSelectedClusterFilter] = useState("all");
  const [selectedStatusFilter, setSelectedStatusFilter] = useState("Pending");
  const [searchTerm, setSearchTerm] = useState("");
  const [reviewItem, setReviewItem] = useState(null);
  const [correctionReasonInput, setCorrectionReasonInput] = useState("");
  const [showCorrectionForm, setShowCorrectionForm] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const tabCounts = useMemo(() => {
    const pendingOnly = approvals.filter((a) => a.status === "Pending");
    return {
      all: pendingOnly.length,
      attendance: pendingOnly.filter((a) => a.module === "Attendance").length,
      lessonPlan: pendingOnly.filter((a) => a.module === "Lesson Plan").length,
      finance: pendingOnly.filter((a) => a.module === "Finance").length,
      sessions: pendingOnly.filter((a) => a.module === "Sessions").length,
      corrections: pendingOnly.filter((a) => a.module === "Correction Request").length
    };
  }, [approvals]);
  const filteredApprovals = useMemo(() => {
    return approvals.filter((item) => {
      if (selectedModuleTab === "attendance" && item.module !== "Attendance") return false;
      if (selectedModuleTab === "lessonPlan" && item.module !== "Lesson Plan") return false;
      if (selectedModuleTab === "finance" && item.module !== "Finance") return false;
      if (selectedModuleTab === "sessions" && item.module !== "Sessions") return false;
      if (selectedModuleTab === "corrections" && item.module !== "Correction Request") return false;
      if (selectedStatusFilter !== "all" && item.status !== selectedStatusFilter) return false;
      if (selectedClusterFilter !== "all") {
        const cLower = selectedClusterFilter.toLowerCase();
        if (item.clusterId.toLowerCase() !== cLower && !item.clusterName.toLowerCase().includes(cLower)) {
          return false;
        }
      }
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return item.recordTitle.toLowerCase().includes(q) || item.clusterName.toLowerCase().includes(q) || item.submittedBy.toLowerCase().includes(q) || item.module.toLowerCase().includes(q);
      }
      return true;
    });
  }, [approvals, selectedModuleTab, selectedStatusFilter, selectedClusterFilter, searchTerm]);
  const handleOpenReview = (item) => {
    setReviewItem(item);
    setCorrectionReasonInput("");
    setShowCorrectionForm(false);
    setIsRejecting(false);
  };
  const handleApproveConfirm = () => {
    if (!reviewItem) return;
    onApprove(reviewItem.id, reviewItem.module, reviewItem.recordId);
    setReviewItem(null);
  };
  const handleSubmitCorrection = () => {
    if (!reviewItem) return;
    if (!correctionReasonInput.trim()) {
      alert("Please enter a specific reason for requesting correction or resubmission.");
      return;
    }
    if (isRejecting) {
      onReject(reviewItem.id, reviewItem.module, reviewItem.recordId, correctionReasonInput.trim());
    } else {
      onRequestCorrection(reviewItem.id, reviewItem.module, reviewItem.recordId, correctionReasonInput.trim());
    }
    setReviewItem(null);
  };
  const getModuleBadgeColor = (module) => {
    switch (module) {
      case "Attendance":
        return "bg-blue-50 text-[#002869] border-blue-200";
      case "Lesson Plan":
        return "bg-purple-50 text-purple-800 border-purple-200";
      case "Finance":
        return "bg-amber-50 text-amber-900 border-amber-200";
      case "Correction Request":
        return "bg-orange-50 text-orange-900 border-orange-200";
      default:
        return "bg-slate-50 text-slate-800 border-slate-200";
    }
  };
  const getModuleIcon = (module) => {
    switch (module) {
      case "Attendance":
        return "how_to_reg";
      case "Lesson Plan":
        return "menu_book";
      case "Finance":
        return "payments";
      case "Correction Request":
        return "edit_note";
      default:
        return "verified";
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-5", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-bold tracking-tight text-foreground sm:text-2xl", children: "Approval Center" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 159,
            columnNumber: 13
          }, this),
          tabCounts.all > 0 && /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800", children: [
            tabCounts.all,
            " pending"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 163,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 158,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted-foreground mt-0.5", children: "Review and action attendance, lesson plans, finance claims and correction requests." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 157,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 text-xs", children: [
        { label: "Attendance", val: tabCounts.attendance },
        { label: "Lesson plans", val: tabCounts.lessonPlan },
        { label: "Finance claims", val: tabCounts.finance }
      ].map(
        (s) => /* @__PURE__ */ jsxDEV("div", { className: "space-y-0.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] uppercase font-semibold text-muted-foreground", children: s.label }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 179,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-lg font-bold text-foreground", children: s.val }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 180,
            columnNumber: 15
          }, this)
        ] }, s.label, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 178,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 172,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 border-b border-border/40 text-xs font-medium overflow-x-auto", children: [
      { id: "all", label: "All Items", count: tabCounts.all },
      { id: "attendance", label: "Attendance", count: tabCounts.attendance },
      { id: "lessonPlan", label: "Lesson Plans", count: tabCounts.lessonPlan },
      { id: "finance", label: "Finance Claims", count: tabCounts.finance },
      { id: "corrections", label: "Correction Requests", count: tabCounts.corrections }
    ].map((tab) => {
      const isActive = selectedModuleTab === tab.id;
      return /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setSelectedModuleTab(tab.id),
          className: `relative pb-3 transition-colors whitespace-nowrap ${isActive ? "text-foreground font-semibold" : "text-muted-foreground hover:text-foreground"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: tab.label }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 208,
                columnNumber: 17
              }, this),
              tab.count > 0 && /* @__PURE__ */ jsxDEV("span", { className: `text-[10px] ${isActive ? "text-foreground font-bold" : "text-muted-foreground"}`, children: [
                "(",
                tab.count,
                ")"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 210,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 207,
              columnNumber: 15
            }, this),
            isActive && /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-0 left-0 right-0 h-0.5 bg-foreground" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 216,
              columnNumber: 15
            }, this)
          ]
        },
        tab.id,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 197,
          columnNumber: 13
        },
        this
      );
    }) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-3 py-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 flex-1 min-w-[280px]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-xs", children: "Cluster:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 228,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-56", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedClusterFilter || "all",
              onValueChange: (val) => setSelectedClusterFilter(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Clusters" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 235,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 234,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Clusters (Tamil Nadu)" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 238,
                    columnNumber: 19
                  }, this),
                  clusters.map(
                    (c) => /* @__PURE__ */ jsxDEV(SelectItem, { value: c.id, children: c.name }, c.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                      lineNumber: 240,
                      columnNumber: 19
                    }, this)
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 237,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 230,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 229,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 227,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-xs", children: "Status:" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 251,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-44", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedStatusFilter || "all",
              onValueChange: (val) => setSelectedStatusFilter(val),
              children: [
                /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-8 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "All Statuses" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 258,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 257,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "all", children: "All Statuses" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 261,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Pending", children: "Pending Review" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 262,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Approved", children: "Approved" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 263,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Correction Requested", children: "Correction Requested" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 264,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectItem, { value: "Rejected", children: "Rejected" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 265,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 260,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 253,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 252,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 250,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 225,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative min-w-[220px]", children: [
        /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-2.5 top-2.5 h-3.5 w-3.5 text-gray-400" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search submissions...",
            value: searchTerm,
            onChange: (e) => setSearchTerm(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-8 pr-3 py-1.5 text-xs text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 275,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 273,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 224,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left text-xs border-collapse", children: [
      /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-border/50 text-muted-foreground font-semibold", children: [
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Module" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 290,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Cluster" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 291,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Item & Description" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 292,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Submitted By" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 293,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Date & Time" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 294,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3", children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 295,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "py-2.5 px-3 text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 296,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 289,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 288,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-border/30", children: filteredApprovals.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 7, className: "text-center py-12 text-slate-400", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[36px] text-slate-300 block mb-1", children: "check_circle" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 303,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-slate-600", children: "No approval requests found" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 306,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-400", children: "All submissions in this category are up to date." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 307,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 302,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 301,
        columnNumber: 13
      }, this) : filteredApprovals.map(
        (item) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-slate-50/70 transition-colors", children: [
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold border ${getModuleBadgeColor(
                item.module
              )}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: getModuleIcon(item.module) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 319,
                  columnNumber: 25
                }, this),
                item.module
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 314,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 313,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 whitespace-nowrap font-medium text-slate-700", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-[#002869]" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 327,
              columnNumber: 25
            }, this),
            item.clusterName
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 326,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 325,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 font-semibold text-[#002869] max-w-[280px]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "truncate", title: item.recordTitle, children: item.recordTitle }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 332,
              columnNumber: 23
            }, this),
            item.details && /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-slate-500 font-normal truncate mt-0.5", children: [
              item.module === "Attendance" && `${item.details.presentCount || 0} Present / ${item.details.totalCount || 0} Students (${item.details.villageName || ""})`,
              item.module === "Lesson Plan" && `${item.details.duration || "90 Mins"} • ${item.details.targetStandard || "6th-8th Std"}`,
              item.module === "Finance" && `Rs. ${item.details.totalAmount || 0} • SPOC: ${item.details.spocName || "Admin"}`,
              item.module === "Correction Request" && `Reason: ${item.details.reason || ""}`
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 336,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 331,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 whitespace-nowrap text-slate-600", children: item.submittedBy }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 344,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 whitespace-nowrap text-slate-500 text-[11px]", children: item.submittedAt }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 347,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: `inline-block px-2 py-0.5 rounded-full text-[10.5px] font-bold ${item.status === "Approved" ? "bg-emerald-100 text-emerald-800" : item.status === "Pending" ? "bg-amber-100 text-amber-900 animate-pulse" : item.status === "Correction Requested" ? "bg-orange-100 text-orange-800" : "bg-red-100 text-red-800"}`,
              children: item.status
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 351,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 350,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "py-3.5 px-4 text-right whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleOpenReview(item),
                className: "bg-[#002869] hover:bg-[#001f52] text-white px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer shadow-xs",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "visibility" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 371,
                    columnNumber: 27
                  }, this),
                  "Review"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 367,
                columnNumber: 25
              },
              this
            ),
            item.status === "Pending" && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => onApprove(item.id, item.module, item.recordId),
                className: "bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer shadow-xs",
                title: "Quick Approve",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[14px]", children: "check" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                    lineNumber: 380,
                    columnNumber: 29
                  }, this),
                  "Approve"
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 375,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 366,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 365,
            columnNumber: 21
          }, this)
        ] }, item.id, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 312,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 299,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 287,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 286,
      columnNumber: 7
    }, this),
    reviewItem && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-[#c4c6d3] rounded-md w-full max-w-2xl shadow-sm overflow-hidden flex flex-col max-h-[90vh]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-[#002869] text-white p-4 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[22px]", children: getModuleIcon(reviewItem.module) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 400,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold", children: [
              "Review Submission: ",
              reviewItem.module
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 404,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-200", children: [
              reviewItem.clusterName,
              " • Submitted by ",
              reviewItem.submittedBy
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 405,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 403,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 399,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setReviewItem(null),
            className: "text-white/80 hover:text-white p-1 rounded-full hover:bg-white10 cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 414,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 410,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 398,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 overflow-y-auto space-y-4 text-xs", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-md p-3.5 space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider block", children: "Record Title" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 423,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-[#002869]", children: reviewItem.recordTitle }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 426,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 422,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `px-2.5 py-0.5 rounded-full text-[11px] font-bold ${reviewItem.status === "Approved" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-900"}`,
                children: reviewItem.status
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 428,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 421,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-200 text-slate-600", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-slate-400 block", children: "Cluster" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 441,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-800", children: reviewItem.clusterName }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 442,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 440,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-slate-400 block", children: "Submission Date" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 445,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-800", children: reviewItem.submittedAt }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 446,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 444,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-slate-400 block", children: "Module ID" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 449,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-800", children: reviewItem.recordId }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 450,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 448,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 439,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 420,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-slate-800 text-xs uppercase tracking-wider", children: "Submission Breakdown" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 457,
            columnNumber: 17
          }, this),
          reviewItem.details && /* @__PURE__ */ jsxDEV("div", { className: "bg-[#f8fafc] border border-slate-200 rounded-md p-3 space-y-1.5", children: Object.entries(reviewItem.details).map(
            ([key, val]) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-1 border-b border-slate-100 last:border-0", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 capitalize", children: [
                key.replace(/([A-Z])/g, " $1"),
                ":"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 464,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-slate-800", children: String(val) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 465,
                columnNumber: 25
              }, this)
            ] }, key, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 463,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 461,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 456,
          columnNumber: 15
        }, this),
        showCorrectionForm && /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50/70 border border-amber-200 rounded-md p-4 space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-amber-900 font-bold", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: isRejecting ? "block" : "edit_note" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 476,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: isRejecting ? "Rejection Reason (Mandatory)" : "Correction Feedback (Mandatory)" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 479,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 475,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-amber-800", children: "Provide precise instructions so the Cluster Admin knows exactly what needs to be revised before resubmitting." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 481,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              value: correctionReasonInput,
              onChange: (e) => setCorrectionReasonInput(e.target.value),
              placeholder: "e.g. Please update student attendance for row 4 and attach the clear fuel bill receipt...",
              rows: 3,
              className: "w-full bg-white border border-amber-300 rounded-md p-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#002869]"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 484,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowCorrectionForm(false),
                className: "px-3 py-1.5 rounded-md text-slate-600 hover:bg-slate-200 text-xs font-semibold cursor-pointer",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 492,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleSubmitCorrection,
                className: `px-4 py-1.5 rounded-md text-white text-xs font-bold transition-colors cursor-pointer shadow-xs ${isRejecting ? "bg-red-600 hover:bg-red-700" : "bg-amber-600 hover:bg-amber-700"}`,
                children: isRejecting ? "Confirm Rejection" : "Submit Correction Request"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 498,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 491,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 474,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 419,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              const targetTab = reviewItem.module === "Attendance" ? "attendance" : reviewItem.module === "Lesson Plan" ? "lesson-plan" : reviewItem.module === "Finance" ? "finance-statement" : "sessions";
              onNavigate(targetTab, reviewItem.recordId);
              setReviewItem(null);
            },
            className: "px-3 py-1.5 text-xs font-semibold text-[#002869] hover:bg-slate-200 rounded-md transition-colors flex items-center gap-1 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "open_in_new" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                lineNumber: 528,
                columnNumber: 17
              }, this),
              "Open in Full Module"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
            lineNumber: 513,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: !showCorrectionForm && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setIsRejecting(false);
                setShowCorrectionForm(true);
              },
              className: "bg-amber-500 hover:bg-amber-600 text-white px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer shadow-xs",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit_note" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 542,
                  columnNumber: 23
                }, this),
                "Request Correction"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 535,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleApproveConfirm,
              className: "bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-md text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shadow-xs",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "check_circle" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
                  lineNumber: 549,
                  columnNumber: 23
                }, this),
                "Approve Record"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
              lineNumber: 545,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 534,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
          lineNumber: 532,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
        lineNumber: 512,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 396,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
      lineNumber: 395,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx",
    lineNumber: 154,
    columnNumber: 5
  }, this);
};
_s(ApprovalCenterView, "pkH0lSj0avRIMZSDVu08a262Ck4=");
_c = ApprovalCenterView;
var _c;
$RefreshReg$(_c, "ApprovalCenterView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ApprovalCenterView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEpZLFNBdVhNLFVBdlhOOztBQTlKWixTQUFnQkEsVUFBVUMsZUFBZTtBQUV6QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxTQUFTQyxjQUFnRjtBQWNsRixhQUFNQyxxQkFBd0RBLENBQUM7QUFBQSxFQUNwRUMsWUFBWTtBQUFBLEVBQ1pDLFdBQVc7QUFBQSxFQUNYQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSWxCLFNBQWlCLEtBQUs7QUFDeEUsUUFBTSxDQUFDbUIsdUJBQXVCQyx3QkFBd0IsSUFBSXBCLFNBQWlCLEtBQUs7QUFDaEYsUUFBTSxDQUFDcUIsc0JBQXNCQyx1QkFBdUIsSUFBSXRCLFNBQWlCLFNBQVM7QUFDbEYsUUFBTSxDQUFDdUIsWUFBWUMsYUFBYSxJQUFJeEIsU0FBaUIsRUFBRTtBQUd2RCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUE4QixJQUFJO0FBQ3RFLFFBQU0sQ0FBQzJCLHVCQUF1QkMsd0JBQXdCLElBQUk1QixTQUFpQixFQUFFO0FBQzdFLFFBQU0sQ0FBQzZCLG9CQUFvQkMscUJBQXFCLElBQUk5QixTQUFrQixLQUFLO0FBQzNFLFFBQU0sQ0FBQytCLGFBQWFDLGNBQWMsSUFBSWhDLFNBQWtCLEtBQUs7QUFHN0QsUUFBTWlDLFlBQVloQyxRQUFRLE1BQU07QUFDOUIsVUFBTWlDLGNBQWN6QixVQUFVMEIsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLFNBQVM7QUFDbEUsV0FBTztBQUFBLE1BQ0xDLEtBQUtKLFlBQVlLO0FBQUFBLE1BQ2pCQyxZQUFZTixZQUFZQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVLLFdBQVcsWUFBWSxFQUFFRjtBQUFBQSxNQUNqRUcsWUFBWVIsWUFBWUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFSyxXQUFXLGFBQWEsRUFBRUY7QUFBQUEsTUFDbEVJLFNBQVNULFlBQVlDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUssV0FBVyxTQUFTLEVBQUVGO0FBQUFBLE1BQzNESyxVQUFVVixZQUFZQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVLLFdBQVcsVUFBVSxFQUFFRjtBQUFBQSxNQUM3RE0sYUFBYVgsWUFBWUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFSyxXQUFXLG9CQUFvQixFQUFFRjtBQUFBQSxJQUM1RTtBQUFBLEVBQ0YsR0FBRyxDQUFDOUIsU0FBUyxDQUFDO0FBR2QsUUFBTXFDLG9CQUFvQjdDLFFBQVEsTUFBTTtBQUN0QyxXQUFPUSxVQUFVMEIsT0FBTyxDQUFDWSxTQUFTO0FBRWhDLFVBQUk5QixzQkFBc0IsZ0JBQWdCOEIsS0FBS04sV0FBVyxhQUFjLFFBQU87QUFDL0UsVUFBSXhCLHNCQUFzQixnQkFBZ0I4QixLQUFLTixXQUFXLGNBQWUsUUFBTztBQUNoRixVQUFJeEIsc0JBQXNCLGFBQWE4QixLQUFLTixXQUFXLFVBQVcsUUFBTztBQUN6RSxVQUFJeEIsc0JBQXNCLGNBQWM4QixLQUFLTixXQUFXLFdBQVksUUFBTztBQUMzRSxVQUFJeEIsc0JBQXNCLGlCQUFpQjhCLEtBQUtOLFdBQVcscUJBQXNCLFFBQU87QUFHeEYsVUFBSXBCLHlCQUF5QixTQUFTMEIsS0FBS1YsV0FBV2hCLHFCQUFzQixRQUFPO0FBR25GLFVBQUlGLDBCQUEwQixPQUFPO0FBQ25DLGNBQU02QixTQUFTN0Isc0JBQXNCOEIsWUFBWTtBQUNqRCxZQUNFRixLQUFLRyxVQUFVRCxZQUFZLE1BQU1ELFVBQ2pDLENBQUNELEtBQUtJLFlBQVlGLFlBQVksRUFBRUcsU0FBU0osTUFBTSxHQUMvQztBQUNBLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFHQSxVQUFJekIsWUFBWTtBQUNkLGNBQU04QixJQUFJOUIsV0FBVzBCLFlBQVk7QUFDakMsZUFDRUYsS0FBS08sWUFBWUwsWUFBWSxFQUFFRyxTQUFTQyxDQUFDLEtBQ3pDTixLQUFLSSxZQUFZRixZQUFZLEVBQUVHLFNBQVNDLENBQUMsS0FDekNOLEtBQUtRLFlBQVlOLFlBQVksRUFBRUcsU0FBU0MsQ0FBQyxLQUN6Q04sS0FBS04sT0FBT1EsWUFBWSxFQUFFRyxTQUFTQyxDQUFDO0FBQUEsTUFFeEM7QUFFQSxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUM1QyxXQUFXUSxtQkFBbUJJLHNCQUFzQkYsdUJBQXVCSSxVQUFVLENBQUM7QUFFMUYsUUFBTWlDLG1CQUFtQkEsQ0FBQ1QsU0FBdUI7QUFDL0NyQixrQkFBY3FCLElBQUk7QUFDbEJuQiw2QkFBeUIsRUFBRTtBQUMzQkUsMEJBQXNCLEtBQUs7QUFDM0JFLG1CQUFlLEtBQUs7QUFBQSxFQUN0QjtBQUVBLFFBQU15Qix1QkFBdUJBLE1BQU07QUFDakMsUUFBSSxDQUFDaEMsV0FBWTtBQUNqQmIsY0FBVWEsV0FBV2lDLElBQUlqQyxXQUFXZ0IsUUFBUWhCLFdBQVdrQyxRQUFRO0FBQy9EakMsa0JBQWMsSUFBSTtBQUFBLEVBQ3BCO0FBRUEsUUFBTWtDLHlCQUF5QkEsTUFBTTtBQUNuQyxRQUFJLENBQUNuQyxXQUFZO0FBQ2pCLFFBQUksQ0FBQ0Usc0JBQXNCa0MsS0FBSyxHQUFHO0FBQ2pDQyxZQUFNLDJFQUEyRTtBQUNqRjtBQUFBLElBQ0Y7QUFDQSxRQUFJL0IsYUFBYTtBQUNmakIsZUFBU1csV0FBV2lDLElBQUlqQyxXQUFXZ0IsUUFBUWhCLFdBQVdrQyxVQUFVaEMsc0JBQXNCa0MsS0FBSyxDQUFDO0FBQUEsSUFDOUYsT0FBTztBQUNMaEQsMEJBQW9CWSxXQUFXaUMsSUFBSWpDLFdBQVdnQixRQUFRaEIsV0FBV2tDLFVBQVVoQyxzQkFBc0JrQyxLQUFLLENBQUM7QUFBQSxJQUN6RztBQUNBbkMsa0JBQWMsSUFBSTtBQUFBLEVBQ3BCO0FBRUEsUUFBTXFDLHNCQUFzQkEsQ0FBQ3RCLFdBQW1CO0FBQzlDLFlBQVFBLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFFBQU11QixnQkFBZ0JBLENBQUN2QixXQUFtQjtBQUN4QyxZQUFRQSxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1Q7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsZ0VBQStELCtCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ1IsVUFBVUssTUFBTSxLQUNmLHVCQUFDLFVBQUssV0FBVSw4RUFDYkw7QUFBQUEsc0JBQVVLO0FBQUFBLFlBQUk7QUFBQSxlQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSx3Q0FBdUMsbUdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1o7QUFBQSxRQUNDLEVBQUUyQixPQUFPLGNBQWNDLEtBQUtqQyxVQUFVTyxXQUFXO0FBQUEsUUFDakQsRUFBRXlCLE9BQU8sZ0JBQWdCQyxLQUFLakMsVUFBVVMsV0FBVztBQUFBLFFBQ25ELEVBQUV1QixPQUFPLGtCQUFrQkMsS0FBS2pDLFVBQVVVLFFBQVE7QUFBQSxNQUFDLEVBQ25Ed0I7QUFBQUEsUUFBSSxDQUFDQyxNQUNMLHVCQUFDLFNBQWtCLFdBQVUsZUFDM0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkRBQTZEQSxZQUFFSCxTQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLFVBQ3BGLHVCQUFDLFNBQUksV0FBVSxxQ0FBcUNHLFlBQUVGLE9BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsYUFGbERFLEVBQUVILE9BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsTUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx5RkFDWjtBQUFBLE1BQ0MsRUFBRVAsSUFBSSxPQUFPTyxPQUFPLGFBQWFJLE9BQU9wQyxVQUFVSyxJQUFJO0FBQUEsTUFDdEQsRUFBRW9CLElBQUksY0FBY08sT0FBTyxjQUFjSSxPQUFPcEMsVUFBVU8sV0FBVztBQUFBLE1BQ3JFLEVBQUVrQixJQUFJLGNBQWNPLE9BQU8sZ0JBQWdCSSxPQUFPcEMsVUFBVVMsV0FBVztBQUFBLE1BQ3ZFLEVBQUVnQixJQUFJLFdBQVdPLE9BQU8sa0JBQWtCSSxPQUFPcEMsVUFBVVUsUUFBUTtBQUFBLE1BQ25FLEVBQUVlLElBQUksZUFBZU8sT0FBTyx1QkFBdUJJLE9BQU9wQyxVQUFVWSxZQUFZO0FBQUEsSUFBQyxFQUNqRnNCLElBQUksQ0FBQ0csUUFBUTtBQUNiLFlBQU1DLFdBQVd0RCxzQkFBc0JxRCxJQUFJWjtBQUMzQyxhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU14QyxxQkFBcUJvRCxJQUFJWixFQUFFO0FBQUEsVUFDMUMsV0FBVyxxREFDVGEsV0FDSSxrQ0FDQSw2Q0FBNkM7QUFBQSxVQUduRDtBQUFBLG1DQUFDLFVBQUssV0FBVSwyQkFDZDtBQUFBLHFDQUFDLFVBQU1ELGNBQUlMLFNBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUNoQkssSUFBSUQsUUFBUSxLQUNYLHVCQUFDLFVBQUssV0FBVyxlQUFlRSxXQUFXLDhCQUE4Qix1QkFBdUIsSUFBSTtBQUFBO0FBQUEsZ0JBQ2hHRCxJQUFJRDtBQUFBQSxnQkFBTTtBQUFBLG1CQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQ0UsWUFDQyx1QkFBQyxVQUFLLFdBQVUsMERBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUE7QUFBQTtBQUFBLFFBbEJuRUQsSUFBSVo7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BcUJBO0FBQUEsSUFFSixDQUFDLEtBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwREFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSx5QkFBd0Isd0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDaEQsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU92Qyx5QkFBeUI7QUFBQSxjQUNoQyxlQUFlLENBQUMrQyxRQUFROUMseUJBQXlCOEMsR0FBRztBQUFBLGNBRXBEO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSxlQUN2QixpQ0FBQyxlQUFZLGFBQVksa0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxpQkFDQztBQUFBLHlDQUFDLGNBQVcsT0FBTSxPQUFNLHlDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRDtBQUFBLGtCQUNoRHhELFNBQVN5RDtBQUFBQSxvQkFBSSxDQUFDSyxNQUNiLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUVkLElBQzdCYyxZQUFFQyxRQURZRCxFQUFFZCxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQSxxQkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUE7QUFBQTtBQUFBLFlBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUseUJBQXdCLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQztBQUFBLFVBQy9DLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPckMsd0JBQXdCO0FBQUEsY0FDL0IsZUFBZSxDQUFDNkMsUUFBUTVDLHdCQUF3QjRDLEdBQUc7QUFBQSxjQUVuRDtBQUFBLHVDQUFDLGlCQUFjLFdBQVUsZUFDdkIsaUNBQUMsZUFBWSxhQUFZLGtCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSx5Q0FBQyxjQUFXLE9BQU0sT0FBTSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0M7QUFBQSxrQkFDcEMsdUJBQUMsY0FBVyxPQUFNLFdBQVUsOEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUEsa0JBQzFDLHVCQUFDLGNBQVcsT0FBTSxZQUFXLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQztBQUFBLGtCQUNyQyx1QkFBQyxjQUFXLE9BQU0sd0JBQXVCLG9DQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLGtCQUM3RCx1QkFBQyxjQUFXLE9BQU0sWUFBVyx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUM7QUFBQSxxQkFMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBO0FBQUE7QUFBQSxZQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsV0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsK0JBQUMsVUFBTyxXQUFVLHlEQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLE9BQU8zQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ21ELE1BQU1sRCxjQUFja0QsRUFBRUMsT0FBT0MsS0FBSztBQUFBLFlBQzdDLFdBQVU7QUFBQTtBQUFBLFVBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSytRO0FBQUEsV0FQalI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiLGlDQUFDLFdBQU0sV0FBVSw0Q0FDZjtBQUFBLDZCQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLGlFQUNaO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGVBQWMsc0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxRQUFHLFdBQVUsZUFBYyx1QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLFFBQUcsV0FBVSxlQUFjLGtDQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsUUFBRyxXQUFVLGVBQWMsNEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBVSxlQUFjLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsUUFBRyxXQUFVLDBCQUF5Qix1QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFdBUGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLDZCQUNaOUIsNEJBQWtCUCxXQUFXLElBQzVCLHVCQUFDLFFBQ0MsaUNBQUMsUUFBRyxTQUFTLEdBQUcsV0FBVSxvQ0FDeEI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsbUVBQWtFLDRCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsMENBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGdFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBGO0FBQUEsV0FMNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLElBRUFPLGtCQUFrQnFCO0FBQUFBLFFBQUksQ0FBQ3BCLFNBQ3JCLHVCQUFDLFFBQWlCLFdBQVUsMENBQzFCO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGlDQUNaO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLHdGQUF3RmdCO0FBQUFBLGdCQUNqR2hCLEtBQUtOO0FBQUFBLGNBQ1AsQ0FBQztBQUFBLGNBRUQ7QUFBQSx1Q0FBQyxVQUFLLFdBQVUseUNBQ2J1Qix3QkFBY2pCLEtBQUtOLE1BQU0sS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDTSxLQUFLTjtBQUFBQTtBQUFBQTtBQUFBQSxZQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLDREQUNaLGlDQUFDLFVBQUssV0FBVSxrQ0FDZDtBQUFBLG1DQUFDLFVBQUssV0FBVSx1Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNuRE0sS0FBS0k7QUFBQUEsZUFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLDBEQUNaO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFlBQVcsT0FBT0osS0FBS08sYUFDbkNQLGVBQUtPLGVBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0NQLEtBQUs4QixXQUNKLHVCQUFDLFNBQUksV0FBVSwwREFDWjlCO0FBQUFBLG1CQUFLTixXQUFXLGdCQUFnQixHQUFHTSxLQUFLOEIsUUFBUUMsZ0JBQWdCLENBQUMsY0FBYy9CLEtBQUs4QixRQUFRRSxjQUFjLENBQUMsY0FBY2hDLEtBQUs4QixRQUFRRyxlQUFlLEVBQUU7QUFBQSxjQUN2SmpDLEtBQUtOLFdBQVcsaUJBQWlCLEdBQUdNLEtBQUs4QixRQUFRSSxZQUFZLFNBQVMsTUFBTWxDLEtBQUs4QixRQUFRSyxrQkFBa0IsYUFBYTtBQUFBLGNBQ3hIbkMsS0FBS04sV0FBVyxhQUFhLE9BQU9NLEtBQUs4QixRQUFRTSxlQUFlLENBQUMsWUFBWXBDLEtBQUs4QixRQUFRTyxZQUFZLE9BQU87QUFBQSxjQUM3R3JDLEtBQUtOLFdBQVcsd0JBQXdCLFdBQVdNLEtBQUs4QixRQUFRUSxVQUFVLEVBQUU7QUFBQSxpQkFKL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLGdEQUNYdEMsZUFBS1EsZUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsNERBQ1hSLGVBQUt1QyxlQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSxpQ0FDWjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyxpRUFDVHZDLEtBQUtWLFdBQVcsYUFDWixvQ0FDQVUsS0FBS1YsV0FBVyxZQUNoQiw4Q0FDQVUsS0FBS1YsV0FBVyx5QkFDaEIsa0NBQ0EseUJBQXlCO0FBQUEsY0FHOUJVLGVBQUtWO0FBQUFBO0FBQUFBLFlBWFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsNENBQ1osaUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1tQixpQkFBaUJULElBQUk7QUFBQSxnQkFDcEMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsVUFBSyxXQUFVLHlDQUF3QywwQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0U7QUFBQSxrQkFBTztBQUFBO0FBQUE7QUFBQSxjQUozRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0NBLEtBQUtWLFdBQVcsYUFDZjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTXpCLFVBQVVtQyxLQUFLVyxJQUFJWCxLQUFLTixRQUFRTSxLQUFLWSxRQUFRO0FBQUEsZ0JBQzVELFdBQVU7QUFBQSxnQkFDVixPQUFNO0FBQUEsZ0JBRU47QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2RDtBQUFBLGtCQUFPO0FBQUE7QUFBQTtBQUFBLGNBTHRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxhQXpFT1osS0FBS1csSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEVBO0FBQUEsTUFDRCxLQXhGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEZFO0FBQUEsU0F0R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVHRSxLQXhHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUdFO0FBQUEsSUFHRGpDLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSxxSEFFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSx5Q0FDYnVDLHdCQUFjdkMsV0FBV2dCLE1BQU0sS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx1QkFBc0I7QUFBQTtBQUFBLGNBQW9CaEIsV0FBV2dCO0FBQUFBLGlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLE9BQUUsV0FBVSw4QkFDVmhCO0FBQUFBLHlCQUFXMEI7QUFBQUEsY0FBWTtBQUFBLGNBQWlCMUIsV0FBVzhCO0FBQUFBLGlCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU03QixjQUFjLElBQUk7QUFBQSxZQUNqQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsVUFBSyxXQUFVLHVFQUFzRSw0QkFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLG9DQUFvQ0QscUJBQVc2QixlQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RTtBQUFBLGlCQUoxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsb0RBQ1Q3QixXQUFXWSxXQUFXLGFBQ2xCLG9DQUNBLDZCQUE2QjtBQUFBLGdCQUdsQ1oscUJBQVdZO0FBQUFBO0FBQUFBLGNBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsVUFBSyxXQUFVLG9DQUFtQyx1QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUMxRCx1QkFBQyxVQUFLLFdBQVUsZ0NBQWdDWixxQkFBVzBCLGVBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsaUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsb0NBQW1DLCtCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRTtBQUFBLGNBQ2xFLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0MxQixxQkFBVzZELGVBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsaUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsb0NBQW1DLHlCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQzVELHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0M3RCxxQkFBV2tDLFlBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsaUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw2REFBNEQsb0NBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDbEMsV0FBV29ELFdBQ1YsdUJBQUMsU0FBSSxXQUFVLG1FQUNaVSxpQkFBT0MsUUFBUS9ELFdBQVdvRCxPQUFPLEVBQUVWO0FBQUFBLFlBQUksQ0FBQyxDQUFDc0IsS0FBS3ZCLEdBQUcsTUFDaEQsdUJBQUMsU0FBYyxXQUFVLGtGQUN2QjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNkJ1QjtBQUFBQSxvQkFBSUMsUUFBUSxZQUFZLEtBQUs7QUFBQSxnQkFBRTtBQUFBLG1CQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFLHVCQUFDLFVBQUssV0FBVSxnQ0FBZ0NDLGlCQUFPekIsR0FBRyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGlCQUZwRHVCLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFVBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUdDNUQsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlDQUNiRSx3QkFBYyxVQUFVLGVBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQU1BLHdCQUFjLGlDQUFpQyxxQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxlQUoxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDZIQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT0o7QUFBQUEsY0FDUCxVQUFVLENBQUMrQyxNQUFNOUMseUJBQXlCOEMsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGNBQ3hELGFBQVk7QUFBQSxjQUNaLE1BQU07QUFBQSxjQUNOLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS3VJO0FBQUEsVUFFdkksdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU05QyxzQkFBc0IsS0FBSztBQUFBLGdCQUMxQyxXQUFVO0FBQUEsZ0JBQStGO0FBQUE7QUFBQSxjQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTOEI7QUFBQUEsZ0JBQ1QsV0FBVyxrR0FDVDdCLGNBQWMsZ0NBQWdDLGlDQUFpQztBQUFBLGdCQUdoRkEsd0JBQWMsc0JBQXNCO0FBQUE7QUFBQSxjQU52QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQTtBQUFBLGFBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0E7QUFBQSxXQXhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEZBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2Isb0JBQU02RCxZQUNKbkUsV0FBV2dCLFdBQVcsZUFDbEIsZUFDQWhCLFdBQVdnQixXQUFXLGdCQUN0QixnQkFDQWhCLFdBQVdnQixXQUFXLFlBQ3RCLHNCQUNBO0FBQ04xQix5QkFBVzZFLFdBQVduRSxXQUFXa0MsUUFBUTtBQUN6Q2pDLDRCQUFjLElBQUk7QUFBQSxZQUNwQjtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDJCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQU87QUFBQTtBQUFBO0FBQUEsVUFmNUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBaUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1osV0FBQ0csc0JBQ0EsbUNBQ0U7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JHLCtCQUFlLEtBQUs7QUFDcEJGLHNDQUFzQixJQUFJO0FBQUEsY0FDNUI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHlDQUF3Qyx5QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUU7QUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQVAxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMyQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHlDQUF3Qyw0QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0U7QUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQUo3RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkEsS0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxTQS9KRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0tBLEtBaktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrS0E7QUFBQSxPQW5aSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcVpBO0FBRUo7QUFBRXpDLEdBemhCV1Isb0JBQXFEO0FBQUEsS0FBckRBO0FBQXFELElBQUFxRjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIlNlYXJjaCIsIkFwcHJvdmFsQ2VudGVyVmlldyIsImFwcHJvdmFscyIsImNsdXN0ZXJzIiwidXNlclJvbGUiLCJvbkFwcHJvdmUiLCJvblJlcXVlc3RDb3JyZWN0aW9uIiwib25SZWplY3QiLCJvbk5hdmlnYXRlIiwiX3MiLCJzZWxlY3RlZE1vZHVsZVRhYiIsInNldFNlbGVjdGVkTW9kdWxlVGFiIiwic2VsZWN0ZWRDbHVzdGVyRmlsdGVyIiwic2V0U2VsZWN0ZWRDbHVzdGVyRmlsdGVyIiwic2VsZWN0ZWRTdGF0dXNGaWx0ZXIiLCJzZXRTZWxlY3RlZFN0YXR1c0ZpbHRlciIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwicmV2aWV3SXRlbSIsInNldFJldmlld0l0ZW0iLCJjb3JyZWN0aW9uUmVhc29uSW5wdXQiLCJzZXRDb3JyZWN0aW9uUmVhc29uSW5wdXQiLCJzaG93Q29ycmVjdGlvbkZvcm0iLCJzZXRTaG93Q29ycmVjdGlvbkZvcm0iLCJpc1JlamVjdGluZyIsInNldElzUmVqZWN0aW5nIiwidGFiQ291bnRzIiwicGVuZGluZ09ubHkiLCJmaWx0ZXIiLCJhIiwic3RhdHVzIiwiYWxsIiwibGVuZ3RoIiwiYXR0ZW5kYW5jZSIsIm1vZHVsZSIsImxlc3NvblBsYW4iLCJmaW5hbmNlIiwic2Vzc2lvbnMiLCJjb3JyZWN0aW9ucyIsImZpbHRlcmVkQXBwcm92YWxzIiwiaXRlbSIsImNMb3dlciIsInRvTG93ZXJDYXNlIiwiY2x1c3RlcklkIiwiY2x1c3Rlck5hbWUiLCJpbmNsdWRlcyIsInEiLCJyZWNvcmRUaXRsZSIsInN1Ym1pdHRlZEJ5IiwiaGFuZGxlT3BlblJldmlldyIsImhhbmRsZUFwcHJvdmVDb25maXJtIiwiaWQiLCJyZWNvcmRJZCIsImhhbmRsZVN1Ym1pdENvcnJlY3Rpb24iLCJ0cmltIiwiYWxlcnQiLCJnZXRNb2R1bGVCYWRnZUNvbG9yIiwiZ2V0TW9kdWxlSWNvbiIsImxhYmVsIiwidmFsIiwibWFwIiwicyIsImNvdW50IiwidGFiIiwiaXNBY3RpdmUiLCJjIiwibmFtZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImRldGFpbHMiLCJwcmVzZW50Q291bnQiLCJ0b3RhbENvdW50IiwidmlsbGFnZU5hbWUiLCJkdXJhdGlvbiIsInRhcmdldFN0YW5kYXJkIiwidG90YWxBbW91bnQiLCJzcG9jTmFtZSIsInJlYXNvbiIsInN1Ym1pdHRlZEF0IiwiT2JqZWN0IiwiZW50cmllcyIsImtleSIsInJlcGxhY2UiLCJTdHJpbmciLCJ0YXJnZXRUYWIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHByb3ZhbENlbnRlclZpZXcudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQXBwcm92YWxJdGVtLCBUYWJUeXBlLCBDbHVzdGVyIH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBTZWxlY3RDb250ZW50LFxyXG4gIFNlbGVjdEl0ZW0sXHJcbiAgU2VsZWN0VHJpZ2dlcixcclxuICBTZWxlY3RWYWx1ZSxcclxufSBmcm9tICcuL3VpL3NlbGVjdCc7XHJcbmltcG9ydCB7IFNlYXJjaCwgQ2hlY2tDaXJjbGUyLCBBbGVydENpcmNsZSwgWENpcmNsZSwgQ2xvY2ssIEV5ZSwgQ2hlY2ssIFJlZnJlc2hDdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcbmltcG9ydCB7IEFjdGlvbkJ1dHRvbiB9IGZyb20gJy4vdWkvYWN0aW9uLWJ1dHRvbic7XHJcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnLi91aS9iYWRnZSc7XHJcblxyXG5pbnRlcmZhY2UgQXBwcm92YWxDZW50ZXJWaWV3UHJvcHMge1xyXG4gIGFwcHJvdmFsczogQXBwcm92YWxJdGVtW107XHJcbiAgY2x1c3RlcnM6IENsdXN0ZXJbXTtcclxuICB1c2VyUm9sZTogJ1N1cGVyIEFkbWluJyB8ICdDbHVzdGVyIEFkbWluJztcclxuICBvbkFwcHJvdmU6IChpZDogc3RyaW5nLCBtb2R1bGU6IHN0cmluZywgcmVjb3JkSWQ6IHN0cmluZykgPT4gdm9pZDtcclxuICBvblJlcXVlc3RDb3JyZWN0aW9uOiAoaWQ6IHN0cmluZywgbW9kdWxlOiBzdHJpbmcsIHJlY29yZElkOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIG9uUmVqZWN0OiAoaWQ6IHN0cmluZywgbW9kdWxlOiBzdHJpbmcsIHJlY29yZElkOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgQXBwcm92YWxDZW50ZXJWaWV3OiBSZWFjdC5GQzxBcHByb3ZhbENlbnRlclZpZXdQcm9wcz4gPSAoe1xyXG4gIGFwcHJvdmFscyA9IFtdLFxyXG4gIGNsdXN0ZXJzID0gW10sXHJcbiAgdXNlclJvbGUsXHJcbiAgb25BcHByb3ZlLFxyXG4gIG9uUmVxdWVzdENvcnJlY3Rpb24sXHJcbiAgb25SZWplY3QsXHJcbiAgb25OYXZpZ2F0ZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1vZHVsZVRhYiwgc2V0U2VsZWN0ZWRNb2R1bGVUYWJdID0gdXNlU3RhdGU8c3RyaW5nPignYWxsJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ2x1c3RlckZpbHRlciwgc2V0U2VsZWN0ZWRDbHVzdGVyRmlsdGVyXSA9IHVzZVN0YXRlPHN0cmluZz4oJ2FsbCcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFN0YXR1c0ZpbHRlciwgc2V0U2VsZWN0ZWRTdGF0dXNGaWx0ZXJdID0gdXNlU3RhdGU8c3RyaW5nPignUGVuZGluZycpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xyXG5cclxuICAvLyBBY3RpdmUgUmV2aWV3IEl0ZW0gTW9kYWxcclxuICBjb25zdCBbcmV2aWV3SXRlbSwgc2V0UmV2aWV3SXRlbV0gPSB1c2VTdGF0ZTxBcHByb3ZhbEl0ZW0gfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbY29ycmVjdGlvblJlYXNvbklucHV0LCBzZXRDb3JyZWN0aW9uUmVhc29uSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XHJcbiAgY29uc3QgW3Nob3dDb3JyZWN0aW9uRm9ybSwgc2V0U2hvd0NvcnJlY3Rpb25Gb3JtXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcclxuICBjb25zdCBbaXNSZWplY3RpbmcsIHNldElzUmVqZWN0aW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcclxuXHJcbiAgLy8gQ291bnRzIGZvciB0YWJzXHJcbiAgY29uc3QgdGFiQ291bnRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBwZW5kaW5nT25seSA9IGFwcHJvdmFscy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSAnUGVuZGluZycpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgYWxsOiBwZW5kaW5nT25seS5sZW5ndGgsXHJcbiAgICAgIGF0dGVuZGFuY2U6IHBlbmRpbmdPbmx5LmZpbHRlcigoYSkgPT4gYS5tb2R1bGUgPT09ICdBdHRlbmRhbmNlJykubGVuZ3RoLFxyXG4gICAgICBsZXNzb25QbGFuOiBwZW5kaW5nT25seS5maWx0ZXIoKGEpID0+IGEubW9kdWxlID09PSAnTGVzc29uIFBsYW4nKS5sZW5ndGgsXHJcbiAgICAgIGZpbmFuY2U6IHBlbmRpbmdPbmx5LmZpbHRlcigoYSkgPT4gYS5tb2R1bGUgPT09ICdGaW5hbmNlJykubGVuZ3RoLFxyXG4gICAgICBzZXNzaW9uczogcGVuZGluZ09ubHkuZmlsdGVyKChhKSA9PiBhLm1vZHVsZSA9PT0gJ1Nlc3Npb25zJykubGVuZ3RoLFxyXG4gICAgICBjb3JyZWN0aW9uczogcGVuZGluZ09ubHkuZmlsdGVyKChhKSA9PiBhLm1vZHVsZSA9PT0gJ0NvcnJlY3Rpb24gUmVxdWVzdCcpLmxlbmd0aCxcclxuICAgIH07XHJcbiAgfSwgW2FwcHJvdmFsc10pO1xyXG5cclxuICAvLyBGaWx0ZXJlZCBhcHByb3ZhbHNcclxuICBjb25zdCBmaWx0ZXJlZEFwcHJvdmFscyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGFwcHJvdmFscy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgLy8gTW9kdWxlIHRhYiBmaWx0ZXJcclxuICAgICAgaWYgKHNlbGVjdGVkTW9kdWxlVGFiID09PSAnYXR0ZW5kYW5jZScgJiYgaXRlbS5tb2R1bGUgIT09ICdBdHRlbmRhbmNlJykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRNb2R1bGVUYWIgPT09ICdsZXNzb25QbGFuJyAmJiBpdGVtLm1vZHVsZSAhPT0gJ0xlc3NvbiBQbGFuJykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRNb2R1bGVUYWIgPT09ICdmaW5hbmNlJyAmJiBpdGVtLm1vZHVsZSAhPT0gJ0ZpbmFuY2UnKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgIGlmIChzZWxlY3RlZE1vZHVsZVRhYiA9PT0gJ3Nlc3Npb25zJyAmJiBpdGVtLm1vZHVsZSAhPT0gJ1Nlc3Npb25zJykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICBpZiAoc2VsZWN0ZWRNb2R1bGVUYWIgPT09ICdjb3JyZWN0aW9ucycgJiYgaXRlbS5tb2R1bGUgIT09ICdDb3JyZWN0aW9uIFJlcXVlc3QnKSByZXR1cm4gZmFsc2U7XHJcblxyXG4gICAgICAvLyBTdGF0dXMgZmlsdGVyXHJcbiAgICAgIGlmIChzZWxlY3RlZFN0YXR1c0ZpbHRlciAhPT0gJ2FsbCcgJiYgaXRlbS5zdGF0dXMgIT09IHNlbGVjdGVkU3RhdHVzRmlsdGVyKSByZXR1cm4gZmFsc2U7XHJcblxyXG4gICAgICAvLyBDbHVzdGVyIGZpbHRlclxyXG4gICAgICBpZiAoc2VsZWN0ZWRDbHVzdGVyRmlsdGVyICE9PSAnYWxsJykge1xyXG4gICAgICAgIGNvbnN0IGNMb3dlciA9IHNlbGVjdGVkQ2x1c3RlckZpbHRlci50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgIGl0ZW0uY2x1c3RlcklkLnRvTG93ZXJDYXNlKCkgIT09IGNMb3dlciAmJlxyXG4gICAgICAgICAgIWl0ZW0uY2x1c3Rlck5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhjTG93ZXIpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBTZWFyY2ggdGVybVxyXG4gICAgICBpZiAoc2VhcmNoVGVybSkge1xyXG4gICAgICAgIGNvbnN0IHEgPSBzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIGl0ZW0ucmVjb3JkVGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxKSB8fFxyXG4gICAgICAgICAgaXRlbS5jbHVzdGVyTmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHEpIHx8XHJcbiAgICAgICAgICBpdGVtLnN1Ym1pdHRlZEJ5LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSkgfHxcclxuICAgICAgICAgIGl0ZW0ubW9kdWxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocSlcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0pO1xyXG4gIH0sIFthcHByb3ZhbHMsIHNlbGVjdGVkTW9kdWxlVGFiLCBzZWxlY3RlZFN0YXR1c0ZpbHRlciwgc2VsZWN0ZWRDbHVzdGVyRmlsdGVyLCBzZWFyY2hUZXJtXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5SZXZpZXcgPSAoaXRlbTogQXBwcm92YWxJdGVtKSA9PiB7XHJcbiAgICBzZXRSZXZpZXdJdGVtKGl0ZW0pO1xyXG4gICAgc2V0Q29ycmVjdGlvblJlYXNvbklucHV0KCcnKTtcclxuICAgIHNldFNob3dDb3JyZWN0aW9uRm9ybShmYWxzZSk7XHJcbiAgICBzZXRJc1JlamVjdGluZyhmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQXBwcm92ZUNvbmZpcm0gPSAoKSA9PiB7XHJcbiAgICBpZiAoIXJldmlld0l0ZW0pIHJldHVybjtcclxuICAgIG9uQXBwcm92ZShyZXZpZXdJdGVtLmlkLCByZXZpZXdJdGVtLm1vZHVsZSwgcmV2aWV3SXRlbS5yZWNvcmRJZCk7XHJcbiAgICBzZXRSZXZpZXdJdGVtKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdENvcnJlY3Rpb24gPSAoKSA9PiB7XHJcbiAgICBpZiAoIXJldmlld0l0ZW0pIHJldHVybjtcclxuICAgIGlmICghY29ycmVjdGlvblJlYXNvbklucHV0LnRyaW0oKSkge1xyXG4gICAgICBhbGVydCgnUGxlYXNlIGVudGVyIGEgc3BlY2lmaWMgcmVhc29uIGZvciByZXF1ZXN0aW5nIGNvcnJlY3Rpb24gb3IgcmVzdWJtaXNzaW9uLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoaXNSZWplY3RpbmcpIHtcclxuICAgICAgb25SZWplY3QocmV2aWV3SXRlbS5pZCwgcmV2aWV3SXRlbS5tb2R1bGUsIHJldmlld0l0ZW0ucmVjb3JkSWQsIGNvcnJlY3Rpb25SZWFzb25JbnB1dC50cmltKCkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgb25SZXF1ZXN0Q29ycmVjdGlvbihyZXZpZXdJdGVtLmlkLCByZXZpZXdJdGVtLm1vZHVsZSwgcmV2aWV3SXRlbS5yZWNvcmRJZCwgY29ycmVjdGlvblJlYXNvbklucHV0LnRyaW0oKSk7XHJcbiAgICB9XHJcbiAgICBzZXRSZXZpZXdJdGVtKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldE1vZHVsZUJhZGdlQ29sb3IgPSAobW9kdWxlOiBzdHJpbmcpID0+IHtcclxuICAgIHN3aXRjaCAobW9kdWxlKSB7XHJcbiAgICAgIGNhc2UgJ0F0dGVuZGFuY2UnOlxyXG4gICAgICAgIHJldHVybiAnYmctYmx1ZS01MCB0ZXh0LVsjMDAyODY5XSBib3JkZXItYmx1ZS0yMDAnO1xyXG4gICAgICBjYXNlICdMZXNzb24gUGxhbic6XHJcbiAgICAgICAgcmV0dXJuICdiZy1wdXJwbGUtNTAgdGV4dC1wdXJwbGUtODAwIGJvcmRlci1wdXJwbGUtMjAwJztcclxuICAgICAgY2FzZSAnRmluYW5jZSc6XHJcbiAgICAgICAgcmV0dXJuICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTkwMCBib3JkZXItYW1iZXItMjAwJztcclxuICAgICAgY2FzZSAnQ29ycmVjdGlvbiBSZXF1ZXN0JzpcclxuICAgICAgICByZXR1cm4gJ2JnLW9yYW5nZS01MCB0ZXh0LW9yYW5nZS05MDAgYm9yZGVyLW9yYW5nZS0yMDAnO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAnYmctc2xhdGUtNTAgdGV4dC1zbGF0ZS04MDAgYm9yZGVyLXNsYXRlLTIwMCc7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0TW9kdWxlSWNvbiA9IChtb2R1bGU6IHN0cmluZykgPT4ge1xyXG4gICAgc3dpdGNoIChtb2R1bGUpIHtcclxuICAgICAgY2FzZSAnQXR0ZW5kYW5jZSc6XHJcbiAgICAgICAgcmV0dXJuICdob3dfdG9fcmVnJztcclxuICAgICAgY2FzZSAnTGVzc29uIFBsYW4nOlxyXG4gICAgICAgIHJldHVybiAnbWVudV9ib29rJztcclxuICAgICAgY2FzZSAnRmluYW5jZSc6XHJcbiAgICAgICAgcmV0dXJuICdwYXltZW50cyc7XHJcbiAgICAgIGNhc2UgJ0NvcnJlY3Rpb24gUmVxdWVzdCc6XHJcbiAgICAgICAgcmV0dXJuICdlZGl0X25vdGUnO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiAndmVyaWZpZWQnO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTZcIj5cclxuICAgICAgey8qIFBhZ2UgaGVhZGVyICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBib3JkZXItYiBib3JkZXItYm9yZGVyLzUwIHBiLTVcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kIHNtOnRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAgQXBwcm92YWwgQ2VudGVyXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIHt0YWJDb3VudHMuYWxsID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJnLWFtYmVyLTEwMCBweC0yIHB5LTAuNSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1hbWJlci04MDBcIj5cclxuICAgICAgICAgICAgICAgIHt0YWJDb3VudHMuYWxsfSBwZW5kaW5nXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgUmV2aWV3IGFuZCBhY3Rpb24gYXR0ZW5kYW5jZSwgbGVzc29uIHBsYW5zLCBmaW5hbmNlIGNsYWltcyBhbmQgY29ycmVjdGlvbiByZXF1ZXN0cy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02IHRleHQteHNcIj5cclxuICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgIHsgbGFiZWw6ICdBdHRlbmRhbmNlJywgdmFsOiB0YWJDb3VudHMuYXR0ZW5kYW5jZSB9LFxyXG4gICAgICAgICAgICB7IGxhYmVsOiAnTGVzc29uIHBsYW5zJywgdmFsOiB0YWJDb3VudHMubGVzc29uUGxhbiB9LFxyXG4gICAgICAgICAgICB7IGxhYmVsOiAnRmluYW5jZSBjbGFpbXMnLCB2YWw6IHRhYkNvdW50cy5maW5hbmNlIH0sXHJcbiAgICAgICAgICBdLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17cy5sYWJlbH0gY2xhc3NOYW1lPVwic3BhY2UteS0wLjVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntzLmxhYmVsfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3MudmFsfTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBNb2R1bGUgTmF2aWdhdGlvbiBUYWJzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02IGJvcmRlci1iIGJvcmRlci1ib3JkZXIvNDAgdGV4dC14cyBmb250LW1lZGl1bSBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICB7W1xyXG4gICAgICAgICAgeyBpZDogJ2FsbCcsIGxhYmVsOiAnQWxsIEl0ZW1zJywgY291bnQ6IHRhYkNvdW50cy5hbGwgfSxcclxuICAgICAgICAgIHsgaWQ6ICdhdHRlbmRhbmNlJywgbGFiZWw6ICdBdHRlbmRhbmNlJywgY291bnQ6IHRhYkNvdW50cy5hdHRlbmRhbmNlIH0sXHJcbiAgICAgICAgICB7IGlkOiAnbGVzc29uUGxhbicsIGxhYmVsOiAnTGVzc29uIFBsYW5zJywgY291bnQ6IHRhYkNvdW50cy5sZXNzb25QbGFuIH0sXHJcbiAgICAgICAgICB7IGlkOiAnZmluYW5jZScsIGxhYmVsOiAnRmluYW5jZSBDbGFpbXMnLCBjb3VudDogdGFiQ291bnRzLmZpbmFuY2UgfSxcclxuICAgICAgICAgIHsgaWQ6ICdjb3JyZWN0aW9ucycsIGxhYmVsOiAnQ29ycmVjdGlvbiBSZXF1ZXN0cycsIGNvdW50OiB0YWJDb3VudHMuY29ycmVjdGlvbnMgfSxcclxuICAgICAgICBdLm1hcCgodGFiKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IHNlbGVjdGVkTW9kdWxlVGFiID09PSB0YWIuaWQ7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAga2V5PXt0YWIuaWR9XHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRNb2R1bGVUYWIodGFiLmlkKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBwYi0zIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbiAgICAgICAgICAgICAgICBpc0FjdGl2ZSBcclxuICAgICAgICAgICAgICAgICAgPyAndGV4dC1mb3JlZ3JvdW5kIGZvbnQtc2VtaWJvbGQnIFxyXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kJ1xyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge3RhYi5jb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSAke2lzQWN0aXZlID8gJ3RleHQtZm9yZWdyb3VuZCBmb250LWJvbGQnIDogJ3RleHQtbXV0ZWQtZm9yZWdyb3VuZCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgKHt0YWIuY291bnR9KVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICB7aXNBY3RpdmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHJpZ2h0LTAgaC0wLjUgYmctZm9yZWdyb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBGaWx0ZXIgJiBTZWFyY2ggQmFyIC0gQ2FyZGxlc3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBweS0xXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC0xIG1pbi13LVsyODBweF1cIj5cclxuICAgICAgICAgIHsvKiBDbHVzdGVyIEZpbHRlciAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC14c1wiPkNsdXN0ZXI6PC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNTZcIj5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDbHVzdGVyRmlsdGVyIHx8IFwiYWxsXCJ9XHJcbiAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZENsdXN0ZXJGaWx0ZXIodmFsKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTggdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJBbGwgQ2x1c3RlcnNcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiYWxsXCI+QWxsIENsdXN0ZXJzIChUYW1pbCBOYWR1KTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAge2NsdXN0ZXJzLm1hcCgoYykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17Yy5pZH0gdmFsdWU9e2MuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2MubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBTdGF0dXMgRmlsdGVyICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhzXCI+U3RhdHVzOjwvc3Bhbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQ0XCI+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkU3RhdHVzRmlsdGVyIHx8IFwiYWxsXCJ9XHJcbiAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZFN0YXR1c0ZpbHRlcih2YWwpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cImgtOCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIkFsbCBTdGF0dXNlc1wiIC8+XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJhbGxcIj5BbGwgU3RhdHVzZXM8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiUGVuZGluZ1wiPlBlbmRpbmcgUmV2aWV3PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIkFwcHJvdmVkXCI+QXBwcm92ZWQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiQ29ycmVjdGlvbiBSZXF1ZXN0ZWRcIj5Db3JyZWN0aW9uIFJlcXVlc3RlZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCJSZWplY3RlZFwiPlJlamVjdGVkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU2VhcmNoIEJveCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1pbi13LVsyMjBweF1cIj5cclxuICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0yLjUgdG9wLTIuNSBoLTMuNSB3LTMuNSB0ZXh0LWdyYXktNDAwXCIgLz5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIHN1Ym1pc3Npb25zLi4uXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcGwtOCBwci0zIHB5LTEuNSB0ZXh0LXhzIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIHBsYWNlaG9sZGVyOnRleHQtZ3JheS00MDAgZm9jdXM6Ym9yZGVyLWJyYW5kLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZGFyazpwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEFwcHJvdmFscyBUYWJsZSAtIFNlYW1sZXNzICYgQm9yZGVybGVzcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14cyBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIvNTAgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5Nb2R1bGU8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkNsdXN0ZXI8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkl0ZW0gJiBEZXNjcmlwdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+U3VibWl0dGVkIEJ5PC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5EYXRlICYgVGltZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtYm9yZGVyLzMwXCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkQXBwcm92YWxzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezd9IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVszNnB4XSB0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja19jaXJjbGVcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPk5vIGFwcHJvdmFsIHJlcXVlc3RzIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+QWxsIHN1Ym1pc3Npb25zIGluIHRoaXMgY2F0ZWdvcnkgYXJlIHVwIHRvIGRhdGUuPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRBcHByb3ZhbHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzcwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtYm9sZCBib3JkZXIgJHtnZXRNb2R1bGVCYWRnZUNvbG9yKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubW9kdWxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRNb2R1bGVJY29uKGl0ZW0ubW9kdWxlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5tb2R1bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgd2hpdGVzcGFjZS1ub3dyYXAgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1bIzAwMjg2OV1cIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNsdXN0ZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IGZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMjg2OV0gbWF4LXctWzI4MHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiIHRpdGxlPXtpdGVtLnJlY29yZFRpdGxlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmVjb3JkVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRldGFpbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbm9ybWFsIHRydW5jYXRlIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm1vZHVsZSA9PT0gJ0F0dGVuZGFuY2UnICYmIGAke2l0ZW0uZGV0YWlscy5wcmVzZW50Q291bnQgfHwgMH0gUHJlc2VudCAvICR7aXRlbS5kZXRhaWxzLnRvdGFsQ291bnQgfHwgMH0gU3R1ZGVudHMgKCR7aXRlbS5kZXRhaWxzLnZpbGxhZ2VOYW1lIHx8ICcnfSlgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm1vZHVsZSA9PT0gJ0xlc3NvbiBQbGFuJyAmJiBgJHtpdGVtLmRldGFpbHMuZHVyYXRpb24gfHwgJzkwIE1pbnMnfSDigKIgJHtpdGVtLmRldGFpbHMudGFyZ2V0U3RhbmRhcmQgfHwgJzZ0aC04dGggU3RkJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm1vZHVsZSA9PT0gJ0ZpbmFuY2UnICYmIGBScy4gJHtpdGVtLmRldGFpbHMudG90YWxBbW91bnQgfHwgMH0g4oCiIFNQT0M6ICR7aXRlbS5kZXRhaWxzLnNwb2NOYW1lIHx8ICdBZG1pbid9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5tb2R1bGUgPT09ICdDb3JyZWN0aW9uIFJlcXVlc3QnICYmIGBSZWFzb246ICR7aXRlbS5kZXRhaWxzLnJlYXNvbiB8fCAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN1Ym1pdHRlZEJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc2xhdGUtNTAwIHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdWJtaXR0ZWRBdH1cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMC41cHhdIGZvbnQtYm9sZCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uc3RhdHVzID09PSAnQXBwcm92ZWQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtODAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpdGVtLnN0YXR1cyA9PT0gJ1BlbmRpbmcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci0xMDAgdGV4dC1hbWJlci05MDAgYW5pbWF0ZS1wdWxzZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbS5zdGF0dXMgPT09ICdDb3JyZWN0aW9uIFJlcXVlc3RlZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLW9yYW5nZS0xMDAgdGV4dC1vcmFuZ2UtODAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuUmV2aWV3KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLVsjMDAyODY5XSBob3ZlcjpiZy1bIzAwMWY1Ml0gdGV4dC13aGl0ZSBweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTRweF1cIj52aXNpYmlsaXR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSAnUGVuZGluZycgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQXBwcm92ZShpdGVtLmlkLCBpdGVtLm1vZHVsZSwgaXRlbS5yZWNvcmRJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHB4LTIuNSBweS0xIHJvdW5kZWQtbWQgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlciBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJRdWljayBBcHByb3ZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE0cHhdXCI+Y2hlY2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcHByb3ZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBERVRBSUxFRCBSRVZJRVcgJiBBUFBST1ZBTCBNT0RBTCAqL31cclxuICAgICAge3Jldmlld0l0ZW0gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gYmctZ3JheS05MDAvNzAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB3LWZ1bGwgbWF4LXctMnhsIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bOTB2aF1cIj5cclxuICAgICAgICAgICAgey8qIE1vZGFsIEhlYWRlciAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1bIzAwMjg2OV0gdGV4dC13aGl0ZSBwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMnB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICB7Z2V0TW9kdWxlSWNvbihyZXZpZXdJdGVtLm1vZHVsZSl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZFwiPlJldmlldyBTdWJtaXNzaW9uOiB7cmV2aWV3SXRlbS5tb2R1bGV9PC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cmV2aWV3SXRlbS5jbHVzdGVyTmFtZX0g4oCiIFN1Ym1pdHRlZCBieSB7cmV2aWV3SXRlbS5zdWJtaXR0ZWRCeX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmV2aWV3SXRlbShudWxsKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGUvODAgaG92ZXI6dGV4dC13aGl0ZSBwLTEgcm91bmRlZC1mdWxsIGhvdmVyOmJnLXdoaXRlMTAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTW9kYWwgQm9keSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMy41IHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlY29yZCBUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPntyZXZpZXdJdGVtLnJlY29yZFRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ib2xkICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXZpZXdJdGVtLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTEwMCB0ZXh0LWVtZXJhbGQtODAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci0xMDAgdGV4dC1hbWJlci05MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7cmV2aWV3SXRlbS5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBnYXAtMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBibG9ja1wiPkNsdXN0ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPntyZXZpZXdJdGVtLmNsdXN0ZXJOYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5TdWJtaXNzaW9uIERhdGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPntyZXZpZXdJdGVtLnN1Ym1pdHRlZEF0fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5Nb2R1bGUgSUQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPntyZXZpZXdJdGVtLnJlY29yZElkfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIE1vZHVsZS1TcGVjaWZpYyBEYXRhIFJlbmRlcmluZyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBTdWJtaXNzaW9uIEJyZWFrZG93blxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIHtyZXZpZXdJdGVtLmRldGFpbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLVsjZjhmYWZjXSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLW1kIHAtMyBzcGFjZS15LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhyZXZpZXdJdGVtLmRldGFpbHMpLm1hcCgoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHB5LTEgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBsYXN0OmJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGNhcGl0YWxpemVcIj57a2V5LnJlcGxhY2UoLyhbQS1aXSkvZywgJyAkMScpfTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj57U3RyaW5nKHZhbCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIENvcnJlY3Rpb24gUmVhc29uIEZvcm0gKi99XHJcbiAgICAgICAgICAgICAge3Nob3dDb3JyZWN0aW9uRm9ybSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwLzcwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQtbWQgcC00IHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1hbWJlci05MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxOHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2lzUmVqZWN0aW5nID8gJ2Jsb2NrJyA6ICdlZGl0X25vdGUnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXNSZWplY3RpbmcgPyAnUmVqZWN0aW9uIFJlYXNvbiAoTWFuZGF0b3J5KScgOiAnQ29ycmVjdGlvbiBGZWVkYmFjayAoTWFuZGF0b3J5KSd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1hbWJlci04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQcm92aWRlIHByZWNpc2UgaW5zdHJ1Y3Rpb25zIHNvIHRoZSBDbHVzdGVyIEFkbWluIGtub3dzIGV4YWN0bHkgd2hhdCBuZWVkcyB0byBiZSByZXZpc2VkIGJlZm9yZSByZXN1Ym1pdHRpbmcuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvcnJlY3Rpb25SZWFzb25JbnB1dH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvcnJlY3Rpb25SZWFzb25JbnB1dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFBsZWFzZSB1cGRhdGUgc3R1ZGVudCBhdHRlbmRhbmNlIGZvciByb3cgNCBhbmQgYXR0YWNoIHRoZSBjbGVhciBmdWVsIGJpbGwgcmVjZWlwdC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1hbWJlci0zMDAgcm91bmRlZC1tZCBwLTIuNSB0ZXh0LXhzIHRleHQtc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwMDI4NjldXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0NvcnJlY3Rpb25Gb3JtKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHJvdW5kZWQtbWQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMjAwIHRleHQteHMgZm9udC1zZW1pYm9sZCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VibWl0Q29ycmVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMS41IHJvdW5kZWQtbWQgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBzaGFkb3cteHMgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNSZWplY3RpbmcgPyAnYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwJyA6ICdiZy1hbWJlci02MDAgaG92ZXI6YmctYW1iZXItNzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2lzUmVqZWN0aW5nID8gJ0NvbmZpcm0gUmVqZWN0aW9uJyA6ICdTdWJtaXQgQ29ycmVjdGlvbiBSZXF1ZXN0J31cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBGb290ZXIgQWN0aW9ucyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtNTAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRUYWIgPVxyXG4gICAgICAgICAgICAgICAgICAgIHJldmlld0l0ZW0ubW9kdWxlID09PSAnQXR0ZW5kYW5jZSdcclxuICAgICAgICAgICAgICAgICAgICAgID8gJ2F0dGVuZGFuY2UnXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IHJldmlld0l0ZW0ubW9kdWxlID09PSAnTGVzc29uIFBsYW4nXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICdsZXNzb24tcGxhbidcclxuICAgICAgICAgICAgICAgICAgICAgIDogcmV2aWV3SXRlbS5tb2R1bGUgPT09ICdGaW5hbmNlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyAnZmluYW5jZS1zdGF0ZW1lbnQnXHJcbiAgICAgICAgICAgICAgICAgICAgICA6ICdzZXNzaW9ucyc7XHJcbiAgICAgICAgICAgICAgICAgIG9uTmF2aWdhdGUodGFyZ2V0VGFiLCByZXZpZXdJdGVtLnJlY29yZElkKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UmV2aWV3SXRlbShudWxsKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1bIzAwMjg2OV0gaG92ZXI6Ymctc2xhdGUtMjAwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5vcGVuX2luX25ldzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIE9wZW4gaW4gRnVsbCBNb2R1bGVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgeyFzaG93Q29ycmVjdGlvbkZvcm0gJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNSZWplY3RpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93Q29ycmVjdGlvbkZvcm0odHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTYwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMS41IHJvdW5kZWQtbWQgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmVkaXRfbm90ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlcXVlc3QgQ29ycmVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFwcHJvdmVDb25maXJtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSBweC00IHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmNoZWNrX2NpcmNsZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmUgUmVjb3JkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5cclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0FwcHJvdmFsQ2VudGVyVmlldy50c3gifQ==