import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navigation.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import {
  LayoutDashboard,
  CalendarRange,
  MapPin,
  GraduationCap,
  Users,
  CalendarCheck2,
  BookOpen,
  ReceiptIndianRupee,
  ShieldCheck,
  FileText,
  Settings,
  Camera,
  Network,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ClipboardList,
  UserCheck,
  X,
  Calendar,
  ClipboardCheck
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { TqiLogo } from "/src/components/TqiLogo.tsx";
export const Navigation = ({
  currentTab,
  onSelectTab,
  userRole = "Super Admin",
  pendingApprovalsCount = 0,
  isCollapsed = false,
  onToggleCollapse,
  onLogout,
  isMobileOpen = false,
  onCloseMobile
}) => {
  const isSuperAdmin = !userRole || userRole === "Super Admin" || userRole.toLowerCase().includes("super");
  const isVolunteer = userRole === "Volunteer";
  const navGroups = [
    {
      label: "Main Dashboard",
      items: [
        { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
        ...isSuperAdmin ? [{ id: "academic-setup", label: "Academic Term (8-Day)", icon: CalendarRange, superAdminOnly: true }] : []
      ]
    },
    {
      label: "Field Operations",
      items: [
        ...!isVolunteer ? [{ id: "clusters", label: "Clusters", icon: Network }] : [],
        { id: "panchayats", label: "Panchayats & Villages", icon: MapPin },
        { id: "students", label: "Students Roster", icon: GraduationCap },
        { id: "volunteers", label: "Volunteers Directory", icon: Users },
        { id: "attendance", label: "8-Day Attendance", icon: CalendarCheck2 },
        { id: "sessions", label: "Session Scheduling", icon: ClipboardList },
        { id: "session-photos", label: "Session Photos", icon: Camera },
        { id: "date-change-requests", label: "Date Change Requests", icon: Calendar },
        { id: "session-reports", label: "Session Reports", icon: FileText }
      ]
    },
    {
      label: "Curriculum & Finance",
      items: [
        { id: "module-library", label: "Module Library & PPTs", icon: BookOpen },
        { id: "lesson-plan", label: "Lesson Plans", icon: FileText },
        { id: "finance", label: "Finance & OCR Bills", icon: ReceiptIndianRupee },
        { id: "finance-statement", label: "Finance Statements", icon: FileText }
      ]
    },
    {
      label: "Governance & Administration",
      items: [
        {
          id: "approvals",
          label: "Approval Center",
          icon: ShieldCheck,
          badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : void 0
        },
        { id: "session-submissions", label: "Session Submissions", icon: ClipboardCheck },
        { id: "reports", label: "Analytics & Reports", icon: FileText },
        ...isSuperAdmin ? [{ id: "users", label: "User & Role Management", icon: UserCheck }] : [],
        ...isSuperAdmin ? [{ id: "audit-logs", label: "Audit & Governance Trail", icon: FileText }] : [],
        { id: "settings", label: "Settings & Profile", icon: Settings }
      ]
    }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    isMobileOpen && /* @__PURE__ */ jsxDEV(
      "div",
      {
        onClick: onCloseMobile,
        className: "fixed inset-0 z-30 bg-gray-900/60 backdrop-blur-xs lg:hidden transition-opacity animate-in fade-in-0"
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
        lineNumber: 127,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "aside",
      {
        className: `fixed top-0 left-0 z-40 flex flex-col h-screen border-r border-gray-200 bg-white transition-all duration-300 ease-in-out dark:border-gray-800 dark:bg-gray-900 select-none ${isMobileOpen ? "translate-x-0 shadow-2xl" : "-translate-x-full lg:translate-x-0"} ${isCollapsed ? "lg:w-[90px]" : "w-[280px] sm:w-[290px]"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex h-20 items-center justify-between px-5 border-b border-gray-100 dark:border-gray-800/80 shrink-0", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV(TqiLogo, { size: 44, className: "shrink-0" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 142,
                columnNumber: 13
              }, this),
              (!isCollapsed || isMobileOpen) && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-base font-bold text-gray-900 dark:text-white tracking-tight leading-tight", children: "Talent Quest" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 145,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-brand-500 dark:text-brand-400", children: "ERP System" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 148,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 144,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
              lineNumber: 141,
              columnNumber: 11
            }, this),
            onToggleCollapse && !isCollapsed && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onToggleCollapse,
                className: "hidden lg:flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white transition-colors cursor-pointer",
                title: "Collapse sidebar",
                children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-4 w-4" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 163,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 157,
                columnNumber: 11
              },
              this
            ),
            onCloseMobile && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: onCloseMobile,
                className: "flex lg:hidden h-9 w-9 items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white transition-colors cursor-pointer",
                "aria-label": "Close sidebar",
                children: /* @__PURE__ */ jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 175,
                  columnNumber: 15
                }, this)
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 169,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
            lineNumber: 140,
            columnNumber: 9
          }, this),
          onToggleCollapse && isCollapsed && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: onToggleCollapse,
              className: "mx-auto mt-3 hidden lg:flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-900 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white transition-colors cursor-pointer",
              title: "Expand sidebar",
              children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 188,
                columnNumber: 13
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
              lineNumber: 182,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("nav", { className: "flex-1 overflow-y-auto px-4 py-5 space-y-6 custom-scrollbar", children: navGroups.map((group) => {
            const visibleItems = group.items.filter((item) => {
              if (item.superAdminOnly && !isSuperAdmin) return false;
              return true;
            });
            if (visibleItems.length === 0) return null;
            return /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
              !isCollapsed || isMobileOpen ? /* @__PURE__ */ jsxDEV("div", { className: "px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500", children: group.label }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 205,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mx-2 my-2 h-px bg-gray-100 dark:bg-gray-800" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                lineNumber: 209,
                columnNumber: 17
              }, this),
              visibleItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentTab === item.id;
                return /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => {
                      onSelectTab(item.id);
                      onCloseMobile?.();
                    },
                    title: isCollapsed && !isMobileOpen ? item.label : void 0,
                    className: `group relative flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all cursor-pointer ${isActive ? "bg-brand-50 text-brand-500 dark:bg-brand-500/15 dark:text-brand-400 font-semibold shadow-theme-xs" : "text-gray-600 hover:bg-gray-100/80 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-white"} ${isCollapsed && !isMobileOpen ? "justify-center px-0" : ""}`,
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        IconComponent,
                        {
                          className: `h-5 w-5 shrink-0 transition-colors ${isActive ? "text-brand-500 dark:text-brand-400" : "text-gray-500 group-hover:text-gray-700 dark:text-gray-400 dark:group-hover:text-gray-300"}`
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                          lineNumber: 230,
                          columnNumber: 23
                        },
                        this
                      ),
                      (!isCollapsed || isMobileOpen) && /* @__PURE__ */ jsxDEV("span", { className: "truncate flex-1 text-left", children: item.label }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                        lineNumber: 238,
                        columnNumber: 23
                      }, this),
                      item.badge !== void 0 && item.badge > 0 && /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          className: `inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold tabular-nums shadow-theme-xs ${isActive ? "bg-brand-500 text-white" : "bg-error-500 text-white"} ${isCollapsed && !isMobileOpen ? "absolute top-1 right-2" : ""}`,
                          children: item.badge
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                          lineNumber: 241,
                          columnNumber: 23
                        },
                        this
                      )
                    ]
                  },
                  item.id,
                  true,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                    lineNumber: 216,
                    columnNumber: 21
                  },
                  this
                );
              })
            ] }, group.label, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
              lineNumber: 203,
              columnNumber: 15
            }, this);
          }) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
            lineNumber: 193,
            columnNumber: 9
          }, this),
          onLogout && /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-100 p-4 dark:border-gray-800 shrink-0", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                onLogout();
                onCloseMobile?.();
              },
              title: isCollapsed && !isMobileOpen ? "Sign out" : void 0,
              className: `flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-gray-600 hover:bg-error-50 hover:text-error-600 dark:text-gray-400 dark:hover:bg-error-500/15 dark:hover:text-error-400 transition-colors cursor-pointer ${isCollapsed && !isMobileOpen ? "justify-center px-0" : ""}`,
              children: [
                /* @__PURE__ */ jsxDEV(LogOut, { className: "h-5 w-5 shrink-0" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 273,
                  columnNumber: 15
                }, this),
                (!isCollapsed || isMobileOpen) && /* @__PURE__ */ jsxDEV("span", { children: "Sign Out" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
                  lineNumber: 274,
                  columnNumber: 50
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
              lineNumber: 262,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
            lineNumber: 261,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
        lineNumber: 134,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx",
    lineNumber: 124,
    columnNumber: 5
  }, this);
};
_c = Navigation;
var _c;
$RefreshReg$(_c, "Navigation");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/Navigation.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkhJLG1CQUdJLGNBSEo7QUExSEo7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsU0FBU0MsZUFBZTtBQWdDakIsYUFBTUMsYUFBd0NBLENBQUM7QUFBQSxFQUNwREM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsV0FBVztBQUFBLEVBQ1hDLHdCQUF3QjtBQUFBLEVBQ3hCQyxjQUFjO0FBQUEsRUFDZEM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsZUFBZTtBQUFBLEVBQ2ZDO0FBQ0YsTUFBTTtBQUNKLFFBQU1DLGVBQWUsQ0FBQ1AsWUFBWUEsYUFBYSxpQkFBaUJBLFNBQVNRLFlBQVksRUFBRUMsU0FBUyxPQUFPO0FBQ3ZHLFFBQU1DLGNBQWVWLGFBQXdCO0FBRTdDLFFBQU1XLFlBQXdCO0FBQUEsSUFDNUI7QUFBQSxNQUNFQyxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLFFBQ0wsRUFBRUMsSUFBSSxhQUFhRixPQUFPLGFBQWFHLE1BQU14QyxnQkFBZ0I7QUFBQSxRQUM3RCxHQUFJZ0MsZUFDQSxDQUFDLEVBQUVPLElBQUksa0JBQWtCRixPQUFPLHlCQUF5QkcsTUFBTXZDLGVBQWV3QyxnQkFBZ0IsS0FBSyxDQUFDLElBQ3BHO0FBQUEsTUFBRztBQUFBLElBRVg7QUFBQSxJQUNBO0FBQUEsTUFDRUosT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxRQUNMLEdBQUksQ0FBQ0gsY0FBYyxDQUFDLEVBQUVJLElBQUksWUFBWUYsT0FBTyxZQUFZRyxNQUFNNUIsUUFBUSxDQUFDLElBQUk7QUFBQSxRQUM1RSxFQUFFMkIsSUFBSSxjQUFjRixPQUFPLHlCQUF5QkcsTUFBTXRDLE9BQU87QUFBQSxRQUNqRSxFQUFFcUMsSUFBSSxZQUFZRixPQUFPLG1CQUFtQkcsTUFBTXJDLGNBQWM7QUFBQSxRQUNoRSxFQUFFb0MsSUFBSSxjQUFjRixPQUFPLHdCQUF3QkcsTUFBTXBDLE1BQU07QUFBQSxRQUMvRCxFQUFFbUMsSUFBSSxjQUFjRixPQUFPLG9CQUFvQkcsTUFBTW5DLGVBQWU7QUFBQSxRQUNwRSxFQUFFa0MsSUFBSSxZQUFZRixPQUFPLHNCQUFzQkcsTUFBTXhCLGNBQWM7QUFBQSxRQUNuRSxFQUFFdUIsSUFBSSxrQkFBa0JGLE9BQU8sa0JBQWtCRyxNQUFNN0IsT0FBTztBQUFBLFFBQzlELEVBQUU0QixJQUFJLHdCQUF3QkYsT0FBTyx3QkFBd0JHLE1BQU1yQixTQUFTO0FBQUEsUUFDNUUsRUFBRW9CLElBQUksbUJBQW1CRixPQUFPLG1CQUFtQkcsTUFBTS9CLFNBQVM7QUFBQSxNQUFDO0FBQUEsSUFFdkU7QUFBQSxJQUNBO0FBQUEsTUFDRTRCLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsUUFDTCxFQUFFQyxJQUFJLGtCQUFrQkYsT0FBTyx5QkFBeUJHLE1BQU1sQyxTQUFTO0FBQUEsUUFDdkUsRUFBRWlDLElBQUksZUFBZUYsT0FBTyxnQkFBZ0JHLE1BQU0vQixTQUFTO0FBQUEsUUFDM0QsRUFBRThCLElBQUksV0FBV0YsT0FBTyx1QkFBdUJHLE1BQU1qQyxtQkFBbUI7QUFBQSxRQUN4RSxFQUFFZ0MsSUFBSSxxQkFBcUJGLE9BQU8sc0JBQXNCRyxNQUFNL0IsU0FBUztBQUFBLE1BQUM7QUFBQSxJQUU1RTtBQUFBLElBQ0E7QUFBQSxNQUNFNEIsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxRQUNMO0FBQUEsVUFDRUMsSUFBSTtBQUFBLFVBQ0pGLE9BQU87QUFBQSxVQUNQRyxNQUFNaEM7QUFBQUEsVUFDTmtDLE9BQU9oQix3QkFBd0IsSUFBSUEsd0JBQXdCaUI7QUFBQUEsUUFDN0Q7QUFBQSxRQUNBLEVBQUVKLElBQUksdUJBQXVCRixPQUFPLHVCQUF1QkcsTUFBTXBCLGVBQWU7QUFBQSxRQUNoRixFQUFFbUIsSUFBSSxXQUFXRixPQUFPLHVCQUF1QkcsTUFBTS9CLFNBQVM7QUFBQSxRQUM5RCxHQUFJdUIsZUFBZSxDQUFDLEVBQUVPLElBQUksU0FBU0YsT0FBTywwQkFBMEJHLE1BQU12QixVQUFVLENBQUMsSUFBSTtBQUFBLFFBQ3pGLEdBQUllLGVBQWUsQ0FBQyxFQUFFTyxJQUFJLGNBQWNGLE9BQU8sNEJBQTRCRyxNQUFNL0IsU0FBUyxDQUFDLElBQUk7QUFBQSxRQUMvRixFQUFFOEIsSUFBSSxZQUFZRixPQUFPLHNCQUFzQkcsTUFBTTlCLFNBQVM7QUFBQSxNQUFDO0FBQUEsSUFFbkU7QUFBQSxFQUFDO0FBR0gsU0FDRSxtQ0FFR29CO0FBQUFBLG9CQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTQztBQUFBQSxRQUNULFdBQVU7QUFBQTtBQUFBLE1BRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRWtIO0FBQUEsSUFLcEg7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsOEtBQ1RELGVBQWUsNkJBQTZCLG9DQUFvQyxJQUM5RUgsY0FBYyxnQkFBZ0Isd0JBQXdCO0FBQUEsUUFHMUQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUdBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLGNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsZUFDckMsQ0FBQ0EsZUFBZUcsaUJBQ2hCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxrRkFBZ0YsNEJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsNERBQTBELDBCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUdDRixvQkFBb0IsQ0FBQ0QsZUFDcEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0M7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUNWLE9BQU07QUFBQSxnQkFFTixpQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQTtBQUFBLGNBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFJREcsaUJBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0E7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUNWLGNBQVc7QUFBQSxnQkFFWCxpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQjtBQUFBO0FBQUEsY0FOeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLFVBR0NILG9CQUFvQkQsZUFDbkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQ1YsT0FBTTtBQUFBLGNBRU4saUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBO0FBQUEsWUFObkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUlGLHVCQUFDLFNBQUksV0FBVSwrREFDWlEsb0JBQVVRLElBQUksQ0FBQ0MsVUFBVTtBQUN4QixrQkFBTUMsZUFBZUQsTUFBTVAsTUFBTVMsT0FBTyxDQUFDQyxTQUFTO0FBQ2hELGtCQUFJQSxLQUFLUCxrQkFBa0IsQ0FBQ1QsYUFBYyxRQUFPO0FBQ2pELHFCQUFPO0FBQUEsWUFDVCxDQUFDO0FBRUQsZ0JBQUljLGFBQWFHLFdBQVcsRUFBRyxRQUFPO0FBRXRDLG1CQUNFLHVCQUFDLFNBQXNCLFdBQVUsYUFDOUI7QUFBQSxlQUFDdEIsZUFBZUcsZUFDZix1QkFBQyxTQUFJLFdBQVUsaUdBQ1plLGdCQUFNUixTQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsaURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQ7QUFBQSxjQUU3RFMsYUFBYUYsSUFBSSxDQUFDSSxTQUFTO0FBQzFCLHNCQUFNRSxnQkFBZ0JGLEtBQUtSO0FBQzNCLHNCQUFNVyxXQUFXNUIsZUFBZXlCLEtBQUtUO0FBRXJDLHVCQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU07QUFDYmYsa0NBQVl3QixLQUFLVCxFQUFFO0FBQ25CUixzQ0FBZ0I7QUFBQSxvQkFDbEI7QUFBQSxvQkFDQSxPQUFPSixlQUFlLENBQUNHLGVBQWVrQixLQUFLWCxRQUFRTTtBQUFBQSxvQkFDbkQsV0FBVyw0SEFDVFEsV0FDSSxzR0FDQSx1SEFBdUgsSUFDekh4QixlQUFlLENBQUNHLGVBQWUsd0JBQXdCLEVBQUU7QUFBQSxvQkFFN0Q7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLHNDQUNUcUIsV0FDSSx1Q0FDQSwyRkFBMkY7QUFBQTtBQUFBLHdCQUpuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0s7QUFBQSx1QkFFSCxDQUFDeEIsZUFBZUcsaUJBQ2hCLHVCQUFDLFVBQUssV0FBVSw2QkFBNkJrQixlQUFLWCxTQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RDtBQUFBLHNCQUV6RFcsS0FBS04sVUFBVUMsVUFBYUssS0FBS04sUUFBUSxLQUN4QztBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFXLHdHQUNUUyxXQUNJLDRCQUNBLHlCQUF5QixJQUMzQnhCLGVBQWUsQ0FBQ0csZUFBZSwyQkFBMkIsRUFBRTtBQUFBLDBCQUUvRGtCLGVBQUtOO0FBQUFBO0FBQUFBLHdCQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRQTtBQUFBO0FBQUE7QUFBQSxrQkFoQ0dNLEtBQUtUO0FBQUFBLGtCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbUNBO0FBQUEsY0FFSixDQUFDO0FBQUEsaUJBbERPTSxNQUFNUixPQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1EQTtBQUFBLFVBRUosQ0FBQyxLQS9ESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdFQTtBQUFBLFVBR0NSLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYkEseUJBQVM7QUFDVEUsZ0NBQWdCO0FBQUEsY0FDbEI7QUFBQSxjQUNBLE9BQU9KLGVBQWUsQ0FBQ0csZUFBZSxhQUFhYTtBQUFBQSxjQUNuRCxXQUFXLDZPQUNUaEIsZUFBZSxDQUFDRyxlQUFlLHdCQUF3QixFQUFFO0FBQUEsY0FHM0Q7QUFBQSx1Q0FBQyxVQUFPLFdBQVUsc0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUEsaUJBQ2xDLENBQUNILGVBQWVHLGlCQUFpQix1QkFBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWM7QUFBQTtBQUFBO0FBQUEsWUFabkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUE7QUFBQTtBQUFBLE1BOUlKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdKQTtBQUFBLE9BMUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EySkE7QUFFSjtBQUFFc0IsS0EvTlc5QjtBQUFxQyxJQUFBOEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGF5b3V0RGFzaGJvYXJkIiwiQ2FsZW5kYXJSYW5nZSIsIk1hcFBpbiIsIkdyYWR1YXRpb25DYXAiLCJVc2VycyIsIkNhbGVuZGFyQ2hlY2syIiwiQm9va09wZW4iLCJSZWNlaXB0SW5kaWFuUnVwZWUiLCJTaGllbGRDaGVjayIsIkZpbGVUZXh0IiwiU2V0dGluZ3MiLCJDYW1lcmEiLCJOZXR3b3JrIiwiTG9nT3V0IiwiQ2hldnJvbkxlZnQiLCJDaGV2cm9uUmlnaHQiLCJDbGlwYm9hcmRMaXN0IiwiVXNlckNoZWNrIiwiWCIsIkNhbGVuZGFyIiwiQ2xpcGJvYXJkQ2hlY2siLCJUcWlMb2dvIiwiTmF2aWdhdGlvbiIsImN1cnJlbnRUYWIiLCJvblNlbGVjdFRhYiIsInVzZXJSb2xlIiwicGVuZGluZ0FwcHJvdmFsc0NvdW50IiwiaXNDb2xsYXBzZWQiLCJvblRvZ2dsZUNvbGxhcHNlIiwib25Mb2dvdXQiLCJpc01vYmlsZU9wZW4iLCJvbkNsb3NlTW9iaWxlIiwiaXNTdXBlckFkbWluIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImlzVm9sdW50ZWVyIiwibmF2R3JvdXBzIiwibGFiZWwiLCJpdGVtcyIsImlkIiwiaWNvbiIsInN1cGVyQWRtaW5Pbmx5IiwiYmFkZ2UiLCJ1bmRlZmluZWQiLCJtYXAiLCJncm91cCIsInZpc2libGVJdGVtcyIsImZpbHRlciIsIml0ZW0iLCJsZW5ndGgiLCJJY29uQ29tcG9uZW50IiwiaXNBY3RpdmUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOYXZpZ2F0aW9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQge1xuICBMYXlvdXREYXNoYm9hcmQsXG4gIENhbGVuZGFyUmFuZ2UsXG4gIE1hcFBpbixcbiAgR3JhZHVhdGlvbkNhcCxcbiAgVXNlcnMsXG4gIENhbGVuZGFyQ2hlY2syLFxuICBCb29rT3BlbixcbiAgUmVjZWlwdEluZGlhblJ1cGVlLFxuICBTaGllbGRDaGVjayxcbiAgRmlsZVRleHQsXG4gIFNldHRpbmdzLFxuICBDYW1lcmEsXG4gIE5ldHdvcmssXG4gIExvZ091dCxcbiAgQ2hldnJvbkxlZnQsXG4gIENoZXZyb25SaWdodCxcbiAgQ2xpcGJvYXJkTGlzdCxcbiAgVXNlckNoZWNrLFxuICBYLFxuICBDYWxlbmRhcixcbiAgQ2xpcGJvYXJkQ2hlY2tcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgVGFiVHlwZSwgTm90aWZpY2F0aW9uSXRlbSwgVXNlclJvbGUgfSBmcm9tIFwiLi4vdHlwZXNcIjtcbmltcG9ydCB7IFRxaUxvZ28gfSBmcm9tIFwiLi9UcWlMb2dvXCI7XG5cbmludGVyZmFjZSBOYXZpZ2F0aW9uUHJvcHMge1xuICBjdXJyZW50VGFiOiBUYWJUeXBlIHwgc3RyaW5nO1xuICBvblNlbGVjdFRhYjogKHRhYjogVGFiVHlwZSB8IHN0cmluZykgPT4gdm9pZDtcbiAgbm90aWZpY2F0aW9ucz86IE5vdGlmaWNhdGlvbkl0ZW1bXTtcbiAgdXNlclJvbGU/OiBVc2VyUm9sZTtcbiAgY2x1c3Rlck5hbWU/OiBzdHJpbmc7XG4gIGFkbWluTmFtZT86IHN0cmluZztcbiAgdXNlckVtYWlsPzogc3RyaW5nO1xuICBwZW5kaW5nQXBwcm92YWxzQ291bnQ/OiBudW1iZXI7XG4gIGlzQ29sbGFwc2VkPzogYm9vbGVhbjtcbiAgb25Ub2dnbGVDb2xsYXBzZT86ICgpID0+IHZvaWQ7XG4gIG9uTG9nb3V0PzogKCkgPT4gdm9pZDtcbiAgaXNNb2JpbGVPcGVuPzogYm9vbGVhbjtcbiAgb25DbG9zZU1vYmlsZT86ICgpID0+IHZvaWQ7XG59XG5cbmludGVyZmFjZSBOYXZJdGVtIHtcbiAgaWQ6IFRhYlR5cGUgfCBzdHJpbmc7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGljb246IFJlYWN0LkNvbXBvbmVudFR5cGU8eyBjbGFzc05hbWU/OiBzdHJpbmcgfT47XG4gIGJhZGdlPzogbnVtYmVyO1xuICBzdXBlckFkbWluT25seT86IGJvb2xlYW47XG4gIGNsdXN0ZXJBZG1pbk9ubHk/OiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgTmF2R3JvdXAge1xuICBsYWJlbDogc3RyaW5nO1xuICBpdGVtczogTmF2SXRlbVtdO1xufVxuXG5leHBvcnQgY29uc3QgTmF2aWdhdGlvbjogUmVhY3QuRkM8TmF2aWdhdGlvblByb3BzPiA9ICh7XG4gIGN1cnJlbnRUYWIsXG4gIG9uU2VsZWN0VGFiLFxuICB1c2VyUm9sZSA9IFwiU3VwZXIgQWRtaW5cIixcbiAgcGVuZGluZ0FwcHJvdmFsc0NvdW50ID0gMCxcbiAgaXNDb2xsYXBzZWQgPSBmYWxzZSxcbiAgb25Ub2dnbGVDb2xsYXBzZSxcbiAgb25Mb2dvdXQsXG4gIGlzTW9iaWxlT3BlbiA9IGZhbHNlLFxuICBvbkNsb3NlTW9iaWxlLFxufSkgPT4ge1xuICBjb25zdCBpc1N1cGVyQWRtaW4gPSAhdXNlclJvbGUgfHwgdXNlclJvbGUgPT09IFwiU3VwZXIgQWRtaW5cIiB8fCB1c2VyUm9sZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwic3VwZXJcIik7XG4gIGNvbnN0IGlzVm9sdW50ZWVyID0gKHVzZXJSb2xlIGFzIHN0cmluZykgPT09IFwiVm9sdW50ZWVyXCI7XG5cbiAgY29uc3QgbmF2R3JvdXBzOiBOYXZHcm91cFtdID0gW1xuICAgIHtcbiAgICAgIGxhYmVsOiBcIk1haW4gRGFzaGJvYXJkXCIsXG4gICAgICBpdGVtczogW1xuICAgICAgICB7IGlkOiBcImRhc2hib2FyZFwiLCBsYWJlbDogXCJEYXNoYm9hcmRcIiwgaWNvbjogTGF5b3V0RGFzaGJvYXJkIH0sXG4gICAgICAgIC4uLihpc1N1cGVyQWRtaW5cbiAgICAgICAgICA/IFt7IGlkOiBcImFjYWRlbWljLXNldHVwXCIsIGxhYmVsOiBcIkFjYWRlbWljIFRlcm0gKDgtRGF5KVwiLCBpY29uOiBDYWxlbmRhclJhbmdlLCBzdXBlckFkbWluT25seTogdHJ1ZSB9XVxuICAgICAgICAgIDogW10pLFxuICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBcIkZpZWxkIE9wZXJhdGlvbnNcIixcbiAgICAgIGl0ZW1zOiBbXG4gICAgICAgIC4uLighaXNWb2x1bnRlZXIgPyBbeyBpZDogXCJjbHVzdGVyc1wiLCBsYWJlbDogXCJDbHVzdGVyc1wiLCBpY29uOiBOZXR3b3JrIH1dIDogW10pLFxuICAgICAgICB7IGlkOiBcInBhbmNoYXlhdHNcIiwgbGFiZWw6IFwiUGFuY2hheWF0cyAmIFZpbGxhZ2VzXCIsIGljb246IE1hcFBpbiB9LFxuICAgICAgICB7IGlkOiBcInN0dWRlbnRzXCIsIGxhYmVsOiBcIlN0dWRlbnRzIFJvc3RlclwiLCBpY29uOiBHcmFkdWF0aW9uQ2FwIH0sXG4gICAgICAgIHsgaWQ6IFwidm9sdW50ZWVyc1wiLCBsYWJlbDogXCJWb2x1bnRlZXJzIERpcmVjdG9yeVwiLCBpY29uOiBVc2VycyB9LFxuICAgICAgICB7IGlkOiBcImF0dGVuZGFuY2VcIiwgbGFiZWw6IFwiOC1EYXkgQXR0ZW5kYW5jZVwiLCBpY29uOiBDYWxlbmRhckNoZWNrMiB9LFxuICAgICAgICB7IGlkOiBcInNlc3Npb25zXCIsIGxhYmVsOiBcIlNlc3Npb24gU2NoZWR1bGluZ1wiLCBpY29uOiBDbGlwYm9hcmRMaXN0IH0sXG4gICAgICAgIHsgaWQ6IFwic2Vzc2lvbi1waG90b3NcIiwgbGFiZWw6IFwiU2Vzc2lvbiBQaG90b3NcIiwgaWNvbjogQ2FtZXJhIH0sXG4gICAgICAgIHsgaWQ6IFwiZGF0ZS1jaGFuZ2UtcmVxdWVzdHNcIiwgbGFiZWw6IFwiRGF0ZSBDaGFuZ2UgUmVxdWVzdHNcIiwgaWNvbjogQ2FsZW5kYXIgfSxcbiAgICAgICAgeyBpZDogXCJzZXNzaW9uLXJlcG9ydHNcIiwgbGFiZWw6IFwiU2Vzc2lvbiBSZXBvcnRzXCIsIGljb246IEZpbGVUZXh0IH0sXG4gICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgbGFiZWw6IFwiQ3VycmljdWx1bSAmIEZpbmFuY2VcIixcbiAgICAgIGl0ZW1zOiBbXG4gICAgICAgIHsgaWQ6IFwibW9kdWxlLWxpYnJhcnlcIiwgbGFiZWw6IFwiTW9kdWxlIExpYnJhcnkgJiBQUFRzXCIsIGljb246IEJvb2tPcGVuIH0sXG4gICAgICAgIHsgaWQ6IFwibGVzc29uLXBsYW5cIiwgbGFiZWw6IFwiTGVzc29uIFBsYW5zXCIsIGljb246IEZpbGVUZXh0IH0sXG4gICAgICAgIHsgaWQ6IFwiZmluYW5jZVwiLCBsYWJlbDogXCJGaW5hbmNlICYgT0NSIEJpbGxzXCIsIGljb246IFJlY2VpcHRJbmRpYW5SdXBlZSB9LFxuICAgICAgICB7IGlkOiBcImZpbmFuY2Utc3RhdGVtZW50XCIsIGxhYmVsOiBcIkZpbmFuY2UgU3RhdGVtZW50c1wiLCBpY29uOiBGaWxlVGV4dCB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBcIkdvdmVybmFuY2UgJiBBZG1pbmlzdHJhdGlvblwiLFxuICAgICAgaXRlbXM6IFtcbiAgICAgICAge1xuICAgICAgICAgIGlkOiBcImFwcHJvdmFsc1wiLFxuICAgICAgICAgIGxhYmVsOiBcIkFwcHJvdmFsIENlbnRlclwiLFxuICAgICAgICAgIGljb246IFNoaWVsZENoZWNrLFxuICAgICAgICAgIGJhZGdlOiBwZW5kaW5nQXBwcm92YWxzQ291bnQgPiAwID8gcGVuZGluZ0FwcHJvdmFsc0NvdW50IDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgICAgICB7IGlkOiBcInNlc3Npb24tc3VibWlzc2lvbnNcIiwgbGFiZWw6IFwiU2Vzc2lvbiBTdWJtaXNzaW9uc1wiLCBpY29uOiBDbGlwYm9hcmRDaGVjayB9LFxuICAgICAgICB7IGlkOiBcInJlcG9ydHNcIiwgbGFiZWw6IFwiQW5hbHl0aWNzICYgUmVwb3J0c1wiLCBpY29uOiBGaWxlVGV4dCB9LFxuICAgICAgICAuLi4oaXNTdXBlckFkbWluID8gW3sgaWQ6IFwidXNlcnNcIiwgbGFiZWw6IFwiVXNlciAmIFJvbGUgTWFuYWdlbWVudFwiLCBpY29uOiBVc2VyQ2hlY2sgfV0gOiBbXSksXG4gICAgICAgIC4uLihpc1N1cGVyQWRtaW4gPyBbeyBpZDogXCJhdWRpdC1sb2dzXCIsIGxhYmVsOiBcIkF1ZGl0ICYgR292ZXJuYW5jZSBUcmFpbFwiLCBpY29uOiBGaWxlVGV4dCB9XSA6IFtdKSxcbiAgICAgICAgeyBpZDogXCJzZXR0aW5nc1wiLCBsYWJlbDogXCJTZXR0aW5ncyAmIFByb2ZpbGVcIiwgaWNvbjogU2V0dGluZ3MgfSxcbiAgICAgIF0sXG4gICAgfSxcbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogTW9iaWxlIEJhY2tkcm9wIE92ZXJsYXkgKi99XG4gICAgICB7aXNNb2JpbGVPcGVuICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2VNb2JpbGV9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTMwIGJnLWdyYXktOTAwLzYwIGJhY2tkcm9wLWJsdXIteHMgbGc6aGlkZGVuIHRyYW5zaXRpb24tb3BhY2l0eSBhbmltYXRlLWluIGZhZGUtaW4tMFwiXG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogU2lkZWJhciBDb250YWluZXIgKi99XG4gICAgICA8YXNpZGVcbiAgICAgICAgY2xhc3NOYW1lPXtgZml4ZWQgdG9wLTAgbGVmdC0wIHotNDAgZmxleCBmbGV4LWNvbCBoLXNjcmVlbiBib3JkZXItciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0IGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgc2VsZWN0LW5vbmUgJHtcbiAgICAgICAgICBpc01vYmlsZU9wZW4gPyBcInRyYW5zbGF0ZS14LTAgc2hhZG93LTJ4bFwiIDogXCItdHJhbnNsYXRlLXgtZnVsbCBsZzp0cmFuc2xhdGUteC0wXCJcbiAgICAgICAgfSAke2lzQ29sbGFwc2VkID8gXCJsZzp3LVs5MHB4XVwiIDogXCJ3LVsyODBweF0gc206dy1bMjkwcHhdXCJ9YH1cbiAgICAgID5cbiAgICAgICAgey8qIEJyYW5kIEhlYWRlciB3aXRoIExhcmdlciBMb2dvICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0yMCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwLzgwIHNocmluay0wXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxUcWlMb2dvIHNpemU9ezQ0fSBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICB7KCFpc0NvbGxhcHNlZCB8fCBpc01vYmlsZU9wZW4pICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICBUYWxlbnQgUXVlc3RcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC1icmFuZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgIEVSUCBTeXN0ZW1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBEZXNrdG9wIENvbGxhcHNlIGJ1dHRvbiAqL31cbiAgICAgICAgICB7b25Ub2dnbGVDb2xsYXBzZSAmJiAhaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25Ub2dnbGVDb2xsYXBzZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkNvbGxhcHNlIHNpZGViYXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIE1vYmlsZSBDbG9zZSBCdXR0b24gKi99XG4gICAgICAgICAge29uQ2xvc2VNb2JpbGUgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZU1vYmlsZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBsZzpoaWRkZW4gaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2Ugc2lkZWJhclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEV4cGFuZCBidXR0b24gd2hlbiBjb2xsYXBzZWQgb24gRGVza3RvcCAqL31cbiAgICAgICAge29uVG9nZ2xlQ29sbGFwc2UgJiYgaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25Ub2dnbGVDb2xsYXBzZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gbXQtMyBoaWRkZW4gbGc6ZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTEwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT1cIkV4cGFuZCBzaWRlYmFyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uIEdyb3VwIEl0ZW1zICovfVxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcHgtNCBweS01IHNwYWNlLXktNiBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgICAge25hdkdyb3Vwcy5tYXAoKGdyb3VwKSA9PiB7XG4gICAgICAgICAgICBjb25zdCB2aXNpYmxlSXRlbXMgPSBncm91cC5pdGVtcy5maWx0ZXIoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgaWYgKGl0ZW0uc3VwZXJBZG1pbk9ubHkgJiYgIWlzU3VwZXJBZG1pbikgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBpZiAodmlzaWJsZUl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtncm91cC5sYWJlbH0gY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgeyFpc0NvbGxhcHNlZCB8fCBpc01vYmlsZU9wZW4gPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcGItMiB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNDAwIGRhcms6dGV4dC1ncmF5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXAubGFiZWx9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC0yIG15LTIgaC1weCBiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwXCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHt2aXNpYmxlSXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBJY29uQ29tcG9uZW50ID0gaXRlbS5pY29uO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBjdXJyZW50VGFiID09PSBpdGVtLmlkO1xuXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0VGFiKGl0ZW0uaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZU1vYmlsZT8uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17aXNDb2xsYXBzZWQgJiYgIWlzTW9iaWxlT3BlbiA/IGl0ZW0ubGFiZWwgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgcmVsYXRpdmUgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQteGwgcHgtMy41IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgZGFyazpiZy1icmFuZC01MDAvMTUgZGFyazp0ZXh0LWJyYW5kLTQwMCBmb250LXNlbWlib2xkIHNoYWRvdy10aGVtZS14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwLzgwIGhvdmVyOnRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICAgIH0gJHtpc0NvbGxhcHNlZCAmJiAhaXNNb2JpbGVPcGVuID8gXCJqdXN0aWZ5LWNlbnRlciBweC0wXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbkNvbXBvbmVudFxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC01IHctNSBzaHJpbmstMCB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTUwMCBncm91cC1ob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmdyb3VwLWhvdmVyOnRleHQtZ3JheS0zMDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICB7KCFpc0NvbGxhcHNlZCB8fCBpc01vYmlsZU9wZW4pICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlIGZsZXgtMSB0ZXh0LWxlZnRcIj57aXRlbS5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iYWRnZSAhPT0gdW5kZWZpbmVkICYmIGl0ZW0uYmFkZ2UgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtcyBzaGFkb3ctdGhlbWUteHMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1lcnJvci01MDAgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtpc0NvbGxhcHNlZCAmJiAhaXNNb2JpbGVPcGVuID8gXCJhYnNvbHV0ZSB0b3AtMSByaWdodC0yXCIgOiBcIlwifWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L25hdj5cblxuICAgICAgICB7LyogRm9vdGVyIC8gVXNlciAmIFNpZ24gb3V0ICovfVxuICAgICAgICB7b25Mb2dvdXQgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHAtNCBkYXJrOmJvcmRlci1ncmF5LTgwMCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIG9uTG9nb3V0KCk7XG4gICAgICAgICAgICAgICAgb25DbG9zZU1vYmlsZT8uKCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHRpdGxlPXtpc0NvbGxhcHNlZCAmJiAhaXNNb2JpbGVPcGVuID8gXCJTaWduIG91dFwiIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC14bCBweC0zLjUgcHktMi41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1lcnJvci01MCBob3Zlcjp0ZXh0LWVycm9yLTYwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3ZlcjpiZy1lcnJvci01MDAvMTUgZGFyazpob3Zlcjp0ZXh0LWVycm9yLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGlzQ29sbGFwc2VkICYmICFpc01vYmlsZU9wZW4gPyBcImp1c3RpZnktY2VudGVyIHB4LTBcIiA6IFwiXCJcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxMb2dPdXQgY2xhc3NOYW1lPVwiaC01IHctNSBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIHsoIWlzQ29sbGFwc2VkIHx8IGlzTW9iaWxlT3BlbikgJiYgPHNwYW4+U2lnbiBPdXQ8L3NwYW4+fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2FzaWRlPlxuICAgIDwvPlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9OYXZpZ2F0aW9uLnRzeCJ9