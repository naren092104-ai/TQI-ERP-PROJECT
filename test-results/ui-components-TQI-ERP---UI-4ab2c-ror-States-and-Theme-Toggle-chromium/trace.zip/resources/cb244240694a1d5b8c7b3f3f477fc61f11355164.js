import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StudentsView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import * as XLSX from "/node_modules/.vite/deps/xlsx.js?v=8975830d";
import { Badge } from "/src/components/ui/badge.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "/src/components/ui/select.tsx";
export const StudentsView = ({
  students,
  panchayats,
  initialFilters,
  onAddStudent,
  onBulkImportStudents,
  onEditStudent,
  onUpdateStudent,
  onDeleteStudent
}) => {
  _s();
  const [selectedPanchayatId, setSelectedPanchayatId] = useState(null);
  const [selectedVillageName, setSelectedVillageName] = useState(null);
  const [globalSearch, setGlobalSearch] = useState("");
  const [selectedStd, setSelectedStd] = useState("");
  const [viewMode, setViewMode] = useState("split");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [viewingStudent, setViewingStudent] = useState(null);
  const [studentToDelete, setStudentToDelete] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4e3);
  };
  const handleConfirmDeleteStudent = () => {
    if (!studentToDelete) return;
    const sName = studentToDelete.name;
    onDeleteStudent(studentToDelete.id);
    if (viewingStudent?.id === studentToDelete.id) {
      setViewingStudent(null);
    }
    showToast(`Student ${sName} deleted successfully`);
    setStudentToDelete(null);
  };
  const [importRows, setImportRows] = useState([]);
  const [importFileName, setImportFileName] = useState("");
  const [isParsingFile, setIsParsingFile] = useState(false);
  const [importSuccessMessage, setImportSuccessMessage] = useState(null);
  const [importPanchayatId, setImportPanchayatId] = useState("");
  const [importVillageName, setImportVillageName] = useState("");
  const fileInputRef = useRef(null);
  useEffect(() => {
    if (initialFilters?.panchayatId) {
      setSelectedPanchayatId(initialFilters.panchayatId);
      if (initialFilters.villageId) {
        const pan = panchayats.find((p) => p.id === initialFilters.panchayatId);
        const vill = pan?.villages.find((v) => v.id === initialFilters.villageId || v.name === initialFilters.villageId);
        if (vill) {
          setSelectedVillageName(vill.name);
        }
      }
    }
  }, [initialFilters, panchayats]);
  const activePanchayat = useMemo(() => {
    return panchayats.find((p) => p.id === selectedPanchayatId) || null;
  }, [panchayats, selectedPanchayatId]);
  const activeVillage = useMemo(() => {
    if (!activePanchayat || !selectedVillageName) return null;
    return activePanchayat.villages.find(
      (v) => v.name.toLowerCase() === selectedVillageName.toLowerCase() || v.id === selectedVillageName
    ) || null;
  }, [activePanchayat, selectedVillageName]);
  const [formData, setFormData] = useState({
    name: "",
    gender: "female",
    dob: "2009-06-15",
    standard: "9",
    // 9 to 12
    parentName: "",
    phone: "",
    status: "active",
    panchayatId: "",
    villageName: ""
  });
  const villageStudents = useMemo(() => {
    if (!activePanchayat || !selectedVillageName) return [];
    return students.filter(
      (s) => (s.panchayatId === activePanchayat.id || s.panchayatName.toLowerCase() === activePanchayat.name.toLowerCase()) && (s.villageName.toLowerCase() === selectedVillageName.toLowerCase() || s.villageId === activeVillage?.id)
    );
  }, [students, activePanchayat, selectedVillageName, activeVillage]);
  const filteredRosterStudents = useMemo(() => {
    return villageStudents.filter((s) => {
      const matchSearch = s.name.toLowerCase().includes(globalSearch.toLowerCase()) || s.code.toLowerCase().includes(globalSearch.toLowerCase()) || s.parentName.toLowerCase().includes(globalSearch.toLowerCase()) || s.phone.includes(globalSearch);
      const matchStd = !selectedStd || s.standard === selectedStd;
      return matchSearch && matchStd;
    });
  }, [villageStudents, globalSearch, selectedStd]);
  const boyStudents = useMemo(() => filteredRosterStudents.filter((s) => s.gender === "male"), [filteredRosterStudents]);
  const girlStudents = useMemo(() => filteredRosterStudents.filter((s) => s.gender === "female"), [filteredRosterStudents]);
  const clusterTotalStudents = students.length;
  const clusterBoys = students.filter((s) => s.gender === "male").length;
  const clusterGirls = students.filter((s) => s.gender === "female").length;
  const handleSelectPanchayat = (panchayatId) => {
    setSelectedPanchayatId(panchayatId);
    setSelectedVillageName(null);
    setGlobalSearch("");
    setSelectedStd("");
  };
  const handleSelectVillage = (villageName) => {
    setSelectedVillageName(villageName);
    setGlobalSearch("");
    setSelectedStd("");
    setViewMode("split");
  };
  const handleBackToPanchayats = () => {
    setSelectedPanchayatId(null);
    setSelectedVillageName(null);
    setGlobalSearch("");
    setSelectedStd("");
  };
  const handleBackToVillages = () => {
    setSelectedVillageName(null);
    setGlobalSearch("");
    setSelectedStd("");
  };
  const handleOpenAddModal = () => {
    setEditingStudent(null);
    setFormData({
      name: "",
      gender: "female",
      dob: "2009-06-15",
      standard: "9",
      parentName: "",
      phone: "",
      status: "active",
      panchayatId: activePanchayat?.id || "",
      villageName: selectedVillageName || ""
    });
    setShowAddModal(true);
  };
  const handleEditStudent = (student) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      gender: student.gender === "male" ? "male" : "female",
      dob: student.dob || "2009-06-15",
      standard: ["9", "10", "11", "12"].includes(student.standard) ? student.standard : "9",
      parentName: student.parentName || "",
      phone: student.phone || "+91 ",
      status: student.status || "active",
      panchayatId: student.panchayatId || activePanchayat?.id || "",
      villageName: student.villageName || selectedVillageName || ""
    });
    setShowAddModal(true);
  };
  const handleSaveStudent = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert("Please enter student name");
      return;
    }
    if (!formData.panchayatId || !formData.villageName) {
      alert("Please select a Target Panchayat and Village.");
      return;
    }
    const targetPanchayat = panchayats.find((p) => p.id === formData.panchayatId);
    if (!targetPanchayat) return;
    const currentVillageId = targetPanchayat.villages.find((v) => v.name === formData.villageName)?.id || formData.villageName.toLowerCase().replace(/\s+/g, "-");
    if (editingStudent) {
      if (onEditStudent) {
        onEditStudent(editingStudent.id, {
          name: formData.name.trim(),
          gender: formData.gender,
          dob: formData.dob,
          standard: formData.standard,
          parentName: formData.parentName.trim(),
          phone: formData.phone.trim(),
          status: formData.status
        });
      } else if (onUpdateStudent) {
        onUpdateStudent(editingStudent.id, {
          name: formData.name.trim(),
          gender: formData.gender,
          dob: formData.dob,
          standard: formData.standard,
          parentName: formData.parentName.trim(),
          phone: formData.phone.trim(),
          status: formData.status
        });
      }
      showToast(`Updated student ${formData.name.trim()}`);
      setEditingStudent(null);
    } else {
      onAddStudent({
        name: formData.name.trim(),
        gender: formData.gender,
        dob: formData.dob,
        standard: formData.standard,
        panchayatId: activePanchayat.id,
        panchayatName: activePanchayat.name,
        villageId: currentVillageId,
        villageName: selectedVillageName,
        parentName: formData.parentName.trim(),
        phone: formData.phone.trim(),
        status: formData.status
      });
      showToast(`Added student ${formData.name.trim()} successfully`);
    }
    setShowAddModal(false);
  };
  const handleDownloadSampleExcel = () => {
    const sampleData = [
      {
        "Student Name": "Kavya S.",
        "Gender": "Female",
        "Standard": "9",
        "Date of Birth": "2010-04-15",
        "Parent Name": "Srinivasan K.",
        "Contact Phone": "+91 94432 11223",
        "Status": "Active"
      },
      {
        "Student Name": "Gokul Nathan",
        "Gender": "Male",
        "Standard": "10",
        "Date of Birth": "2009-08-20",
        "Parent Name": "Nathan P.",
        "Contact Phone": "+91 98421 99887",
        "Status": "Active"
      },
      {
        "Student Name": "Deepika R.",
        "Gender": "Female",
        "Standard": "11",
        "Date of Birth": "2008-01-10",
        "Parent Name": "Ramesh T.",
        "Contact Phone": "+91 97890 44556",
        "Status": "Active"
      },
      {
        "Student Name": "Vignesh M.",
        "Gender": "Male",
        "Standard": "12",
        "Date of Birth": "2007-11-28",
        "Parent Name": "Murugesan V.",
        "Contact Phone": "+91 98402 77889",
        "Status": "Active"
      }
    ];
    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Students_Template");
    XLSX.writeFile(wb, `Student_Import_Template_${selectedVillageName || "Village"}.xlsx`);
  };
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportFileName(file.name);
    setIsParsingFile(true);
    setImportRows([]);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: "binary" });
        const firstSheetName = wb.SheetNames[0];
        const ws = wb.Sheets[firstSheetName];
        const rawJson = XLSX.utils.sheet_to_json(ws, { defval: "" });
        if (rawJson.length === 0) {
          alert("The uploaded sheet is empty. Please check the file.");
          setIsParsingFile(false);
          return;
        }
        const parsed = rawJson.map((row) => {
          const keys = Object.keys(row);
          const findVal = (terms) => {
            const matchedKey = keys.find(
              (k) => terms.some((t) => k.toLowerCase().replace(/[^a-z0-9]/g, "").includes(t))
            );
            return matchedKey ? String(row[matchedKey]).trim() : "";
          };
          const name = findVal(["name", "studentname", "fullname"]) || "";
          const rawGender = findVal(["gender", "sex"]).toLowerCase();
          const gender = rawGender.startsWith("m") || rawGender.includes("boy") ? "male" : "female";
          const rawStd = findVal(["standard", "std", "class", "grade"]);
          let standard = "9";
          const numMatch = rawStd.match(/\d+/);
          if (numMatch) {
            const num = numMatch[0];
            if (["9", "10", "11", "12"].includes(num)) {
              standard = num;
            } else {
              standard = "9";
            }
          }
          const dob = findVal(["dob", "birth", "dateofbirth"]) || "2009-06-15";
          const parentName = findVal(["parent", "guardian", "father", "mother"]) || "";
          const phone = findVal(["phone", "mobile", "contact"]) || "+91 ";
          const rawStatus = findVal(["status"]).toLowerCase();
          const status = rawStatus.includes("inact") ? "inactive" : "active";
          let isValid = true;
          let validationError = "";
          if (!name) {
            isValid = false;
            validationError = "Student name is missing";
          }
          return {
            name,
            gender,
            standard,
            dob,
            parentName,
            phone,
            status,
            isValid,
            validationError
          };
        });
        setImportRows(parsed);
      } catch (err) {
        console.error("Error reading excel file:", err);
        alert("Could not read Excel file. Please ensure it is a valid .xlsx or .csv file.");
      } finally {
        setIsParsingFile(false);
      }
    };
    reader.readAsBinaryString(file);
  };
  const handleConfirmBulkImport = () => {
    if (!importPanchayatId || !importVillageName) {
      alert("Please select a Panchayat and Village before importing.");
      return;
    }
    const tgtPanchayat = panchayats.find((p) => p.id === importPanchayatId);
    if (!tgtPanchayat) return;
    const validRows = importRows.filter((r) => r.isValid && r.name.trim().length > 0);
    if (validRows.length === 0) {
      alert("No valid student records found to import.");
      return;
    }
    const currentVillageId = activeVillage?.id || selectedVillageName.toLowerCase().replace(/\s+/g, "-");
    const formattedStudents = validRows.map((r) => ({
      name: r.name,
      gender: r.gender,
      dob: r.dob,
      standard: r.standard,
      panchayatId: activePanchayat.id,
      panchayatName: activePanchayat.name,
      villageId: currentVillageId,
      villageName: selectedVillageName,
      parentName: r.parentName,
      phone: r.phone,
      status: r.status
    }));
    if (onBulkImportStudents) {
      onBulkImportStudents(formattedStudents, tgtPanchayat.clusterId || tgtPanchayat.cluster || "");
    } else {
      formattedStudents.forEach((st) => onAddStudent(st));
    }
    setImportSuccessMessage(
      `Successfully imported ${formattedStudents.length} students into ${selectedVillageName}, ${activePanchayat.name}!`
    );
    setShowImportModal(false);
    setImportRows([]);
    setImportFileName("");
    setTimeout(() => {
      setImportSuccessMessage(null);
    }, 6e3);
  };
  if (!selectedPanchayatId) {
    return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: "Students by Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 484,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
              clusterTotalStudents,
              " Total"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 487,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 483,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Select any Panchayat below to explore its villages and manage student rosters." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 491,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 482,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setImportPanchayatId("");
                setImportVillageName("");
                setShowImportModal(true);
              },
              className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Bulk Import (Excel)" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 506,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 497,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                handleOpenAddModal();
                setFormData((prev) => ({ ...prev, panchayatId: "", villageName: "" }));
              },
              className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-sm font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Add Student" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 516,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 508,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 496,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 481,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: "Total Enrolled" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 524,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: clusterTotalStudents }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 525,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 523,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-brand-500 dark:text-brand-400", children: "👦 Boys" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 528,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: clusterBoys }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 529,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 527,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold uppercase tracking-wider text-orange-500 dark:text-orange-400", children: "👧 Girls" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 532,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-2xl font-bold text-gray-900 dark:text-white", children: clusterGirls }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 533,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 531,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 522,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-[18px] pointer-events-none", children: "search" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 539,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search panchayats or cluster...",
            value: globalSearch,
            onChange: (e) => setGlobalSearch(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 542,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 538,
        columnNumber: 9
      }, this),
      importSuccessMessage && /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-success-200 bg-success-50 p-4 text-xs font-medium text-success-600 dark:border-success-900/40 dark:bg-success-500/10 dark:text-success-400 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("span", { children: importSuccessMessage }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 553,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setImportSuccessMessage(null),
            className: "text-success-600 hover:text-success-800 dark:text-success-400",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 559,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 554,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 552,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5", children: panchayats.filter((p) => p.name.toLowerCase().includes(globalSearch.toLowerCase())).map((panchayat) => {
        const panStudents = students.filter(
          (s) => s.panchayatId === panchayat.id || s.panchayatName.toLowerCase() === panchayat.name.toLowerCase()
        );
        const boysCount = panStudents.filter((s) => s.gender === "male").length;
        const girlsCount = panStudents.filter((s) => s.gender === "female").length;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => handleSelectPanchayat(panchayat.id),
            className: "group rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition-all hover:border-brand-300 dark:border-gray-800 dark:bg-white/[0.02] dark:hover:border-brand-800 flex flex-col justify-between cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold uppercase text-gray-400 block", children: [
                      panchayat.cluster,
                      " Cluster"
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 584,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900 dark:text-white group-hover:text-brand-500 transition-colors mt-0.5", children: panchayat.name }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 587,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 583,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Badge,
                    {
                      color: panchayat.status === "On Track" ? "success" : panchayat.status === "Correction Required" ? "warning" : "error",
                      size: "sm",
                      children: panchayat.status
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 591,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 582,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400 font-medium", children: /* @__PURE__ */ jsxDEV("span", { children: [
                  panchayat.villages.length || panchayat.villagesCount,
                  " Villages · ",
                  panStudents.length,
                  " Students"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 606,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 605,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 rounded-xl bg-gray-50/80 p-2.5 text-xs dark:bg-white/[0.02]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm", children: "👦" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 611,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400 uppercase font-semibold", children: "Boys" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 613,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-bold text-gray-900 dark:text-white", children: boysCount }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 614,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 612,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 610,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm", children: "👧" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 618,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400 uppercase font-semibold", children: "Girls" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 620,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-bold text-gray-900 dark:text-white", children: girlsCount }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 621,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 619,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 617,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 609,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5 pt-1", children: panchayat.villages.map(
                  (v) => /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: "rounded-lg border border-gray-200 bg-white px-2 py-0.5 text-[11px] font-medium text-gray-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300",
                      children: v.name
                    },
                    v.id,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 628,
                      columnNumber: 21
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 626,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 581,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs font-bold text-brand-500 group-hover:translate-x-0.5 transition-transform", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "View Villages" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 639,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "arrow_forward" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 640,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 638,
                columnNumber: 19
              }, this)
            ]
          },
          panchayat.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 576,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 565,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 479,
      columnNumber: 7
    }, this);
  }
  if (activePanchayat && !selectedVillageName) {
    const panchayatStudents = students.filter(
      (s) => s.panchayatId === activePanchayat.id || s.panchayatName.toLowerCase() === activePanchayat.name.toLowerCase()
    );
    return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: handleBackToPanchayats,
                className: "hover:text-brand-500 font-semibold",
                children: "Panchayats"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 664,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 671,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 dark:text-white", children: activePanchayat.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 672,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 663,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxDEV("span", { children: activePanchayat.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 675,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
              activePanchayat.villages.length,
              " Villages"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 676,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 674,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Select a village card to view its student roster (Standards 9 to 12)." }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 680,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 662,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setImportPanchayatId(activePanchayat?.id || "");
                setImportVillageName("");
                setShowImportModal(true);
              },
              className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Bulk Import" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 691,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 686,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                handleOpenAddModal();
                setFormData((prev) => ({ ...prev, panchayatId: activePanchayat?.id || "", villageName: "" }));
              },
              className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-3.5 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Add Student" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 698,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 693,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleBackToPanchayats,
              className: "inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
              children: /* @__PURE__ */ jsxDEV("span", { children: "Back" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 705,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 700,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 685,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 661,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5", children: activePanchayat.villages.map((village) => {
        const vStudents = panchayatStudents.filter(
          (s) => s.villageName.toLowerCase() === village.name.toLowerCase() || s.villageId === village.id
        );
        const vBoys = vStudents.filter((s) => s.gender === "male").length;
        const vGirls = vStudents.filter((s) => s.gender === "female").length;
        const std9 = vStudents.filter((s) => s.standard === "9").length;
        const std10 = vStudents.filter((s) => s.standard === "10").length;
        const std11 = vStudents.filter((s) => s.standard === "11").length;
        const std12 = vStudents.filter((s) => s.standard === "12").length;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => handleSelectVillage(village.name),
            className: "group rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition-all hover:border-brand-300 dark:border-gray-800 dark:bg-white/[0.02] dark:hover:border-brand-800 flex flex-col justify-between cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-semibold uppercase text-gray-400 block", children: "Village" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 733,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900 dark:text-white group-hover:text-brand-500 transition-colors mt-0.5", children: village.name }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 734,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 732,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
                    vStudents.length,
                    " Students"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 738,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 731,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 rounded-xl bg-gray-50/80 p-2.5 text-xs dark:bg-white/[0.02]", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "👦" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 745,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400 uppercase font-semibold", children: "Boys" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 747,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-gray-900 dark:text-white", children: vBoys }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 748,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 746,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 744,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "👧" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 752,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[10px] text-gray-400 uppercase font-semibold", children: "Girls" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 754,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-gray-900 dark:text-white", children: vGirls }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 755,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 753,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 751,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 743,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] font-semibold uppercase text-gray-400 mb-1.5", children: "Standard Distribution" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 761,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-1.5 text-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-gray-200 p-1 dark:border-gray-700", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-gray-400 font-bold", children: "9th" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 764,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-brand-500", children: std9 }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 765,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 763,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-gray-200 p-1 dark:border-gray-700", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-gray-400 font-bold", children: "10th" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 768,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-brand-500", children: std10 }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 769,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 767,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-gray-200 p-1 dark:border-gray-700", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-gray-400 font-bold", children: "11th" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 772,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-brand-500", children: std11 }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 773,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 771,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "rounded-lg border border-gray-200 p-1 dark:border-gray-700", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-[9px] text-gray-400 font-bold", children: "12th" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 776,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-bold text-brand-500", children: std12 }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 777,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 775,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 762,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 760,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 730,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs font-bold text-brand-500 group-hover:translate-x-0.5 transition-transform", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Open Student Roster" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 784,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "arrow_forward" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 785,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 783,
                columnNumber: 17
              }, this)
            ]
          },
          village.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 725,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 711,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 659,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-1", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleBackToPanchayats,
              className: "hover:text-brand-500 font-semibold",
              children: "Panchayats"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 804,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 811,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleBackToVillages,
              className: "hover:text-brand-500 font-semibold",
              children: activePanchayat?.name
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 812,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 819,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 dark:text-white", children: selectedVillageName }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 820,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 803,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: [
            selectedVillageName,
            " Roster"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 824,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            filteredRosterStudents.length,
            " Students"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 827,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 823,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: [
          activePanchayat?.name,
          " Panchayat · Standards 9 to 12"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 831,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 802,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setImportPanchayatId(activePanchayat?.id || "");
              setImportVillageName(selectedVillageName || "");
              setShowImportModal(true);
            },
            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Import Excel" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 842,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 837,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleOpenAddModal,
            className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-3.5 py-2 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Add Student" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 849,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 844,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleBackToVillages,
            className: "inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 transition",
            children: /* @__PURE__ */ jsxDEV("span", { children: "Villages" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 856,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 851,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 836,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 801,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-sm", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-[18px] pointer-events-none", children: "search" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 864,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            placeholder: "Search student by name or code...",
            value: globalSearch,
            onChange: (e) => setGlobalSearch(e.target.value),
            className: "w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 py-2 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/10 dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:placeholder:text-gray-500"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 867,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 863,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 overflow-x-auto", children: ["", "9", "10", "11", "12"].map(
          (std) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setSelectedStd(std),
              className: `rounded-lg px-3 py-1.5 text-xs font-medium transition ${selectedStd === std ? "bg-brand-500 text-white shadow-theme-xs" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"}`,
              children: std === "" ? "All (9-12)" : `Std ${std}`
            },
            std,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 879,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 877,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 border-l border-gray-200 pl-2 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setViewMode("split"),
              className: `rounded-lg px-2.5 py-1.5 text-xs font-medium transition ${viewMode === "split" ? "bg-brand-500 text-white shadow-theme-xs" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"}`,
              children: "Split"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 895,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setViewMode("all"),
              className: `rounded-lg px-2.5 py-1.5 text-xs font-medium transition ${viewMode === "all" ? "bg-brand-500 text-white shadow-theme-xs" : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"}`,
              children: "Table"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 906,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 894,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 876,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 862,
      columnNumber: 7
    }, this),
    viewMode === "split" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02] flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg", children: "👦" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 928,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm", children: "Boys Roster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 929,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 927,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
            boyStudents.length,
            " Boys"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 931,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 926,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-gray-100 dark:divide-gray-800/60 p-2 flex-1 overflow-y-auto max-h-[560px]", children: boyStudents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center text-gray-400 text-xs", children: "No boys enrolled in this selection." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 938,
          columnNumber: 13
        }, this) : boyStudents.map(
          (student) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setViewingStudent(student),
              className: "p-3 hover:bg-gray-50/80 rounded-xl transition-all flex items-center justify-between gap-3 cursor-pointer group dark:hover:bg-white/[0.02]",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full bg-brand-50 text-brand-500 flex items-center justify-center font-bold text-xs flex-shrink-0 dark:bg-brand-500/10 dark:text-brand-400", children: student.avatarLetter }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 949,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white group-hover:text-brand-500", children: student.name }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 954,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: [
                        "Std ",
                        student.standard
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 957,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 953,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-0.5", children: [
                      "Parent: ",
                      student.parentName || "N/A",
                      " · ",
                      student.phone
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 961,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 952,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 948,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", onClick: (e) => e.stopPropagation(), children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleEditStudent(student),
                      className: "p-1 text-gray-400 hover:text-brand-500 rounded",
                      title: "Edit Student",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 974,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 968,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setStudentToDelete(student),
                      className: "p-1 text-gray-400 hover:text-error-500 rounded",
                      title: "Delete Student",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "delete" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 982,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 976,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 967,
                  columnNumber: 21
                }, this)
              ]
            },
            student.id,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 943,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 936,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 925,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02] flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg", children: "👧" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 995,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-gray-900 dark:text-white text-sm", children: "Girls Roster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 996,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 994,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: [
            girlStudents.length,
            " Girls"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 998,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 993,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-gray-100 dark:divide-gray-800/60 p-2 flex-1 overflow-y-auto max-h-[560px]", children: girlStudents.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center text-gray-400 text-xs", children: "No girls enrolled in this selection." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1005,
          columnNumber: 13
        }, this) : girlStudents.map(
          (student) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setViewingStudent(student),
              className: "p-3 hover:bg-gray-50/80 rounded-xl transition-all flex items-center justify-between gap-3 cursor-pointer group dark:hover:bg-white/[0.02]",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full bg-orange-50 text-orange-500 flex items-center justify-center font-bold text-xs flex-shrink-0 dark:bg-orange-500/10 dark:text-orange-400", children: student.avatarLetter }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1016,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white group-hover:text-orange-500", children: student.name }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1021,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(Badge, { color: "light", size: "sm", children: [
                        "Std ",
                        student.standard
                      ] }, void 0, true, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1024,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1020,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400 mt-0.5", children: [
                      "Parent: ",
                      student.parentName || "N/A",
                      " · ",
                      student.phone
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1028,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1019,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1015,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", onClick: (e) => e.stopPropagation(), children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleEditStudent(student),
                      className: "p-1 text-gray-400 hover:text-brand-500 rounded",
                      title: "Edit Student",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1041,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1035,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => setStudentToDelete(student),
                      className: "p-1 text-gray-400 hover:text-error-500 rounded",
                      title: "Delete Student",
                      children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "delete" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1049,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1043,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1034,
                  columnNumber: 21
                }, this)
              ]
            },
            student.id,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1010,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1003,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 992,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 923,
      columnNumber: 7
    }, this),
    (viewMode === "all" || viewMode === "boys" || viewMode === "girls") && /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.02]", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-white/[0.02] dark:text-gray-400", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Code" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1066,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Student Name" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1067,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Gender" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1068,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Standard" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1069,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Parent / Guardian" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1070,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Phone" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1071,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5", children: "Status" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1072,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "px-5 py-3.5 text-right", children: "Actions" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1073,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1065,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1064,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-100 dark:divide-gray-800 text-xs", children: (viewMode === "boys" ? boyStudents : viewMode === "girls" ? girlStudents : filteredRosterStudents).length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 8, className: "px-5 py-12 text-center text-gray-400", children: "No students found matching the selected filters." }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1080,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1079,
        columnNumber: 13
      }, this) : (viewMode === "boys" ? boyStudents : viewMode === "girls" ? girlStudents : filteredRosterStudents).map(
        (student) => /* @__PURE__ */ jsxDEV(
          "tr",
          {
            onClick: () => setViewingStudent(student),
            className: "hover:bg-gray-50/80 dark:hover:bg-white/[0.02] transition-colors cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 font-mono text-gray-400", children: student.code }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1092,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 font-bold text-gray-900 dark:text-white", children: student.name }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1093,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: /* @__PURE__ */ jsxDEV(Badge, { color: student.gender === "male" ? "primary" : "warning", size: "sm", children: student.gender === "male" ? "👦 Boy" : "👧 Girl" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1095,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1094,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-gray-700 dark:text-gray-300 font-medium", children: [
                student.standard,
                "th Standard"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1099,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-gray-500 dark:text-gray-400", children: student.parentName || "—" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1102,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 font-mono text-gray-500 dark:text-gray-400", children: student.phone }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1103,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5", children: /* @__PURE__ */ jsxDEV(Badge, { color: student.status === "active" ? "success" : "light", size: "sm", children: student.status === "active" ? "Active" : "Inactive" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1105,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1104,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "px-5 py-3.5 text-right", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-1", onClick: (e) => e.stopPropagation(), children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => handleEditStudent(student),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-gray-100 hover:text-brand-500 dark:hover:bg-white/5 dark:hover:text-brand-400 transition",
                    title: "Edit",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1117,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1111,
                    columnNumber: 27
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setStudentToDelete(student),
                    className: "rounded-lg p-1.5 text-gray-400 hover:bg-error-50 hover:text-error-600 dark:hover:bg-error-500/10 dark:hover:text-error-400 transition",
                    title: "Delete",
                    children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "delete" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1125,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1119,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1110,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1109,
                columnNumber: 23
              }, this)
            ]
          },
          student.id,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1087,
            columnNumber: 15
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1076,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1063,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1062,
      columnNumber: 7
    }, this),
    showAddModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex justify-end", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm transition-opacity",
          onClick: () => setShowAddModal(false)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1145,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-md bg-white shadow-sm flex flex-col h-full z-10 animate-[fadeIn_0.2s_ease-out]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-[#c4c6d3] flex items-center justify-between bg-[#f4f3fb]", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-[17px] font-bold text-[#002869] flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "person_add" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1153,
              columnNumber: 17
            }, this),
            editingStudent ? "Edit Student" : "Add New Student"
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1152,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowAddModal(false),
              className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-full transition-colors cursor-pointer",
              children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1160,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1156,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1151,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSaveStudent, className: "flex-1 overflow-y-auto p-6 space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 bg-gray-50 dark:bg-white/[0.02] border border-gray-200 dark:border-gray-800 rounded-xl p-3.5 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1", children: "Target Panchayat *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1168,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: formData.panchayatId || (panchayats[0]?.id ?? void 0),
                  onValueChange: (val) => setFormData({ ...formData, panchayatId: val, villageName: "" }),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1174,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1173,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                      (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1178,
                        columnNumber: 21
                      }, this)
                    ) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1176,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1169,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1167,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1", children: "Target Village *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1184,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: formData.villageName || (panchayats.find((p) => p.id === formData.panchayatId)?.villages[0]?.name ?? void 0),
                  onValueChange: (val) => setFormData({ ...formData, villageName: val }),
                  disabled: !formData.panchayatId,
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "h-9 text-xs", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Village" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1191,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1190,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.find((p) => p.id === formData.panchayatId)?.villages.map(
                      (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1195,
                        columnNumber: 21
                      }, this)
                    ) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1193,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1185,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1183,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1166,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Student Full Name *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1202,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                required: true,
                placeholder: "Enter student name",
                value: formData.name,
                onChange: (e) => setFormData({ ...formData, name: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md text-[13px] focus:outline-none focus:border-[#002869] h-[38px]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1203,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1201,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Gender *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1215,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setFormData({ ...formData, gender: "male" }),
                  className: `py-2 px-3 rounded-md border text-[13px] font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${formData.gender === "male" ? "bg-[#dae2ff] border-[#002869] text-[#001947]" : "border-[#c4c6d3] bg-white text-[#434652] hover:bg-[#f4f3fb]"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "ðŸ‘¦" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1226,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Boy / Male" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1227,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1217,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => setFormData({ ...formData, gender: "female" }),
                  className: `py-2 px-3 rounded-md border text-[13px] font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${formData.gender === "female" ? "bg-[#ffdbc8] border-[#fb7800] text-[#592600]" : "border-[#c4c6d3] bg-white text-[#434652] hover:bg-[#f4f3fb]"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "ðŸ‘§" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1239,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Girl / Female" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1240,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1230,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1216,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1214,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Standard (Class) *" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1248,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: formData.standard,
                  onValueChange: (val) => setFormData({ ...formData, standard: val }),
                  children: [
                    /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-[38px] text-[13px] border-[#c4c6d3] font-bold text-[#002869]", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Standard" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1254,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1253,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "9", children: "9th Standard" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1257,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "10", children: "10th Standard" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1258,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "11", children: "11th Standard" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1259,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(SelectItem, { value: "12", children: "12th Standard" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                        lineNumber: 1260,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1256,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1249,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1247,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Date of Birth" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1266,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: formData.dob,
                  onChange: (e) => setFormData({ ...formData, dob: e.target.value }),
                  className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md text-[13px] focus:outline-none focus:border-[#002869] h-[38px]"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1267,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1265,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1246,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Parent / Guardian Name" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1277,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Enter parent or guardian name",
                value: formData.parentName,
                onChange: (e) => setFormData({ ...formData, parentName: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md text-[13px] focus:outline-none focus:border-[#002869] h-[38px]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1278,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1276,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Contact Phone Number" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1288,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "tel",
                placeholder: "+91 98765 43210",
                value: formData.phone,
                onChange: (e) => setFormData({ ...formData, phone: e.target.value }),
                className: "w-full px-3 py-2 bg-white border border-[#c4c6d3] rounded-md text-[13px] focus:outline-none focus:border-[#002869] h-[38px]"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1289,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1287,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Enrollment Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1299,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: formData.status,
                onValueChange: (val) => setFormData({ ...formData, status: val }),
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-[38px] text-[13px] border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Status" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1305,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1304,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: [
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "active", children: "Active" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1308,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(SelectItem, { value: "inactive", children: "Inactive" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1309,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1307,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1300,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1298,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-[#c4c6d3] bg-[#faf8ff] flex justify-end gap-3 -mx-6 -mb-6 mt-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setShowAddModal(false),
                className: "px-4 py-2 border border-[#747783] text-[#434652] font-bold text-[13px] rounded-md hover:bg-[#f4f3fb] cursor-pointer",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1315,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "px-5 py-2 bg-[#002869] text-white font-bold text-[13px] rounded-md hover:bg-[#0b3d91] transition-colors shadow-xs cursor-pointer",
                children: editingStudent ? "Update Student" : "Save Student"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1322,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1314,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1164,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1150,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1144,
      columnNumber: 7
    }, this),
    showImportModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-gray-900/75 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md shadow-sm w-full max-w-2xl overflow-hidden animate-[fadeIn_0.2s_ease-out] flex flex-col max-h-[90vh]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-[#c4c6d3] flex justify-between items-center bg-[#f4f3fb]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-md bg-[#002869] text-white flex items-center justify-center font-bold", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "table_view" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1343,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1342,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-bold text-[#002869]", children: "Bulk Import Students via Excel" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1346,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-[#434652]", children: "Upload and automatically enroll students into a village." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1347,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1345,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1341,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowImportModal(false);
              setImportRows([]);
              setImportFileName("");
            },
            className: "p-1.5 text-[#434652] hover:bg-[#e8e7ef] rounded-full cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1360,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1352,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1340,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 space-y-5 flex-1 overflow-y-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 bg-[#f4f3fb] border border-[#c4c6d3]/60 rounded-md p-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Target Panchayat *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1368,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: importPanchayatId,
                onValueChange: (val) => {
                  setImportPanchayatId(val);
                  setImportVillageName("");
                },
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-[38px] text-[13px] border-[#c4c6d3] bg-white", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Panchayat" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1377,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1376,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: panchayats.map(
                    (p) => /* @__PURE__ */ jsxDEV(SelectItem, { value: p.id, children: p.name }, p.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1381,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1379,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1369,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1367,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-[12px] font-bold text-[#002869] mb-1", children: "Target Village *" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1389,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: importVillageName,
                onValueChange: (val) => setImportVillageName(val),
                disabled: !importPanchayatId,
                children: [
                  /* @__PURE__ */ jsxDEV(SelectTrigger, { className: "w-full h-[38px] text-[13px] border-[#c4c6d3] bg-white disabled:opacity-50", children: /* @__PURE__ */ jsxDEV(SelectValue, { placeholder: "Select Village" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1396,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1395,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(SelectContent, { children: (panchayats.find((p) => p.id === importPanchayatId)?.villages || []).map(
                    (v) => /* @__PURE__ */ jsxDEV(SelectItem, { value: v.name, children: v.name }, v.id, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                      lineNumber: 1400,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                    lineNumber: 1398,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1390,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1388,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1366,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 bg-[#f4f3fb] border border-[#c4c6d3]/60 rounded-md", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-[13px] font-bold text-[#002869]", children: "Need the Excel Format?" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1412,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-[11px] text-[#434652]", children: "Download the pre-formatted Excel template with 9th-12th standards." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1413,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1411,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: handleDownloadSampleExcel,
              className: "flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#002869] text-[#002869] rounded-md text-[12px] font-bold hover:bg-[#dae2ff]/30 transition-colors cursor-pointer whitespace-nowrap",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "download" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1422,
                  columnNumber: 19
                }, this),
                "Download Template (.xlsx)"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1417,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1410,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => fileInputRef.current?.click(),
            className: "border-2 border-dashed border-[#002869]/40 hover:border-[#002869] rounded-md p-6 text-center cursor-pointer bg-[#faf8ff] hover:bg-[#f4f3fb] transition-all group",
            children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "file",
                  ref: fileInputRef,
                  onChange: handleFileUpload,
                  accept: ".xlsx, .xls, .csv",
                  className: "hidden"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1432,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#dae2ff] text-[#002869] flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[24px]", children: "cloud_upload" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1440,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1439,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-[14px] font-bold text-[#002869]", children: importFileName ? importFileName : "Click to select Excel / CSV file" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1442,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#747783] mt-1", children: "Supports .xlsx, .xls, and .csv formats" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1445,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1428,
            columnNumber: 15
          },
          this
        ),
        isParsingFile && /* @__PURE__ */ jsxDEV("div", { className: "p-4 text-center text-[#002869] font-bold text-[13px] flex items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined animate-spin text-[20px]", children: "progress_activity" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1451,
            columnNumber: 19
          }, this),
          "Parsing Excel data and validating standards 9 to 12..."
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1450,
          columnNumber: 13
        }, this),
        importRows.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-[12px]", children: /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-[#002869] flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { children: [
              "Parsed ",
              importRows.length,
              " Student Rows:"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1461,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-[#e6f4ea] text-[#137333] px-2 py-0.5 rounded font-bold", children: [
              importRows.filter((r) => r.isValid).length,
              " Valid"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1462,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1460,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1459,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border border-[#c4c6d3] rounded-md overflow-hidden max-h-[220px] overflow-y-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse text-[12px]", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-[#f4f3fb] text-[#434652] uppercase text-[10px] font-bold sticky top-0 border-b border-[#c4c6d3]", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Name" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1472,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Gender" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1473,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Standard" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1474,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Parent" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1475,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Phone" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1476,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2", children: "Status" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1477,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1471,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1470,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-[#c4c6d3]/40 bg-white", children: importRows.map(
              (r, idx) => /* @__PURE__ */ jsxDEV("tr", { className: r.isValid ? "" : "bg-[#ffdad6]/20", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5 font-bold text-[#002869]", children: r.name || "â€”" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1483,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5 capitalize", children: r.gender }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1484,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5 font-bold", children: [
                  r.standard,
                  "th Std"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1485,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5 text-[#434652]", children: r.parentName || "â€”" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1486,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5 text-[#434652]", children: r.phone }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1487,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-1.5", children: r.isValid ? /* @__PURE__ */ jsxDEV("span", { className: "text-[#137333] font-bold", children: "Ready" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1490,
                  columnNumber: 25
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-[#ba1a1a] font-bold", children: r.validationError }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1492,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1488,
                  columnNumber: 29
                }, this)
              ] }, idx, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1482,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1480,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1469,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1468,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1458,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1364,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-[#c4c6d3] bg-[#faf8ff] flex justify-end gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              setShowImportModal(false);
              setImportRows([]);
              setImportFileName("");
            },
            className: "px-4 py-2 text-[13px] font-bold text-[#434652] border border-[#747783] rounded-md hover:bg-[#f4f3fb] cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1505,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            disabled: importRows.length === 0 || importRows.filter((r) => r.isValid).length === 0,
            onClick: handleConfirmBulkImport,
            className: `px-5 py-2 text-[13px] font-bold rounded-md transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer ${importRows.length > 0 && importRows.filter((r) => r.isValid).length > 0 ? "bg-[#002869] text-white hover:bg-[#0b3d91]" : "bg-[#c4c6d3] text-white cursor-not-allowed"}`,
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px]", children: "check" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1526,
                columnNumber: 17
              }, this),
              "Confirm & Import ",
              importRows.filter((r) => r.isValid).length,
              " Students"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1516,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1504,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1339,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1338,
      columnNumber: 7
    }, this),
    viewingStudent && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-gray-900/75 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md shadow-sm w-full max-w-md overflow-hidden animate-[fadeIn_0.2s_ease-out]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-[#c4c6d3] flex justify-between items-center bg-[#f4f3fb]", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-bold text-[#002869] flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "badge" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1542,
            columnNumber: 17
          }, this),
          "Student Profile"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1541,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setViewingStudent(null),
            className: "p-1 rounded-full text-[#434652] hover:bg-[#e8e7ef] cursor-pointer",
            children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[20px]", children: "close" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1549,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1545,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1540,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `w-14 h-14 rounded-full flex items-center justify-center font-bold text-[20px] ${viewingStudent.gender === "male" ? "bg-[#002869] text-white" : "bg-[#fb7800] text-white"}`,
              children: viewingStudent.avatarLetter
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1555,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-[18px] font-bold text-[#002869]", children: viewingStudent.name }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1563,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[12px] text-[#747783]", children: viewingStudent.code }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1564,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-1", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold ${viewingStudent.gender === "male" ? "bg-[#dae2ff] text-[#001947]" : "bg-[#ffdbc8] text-[#592600]"}`,
                  children: viewingStudent.gender === "male" ? "ðŸ‘¦ Male / Boy" : "ðŸ‘§ Female / Girl"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1566,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold ${viewingStudent.status === "active" ? "bg-[#e6f4ea] text-[#137333]" : "bg-[#ffdad6] text-[#ba1a1a]"}`,
                  children: viewingStudent.status === "active" ? "Active" : "Inactive"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1575,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1565,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1562,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1554,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 pt-2 text-[13px] border-t border-[#c4c6d3]/40", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Standard" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1590,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-[#002869]", children: [
              viewingStudent.standard,
              "th Standard"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1591,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1589,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Gender" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1594,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "capitalize font-bold", children: viewingStudent.gender }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1595,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1593,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Panchayat" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1598,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: viewingStudent.panchayatName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1599,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1597,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Village" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1602,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: viewingStudent.villageName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1603,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1601,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Parent / Guardian" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1606,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: viewingStudent.parentName || "N/A" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1607,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1605,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-[#747783] text-[11px] font-semibold uppercase block", children: "Contact Phone" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1610,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: viewingStudent.phone || "N/A" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1611,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1609,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1588,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1553,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-[#c4c6d3] bg-[#faf8ff] flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => {
              const toDelete = viewingStudent;
              setViewingStudent(null);
              setStudentToDelete(toDelete);
            },
            className: "px-3.5 py-2 bg-[#ffdad6] text-[#ba1a1a] rounded-md text-[12.5px] font-bold hover:bg-[#ffdad6]/80 flex items-center gap-1.5 cursor-pointer",
            children: [
              /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "delete" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                lineNumber: 1626,
                columnNumber: 17
              }, this),
              "Delete Student"
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1617,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setViewingStudent(null),
              className: "px-3.5 py-2 bg-white border border-[#c4c6d3] text-[#434652] rounded-md text-[12.5px] font-bold hover:bg-[#f4f3fb] cursor-pointer",
              children: "Close"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1631,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                const toEdit = viewingStudent;
                setViewingStudent(null);
                handleEditStudent(toEdit);
              },
              className: "px-4 py-2 bg-[#002869] text-white rounded-md text-[12.5px] font-bold cursor-pointer hover:bg-[#0b3d91] flex items-center gap-1.5 shadow-xs",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "edit" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
                  lineNumber: 1647,
                  columnNumber: 19
                }, this),
                "Edit Student"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
              lineNumber: 1638,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1630,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1616,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1539,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1538,
      columnNumber: 7
    }, this),
    studentToDelete && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-gray-900/75 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 animate-[fadeIn_0.15s_ease-out]", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-md max-w-sm w-full overflow-hidden shadow-sm border border-[#c4c6d3] p-6 space-y-4 text-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-[#ffdad6] text-[#ba1a1a] flex items-center justify-center mx-auto", children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[26px]", children: "delete_forever" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1663,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1662,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-[17px] font-bold text-[#ba1a1a]", children: "Delete Student?" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1666,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[13px] text-[#434652] mt-1.5 leading-relaxed", children: [
          "Are you sure you want to delete ",
          /* @__PURE__ */ jsxDEV("strong", { className: "text-[#1a1b21]", children: studentToDelete.name }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1668,
            columnNumber: 49
          }, this),
          " (",
          studentToDelete.standard,
          "th Std) from ",
          studentToDelete.villageName,
          "?"
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1667,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1665,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2 pt-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setStudentToDelete(null),
            className: "flex-1 py-2 bg-white border border-[#c4c6d3] rounded-md text-[13px] font-bold text-[#434652] hover:bg-[#f4f3fb] cursor-pointer",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1672,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: handleConfirmDeleteStudent,
            className: "flex-1 py-2 bg-[#ba1a1a] text-white rounded-md text-[13px] font-bold hover:bg-[#93000a] transition-colors shadow-xs cursor-pointer",
            children: "Yes, Delete"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1679,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1671,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1661,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1660,
      columnNumber: 7
    }, this),
    toastMessage && /* @__PURE__ */ jsxDEV("div", { className: "fixed bottom-6 right-6 z-[200] bg-[#002869] text-white px-4 py-3 rounded-md shadow-sm flex items-center gap-2 text-[13px] font-bold animate-[slideUp_0.2s_ease-out] border border-white/20", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[18px] text-[#80bdff]", children: "check_circle" }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1694,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: toastMessage }, void 0, false, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
        lineNumber: 1695,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setToastMessage(null),
          className: "ml-2 text-white/70 hover:text-white cursor-pointer",
          children: /* @__PURE__ */ jsxDEV("span", { className: "material-symbols-outlined text-[16px]", children: "close" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
            lineNumber: 1700,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
          lineNumber: 1696,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
      lineNumber: 1693,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx",
    lineNumber: 799,
    columnNumber: 5
  }, this);
};
_s(StudentsView, "xSJew5+PyRRw/K1T2ehL2HER4G4=");
_c = StudentsView;
var _c;
$RefreshReg$(_c, "StudentsView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/StudentsView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbWVjOztBQW5lZCxTQUFnQkEsVUFBVUMsU0FBU0MsV0FBV0MsY0FBYztBQUM1RCxZQUFZQyxVQUFVO0FBRXRCLFNBQVNDLGFBQWE7QUFDdEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBNEJBLGFBQU1DLGVBQTRDQSxDQUFDO0FBQUEsRUFDeERDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBRUosUUFBTSxDQUFDQyxxQkFBcUJDLHNCQUFzQixJQUFJdEIsU0FBd0IsSUFBSTtBQUNsRixRQUFNLENBQUN1QixxQkFBcUJDLHNCQUFzQixJQUFJeEIsU0FBd0IsSUFBSTtBQUdsRixRQUFNLENBQUN5QixjQUFjQyxlQUFlLElBQUkxQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDMkIsYUFBYUMsY0FBYyxJQUFJNUIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzZCLFVBQVVDLFdBQVcsSUFBSTlCLFNBQW1CLE9BQU87QUFHMUQsUUFBTSxDQUFDK0IsY0FBY0MsZUFBZSxJQUFJaEMsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2lDLGlCQUFpQkMsa0JBQWtCLElBQUlsQyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDbUMsZ0JBQWdCQyxpQkFBaUIsSUFBSXBDLFNBQXlCLElBQUk7QUFDekUsUUFBTSxDQUFDcUMsZ0JBQWdCQyxpQkFBaUIsSUFBSXRDLFNBQXlCLElBQUk7QUFDekUsUUFBTSxDQUFDdUMsaUJBQWlCQyxrQkFBa0IsSUFBSXhDLFNBQXlCLElBQUk7QUFDM0UsUUFBTSxDQUFDeUMsY0FBY0MsZUFBZSxJQUFJMUMsU0FBd0IsSUFBSTtBQUVwRSxRQUFNMkMsWUFBWUEsQ0FBQ0MsUUFBZ0I7QUFDakNGLG9CQUFnQkUsR0FBRztBQUNuQkMsZUFBVyxNQUFNO0FBQ2ZILHNCQUFnQixJQUFJO0FBQUEsSUFDdEIsR0FBRyxHQUFJO0FBQUEsRUFDVDtBQUVBLFFBQU1JLDZCQUE2QkEsTUFBTTtBQUN2QyxRQUFJLENBQUNQLGdCQUFpQjtBQUN0QixVQUFNUSxRQUFRUixnQkFBZ0JTO0FBQzlCN0Isb0JBQWdCb0IsZ0JBQWdCVSxFQUFFO0FBQ2xDLFFBQUlaLGdCQUFnQlksT0FBT1YsZ0JBQWdCVSxJQUFJO0FBQzdDWCx3QkFBa0IsSUFBSTtBQUFBLElBQ3hCO0FBQ0FLLGNBQVUsV0FBV0ksS0FBSyx1QkFBdUI7QUFDakRQLHVCQUFtQixJQUFJO0FBQUEsRUFDekI7QUFHQSxRQUFNLENBQUNVLFlBQVlDLGFBQWEsSUFBSW5ELFNBQTZCLEVBQUU7QUFDbkUsUUFBTSxDQUFDb0QsZ0JBQWdCQyxpQkFBaUIsSUFBSXJELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNzRCxlQUFlQyxnQkFBZ0IsSUFBSXZELFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN3RCxzQkFBc0JDLHVCQUF1QixJQUFJekQsU0FBd0IsSUFBSTtBQUNwRixRQUFNLENBQUMwRCxtQkFBbUJDLG9CQUFvQixJQUFJM0QsU0FBaUIsRUFBRTtBQUNyRSxRQUFNLENBQUM0RCxtQkFBbUJDLG9CQUFvQixJQUFJN0QsU0FBaUIsRUFBRTtBQUNyRSxRQUFNOEQsZUFBZTNELE9BQXlCLElBQUk7QUFHbERELFlBQVUsTUFBTTtBQUNkLFFBQUlZLGdCQUFnQmlELGFBQWE7QUFDL0J6Qyw2QkFBdUJSLGVBQWVpRCxXQUFXO0FBQ2pELFVBQUlqRCxlQUFla0QsV0FBVztBQUM1QixjQUFNQyxNQUFNcEQsV0FBV3FELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRWxCLE9BQU9uQyxlQUFlaUQsV0FBVztBQUN0RSxjQUFNSyxPQUFPSCxLQUFLSSxTQUFTSCxLQUFLLENBQUNJLE1BQU1BLEVBQUVyQixPQUFPbkMsZUFBZWtELGFBQWFNLEVBQUV0QixTQUFTbEMsZUFBZWtELFNBQVM7QUFDL0csWUFBSUksTUFBTTtBQUNSNUMsaUNBQXVCNEMsS0FBS3BCLElBQUk7QUFBQSxRQUNsQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNsQyxnQkFBZ0JELFVBQVUsQ0FBQztBQUcvQixRQUFNMEQsa0JBQWtCdEUsUUFBUSxNQUFNO0FBQ3BDLFdBQU9ZLFdBQVdxRCxLQUFLLENBQUNDLE1BQU1BLEVBQUVsQixPQUFPNUIsbUJBQW1CLEtBQUs7QUFBQSxFQUNqRSxHQUFHLENBQUNSLFlBQVlRLG1CQUFtQixDQUFDO0FBRXBDLFFBQU1tRCxnQkFBZ0J2RSxRQUFRLE1BQU07QUFDbEMsUUFBSSxDQUFDc0UsbUJBQW1CLENBQUNoRCxvQkFBcUIsUUFBTztBQUNyRCxXQUNFZ0QsZ0JBQWdCRixTQUFTSDtBQUFBQSxNQUN2QixDQUFDSSxNQUFNQSxFQUFFdEIsS0FBS3lCLFlBQVksTUFBTWxELG9CQUFvQmtELFlBQVksS0FBS0gsRUFBRXJCLE9BQU8xQjtBQUFBQSxJQUNoRixLQUFLO0FBQUEsRUFFVCxHQUFHLENBQUNnRCxpQkFBaUJoRCxtQkFBbUIsQ0FBQztBQUl6QyxRQUFNLENBQUNtRCxVQUFVQyxXQUFXLElBQUkzRSxTQUFTO0FBQUEsSUFDdkNnRCxNQUFNO0FBQUEsSUFDTjRCLFFBQVE7QUFBQSxJQUNSQyxLQUFLO0FBQUEsSUFDTEMsVUFBVTtBQUFBO0FBQUEsSUFDVkMsWUFBWTtBQUFBLElBQ1pDLE9BQU87QUFBQSxJQUNQQyxRQUFRO0FBQUEsSUFDUmxCLGFBQWE7QUFBQSxJQUNibUIsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUdELFFBQU1DLGtCQUFrQmxGLFFBQVEsTUFBTTtBQUNwQyxRQUFJLENBQUNzRSxtQkFBbUIsQ0FBQ2hELG9CQUFxQixRQUFPO0FBQ3JELFdBQU9YLFNBQVN3RTtBQUFBQSxNQUNkLENBQUNDLE9BQ0VBLEVBQUV0QixnQkFBZ0JRLGdCQUFnQnRCLE1BQU1vQyxFQUFFQyxjQUFjYixZQUFZLE1BQU1GLGdCQUFnQnZCLEtBQUt5QixZQUFZLE9BQzNHWSxFQUFFSCxZQUFZVCxZQUFZLE1BQU1sRCxvQkFBb0JrRCxZQUFZLEtBQUtZLEVBQUVyQixjQUFjUSxlQUFldkI7QUFBQUEsSUFDekc7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JDLFVBQVUyRCxpQkFBaUJoRCxxQkFBcUJpRCxhQUFhLENBQUM7QUFFbEUsUUFBTWUseUJBQXlCdEYsUUFBUSxNQUFNO0FBQzNDLFdBQU9rRixnQkFBZ0JDLE9BQU8sQ0FBQ0MsTUFBTTtBQUNuQyxZQUFNRyxjQUNKSCxFQUFFckMsS0FBS3lCLFlBQVksRUFBRWdCLFNBQVNoRSxhQUFhZ0QsWUFBWSxDQUFDLEtBQ3hEWSxFQUFFSyxLQUFLakIsWUFBWSxFQUFFZ0IsU0FBU2hFLGFBQWFnRCxZQUFZLENBQUMsS0FDeERZLEVBQUVOLFdBQVdOLFlBQVksRUFBRWdCLFNBQVNoRSxhQUFhZ0QsWUFBWSxDQUFDLEtBQzlEWSxFQUFFTCxNQUFNUyxTQUFTaEUsWUFBWTtBQUUvQixZQUFNa0UsV0FBVyxDQUFDaEUsZUFBZTBELEVBQUVQLGFBQWFuRDtBQUNoRCxhQUFPNkQsZUFBZUc7QUFBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDUixpQkFBaUIxRCxjQUFjRSxXQUFXLENBQUM7QUFHL0MsUUFBTWlFLGNBQWMzRixRQUFRLE1BQU1zRix1QkFBdUJILE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVQsV0FBVyxNQUFNLEdBQUcsQ0FBQ1csc0JBQXNCLENBQUM7QUFDckgsUUFBTU0sZUFBZTVGLFFBQVEsTUFBTXNGLHVCQUF1QkgsT0FBTyxDQUFDQyxNQUFNQSxFQUFFVCxXQUFXLFFBQVEsR0FBRyxDQUFDVyxzQkFBc0IsQ0FBQztBQUd4SCxRQUFNTyx1QkFBdUJsRixTQUFTbUY7QUFDdEMsUUFBTUMsY0FBY3BGLFNBQVN3RSxPQUFPLENBQUNDLE1BQU1BLEVBQUVULFdBQVcsTUFBTSxFQUFFbUI7QUFDaEUsUUFBTUUsZUFBZXJGLFNBQVN3RSxPQUFPLENBQUNDLE1BQU1BLEVBQUVULFdBQVcsUUFBUSxFQUFFbUI7QUFHbkUsUUFBTUcsd0JBQXdCQSxDQUFDbkMsZ0JBQXdCO0FBQ3JEekMsMkJBQXVCeUMsV0FBVztBQUNsQ3ZDLDJCQUF1QixJQUFJO0FBQzNCRSxvQkFBZ0IsRUFBRTtBQUNsQkUsbUJBQWUsRUFBRTtBQUFBLEVBQ25CO0FBRUEsUUFBTXVFLHNCQUFzQkEsQ0FBQ2pCLGdCQUF3QjtBQUNuRDFELDJCQUF1QjBELFdBQVc7QUFDbEN4RCxvQkFBZ0IsRUFBRTtBQUNsQkUsbUJBQWUsRUFBRTtBQUNqQkUsZ0JBQVksT0FBTztBQUFBLEVBQ3JCO0FBRUEsUUFBTXNFLHlCQUF5QkEsTUFBTTtBQUNuQzlFLDJCQUF1QixJQUFJO0FBQzNCRSwyQkFBdUIsSUFBSTtBQUMzQkUsb0JBQWdCLEVBQUU7QUFDbEJFLG1CQUFlLEVBQUU7QUFBQSxFQUNuQjtBQUVBLFFBQU15RSx1QkFBdUJBLE1BQU07QUFDakM3RSwyQkFBdUIsSUFBSTtBQUMzQkUsb0JBQWdCLEVBQUU7QUFDbEJFLG1CQUFlLEVBQUU7QUFBQSxFQUNuQjtBQUdBLFFBQU0wRSxxQkFBcUJBLE1BQU07QUFDL0JsRSxzQkFBa0IsSUFBSTtBQUN0QnVDLGdCQUFZO0FBQUEsTUFDVjNCLE1BQU07QUFBQSxNQUNONEIsUUFBUTtBQUFBLE1BQ1JDLEtBQUs7QUFBQSxNQUNMQyxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxRQUFRO0FBQUEsTUFDUmxCLGFBQWFRLGlCQUFpQnRCLE1BQU07QUFBQSxNQUNwQ2lDLGFBQWEzRCx1QkFBdUI7QUFBQSxJQUN0QyxDQUFDO0FBQ0RTLG9CQUFnQixJQUFJO0FBQUEsRUFDdEI7QUFFQSxRQUFNdUUsb0JBQW9CQSxDQUFDQyxZQUFxQjtBQUM5Q3BFLHNCQUFrQm9FLE9BQU87QUFDekI3QixnQkFBWTtBQUFBLE1BQ1YzQixNQUFNd0QsUUFBUXhEO0FBQUFBLE1BQ2Q0QixRQUFRNEIsUUFBUTVCLFdBQVcsU0FBUyxTQUFTO0FBQUEsTUFDN0NDLEtBQUsyQixRQUFRM0IsT0FBTztBQUFBLE1BQ3BCQyxVQUFVLENBQUMsS0FBSyxNQUFNLE1BQU0sSUFBSSxFQUFFVyxTQUFTZSxRQUFRMUIsUUFBUSxJQUFJMEIsUUFBUTFCLFdBQVc7QUFBQSxNQUNsRkMsWUFBWXlCLFFBQVF6QixjQUFjO0FBQUEsTUFDbENDLE9BQU93QixRQUFReEIsU0FBUztBQUFBLE1BQ3hCQyxRQUFRdUIsUUFBUXZCLFVBQVU7QUFBQSxNQUMxQmxCLGFBQWF5QyxRQUFRekMsZUFBZVEsaUJBQWlCdEIsTUFBTTtBQUFBLE1BQzNEaUMsYUFBYXNCLFFBQVF0QixlQUFlM0QsdUJBQXVCO0FBQUEsSUFDN0QsQ0FBQztBQUNEUyxvQkFBZ0IsSUFBSTtBQUFBLEVBQ3RCO0FBRUEsUUFBTXlFLG9CQUFvQkEsQ0FBQ0MsTUFBdUI7QUFDaERBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDakMsU0FBUzFCLEtBQUs0RCxLQUFLLEdBQUc7QUFDekJDLFlBQU0sMkJBQTJCO0FBQ2pDO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ25DLFNBQVNYLGVBQWUsQ0FBQ1csU0FBU1EsYUFBYTtBQUNsRDJCLFlBQU0sK0NBQStDO0FBQ3JEO0FBQUEsSUFDRjtBQUVBLFVBQU1DLGtCQUFrQmpHLFdBQVdxRCxLQUFLLENBQUFDLE1BQUtBLEVBQUVsQixPQUFPeUIsU0FBU1gsV0FBVztBQUMxRSxRQUFJLENBQUMrQyxnQkFBaUI7QUFFdEIsVUFBTUMsbUJBQW1CRCxnQkFBZ0J6QyxTQUFTSCxLQUFLLENBQUFJLE1BQUtBLEVBQUV0QixTQUFTMEIsU0FBU1EsV0FBVyxHQUFHakMsTUFBTXlCLFNBQVNRLFlBQVlULFlBQVksRUFBRXVDLFFBQVEsUUFBUSxHQUFHO0FBRTFKLFFBQUk3RSxnQkFBZ0I7QUFDbEIsVUFBSWxCLGVBQWU7QUFDakJBLHNCQUFja0IsZUFBZWMsSUFBSTtBQUFBLFVBQy9CRCxNQUFNMEIsU0FBUzFCLEtBQUs0RCxLQUFLO0FBQUEsVUFDekJoQyxRQUFRRixTQUFTRTtBQUFBQSxVQUNqQkMsS0FBS0gsU0FBU0c7QUFBQUEsVUFDZEMsVUFBVUosU0FBU0k7QUFBQUEsVUFDbkJDLFlBQVlMLFNBQVNLLFdBQVc2QixLQUFLO0FBQUEsVUFDckM1QixPQUFPTixTQUFTTSxNQUFNNEIsS0FBSztBQUFBLFVBQzNCM0IsUUFBUVAsU0FBU087QUFBQUEsUUFDbkIsQ0FBQztBQUFBLE1BQ0gsV0FBVy9ELGlCQUFpQjtBQUMxQkEsd0JBQWdCaUIsZUFBZWMsSUFBSTtBQUFBLFVBQ2pDRCxNQUFNMEIsU0FBUzFCLEtBQUs0RCxLQUFLO0FBQUEsVUFDekJoQyxRQUFRRixTQUFTRTtBQUFBQSxVQUNqQkMsS0FBS0gsU0FBU0c7QUFBQUEsVUFDZEMsVUFBVUosU0FBU0k7QUFBQUEsVUFDbkJDLFlBQVlMLFNBQVNLLFdBQVc2QixLQUFLO0FBQUEsVUFDckM1QixPQUFPTixTQUFTTSxNQUFNNEIsS0FBSztBQUFBLFVBQzNCM0IsUUFBUVAsU0FBU087QUFBQUEsUUFDbkIsQ0FBQztBQUFBLE1BQ0g7QUFDQXRDLGdCQUFVLG1CQUFtQitCLFNBQVMxQixLQUFLNEQsS0FBSyxDQUFDLEVBQUU7QUFDbkR4RSx3QkFBa0IsSUFBSTtBQUFBLElBQ3hCLE9BQU87QUFDTHJCLG1CQUFhO0FBQUEsUUFDWGlDLE1BQU0wQixTQUFTMUIsS0FBSzRELEtBQUs7QUFBQSxRQUN6QmhDLFFBQVFGLFNBQVNFO0FBQUFBLFFBQ2pCQyxLQUFLSCxTQUFTRztBQUFBQSxRQUNkQyxVQUFVSixTQUFTSTtBQUFBQSxRQUNuQmYsYUFBYVEsZ0JBQWdCdEI7QUFBQUEsUUFDN0JxQyxlQUFlZixnQkFBZ0J2QjtBQUFBQSxRQUMvQmdCLFdBQVcrQztBQUFBQSxRQUNYN0IsYUFBYTNEO0FBQUFBLFFBQ2J3RCxZQUFZTCxTQUFTSyxXQUFXNkIsS0FBSztBQUFBLFFBQ3JDNUIsT0FBT04sU0FBU00sTUFBTTRCLEtBQUs7QUFBQSxRQUMzQjNCLFFBQVFQLFNBQVNPO0FBQUFBLE1BQ25CLENBQUM7QUFDRHRDLGdCQUFVLGlCQUFpQitCLFNBQVMxQixLQUFLNEQsS0FBSyxDQUFDLGVBQWU7QUFBQSxJQUNoRTtBQUVBNUUsb0JBQWdCLEtBQUs7QUFBQSxFQUN2QjtBQU1BLFFBQU1pRiw0QkFBNEJBLE1BQU07QUFDdEMsVUFBTUMsYUFBYTtBQUFBLE1BQ2pCO0FBQUEsUUFDRSxnQkFBZ0I7QUFBQSxRQUNoQixVQUFVO0FBQUEsUUFDVixZQUFZO0FBQUEsUUFDWixpQkFBaUI7QUFBQSxRQUNqQixlQUFlO0FBQUEsUUFDZixpQkFBaUI7QUFBQSxRQUNqQixVQUFVO0FBQUEsTUFDWjtBQUFBLE1BQ0E7QUFBQSxRQUNFLGdCQUFnQjtBQUFBLFFBQ2hCLFVBQVU7QUFBQSxRQUNWLFlBQVk7QUFBQSxRQUNaLGlCQUFpQjtBQUFBLFFBQ2pCLGVBQWU7QUFBQSxRQUNmLGlCQUFpQjtBQUFBLFFBQ2pCLFVBQVU7QUFBQSxNQUNaO0FBQUEsTUFDQTtBQUFBLFFBQ0UsZ0JBQWdCO0FBQUEsUUFDaEIsVUFBVTtBQUFBLFFBQ1YsWUFBWTtBQUFBLFFBQ1osaUJBQWlCO0FBQUEsUUFDakIsZUFBZTtBQUFBLFFBQ2YsaUJBQWlCO0FBQUEsUUFDakIsVUFBVTtBQUFBLE1BQ1o7QUFBQSxNQUNBO0FBQUEsUUFDRSxnQkFBZ0I7QUFBQSxRQUNoQixVQUFVO0FBQUEsUUFDVixZQUFZO0FBQUEsUUFDWixpQkFBaUI7QUFBQSxRQUNqQixlQUFlO0FBQUEsUUFDZixpQkFBaUI7QUFBQSxRQUNqQixVQUFVO0FBQUEsTUFDWjtBQUFBLElBQUM7QUFHSCxVQUFNQyxLQUFLL0csS0FBS2dILE1BQU1DLGNBQWNILFVBQVU7QUFDOUMsVUFBTUksS0FBS2xILEtBQUtnSCxNQUFNRyxTQUFTO0FBQy9CbkgsU0FBS2dILE1BQU1JLGtCQUFrQkYsSUFBSUgsSUFBSSxtQkFBbUI7QUFDeEQvRyxTQUFLcUgsVUFBVUgsSUFBSSwyQkFBMkIvRix1QkFBdUIsU0FBUyxPQUFPO0FBQUEsRUFDdkY7QUFFQSxRQUFNbUcsbUJBQW1CQSxDQUFDaEIsTUFBMkM7QUFDbkUsVUFBTWlCLE9BQU9qQixFQUFFa0IsT0FBT0MsUUFBUSxDQUFDO0FBQy9CLFFBQUksQ0FBQ0YsS0FBTTtBQUVYdEUsc0JBQWtCc0UsS0FBSzNFLElBQUk7QUFDM0JPLHFCQUFpQixJQUFJO0FBQ3JCSixrQkFBYyxFQUFFO0FBRWhCLFVBQU0yRSxTQUFTLElBQUlDLFdBQVc7QUFDOUJELFdBQU9FLFNBQVMsQ0FBQ0MsUUFBUTtBQUN2QixVQUFJO0FBQ0YsY0FBTUMsT0FBT0QsSUFBSUwsUUFBUU87QUFDekIsY0FBTWIsS0FBS2xILEtBQUtnSSxLQUFLRixNQUFNLEVBQUVHLE1BQU0sU0FBUyxDQUFDO0FBQzdDLGNBQU1DLGlCQUFpQmhCLEdBQUdpQixXQUFXLENBQUM7QUFDdEMsY0FBTXBCLEtBQUtHLEdBQUdrQixPQUFPRixjQUFjO0FBQ25DLGNBQU1HLFVBQWlCckksS0FBS2dILE1BQU1zQixjQUFjdkIsSUFBSSxFQUFFd0IsUUFBUSxHQUFHLENBQUM7QUFFbEUsWUFBSUYsUUFBUTFDLFdBQVcsR0FBRztBQUN4QmMsZ0JBQU0scURBQXFEO0FBQzNEdEQsMkJBQWlCLEtBQUs7QUFDdEI7QUFBQSxRQUNGO0FBRUEsY0FBTXFGLFNBQTZCSCxRQUFRSSxJQUFJLENBQUNDLFFBQVE7QUFFdEQsZ0JBQU1DLE9BQU9DLE9BQU9ELEtBQUtELEdBQUc7QUFDNUIsZ0JBQU1HLFVBQVVBLENBQUNDLFVBQW9CO0FBQ25DLGtCQUFNQyxhQUFhSixLQUFLN0U7QUFBQUEsY0FBSyxDQUFDa0YsTUFDNUJGLE1BQU1HLEtBQUssQ0FBQ0MsTUFBTUYsRUFBRTNFLFlBQVksRUFBRXVDLFFBQVEsY0FBYyxFQUFFLEVBQUV2QixTQUFTNkQsQ0FBQyxDQUFDO0FBQUEsWUFDekU7QUFDQSxtQkFBT0gsYUFBYUksT0FBT1QsSUFBSUssVUFBVSxDQUFDLEVBQUV2QyxLQUFLLElBQUk7QUFBQSxVQUN2RDtBQUVBLGdCQUFNNUQsT0FBT2lHLFFBQVEsQ0FBQyxRQUFRLGVBQWUsVUFBVSxDQUFDLEtBQUs7QUFDN0QsZ0JBQU1PLFlBQVlQLFFBQVEsQ0FBQyxVQUFVLEtBQUssQ0FBQyxFQUFFeEUsWUFBWTtBQUN6RCxnQkFBTUcsU0FDSjRFLFVBQVVDLFdBQVcsR0FBRyxLQUFLRCxVQUFVL0QsU0FBUyxLQUFLLElBQUksU0FBUztBQUVwRSxnQkFBTWlFLFNBQVNULFFBQVEsQ0FBQyxZQUFZLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDNUQsY0FBSW5FLFdBQVc7QUFDZixnQkFBTTZFLFdBQVdELE9BQU9FLE1BQU0sS0FBSztBQUNuQyxjQUFJRCxVQUFVO0FBQ1osa0JBQU1FLE1BQU1GLFNBQVMsQ0FBQztBQUN0QixnQkFBSSxDQUFDLEtBQUssTUFBTSxNQUFNLElBQUksRUFBRWxFLFNBQVNvRSxHQUFHLEdBQUc7QUFDekMvRSx5QkFBVytFO0FBQUFBLFlBQ2IsT0FBTztBQUNML0UseUJBQVc7QUFBQSxZQUNiO0FBQUEsVUFDRjtBQUVBLGdCQUFNRCxNQUFNb0UsUUFBUSxDQUFDLE9BQU8sU0FBUyxhQUFhLENBQUMsS0FBSztBQUN4RCxnQkFBTWxFLGFBQWFrRSxRQUFRLENBQUMsVUFBVSxZQUFZLFVBQVUsUUFBUSxDQUFDLEtBQUs7QUFDMUUsZ0JBQU1qRSxRQUFRaUUsUUFBUSxDQUFDLFNBQVMsVUFBVSxTQUFTLENBQUMsS0FBSztBQUN6RCxnQkFBTWEsWUFBWWIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFeEUsWUFBWTtBQUNsRCxnQkFBTVEsU0FBZ0M2RSxVQUFVckUsU0FBUyxPQUFPLElBQUksYUFBYTtBQUVqRixjQUFJc0UsVUFBVTtBQUNkLGNBQUlDLGtCQUFrQjtBQUN0QixjQUFJLENBQUNoSCxNQUFNO0FBQ1QrRyxzQkFBVTtBQUNWQyw4QkFBa0I7QUFBQSxVQUNwQjtBQUVBLGlCQUFPO0FBQUEsWUFDTGhIO0FBQUFBLFlBQ0E0QjtBQUFBQSxZQUNBRTtBQUFBQSxZQUNBRDtBQUFBQSxZQUNBRTtBQUFBQSxZQUNBQztBQUFBQSxZQUNBQztBQUFBQSxZQUNBOEU7QUFBQUEsWUFDQUM7QUFBQUEsVUFDRjtBQUFBLFFBQ0YsQ0FBQztBQUVEN0csc0JBQWN5RixNQUFNO0FBQUEsTUFDdEIsU0FBU3FCLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBQzlDcEQsY0FBTSw0RUFBNEU7QUFBQSxNQUNwRixVQUFDO0FBQ0N0RCx5QkFBaUIsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUNBdUUsV0FBT3NDLG1CQUFtQnpDLElBQUk7QUFBQSxFQUNoQztBQUVBLFFBQU0wQywwQkFBMEJBLE1BQU07QUFDcEMsUUFBSSxDQUFDM0cscUJBQXFCLENBQUNFLG1CQUFtQjtBQUM1Q2lELFlBQU0seURBQXlEO0FBQy9EO0FBQUEsSUFDRjtBQUNBLFVBQU15RCxlQUFlekosV0FBV3FELEtBQUssQ0FBQUMsTUFBS0EsRUFBRWxCLE9BQU9TLGlCQUFpQjtBQUNwRSxRQUFJLENBQUM0RyxhQUFjO0FBRW5CLFVBQU1DLFlBQVlySCxXQUFXa0MsT0FBTyxDQUFDb0YsTUFBTUEsRUFBRVQsV0FBV1MsRUFBRXhILEtBQUs0RCxLQUFLLEVBQUViLFNBQVMsQ0FBQztBQUNoRixRQUFJd0UsVUFBVXhFLFdBQVcsR0FBRztBQUMxQmMsWUFBTSwyQ0FBMkM7QUFDakQ7QUFBQSxJQUNGO0FBRUEsVUFBTUUsbUJBQW1CdkMsZUFBZXZCLE1BQU0xQixvQkFBb0JrRCxZQUFZLEVBQUV1QyxRQUFRLFFBQVEsR0FBRztBQUVuRyxVQUFNeUQsb0JBQW9CRixVQUFVMUIsSUFBSSxDQUFDMkIsT0FBTztBQUFBLE1BQzlDeEgsTUFBTXdILEVBQUV4SDtBQUFBQSxNQUNSNEIsUUFBUTRGLEVBQUU1RjtBQUFBQSxNQUNWQyxLQUFLMkYsRUFBRTNGO0FBQUFBLE1BQ1BDLFVBQVUwRixFQUFFMUY7QUFBQUEsTUFDWmYsYUFBYVEsZ0JBQWdCdEI7QUFBQUEsTUFDN0JxQyxlQUFlZixnQkFBZ0J2QjtBQUFBQSxNQUMvQmdCLFdBQVcrQztBQUFBQSxNQUNYN0IsYUFBYTNEO0FBQUFBLE1BQ2J3RCxZQUFZeUYsRUFBRXpGO0FBQUFBLE1BQ2RDLE9BQU93RixFQUFFeEY7QUFBQUEsTUFDVEMsUUFBUXVGLEVBQUV2RjtBQUFBQSxJQUNaLEVBQUU7QUFFRixRQUFJakUsc0JBQXNCO0FBQ3hCQSwyQkFBcUJ5SixtQkFBbUJILGFBQWFJLGFBQWFKLGFBQWFLLFdBQVcsRUFBRTtBQUFBLElBQzlGLE9BQU87QUFDTEYsd0JBQWtCRyxRQUFRLENBQUNDLE9BQU85SixhQUFhOEosRUFBRSxDQUFDO0FBQUEsSUFDcEQ7QUFFQXBIO0FBQUFBLE1BQ0UseUJBQXlCZ0gsa0JBQWtCMUUsTUFBTSxrQkFBa0J4RSxtQkFBbUIsS0FBS2dELGdCQUFnQnZCLElBQUk7QUFBQSxJQUNqSDtBQUNBZCx1QkFBbUIsS0FBSztBQUN4QmlCLGtCQUFjLEVBQUU7QUFDaEJFLHNCQUFrQixFQUFFO0FBRXBCUixlQUFXLE1BQU07QUFDZlksOEJBQXdCLElBQUk7QUFBQSxJQUM5QixHQUFHLEdBQUk7QUFBQSxFQUNUO0FBS0EsTUFBSSxDQUFDcEMscUJBQXFCO0FBQ3hCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw4RUFBNkUscUNBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFDekJ5RTtBQUFBQTtBQUFBQSxjQUFxQjtBQUFBLGlCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQWdELDhGQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU07QUFDYm5DLHFDQUFxQixFQUFFO0FBQ3ZCRSxxQ0FBcUIsRUFBRTtBQUN2QjNCLG1DQUFtQixJQUFJO0FBQUEsY0FDekI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFVBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQTtBQUFBLFlBVDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JvRSxtQ0FBbUI7QUFDbkIzQiw0QkFBWSxDQUFDbUcsVUFBVSxFQUFFLEdBQUdBLE1BQU0vRyxhQUFhLElBQUltQixhQUFhLEdBQUcsRUFBRTtBQUFBLGNBQ3ZFO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixpQ0FBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUE7QUFBQSxZQVJuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0NBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUZBQWtGLDhCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRztBQUFBLFVBQy9HLHVCQUFDLFNBQUksV0FBVSx5REFBeURZLGtDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RjtBQUFBLGFBRi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFGQUFvRix1QkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEc7QUFBQSxVQUMxRyx1QkFBQyxTQUFJLFdBQVUseURBQXlERSx5QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Y7QUFBQSxhQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx1RkFBc0Ysd0JBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZHO0FBQUEsVUFDN0csdUJBQUMsU0FBSSxXQUFVLHlEQUF5REMsMEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsYUFGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxzSEFBcUgsc0JBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLE9BQU94RTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2lGLE1BQU1oRixnQkFBZ0JnRixFQUFFa0IsT0FBT21ELEtBQUs7QUFBQSxZQUMvQyxXQUFVO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtxVDtBQUFBLFdBVHZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUN2SCx3QkFDQyx1QkFBQyxTQUFJLFdBQVUseU1BQ2I7QUFBQSwrQkFBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTUMsd0JBQXdCLElBQUk7QUFBQSxZQUMzQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFML0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BSUYsdUJBQUMsU0FBSSxXQUFVLHdEQUNaNUMscUJBQ0V1RSxPQUFPLENBQUNqQixNQUFNQSxFQUFFbkIsS0FBS3lCLFlBQVksRUFBRWdCLFNBQVNoRSxhQUFhZ0QsWUFBWSxDQUFDLENBQUMsRUFDdkVvRSxJQUFJLENBQUNtQyxjQUFjO0FBQ2xCLGNBQU1DLGNBQWNySyxTQUFTd0U7QUFBQUEsVUFDM0IsQ0FBQ0MsTUFBTUEsRUFBRXRCLGdCQUFnQmlILFVBQVUvSCxNQUFNb0MsRUFBRUMsY0FBY2IsWUFBWSxNQUFNdUcsVUFBVWhJLEtBQUt5QixZQUFZO0FBQUEsUUFDeEc7QUFDQSxjQUFNeUcsWUFBWUQsWUFBWTdGLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVQsV0FBVyxNQUFNLEVBQUVtQjtBQUNqRSxjQUFNb0YsYUFBYUYsWUFBWTdGLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVQsV0FBVyxRQUFRLEVBQUVtQjtBQUVwRSxlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU1HLHNCQUFzQjhFLFVBQVUvSCxFQUFFO0FBQUEsWUFDakQsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMkRBQ2IrSDtBQUFBQSxnQ0FBVUw7QUFBQUEsc0JBQVE7QUFBQSx5QkFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSx5R0FDWEssb0JBQVVoSSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRWdJLFVBQVUvRixXQUFXLGFBQ2pCLFlBQ0ErRixVQUFVL0YsV0FBVyx3QkFDbkIsWUFDQTtBQUFBLHNCQUVSLE1BQUs7QUFBQSxzQkFFSitGLG9CQUFVL0Y7QUFBQUE7QUFBQUEsb0JBVmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdBO0FBQUEscUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUJBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNiLGlDQUFDLFVBQU0rRjtBQUFBQSw0QkFBVTNHLFNBQVMwQixVQUFVaUYsVUFBVUk7QUFBQUEsa0JBQWM7QUFBQSxrQkFBb0JILFlBQVlsRjtBQUFBQSxrQkFBTztBQUFBLHFCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RyxLQUQ5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLFdBQVUsa0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUEsb0JBQzVCLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxTQUFJLFdBQVUscURBQW9ELG9CQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RTtBQUFBLHNCQUN2RSx1QkFBQyxTQUFJLFdBQVUsbURBQW1EbUYsdUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRFO0FBQUEseUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLFdBQVUsa0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUEsb0JBQzVCLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxTQUFJLFdBQVUscURBQW9ELHFCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RTtBQUFBLHNCQUN4RSx1QkFBQyxTQUFJLFdBQVUsbURBQW1EQyx3QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkU7QUFBQSx5QkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNaSCxvQkFBVTNHLFNBQVN3RTtBQUFBQSxrQkFBSSxDQUFDdkUsTUFDdkI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsV0FBVTtBQUFBLHNCQUVUQSxZQUFFdEI7QUFBQUE7QUFBQUEsb0JBSEVzQixFQUFFckI7QUFBQUEsb0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGdCQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVEQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLCtLQUNiO0FBQUEsdUNBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQjtBQUFBLGdCQUNuQix1QkFBQyxVQUFLLFdBQVUseUNBQXdDLDZCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRTtBQUFBLG1CQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUE7QUFBQTtBQUFBLFVBaEVLK0gsVUFBVS9IO0FBQUFBLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFrRUE7QUFBQSxNQUVKLENBQUMsS0EvRUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdGQTtBQUFBLFNBdEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1S0E7QUFBQSxFQUVKO0FBS0EsTUFBSXNCLG1CQUFtQixDQUFDaEQscUJBQXFCO0FBQzNDLFVBQU04SixvQkFBb0J6SyxTQUFTd0U7QUFBQUEsTUFDakMsQ0FBQ0MsTUFBTUEsRUFBRXRCLGdCQUFnQlEsZ0JBQWdCdEIsTUFBTW9DLEVBQUVDLGNBQWNiLFlBQVksTUFBTUYsZ0JBQWdCdkIsS0FBS3lCLFlBQVk7QUFBQSxJQUNwSDtBQUVBLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSwyRUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMyQjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQW9DO0FBQUE7QUFBQSxjQUhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFPO0FBQUEsWUFDUCx1QkFBQyxVQUFLLFdBQVUsK0NBQStDN0IsMEJBQWdCdkIsUUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxlQVR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsd0dBQ1o7QUFBQSxtQ0FBQyxVQUFNdUIsMEJBQWdCdkIsUUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEI7QUFBQSxZQUM1Qix1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCdUI7QUFBQUEsOEJBQWdCRixTQUFTMEI7QUFBQUEsY0FBTztBQUFBLGlCQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQWdELHFGQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUFFcEMscUNBQXFCWSxpQkFBaUJ0QixNQUFNLEVBQUU7QUFBR1kscUNBQXFCLEVBQUU7QUFBRzNCLG1DQUFtQixJQUFJO0FBQUEsY0FBRztBQUFBLGNBQ3RILFdBQVU7QUFBQSxjQUVWLGlDQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQTtBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQUVvRSxtQ0FBbUI7QUFBRzNCLDRCQUFZLENBQUFtRyxVQUFTLEVBQUUsR0FBR0EsTUFBTS9HLGFBQWFRLGlCQUFpQnRCLE1BQU0sSUFBSWlDLGFBQWEsR0FBRyxFQUFFO0FBQUEsY0FBRztBQUFBLGNBQ3BJLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQTtBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBU2tCO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVYsaUNBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx3REFDWjdCLDBCQUFnQkYsU0FBU3dFLElBQUksQ0FBQ3lDLFlBQVk7QUFDekMsY0FBTUMsWUFBWUYsa0JBQWtCakc7QUFBQUEsVUFDbEMsQ0FBQ0MsTUFBTUEsRUFBRUgsWUFBWVQsWUFBWSxNQUFNNkcsUUFBUXRJLEtBQUt5QixZQUFZLEtBQUtZLEVBQUVyQixjQUFjc0gsUUFBUXJJO0FBQUFBLFFBQy9GO0FBQ0EsY0FBTXVJLFFBQVFELFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVULFdBQVcsTUFBTSxFQUFFbUI7QUFDM0QsY0FBTTBGLFNBQVNGLFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVULFdBQVcsUUFBUSxFQUFFbUI7QUFFOUQsY0FBTTJGLE9BQU9ILFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVQLGFBQWEsR0FBRyxFQUFFaUI7QUFDekQsY0FBTTRGLFFBQVFKLFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVQLGFBQWEsSUFBSSxFQUFFaUI7QUFDM0QsY0FBTTZGLFFBQVFMLFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVQLGFBQWEsSUFBSSxFQUFFaUI7QUFDM0QsY0FBTThGLFFBQVFOLFVBQVVuRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVQLGFBQWEsSUFBSSxFQUFFaUI7QUFFM0QsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBUyxNQUFNSSxvQkFBb0JtRixRQUFRdEksSUFBSTtBQUFBLFlBQy9DLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDJEQUEwRCx1QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUY7QUFBQSxvQkFDakYsdUJBQUMsUUFBRyxXQUFVLHlHQUNYc0ksa0JBQVF0SSxRQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QnVJO0FBQUFBLDhCQUFVeEY7QUFBQUEsb0JBQU87QUFBQSx1QkFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwyQ0FBQyxVQUFLLGtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVE7QUFBQSxvQkFDUix1QkFBQyxTQUNDO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHFEQUFvRCxvQkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUU7QUFBQSxzQkFDdkUsdUJBQUMsU0FBSSxXQUFVLG1EQUFtRHlGLG1CQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RTtBQUFBLHlCQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDJDQUFDLFVBQUssa0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBUTtBQUFBLG9CQUNSLHVCQUFDLFNBQ0M7QUFBQSw2Q0FBQyxTQUFJLFdBQVUscURBQW9ELHFCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RTtBQUFBLHNCQUN4RSx1QkFBQyxTQUFJLFdBQVUsbURBQW1EQyxvQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUU7QUFBQSx5QkFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSw0REFBMkQscUNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStGO0FBQUEsa0JBQy9GLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxzQ0FBcUMsbUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVEO0FBQUEsc0JBQ3ZELHVCQUFDLFNBQUksV0FBVSxvQ0FBb0NDLGtCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RDtBQUFBLHlCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHNDQUFxQyxvQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0Q7QUFBQSxzQkFDeEQsdUJBQUMsU0FBSSxXQUFVLG9DQUFvQ0MsbUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlEO0FBQUEseUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsc0NBQXFDLG9CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3RDtBQUFBLHNCQUN4RCx1QkFBQyxTQUFJLFdBQVUsb0NBQW9DQyxtQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUQ7QUFBQSx5QkFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxzQ0FBcUMsb0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdEO0FBQUEsc0JBQ3hELHVCQUFDLFNBQUksV0FBVSxvQ0FBb0NDLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RDtBQUFBLHlCQUYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb0JBO0FBQUEsbUJBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbURBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsK0tBQ2I7QUFBQSx1Q0FBQyxVQUFLLG1DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsZ0JBQ3pCLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0MsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFFO0FBQUEsbUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQTtBQUFBO0FBQUEsVUE1REtQLFFBQVFySTtBQUFBQSxVQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE4REE7QUFBQSxNQUVKLENBQUMsS0E5RUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStFQTtBQUFBLFNBbklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvSUE7QUFBQSxFQUVKO0FBS0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0JBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNtRDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUFvQztBQUFBO0FBQUEsWUFIaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLFVBQ1A7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVQ5QiwyQkFBaUJ2QjtBQUFBQTtBQUFBQSxZQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFDUCx1QkFBQyxVQUFLLFdBQVUsK0NBQStDekIsaUNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsYUFqQnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw4RUFDWEE7QUFBQUE7QUFBQUEsWUFBb0I7QUFBQSxlQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCZ0U7QUFBQUEsbUNBQXVCUTtBQUFBQSxZQUFPO0FBQUEsZUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQ1Z4QjtBQUFBQSwyQkFBaUJ2QjtBQUFBQSxVQUFLO0FBQUEsYUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTTtBQUFFVyxtQ0FBcUJZLGlCQUFpQnRCLE1BQU0sRUFBRTtBQUFHWSxtQ0FBcUJ0Qyx1QkFBdUIsRUFBRTtBQUFHVyxpQ0FBbUIsSUFBSTtBQUFBLFlBQUc7QUFBQSxZQUM3SSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUE7QUFBQSxVQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNvRTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWLGlDQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQTtBQUFBLFVBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0Q7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLHdCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWM7QUFBQTtBQUFBLFVBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxzSEFBcUgsc0JBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLE9BQU81RTtBQUFBQSxZQUNQLFVBQVUsQ0FBQ2lGLE1BQU1oRixnQkFBZ0JnRixFQUFFa0IsT0FBT21ELEtBQUs7QUFBQSxZQUMvQyxXQUFVO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUttVDtBQUFBLFdBVHJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJDQUNaLFdBQUMsSUFBSSxLQUFLLE1BQU0sTUFBTSxJQUFJLEVBQUVsQztBQUFBQSxVQUFJLENBQUNpRCxRQUNoQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNbEssZUFBZWtLLEdBQUc7QUFBQSxjQUNqQyxXQUFXLHlEQUNUbkssZ0JBQWdCbUssTUFDWiw0Q0FDQSwwSEFBMEg7QUFBQSxjQUcvSEEsa0JBQVEsS0FBSyxlQUFlLE9BQU9BLEdBQUc7QUFBQTtBQUFBLFlBVGxDQTtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLFFBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1oSyxZQUFZLE9BQU87QUFBQSxjQUNsQyxXQUFXLDJEQUNURCxhQUFhLFVBQ1QsNENBQ0EsMEhBQTBIO0FBQUEsY0FDN0g7QUFBQTtBQUFBLFlBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU1DLFlBQVksS0FBSztBQUFBLGNBQ2hDLFdBQVcsMkRBQ1RELGFBQWEsUUFDVCw0Q0FDQSwwSEFBMEg7QUFBQSxjQUM3SDtBQUFBO0FBQUEsWUFQTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxXQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUEsU0F4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlEQTtBQUFBLElBR0NBLGFBQWEsV0FDWix1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsdUlBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEI7QUFBQSxZQUM1Qix1QkFBQyxVQUFLLFdBQVUsbURBQWtELDJCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLGVBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFDekIrRDtBQUFBQSx3QkFBWUc7QUFBQUEsWUFBTztBQUFBLGVBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDZGQUNaSCxzQkFBWUcsV0FBVyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUseUNBQXdDLG1EQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQUgsWUFBWWlEO0FBQUFBLFVBQUksQ0FBQ3JDLFlBQ2Y7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTWxFLGtCQUFrQmtFLE9BQU87QUFBQSxjQUN4QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSw2SkFDWkEsa0JBQVF1RixnQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZDQUFDLFFBQUcsV0FBVSw4RUFDWHZGLGtCQUFReEQsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBTSxPQUFNLFNBQVEsTUFBSyxNQUFLO0FBQUE7QUFBQSx3QkFDeEJ3RCxRQUFRMUI7QUFBQUEsMkJBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxzQkFDckMwQixRQUFRekIsY0FBYztBQUFBLHNCQUFNO0FBQUEsc0JBQVd5QixRQUFReEI7QUFBQUEseUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUEwQixTQUFTLENBQUMwQixNQUFNQSxFQUFFc0YsZ0JBQWdCLEdBQ3pFO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTXpGLGtCQUFrQkMsT0FBTztBQUFBLHNCQUN4QyxXQUFVO0FBQUEsc0JBQ1YsT0FBTTtBQUFBLHNCQUVOLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTREO0FBQUE7QUFBQSxvQkFOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTWhFLG1CQUFtQmdFLE9BQU87QUFBQSxzQkFDekMsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RDtBQUFBO0FBQUEsb0JBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBO0FBQUE7QUFBQSxZQXhDS0EsUUFBUXZEO0FBQUFBLFlBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTBDQTtBQUFBLFFBQ0QsS0FsREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9EQTtBQUFBLFdBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx1SUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxXQUFVLGtCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBLFlBQzVCLHVCQUFDLFVBQUssV0FBVSxtREFBa0QsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsZUFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQVUsTUFBSyxNQUN6QjRDO0FBQUFBLHlCQUFhRTtBQUFBQSxZQUFPO0FBQUEsZUFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkZBQ1pGLHVCQUFhRSxXQUFXLElBQ3ZCLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0Msb0RBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBRixhQUFhZ0Q7QUFBQUEsVUFBSSxDQUFDckMsWUFDaEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTWxFLGtCQUFrQmtFLE9BQU87QUFBQSxjQUN4QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxpS0FDWkEsa0JBQVF1RixnQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZDQUFDLFFBQUcsV0FBVSwrRUFDWHZGLGtCQUFReEQsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBTSxPQUFNLFNBQVEsTUFBSyxNQUFLO0FBQUE7QUFBQSx3QkFDeEJ3RCxRQUFRMUI7QUFBQUEsMkJBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxzQkFDckMwQixRQUFRekIsY0FBYztBQUFBLHNCQUFNO0FBQUEsc0JBQVd5QixRQUFReEI7QUFBQUEseUJBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUEwQixTQUFTLENBQUMwQixNQUFNQSxFQUFFc0YsZ0JBQWdCLEdBQ3pFO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTXpGLGtCQUFrQkMsT0FBTztBQUFBLHNCQUN4QyxXQUFVO0FBQUEsc0JBQ1YsT0FBTTtBQUFBLHNCQUVOLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTREO0FBQUE7QUFBQSxvQkFOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTWhFLG1CQUFtQmdFLE9BQU87QUFBQSxzQkFDekMsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RDtBQUFBO0FBQUEsb0JBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPQTtBQUFBLHFCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBO0FBQUE7QUFBQSxZQXhDS0EsUUFBUXZEO0FBQUFBLFlBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTBDQTtBQUFBLFFBQ0QsS0FsREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9EQTtBQUFBLFdBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRUE7QUFBQSxTQXJJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0lBO0FBQUEsS0FJQXBCLGFBQWEsU0FBU0EsYUFBYSxVQUFVQSxhQUFhLFlBQzFELHVCQUFDLFNBQUksV0FBVSx5SEFDYixpQ0FBQyxXQUFNLFdBQVUsb0NBQ2Y7QUFBQSw2QkFBQyxXQUFNLFdBQVUsd0tBQ2YsaUNBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxlQUFjLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFDaEMsdUJBQUMsUUFBRyxXQUFVLGVBQWMsNEJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYyxzQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFFBQ2xDLHVCQUFDLFFBQUcsV0FBVSxlQUFjLHdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsUUFDcEMsdUJBQUMsUUFBRyxXQUFVLGVBQWMsaUNBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUM3Qyx1QkFBQyxRQUFHLFdBQVUsZUFBYyxxQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFFBQUcsV0FBVSxlQUFjLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEMsdUJBQUMsUUFBRyxXQUFVLDBCQUF5Qix1QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFdBUmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BQ0EsdUJBQUMsV0FBTSxXQUFVLHlEQUNiQSx3QkFBYSxTQUFTK0QsY0FBYy9ELGFBQWEsVUFBVWdFLGVBQWVOLHdCQUF3QlEsV0FDcEcsSUFDRSx1QkFBQyxRQUNDLGlDQUFDLFFBQUcsU0FBUyxHQUFHLFdBQVUsd0NBQXVDLGdFQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsS0FFQ2xFLGFBQWEsU0FBUytELGNBQWMvRCxhQUFhLFVBQVVnRSxlQUFlTix3QkFBd0JzRDtBQUFBQSxRQUNqRyxDQUFDckMsWUFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBUyxNQUFNbEUsa0JBQWtCa0UsT0FBTztBQUFBLFlBQ3hDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsUUFBRyxXQUFVLHVDQUF1Q0Esa0JBQVFkLFFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtFO0FBQUEsY0FDbEUsdUJBQUMsUUFBRyxXQUFVLHVEQUF1RGMsa0JBQVF4RCxRQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRjtBQUFBLGNBQ2xGLHVCQUFDLFFBQUcsV0FBVSxlQUNaLGlDQUFDLFNBQU0sT0FBT3dELFFBQVE1QixXQUFXLFNBQVMsWUFBWSxXQUFXLE1BQUssTUFDbkU0QixrQkFBUTVCLFdBQVcsU0FBUyxXQUFXLGFBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsNERBQ1g0QjtBQUFBQSx3QkFBUTFCO0FBQUFBLGdCQUFTO0FBQUEsbUJBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxnREFBZ0QwQixrQkFBUXpCLGNBQWMsT0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Y7QUFBQSxjQUN4Rix1QkFBQyxRQUFHLFdBQVUsMERBQTBEeUIsa0JBQVF4QixTQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRjtBQUFBLGNBQ3RGLHVCQUFDLFFBQUcsV0FBVSxlQUNaLGlDQUFDLFNBQU0sT0FBT3dCLFFBQVF2QixXQUFXLFdBQVcsWUFBWSxTQUFTLE1BQUssTUFDbkV1QixrQkFBUXZCLFdBQVcsV0FBVyxXQUFXLGNBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsMEJBQ1osaUNBQUMsU0FBSSxXQUFVLDBCQUF5QixTQUFTLENBQUN5QixNQUFNQSxFQUFFc0YsZ0JBQWdCLEdBQ3hFO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTXpGLGtCQUFrQkMsT0FBTztBQUFBLG9CQUN4QyxXQUFVO0FBQUEsb0JBQ1YsT0FBTTtBQUFBLG9CQUVOLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTREO0FBQUE7QUFBQSxrQkFOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTWhFLG1CQUFtQmdFLE9BQU87QUFBQSxvQkFDekMsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFFTixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RDtBQUFBO0FBQUEsa0JBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBO0FBQUE7QUFBQSxVQXhDS0EsUUFBUXZEO0FBQUFBLFVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTBDQTtBQUFBLE1BRUosS0F2REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlEQTtBQUFBLFNBdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RUEsS0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlFQTtBQUFBLElBUURsQixnQkFDQyx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsU0FBUyxNQUFNQyxnQkFBZ0IsS0FBSztBQUFBO0FBQUEsUUFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRXdDO0FBQUEsTUFHeEMsdUJBQUMsU0FBSSxXQUFVLHdHQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGdFQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlDQUF3QywwQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNqRUcsaUJBQWlCLGlCQUFpQjtBQUFBLGVBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU1ILGdCQUFnQixLQUFLO0FBQUEsY0FDcEMsV0FBVTtBQUFBLGNBRVYsaUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQTtBQUFBLFlBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFVBQUssVUFBVXlFLG1CQUFtQixXQUFVLHdDQUV6QztBQUFBLGlDQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsaUVBQWdFLGtDQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRztBQUFBLGNBQ25HO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU8vQixTQUFTWCxnQkFBZ0JsRCxXQUFXLENBQUMsR0FBR29DLE1BQU1nSjtBQUFBQSxrQkFDckQsZUFBZSxDQUFDQyxRQUFRdkgsWUFBWSxFQUFFLEdBQUdELFVBQVVYLGFBQWFtSSxLQUFLaEgsYUFBYSxHQUFHLENBQUM7QUFBQSxrQkFFdEY7QUFBQSwyQ0FBQyxpQkFBYyxXQUFVLGVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLGlCQUNFckUscUJBQVdnSTtBQUFBQSxzQkFBSSxDQUFBMUUsTUFDZCx1QkFBQyxjQUFzQixPQUFPQSxFQUFFbEIsSUFBS2tCLFlBQUVuQixRQUF0Qm1CLEVBQUVsQixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE0QztBQUFBLG9CQUM3QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQTtBQUFBO0FBQUEsZ0JBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGlFQUFnRSxnQ0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUc7QUFBQSxjQUNqRztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPeUIsU0FBU1EsZ0JBQWdCckUsV0FBV3FELEtBQUssQ0FBQUMsTUFBS0EsRUFBRWxCLE9BQU95QixTQUFTWCxXQUFXLEdBQUdNLFNBQVMsQ0FBQyxHQUFHckIsUUFBUWlKO0FBQUFBLGtCQUMxRyxlQUFlLENBQUNDLFFBQVF2SCxZQUFZLEVBQUUsR0FBR0QsVUFBVVEsYUFBYWdILElBQUksQ0FBQztBQUFBLGtCQUNyRSxVQUFVLENBQUN4SCxTQUFTWDtBQUFBQSxrQkFFcEI7QUFBQSwyQ0FBQyxpQkFBYyxXQUFVLGVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxvQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLGlCQUNFbEQscUJBQVdxRCxLQUFLLENBQUFDLE1BQUtBLEVBQUVsQixPQUFPeUIsU0FBU1gsV0FBVyxHQUFHTSxTQUFTd0U7QUFBQUEsc0JBQUksQ0FBQXZFLE1BQ2pFLHVCQUFDLGNBQXNCLE9BQU9BLEVBQUV0QixNQUFPc0IsWUFBRXRCLFFBQXhCc0IsRUFBRXJCLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThDO0FBQUEsb0JBQy9DLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBO0FBQUE7QUFBQSxnQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsZUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQ0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0Q7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELG1DQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLE9BQU95QixTQUFTMUI7QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzBELE1BQU0vQixZQUFZLEVBQUUsR0FBR0QsVUFBVTFCLE1BQU0wRCxFQUFFa0IsT0FBT21ELE1BQU0sQ0FBQztBQUFBLGdCQUNsRSxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU15STtBQUFBLGVBUnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUY7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELHdCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU1wRyxZQUFZLEVBQUUsR0FBR0QsVUFBVUUsUUFBUSxPQUFPLENBQUM7QUFBQSxrQkFDMUQsV0FBVywwSEFDVEYsU0FBU0UsV0FBVyxTQUNoQixpREFDQSw2REFBNkQ7QUFBQSxrQkFHbkU7QUFBQSwyQ0FBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVU7QUFBQSxvQkFDVix1QkFBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdCO0FBQUE7QUFBQTtBQUFBLGdCQVZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTUQsWUFBWSxFQUFFLEdBQUdELFVBQVVFLFFBQVEsU0FBUyxDQUFDO0FBQUEsa0JBQzVELFdBQVcsMEhBQ1RGLFNBQVNFLFdBQVcsV0FDaEIsaURBQ0EsNkRBQTZEO0FBQUEsa0JBR25FO0FBQUEsMkNBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFVO0FBQUEsb0JBQ1YsdUJBQUMsVUFBSyw2QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQjtBQUFBO0FBQUE7QUFBQSxnQkFWckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxtREFBa0Qsa0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsY0FDckY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT0YsU0FBU0k7QUFBQUEsa0JBQ2hCLGVBQWUsQ0FBQ29ILFFBQVF2SCxZQUFZLEVBQUUsR0FBR0QsVUFBVUksVUFBVW9ILElBQUksQ0FBQztBQUFBLGtCQUVsRTtBQUFBLDJDQUFDLGlCQUFjLFdBQVUseUVBQ3ZCLGlDQUFDLGVBQVksYUFBWSxjQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQyxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsaUJBQ0M7QUFBQSw2Q0FBQyxjQUFXLE9BQU0sS0FBSSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBa0M7QUFBQSxzQkFDbEMsdUJBQUMsY0FBVyxPQUFNLE1BQUssNkJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9DO0FBQUEsc0JBQ3BDLHVCQUFDLGNBQVcsT0FBTSxNQUFLLDZCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQztBQUFBLHNCQUNwQyx1QkFBQyxjQUFXLE9BQU0sTUFBSyw2QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0M7QUFBQSx5QkFKdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBO0FBQUE7QUFBQSxnQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFFQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLG1EQUFrRCw2QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Y7QUFBQSxjQUNoRjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT3hILFNBQVNHO0FBQUFBLGtCQUNoQixVQUFVLENBQUM2QixNQUFNL0IsWUFBWSxFQUFFLEdBQUdELFVBQVVHLEtBQUs2QixFQUFFa0IsT0FBT21ELE1BQU0sQ0FBQztBQUFBLGtCQUNqRSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJeUk7QUFBQSxpQkFOM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCxzQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQSxZQUN6RjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3JHLFNBQVNLO0FBQUFBLGdCQUNoQixVQUFVLENBQUMyQixNQUFNL0IsWUFBWSxFQUFFLEdBQUdELFVBQVVLLFlBQVkyQixFQUFFa0IsT0FBT21ELE1BQU0sQ0FBQztBQUFBLGdCQUN4RSxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUt5STtBQUFBLGVBUDNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsbURBQWtELG9DQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RjtBQUFBLFlBQ3ZGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLGFBQVk7QUFBQSxnQkFDWixPQUFPckcsU0FBU007QUFBQUEsZ0JBQ2hCLFVBQVUsQ0FBQzBCLE1BQU0vQixZQUFZLEVBQUUsR0FBR0QsVUFBVU0sT0FBTzBCLEVBQUVrQixPQUFPbUQsTUFBTSxDQUFDO0FBQUEsZ0JBQ25FLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3lJO0FBQUEsZUFQM0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxtREFBa0QsaUNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsWUFDcEY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPckcsU0FBU087QUFBQUEsZ0JBQ2hCLGVBQWUsQ0FBQ2lILFFBQVF2SCxZQUFZLEVBQUUsR0FBR0QsVUFBVU8sUUFBUWlILElBQTZCLENBQUM7QUFBQSxnQkFFekY7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLGdEQUN2QixpQ0FBQyxlQUFZLGFBQVksWUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUMsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNDO0FBQUEsMkNBQUMsY0FBVyxPQUFNLFVBQVMsc0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLGNBQVcsT0FBTSxZQUFXLHdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBLHVCQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUE7QUFBQTtBQUFBLGNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTWxLLGdCQUFnQixLQUFLO0FBQUEsZ0JBQ3BDLFdBQVU7QUFBQSxnQkFBcUg7QUFBQTtBQUFBLGNBSGpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBRVRHLDJCQUFpQixtQkFBbUI7QUFBQTtBQUFBLGNBSnZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUFwS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFLQTtBQUFBLFdBbkxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvTEE7QUFBQSxTQTFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkxBO0FBQUEsSUFNREYsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5RkFDYixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDBCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRSxLQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyw4Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHdFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYkMsaUNBQW1CLEtBQUs7QUFDeEJpQiw0QkFBYyxFQUFFO0FBQ2hCRSxnQ0FBa0IsRUFBRTtBQUFBLFlBQ3RCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFSL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0E7QUFBQSxXQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0JBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0NBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCxrQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9LO0FBQUFBLGdCQUNQLGVBQWUsQ0FBQ3dJLFFBQVE7QUFDdEJ2SSx1Q0FBcUJ1SSxHQUFHO0FBQ3hCckksdUNBQXFCLEVBQUU7QUFBQSxnQkFDekI7QUFBQSxnQkFFQTtBQUFBLHlDQUFDLGlCQUFjLFdBQVUseURBQ3ZCLGlDQUFDLGVBQVksYUFBWSxzQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGlCQUNFaEQscUJBQVdnSTtBQUFBQSxvQkFBSSxDQUFDMUUsTUFDZix1QkFBQyxjQUFzQixPQUFPQSxFQUFFbEIsSUFDN0JrQixZQUFFbkIsUUFEWW1CLEVBQUVsQixJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUE7QUFBQTtBQUFBLGNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWlCQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG1EQUFrRCxnQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9XO0FBQUFBLGdCQUNQLGVBQWUsQ0FBQ3NJLFFBQVFySSxxQkFBcUJxSSxHQUFHO0FBQUEsZ0JBQ2hELFVBQVUsQ0FBQ3hJO0FBQUFBLGdCQUVYO0FBQUEseUNBQUMsaUJBQWMsV0FBVSw2RUFDdkIsaUNBQUMsZUFBWSxhQUFZLG9CQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsaUJBQ0c3QyxzQkFBV3FELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRWxCLE9BQU9TLGlCQUFpQixHQUFHVyxZQUFZLElBQUl3RTtBQUFBQSxvQkFBSSxDQUFDdkUsTUFDekUsdUJBQUMsY0FBc0IsT0FBT0EsRUFBRXRCLE1BQzdCc0IsWUFBRXRCLFFBRFlzQixFQUFFckIsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWVBO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUseUhBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdDQUF1QyxzQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEU7QUFBQSxZQUM1RSx1QkFBQyxTQUFJLFdBQVUsOEJBQTZCLGtGQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBU2dFO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFLLFdBQVUseUNBQXdDLHdCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRTtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBTHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1uRCxhQUFhcUksU0FBU0MsTUFBTTtBQUFBLFlBQzNDLFdBQVU7QUFBQSxZQUVWO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLEtBQUt0STtBQUFBQSxrQkFDTCxVQUFVNEQ7QUFBQUEsa0JBQ1YsUUFBTztBQUFBLGtCQUNQLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtvQjtBQUFBLGNBRXBCLHVCQUFDLFNBQUksV0FBVSwrSUFDYixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLDRCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRSxLQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0NBQ1p0RSwyQkFBaUJBLGlCQUFpQixzQ0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyxzREFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQTtBQUFBO0FBQUEsVUFqQnZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWtCQTtBQUFBLFFBR0NFLGlCQUNDLHVCQUFDLFNBQUksV0FBVSwrRkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxzREFBcUQsaUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFBTztBQUFBLGFBRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBSURKLFdBQVc2QyxTQUFTLEtBQ25CLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLG1DQUFDLFVBQUs7QUFBQTtBQUFBLGNBQVE3QyxXQUFXNkM7QUFBQUEsY0FBTztBQUFBLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFVBQUssV0FBVSw2REFDYjdDO0FBQUFBLHlCQUFXa0MsT0FBTyxDQUFDb0YsTUFBTUEsRUFBRVQsT0FBTyxFQUFFaEU7QUFBQUEsY0FBTztBQUFBLGlCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzR0FDZixpQ0FBQyxRQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLGFBQVksb0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThCO0FBQUEsY0FDOUIsdUJBQUMsUUFBRyxXQUFVLGFBQVksc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FDaEMsdUJBQUMsUUFBRyxXQUFVLGFBQVksd0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsUUFBRyxXQUFVLGFBQVksc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FDaEMsdUJBQUMsUUFBRyxXQUFVLGFBQVkscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsUUFBRyxXQUFVLGFBQVksc0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxXQUFNLFdBQVUseUNBQ2Q3QyxxQkFBVzJGO0FBQUFBLGNBQUksQ0FBQzJCLEdBQUc2QixRQUNsQix1QkFBQyxRQUFhLFdBQVc3QixFQUFFVCxVQUFVLEtBQUssbUJBQ3hDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHdDQUF3Q1MsWUFBRXhILFFBQVEsU0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxnQkFDdEUsdUJBQUMsUUFBRyxXQUFVLDBCQUEwQndILFlBQUU1RixVQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBLGdCQUNqRCx1QkFBQyxRQUFHLFdBQVUseUJBQXlCNEY7QUFBQUEsb0JBQUUxRjtBQUFBQSxrQkFBUztBQUFBLHFCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUN4RCx1QkFBQyxRQUFHLFdBQVUsOEJBQThCMEYsWUFBRXpGLGNBQWMsU0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQSxnQkFDbEUsdUJBQUMsUUFBRyxXQUFVLDhCQUE4QnlGLFlBQUV4RixTQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxRQUFHLFdBQVUsZUFDWHdGLFlBQUVULFVBQ0QsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQixxQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0QsSUFFaEQsdUJBQUMsVUFBSyxXQUFVLDRCQUE0QlMsWUFBRVIsbUJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThELEtBSmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxtQkFaT3FDLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLFlBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStCQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxXQXhJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMElBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNO0FBQ2JuSyxpQ0FBbUIsS0FBSztBQUN4QmlCLDRCQUFjLEVBQUU7QUFDaEJFLGdDQUFrQixFQUFFO0FBQUEsWUFDdEI7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUFxSDtBQUFBO0FBQUEsVUFQakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxVQUFVSCxXQUFXNkMsV0FBVyxLQUFLN0MsV0FBV2tDLE9BQU8sQ0FBQ29GLE1BQU1BLEVBQUVULE9BQU8sRUFBRWhFLFdBQVc7QUFBQSxZQUNwRixTQUFTc0U7QUFBQUEsWUFDVCxXQUFXLG1IQUNUbkgsV0FBVzZDLFNBQVMsS0FBSzdDLFdBQVdrQyxPQUFPLENBQUNvRixNQUFNQSxFQUFFVCxPQUFPLEVBQUVoRSxTQUFTLElBQ2xFLCtDQUNBLDRDQUE0QztBQUFBLFlBR2xEO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlDQUF3QyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUFPO0FBQUEsY0FDOUM3QyxXQUFXa0MsT0FBTyxDQUFDb0YsTUFBTUEsRUFBRVQsT0FBTyxFQUFFaEU7QUFBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQVhuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFZQTtBQUFBLFdBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQTlMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0xBLEtBaE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpTUE7QUFBQSxJQU1EMUQsa0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGdHQUNiLGlDQUFDLFNBQUksV0FBVSxnR0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxnRUFDWjtBQUFBLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MscUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFBTztBQUFBLGFBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUMsa0JBQWtCLElBQUk7QUFBQSxZQUNyQyxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBO0FBQUEsVUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsaUZBQ1RELGVBQWV1QyxXQUFXLFNBQVMsNEJBQTRCLHlCQUF5QjtBQUFBLGNBR3pGdkMseUJBQWUwSjtBQUFBQTtBQUFBQSxZQUxsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBd0MxSix5QkFBZVcsUUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRSx1QkFBQyxPQUFFLFdBQVUsOEJBQThCWCx5QkFBZXFELFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsWUFDL0QsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxzRUFDVHJELGVBQWV1QyxXQUFXLFNBQ3RCLGdDQUNBLDZCQUE2QjtBQUFBLGtCQUdsQ3ZDLHlCQUFldUMsV0FBVyxTQUFTLG9CQUFvQjtBQUFBO0FBQUEsZ0JBUDFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHNFQUNUdkMsZUFBZTRDLFdBQVcsV0FDdEIsZ0NBQ0EsNkJBQTZCO0FBQUEsa0JBR2xDNUMseUJBQWU0QyxXQUFXLFdBQVcsV0FBVztBQUFBO0FBQUEsZ0JBUG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsZUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDREQUEyRCx3QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUY7QUFBQSxZQUNuRix1QkFBQyxVQUFLLFdBQVUsNEJBQTRCNUM7QUFBQUEsNkJBQWV5QztBQUFBQSxjQUFTO0FBQUEsaUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsZUFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0REFBMkQsc0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsWUFDakYsdUJBQUMsVUFBSyxXQUFVLHdCQUF3QnpDLHlCQUFldUMsVUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDREQUEyRCx5QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxZQUNwRix1QkFBQyxVQUFLLFdBQVUsYUFBYXZDLHlCQUFlaUQsaUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsZUFGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0REFBMkQsdUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFDbEYsdUJBQUMsVUFBSyxXQUFVLGFBQWFqRCx5QkFBZTZDLGVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSw0REFBMkQsaUNBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsWUFDNUYsdUJBQUMsVUFBSyxXQUFVLGFBQWE3Qyx5QkFBZTBDLGNBQWMsU0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0U7QUFBQSxlQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLDREQUEyRCw2QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxZQUN4Rix1QkFBQyxVQUFLLFdBQVUsYUFBYTFDLHlCQUFlMkMsU0FBUyxTQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLGVBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsV0E1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZEQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTTtBQUNiLG9CQUFNc0gsV0FBV2pLO0FBQ2pCQyxnQ0FBa0IsSUFBSTtBQUN0QkUsaUNBQW1COEosUUFBUTtBQUFBLFlBQzdCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFVBQUssV0FBVSx5Q0FBd0Msc0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsY0FBTztBQUFBO0FBQUE7QUFBQSxVQVR2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTWhLLGtCQUFrQixJQUFJO0FBQUEsY0FDckMsV0FBVTtBQUFBLGNBQWtJO0FBQUE7QUFBQSxZQUg5STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTTtBQUNiLHNCQUFNaUssU0FBU2xLO0FBQ2ZDLGtDQUFrQixJQUFJO0FBQ3RCaUUsa0NBQWtCZ0csTUFBTTtBQUFBLGNBQzFCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBVSx5Q0FBd0Msb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTREO0FBQUEsZ0JBQU87QUFBQTtBQUFBO0FBQUEsWUFUckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1DQTtBQUFBLFNBaEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpSEEsS0FsSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1IQTtBQUFBLElBTURoSyxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsZ0lBQ2IsaUNBQUMsU0FBSSxXQUFVLG1IQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtGQUNiLGlDQUFDLFVBQUssV0FBVSx5Q0FBd0MsOEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0UsS0FEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFFBQ3BFLHVCQUFDLE9BQUUsV0FBVSxxREFBb0Q7QUFBQTtBQUFBLFVBQy9CLHVCQUFDLFlBQU8sV0FBVSxrQkFBa0JBLDBCQUFnQlMsUUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUFTO0FBQUEsVUFBR1QsZ0JBQWdCdUM7QUFBQUEsVUFBUztBQUFBLFVBQWN2QyxnQkFBZ0IyQztBQUFBQSxVQUFZO0FBQUEsYUFEMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU0xQyxtQkFBbUIsSUFBSTtBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUFnSTtBQUFBO0FBQUEsVUFINUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTTtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUFvSTtBQUFBO0FBQUEsVUFIaEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLElBSURMLGdCQUNDLHVCQUFDLFNBQUksV0FBVSw4TEFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSx3REFBdUQsNEJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxNQUNuRix1QkFBQyxVQUFNQSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTUMsZ0JBQWdCLElBQUk7QUFBQSxVQUNuQyxXQUFVO0FBQUEsVUFFVixpQ0FBQyxVQUFLLFdBQVUseUNBQXdDLHFCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBO0FBQUEsUUFKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BdjRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeTRCQTtBQUVKO0FBQUV0QixHQW5vRFdULGNBQXlDO0FBQUEsS0FBekNBO0FBQXlDLElBQUE2TDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJYTFNYIiwiQmFkZ2UiLCJTZWxlY3QiLCJTZWxlY3RDb250ZW50IiwiU2VsZWN0SXRlbSIsIlNlbGVjdFRyaWdnZXIiLCJTZWxlY3RWYWx1ZSIsIlN0dWRlbnRzVmlldyIsInN0dWRlbnRzIiwicGFuY2hheWF0cyIsImluaXRpYWxGaWx0ZXJzIiwib25BZGRTdHVkZW50Iiwib25CdWxrSW1wb3J0U3R1ZGVudHMiLCJvbkVkaXRTdHVkZW50Iiwib25VcGRhdGVTdHVkZW50Iiwib25EZWxldGVTdHVkZW50IiwiX3MiLCJzZWxlY3RlZFBhbmNoYXlhdElkIiwic2V0U2VsZWN0ZWRQYW5jaGF5YXRJZCIsInNlbGVjdGVkVmlsbGFnZU5hbWUiLCJzZXRTZWxlY3RlZFZpbGxhZ2VOYW1lIiwiZ2xvYmFsU2VhcmNoIiwic2V0R2xvYmFsU2VhcmNoIiwic2VsZWN0ZWRTdGQiLCJzZXRTZWxlY3RlZFN0ZCIsInZpZXdNb2RlIiwic2V0Vmlld01vZGUiLCJzaG93QWRkTW9kYWwiLCJzZXRTaG93QWRkTW9kYWwiLCJzaG93SW1wb3J0TW9kYWwiLCJzZXRTaG93SW1wb3J0TW9kYWwiLCJlZGl0aW5nU3R1ZGVudCIsInNldEVkaXRpbmdTdHVkZW50Iiwidmlld2luZ1N0dWRlbnQiLCJzZXRWaWV3aW5nU3R1ZGVudCIsInN0dWRlbnRUb0RlbGV0ZSIsInNldFN0dWRlbnRUb0RlbGV0ZSIsInRvYXN0TWVzc2FnZSIsInNldFRvYXN0TWVzc2FnZSIsInNob3dUb2FzdCIsIm1zZyIsInNldFRpbWVvdXQiLCJoYW5kbGVDb25maXJtRGVsZXRlU3R1ZGVudCIsInNOYW1lIiwibmFtZSIsImlkIiwiaW1wb3J0Um93cyIsInNldEltcG9ydFJvd3MiLCJpbXBvcnRGaWxlTmFtZSIsInNldEltcG9ydEZpbGVOYW1lIiwiaXNQYXJzaW5nRmlsZSIsInNldElzUGFyc2luZ0ZpbGUiLCJpbXBvcnRTdWNjZXNzTWVzc2FnZSIsInNldEltcG9ydFN1Y2Nlc3NNZXNzYWdlIiwiaW1wb3J0UGFuY2hheWF0SWQiLCJzZXRJbXBvcnRQYW5jaGF5YXRJZCIsImltcG9ydFZpbGxhZ2VOYW1lIiwic2V0SW1wb3J0VmlsbGFnZU5hbWUiLCJmaWxlSW5wdXRSZWYiLCJwYW5jaGF5YXRJZCIsInZpbGxhZ2VJZCIsInBhbiIsImZpbmQiLCJwIiwidmlsbCIsInZpbGxhZ2VzIiwidiIsImFjdGl2ZVBhbmNoYXlhdCIsImFjdGl2ZVZpbGxhZ2UiLCJ0b0xvd2VyQ2FzZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJnZW5kZXIiLCJkb2IiLCJzdGFuZGFyZCIsInBhcmVudE5hbWUiLCJwaG9uZSIsInN0YXR1cyIsInZpbGxhZ2VOYW1lIiwidmlsbGFnZVN0dWRlbnRzIiwiZmlsdGVyIiwicyIsInBhbmNoYXlhdE5hbWUiLCJmaWx0ZXJlZFJvc3RlclN0dWRlbnRzIiwibWF0Y2hTZWFyY2giLCJpbmNsdWRlcyIsImNvZGUiLCJtYXRjaFN0ZCIsImJveVN0dWRlbnRzIiwiZ2lybFN0dWRlbnRzIiwiY2x1c3RlclRvdGFsU3R1ZGVudHMiLCJsZW5ndGgiLCJjbHVzdGVyQm95cyIsImNsdXN0ZXJHaXJscyIsImhhbmRsZVNlbGVjdFBhbmNoYXlhdCIsImhhbmRsZVNlbGVjdFZpbGxhZ2UiLCJoYW5kbGVCYWNrVG9QYW5jaGF5YXRzIiwiaGFuZGxlQmFja1RvVmlsbGFnZXMiLCJoYW5kbGVPcGVuQWRkTW9kYWwiLCJoYW5kbGVFZGl0U3R1ZGVudCIsInN0dWRlbnQiLCJoYW5kbGVTYXZlU3R1ZGVudCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRyaW0iLCJhbGVydCIsInRhcmdldFBhbmNoYXlhdCIsImN1cnJlbnRWaWxsYWdlSWQiLCJyZXBsYWNlIiwiaGFuZGxlRG93bmxvYWRTYW1wbGVFeGNlbCIsInNhbXBsZURhdGEiLCJ3cyIsInV0aWxzIiwianNvbl90b19zaGVldCIsIndiIiwiYm9va19uZXciLCJib29rX2FwcGVuZF9zaGVldCIsIndyaXRlRmlsZSIsImhhbmRsZUZpbGVVcGxvYWQiLCJmaWxlIiwidGFyZ2V0IiwiZmlsZXMiLCJyZWFkZXIiLCJGaWxlUmVhZGVyIiwib25sb2FkIiwiZXZ0IiwiYnN0ciIsInJlc3VsdCIsInJlYWQiLCJ0eXBlIiwiZmlyc3RTaGVldE5hbWUiLCJTaGVldE5hbWVzIiwiU2hlZXRzIiwicmF3SnNvbiIsInNoZWV0X3RvX2pzb24iLCJkZWZ2YWwiLCJwYXJzZWQiLCJtYXAiLCJyb3ciLCJrZXlzIiwiT2JqZWN0IiwiZmluZFZhbCIsInRlcm1zIiwibWF0Y2hlZEtleSIsImsiLCJzb21lIiwidCIsIlN0cmluZyIsInJhd0dlbmRlciIsInN0YXJ0c1dpdGgiLCJyYXdTdGQiLCJudW1NYXRjaCIsIm1hdGNoIiwibnVtIiwicmF3U3RhdHVzIiwiaXNWYWxpZCIsInZhbGlkYXRpb25FcnJvciIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsInJlYWRBc0JpbmFyeVN0cmluZyIsImhhbmRsZUNvbmZpcm1CdWxrSW1wb3J0IiwidGd0UGFuY2hheWF0IiwidmFsaWRSb3dzIiwiciIsImZvcm1hdHRlZFN0dWRlbnRzIiwiY2x1c3RlcklkIiwiY2x1c3RlciIsImZvckVhY2giLCJzdCIsInByZXYiLCJ2YWx1ZSIsInBhbmNoYXlhdCIsInBhblN0dWRlbnRzIiwiYm95c0NvdW50IiwiZ2lybHNDb3VudCIsInZpbGxhZ2VzQ291bnQiLCJwYW5jaGF5YXRTdHVkZW50cyIsInZpbGxhZ2UiLCJ2U3R1ZGVudHMiLCJ2Qm95cyIsInZHaXJscyIsInN0ZDkiLCJzdGQxMCIsInN0ZDExIiwic3RkMTIiLCJzdGQiLCJhdmF0YXJMZXR0ZXIiLCJzdG9wUHJvcGFnYXRpb24iLCJ1bmRlZmluZWQiLCJ2YWwiLCJjdXJyZW50IiwiY2xpY2siLCJpZHgiLCJ0b0RlbGV0ZSIsInRvRWRpdCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN0dWRlbnRzVmlldy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VNZW1vLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0ICogYXMgWExTWCBmcm9tICd4bHN4JztcclxuaW1wb3J0IHsgU3R1ZGVudCwgUGFuY2hheWF0LCBWaWxsYWdlIH0gZnJvbSAnLi4vdHlwZXMnO1xyXG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJy4vdWkvYmFkZ2UnO1xyXG5pbXBvcnQge1xyXG4gIFNlbGVjdCxcclxuICBTZWxlY3RDb250ZW50LFxyXG4gIFNlbGVjdEl0ZW0sXHJcbiAgU2VsZWN0VHJpZ2dlcixcclxuICBTZWxlY3RWYWx1ZSxcclxufSBmcm9tICcuL3VpL3NlbGVjdCc7XHJcbmltcG9ydCB7IEFjdGlvbkJ1dHRvbiB9IGZyb20gJy4vdWkvYWN0aW9uLWJ1dHRvbic7XHJcblxyXG5pbnRlcmZhY2UgU3R1ZGVudHNWaWV3UHJvcHMge1xyXG4gIHN0dWRlbnRzOiBTdHVkZW50W107XHJcbiAgcGFuY2hheWF0czogUGFuY2hheWF0W107XHJcbiAgaW5pdGlhbEZpbHRlcnM/OiB7IHBhbmNoYXlhdElkPzogc3RyaW5nOyB2aWxsYWdlSWQ/OiBzdHJpbmcgfTtcclxuICBvbkFkZFN0dWRlbnQ6IChuZXdTdHVkZW50OiBPbWl0PFN0dWRlbnQsICdpZCcgfCAnY29kZScgfCAnYXZhdGFyTGV0dGVyJyB8ICdhdmF0YXJCZyc+KSA9PiB2b2lkO1xyXG4gIG9uQnVsa0ltcG9ydFN0dWRlbnRzPzogKHN0dWRlbnRzOiBhbnlbXSwgY2x1c3RlcklkOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD4gfCB2b2lkO1xyXG4gIG9uRWRpdFN0dWRlbnQ/OiAoaWQ6IHN0cmluZywgdXBkYXRlZDogUGFydGlhbDxTdHVkZW50PikgPT4gUHJvbWlzZTx2b2lkPiB8IHZvaWQ7XHJcbiAgb25VcGRhdGVTdHVkZW50PzogKGlkOiBzdHJpbmcsIHVwZGF0ZWQ6IFBhcnRpYWw8U3R1ZGVudD4pID0+IHZvaWQ7XHJcbiAgb25EZWxldGVTdHVkZW50OiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcclxufVxyXG5cclxudHlwZSBWaWV3TW9kZSA9ICdzcGxpdCcgfCAnYWxsJyB8ICdib3lzJyB8ICdnaXJscyc7XHJcblxyXG5pbnRlcmZhY2UgUGFyc2VkU3R1ZGVudFJvdyB7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIGdlbmRlcjogJ21hbGUnIHwgJ2ZlbWFsZSc7XHJcbiAgc3RhbmRhcmQ6IHN0cmluZztcclxuICBkb2I6IHN0cmluZztcclxuICBwYXJlbnROYW1lOiBzdHJpbmc7XHJcbiAgcGhvbmU6IHN0cmluZztcclxuICBzdGF0dXM6ICdhY3RpdmUnIHwgJ2luYWN0aXZlJztcclxuICBpc1ZhbGlkOiBib29sZWFuO1xyXG4gIHZhbGlkYXRpb25FcnJvcj86IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFN0dWRlbnRzVmlldzogUmVhY3QuRkM8U3R1ZGVudHNWaWV3UHJvcHM+ID0gKHtcclxuICBzdHVkZW50cyxcclxuICBwYW5jaGF5YXRzLFxyXG4gIGluaXRpYWxGaWx0ZXJzLFxyXG4gIG9uQWRkU3R1ZGVudCxcclxuICBvbkJ1bGtJbXBvcnRTdHVkZW50cyxcclxuICBvbkVkaXRTdHVkZW50LFxyXG4gIG9uVXBkYXRlU3R1ZGVudCxcclxuICBvbkRlbGV0ZVN0dWRlbnQsXHJcbn0pID0+IHtcclxuICAvLyBOYXZpZ2F0aW9uIExldmVsOiAncGFuY2hheWF0cycgKGxldmVsIDEpIHwgJ3ZpbGxhZ2VzJyAobGV2ZWwgMikgfCAncm9zdGVyJyAobGV2ZWwgMylcclxuICBjb25zdCBbc2VsZWN0ZWRQYW5jaGF5YXRJZCwgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRWaWxsYWdlTmFtZSwgc2V0U2VsZWN0ZWRWaWxsYWdlTmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgLy8gU2VhcmNoICYgRmlsdGVyc1xyXG4gIGNvbnN0IFtnbG9iYWxTZWFyY2gsIHNldEdsb2JhbFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkU3RkLCBzZXRTZWxlY3RlZFN0ZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZTxWaWV3TW9kZT4oJ3NwbGl0Jyk7XHJcblxyXG4gIC8vIE1vZGFscyAmIERyYXdlcnNcclxuICBjb25zdCBbc2hvd0FkZE1vZGFsLCBzZXRTaG93QWRkTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93SW1wb3J0TW9kYWwsIHNldFNob3dJbXBvcnRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRpbmdTdHVkZW50LCBzZXRFZGl0aW5nU3R1ZGVudF0gPSB1c2VTdGF0ZTxTdHVkZW50IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3ZpZXdpbmdTdHVkZW50LCBzZXRWaWV3aW5nU3R1ZGVudF0gPSB1c2VTdGF0ZTxTdHVkZW50IHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW3N0dWRlbnRUb0RlbGV0ZSwgc2V0U3R1ZGVudFRvRGVsZXRlXSA9IHVzZVN0YXRlPFN0dWRlbnQgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbdG9hc3RNZXNzYWdlLCBzZXRUb2FzdE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IHNob3dUb2FzdCA9IChtc2c6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0VG9hc3RNZXNzYWdlKG1zZyk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0VG9hc3RNZXNzYWdlKG51bGwpO1xyXG4gICAgfSwgNDAwMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29uZmlybURlbGV0ZVN0dWRlbnQgPSAoKSA9PiB7XHJcbiAgICBpZiAoIXN0dWRlbnRUb0RlbGV0ZSkgcmV0dXJuO1xyXG4gICAgY29uc3Qgc05hbWUgPSBzdHVkZW50VG9EZWxldGUubmFtZTtcclxuICAgIG9uRGVsZXRlU3R1ZGVudChzdHVkZW50VG9EZWxldGUuaWQpO1xyXG4gICAgaWYgKHZpZXdpbmdTdHVkZW50Py5pZCA9PT0gc3R1ZGVudFRvRGVsZXRlLmlkKSB7XHJcbiAgICAgIHNldFZpZXdpbmdTdHVkZW50KG51bGwpO1xyXG4gICAgfVxyXG4gICAgc2hvd1RvYXN0KGBTdHVkZW50ICR7c05hbWV9IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5YCk7XHJcbiAgICBzZXRTdHVkZW50VG9EZWxldGUobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRXhjZWwgQnVsayBJbXBvcnQgU3RhdGVzXHJcbiAgY29uc3QgW2ltcG9ydFJvd3MsIHNldEltcG9ydFJvd3NdID0gdXNlU3RhdGU8UGFyc2VkU3R1ZGVudFJvd1tdPihbXSk7XHJcbiAgY29uc3QgW2ltcG9ydEZpbGVOYW1lLCBzZXRJbXBvcnRGaWxlTmFtZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2lzUGFyc2luZ0ZpbGUsIHNldElzUGFyc2luZ0ZpbGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpbXBvcnRTdWNjZXNzTWVzc2FnZSwgc2V0SW1wb3J0U3VjY2Vzc01lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2ltcG9ydFBhbmNoYXlhdElkLCBzZXRJbXBvcnRQYW5jaGF5YXRJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcclxuICBjb25zdCBbaW1wb3J0VmlsbGFnZU5hbWUsIHNldEltcG9ydFZpbGxhZ2VOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xyXG4gIGNvbnN0IGZpbGVJbnB1dFJlZiA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKTtcclxuXHJcbiAgLy8gU3luY2hyb25pemUgd2hlbiBpbml0aWFsRmlsdGVycyBjaGFuZ2UgZnJvbSBvdGhlciBzY3JlZW5zIChlLmcuIERhc2hib2FyZClcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGluaXRpYWxGaWx0ZXJzPy5wYW5jaGF5YXRJZCkge1xyXG4gICAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdElkKGluaXRpYWxGaWx0ZXJzLnBhbmNoYXlhdElkKTtcclxuICAgICAgaWYgKGluaXRpYWxGaWx0ZXJzLnZpbGxhZ2VJZCkge1xyXG4gICAgICAgIGNvbnN0IHBhbiA9IHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gaW5pdGlhbEZpbHRlcnMucGFuY2hheWF0SWQpO1xyXG4gICAgICAgIGNvbnN0IHZpbGwgPSBwYW4/LnZpbGxhZ2VzLmZpbmQoKHYpID0+IHYuaWQgPT09IGluaXRpYWxGaWx0ZXJzLnZpbGxhZ2VJZCB8fCB2Lm5hbWUgPT09IGluaXRpYWxGaWx0ZXJzLnZpbGxhZ2VJZCk7XHJcbiAgICAgICAgaWYgKHZpbGwpIHtcclxuICAgICAgICAgIHNldFNlbGVjdGVkVmlsbGFnZU5hbWUodmlsbC5uYW1lKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9LCBbaW5pdGlhbEZpbHRlcnMsIHBhbmNoYXlhdHNdKTtcclxuXHJcbiAgLy8gQWN0aXZlIFBhbmNoYXlhdCAmIFZpbGxhZ2Ugb2JqZWN0c1xyXG4gIGNvbnN0IGFjdGl2ZVBhbmNoYXlhdCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHBhbmNoYXlhdHMuZmluZCgocCkgPT4gcC5pZCA9PT0gc2VsZWN0ZWRQYW5jaGF5YXRJZCkgfHwgbnVsbDtcclxuICB9LCBbcGFuY2hheWF0cywgc2VsZWN0ZWRQYW5jaGF5YXRJZF0pO1xyXG5cclxuICBjb25zdCBhY3RpdmVWaWxsYWdlID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWFjdGl2ZVBhbmNoYXlhdCB8fCAhc2VsZWN0ZWRWaWxsYWdlTmFtZSkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICBhY3RpdmVQYW5jaGF5YXQudmlsbGFnZXMuZmluZChcclxuICAgICAgICAodikgPT4gdi5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IHNlbGVjdGVkVmlsbGFnZU5hbWUudG9Mb3dlckNhc2UoKSB8fCB2LmlkID09PSBzZWxlY3RlZFZpbGxhZ2VOYW1lXHJcbiAgICAgICkgfHwgbnVsbFxyXG4gICAgKTtcclxuICB9LCBbYWN0aXZlUGFuY2hheWF0LCBzZWxlY3RlZFZpbGxhZ2VOYW1lXSk7XHJcblxyXG4gIC8vIEZvcm0gU3RhdGUgZm9yIEFkZCAvIEVkaXQgU3R1ZGVudFxyXG4gIC8vIFN0YW5kYXJkIG9wdGlvbnMgc3RyaWN0bHkgOSB0byAxMiBhcyByZXF1ZXN0ZWQ6IDksIDEwLCAxMSwgMTJcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIG5hbWU6ICcnLFxyXG4gICAgZ2VuZGVyOiAnZmVtYWxlJyBhcyAnbWFsZScgfCAnZmVtYWxlJyxcclxuICAgIGRvYjogJzIwMDktMDYtMTUnLFxyXG4gICAgc3RhbmRhcmQ6ICc5JywgLy8gOSB0byAxMlxyXG4gICAgcGFyZW50TmFtZTogJycsXHJcbiAgICBwaG9uZTogJycsXHJcbiAgICBzdGF0dXM6ICdhY3RpdmUnIGFzICdhY3RpdmUnIHwgJ2luYWN0aXZlJyxcclxuICAgIHBhbmNoYXlhdElkOiAnJyxcclxuICAgIHZpbGxhZ2VOYW1lOiAnJyxcclxuICB9KTtcclxuXHJcbiAgLy8gU3R1ZGVudHMgZmlsdGVyaW5nIHdpdGhpbiB0aGUgc2VsZWN0ZWQgdmlsbGFnZSBvciBvdmVyYWxsXHJcbiAgY29uc3QgdmlsbGFnZVN0dWRlbnRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoIWFjdGl2ZVBhbmNoYXlhdCB8fCAhc2VsZWN0ZWRWaWxsYWdlTmFtZSkgcmV0dXJuIFtdO1xyXG4gICAgcmV0dXJuIHN0dWRlbnRzLmZpbHRlcihcclxuICAgICAgKHMpID0+XHJcbiAgICAgICAgKHMucGFuY2hheWF0SWQgPT09IGFjdGl2ZVBhbmNoYXlhdC5pZCB8fCBzLnBhbmNoYXlhdE5hbWUudG9Mb3dlckNhc2UoKSA9PT0gYWN0aXZlUGFuY2hheWF0Lm5hbWUudG9Mb3dlckNhc2UoKSkgJiZcclxuICAgICAgICAocy52aWxsYWdlTmFtZS50b0xvd2VyQ2FzZSgpID09PSBzZWxlY3RlZFZpbGxhZ2VOYW1lLnRvTG93ZXJDYXNlKCkgfHwgcy52aWxsYWdlSWQgPT09IGFjdGl2ZVZpbGxhZ2U/LmlkKVxyXG4gICAgKTtcclxuICB9LCBbc3R1ZGVudHMsIGFjdGl2ZVBhbmNoYXlhdCwgc2VsZWN0ZWRWaWxsYWdlTmFtZSwgYWN0aXZlVmlsbGFnZV0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFJvc3RlclN0dWRlbnRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gdmlsbGFnZVN0dWRlbnRzLmZpbHRlcigocykgPT4ge1xyXG4gICAgICBjb25zdCBtYXRjaFNlYXJjaCA9XHJcbiAgICAgICAgcy5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoZ2xvYmFsU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgcy5jb2RlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoZ2xvYmFsU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgcy5wYXJlbnROYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoZ2xvYmFsU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgcy5waG9uZS5pbmNsdWRlcyhnbG9iYWxTZWFyY2gpO1xyXG5cclxuICAgICAgY29uc3QgbWF0Y2hTdGQgPSAhc2VsZWN0ZWRTdGQgfHwgcy5zdGFuZGFyZCA9PT0gc2VsZWN0ZWRTdGQ7XHJcbiAgICAgIHJldHVybiBtYXRjaFNlYXJjaCAmJiBtYXRjaFN0ZDtcclxuICAgIH0pO1xyXG4gIH0sIFt2aWxsYWdlU3R1ZGVudHMsIGdsb2JhbFNlYXJjaCwgc2VsZWN0ZWRTdGRdKTtcclxuXHJcbiAgLy8gR2VuZGVyIGJyZWFrZG93blxyXG4gIGNvbnN0IGJveVN0dWRlbnRzID0gdXNlTWVtbygoKSA9PiBmaWx0ZXJlZFJvc3RlclN0dWRlbnRzLmZpbHRlcigocykgPT4gcy5nZW5kZXIgPT09ICdtYWxlJyksIFtmaWx0ZXJlZFJvc3RlclN0dWRlbnRzXSk7XHJcbiAgY29uc3QgZ2lybFN0dWRlbnRzID0gdXNlTWVtbygoKSA9PiBmaWx0ZXJlZFJvc3RlclN0dWRlbnRzLmZpbHRlcigocykgPT4gcy5nZW5kZXIgPT09ICdmZW1hbGUnKSwgW2ZpbHRlcmVkUm9zdGVyU3R1ZGVudHNdKTtcclxuXHJcbiAgLy8gT3ZlcmFsbCBDbHVzdGVyIFN0dWRlbnQgU3VtbWFyeVxyXG4gIGNvbnN0IGNsdXN0ZXJUb3RhbFN0dWRlbnRzID0gc3R1ZGVudHMubGVuZ3RoO1xyXG4gIGNvbnN0IGNsdXN0ZXJCb3lzID0gc3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLmdlbmRlciA9PT0gJ21hbGUnKS5sZW5ndGg7XHJcbiAgY29uc3QgY2x1c3RlckdpcmxzID0gc3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLmdlbmRlciA9PT0gJ2ZlbWFsZScpLmxlbmd0aDtcclxuXHJcbiAgLy8gSGFuZGxlcnMgZm9yIGhpZXJhcmNoaWNhbCBjYXJkIG5hdmlnYXRpb25cclxuICBjb25zdCBoYW5kbGVTZWxlY3RQYW5jaGF5YXQgPSAocGFuY2hheWF0SWQ6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRQYW5jaGF5YXRJZChwYW5jaGF5YXRJZCk7XHJcbiAgICBzZXRTZWxlY3RlZFZpbGxhZ2VOYW1lKG51bGwpO1xyXG4gICAgc2V0R2xvYmFsU2VhcmNoKCcnKTtcclxuICAgIHNldFNlbGVjdGVkU3RkKCcnKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RWaWxsYWdlID0gKHZpbGxhZ2VOYW1lOiBzdHJpbmcpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVmlsbGFnZU5hbWUodmlsbGFnZU5hbWUpO1xyXG4gICAgc2V0R2xvYmFsU2VhcmNoKCcnKTtcclxuICAgIHNldFNlbGVjdGVkU3RkKCcnKTtcclxuICAgIHNldFZpZXdNb2RlKCdzcGxpdCcpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUJhY2tUb1BhbmNoYXlhdHMgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFBhbmNoYXlhdElkKG51bGwpO1xyXG4gICAgc2V0U2VsZWN0ZWRWaWxsYWdlTmFtZShudWxsKTtcclxuICAgIHNldEdsb2JhbFNlYXJjaCgnJyk7XHJcbiAgICBzZXRTZWxlY3RlZFN0ZCgnJyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQmFja1RvVmlsbGFnZXMgPSAoKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFZpbGxhZ2VOYW1lKG51bGwpO1xyXG4gICAgc2V0R2xvYmFsU2VhcmNoKCcnKTtcclxuICAgIHNldFNlbGVjdGVkU3RkKCcnKTtcclxuICB9O1xyXG5cclxuICAvLyBPcGVuIEFkZCBTdHVkZW50IE1vZGFsXHJcbiAgY29uc3QgaGFuZGxlT3BlbkFkZE1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0RWRpdGluZ1N0dWRlbnQobnVsbCk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIG5hbWU6ICcnLFxyXG4gICAgICBnZW5kZXI6ICdmZW1hbGUnLFxyXG4gICAgICBkb2I6ICcyMDA5LTA2LTE1JyxcclxuICAgICAgc3RhbmRhcmQ6ICc5JyxcclxuICAgICAgcGFyZW50TmFtZTogJycsXHJcbiAgICAgIHBob25lOiAnJyxcclxuICAgICAgc3RhdHVzOiAnYWN0aXZlJyxcclxuICAgICAgcGFuY2hheWF0SWQ6IGFjdGl2ZVBhbmNoYXlhdD8uaWQgfHwgJycsXHJcbiAgICAgIHZpbGxhZ2VOYW1lOiBzZWxlY3RlZFZpbGxhZ2VOYW1lIHx8ICcnLFxyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93QWRkTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRWRpdFN0dWRlbnQgPSAoc3R1ZGVudDogU3R1ZGVudCkgPT4ge1xyXG4gICAgc2V0RWRpdGluZ1N0dWRlbnQoc3R1ZGVudCk7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIG5hbWU6IHN0dWRlbnQubmFtZSxcclxuICAgICAgZ2VuZGVyOiBzdHVkZW50LmdlbmRlciA9PT0gJ21hbGUnID8gJ21hbGUnIDogJ2ZlbWFsZScsXHJcbiAgICAgIGRvYjogc3R1ZGVudC5kb2IgfHwgJzIwMDktMDYtMTUnLFxyXG4gICAgICBzdGFuZGFyZDogWyc5JywgJzEwJywgJzExJywgJzEyJ10uaW5jbHVkZXMoc3R1ZGVudC5zdGFuZGFyZCkgPyBzdHVkZW50LnN0YW5kYXJkIDogJzknLFxyXG4gICAgICBwYXJlbnROYW1lOiBzdHVkZW50LnBhcmVudE5hbWUgfHwgJycsXHJcbiAgICAgIHBob25lOiBzdHVkZW50LnBob25lIHx8ICcrOTEgJyxcclxuICAgICAgc3RhdHVzOiBzdHVkZW50LnN0YXR1cyB8fCAnYWN0aXZlJyxcclxuICAgICAgcGFuY2hheWF0SWQ6IHN0dWRlbnQucGFuY2hheWF0SWQgfHwgYWN0aXZlUGFuY2hheWF0Py5pZCB8fCAnJyxcclxuICAgICAgdmlsbGFnZU5hbWU6IHN0dWRlbnQudmlsbGFnZU5hbWUgfHwgc2VsZWN0ZWRWaWxsYWdlTmFtZSB8fCAnJyxcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd0FkZE1vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNhdmVTdHVkZW50ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKCFmb3JtRGF0YS5uYW1lLnRyaW0oKSkge1xyXG4gICAgICBhbGVydCgnUGxlYXNlIGVudGVyIHN0dWRlbnQgbmFtZScpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYW5jaGF5YXRJZCB8fCAhZm9ybURhdGEudmlsbGFnZU5hbWUpIHtcclxuICAgICAgYWxlcnQoJ1BsZWFzZSBzZWxlY3QgYSBUYXJnZXQgUGFuY2hheWF0IGFuZCBWaWxsYWdlLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGFyZ2V0UGFuY2hheWF0ID0gcGFuY2hheWF0cy5maW5kKHAgPT4gcC5pZCA9PT0gZm9ybURhdGEucGFuY2hheWF0SWQpO1xyXG4gICAgaWYgKCF0YXJnZXRQYW5jaGF5YXQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBjdXJyZW50VmlsbGFnZUlkID0gdGFyZ2V0UGFuY2hheWF0LnZpbGxhZ2VzLmZpbmQodiA9PiB2Lm5hbWUgPT09IGZvcm1EYXRhLnZpbGxhZ2VOYW1lKT8uaWQgfHwgZm9ybURhdGEudmlsbGFnZU5hbWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9cXHMrL2csICctJyk7XHJcblxyXG4gICAgaWYgKGVkaXRpbmdTdHVkZW50KSB7XHJcbiAgICAgIGlmIChvbkVkaXRTdHVkZW50KSB7XHJcbiAgICAgICAgb25FZGl0U3R1ZGVudChlZGl0aW5nU3R1ZGVudC5pZCwge1xyXG4gICAgICAgICAgbmFtZTogZm9ybURhdGEubmFtZS50cmltKCksXHJcbiAgICAgICAgICBnZW5kZXI6IGZvcm1EYXRhLmdlbmRlcixcclxuICAgICAgICAgIGRvYjogZm9ybURhdGEuZG9iLFxyXG4gICAgICAgICAgc3RhbmRhcmQ6IGZvcm1EYXRhLnN0YW5kYXJkLFxyXG4gICAgICAgICAgcGFyZW50TmFtZTogZm9ybURhdGEucGFyZW50TmFtZS50cmltKCksXHJcbiAgICAgICAgICBwaG9uZTogZm9ybURhdGEucGhvbmUudHJpbSgpLFxyXG4gICAgICAgICAgc3RhdHVzOiBmb3JtRGF0YS5zdGF0dXMsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAob25VcGRhdGVTdHVkZW50KSB7XHJcbiAgICAgICAgb25VcGRhdGVTdHVkZW50KGVkaXRpbmdTdHVkZW50LmlkLCB7XHJcbiAgICAgICAgICBuYW1lOiBmb3JtRGF0YS5uYW1lLnRyaW0oKSxcclxuICAgICAgICAgIGdlbmRlcjogZm9ybURhdGEuZ2VuZGVyLFxyXG4gICAgICAgICAgZG9iOiBmb3JtRGF0YS5kb2IsXHJcbiAgICAgICAgICBzdGFuZGFyZDogZm9ybURhdGEuc3RhbmRhcmQsXHJcbiAgICAgICAgICBwYXJlbnROYW1lOiBmb3JtRGF0YS5wYXJlbnROYW1lLnRyaW0oKSxcclxuICAgICAgICAgIHBob25lOiBmb3JtRGF0YS5waG9uZS50cmltKCksXHJcbiAgICAgICAgICBzdGF0dXM6IGZvcm1EYXRhLnN0YXR1cyxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICBzaG93VG9hc3QoYFVwZGF0ZWQgc3R1ZGVudCAke2Zvcm1EYXRhLm5hbWUudHJpbSgpfWApO1xyXG4gICAgICBzZXRFZGl0aW5nU3R1ZGVudChudWxsKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG9uQWRkU3R1ZGVudCh7XHJcbiAgICAgICAgbmFtZTogZm9ybURhdGEubmFtZS50cmltKCksXHJcbiAgICAgICAgZ2VuZGVyOiBmb3JtRGF0YS5nZW5kZXIsXHJcbiAgICAgICAgZG9iOiBmb3JtRGF0YS5kb2IsXHJcbiAgICAgICAgc3RhbmRhcmQ6IGZvcm1EYXRhLnN0YW5kYXJkLFxyXG4gICAgICAgIHBhbmNoYXlhdElkOiBhY3RpdmVQYW5jaGF5YXQuaWQsXHJcbiAgICAgICAgcGFuY2hheWF0TmFtZTogYWN0aXZlUGFuY2hheWF0Lm5hbWUsXHJcbiAgICAgICAgdmlsbGFnZUlkOiBjdXJyZW50VmlsbGFnZUlkLFxyXG4gICAgICAgIHZpbGxhZ2VOYW1lOiBzZWxlY3RlZFZpbGxhZ2VOYW1lLFxyXG4gICAgICAgIHBhcmVudE5hbWU6IGZvcm1EYXRhLnBhcmVudE5hbWUudHJpbSgpLFxyXG4gICAgICAgIHBob25lOiBmb3JtRGF0YS5waG9uZS50cmltKCksXHJcbiAgICAgICAgc3RhdHVzOiBmb3JtRGF0YS5zdGF0dXMsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzaG93VG9hc3QoYEFkZGVkIHN0dWRlbnQgJHtmb3JtRGF0YS5uYW1lLnRyaW0oKX0gc3VjY2Vzc2Z1bGx5YCk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0U2hvd0FkZE1vZGFsKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBFWENFTCBJTVBPUlQgJiBCVUxLIFVQTE9BRCBIQU5ETEVSU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBjb25zdCBoYW5kbGVEb3dubG9hZFNhbXBsZUV4Y2VsID0gKCkgPT4ge1xyXG4gICAgY29uc3Qgc2FtcGxlRGF0YSA9IFtcclxuICAgICAge1xyXG4gICAgICAgICdTdHVkZW50IE5hbWUnOiAnS2F2eWEgUy4nLFxyXG4gICAgICAgICdHZW5kZXInOiAnRmVtYWxlJyxcclxuICAgICAgICAnU3RhbmRhcmQnOiAnOScsXHJcbiAgICAgICAgJ0RhdGUgb2YgQmlydGgnOiAnMjAxMC0wNC0xNScsXHJcbiAgICAgICAgJ1BhcmVudCBOYW1lJzogJ1NyaW5pdmFzYW4gSy4nLFxyXG4gICAgICAgICdDb250YWN0IFBob25lJzogJys5MSA5NDQzMiAxMTIyMycsXHJcbiAgICAgICAgJ1N0YXR1cyc6ICdBY3RpdmUnLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgJ1N0dWRlbnQgTmFtZSc6ICdHb2t1bCBOYXRoYW4nLFxyXG4gICAgICAgICdHZW5kZXInOiAnTWFsZScsXHJcbiAgICAgICAgJ1N0YW5kYXJkJzogJzEwJyxcclxuICAgICAgICAnRGF0ZSBvZiBCaXJ0aCc6ICcyMDA5LTA4LTIwJyxcclxuICAgICAgICAnUGFyZW50IE5hbWUnOiAnTmF0aGFuIFAuJyxcclxuICAgICAgICAnQ29udGFjdCBQaG9uZSc6ICcrOTEgOTg0MjEgOTk4ODcnLFxyXG4gICAgICAgICdTdGF0dXMnOiAnQWN0aXZlJyxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgICdTdHVkZW50IE5hbWUnOiAnRGVlcGlrYSBSLicsXHJcbiAgICAgICAgJ0dlbmRlcic6ICdGZW1hbGUnLFxyXG4gICAgICAgICdTdGFuZGFyZCc6ICcxMScsXHJcbiAgICAgICAgJ0RhdGUgb2YgQmlydGgnOiAnMjAwOC0wMS0xMCcsXHJcbiAgICAgICAgJ1BhcmVudCBOYW1lJzogJ1JhbWVzaCBULicsXHJcbiAgICAgICAgJ0NvbnRhY3QgUGhvbmUnOiAnKzkxIDk3ODkwIDQ0NTU2JyxcclxuICAgICAgICAnU3RhdHVzJzogJ0FjdGl2ZScsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICAnU3R1ZGVudCBOYW1lJzogJ1ZpZ25lc2ggTS4nLFxyXG4gICAgICAgICdHZW5kZXInOiAnTWFsZScsXHJcbiAgICAgICAgJ1N0YW5kYXJkJzogJzEyJyxcclxuICAgICAgICAnRGF0ZSBvZiBCaXJ0aCc6ICcyMDA3LTExLTI4JyxcclxuICAgICAgICAnUGFyZW50IE5hbWUnOiAnTXVydWdlc2FuIFYuJyxcclxuICAgICAgICAnQ29udGFjdCBQaG9uZSc6ICcrOTEgOTg0MDIgNzc4ODknLFxyXG4gICAgICAgICdTdGF0dXMnOiAnQWN0aXZlJyxcclxuICAgICAgfSxcclxuICAgIF07XHJcblxyXG4gICAgY29uc3Qgd3MgPSBYTFNYLnV0aWxzLmpzb25fdG9fc2hlZXQoc2FtcGxlRGF0YSk7XHJcbiAgICBjb25zdCB3YiA9IFhMU1gudXRpbHMuYm9va19uZXcoKTtcclxuICAgIFhMU1gudXRpbHMuYm9va19hcHBlbmRfc2hlZXQod2IsIHdzLCAnU3R1ZGVudHNfVGVtcGxhdGUnKTtcclxuICAgIFhMU1gud3JpdGVGaWxlKHdiLCBgU3R1ZGVudF9JbXBvcnRfVGVtcGxhdGVfJHtzZWxlY3RlZFZpbGxhZ2VOYW1lIHx8ICdWaWxsYWdlJ30ueGxzeGApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpbGVVcGxvYWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcclxuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xyXG4gICAgaWYgKCFmaWxlKSByZXR1cm47XHJcblxyXG4gICAgc2V0SW1wb3J0RmlsZU5hbWUoZmlsZS5uYW1lKTtcclxuICAgIHNldElzUGFyc2luZ0ZpbGUodHJ1ZSk7XHJcbiAgICBzZXRJbXBvcnRSb3dzKFtdKTtcclxuXHJcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgcmVhZGVyLm9ubG9hZCA9IChldnQpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBic3RyID0gZXZ0LnRhcmdldD8ucmVzdWx0O1xyXG4gICAgICAgIGNvbnN0IHdiID0gWExTWC5yZWFkKGJzdHIsIHsgdHlwZTogJ2JpbmFyeScgfSk7XHJcbiAgICAgICAgY29uc3QgZmlyc3RTaGVldE5hbWUgPSB3Yi5TaGVldE5hbWVzWzBdO1xyXG4gICAgICAgIGNvbnN0IHdzID0gd2IuU2hlZXRzW2ZpcnN0U2hlZXROYW1lXTtcclxuICAgICAgICBjb25zdCByYXdKc29uOiBhbnlbXSA9IFhMU1gudXRpbHMuc2hlZXRfdG9fanNvbih3cywgeyBkZWZ2YWw6ICcnIH0pO1xyXG5cclxuICAgICAgICBpZiAocmF3SnNvbi5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgIGFsZXJ0KCdUaGUgdXBsb2FkZWQgc2hlZXQgaXMgZW1wdHkuIFBsZWFzZSBjaGVjayB0aGUgZmlsZS4nKTtcclxuICAgICAgICAgIHNldElzUGFyc2luZ0ZpbGUoZmFsc2UpO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcGFyc2VkOiBQYXJzZWRTdHVkZW50Um93W10gPSByYXdKc29uLm1hcCgocm93KSA9PiB7XHJcbiAgICAgICAgICAvLyBOb3JtYWxpemUgY29sdW1uIG5hbWVzXHJcbiAgICAgICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMocm93KTtcclxuICAgICAgICAgIGNvbnN0IGZpbmRWYWwgPSAodGVybXM6IHN0cmluZ1tdKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IG1hdGNoZWRLZXkgPSBrZXlzLmZpbmQoKGspID0+XHJcbiAgICAgICAgICAgICAgdGVybXMuc29tZSgodCkgPT4gay50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1teYS16MC05XS9nLCAnJykuaW5jbHVkZXModCkpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIHJldHVybiBtYXRjaGVkS2V5ID8gU3RyaW5nKHJvd1ttYXRjaGVkS2V5XSkudHJpbSgpIDogJyc7XHJcbiAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgIGNvbnN0IG5hbWUgPSBmaW5kVmFsKFsnbmFtZScsICdzdHVkZW50bmFtZScsICdmdWxsbmFtZSddKSB8fCAnJztcclxuICAgICAgICAgIGNvbnN0IHJhd0dlbmRlciA9IGZpbmRWYWwoWydnZW5kZXInLCAnc2V4J10pLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICBjb25zdCBnZW5kZXI6ICdtYWxlJyB8ICdmZW1hbGUnID1cclxuICAgICAgICAgICAgcmF3R2VuZGVyLnN0YXJ0c1dpdGgoJ20nKSB8fCByYXdHZW5kZXIuaW5jbHVkZXMoJ2JveScpID8gJ21hbGUnIDogJ2ZlbWFsZSc7XHJcblxyXG4gICAgICAgICAgY29uc3QgcmF3U3RkID0gZmluZFZhbChbJ3N0YW5kYXJkJywgJ3N0ZCcsICdjbGFzcycsICdncmFkZSddKTtcclxuICAgICAgICAgIGxldCBzdGFuZGFyZCA9ICc5JztcclxuICAgICAgICAgIGNvbnN0IG51bU1hdGNoID0gcmF3U3RkLm1hdGNoKC9cXGQrLyk7XHJcbiAgICAgICAgICBpZiAobnVtTWF0Y2gpIHtcclxuICAgICAgICAgICAgY29uc3QgbnVtID0gbnVtTWF0Y2hbMF07XHJcbiAgICAgICAgICAgIGlmIChbJzknLCAnMTAnLCAnMTEnLCAnMTInXS5pbmNsdWRlcyhudW0pKSB7XHJcbiAgICAgICAgICAgICAgc3RhbmRhcmQgPSBudW07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgc3RhbmRhcmQgPSAnOSc7IC8vIGRlZmF1bHQgZmFsbGJhY2sgdG8gOVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgY29uc3QgZG9iID0gZmluZFZhbChbJ2RvYicsICdiaXJ0aCcsICdkYXRlb2ZiaXJ0aCddKSB8fCAnMjAwOS0wNi0xNSc7XHJcbiAgICAgICAgICBjb25zdCBwYXJlbnROYW1lID0gZmluZFZhbChbJ3BhcmVudCcsICdndWFyZGlhbicsICdmYXRoZXInLCAnbW90aGVyJ10pIHx8ICcnO1xyXG4gICAgICAgICAgY29uc3QgcGhvbmUgPSBmaW5kVmFsKFsncGhvbmUnLCAnbW9iaWxlJywgJ2NvbnRhY3QnXSkgfHwgJys5MSAnO1xyXG4gICAgICAgICAgY29uc3QgcmF3U3RhdHVzID0gZmluZFZhbChbJ3N0YXR1cyddKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgY29uc3Qgc3RhdHVzOiAnYWN0aXZlJyB8ICdpbmFjdGl2ZScgPSByYXdTdGF0dXMuaW5jbHVkZXMoJ2luYWN0JykgPyAnaW5hY3RpdmUnIDogJ2FjdGl2ZSc7XHJcblxyXG4gICAgICAgICAgbGV0IGlzVmFsaWQgPSB0cnVlO1xyXG4gICAgICAgICAgbGV0IHZhbGlkYXRpb25FcnJvciA9ICcnO1xyXG4gICAgICAgICAgaWYgKCFuYW1lKSB7XHJcbiAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgdmFsaWRhdGlvbkVycm9yID0gJ1N0dWRlbnQgbmFtZSBpcyBtaXNzaW5nJztcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBuYW1lLFxyXG4gICAgICAgICAgICBnZW5kZXIsXHJcbiAgICAgICAgICAgIHN0YW5kYXJkLFxyXG4gICAgICAgICAgICBkb2IsXHJcbiAgICAgICAgICAgIHBhcmVudE5hbWUsXHJcbiAgICAgICAgICAgIHBob25lLFxyXG4gICAgICAgICAgICBzdGF0dXMsXHJcbiAgICAgICAgICAgIGlzVmFsaWQsXHJcbiAgICAgICAgICAgIHZhbGlkYXRpb25FcnJvcixcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldEltcG9ydFJvd3MocGFyc2VkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgcmVhZGluZyBleGNlbCBmaWxlOicsIGVycik7XHJcbiAgICAgICAgYWxlcnQoJ0NvdWxkIG5vdCByZWFkIEV4Y2VsIGZpbGUuIFBsZWFzZSBlbnN1cmUgaXQgaXMgYSB2YWxpZCAueGxzeCBvciAuY3N2IGZpbGUuJyk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNQYXJzaW5nRmlsZShmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGZpbGUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvbmZpcm1CdWxrSW1wb3J0ID0gKCkgPT4ge1xyXG4gICAgaWYgKCFpbXBvcnRQYW5jaGF5YXRJZCB8fCAhaW1wb3J0VmlsbGFnZU5hbWUpIHtcclxuICAgICAgYWxlcnQoJ1BsZWFzZSBzZWxlY3QgYSBQYW5jaGF5YXQgYW5kIFZpbGxhZ2UgYmVmb3JlIGltcG9ydGluZy4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgdGd0UGFuY2hheWF0ID0gcGFuY2hheWF0cy5maW5kKHAgPT4gcC5pZCA9PT0gaW1wb3J0UGFuY2hheWF0SWQpO1xyXG4gICAgaWYgKCF0Z3RQYW5jaGF5YXQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB2YWxpZFJvd3MgPSBpbXBvcnRSb3dzLmZpbHRlcigocikgPT4gci5pc1ZhbGlkICYmIHIubmFtZS50cmltKCkubGVuZ3RoID4gMCk7XHJcbiAgICBpZiAodmFsaWRSb3dzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhbGVydCgnTm8gdmFsaWQgc3R1ZGVudCByZWNvcmRzIGZvdW5kIHRvIGltcG9ydC4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGN1cnJlbnRWaWxsYWdlSWQgPSBhY3RpdmVWaWxsYWdlPy5pZCB8fCBzZWxlY3RlZFZpbGxhZ2VOYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKy9nLCAnLScpO1xyXG5cclxuICAgIGNvbnN0IGZvcm1hdHRlZFN0dWRlbnRzID0gdmFsaWRSb3dzLm1hcCgocikgPT4gKHtcclxuICAgICAgbmFtZTogci5uYW1lLFxyXG4gICAgICBnZW5kZXI6IHIuZ2VuZGVyLFxyXG4gICAgICBkb2I6IHIuZG9iLFxyXG4gICAgICBzdGFuZGFyZDogci5zdGFuZGFyZCxcclxuICAgICAgcGFuY2hheWF0SWQ6IGFjdGl2ZVBhbmNoYXlhdC5pZCxcclxuICAgICAgcGFuY2hheWF0TmFtZTogYWN0aXZlUGFuY2hheWF0Lm5hbWUsXHJcbiAgICAgIHZpbGxhZ2VJZDogY3VycmVudFZpbGxhZ2VJZCxcclxuICAgICAgdmlsbGFnZU5hbWU6IHNlbGVjdGVkVmlsbGFnZU5hbWUsXHJcbiAgICAgIHBhcmVudE5hbWU6IHIucGFyZW50TmFtZSxcclxuICAgICAgcGhvbmU6IHIucGhvbmUsXHJcbiAgICAgIHN0YXR1czogci5zdGF0dXMsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgaWYgKG9uQnVsa0ltcG9ydFN0dWRlbnRzKSB7XHJcbiAgICAgIG9uQnVsa0ltcG9ydFN0dWRlbnRzKGZvcm1hdHRlZFN0dWRlbnRzLCB0Z3RQYW5jaGF5YXQuY2x1c3RlcklkIHx8IHRndFBhbmNoYXlhdC5jbHVzdGVyIHx8ICcnKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvcm1hdHRlZFN0dWRlbnRzLmZvckVhY2goKHN0KSA9PiBvbkFkZFN0dWRlbnQoc3QpKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJbXBvcnRTdWNjZXNzTWVzc2FnZShcclxuICAgICAgYFN1Y2Nlc3NmdWxseSBpbXBvcnRlZCAke2Zvcm1hdHRlZFN0dWRlbnRzLmxlbmd0aH0gc3R1ZGVudHMgaW50byAke3NlbGVjdGVkVmlsbGFnZU5hbWV9LCAke2FjdGl2ZVBhbmNoYXlhdC5uYW1lfSFgXHJcbiAgICApO1xyXG4gICAgc2V0U2hvd0ltcG9ydE1vZGFsKGZhbHNlKTtcclxuICAgIHNldEltcG9ydFJvd3MoW10pO1xyXG4gICAgc2V0SW1wb3J0RmlsZU5hbWUoJycpO1xyXG5cclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBzZXRJbXBvcnRTdWNjZXNzTWVzc2FnZShudWxsKTtcclxuICAgIH0sIDYwMDApO1xyXG4gIH07XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIFJFTkRFUjogTEVWRUwgMSAoUEFOQ0hBWUFUUyBDQVJEUylcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBpZiAoIXNlbGVjdGVkUGFuY2hheWF0SWQpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktNlwiPlxyXG4gICAgICAgIHsvKiAxLiBDYXJkbGVzcyBQYWdlIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICBTdHVkZW50cyBieSBQYW5jaGF5YXRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cInByaW1hcnlcIiBzaXplPVwic21cIj5cclxuICAgICAgICAgICAgICAgIHtjbHVzdGVyVG90YWxTdHVkZW50c30gVG90YWxcclxuICAgICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgU2VsZWN0IGFueSBQYW5jaGF5YXQgYmVsb3cgdG8gZXhwbG9yZSBpdHMgdmlsbGFnZXMgYW5kIG1hbmFnZSBzdHVkZW50IHJvc3RlcnMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldEltcG9ydFBhbmNoYXlhdElkKCcnKTtcclxuICAgICAgICAgICAgICAgIHNldEltcG9ydFZpbGxhZ2VOYW1lKCcnKTtcclxuICAgICAgICAgICAgICAgIHNldFNob3dJbXBvcnRNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtNCBweS0yLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4+QnVsayBJbXBvcnQgKEV4Y2VsKTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVPcGVuQWRkTW9kYWwoKTtcclxuICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBwYW5jaGF5YXRJZDogJycsIHZpbGxhZ2VOYW1lOiAnJyB9KSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBiZy1icmFuZC01MDAgcHgtNCBweS0yLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkFkZCBTdHVkZW50PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogMi4gQ29tcGFjdCBNZXRyaWMgQ2FyZHMgKGNvdW50cyAmIHN0YXR1cyBvbmx5KSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlRvdGFsIEVucm9sbGVkPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3RlclRvdGFsU3R1ZGVudHN9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+8J+RpiBCb3lzPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3RlckJveXN9PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LW9yYW5nZS01MDAgZGFyazp0ZXh0LW9yYW5nZS00MDBcIj7wn5GnIEdpcmxzPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3RlckdpcmxzfTwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiAzLiBDYXJkbGVzcyBTZWFyY2ggQmFyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIGFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwIHRleHQtWzE4cHhdIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgc2VhcmNoXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBwYW5jaGF5YXRzIG9yIGNsdXN0ZXIuLi5cIlxyXG4gICAgICAgICAgICB2YWx1ZT17Z2xvYmFsU2VhcmNofVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEdsb2JhbFNlYXJjaChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcGwtMTAgcHItNCBweS0yLjUgdGV4dC1zbSB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnBsYWNlaG9sZGVyOnRleHQtZ3JheS01MDBcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2ltcG9ydFN1Y2Nlc3NNZXNzYWdlICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN1Y2Nlc3MtMjAwIGJnLXN1Y2Nlc3MtNTAgcC00IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zdWNjZXNzLTYwMCBkYXJrOmJvcmRlci1zdWNjZXNzLTkwMC80MCBkYXJrOmJnLXN1Y2Nlc3MtNTAwLzEwIGRhcms6dGV4dC1zdWNjZXNzLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4+e2ltcG9ydFN1Y2Nlc3NNZXNzYWdlfTwvc3Bhbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEltcG9ydFN1Y2Nlc3NNZXNzYWdlKG51bGwpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc3VjY2Vzcy02MDAgaG92ZXI6dGV4dC1zdWNjZXNzLTgwMCBkYXJrOnRleHQtc3VjY2Vzcy00MDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmNsb3NlPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiA0LiBDYXJkbGVzcyBHcmlkIExpc3QgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC01XCI+XHJcbiAgICAgICAgICB7cGFuY2hheWF0c1xyXG4gICAgICAgICAgICAuZmlsdGVyKChwKSA9PiBwLm5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhnbG9iYWxTZWFyY2gudG9Mb3dlckNhc2UoKSkpXHJcbiAgICAgICAgICAgIC5tYXAoKHBhbmNoYXlhdCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHBhblN0dWRlbnRzID0gc3R1ZGVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgKHMpID0+IHMucGFuY2hheWF0SWQgPT09IHBhbmNoYXlhdC5pZCB8fCBzLnBhbmNoYXlhdE5hbWUudG9Mb3dlckNhc2UoKSA9PT0gcGFuY2hheWF0Lm5hbWUudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgY29uc3QgYm95c0NvdW50ID0gcGFuU3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLmdlbmRlciA9PT0gJ21hbGUnKS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgY29uc3QgZ2lybHNDb3VudCA9IHBhblN0dWRlbnRzLmZpbHRlcigocykgPT4gcy5nZW5kZXIgPT09ICdmZW1hbGUnKS5sZW5ndGg7XHJcblxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGtleT17cGFuY2hheWF0LmlkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RQYW5jaGF5YXQocGFuY2hheWF0LmlkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgc2hhZG93LXRoZW1lLXhzIHRyYW5zaXRpb24tYWxsIGhvdmVyOmJvcmRlci1icmFuZC0zMDAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gZGFyazpob3Zlcjpib3JkZXItYnJhbmQtODAwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0ZXh0LWdyYXktNDAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3BhbmNoYXlhdC5jbHVzdGVyfSBDbHVzdGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC1icmFuZC01MDAgdHJhbnNpdGlvbi1jb2xvcnMgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3BhbmNoYXlhdC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBhbmNoYXlhdC5zdGF0dXMgPT09ICdPbiBUcmFjaydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3N1Y2Nlc3MnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHBhbmNoYXlhdC5zdGF0dXMgPT09ICdDb3JyZWN0aW9uIFJlcXVpcmVkJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICd3YXJuaW5nJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdlcnJvcidcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGFuY2hheWF0LnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3BhbmNoYXlhdC52aWxsYWdlcy5sZW5ndGggfHwgcGFuY2hheWF0LnZpbGxhZ2VzQ291bnR9IFZpbGxhZ2VzICZtaWRkb3Q7IHtwYW5TdHVkZW50cy5sZW5ndGh9IFN0dWRlbnRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgcm91bmRlZC14bCBiZy1ncmF5LTUwLzgwIHAtMi41IHRleHQteHMgZGFyazpiZy13aGl0ZS9bMC4wMl1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbVwiPvCfkaY8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+Qm95czwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Ym95c0NvdW50fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+8J+Rpzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5HaXJsczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Z2lybHNDb3VudH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMS41IHB0LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwYW5jaGF5YXQudmlsbGFnZXMubWFwKCh2KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt2LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt2Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMC41IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmlldyBWaWxsYWdlczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+YXJyb3dfZm9yd2FyZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gUkVOREVSOiBMRVZFTCAyIChWSUxMQUdFUyBJTiBQQU5DSEFZQVQpXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgaWYgKGFjdGl2ZVBhbmNoYXlhdCAmJiAhc2VsZWN0ZWRWaWxsYWdlTmFtZSkge1xyXG4gICAgY29uc3QgcGFuY2hheWF0U3R1ZGVudHMgPSBzdHVkZW50cy5maWx0ZXIoXHJcbiAgICAgIChzKSA9PiBzLnBhbmNoYXlhdElkID09PSBhY3RpdmVQYW5jaGF5YXQuaWQgfHwgcy5wYW5jaGF5YXROYW1lLnRvTG93ZXJDYXNlKCkgPT09IGFjdGl2ZVBhbmNoYXlhdC5uYW1lLnRvTG93ZXJDYXNlKClcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XHJcbiAgICAgICAgey8qIDEuIENhcmRsZXNzIFBhZ2UgSGVhZGVyIHdpdGggQnJlYWRjcnVtYnMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJhY2tUb1BhbmNoYXlhdHN9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LWJyYW5kLTUwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBQYW5jaGF5YXRzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPHNwYW4+Lzwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2FjdGl2ZVBhbmNoYXlhdC5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZVBhbmNoYXlhdC5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAgICB7YWN0aXZlUGFuY2hheWF0LnZpbGxhZ2VzLmxlbmd0aH0gVmlsbGFnZXNcclxuICAgICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICBTZWxlY3QgYSB2aWxsYWdlIGNhcmQgdG8gdmlldyBpdHMgc3R1ZGVudCByb3N0ZXIgKFN0YW5kYXJkcyA5IHRvIDEyKS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRJbXBvcnRQYW5jaGF5YXRJZChhY3RpdmVQYW5jaGF5YXQ/LmlkIHx8ICcnKTsgc2V0SW1wb3J0VmlsbGFnZU5hbWUoJycpOyBzZXRTaG93SW1wb3J0TW9kYWwodHJ1ZSk7IH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8c3Bhbj5CdWxrIEltcG9ydDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IGhhbmRsZU9wZW5BZGRNb2RhbCgpOyBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHBhbmNoYXlhdElkOiBhY3RpdmVQYW5jaGF5YXQ/LmlkIHx8ICcnLCB2aWxsYWdlTmFtZTogJycgfSkpOyB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4+QWRkIFN0dWRlbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQmFja1RvUGFuY2hheWF0c31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4+QmFjazwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIDIuIFZpbGxhZ2VzIEdyaWQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC01XCI+XHJcbiAgICAgICAgICB7YWN0aXZlUGFuY2hheWF0LnZpbGxhZ2VzLm1hcCgodmlsbGFnZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB2U3R1ZGVudHMgPSBwYW5jaGF5YXRTdHVkZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgKHMpID0+IHMudmlsbGFnZU5hbWUudG9Mb3dlckNhc2UoKSA9PT0gdmlsbGFnZS5uYW1lLnRvTG93ZXJDYXNlKCkgfHwgcy52aWxsYWdlSWQgPT09IHZpbGxhZ2UuaWRcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgY29uc3QgdkJveXMgPSB2U3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLmdlbmRlciA9PT0gJ21hbGUnKS5sZW5ndGg7XHJcbiAgICAgICAgICAgIGNvbnN0IHZHaXJscyA9IHZTdHVkZW50cy5maWx0ZXIoKHMpID0+IHMuZ2VuZGVyID09PSAnZmVtYWxlJykubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgY29uc3Qgc3RkOSA9IHZTdHVkZW50cy5maWx0ZXIoKHMpID0+IHMuc3RhbmRhcmQgPT09ICc5JykubGVuZ3RoO1xyXG4gICAgICAgICAgICBjb25zdCBzdGQxMCA9IHZTdHVkZW50cy5maWx0ZXIoKHMpID0+IHMuc3RhbmRhcmQgPT09ICcxMCcpLmxlbmd0aDtcclxuICAgICAgICAgICAgY29uc3Qgc3RkMTEgPSB2U3R1ZGVudHMuZmlsdGVyKChzKSA9PiBzLnN0YW5kYXJkID09PSAnMTEnKS5sZW5ndGg7XHJcbiAgICAgICAgICAgIGNvbnN0IHN0ZDEyID0gdlN0dWRlbnRzLmZpbHRlcigocykgPT4gcy5zdGFuZGFyZCA9PT0gJzEyJykubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e3ZpbGxhZ2UuaWR9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RWaWxsYWdlKHZpbGxhZ2UubmFtZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ym9yZGVyLWJyYW5kLTMwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBkYXJrOmhvdmVyOmJvcmRlci1icmFuZC04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1ncmF5LTQwMCBibG9ja1wiPlZpbGxhZ2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3ZpbGxhZ2UubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwicHJpbWFyeVwiIHNpemU9XCJzbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3ZTdHVkZW50cy5sZW5ndGh9IFN0dWRlbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgcm91bmRlZC14bCBiZy1ncmF5LTUwLzgwIHAtMi41IHRleHQteHMgZGFyazpiZy13aGl0ZS9bMC4wMl1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPvCfkaY8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5Cb3lzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dkJveXN9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPvCfkac8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5HaXJsczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3ZHaXJsc308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0ZXh0LWdyYXktNDAwIG1iLTEuNVwiPlN0YW5kYXJkIERpc3RyaWJ1dGlvbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMS41IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEgZGFyazpib3JkZXItZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIHRleHQtZ3JheS00MDAgZm9udC1ib2xkXCI+OXRoPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDBcIj57c3RkOX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC0xIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtYm9sZFwiPjEwdGg8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPntzdGQxMH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC0xIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtYm9sZFwiPjExdGg8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPntzdGQxMX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC0xIGRhcms6Ym9yZGVyLWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LWdyYXktNDAwIGZvbnQtYm9sZFwiPjEydGg8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLTUwMFwiPntzdGQxMn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC01MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMC41IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPk9wZW4gU3R1ZGVudCBSb3N0ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5hcnJvd19mb3J3YXJkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gUkVOREVSOiBMRVZFTCAzIChTVFVERU5UUyBST1NURVIgSU4gVklMTEFHRSlcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiAxLiBDYXJkbGVzcyBQYWdlIEhlYWRlciB3aXRoIEJyZWFkY3J1bWJzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCYWNrVG9QYW5jaGF5YXRzfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtYnJhbmQtNTAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUGFuY2hheWF0c1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPHNwYW4+Lzwvc3Bhbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJhY2tUb1ZpbGxhZ2VzfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtYnJhbmQtNTAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2FjdGl2ZVBhbmNoYXlhdD8ubmFtZX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxzcGFuPi88L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGVcIj57c2VsZWN0ZWRWaWxsYWdlTmFtZX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkVmlsbGFnZU5hbWV9IFJvc3RlclxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkUm9zdGVyU3R1ZGVudHMubGVuZ3RofSBTdHVkZW50c1xyXG4gICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAge2FjdGl2ZVBhbmNoYXlhdD8ubmFtZX0gUGFuY2hheWF0ICZtaWRkb3Q7IFN0YW5kYXJkcyA5IHRvIDEyXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0SW1wb3J0UGFuY2hheWF0SWQoYWN0aXZlUGFuY2hheWF0Py5pZCB8fCAnJyk7IHNldEltcG9ydFZpbGxhZ2VOYW1lKHNlbGVjdGVkVmlsbGFnZU5hbWUgfHwgJycpOyBzZXRTaG93SW1wb3J0TW9kYWwodHJ1ZSk7IH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuPkltcG9ydCBFeGNlbDwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlT3BlbkFkZE1vZGFsfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBiZy1icmFuZC01MDAgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4+QWRkIFN0dWRlbnQ8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJhY2tUb1ZpbGxhZ2VzfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3Bhbj5WaWxsYWdlczwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiAyLiBDYXJkbGVzcyBGaWx0ZXIgYW5kIFZpZXcgQ29udHJvbHMgQmFyICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIGFic29sdXRlIGxlZnQtMy41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwIHRleHQtWzE4cHhdIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgc2VhcmNoXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBzdHVkZW50IGJ5IG5hbWUgb3IgY29kZS4uLlwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtnbG9iYWxTZWFyY2h9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R2xvYmFsU2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwbC0xMCBwci00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktODAwIHNoYWRvdy10aGVtZS14cyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJyYW5kLTUwMC8xMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBkYXJrOnBsYWNlaG9sZGVyOnRleHQtZ3JheS01MDBcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIHtbJycsICc5JywgJzEwJywgJzExJywgJzEyJ10ubWFwKChzdGQpID0+IChcclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBrZXk9e3N0ZH1cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTdGQoc3RkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uICR7XHJcbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkU3RkID09PSBzdGRcclxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1icmFuZC01MDAgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMnXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgdGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6Ym9yZGVyLWdyYXktNzAwJ1xyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3N0ZCA9PT0gJycgPyAnQWxsICg5LTEyKScgOiBgU3RkICR7c3RkfWB9XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBib3JkZXItbCBib3JkZXItZ3JheS0yMDAgcGwtMiBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoJ3NwbGl0Jyl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbiAke1xyXG4gICAgICAgICAgICAgICAgdmlld01vZGUgPT09ICdzcGxpdCdcclxuICAgICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpib3JkZXItZ3JheS03MDAnXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBTcGxpdFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKCdhbGwnKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uICR7XHJcbiAgICAgICAgICAgICAgICB2aWV3TW9kZSA9PT0gJ2FsbCdcclxuICAgICAgICAgICAgICAgICAgPyAnYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgc2hhZG93LXRoZW1lLXhzJ1xyXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpib3JkZXItZ3JheS03MDAnXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBUYWJsZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBSb3N0ZXIgVmlld3MgKi99XHJcbiAgICAgIHt2aWV3TW9kZSA9PT0gJ3NwbGl0JyAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC01XCI+XHJcbiAgICAgICAgICB7LyogQm95cyBDb2x1bW4gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGdcIj7wn5GmPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5Cb3lzIFJvc3Rlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJwcmltYXJ5XCIgc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAgICB7Ym95U3R1ZGVudHMubGVuZ3RofSBCb3lzXHJcbiAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTEwMCBkYXJrOmRpdmlkZS1ncmF5LTgwMC82MCBwLTIgZmxleC0xIG92ZXJmbG93LXktYXV0byBtYXgtaC1bNTYwcHhdXCI+XHJcbiAgICAgICAgICAgICAge2JveVN0dWRlbnRzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICBObyBib3lzIGVucm9sbGVkIGluIHRoaXMgc2VsZWN0aW9uLlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIGJveVN0dWRlbnRzLm1hcCgoc3R1ZGVudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtzdHVkZW50LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdTdHVkZW50KHN0dWRlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBob3ZlcjpiZy1ncmF5LTUwLzgwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGN1cnNvci1wb2ludGVyIGdyb3VwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgZmxleC1zaHJpbmstMCBkYXJrOmJnLWJyYW5kLTUwMC8xMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdHVkZW50LmF2YXRhckxldHRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0dWRlbnQubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cImxpZ2h0XCIgc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdGQge3N0dWRlbnQuc3RhbmRhcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFyZW50OiB7c3R1ZGVudC5wYXJlbnROYW1lIHx8ICdOL0EnfSAmbWlkZG90OyB7c3R1ZGVudC5waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFZGl0U3R1ZGVudChzdHVkZW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1icmFuZC01MDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWRpdCBTdHVkZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmVkaXQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0dWRlbnRUb0RlbGV0ZShzdHVkZW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1lcnJvci01MDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIFN0dWRlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZGVsZXRlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBHaXJscyBDb2x1bW4gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGdcIj7wn5GnPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5HaXJscyBSb3N0ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPlxyXG4gICAgICAgICAgICAgICAge2dpcmxTdHVkZW50cy5sZW5ndGh9IEdpcmxzXHJcbiAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTEwMCBkYXJrOmRpdmlkZS1ncmF5LTgwMC82MCBwLTIgZmxleC0xIG92ZXJmbG93LXktYXV0byBtYXgtaC1bNTYwcHhdXCI+XHJcbiAgICAgICAgICAgICAge2dpcmxTdHVkZW50cy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgTm8gZ2lybHMgZW5yb2xsZWQgaW4gdGhpcyBzZWxlY3Rpb24uXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgZ2lybFN0dWRlbnRzLm1hcCgoc3R1ZGVudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtzdHVkZW50LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdTdHVkZW50KHN0dWRlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBob3ZlcjpiZy1ncmF5LTUwLzgwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGN1cnNvci1wb2ludGVyIGdyb3VwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctb3JhbmdlLTUwIHRleHQtb3JhbmdlLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC14cyBmbGV4LXNocmluay0wIGRhcms6Ymctb3JhbmdlLTUwMC8xMCBkYXJrOnRleHQtb3JhbmdlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3R1ZGVudC5hdmF0YXJMZXR0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC1vcmFuZ2UtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3R1ZGVudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwibGlnaHRcIiBzaXplPVwic21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0ZCB7c3R1ZGVudC5zdGFuZGFyZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYXJlbnQ6IHtzdHVkZW50LnBhcmVudE5hbWUgfHwgJ04vQSd9ICZtaWRkb3Q7IHtzdHVkZW50LnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVkaXRTdHVkZW50KHN0dWRlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWJyYW5kLTUwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IFN0dWRlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZWRpdDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3R1ZGVudFRvRGVsZXRlKHN0dWRlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWVycm9yLTUwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgU3R1ZGVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5kZWxldGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogMi4gVEFCTEUgVklFVyAqL31cclxuICAgICAgeyh2aWV3TW9kZSA9PT0gJ2FsbCcgfHwgdmlld01vZGUgPT09ICdib3lzJyB8fCB2aWV3TW9kZSA9PT0gJ2dpcmxzJykgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDJdXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBiZy1ncmF5LTUwLzUwIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gZGFyazp0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+Q29kZTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5TdHVkZW50IE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+R2VuZGVyPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlN0YW5kYXJkPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlBhcmVudCAvIEd1YXJkaWFuPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlBob25lPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC01IHB5LTMuNVwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0xMDAgZGFyazpkaXZpZGUtZ3JheS04MDAgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIHsodmlld01vZGUgPT09ICdib3lzJyA/IGJveVN0dWRlbnRzIDogdmlld01vZGUgPT09ICdnaXJscycgPyBnaXJsU3R1ZGVudHMgOiBmaWx0ZXJlZFJvc3RlclN0dWRlbnRzKS5sZW5ndGggPT09XHJcbiAgICAgICAgICAgICAgMCA/IChcclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezh9IGNsYXNzTmFtZT1cInB4LTUgcHktMTIgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5vIHN0dWRlbnRzIGZvdW5kIG1hdGNoaW5nIHRoZSBzZWxlY3RlZCBmaWx0ZXJzLlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgKHZpZXdNb2RlID09PSAnYm95cycgPyBib3lTdHVkZW50cyA6IHZpZXdNb2RlID09PSAnZ2lybHMnID8gZ2lybFN0dWRlbnRzIDogZmlsdGVyZWRSb3N0ZXJTdHVkZW50cykubWFwKFxyXG4gICAgICAgICAgICAgICAgICAoc3R1ZGVudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtzdHVkZW50LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld2luZ1N0dWRlbnQoc3R1ZGVudCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwLzgwIGRhcms6aG92ZXI6Ymctd2hpdGUvWzAuMDJdIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgZm9udC1tb25vIHRleHQtZ3JheS00MDBcIj57c3R1ZGVudC5jb2RlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e3N0dWRlbnQubmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj17c3R1ZGVudC5nZW5kZXIgPT09ICdtYWxlJyA/ICdwcmltYXJ5JyA6ICd3YXJuaW5nJ30gc2l6ZT1cInNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3N0dWRlbnQuZ2VuZGVyID09PSAnbWFsZScgPyAn8J+RpiBCb3knIDogJ/CfkacgR2lybCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdHVkZW50LnN0YW5kYXJkfXRoIFN0YW5kYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+e3N0dWRlbnQucGFyZW50TmFtZSB8fCAn4oCUJ308L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTUgcHktMy41IGZvbnQtbW9ubyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPntzdHVkZW50LnBob25lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNSBweS0zLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPXtzdHVkZW50LnN0YXR1cyA9PT0gJ2FjdGl2ZScgPyAnc3VjY2VzcycgOiAnbGlnaHQnfSBzaXplPVwic21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c3R1ZGVudC5zdGF0dXMgPT09ICdhY3RpdmUnID8gJ0FjdGl2ZScgOiAnSW5hY3RpdmUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC01IHB5LTMuNSB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMVwiIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVkaXRTdHVkZW50KHN0dWRlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBwLTEuNSB0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwIGhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSBkYXJrOmhvdmVyOnRleHQtYnJhbmQtNDAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZWRpdDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0dWRlbnRUb0RlbGV0ZShzdHVkZW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgcC0xLjUgdGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1lcnJvci01MCBob3Zlcjp0ZXh0LWVycm9yLTYwMCBkYXJrOmhvdmVyOmJnLWVycm9yLTUwMC8xMCBkYXJrOmhvdmVyOnRleHQtZXJyb3ItNDAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMTZweF1cIj5kZWxldGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBBREQgLyBFRElUIFNUVURFTlQgTU9EQUxcclxuICAgICAgICAgIC0gU3RhbmRhcmQgOSB0byAxMlxyXG4gICAgICAgICAgLSBQYW5jaGF5YXQgJiBWaWxsYWdlIHJlbW92ZWQgKGF1dG9tYXRpYylcclxuICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICB7c2hvd0FkZE1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei1bOTk5OTldIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ncmF5LTkwMC83NSBiYWNrZHJvcC1ibHVyLXNtIHRyYW5zaXRpb24tb3BhY2l0eVwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LW1kIGJnLXdoaXRlIHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIGgtZnVsbCB6LTEwIGFuaW1hdGUtW2ZhZGVJbl8wLjJzX2Vhc2Utb3V0XVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItWyNjNGM2ZDNdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1bI2Y0ZjNmYl1cIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1bMTdweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+cGVyc29uX2FkZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtlZGl0aW5nU3R1ZGVudCA/ICdFZGl0IFN0dWRlbnQnIDogJ0FkZCBOZXcgU3R1ZGVudCd9XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNlOGU3ZWZdIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMHB4XVwiPmNsb3NlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlU3R1ZGVudH0gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwLTYgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgey8qIFRhcmdldCBMb2NhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBiZy1ncmF5LTUwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS04MDAgcm91bmRlZC14bCBwLTMuNSBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMzAwIG1iLTFcIj5UYXJnZXQgUGFuY2hheWF0ICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYW5jaGF5YXRJZCB8fCAocGFuY2hheWF0c1swXT8uaWQgPz8gdW5kZWZpbmVkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBhbmNoYXlhdElkOiB2YWwsIHZpbGxhZ2VOYW1lOiAnJyB9KX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJoLTkgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGFuY2hheWF0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGFuY2hheWF0cy5tYXAocCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+e3AubmFtZX08L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0zMDAgbWItMVwiPlRhcmdldCBWaWxsYWdlICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS52aWxsYWdlTmFtZSB8fCAocGFuY2hheWF0cy5maW5kKHAgPT4gcC5pZCA9PT0gZm9ybURhdGEucGFuY2hheWF0SWQpPy52aWxsYWdlc1swXT8ubmFtZSA/PyB1bmRlZmluZWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdmlsbGFnZU5hbWU6IHZhbCB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshZm9ybURhdGEucGFuY2hheWF0SWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwiaC05IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFZpbGxhZ2VcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYW5jaGF5YXRzLmZpbmQocCA9PiBwLmlkID09PSBmb3JtRGF0YS5wYW5jaGF5YXRJZCk/LnZpbGxhZ2VzLm1hcCh2ID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e3YuaWR9IHZhbHVlPXt2Lm5hbWV9Pnt2Lm5hbWV9PC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5TdHVkZW50IEZ1bGwgTmFtZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgc3R1ZGVudCBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB0ZXh0LVsxM3B4XSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMDAyODY5XSBoLVszOHB4XVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogR2VuZGVyIFNlbGVjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+R2VuZGVyICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBnZW5kZXI6ICdtYWxlJyB9KX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTMgcm91bmRlZC1tZCBib3JkZXIgdGV4dC1bMTNweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5nZW5kZXIgPT09ICdtYWxlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1bI2RhZTJmZl0gYm9yZGVyLVsjMDAyODY5XSB0ZXh0LVsjMDAxOTQ3XSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLVsjYzRjNmQzXSBiZy13aGl0ZSB0ZXh0LVsjNDM0NjUyXSBob3ZlcjpiZy1bI2Y0ZjNmYl0nXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7DsMW44oCYwqY8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Qm95IC8gTWFsZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZ2VuZGVyOiAnZmVtYWxlJyB9KX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTMgcm91bmRlZC1tZCBib3JkZXIgdGV4dC1bMTNweF0gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5nZW5kZXIgPT09ICdmZW1hbGUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjZmZkYmM4XSBib3JkZXItWyNmYjc4MDBdIHRleHQtWyM1OTI2MDBdJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItWyNjNGM2ZDNdIGJnLXdoaXRlIHRleHQtWyM0MzQ2NTJdIGhvdmVyOmJnLVsjZjRmM2ZiXSdcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPsOwxbjigJjCpzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5HaXJsIC8gRmVtYWxlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogU3RhbmRhcmQgc3RyaWN0bHkgOSB0byAxMiBhcyByZXF1ZXN0ZWQgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5TdGFuZGFyZCAoQ2xhc3MpICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0YW5kYXJkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHN0YW5kYXJkOiB2YWwgfSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VHJpZ2dlciBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1bMzhweF0gdGV4dC1bMTNweF0gYm9yZGVyLVsjYzRjNmQzXSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlN0YW5kYXJkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIjlcIj45dGggU3RhbmRhcmQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cIjEwXCI+MTB0aCBTdGFuZGFyZDwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPVwiMTFcIj4xMXRoIFN0YW5kYXJkPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0gdmFsdWU9XCIxMlwiPjEydGggU3RhbmRhcmQ8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMnB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gbWItMVwiPkRhdGUgb2YgQmlydGg8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmRvYn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGRvYjogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSByb3VuZGVkLW1kIHRleHQtWzEzcHhdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItWyMwMDI4NjldIGgtWzM4cHhdXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+UGFyZW50IC8gR3VhcmRpYW4gTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBhcmVudCBvciBndWFyZGlhbiBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhcmVudE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGFyZW50TmFtZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB0ZXh0LVsxM3B4XSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMDAyODY5XSBoLVszOHB4XVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+Q29udGFjdCBQaG9uZSBOdW1iZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIis5MSA5ODc2NSA0MzIxMFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB0ZXh0LVsxM3B4XSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLVsjMDAyODY5XSBoLVszOHB4XVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+RW5yb2xsbWVudCBTdGF0dXM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICBvblZhbHVlQ2hhbmdlPXsodmFsKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBzdGF0dXM6IHZhbCBhcyAnYWN0aXZlJyB8ICdpbmFjdGl2ZScgfSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLVszOHB4XSB0ZXh0LVsxM3B4XSBib3JkZXItWyNjNGM2ZDNdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU3RhdHVzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImFjdGl2ZVwiPkFjdGl2ZTwvU2VsZWN0SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSB2YWx1ZT1cImluYWN0aXZlXCI+SW5hY3RpdmU8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItWyNjNGM2ZDNdIGJnLVsjZmFmOGZmXSBmbGV4IGp1c3RpZnktZW5kIGdhcC0zIC1teC02IC1tYi02IG10LTZcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLVsjNzQ3NzgzXSB0ZXh0LVsjNDM0NjUyXSBmb250LWJvbGQgdGV4dC1bMTNweF0gcm91bmRlZC1tZCBob3ZlcjpiZy1bI2Y0ZjNmYl0gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LVsxM3B4XSByb3VuZGVkLW1kIGhvdmVyOmJnLVsjMGIzZDkxXSB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3cteHMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZWRpdGluZ1N0dWRlbnQgPyAnVXBkYXRlIFN0dWRlbnQnIDogJ1NhdmUgU3R1ZGVudCd9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICAgICBFWENFTCBCVUxLIElNUE9SVCBNT0RBTFxyXG4gICAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgIHtzaG93SW1wb3J0TW9kYWwgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctc20gdy1mdWxsIG1heC13LTJ4bCBvdmVyZmxvdy1oaWRkZW4gYW5pbWF0ZS1bZmFkZUluXzAuMnNfZWFzZS1vdXRdIGZsZXggZmxleC1jb2wgbWF4LWgtWzkwdmhdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1bI2M0YzZkM10gZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGJnLVsjZjRmM2ZiXVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLW1kIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+dGFibGVfdmlldzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPkJ1bGsgSW1wb3J0IFN0dWRlbnRzIHZpYSBFeGNlbDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtWyM0MzQ2NTJdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVXBsb2FkIGFuZCBhdXRvbWF0aWNhbGx5IGVucm9sbCBzdHVkZW50cyBpbnRvIGEgdmlsbGFnZS5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93SW1wb3J0TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRJbXBvcnRSb3dzKFtdKTtcclxuICAgICAgICAgICAgICAgICAgc2V0SW1wb3J0RmlsZU5hbWUoJycpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtWyM0MzQ2NTJdIGhvdmVyOmJnLVsjZThlN2VmXSByb3VuZGVkLWZ1bGwgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjBweF1cIj5jbG9zZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTUgZmxleC0xIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICAgIHsvKiBUYXJnZXQgTG9jYXRpb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIGJnLVsjZjRmM2ZiXSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS82MCByb3VuZGVkLW1kIHAtMy41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTJweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldIG1iLTFcIj5UYXJnZXQgUGFuY2hheWF0ICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ltcG9ydFBhbmNoYXlhdElkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldEltcG9ydFBhbmNoYXlhdElkKHZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJbXBvcnRWaWxsYWdlTmFtZSgnJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLVszOHB4XSB0ZXh0LVsxM3B4XSBib3JkZXItWyNjNGM2ZDNdIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0VmFsdWUgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGFuY2hheWF0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGFuY2hheWF0cy5tYXAoKHApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXtwLmlkfSB2YWx1ZT17cC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3AubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEycHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBtYi0xXCI+VGFyZ2V0IFZpbGxhZ2UgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW1wb3J0VmlsbGFnZU5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25WYWx1ZUNoYW5nZT17KHZhbCkgPT4gc2V0SW1wb3J0VmlsbGFnZU5hbWUodmFsKX1cclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWltcG9ydFBhbmNoYXlhdElkfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgY2xhc3NOYW1lPVwidy1mdWxsIGgtWzM4cHhdIHRleHQtWzEzcHhdIGJvcmRlci1bI2M0YzZkM10gYmctd2hpdGUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFZhbHVlIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFZpbGxhZ2VcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0VHJpZ2dlcj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgIHsocGFuY2hheWF0cy5maW5kKChwKSA9PiBwLmlkID09PSBpbXBvcnRQYW5jaGF5YXRJZCk/LnZpbGxhZ2VzIHx8IFtdKS5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdEl0ZW0ga2V5PXt2LmlkfSB2YWx1ZT17di5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7di5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdENvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTdGVwIDE6IERvd25sb2FkIFNhbXBsZSAmIFVwbG9hZCBBcmVhICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHAtMy41IGJnLVsjZjRmM2ZiXSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXS82MCByb3VuZGVkLW1kXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XVwiPk5lZWQgdGhlIEV4Y2VsIEZvcm1hdD88L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LVsjNDM0NjUyXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERvd25sb2FkIHRoZSBwcmUtZm9ybWF0dGVkIEV4Y2VsIHRlbXBsYXRlIHdpdGggOXRoLTEydGggc3RhbmRhcmRzLlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRTYW1wbGVFeGNlbH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjMDAyODY5XSB0ZXh0LVsjMDAyODY5XSByb3VuZGVkLW1kIHRleHQtWzEycHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bI2RhZTJmZl0vMzAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZG93bmxvYWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIERvd25sb2FkIFRlbXBsYXRlICgueGxzeClcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVXBsb2FkIERyb3B6b25lICovfVxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItWyMwMDI4NjldLzQwIGhvdmVyOmJvcmRlci1bIzAwMjg2OV0gcm91bmRlZC1tZCBwLTYgdGV4dC1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgYmctWyNmYWY4ZmZdIGhvdmVyOmJnLVsjZjRmM2ZiXSB0cmFuc2l0aW9uLWFsbCBncm91cFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlVXBsb2FkfVxyXG4gICAgICAgICAgICAgICAgICBhY2NlcHQ9XCIueGxzeCwgLnhscywgLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLVsjZGFlMmZmXSB0ZXh0LVsjMDAyODY5XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTIgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgdGV4dC1bMjRweF1cIj5jbG91ZF91cGxvYWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpbXBvcnRGaWxlTmFtZSA/IGltcG9ydEZpbGVOYW1lIDogJ0NsaWNrIHRvIHNlbGVjdCBFeGNlbCAvIENTViBmaWxlJ31cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTJweF0gdGV4dC1bIzc0Nzc4M10gbXQtMVwiPlN1cHBvcnRzIC54bHN4LCAueGxzLCBhbmQgLmNzdiBmb3JtYXRzPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUGFyc2luZyBJbmRpY2F0b3IgKi99XHJcbiAgICAgICAgICAgICAge2lzUGFyc2luZ0ZpbGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgdGV4dC1jZW50ZXIgdGV4dC1bIzAwMjg2OV0gZm9udC1ib2xkIHRleHQtWzEzcHhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1hdGVyaWFsLXN5bWJvbHMtb3V0bGluZWQgYW5pbWF0ZS1zcGluIHRleHQtWzIwcHhdXCI+cHJvZ3Jlc3NfYWN0aXZpdHk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIFBhcnNpbmcgRXhjZWwgZGF0YSBhbmQgdmFsaWRhdGluZyBzdGFuZGFyZHMgOSB0byAxMi4uLlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIExpdmUgUHJldmlldyBUYWJsZSAqL31cclxuICAgICAgICAgICAgICB7aW1wb3J0Um93cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEycHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1bIzAwMjg2OV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBhcnNlZCB7aW1wb3J0Um93cy5sZW5ndGh9IFN0dWRlbnQgUm93czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1bI2U2ZjRlYV0gdGV4dC1bIzEzNzMzM10gcHgtMiBweS0wLjUgcm91bmRlZCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ltcG9ydFJvd3MuZmlsdGVyKChyKSA9PiByLmlzVmFsaWQpLmxlbmd0aH0gVmFsaWRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItWyNjNGM2ZDNdIHJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLVsyMjBweF0gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQtWzEycHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctWyNmNGYzZmJdIHRleHQtWyM0MzQ2NTJdIHVwcGVyY2FzZSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgc3RpY2t5IHRvcC0wIGJvcmRlci1iIGJvcmRlci1bI2M0YzZkM11cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5OYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+R2VuZGVyPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+U3RhbmRhcmQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5QYXJlbnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTJcIj5QaG9uZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMlwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1bI2M0YzZkM10vNDAgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ltcG9ydFJvd3MubWFwKChyLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpZHh9IGNsYXNzTmFtZT17ci5pc1ZhbGlkID8gJycgOiAnYmctWyNmZmRhZDZdLzIwJ30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+e3IubmFtZSB8fCAnw6LigqzigJ0nfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgY2FwaXRhbGl6ZVwiPntyLmdlbmRlcn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGZvbnQtYm9sZFwiPntyLnN0YW5kYXJkfXRoIFN0ZDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC1bIzQzNDY1Ml1cIj57ci5wYXJlbnROYW1lIHx8ICfDouKCrOKAnSd9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LVsjNDM0NjUyXVwiPntyLnBob25lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3IuaXNWYWxpZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjMTM3MzMzXSBmb250LWJvbGRcIj5SZWFkeTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjYmExYTFhXSBmb250LWJvbGRcIj57ci52YWxpZGF0aW9uRXJyb3J9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci10IGJvcmRlci1bI2M0YzZkM10gYmctWyNmYWY4ZmZdIGZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd0ltcG9ydE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0SW1wb3J0Um93cyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldEltcG9ydEZpbGVOYW1lKCcnKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1bMTNweF0gZm9udC1ib2xkIHRleHQtWyM0MzQ2NTJdIGJvcmRlciBib3JkZXItWyM3NDc3ODNdIHJvdW5kZWQtbWQgaG92ZXI6YmctWyNmNGYzZmJdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpbXBvcnRSb3dzLmxlbmd0aCA9PT0gMCB8fCBpbXBvcnRSb3dzLmZpbHRlcigocikgPT4gci5pc1ZhbGlkKS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25maXJtQnVsa0ltcG9ydH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMiB0ZXh0LVsxM3B4XSBmb250LWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3cteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICBpbXBvcnRSb3dzLmxlbmd0aCA+IDAgJiYgaW1wb3J0Um93cy5maWx0ZXIoKHIpID0+IHIuaXNWYWxpZCkubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIGhvdmVyOmJnLVsjMGIzZDkxXSdcclxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1bI2M0YzZkM10gdGV4dC13aGl0ZSBjdXJzb3Itbm90LWFsbG93ZWQnXHJcbiAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdXCI+Y2hlY2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICBDb25maXJtICZhbXA7IEltcG9ydCB7aW1wb3J0Um93cy5maWx0ZXIoKHIpID0+IHIuaXNWYWxpZCkubGVuZ3RofSBTdHVkZW50c1xyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgVklFVyBTVFVERU5UIERFVEFJTFMgTU9EQUxcclxuICAgICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICB7dmlld2luZ1N0dWRlbnQgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk5OV0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBzaGFkb3ctc20gdy1mdWxsIG1heC13LW1kIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLVtmYWRlSW5fMC4yc19lYXNlLW91dF1cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLVsjYzRjNmQzXSBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctWyNmNGYzZmJdXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtWzE3cHhdIGZvbnQtYm9sZCB0ZXh0LVsjMDAyODY5XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsyMHB4XVwiPmJhZGdlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgU3R1ZGVudCBQcm9maWxlXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3aW5nU3R1ZGVudChudWxsKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSByb3VuZGVkLWZ1bGwgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNlOGU3ZWZdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzIwcHhdXCI+Y2xvc2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTE0IGgtMTQgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LVsyMHB4XSAke1xyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdpbmdTdHVkZW50LmdlbmRlciA9PT0gJ21hbGUnID8gJ2JnLVsjMDAyODY5XSB0ZXh0LXdoaXRlJyA6ICdiZy1bI2ZiNzgwMF0gdGV4dC13aGl0ZSdcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHt2aWV3aW5nU3R1ZGVudC5hdmF0YXJMZXR0ZXJ9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LVsxOHB4XSBmb250LWJvbGQgdGV4dC1bIzAwMjg2OV1cIj57dmlld2luZ1N0dWRlbnQubmFtZX08L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMnB4XSB0ZXh0LVsjNzQ3NzgzXVwiPnt2aWV3aW5nU3R1ZGVudC5jb2RlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3aW5nU3R1ZGVudC5nZW5kZXIgPT09ICdtYWxlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLVsjZGFlMmZmXSB0ZXh0LVsjMDAxOTQ3XSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1bI2ZmZGJjOF0gdGV4dC1bIzU5MjYwMF0nXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dmlld2luZ1N0dWRlbnQuZ2VuZGVyID09PSAnbWFsZScgPyAnw7DFuOKAmMKmIE1hbGUgLyBCb3knIDogJ8OwxbjigJjCpyBGZW1hbGUgLyBHaXJsJ31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtYm9sZCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3aW5nU3R1ZGVudC5zdGF0dXMgPT09ICdhY3RpdmUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctWyNlNmY0ZWFdIHRleHQtWyMxMzczMzNdJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLVsjZmZkYWQ2XSB0ZXh0LVsjYmExYTFhXSdcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2aWV3aW5nU3R1ZGVudC5zdGF0dXMgPT09ICdhY3RpdmUnID8gJ0FjdGl2ZScgOiAnSW5hY3RpdmUnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIHB0LTIgdGV4dC1bMTNweF0gYm9yZGVyLXQgYm9yZGVyLVsjYzRjNmQzXS80MFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzc0Nzc4M10gdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5TdGFuZGFyZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtWyMwMDI4NjldXCI+e3ZpZXdpbmdTdHVkZW50LnN0YW5kYXJkfXRoIFN0YW5kYXJkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSBibG9ja1wiPkdlbmRlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZSBmb250LWJvbGRcIj57dmlld2luZ1N0dWRlbnQuZ2VuZGVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzc0Nzc4M10gdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5QYW5jaGF5YXQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPnt2aWV3aW5nU3R1ZGVudC5wYW5jaGF5YXROYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bIzc0Nzc4M10gdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgYmxvY2tcIj5WaWxsYWdlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57dmlld2luZ1N0dWRlbnQudmlsbGFnZU5hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjNzQ3NzgzXSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSBibG9ja1wiPlBhcmVudCAvIEd1YXJkaWFuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57dmlld2luZ1N0dWRlbnQucGFyZW50TmFtZSB8fCAnTi9BJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyM3NDc3ODNdIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIGJsb2NrXCI+Q29udGFjdCBQaG9uZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e3ZpZXdpbmdTdHVkZW50LnBob25lIHx8ICdOL0EnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlci10IGJvcmRlci1bI2M0YzZkM10gYmctWyNmYWY4ZmZdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCB0b0RlbGV0ZSA9IHZpZXdpbmdTdHVkZW50O1xyXG4gICAgICAgICAgICAgICAgICBzZXRWaWV3aW5nU3R1ZGVudChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U3R1ZGVudFRvRGVsZXRlKHRvRGVsZXRlKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1bI2ZmZGFkNl0gdGV4dC1bI2JhMWExYV0gcm91bmRlZC1tZCB0ZXh0LVsxMi41cHhdIGZvbnQtYm9sZCBob3ZlcjpiZy1bI2ZmZGFkNl0vODAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LVsxNnB4XVwiPmRlbGV0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIERlbGV0ZSBTdHVkZW50XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdpbmdTdHVkZW50KG51bGwpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLVsjYzRjNmQzXSB0ZXh0LVsjNDM0NjUyXSByb3VuZGVkLW1kIHRleHQtWzEyLjVweF0gZm9udC1ib2xkIGhvdmVyOmJnLVsjZjRmM2ZiXSBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB0b0VkaXQgPSB2aWV3aW5nU3R1ZGVudDtcclxuICAgICAgICAgICAgICAgICAgICBzZXRWaWV3aW5nU3R1ZGVudChudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVFZGl0U3R1ZGVudCh0b0VkaXQpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctWyMwMDI4NjldIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LVsxMi41cHhdIGZvbnQtYm9sZCBjdXJzb3ItcG9pbnRlciBob3ZlcjpiZy1bIzBiM2Q5MV0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+ZWRpdDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBTdHVkZW50XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgIElOLUFQUCBERUxFVEUgQ09ORklSTUFUSU9OIE1PREFMXHJcbiAgICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge3N0dWRlbnRUb0RlbGV0ZSAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWdyYXktOTAwLzc1IGJhY2tkcm9wLWJsdXItc20gei1bOTk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBhbmltYXRlLVtmYWRlSW5fMC4xNXNfZWFzZS1vdXRdXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgbWF4LXctc20gdy1mdWxsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcC02IHNwYWNlLXktNCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctWyNmZmRhZDZdIHRleHQtWyNiYTFhMWFdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzI2cHhdXCI+ZGVsZXRlX2ZvcmV2ZXI8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LVsxN3B4XSBmb250LWJvbGQgdGV4dC1bI2JhMWExYV1cIj5EZWxldGUgU3R1ZGVudD88L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEzcHhdIHRleHQtWyM0MzQ2NTJdIG10LTEuNSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgIEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LVsjMWExYjIxXVwiPntzdHVkZW50VG9EZWxldGUubmFtZX08L3N0cm9uZz4gKHtzdHVkZW50VG9EZWxldGUuc3RhbmRhcmR9dGggU3RkKSBmcm9tIHtzdHVkZW50VG9EZWxldGUudmlsbGFnZU5hbWV9P1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3R1ZGVudFRvRGVsZXRlKG51bGwpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1bI2M0YzZkM10gcm91bmRlZC1tZCB0ZXh0LVsxM3B4XSBmb250LWJvbGQgdGV4dC1bIzQzNDY1Ml0gaG92ZXI6YmctWyNmNGYzZmJdIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvbmZpcm1EZWxldGVTdHVkZW50fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIgYmctWyNiYTFhMWFdIHRleHQtd2hpdGUgcm91bmRlZC1tZCB0ZXh0LVsxM3B4XSBmb250LWJvbGQgaG92ZXI6YmctWyM5MzAwMGFdIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy14cyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgWWVzLCBEZWxldGVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XHJcbiAgICAgIHt0b2FzdE1lc3NhZ2UgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTYgcmlnaHQtNiB6LVsyMDBdIGJnLVsjMDAyODY5XSB0ZXh0LXdoaXRlIHB4LTQgcHktMyByb3VuZGVkLW1kIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxM3B4XSBmb250LWJvbGQgYW5pbWF0ZS1bc2xpZGVVcF8wLjJzX2Vhc2Utb3V0XSBib3JkZXIgYm9yZGVyLXdoaXRlLzIwXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE4cHhdIHRleHQtWyM4MGJkZmZdXCI+Y2hlY2tfY2lyY2xlPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4+e3RvYXN0TWVzc2FnZX08L3NwYW4+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRvYXN0TWVzc2FnZShudWxsKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXdoaXRlLzcwIGhvdmVyOnRleHQtd2hpdGUgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtWzE2cHhdXCI+Y2xvc2U8L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5cclxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL1N0dWRlbnRzVmlldy50c3gifQ==