import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\ui\\card.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport1_react);
const Card = React.forwardRef(
  _c = ({ className = "", size = "default", ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref,
      className: `rounded-2xl border border-gray-200 bg-white text-gray-800 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03] dark:text-white/90 transition-all duration-200 ${size === "sm" ? "p-4 space-y-3" : "p-5 md:p-6 space-y-4"} ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
      lineNumber: 7,
      columnNumber: 1
    },
    this
  )
);
_c2 = Card;
Card.displayName = "Card";
const CardHeader = React.forwardRef(
  _c3 = ({ className = "", ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref,
      className: `flex flex-col space-y-1.5 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
      lineNumber: 21,
      columnNumber: 1
    },
    this
  )
);
_c4 = CardHeader;
CardHeader.displayName = "CardHeader";
const CardTitle = React.forwardRef(
  _c5 = ({ className = "", ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "h3",
    {
      ref,
      className: `text-base font-semibold tracking-tight text-gray-800 dark:text-white/90 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
      lineNumber: 33,
      columnNumber: 1
    },
    this
  )
);
_c6 = CardTitle;
CardTitle.displayName = "CardTitle";
const CardDescription = React.forwardRef(
  _c7 = ({ className = "", ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "p",
    {
      ref,
      className: `text-sm text-gray-500 dark:text-gray-400 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
      lineNumber: 45,
      columnNumber: 1
    },
    this
  )
);
_c8 = CardDescription;
CardDescription.displayName = "CardDescription";
const CardContent = React.forwardRef(
  _c9 = ({ className = "", ...props }, ref) => /* @__PURE__ */ jsxDEV("div", { ref, className: `text-sm text-gray-800 dark:text-gray-200 ${className}`, ...props }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
    lineNumber: 57,
    columnNumber: 1
  }, this)
);
_c0 = CardContent;
CardContent.displayName = "CardContent";
const CardFooter = React.forwardRef(
  _c1 = ({ className = "", ...props }, ref) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      ref,
      className: `flex items-center pt-2 ${className}`,
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx",
      lineNumber: 65,
      columnNumber: 1
    },
    this
  )
);
_c10 = CardFooter;
CardFooter.displayName = "CardFooter";
export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10;
$RefreshReg$(_c, "Card$React.forwardRef");
$RefreshReg$(_c2, "Card");
$RefreshReg$(_c3, "CardHeader$React.forwardRef");
$RefreshReg$(_c4, "CardHeader");
$RefreshReg$(_c5, "CardTitle$React.forwardRef");
$RefreshReg$(_c6, "CardTitle");
$RefreshReg$(_c7, "CardDescription$React.forwardRef");
$RefreshReg$(_c8, "CardDescription");
$RefreshReg$(_c9, "CardContent$React.forwardRef");
$RefreshReg$(_c0, "CardContent");
$RefreshReg$(_c1, "CardFooter$React.forwardRef");
$RefreshReg$(_c10, "CardFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/ui/card.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUU7QUFORixZQUFZQSxXQUFXO0FBRXZCLE1BQU1DLE9BQU9ELE1BQU1FO0FBQUFBLEVBR2xCQyxLQUFDQSxDQUFDLEVBQUVDLFlBQVksSUFBSUMsT0FBTyxXQUFXLEdBQUdDLE1BQU0sR0FBR0MsUUFDakQ7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXLHNLQUNURixTQUFTLE9BQU8sa0JBQWtCLHNCQUFzQixJQUN0REQsU0FBUztBQUFBLE1BQ2IsR0FBSUU7QUFBQUE7QUFBQUEsSUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLWTtBQUViO0FBQUNFLE1BWElQO0FBWU5BLEtBQUtRLGNBQWM7QUFFbkIsTUFBTUMsYUFBYVYsTUFBTUU7QUFBQUEsRUFHeEJTLE1BQUNBLENBQUMsRUFBRVAsWUFBWSxJQUFJLEdBQUdFLE1BQU0sR0FBR0MsUUFDL0I7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXLDZCQUE2QkgsU0FBUztBQUFBLE1BQ2pELEdBQUlFO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDTSxNQVRJRjtBQVVOQSxXQUFXRCxjQUFjO0FBRXpCLE1BQU1JLFlBQVliLE1BQU1FO0FBQUFBLEVBR3ZCWSxNQUFDQSxDQUFDLEVBQUVWLFlBQVksSUFBSSxHQUFHRSxNQUFNLEdBQUdDLFFBQy9CO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsV0FBVywyRUFBMkVILFNBQVM7QUFBQSxNQUMvRixHQUFJRTtBQUFBQTtBQUFBQSxJQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUdZO0FBRWI7QUFBQ1MsTUFUSUY7QUFVTkEsVUFBVUosY0FBYztBQUV4QixNQUFNTyxrQkFBa0JoQixNQUFNRTtBQUFBQSxFQUc3QmUsTUFBQ0EsQ0FBQyxFQUFFYixZQUFZLElBQUksR0FBR0UsTUFBTSxHQUFHQyxRQUMvQjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVcsNENBQTRDSCxTQUFTO0FBQUEsTUFDaEUsR0FBSUU7QUFBQUE7QUFBQUEsSUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHWTtBQUViO0FBQUNZLE1BVElGO0FBVU5BLGdCQUFnQlAsY0FBYztBQUU5QixNQUFNVSxjQUFjbkIsTUFBTUU7QUFBQUEsRUFHekJrQixNQUFDQSxDQUFDLEVBQUVoQixZQUFZLElBQUksR0FBR0UsTUFBTSxHQUFHQyxRQUMvQix1QkFBQyxTQUFJLEtBQVUsV0FBVyw0Q0FBNENILFNBQVMsSUFBSSxHQUFJRSxTQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZGO0FBQzlGO0FBQUNlLE1BTElGO0FBTU5BLFlBQVlWLGNBQWM7QUFFMUIsTUFBTWEsYUFBYXRCLE1BQU1FO0FBQUFBLEVBR3hCcUIsTUFBQ0EsQ0FBQyxFQUFFbkIsWUFBWSxJQUFJLEdBQUdFLE1BQU0sR0FBR0MsUUFDL0I7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxXQUFXLDBCQUEwQkgsU0FBUztBQUFBLE1BQzlDLEdBQUlFO0FBQUFBO0FBQUFBLElBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBR1k7QUFFYjtBQUFDa0IsT0FUSUY7QUFVTkEsV0FBV2IsY0FBYztBQUV6QixTQUFTUixNQUFNUyxZQUFZWSxZQUFZVCxXQUFXRyxpQkFBaUJHO0FBQWEsSUFBQWhCLElBQUFLLEtBQUFHLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDLEtBQUFFLEtBQUFDO0FBQUEsYUFBQXJCLElBQUE7QUFBQSxhQUFBSyxLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUUsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUMsTUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQ2FyZCIsImZvcndhcmRSZWYiLCJfYyIsImNsYXNzTmFtZSIsInNpemUiLCJwcm9wcyIsInJlZiIsIl9jMiIsImRpc3BsYXlOYW1lIiwiQ2FyZEhlYWRlciIsIl9jMyIsIl9jNCIsIkNhcmRUaXRsZSIsIl9jNSIsIl9jNiIsIkNhcmREZXNjcmlwdGlvbiIsIl9jNyIsIl9jOCIsIkNhcmRDb250ZW50IiwiX2M5IiwiX2MwIiwiQ2FyZEZvb3RlciIsIl9jMSIsIl9jMTAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcblxuY29uc3QgQ2FyZCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxEaXZFbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD4gJiB7IHNpemU/OiBcImRlZmF1bHRcIiB8IFwic21cIiB9XG4+KCh7IGNsYXNzTmFtZSA9IFwiXCIsIHNpemUgPSBcImRlZmF1bHRcIiwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXZcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHRleHQtZ3JheS04MDAgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdIGRhcms6dGV4dC13aGl0ZS85MCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcbiAgICAgIHNpemUgPT09IFwic21cIiA/IFwicC00IHNwYWNlLXktM1wiIDogXCJwLTUgbWQ6cC02IHNwYWNlLXktNFwiXG4gICAgfSAke2NsYXNzTmFtZX1gfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5DYXJkLmRpc3BsYXlOYW1lID0gXCJDYXJkXCJcblxuY29uc3QgQ2FyZEhlYWRlciA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxEaXZFbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lID0gXCJcIiwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXZcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIHNwYWNlLXktMS41ICR7Y2xhc3NOYW1lfWB9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSlcbkNhcmRIZWFkZXIuZGlzcGxheU5hbWUgPSBcIkNhcmRIZWFkZXJcIlxuXG5jb25zdCBDYXJkVGl0bGUgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MUGFyYWdyYXBoRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTEhlYWRpbmdFbGVtZW50PlxuPigoeyBjbGFzc05hbWUgPSBcIlwiLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPGgzXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUvOTAgJHtjbGFzc05hbWV9YH1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuQ2FyZFRpdGxlLmRpc3BsYXlOYW1lID0gXCJDYXJkVGl0bGVcIlxuXG5jb25zdCBDYXJkRGVzY3JpcHRpb24gPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MUGFyYWdyYXBoRWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTFBhcmFncmFwaEVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSA9IFwiXCIsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8cFxuICAgIHJlZj17cmVmfVxuICAgIGNsYXNzTmFtZT17YHRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgJHtjbGFzc05hbWV9YH1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuQ2FyZERlc2NyaXB0aW9uLmRpc3BsYXlOYW1lID0gXCJDYXJkRGVzY3JpcHRpb25cIlxuXG5jb25zdCBDYXJkQ29udGVudCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIEhUTUxEaXZFbGVtZW50LFxuICBSZWFjdC5IVE1MQXR0cmlidXRlczxIVE1MRGl2RWxlbWVudD5cbj4oKHsgY2xhc3NOYW1lID0gXCJcIiwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxkaXYgcmVmPXtyZWZ9IGNsYXNzTmFtZT17YHRleHQtc20gdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0yMDAgJHtjbGFzc05hbWV9YH0gey4uLnByb3BzfSAvPlxuKSlcbkNhcmRDb250ZW50LmRpc3BsYXlOYW1lID0gXCJDYXJkQ29udGVudFwiXG5cbmNvbnN0IENhcmRGb290ZXIgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBIVE1MRGl2RWxlbWVudCxcbiAgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+XG4+KCh7IGNsYXNzTmFtZSA9IFwiXCIsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8ZGl2XG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgcHQtMiAke2NsYXNzTmFtZX1gfVxuICAgIHsuLi5wcm9wc31cbiAgLz5cbikpXG5DYXJkRm9vdGVyLmRpc3BsYXlOYW1lID0gXCJDYXJkRm9vdGVyXCJcblxuZXhwb3J0IHsgQ2FyZCwgQ2FyZEhlYWRlciwgQ2FyZEZvb3RlciwgQ2FyZFRpdGxlLCBDYXJkRGVzY3JpcHRpb24sIENhcmRDb250ZW50IH1cblxuIl0sImZpbGUiOiJEOi9Qcm9qZWN0LU1haW5maWxlcy9DbGllbnQtUHJvamVjdC9UUUktRVJQL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL3VpL2NhcmQudHN4In0=