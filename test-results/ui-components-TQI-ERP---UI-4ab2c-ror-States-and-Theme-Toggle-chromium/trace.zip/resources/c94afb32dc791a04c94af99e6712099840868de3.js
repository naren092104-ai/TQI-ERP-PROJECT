import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\Project-Mainfiles\\Client-Project\\TQI-ERP\\frontend\\src\\components\\BillScannerModal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useRef = __vite__cjsImport1_react["useRef"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import { checkImageClarity, scanBillAndExtractDetails } from "/src/utils/billParser.ts";
import {
  Camera,
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Check,
  X,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ScanLine
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { ActionButton } from "/src/components/ui/action-button.tsx";
export const BillScannerModal = ({
  isOpen,
  onClose,
  expectedAmount = 0,
  categoryLabel = "Expense",
  onAttachBill
}) => {
  _s();
  const [mode, setMode] = useState("camera");
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [fileName, setFileName] = useState("");
  const [detectedAmount, setDetectedAmount] = useState(expectedAmount || 0);
  const [isScanning, setIsScanning] = useState(false);
  const [scannerFilter, setScannerFilter] = useState("clear");
  const [clarityResult, setClarityResult] = useState(null);
  const [extractedData, setExtractedData] = useState(null);
  const [clarityWarning, setClarityWarning] = useState(null);
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const fileInputRef = useRef(null);
  const sampleBills = [
    {
      title: "Bus Ticket (KSR College → Salem)",
      category: "Travel",
      amount: 200,
      from: "KSR College",
      to: "Salem",
      url: "https://images.unsplash.com/photo-1554415707-9e49fe74a6d0?w=600&auto=format&fit=crop&q=80"
    },
    {
      title: "Bus Ticket (Dharmapuri → Pennagaram)",
      category: "Travel",
      amount: 60,
      from: "Dharmapuri",
      to: "Pennagaram",
      url: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80"
    },
    {
      title: "Restaurant Lunch Receipt",
      category: "Food",
      amount: 1e3,
      url: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=600&auto=format&fit=crop&q=80"
    },
    {
      title: "Stationery Store Cash Memo",
      category: "Stationery",
      amount: 450,
      url: "https://images.unsplash.com/photo-1586075010923-2dd4570fb338?w=600&auto=format&fit=crop&q=80"
    }
  ];
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
        setCameraActive(true);
      } else {
        setCameraError("Camera API is not supported in this browser environment. You can upload an image or choose a sample bill.");
      }
    } catch (err) {
      console.warn("Camera access error:", err);
      setCameraError("Could not access camera. Please upload a file or select a sample receipt.");
      setCameraActive(false);
    }
  };
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };
  useEffect(() => {
    if (isOpen) {
      setDetectedAmount(expectedAmount || 0);
      setCapturedImage(null);
      setClarityResult(null);
      setExtractedData(null);
      setClarityWarning(null);
      if (mode === "camera") {
        startCamera();
      }
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, mode]);
  const handleCapture = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
      stopCamera();
      processScannedImage(dataUrl, `captured_receipt_${Date.now()}.jpg`);
    }
  };
  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result;
      processScannedImage(dataUrl, file.name);
    };
    reader.readAsDataURL(file);
  };
  const handleSelectSample = (sample) => {
    processScannedImage(sample.url, `${sample.title.replace(/\s+/g, "_")}.jpg`, sample);
  };
  const processScannedImage = async (imageUrl, name, sampleMeta) => {
    setCapturedImage(imageUrl);
    setFileName(name);
    setIsScanning(true);
    setClarityWarning(null);
    try {
      const clarity = await checkImageClarity(imageUrl);
      setClarityResult(clarity);
      if (!clarity.isClear) {
        setClarityWarning(
          `Image sharpness score is ${clarity.score}/100. Text may be blurry. Please ensure lighting is bright.`
        );
      }
    } catch (err) {
      console.warn("Clarity check failed:", err);
    }
    try {
      const ocrResult = await scanBillAndExtractDetails(imageUrl);
      setIsScanning(false);
      setExtractedData(ocrResult);
      if (sampleMeta && sampleMeta.amount) {
        setDetectedAmount(sampleMeta.amount);
      } else if (ocrResult.amount && ocrResult.amount > 0) {
        setDetectedAmount(ocrResult.amount);
      } else if (expectedAmount && expectedAmount > 0) {
        setDetectedAmount(expectedAmount);
      }
    } catch (err) {
      console.warn("OCR Scan failed:", err);
      setIsScanning(false);
      if (sampleMeta?.amount) {
        setDetectedAmount(sampleMeta.amount);
      }
    }
  };
  const handleConfirm = () => {
    if (!capturedImage) return;
    const finalAttachment = {
      url: capturedImage,
      fileName: fileName || "scanned_receipt.jpg",
      detectedAmount,
      isVerified: clarityResult?.isClear ?? true,
      origin: extractedData?.origin,
      destination: extractedData?.destination,
      count: extractedData?.count,
      quality: clarityResult?.quality || "High"
    };
    onAttachBill(finalAttachment, extractedData || void 0);
    stopCamera();
    onClose();
  };
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-gray-950/85 backdrop-blur-sm animate-in fade-in-0 duration-200", children: /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl border border-gray-200 bg-white shadow-2xl dark:border-gray-800 dark:bg-gray-900 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3.5 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between bg-white dark:bg-gray-900", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex h-8 w-8 items-center justify-center rounded-xl bg-brand-50 text-brand-500 dark:bg-brand-950/40 dark:text-brand-400", children: /* @__PURE__ */ jsxDEV(ScanLine, { className: "h-4.5 w-4.5" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 258,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 257,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Clear Scanner & OCR Receipt Capture" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 261,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 dark:text-gray-400", children: [
            "Target: ",
            categoryLabel
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 264,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 260,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 256,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            stopCamera();
            onClose();
          },
          className: "flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200 transition-colors",
          children: /* @__PURE__ */ jsxDEV(X, { className: "h-4 w-4" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 277,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 269,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
      lineNumber: 255,
      columnNumber: 9
    }, this),
    !capturedImage && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-white/[0.02] text-xs font-semibold", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setMode("camera");
            startCamera();
          },
          className: `py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition-colors ${mode === "camera" ? "border-brand-500 text-brand-500 dark:text-brand-400" : "border-transparent text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(Camera, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 296,
              columnNumber: 15
            }, this),
            "Live Camera"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 284,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            stopCamera();
            setMode("upload");
          },
          className: `py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition-colors ${mode === "upload" ? "border-brand-500 text-brand-500 dark:text-brand-400" : "border-transparent text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(UploadCloud, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 311,
              columnNumber: 15
            }, this),
            "Upload Image"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 299,
          columnNumber: 13
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            stopCamera();
            setMode("samples");
          },
          className: `py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition-colors ${mode === "samples" ? "border-brand-500 text-brand-500 dark:text-brand-400" : "border-transparent text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV(FileText, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 326,
              columnNumber: 15
            }, this),
            "Sample Receipts"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 314,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
      lineNumber: 283,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex-1 overflow-y-auto space-y-4", children: [
      mode === "upload" && !capturedImage && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 text-center", children: [
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            ref: fileInputRef,
            type: "file",
            accept: "image/*,application/pdf",
            className: "hidden",
            onChange: handleFileUpload
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 337,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => fileInputRef.current?.click(),
            className: "border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-brand-500 rounded-2xl p-8 bg-gray-50/50 hover:bg-brand-50/10 transition-colors cursor-pointer flex flex-col items-center justify-center gap-3",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-2xl bg-brand-50 dark:bg-brand-950/40 text-brand-500 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UploadCloud, { className: "h-6 w-6" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 349,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 348,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-900 dark:text-white", children: "Click or Drop Ticket / Bill Photo" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 352,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 mt-0.5", children: "Clear photos only (JPG, PNG, WEBP)" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 353,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-brand-500 font-semibold mt-1", children: "✨ Automatic Route (From → To) & Amount Detection" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 354,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 351,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "mt-2 px-4 py-1.5 bg-brand-500 text-white text-xs font-semibold rounded-xl shadow-theme-xs hover:bg-brand-600 cursor-pointer",
                  children: "Browse Image"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 358,
                  columnNumber: 17
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 344,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 336,
        columnNumber: 11
      }, this),
      mode === "camera" && !capturedImage && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        cameraError ? /* @__PURE__ */ jsxDEV("div", { className: "p-5 bg-warning-50/50 border border-warning-200 rounded-2xl text-center space-y-3 dark:bg-warning-950/20 dark:border-warning-900/40", children: [
          /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-8 w-8 text-warning-500 mx-auto" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 373,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-warning-800 dark:text-warning-300 font-medium", children: cameraError }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 374,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2 pt-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setMode("upload"),
                className: "px-3.5 py-1.5 bg-brand-500 text-white rounded-xl text-xs font-semibold shadow-theme-xs hover:bg-brand-600 cursor-pointer",
                children: "Upload Bill Image"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 376,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setMode("samples"),
                className: "px-3.5 py-1.5 border border-gray-200 bg-white text-gray-700 rounded-xl text-xs font-semibold shadow-theme-xs hover:bg-gray-50 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 cursor-pointer",
                children: "Use Sample Bill"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 383,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 375,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 372,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "relative bg-black rounded-2xl overflow-hidden aspect-[4/3] flex items-center justify-center shadow-inner group", children: [
          /* @__PURE__ */ jsxDEV(
            "video",
            {
              ref: videoRef,
              autoPlay: true,
              playsInline: true,
              muted: true,
              className: "w-full h-full object-cover"
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 394,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-5 border border-brand-400/60 rounded-xl pointer-events-none flex flex-col justify-between p-2 shadow-[0_0_15px_rgba(22,137,254,0.3)]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 border-t-3 border-l-3 border-brand-400 rounded-tl-sm" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 406,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 border-t-3 border-r-3 border-brand-400 rounded-tr-sm" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 407,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 405,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full h-0.5 bg-gradient-to-r from-transparent via-brand-400 to-transparent shadow-[0_0_8px_#1689fe] animate-pulse" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 411,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-black/70 backdrop-blur-xs text-brand-300 rounded-full text-[10px] font-bold tracking-wider uppercase border border-brand-400/30", children: "Align Bill Inside Scanner Frame" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 414,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 413,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 border-b-3 border-l-3 border-brand-400 rounded-bl-sm" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 421,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "w-5 h-5 border-b-3 border-r-3 border-brand-400 rounded-br-sm" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 422,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 420,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 403,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 393,
          columnNumber: 13
        }, this),
        cameraActive && !cameraError && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center pt-1", children: /* @__PURE__ */ jsxDEV(
          ActionButton,
          {
            onClick: handleCapture,
            size: "default",
            variant: "primary",
            icon: /* @__PURE__ */ jsxDEV(Camera, { size: 16 }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 434,
              columnNumber: 23
            }, this),
            children: "Scan & Capture Bill"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 430,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 429,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 370,
        columnNumber: 11
      }, this),
      mode === "samples" && !capturedImage && /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 dark:text-gray-400 font-semibold", children: "Select a verified sample ticket / bill for instant scanning:" }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 446,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: sampleBills.map(
          (sample, idx) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => handleSelectSample(sample),
              className: "p-3 border border-gray-200 dark:border-gray-800 rounded-2xl hover:border-brand-500 hover:bg-brand-50/10 dark:hover:bg-brand-950/20 transition-all cursor-pointer flex items-center gap-3 group",
              children: [
                /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: sample.url,
                    alt: sample.title,
                    className: "w-12 h-12 rounded-xl object-cover border border-gray-200 dark:border-gray-800 shrink-0"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                    lineNumber: 456,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-gray-900 dark:text-white truncate group-hover:text-brand-500", children: sample.title }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                    lineNumber: 462,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-400", children: sample.category }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                    lineNumber: 465,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-mono font-bold text-success-600", children: [
                    "₹",
                    sample.amount
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                    lineNumber: 466,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 461,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-4 w-4 text-gray-400 group-hover:text-brand-500 shrink-0" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 468,
                  columnNumber: 21
                }, this)
              ]
            },
            idx,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 451,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 449,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 445,
        columnNumber: 11
      }, this),
      capturedImage && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl text-xs font-semibold", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setScannerFilter("clear"),
                className: `px-2.5 py-1 rounded-lg transition-colors ${scannerFilter === "clear" ? "bg-white dark:bg-gray-700 text-brand-500 shadow-theme-xs" : "text-gray-600 dark:text-gray-400"}`,
                children: "Clear Scan"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 481,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setScannerFilter("bw"),
                className: `px-2.5 py-1 rounded-lg transition-colors ${scannerFilter === "bw" ? "bg-white dark:bg-gray-700 text-brand-500 shadow-theme-xs" : "text-gray-600 dark:text-gray-400"}`,
                children: "B&W Doc"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 492,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setScannerFilter("original"),
                className: `px-2.5 py-1 rounded-lg transition-colors ${scannerFilter === "original" ? "bg-white dark:bg-gray-700 text-brand-500 shadow-theme-xs" : "text-gray-600 dark:text-gray-400"}`,
                children: "Original"
              },
              void 0,
              false,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 503,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 480,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setCapturedImage(null);
                setClarityResult(null);
                setExtractedData(null);
                if (mode === "camera") startCamera();
              },
              className: "inline-flex items-center gap-1 text-xs font-semibold text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white",
              children: [
                /* @__PURE__ */ jsxDEV(RefreshCw, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 526,
                  columnNumber: 19
                }, this),
                "Retake"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 516,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 479,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative bg-gray-900 rounded-2xl overflow-hidden max-h-[220px] flex items-center justify-center border border-gray-800", children: [
          /* @__PURE__ */ jsxDEV(
            "img",
            {
              src: capturedImage,
              alt: "Scanned Bill",
              className: `max-h-[220px] w-auto object-contain transition-all ${scannerFilter === "clear" ? "contrast-125 brightness-105" : scannerFilter === "bw" ? "grayscale contrast-150" : ""}`
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 533,
              columnNumber: 17
            },
            this
          ),
          isScanning && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center text-white gap-2", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-6 w-6 animate-spin text-brand-400" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 546,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold", children: "Scanning & Reading Document Details..." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 547,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 545,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 532,
          columnNumber: 15
        }, this),
        clarityResult && /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `p-3 rounded-xl border flex items-center justify-between text-xs ${clarityResult.isClear ? "bg-success-50 border-success-200 text-success-700 dark:bg-success-950/30 dark:border-success-900/40 dark:text-success-400" : "bg-error-50 border-error-200 text-error-700 dark:bg-error-950/30 dark:border-error-900/40 dark:text-error-400"}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                clarityResult.isClear ? /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-4 w-4 shrink-0 text-success-600" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 563,
                  columnNumber: 17
                }, this) : /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "h-4 w-4 shrink-0 text-error-600" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 565,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: clarityResult.isClear ? `Document Clarity: High Resolution (${clarityResult.quality})` : "Image Quality Warning (Blurry)" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 567,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 561,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-mono text-[11px] opacity-75", children: [
                clarityResult.width,
                "×",
                clarityResult.height,
                "px"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 573,
                columnNumber: 19
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 554,
            columnNumber: 13
          },
          this
        ),
        extractedData && (extractedData.origin || extractedData.destination) && /* @__PURE__ */ jsxDEV("div", { className: "p-3 bg-brand-50/50 border border-brand-200 rounded-xl space-y-1.5 text-xs dark:bg-brand-950/20 dark:border-brand-900/40", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-brand-600 dark:text-brand-400 flex items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 583,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: "Auto-Extracted Travel Route" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 584,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 582,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 font-bold text-gray-900 dark:text-white", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "bg-white dark:bg-gray-800 px-2 py-0.5 rounded-lg border border-gray-200 dark:border-gray-700", children: extractedData.origin || "Origin" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 587,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3.5 w-3.5 text-brand-500" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 590,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-white dark:bg-gray-800 px-2 py-0.5 rounded-lg border border-gray-200 dark:border-gray-700", children: extractedData.destination || "Destination" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 591,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 586,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 581,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-3.5 bg-gray-50/70 dark:bg-white/[0.02] border border-gray-200 dark:border-gray-800 rounded-2xl space-y-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(ShieldCheck, { className: "h-4 w-4 text-success-600" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 602,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Scanned Bill Amount (₹)" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 603,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 601,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400 truncate max-w-[180px]", children: fileName }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 605,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 600,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-400 mb-1", children: "Detected Amount" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 610,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  value: detectedAmount,
                  onChange: (e) => setDetectedAmount(parseFloat(e.target.value) || 0),
                  className: "w-full rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-sm font-mono font-bold text-gray-900 shadow-theme-xs focus:border-brand-500 focus:outline-none dark:border-gray-800 dark:bg-gray-800 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                  lineNumber: 613,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 609,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-[11px] font-semibold uppercase tracking-wider text-gray-400 mb-1", children: "Assigned To" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 622,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-gray-200 bg-white/70 px-3 py-1.5 text-xs font-semibold text-gray-700 dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 truncate", children: categoryLabel }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
                lineNumber: 625,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 621,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 608,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 599,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 477,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
      lineNumber: 333,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900 flex items-center justify-between", children: capturedImage ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setCapturedImage(null);
            setClarityResult(null);
            setExtractedData(null);
            if (mode === "camera") startCamera();
          },
          className: "px-3.5 py-2 text-gray-600 hover:bg-gray-100 rounded-xl text-xs font-semibold flex items-center gap-1 dark:text-gray-300 dark:hover:bg-gray-800",
          children: [
            /* @__PURE__ */ jsxDEV(RefreshCw, { className: "h-3.5 w-3.5" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
              lineNumber: 649,
              columnNumber: 17
            }, this),
            "Retake"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 639,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        ActionButton,
        {
          onClick: handleConfirm,
          size: "sm",
          variant: "primary",
          icon: /* @__PURE__ */ jsxDEV(Check, { size: 15 }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
            lineNumber: 656,
            columnNumber: 21
          }, this),
          children: "Attach Scanned Bill"
        },
        void 0,
        false,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
          lineNumber: 652,
          columnNumber: 15
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
      lineNumber: 638,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => {
          stopCamera();
          onClose();
        },
        className: "ml-auto px-4 py-2 border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 rounded-xl text-xs font-semibold dark:border-gray-800 dark:bg-gray-800 dark:text-gray-300 shadow-theme-xs",
        children: "Cancel"
      },
      void 0,
      false,
      {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
        lineNumber: 662,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
      lineNumber: 636,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
    lineNumber: 253,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx",
    lineNumber: 252,
    columnNumber: 5
  }, this);
};
_s(BillScannerModal, "+XTtPHqI1qXfvPT6RLX9gGhqTIk=");
_c = BillScannerModal;
var _c;
$RefreshReg$(_c, "BillScannerModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/BillScannerModal.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaVFjLFNBNFhGLFVBNVhFOztBQWpRZCxTQUFnQkEsVUFBVUMsUUFBUUMsaUJBQWlCO0FBQ25ELFNBQVNDLG1CQUFtQkMsaUNBQXdFO0FBQ3BHO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFJQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLG9CQUFvQjtBQXFCdEIsYUFBTUMsbUJBQW9EQSxDQUFDO0FBQUEsRUFDaEVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGlCQUFpQjtBQUFBLEVBQ2pCQyxnQkFBZ0I7QUFBQSxFQUNoQkM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSTFCLFNBQTBDLFFBQVE7QUFDMUUsUUFBTSxDQUFDMkIsY0FBY0MsZUFBZSxJQUFJNUIsU0FBa0IsS0FBSztBQUMvRCxRQUFNLENBQUM2QixhQUFhQyxjQUFjLElBQUk5QixTQUF3QixJQUFJO0FBQ2xFLFFBQU0sQ0FBQytCLGVBQWVDLGdCQUFnQixJQUFJaEMsU0FBd0IsSUFBSTtBQUN0RSxRQUFNLENBQUNpQyxVQUFVQyxXQUFXLElBQUlsQyxTQUFpQixFQUFFO0FBQ25ELFFBQU0sQ0FBQ21DLGdCQUFnQkMsaUJBQWlCLElBQUlwQyxTQUFpQnFCLGtCQUFrQixDQUFDO0FBQ2hGLFFBQU0sQ0FBQ2dCLFlBQVlDLGFBQWEsSUFBSXRDLFNBQWtCLEtBQUs7QUFDM0QsUUFBTSxDQUFDdUMsZUFBZUMsZ0JBQWdCLElBQUl4QyxTQUFzQyxPQUFPO0FBR3ZGLFFBQU0sQ0FBQ3lDLGVBQWVDLGdCQUFnQixJQUFJMUMsU0FBb0MsSUFBSTtBQUNsRixRQUFNLENBQUMyQyxlQUFlQyxnQkFBZ0IsSUFBSTVDLFNBQW1DLElBQUk7QUFDakYsUUFBTSxDQUFDNkMsZ0JBQWdCQyxpQkFBaUIsSUFBSTlDLFNBQXdCLElBQUk7QUFFeEUsUUFBTStDLFdBQVc5QyxPQUFnQyxJQUFJO0FBQ3JELFFBQU0rQyxZQUFZL0MsT0FBMkIsSUFBSTtBQUNqRCxRQUFNZ0QsZUFBZWhELE9BQWdDLElBQUk7QUFHekQsUUFBTWlELGNBQWM7QUFBQSxJQUNsQjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxVQUFVO0FBQUEsTUFDVkMsUUFBUTtBQUFBLE1BQ1JDLE1BQU07QUFBQSxNQUNOQyxJQUFJO0FBQUEsTUFDSkMsS0FBSztBQUFBLElBQ1A7QUFBQSxJQUNBO0FBQUEsTUFDRUwsT0FBTztBQUFBLE1BQ1BDLFVBQVU7QUFBQSxNQUNWQyxRQUFRO0FBQUEsTUFDUkMsTUFBTTtBQUFBLE1BQ05DLElBQUk7QUFBQSxNQUNKQyxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQSxNQUNFTCxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSRyxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQSxNQUNFTCxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSRyxLQUFLO0FBQUEsSUFDUDtBQUFBLEVBQUM7QUFJSCxRQUFNQyxjQUFjLFlBQVk7QUFDOUIzQixtQkFBZSxJQUFJO0FBQ25CLFFBQUk7QUFDRixVQUFJNEIsVUFBVUMsZ0JBQWdCRCxVQUFVQyxhQUFhQyxjQUFjO0FBQ2pFLGNBQU1DLFNBQVMsTUFBTUgsVUFBVUMsYUFBYUMsYUFBYTtBQUFBLFVBQ3ZERSxPQUFPLEVBQUVDLFlBQVksZUFBZUMsT0FBTyxFQUFFQyxPQUFPLEtBQUssR0FBR0MsUUFBUSxFQUFFRCxPQUFPLElBQUksRUFBRTtBQUFBLFFBQ3JGLENBQUM7QUFDRGpCLGtCQUFVbUIsVUFBVU47QUFDcEIsWUFBSWQsU0FBU29CLFNBQVM7QUFDcEJwQixtQkFBU29CLFFBQVFDLFlBQVlQO0FBQzdCZCxtQkFBU29CLFFBQVFFLEtBQUs7QUFBQSxRQUN4QjtBQUNBekMsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixPQUFPO0FBQ0xFLHVCQUFlLDJHQUEyRztBQUFBLE1BQzVIO0FBQUEsSUFDRixTQUFTd0MsS0FBVTtBQUNqQkMsY0FBUUMsS0FBSyx3QkFBd0JGLEdBQUc7QUFDeEN4QyxxQkFBZSwyRUFBMkU7QUFDMUZGLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBR0EsUUFBTTZDLGFBQWFBLE1BQU07QUFDdkIsUUFBSXpCLFVBQVVtQixTQUFTO0FBQ3JCbkIsZ0JBQVVtQixRQUFRTyxVQUFVLEVBQUVDLFFBQVEsQ0FBQ0MsVUFBVUEsTUFBTUMsS0FBSyxDQUFDO0FBQzdEN0IsZ0JBQVVtQixVQUFVO0FBQUEsSUFDdEI7QUFDQXZDLG9CQUFnQixLQUFLO0FBQUEsRUFDdkI7QUFHQTFCLFlBQVUsTUFBTTtBQUNkLFFBQUlpQixRQUFRO0FBQ1ZpQix3QkFBa0JmLGtCQUFrQixDQUFDO0FBQ3JDVyx1QkFBaUIsSUFBSTtBQUNyQlUsdUJBQWlCLElBQUk7QUFDckJFLHVCQUFpQixJQUFJO0FBQ3JCRSx3QkFBa0IsSUFBSTtBQUN0QixVQUFJckIsU0FBUyxVQUFVO0FBQ3JCZ0Msb0JBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRixPQUFPO0FBQ0xnQixpQkFBVztBQUFBLElBQ2I7QUFDQSxXQUFPLE1BQU07QUFDWEEsaUJBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRixHQUFHLENBQUN0RCxRQUFRTSxJQUFJLENBQUM7QUFHakIsUUFBTXFELGdCQUFnQkEsTUFBTTtBQUMxQixRQUFJLENBQUMvQixTQUFTb0IsUUFBUztBQUN2QixVQUFNWSxTQUFTQyxTQUFTQyxjQUFjLFFBQVE7QUFDOUNGLFdBQU9mLFFBQVFqQixTQUFTb0IsUUFBUWUsY0FBYztBQUM5Q0gsV0FBT2IsU0FBU25CLFNBQVNvQixRQUFRZ0IsZUFBZTtBQUNoRCxVQUFNQyxNQUFNTCxPQUFPTSxXQUFXLElBQUk7QUFDbEMsUUFBSUQsS0FBSztBQUNQQSxVQUFJRSxVQUFVdkMsU0FBU29CLFNBQVMsR0FBRyxHQUFHWSxPQUFPZixPQUFPZSxPQUFPYixNQUFNO0FBQ2pFLFlBQU1xQixVQUFVUixPQUFPUyxVQUFVLGNBQWMsR0FBRztBQUNsRGYsaUJBQVc7QUFDWGdCLDBCQUFvQkYsU0FBUyxvQkFBb0JHLEtBQUtDLElBQUksQ0FBQyxNQUFNO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBR0EsUUFBTUMsbUJBQW1CQSxDQUFDQyxNQUEyQztBQUNuRSxVQUFNQyxPQUFPRCxFQUFFRSxPQUFPQyxRQUFRLENBQUM7QUFDL0IsUUFBSSxDQUFDRixLQUFNO0FBRVgsVUFBTUcsU0FBUyxJQUFJQyxXQUFXO0FBQzlCRCxXQUFPRSxTQUFTLENBQUNDLFVBQVU7QUFDekIsWUFBTWIsVUFBVWEsTUFBTUwsUUFBUU07QUFDOUJaLDBCQUFvQkYsU0FBU08sS0FBS1EsSUFBSTtBQUFBLElBQ3hDO0FBQ0FMLFdBQU9NLGNBQWNULElBQUk7QUFBQSxFQUMzQjtBQUdBLFFBQU1VLHFCQUFxQkEsQ0FBQ0MsV0FBa0M7QUFDNURoQix3QkFBb0JnQixPQUFPakQsS0FBSyxHQUFHaUQsT0FBT3RELE1BQU11RCxRQUFRLFFBQVEsR0FBRyxDQUFDLFFBQVFELE1BQU07QUFBQSxFQUNwRjtBQUdBLFFBQU1oQixzQkFBc0IsT0FDMUJrQixVQUNBTCxNQUNBTSxlQUNHO0FBQ0g1RSxxQkFBaUIyRSxRQUFRO0FBQ3pCekUsZ0JBQVlvRSxJQUFJO0FBQ2hCaEUsa0JBQWMsSUFBSTtBQUNsQlEsc0JBQWtCLElBQUk7QUFHdEIsUUFBSTtBQUNGLFlBQU0rRCxVQUFVLE1BQU0xRyxrQkFBa0J3RyxRQUFRO0FBQ2hEakUsdUJBQWlCbUUsT0FBTztBQUN4QixVQUFJLENBQUNBLFFBQVFDLFNBQVM7QUFDcEJoRTtBQUFBQSxVQUNFLDRCQUE0QitELFFBQVFFLEtBQUs7QUFBQSxRQUMzQztBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVN6QyxLQUFLO0FBQ1pDLGNBQVFDLEtBQUsseUJBQXlCRixHQUFHO0FBQUEsSUFDM0M7QUFHQSxRQUFJO0FBQ0YsWUFBTTBDLFlBQVksTUFBTTVHLDBCQUEwQnVHLFFBQVE7QUFDMURyRSxvQkFBYyxLQUFLO0FBQ25CTSx1QkFBaUJvRSxTQUFTO0FBRTFCLFVBQUlKLGNBQWNBLFdBQVd2RCxRQUFRO0FBQ25DakIsMEJBQWtCd0UsV0FBV3ZELE1BQU07QUFBQSxNQUNyQyxXQUFXMkQsVUFBVTNELFVBQVUyRCxVQUFVM0QsU0FBUyxHQUFHO0FBQ25EakIsMEJBQWtCNEUsVUFBVTNELE1BQU07QUFBQSxNQUNwQyxXQUFXaEMsa0JBQWtCQSxpQkFBaUIsR0FBRztBQUMvQ2UsMEJBQWtCZixjQUFjO0FBQUEsTUFDbEM7QUFBQSxJQUNGLFNBQVNpRCxLQUFLO0FBQ1pDLGNBQVFDLEtBQUssb0JBQW9CRixHQUFHO0FBQ3BDaEMsb0JBQWMsS0FBSztBQUNuQixVQUFJc0UsWUFBWXZELFFBQVE7QUFDdEJqQiwwQkFBa0J3RSxXQUFXdkQsTUFBTTtBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNEQsZ0JBQWdCQSxNQUFNO0FBQzFCLFFBQUksQ0FBQ2xGLGNBQWU7QUFFcEIsVUFBTW1GLGtCQUFrQztBQUFBLE1BQ3RDMUQsS0FBS3pCO0FBQUFBLE1BQ0xFLFVBQVVBLFlBQVk7QUFBQSxNQUN0QkU7QUFBQUEsTUFDQWdGLFlBQVkxRSxlQUFlcUUsV0FBVztBQUFBLE1BQ3RDTSxRQUFRekUsZUFBZXlFO0FBQUFBLE1BQ3ZCQyxhQUFhMUUsZUFBZTBFO0FBQUFBLE1BQzVCQyxPQUFPM0UsZUFBZTJFO0FBQUFBLE1BQ3RCQyxTQUFTOUUsZUFBZThFLFdBQVc7QUFBQSxJQUNyQztBQUVBaEcsaUJBQWEyRixpQkFBaUJ2RSxpQkFBaUI2RSxNQUFTO0FBQ3hEL0MsZUFBVztBQUNYckQsWUFBUTtBQUFBLEVBQ1Y7QUFFQSxNQUFJLENBQUNELE9BQVEsUUFBTztBQUVwQixTQUNFLHVCQUFDLFNBQUksV0FBVSxtSUFDYixpQ0FBQyxTQUFJLFdBQVUscUtBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUhBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkhBQ2IsaUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxtREFBaUQsbURBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxnREFBOEM7QUFBQTtBQUFBLFlBQ2hERztBQUFBQSxlQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQ2JtRCx1QkFBVztBQUNYckQsb0JBQVE7QUFBQSxVQUNWO0FBQUEsVUFDQSxXQUFVO0FBQUEsVUFFVixpQ0FBQyxLQUFFLFdBQVUsYUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQjtBQUFBO0FBQUEsUUFSeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0E7QUFBQSxTQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0JBO0FBQUEsSUFHQyxDQUFDVyxpQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkhBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQ2JMLG9CQUFRLFFBQVE7QUFDaEIrQix3QkFBWTtBQUFBLFVBQ2Q7QUFBQSxVQUNBLFdBQVcsZ0ZBQ1RoQyxTQUFTLFdBQ0wsd0RBQ0EsK0ZBQStGO0FBQUEsVUFHckc7QUFBQSxtQ0FBQyxVQUFPLFdBQVUsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFaakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BY0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU07QUFDYmdELHVCQUFXO0FBQ1gvQyxvQkFBUSxRQUFRO0FBQUEsVUFDbEI7QUFBQSxVQUNBLFdBQVcsZ0ZBQ1RELFNBQVMsV0FDTCx3REFDQSwrRkFBK0Y7QUFBQSxVQUdyRztBQUFBLG1DQUFDLGVBQVksV0FBVSxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVp0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFjQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUNiZ0QsdUJBQVc7QUFDWC9DLG9CQUFRLFNBQVM7QUFBQSxVQUNuQjtBQUFBLFVBQ0EsV0FBVyxnRkFDVEQsU0FBUyxZQUNMLHdEQUNBLCtGQUErRjtBQUFBLFVBR3JHO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWNBO0FBQUEsU0E3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThDQTtBQUFBLElBSUYsdUJBQUMsU0FBSSxXQUFVLHdDQUVaQTtBQUFBQSxlQUFTLFlBQVksQ0FBQ00saUJBQ3JCLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxLQUFLa0I7QUFBQUEsWUFDTCxNQUFLO0FBQUEsWUFDTCxRQUFPO0FBQUEsWUFDUCxXQUFVO0FBQUEsWUFDVixVQUFVMkM7QUFBQUE7QUFBQUEsVUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLNkI7QUFBQSxRQUU3QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNM0MsYUFBYWtCLFNBQVNzRCxNQUFNO0FBQUEsWUFDM0MsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEdBQ2IsaUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsbURBQWtELGlEQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRztBQUFBLGdCQUNoRyx1QkFBQyxPQUFFLFdBQVUsbURBQWtELGtEQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRztBQUFBLGdCQUNqRyx1QkFBQyxPQUFFLFdBQVUsaURBQStDLGdFQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBNkg7QUFBQTtBQUFBLGdCQUZ6STtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBO0FBQUE7QUFBQSxVQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxXQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFJRGhHLFNBQVMsWUFBWSxDQUFDTSxpQkFDckIsdUJBQUMsU0FBSSxXQUFVLGFBQ1pGO0FBQUFBLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxzSUFDYjtBQUFBLGlDQUFDLGlCQUFjLFdBQVUsc0NBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsVUFDM0QsdUJBQUMsT0FBRSxXQUFVLDhEQUE4REEseUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkYsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNSCxRQUFRLFFBQVE7QUFBQSxnQkFDL0IsV0FBVTtBQUFBLGdCQUEwSDtBQUFBO0FBQUEsY0FIdEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTUEsUUFBUSxTQUFTO0FBQUEsZ0JBQ2hDLFdBQVU7QUFBQSxnQkFBdU07QUFBQTtBQUFBLGNBSG5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrSEFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxLQUFLcUI7QUFBQUEsY0FDTDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQSxXQUFVO0FBQUE7QUFBQSxZQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt3QztBQUFBLFVBSXhDLHVCQUFDLFNBQUksV0FBVSx1SkFFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxrRUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0U7QUFBQSxjQUMvRSx1QkFBQyxVQUFLLFdBQVUsa0VBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsaUJBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSx3SEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSTtBQUFBLFlBRW5JLHVCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFVBQUssV0FBVSxnSkFBOEksK0NBQTlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsa0VBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FDL0UsdUJBQUMsVUFBSyxXQUFVLGtFQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRTtBQUFBLGlCQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFHRHBCLGdCQUFnQixDQUFDRSxlQUNoQix1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNpRDtBQUFBQSxZQUNULE1BQUs7QUFBQSxZQUNMLFNBQVE7QUFBQSxZQUNSLE1BQU0sdUJBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUFJO0FBQUE7QUFBQSxVQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzRUE7QUFBQSxNQUlEckQsU0FBUyxhQUFhLENBQUNNLGlCQUN0Qix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSwwREFBd0QsNEVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNabUIsc0JBQVl3RTtBQUFBQSxVQUFJLENBQUNqQixRQUFRa0IsUUFDeEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTW5CLG1CQUFtQkMsTUFBTTtBQUFBLGNBQ3hDLFdBQVU7QUFBQSxjQUVWO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsS0FBS0EsT0FBT2pEO0FBQUFBLG9CQUNaLEtBQUtpRCxPQUFPdEQ7QUFBQUEsb0JBQ1osV0FBVTtBQUFBO0FBQUEsa0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdvRztBQUFBLGdCQUVwRyx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUZBQ1hzRCxpQkFBT3RELFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJzRCxpQkFBT3JELFlBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBEO0FBQUEsa0JBQzFELHVCQUFDLE9BQUUsV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUFFcUQsT0FBT3BEO0FBQUFBLHVCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RTtBQUFBLHFCQUw5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsZ0JBQ0EsdUJBQUMsY0FBVyxXQUFVLCtEQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRjtBQUFBO0FBQUE7QUFBQSxZQWhCNUVzRTtBQUFBQSxZQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxRQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxXQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkJBO0FBQUEsTUFJRDVGLGlCQUNDLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZGQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNUyxpQkFBaUIsT0FBTztBQUFBLGdCQUN2QyxXQUFXLDRDQUNURCxrQkFBa0IsVUFDZCw2REFDQSxrQ0FBa0M7QUFBQSxnQkFDckM7QUFBQTtBQUFBLGNBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTUMsaUJBQWlCLElBQUk7QUFBQSxnQkFDcEMsV0FBVyw0Q0FDVEQsa0JBQWtCLE9BQ2QsNkRBQ0Esa0NBQWtDO0FBQUEsZ0JBQ3JDO0FBQUE7QUFBQSxjQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1DLGlCQUFpQixVQUFVO0FBQUEsZ0JBQzFDLFdBQVcsNENBQ1RELGtCQUFrQixhQUNkLDZEQUNBLGtDQUFrQztBQUFBLGdCQUNyQztBQUFBO0FBQUEsY0FQTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JQLGlDQUFpQixJQUFJO0FBQ3JCVSxpQ0FBaUIsSUFBSTtBQUNyQkUsaUNBQWlCLElBQUk7QUFDckIsb0JBQUluQixTQUFTLFNBQVVnQyxhQUFZO0FBQUEsY0FDckM7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsYUFBVSxXQUFVLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsYUFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtEQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLEtBQUsxQjtBQUFBQSxjQUNMLEtBQUk7QUFBQSxjQUNKLFdBQVcsc0RBQ1RRLGtCQUFrQixVQUNkLGdDQUNBQSxrQkFBa0IsT0FDbEIsMkJBQ0EsRUFBRTtBQUFBO0FBQUEsWUFSVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTSztBQUFBLFVBRUpGLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLDRHQUNiO0FBQUEsbUNBQUMsWUFBUyxXQUFVLHlDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLE9BQUUsV0FBVSxxQkFBb0Isc0RBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsZUFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdDSSxpQkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVyxtRUFDVEEsY0FBY3FFLFVBQ1YsOEhBQ0EsK0dBQStHO0FBQUEsWUFHckg7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkJBQ1pyRTtBQUFBQSw4QkFBY3FFLFVBQ2IsdUJBQUMsZ0JBQWEsV0FBVSx1Q0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQsSUFFM0QsdUJBQUMsaUJBQWMsV0FBVSxxQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQ7QUFBQSxnQkFFNUQsdUJBQUMsVUFBSyxXQUFVLGlCQUNickUsd0JBQWNxRSxVQUNYLHNDQUFzQ3JFLGNBQWM4RSxPQUFPLE1BQzNELG9DQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsb0NBQ2I5RTtBQUFBQSw4QkFBY3VCO0FBQUFBLGdCQUFNO0FBQUEsZ0JBQUV2QixjQUFjeUI7QUFBQUEsZ0JBQU87QUFBQSxtQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBO0FBQUE7QUFBQSxVQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQkE7QUFBQSxRQUlEdkIsa0JBQWtCQSxjQUFjeUUsVUFBVXpFLGNBQWMwRSxnQkFDdkQsdUJBQUMsU0FBSSxXQUFVLDJIQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUEsbUNBQUMsWUFBUyxXQUFVLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDLHVCQUFDLFVBQUssMkNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxlQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZ0dBQ2IxRSx3QkFBY3lFLFVBQVUsWUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsY0FBVyxXQUFVLGdDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRDtBQUFBLFlBQ2xELHVCQUFDLFVBQUssV0FBVSxnR0FDYnpFLHdCQUFjMEUsZUFBZSxpQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsOEdBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNkVBQ2Q7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsOEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQsdUJBQUMsVUFBSyx1Q0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsOERBQThEcEYsc0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsZUFMekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSwrRUFBNkUsK0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPRTtBQUFBQSxrQkFDUCxVQUFVLENBQUMwRCxNQUFNekQsa0JBQWtCd0YsV0FBVy9CLEVBQUVFLE9BQU84QixLQUFLLEtBQUssQ0FBQztBQUFBLGtCQUNsRSxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJcU87QUFBQSxpQkFSdk87QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSwrRUFBNkUsMkJBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxtS0FDWnZHLDJCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsV0F6SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBKQTtBQUFBLFNBMVNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0U0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw0SEFDWlMsMEJBQ0MsbUNBQ0U7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQ2JDLDZCQUFpQixJQUFJO0FBQ3JCVSw2QkFBaUIsSUFBSTtBQUNyQkUsNkJBQWlCLElBQUk7QUFDckIsZ0JBQUluQixTQUFTLFNBQVVnQyxhQUFZO0FBQUEsVUFDckM7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsYUFBVSxXQUFVLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU3dEO0FBQUFBLFVBQ1QsTUFBSztBQUFBLFVBQ0wsU0FBUTtBQUFBLFVBQ1IsTUFBTSx1QkFBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQUk7QUFBQTtBQUFBLFFBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTLE1BQU07QUFDYnhDLHFCQUFXO0FBQ1hyRCxrQkFBUTtBQUFBLFFBQ1Y7QUFBQSxRQUNBLFdBQVU7QUFBQSxRQUE0TDtBQUFBO0FBQUEsTUFOeE07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU0EsS0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDQTtBQUFBLE9BcGFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxYUEsS0F0YUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVhQTtBQUVKO0FBQUVJLEdBNW5CV04sa0JBQWlEO0FBQUEsS0FBakRBO0FBQWlELElBQUE0RztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZVJlZiIsInVzZUVmZmVjdCIsImNoZWNrSW1hZ2VDbGFyaXR5Iiwic2NhbkJpbGxBbmRFeHRyYWN0RGV0YWlscyIsIkNhbWVyYSIsIlVwbG9hZENsb3VkIiwiRmlsZVRleHQiLCJDaGVja0NpcmNsZTIiLCJBbGVydFRyaWFuZ2xlIiwiUmVmcmVzaEN3IiwiQ2hlY2siLCJYIiwiU3BhcmtsZXMiLCJBcnJvd1JpZ2h0IiwiU2hpZWxkQ2hlY2siLCJTY2FuTGluZSIsIkFjdGlvbkJ1dHRvbiIsIkJpbGxTY2FubmVyTW9kYWwiLCJpc09wZW4iLCJvbkNsb3NlIiwiZXhwZWN0ZWRBbW91bnQiLCJjYXRlZ29yeUxhYmVsIiwib25BdHRhY2hCaWxsIiwiX3MiLCJtb2RlIiwic2V0TW9kZSIsImNhbWVyYUFjdGl2ZSIsInNldENhbWVyYUFjdGl2ZSIsImNhbWVyYUVycm9yIiwic2V0Q2FtZXJhRXJyb3IiLCJjYXB0dXJlZEltYWdlIiwic2V0Q2FwdHVyZWRJbWFnZSIsImZpbGVOYW1lIiwic2V0RmlsZU5hbWUiLCJkZXRlY3RlZEFtb3VudCIsInNldERldGVjdGVkQW1vdW50IiwiaXNTY2FubmluZyIsInNldElzU2Nhbm5pbmciLCJzY2FubmVyRmlsdGVyIiwic2V0U2Nhbm5lckZpbHRlciIsImNsYXJpdHlSZXN1bHQiLCJzZXRDbGFyaXR5UmVzdWx0IiwiZXh0cmFjdGVkRGF0YSIsInNldEV4dHJhY3RlZERhdGEiLCJjbGFyaXR5V2FybmluZyIsInNldENsYXJpdHlXYXJuaW5nIiwidmlkZW9SZWYiLCJzdHJlYW1SZWYiLCJmaWxlSW5wdXRSZWYiLCJzYW1wbGVCaWxscyIsInRpdGxlIiwiY2F0ZWdvcnkiLCJhbW91bnQiLCJmcm9tIiwidG8iLCJ1cmwiLCJzdGFydENhbWVyYSIsIm5hdmlnYXRvciIsIm1lZGlhRGV2aWNlcyIsImdldFVzZXJNZWRpYSIsInN0cmVhbSIsInZpZGVvIiwiZmFjaW5nTW9kZSIsIndpZHRoIiwiaWRlYWwiLCJoZWlnaHQiLCJjdXJyZW50Iiwic3JjT2JqZWN0IiwicGxheSIsImVyciIsImNvbnNvbGUiLCJ3YXJuIiwic3RvcENhbWVyYSIsImdldFRyYWNrcyIsImZvckVhY2giLCJ0cmFjayIsInN0b3AiLCJoYW5kbGVDYXB0dXJlIiwiY2FudmFzIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwidmlkZW9XaWR0aCIsInZpZGVvSGVpZ2h0IiwiY3R4IiwiZ2V0Q29udGV4dCIsImRyYXdJbWFnZSIsImRhdGFVcmwiLCJ0b0RhdGFVUkwiLCJwcm9jZXNzU2Nhbm5lZEltYWdlIiwiRGF0ZSIsIm5vdyIsImhhbmRsZUZpbGVVcGxvYWQiLCJlIiwiZmlsZSIsInRhcmdldCIsImZpbGVzIiwicmVhZGVyIiwiRmlsZVJlYWRlciIsIm9ubG9hZCIsImV2ZW50IiwicmVzdWx0IiwibmFtZSIsInJlYWRBc0RhdGFVUkwiLCJoYW5kbGVTZWxlY3RTYW1wbGUiLCJzYW1wbGUiLCJyZXBsYWNlIiwiaW1hZ2VVcmwiLCJzYW1wbGVNZXRhIiwiY2xhcml0eSIsImlzQ2xlYXIiLCJzY29yZSIsIm9jclJlc3VsdCIsImhhbmRsZUNvbmZpcm0iLCJmaW5hbEF0dGFjaG1lbnQiLCJpc1ZlcmlmaWVkIiwib3JpZ2luIiwiZGVzdGluYXRpb24iLCJjb3VudCIsInF1YWxpdHkiLCJ1bmRlZmluZWQiLCJjbGljayIsIm1hcCIsImlkeCIsInBhcnNlRmxvYXQiLCJ2YWx1ZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJpbGxTY2FubmVyTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjaGVja0ltYWdlQ2xhcml0eSwgc2NhbkJpbGxBbmRFeHRyYWN0RGV0YWlscywgQ2xhcml0eUNoZWNrUmVzdWx0LCBFeHRyYWN0ZWRCaWxsRGF0YSB9IGZyb20gJy4uL3V0aWxzL2JpbGxQYXJzZXInO1xuaW1wb3J0IHtcbiAgQ2FtZXJhLFxuICBVcGxvYWRDbG91ZCxcbiAgRmlsZVRleHQsXG4gIENoZWNrQ2lyY2xlMixcbiAgQWxlcnRUcmlhbmdsZSxcbiAgUmVmcmVzaEN3LFxuICBDaGVjayxcbiAgWCxcbiAgU3BhcmtsZXMsXG4gIEFycm93UmlnaHQsXG4gIFNoaWVsZENoZWNrLFxuICBDcm9wLFxuICBMYXllcnMsXG4gIFNsaWRlcnMsXG4gIFNjYW5MaW5lXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBBY3Rpb25CdXR0b24gfSBmcm9tICcuL3VpL2FjdGlvbi1idXR0b24nO1xuXG5leHBvcnQgaW50ZXJmYWNlIEJpbGxBdHRhY2htZW50IHtcbiAgdXJsOiBzdHJpbmc7XG4gIGZpbGVOYW1lOiBzdHJpbmc7XG4gIGRldGVjdGVkQW1vdW50PzogbnVtYmVyO1xuICBpc1ZlcmlmaWVkPzogYm9vbGVhbjtcbiAgb3JpZ2luPzogc3RyaW5nO1xuICBkZXN0aW5hdGlvbj86IHN0cmluZztcbiAgY291bnQ/OiBudW1iZXI7XG4gIHF1YWxpdHk/OiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBCaWxsU2Nhbm5lck1vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIGV4cGVjdGVkQW1vdW50PzogbnVtYmVyO1xuICBjYXRlZ29yeUxhYmVsPzogc3RyaW5nO1xuICBvbkF0dGFjaEJpbGw6IChiaWxsOiBCaWxsQXR0YWNobWVudCwgZXh0cmFjdGVkRGF0YT86IEV4dHJhY3RlZEJpbGxEYXRhKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQmlsbFNjYW5uZXJNb2RhbDogUmVhY3QuRkM8QmlsbFNjYW5uZXJNb2RhbFByb3BzPiA9ICh7XG4gIGlzT3BlbixcbiAgb25DbG9zZSxcbiAgZXhwZWN0ZWRBbW91bnQgPSAwLFxuICBjYXRlZ29yeUxhYmVsID0gJ0V4cGVuc2UnLFxuICBvbkF0dGFjaEJpbGwsXG59KSA9PiB7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPCdjYW1lcmEnIHwgJ3VwbG9hZCcgfCAnc2FtcGxlcyc+KCdjYW1lcmEnKTtcbiAgY29uc3QgW2NhbWVyYUFjdGl2ZSwgc2V0Q2FtZXJhQWN0aXZlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2NhbWVyYUVycm9yLCBzZXRDYW1lcmFFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2NhcHR1cmVkSW1hZ2UsIHNldENhcHR1cmVkSW1hZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtmaWxlTmFtZSwgc2V0RmlsZU5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtkZXRlY3RlZEFtb3VudCwgc2V0RGV0ZWN0ZWRBbW91bnRdID0gdXNlU3RhdGU8bnVtYmVyPihleHBlY3RlZEFtb3VudCB8fCAwKTtcbiAgY29uc3QgW2lzU2Nhbm5pbmcsIHNldElzU2Nhbm5pbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbc2Nhbm5lckZpbHRlciwgc2V0U2Nhbm5lckZpbHRlcl0gPSB1c2VTdGF0ZTwnY2xlYXInIHwgJ2J3JyB8ICdvcmlnaW5hbCc+KCdjbGVhcicpO1xuICBcbiAgLy8gQ2xhcml0eSAmIE9DUiBTdGF0ZVxuICBjb25zdCBbY2xhcml0eVJlc3VsdCwgc2V0Q2xhcml0eVJlc3VsdF0gPSB1c2VTdGF0ZTxDbGFyaXR5Q2hlY2tSZXN1bHQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2V4dHJhY3RlZERhdGEsIHNldEV4dHJhY3RlZERhdGFdID0gdXNlU3RhdGU8RXh0cmFjdGVkQmlsbERhdGEgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2NsYXJpdHlXYXJuaW5nLCBzZXRDbGFyaXR5V2FybmluZ10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCB2aWRlb1JlZiA9IHVzZVJlZjxIVE1MVmlkZW9FbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHN0cmVhbVJlZiA9IHVzZVJlZjxNZWRpYVN0cmVhbSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFNhbXBsZSByZWFsaXN0aWMgYmlsbHMgZm9yIHRlc3RpbmdcbiAgY29uc3Qgc2FtcGxlQmlsbHMgPSBbXG4gICAge1xuICAgICAgdGl0bGU6ICdCdXMgVGlja2V0IChLU1IgQ29sbGVnZSDihpIgU2FsZW0pJyxcbiAgICAgIGNhdGVnb3J5OiAnVHJhdmVsJyxcbiAgICAgIGFtb3VudDogMjAwLFxuICAgICAgZnJvbTogJ0tTUiBDb2xsZWdlJyxcbiAgICAgIHRvOiAnU2FsZW0nLFxuICAgICAgdXJsOiAnaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1NTQ0MTU3MDctOWU0OWZlNzRhNmQwP3c9NjAwJmF1dG89Zm9ybWF0JmZpdD1jcm9wJnE9ODAnLFxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6ICdCdXMgVGlja2V0IChEaGFybWFwdXJpIOKGkiBQZW5uYWdhcmFtKScsXG4gICAgICBjYXRlZ29yeTogJ1RyYXZlbCcsXG4gICAgICBhbW91bnQ6IDYwLFxuICAgICAgZnJvbTogJ0RoYXJtYXB1cmknLFxuICAgICAgdG86ICdQZW5uYWdhcmFtJyxcbiAgICAgIHVybDogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTQ0NjIwMzQ3LWM0ZmQ0YTNkNTk1Nz93PTYwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIHRpdGxlOiAnUmVzdGF1cmFudCBMdW5jaCBSZWNlaXB0JyxcbiAgICAgIGNhdGVnb3J5OiAnRm9vZCcsXG4gICAgICBhbW91bnQ6IDEwMDAsXG4gICAgICB1cmw6ICdodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU4MzMzNzEzMDQxNy0zMzQ2YTFiZTdkZWU/dz02MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT04MCcsXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogJ1N0YXRpb25lcnkgU3RvcmUgQ2FzaCBNZW1vJyxcbiAgICAgIGNhdGVnb3J5OiAnU3RhdGlvbmVyeScsXG4gICAgICBhbW91bnQ6IDQ1MCxcbiAgICAgIHVybDogJ2h0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTg2MDc1MDEwOTIzLTJkZDQ1NzBmYjMzOD93PTYwMCZhdXRvPWZvcm1hdCZmaXQ9Y3JvcCZxPTgwJyxcbiAgICB9LFxuICBdO1xuXG4gIC8vIFN0YXJ0IENhbWVyYVxuICBjb25zdCBzdGFydENhbWVyYSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRDYW1lcmFFcnJvcihudWxsKTtcbiAgICB0cnkge1xuICAgICAgaWYgKG5hdmlnYXRvci5tZWRpYURldmljZXMgJiYgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEpIHtcbiAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEoe1xuICAgICAgICAgIHZpZGVvOiB7IGZhY2luZ01vZGU6ICdlbnZpcm9ubWVudCcsIHdpZHRoOiB7IGlkZWFsOiAxMjgwIH0sIGhlaWdodDogeyBpZGVhbDogNzIwIH0gfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gc3RyZWFtO1xuICAgICAgICBpZiAodmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgICAgIHZpZGVvUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gc3RyZWFtO1xuICAgICAgICAgIHZpZGVvUmVmLmN1cnJlbnQucGxheSgpO1xuICAgICAgICB9XG4gICAgICAgIHNldENhbWVyYUFjdGl2ZSh0cnVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldENhbWVyYUVycm9yKCdDYW1lcmEgQVBJIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBicm93c2VyIGVudmlyb25tZW50LiBZb3UgY2FuIHVwbG9hZCBhbiBpbWFnZSBvciBjaG9vc2UgYSBzYW1wbGUgYmlsbC4nKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgY29uc29sZS53YXJuKCdDYW1lcmEgYWNjZXNzIGVycm9yOicsIGVycik7XG4gICAgICBzZXRDYW1lcmFFcnJvcignQ291bGQgbm90IGFjY2VzcyBjYW1lcmEuIFBsZWFzZSB1cGxvYWQgYSBmaWxlIG9yIHNlbGVjdCBhIHNhbXBsZSByZWNlaXB0LicpO1xuICAgICAgc2V0Q2FtZXJhQWN0aXZlKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gU3RvcCBDYW1lcmFcbiAgY29uc3Qgc3RvcENhbWVyYSA9ICgpID0+IHtcbiAgICBpZiAoc3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2goKHRyYWNrKSA9PiB0cmFjay5zdG9wKCkpO1xuICAgICAgc3RyZWFtUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBzZXRDYW1lcmFBY3RpdmUoZmFsc2UpO1xuICB9O1xuXG4gIC8vIExpZmVjeWNsZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIHNldERldGVjdGVkQW1vdW50KGV4cGVjdGVkQW1vdW50IHx8IDApO1xuICAgICAgc2V0Q2FwdHVyZWRJbWFnZShudWxsKTtcbiAgICAgIHNldENsYXJpdHlSZXN1bHQobnVsbCk7XG4gICAgICBzZXRFeHRyYWN0ZWREYXRhKG51bGwpO1xuICAgICAgc2V0Q2xhcml0eVdhcm5pbmcobnVsbCk7XG4gICAgICBpZiAobW9kZSA9PT0gJ2NhbWVyYScpIHtcbiAgICAgICAgc3RhcnRDYW1lcmEoKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc3RvcENhbWVyYSgpO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RvcENhbWVyYSgpO1xuICAgIH07XG4gIH0sIFtpc09wZW4sIG1vZGVdKTtcblxuICAvLyBDYXB0dXJlIGZyb20gbGl2ZSB2aWRlbyBzdHJlYW1cbiAgY29uc3QgaGFuZGxlQ2FwdHVyZSA9ICgpID0+IHtcbiAgICBpZiAoIXZpZGVvUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBjb25zdCBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICBjYW52YXMud2lkdGggPSB2aWRlb1JlZi5jdXJyZW50LnZpZGVvV2lkdGggfHwgNjQwO1xuICAgIGNhbnZhcy5oZWlnaHQgPSB2aWRlb1JlZi5jdXJyZW50LnZpZGVvSGVpZ2h0IHx8IDQ4MDtcbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoY3R4KSB7XG4gICAgICBjdHguZHJhd0ltYWdlKHZpZGVvUmVmLmN1cnJlbnQsIDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOSk7XG4gICAgICBzdG9wQ2FtZXJhKCk7XG4gICAgICBwcm9jZXNzU2Nhbm5lZEltYWdlKGRhdGFVcmwsIGBjYXB0dXJlZF9yZWNlaXB0XyR7RGF0ZS5ub3coKX0uanBnYCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBsb2NhbCBmaWxlIHVwbG9hZFxuICBjb25zdCBoYW5kbGVGaWxlVXBsb2FkID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGRhdGFVcmwgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBwcm9jZXNzU2Nhbm5lZEltYWdlKGRhdGFVcmwsIGZpbGUubmFtZSk7XG4gICAgfTtcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgfTtcblxuICAvLyBTZWxlY3Qgc2FtcGxlIHJlY2VpcHRcbiAgY29uc3QgaGFuZGxlU2VsZWN0U2FtcGxlID0gKHNhbXBsZTogdHlwZW9mIHNhbXBsZUJpbGxzWzBdKSA9PiB7XG4gICAgcHJvY2Vzc1NjYW5uZWRJbWFnZShzYW1wbGUudXJsLCBgJHtzYW1wbGUudGl0bGUucmVwbGFjZSgvXFxzKy9nLCAnXycpfS5qcGdgLCBzYW1wbGUpO1xuICB9O1xuXG4gIC8vIFByb2Nlc3MgYW5kIHJ1biBjbGVhci1zY2FuIE9DUiBkZXRlY3Rpb25cbiAgY29uc3QgcHJvY2Vzc1NjYW5uZWRJbWFnZSA9IGFzeW5jIChcbiAgICBpbWFnZVVybDogc3RyaW5nLFxuICAgIG5hbWU6IHN0cmluZyxcbiAgICBzYW1wbGVNZXRhPzogeyBhbW91bnQ6IG51bWJlcjsgZnJvbT86IHN0cmluZzsgdG8/OiBzdHJpbmc7IGNhdGVnb3J5Pzogc3RyaW5nIH1cbiAgKSA9PiB7XG4gICAgc2V0Q2FwdHVyZWRJbWFnZShpbWFnZVVybCk7XG4gICAgc2V0RmlsZU5hbWUobmFtZSk7XG4gICAgc2V0SXNTY2FubmluZyh0cnVlKTtcbiAgICBzZXRDbGFyaXR5V2FybmluZyhudWxsKTtcblxuICAgIC8vIDEuIENoZWNrIENsYXJpdHkgUXVhbGl0eVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBjbGFyaXR5ID0gYXdhaXQgY2hlY2tJbWFnZUNsYXJpdHkoaW1hZ2VVcmwpO1xuICAgICAgc2V0Q2xhcml0eVJlc3VsdChjbGFyaXR5KTtcbiAgICAgIGlmICghY2xhcml0eS5pc0NsZWFyKSB7XG4gICAgICAgIHNldENsYXJpdHlXYXJuaW5nKFxuICAgICAgICAgIGBJbWFnZSBzaGFycG5lc3Mgc2NvcmUgaXMgJHtjbGFyaXR5LnNjb3JlfS8xMDAuIFRleHQgbWF5IGJlIGJsdXJyeS4gUGxlYXNlIGVuc3VyZSBsaWdodGluZyBpcyBicmlnaHQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS53YXJuKCdDbGFyaXR5IGNoZWNrIGZhaWxlZDonLCBlcnIpO1xuICAgIH1cblxuICAgIC8vIDIuIFBlcmZvcm0gT0NSIEV4dHJhY3Rpb24gJiBSb3V0ZSBQYXJzaW5nXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG9jclJlc3VsdCA9IGF3YWl0IHNjYW5CaWxsQW5kRXh0cmFjdERldGFpbHMoaW1hZ2VVcmwpO1xuICAgICAgc2V0SXNTY2FubmluZyhmYWxzZSk7XG4gICAgICBzZXRFeHRyYWN0ZWREYXRhKG9jclJlc3VsdCk7XG5cbiAgICAgIGlmIChzYW1wbGVNZXRhICYmIHNhbXBsZU1ldGEuYW1vdW50KSB7XG4gICAgICAgIHNldERldGVjdGVkQW1vdW50KHNhbXBsZU1ldGEuYW1vdW50KTtcbiAgICAgIH0gZWxzZSBpZiAob2NyUmVzdWx0LmFtb3VudCAmJiBvY3JSZXN1bHQuYW1vdW50ID4gMCkge1xuICAgICAgICBzZXREZXRlY3RlZEFtb3VudChvY3JSZXN1bHQuYW1vdW50KTtcbiAgICAgIH0gZWxzZSBpZiAoZXhwZWN0ZWRBbW91bnQgJiYgZXhwZWN0ZWRBbW91bnQgPiAwKSB7XG4gICAgICAgIHNldERldGVjdGVkQW1vdW50KGV4cGVjdGVkQW1vdW50KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUud2FybignT0NSIFNjYW4gZmFpbGVkOicsIGVycik7XG4gICAgICBzZXRJc1NjYW5uaW5nKGZhbHNlKTtcbiAgICAgIGlmIChzYW1wbGVNZXRhPy5hbW91bnQpIHtcbiAgICAgICAgc2V0RGV0ZWN0ZWRBbW91bnQoc2FtcGxlTWV0YS5hbW91bnQpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvLyBDb25maXJtIEF0dGFjaG1lbnRcbiAgY29uc3QgaGFuZGxlQ29uZmlybSA9ICgpID0+IHtcbiAgICBpZiAoIWNhcHR1cmVkSW1hZ2UpIHJldHVybjtcblxuICAgIGNvbnN0IGZpbmFsQXR0YWNobWVudDogQmlsbEF0dGFjaG1lbnQgPSB7XG4gICAgICB1cmw6IGNhcHR1cmVkSW1hZ2UsXG4gICAgICBmaWxlTmFtZTogZmlsZU5hbWUgfHwgJ3NjYW5uZWRfcmVjZWlwdC5qcGcnLFxuICAgICAgZGV0ZWN0ZWRBbW91bnQ6IGRldGVjdGVkQW1vdW50LFxuICAgICAgaXNWZXJpZmllZDogY2xhcml0eVJlc3VsdD8uaXNDbGVhciA/PyB0cnVlLFxuICAgICAgb3JpZ2luOiBleHRyYWN0ZWREYXRhPy5vcmlnaW4sXG4gICAgICBkZXN0aW5hdGlvbjogZXh0cmFjdGVkRGF0YT8uZGVzdGluYXRpb24sXG4gICAgICBjb3VudDogZXh0cmFjdGVkRGF0YT8uY291bnQsXG4gICAgICBxdWFsaXR5OiBjbGFyaXR5UmVzdWx0Py5xdWFsaXR5IHx8ICdIaWdoJyxcbiAgICB9O1xuXG4gICAgb25BdHRhY2hCaWxsKGZpbmFsQXR0YWNobWVudCwgZXh0cmFjdGVkRGF0YSB8fCB1bmRlZmluZWQpO1xuICAgIHN0b3BDYW1lcmEoKTtcbiAgICBvbkNsb3NlKCk7XG4gIH07XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzEwMDAwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWdyYXktOTUwLzg1IGJhY2tkcm9wLWJsdXItc20gYW5pbWF0ZS1pbiBmYWRlLWluLTAgZHVyYXRpb24tMjAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy0yeGwgbWF4LWgtWzkydmhdIGZsZXggZmxleC1jb2wgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBzaGFkb3ctMnhsIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS05MDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctYnJhbmQtNTAgdGV4dC1icmFuZC01MDAgZGFyazpiZy1icmFuZC05NTAvNDAgZGFyazp0ZXh0LWJyYW5kLTQwMFwiPlxuICAgICAgICAgICAgICA8U2NhbkxpbmUgY2xhc3NOYW1lPVwiaC00LjUgdy00LjVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICBDbGVhciBTY2FubmVyICZhbXA7IE9DUiBSZWNlaXB0IENhcHR1cmVcbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICBUYXJnZXQ6IHtjYXRlZ29yeUxhYmVsfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgc3RvcENhbWVyYSgpO1xuICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIHRleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS0xMDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTb3VyY2UgTW9kZSBUYWJzICovfVxuICAgICAgICB7IWNhcHR1cmVkSW1hZ2UgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgYmctZ3JheS01MC81MCBkYXJrOmJnLXdoaXRlL1swLjAyXSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRNb2RlKCdjYW1lcmEnKTtcbiAgICAgICAgICAgICAgICBzdGFydENhbWVyYSgpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgbW9kZSA9PT0gJ2NhbWVyYSdcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1icmFuZC01MDAgdGV4dC1icmFuZC01MDAgZGFyazp0ZXh0LWJyYW5kLTQwMCdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICBMaXZlIENhbWVyYVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc3RvcENhbWVyYSgpO1xuICAgICAgICAgICAgICAgIHNldE1vZGUoJ3VwbG9hZCcpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgbW9kZSA9PT0gJ3VwbG9hZCdcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1icmFuZC01MDAgdGV4dC1icmFuZC01MDAgZGFyazp0ZXh0LWJyYW5kLTQwMCdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS05MDAgZGFyazp0ZXh0LWdyYXktNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxVcGxvYWRDbG91ZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgIFVwbG9hZCBJbWFnZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc3RvcENhbWVyYSgpO1xuICAgICAgICAgICAgICAgIHNldE1vZGUoJ3NhbXBsZXMnKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMi41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgIG1vZGUgPT09ICdzYW1wbGVzJ1xuICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWJyYW5kLTUwMCB0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtYnJhbmQtNDAwJ1xuICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgU2FtcGxlIFJlY2VpcHRzXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQ29udGVudCBCb2R5ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiAxLiBVcGxvYWQgRmlsZSBNb2RlICovfVxuICAgICAgICAgIHttb2RlID09PSAndXBsb2FkJyAmJiAhY2FwdHVyZWRJbWFnZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKixhcHBsaWNhdGlvbi9wZGZcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVVcGxvYWR9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCBkYXJrOmJvcmRlci1ncmF5LTcwMCBob3Zlcjpib3JkZXItYnJhbmQtNTAwIHJvdW5kZWQtMnhsIHAtOCBiZy1ncmF5LTUwLzUwIGhvdmVyOmJnLWJyYW5kLTUwLzEwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtMnhsIGJnLWJyYW5kLTUwIGRhcms6YmctYnJhbmQtOTUwLzQwIHRleHQtYnJhbmQtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8VXBsb2FkQ2xvdWQgY2xhc3NOYW1lPVwiaC02IHctNlwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+Q2xpY2sgb3IgRHJvcCBUaWNrZXQgLyBCaWxsIFBob3RvPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBtdC0wLjVcIj5DbGVhciBwaG90b3Mgb25seSAoSlBHLCBQTkcsIFdFQlApPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1icmFuZC01MDAgZm9udC1zZW1pYm9sZCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIOKcqCBBdXRvbWF0aWMgUm91dGUgKEZyb20g4oaSIFRvKSAmYW1wOyBBbW91bnQgRGV0ZWN0aW9uXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHB4LTQgcHktMS41IGJnLWJyYW5kLTUwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1icmFuZC02MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEJyb3dzZSBJbWFnZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogMi4gTGl2ZSBDYW1lcmEgTW9kZSB3aXRoIENsZWFyIFNjYW5uZXIgVmlld3BvcnQgKi99XG4gICAgICAgICAge21vZGUgPT09ICdjYW1lcmEnICYmICFjYXB0dXJlZEltYWdlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIHtjYW1lcmFFcnJvciA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBiZy13YXJuaW5nLTUwLzUwIGJvcmRlciBib3JkZXItd2FybmluZy0yMDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS0zIGRhcms6Ymctd2FybmluZy05NTAvMjAgZGFyazpib3JkZXItd2FybmluZy05MDAvNDBcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtOCB3LTggdGV4dC13YXJuaW5nLTUwMCBteC1hdXRvXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC13YXJuaW5nLTgwMCBkYXJrOnRleHQtd2FybmluZy0zMDAgZm9udC1tZWRpdW1cIj57Y2FtZXJhRXJyb3J9PC9wPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGUoJ3VwbG9hZCcpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgYmctYnJhbmQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWJyYW5kLTYwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgQmlsbCBJbWFnZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGUoJ3NhbXBsZXMnKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgdGV4dC1ncmF5LTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBVc2UgU2FtcGxlIEJpbGxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWJsYWNrIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBhc3BlY3QtWzQvM10gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LWlubmVyIGdyb3VwXCI+XG4gICAgICAgICAgICAgICAgICA8dmlkZW9cbiAgICAgICAgICAgICAgICAgICAgcmVmPXt2aWRlb1JlZn1cbiAgICAgICAgICAgICAgICAgICAgYXV0b1BsYXlcbiAgICAgICAgICAgICAgICAgICAgcGxheXNJbmxpbmVcbiAgICAgICAgICAgICAgICAgICAgbXV0ZWRcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgey8qIENsZWFyIFNjYW5uZXIgRWRnZSBEZXRlY3Rpb24gUmV0aWNsZSBPdmVybGF5ICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC01IGJvcmRlciBib3JkZXItYnJhbmQtNDAwLzYwIHJvdW5kZWQteGwgcG9pbnRlci1ldmVudHMtbm9uZSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTIgc2hhZG93LVswXzBfMTVweF9yZ2JhKDIyLDEzNywyNTQsMC4zKV1cIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIFRvcCBlZGdlIGhhbmRsZXMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTUgaC01IGJvcmRlci10LTMgYm9yZGVyLWwtMyBib3JkZXItYnJhbmQtNDAwIHJvdW5kZWQtdGwtc21cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSBib3JkZXItdC0zIGJvcmRlci1yLTMgYm9yZGVyLWJyYW5kLTQwMCByb3VuZGVkLXRyLXNtXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogTGFzZXIgU2NhbiBTd2VlcGluZyBMaW5lIEFuaW1hdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0wLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXRyYW5zcGFyZW50IHZpYS1icmFuZC00MDAgdG8tdHJhbnNwYXJlbnQgc2hhZG93LVswXzBfOHB4XyMxNjg5ZmVdIGFuaW1hdGUtcHVsc2VcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctYmxhY2svNzAgYmFja2Ryb3AtYmx1ci14cyB0ZXh0LWJyYW5kLTMwMCByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSBib3JkZXIgYm9yZGVyLWJyYW5kLTQwMC8zMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQWxpZ24gQmlsbCBJbnNpZGUgU2Nhbm5lciBGcmFtZVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEJvdHRvbSBlZGdlIGhhbmRsZXMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTUgaC01IGJvcmRlci1iLTMgYm9yZGVyLWwtMyBib3JkZXItYnJhbmQtNDAwIHJvdW5kZWQtYmwtc21cIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSBib3JkZXItYi0zIGJvcmRlci1yLTMgYm9yZGVyLWJyYW5kLTQwMCByb3VuZGVkLWJyLXNtXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtjYW1lcmFBY3RpdmUgJiYgIWNhbWVyYUVycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgPEFjdGlvbkJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDYXB0dXJlfVxuICAgICAgICAgICAgICAgICAgICBzaXplPVwiZGVmYXVsdFwiXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj17PENhbWVyYSBzaXplPXsxNn0gLz59XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFNjYW4gJmFtcDsgQ2FwdHVyZSBCaWxsXG4gICAgICAgICAgICAgICAgICA8L0FjdGlvbkJ1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogMy4gU2FtcGxlIEJpbGxzIE1vZGUgKi99XG4gICAgICAgICAge21vZGUgPT09ICdzYW1wbGVzJyAmJiAhY2FwdHVyZWRJbWFnZSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICBTZWxlY3QgYSB2ZXJpZmllZCBzYW1wbGUgdGlja2V0IC8gYmlsbCBmb3IgaW5zdGFudCBzY2FubmluZzpcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICB7c2FtcGxlQmlsbHMubWFwKChzYW1wbGUsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0U2FtcGxlKHNhbXBsZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHJvdW5kZWQtMnhsIGhvdmVyOmJvcmRlci1icmFuZC01MDAgaG92ZXI6YmctYnJhbmQtNTAvMTAgZGFyazpob3ZlcjpiZy1icmFuZC05NTAvMjAgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtzYW1wbGUudXJsfVxuICAgICAgICAgICAgICAgICAgICAgIGFsdD17c2FtcGxlLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLXhsIG9iamVjdC1jb3ZlciBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC13aGl0ZSB0cnVuY2F0ZSBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NhbXBsZS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj57c2FtcGxlLmNhdGVnb3J5fTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zdWNjZXNzLTYwMFwiPuKCuXtzYW1wbGUuYW1vdW50fTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1ncmF5LTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIDQuIFByZXZpZXcgJiBPQ1IgQ2xlYXIgU2Nhbm5lciBSZXN1bHRzICovfVxuICAgICAgICAgIHtjYXB0dXJlZEltYWdlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIHsvKiBEb2N1bWVudCBGaWx0ZXIgQ29udHJvbHMgKENsZWFyIFNjYW5uZXIgLyBIaWdoIENvbnRyYXN0IC8gT3JpZ2luYWwpICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctZ3JheS0xMDAgZGFyazpiZy1ncmF5LTgwMCBwLTEgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNjYW5uZXJGaWx0ZXIoJ2NsZWFyJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICBzY2FubmVyRmlsdGVyID09PSAnY2xlYXInXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLWdyYXktNzAwIHRleHQtYnJhbmQtNTAwIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2xlYXIgU2NhblxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTY2FubmVyRmlsdGVyKCdidycpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgICAgc2Nhbm5lckZpbHRlciA9PT0gJ2J3J1xuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1ncmF5LTcwMCB0ZXh0LWJyYW5kLTUwMCBzaGFkb3ctdGhlbWUteHMnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEImYW1wO1cgRG9jXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNjYW5uZXJGaWx0ZXIoJ29yaWdpbmFsJyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgICBzY2FubmVyRmlsdGVyID09PSAnb3JpZ2luYWwnXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLWdyYXktNzAwIHRleHQtYnJhbmQtNTAwIHNoYWRvdy10aGVtZS14cydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgT3JpZ2luYWxcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldENhcHR1cmVkSW1hZ2UobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENsYXJpdHlSZXN1bHQobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIHNldEV4dHJhY3RlZERhdGEobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtb2RlID09PSAnY2FtZXJhJykgc3RhcnRDYW1lcmEoKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtZ3JheS00MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIFJldGFrZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2Nhbm5lZCBEb2N1bWVudCBDYW52YXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JheS05MDAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLVsyMjBweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgIHNyYz17Y2FwdHVyZWRJbWFnZX1cbiAgICAgICAgICAgICAgICAgIGFsdD1cIlNjYW5uZWQgQmlsbFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtYXgtaC1bMjIwcHhdIHctYXV0byBvYmplY3QtY29udGFpbiB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBzY2FubmVyRmlsdGVyID09PSAnY2xlYXInXG4gICAgICAgICAgICAgICAgICAgICAgPyAnY29udHJhc3QtMTI1IGJyaWdodG5lc3MtMTA1J1xuICAgICAgICAgICAgICAgICAgICAgIDogc2Nhbm5lckZpbHRlciA9PT0gJ2J3J1xuICAgICAgICAgICAgICAgICAgICAgID8gJ2dyYXlzY2FsZSBjb250cmFzdC0xNTAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7aXNTY2FubmluZyAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svNzUgYmFja2Ryb3AtYmx1ci14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTYgdy02IGFuaW1hdGUtc3BpbiB0ZXh0LWJyYW5kLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkXCI+U2Nhbm5pbmcgJmFtcDsgUmVhZGluZyBEb2N1bWVudCBEZXRhaWxzLi4uPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENsYXJpdHkgUXVhbGl0eSBCYWRnZSAqL31cbiAgICAgICAgICAgICAge2NsYXJpdHlSZXN1bHQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyAke1xuICAgICAgICAgICAgICAgICAgICBjbGFyaXR5UmVzdWx0LmlzQ2xlYXJcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1zdWNjZXNzLTUwIGJvcmRlci1zdWNjZXNzLTIwMCB0ZXh0LXN1Y2Nlc3MtNzAwIGRhcms6Ymctc3VjY2Vzcy05NTAvMzAgZGFyazpib3JkZXItc3VjY2Vzcy05MDAvNDAgZGFyazp0ZXh0LXN1Y2Nlc3MtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWVycm9yLTUwIGJvcmRlci1lcnJvci0yMDAgdGV4dC1lcnJvci03MDAgZGFyazpiZy1lcnJvci05NTAvMzAgZGFyazpib3JkZXItZXJyb3ItOTAwLzQwIGRhcms6dGV4dC1lcnJvci00MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjbGFyaXR5UmVzdWx0LmlzQ2xlYXIgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIHRleHQtc3VjY2Vzcy02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtNCB3LTQgc2hyaW5rLTAgdGV4dC1lcnJvci02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NsYXJpdHlSZXN1bHQuaXNDbGVhclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBgRG9jdW1lbnQgQ2xhcml0eTogSGlnaCBSZXNvbHV0aW9uICgke2NsYXJpdHlSZXN1bHQucXVhbGl0eX0pYFxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnSW1hZ2UgUXVhbGl0eSBXYXJuaW5nIChCbHVycnkpJ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF0gb3BhY2l0eS03NVwiPlxuICAgICAgICAgICAgICAgICAgICB7Y2xhcml0eVJlc3VsdC53aWR0aH3Dl3tjbGFyaXR5UmVzdWx0LmhlaWdodH1weFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBBdXRvLWV4dHJhY3RlZCBUcmF2ZWwgUm91dGUgKi99XG4gICAgICAgICAgICAgIHtleHRyYWN0ZWREYXRhICYmIChleHRyYWN0ZWREYXRhLm9yaWdpbiB8fCBleHRyYWN0ZWREYXRhLmRlc3RpbmF0aW9uKSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctYnJhbmQtNTAvNTAgYm9yZGVyIGJvcmRlci1icmFuZC0yMDAgcm91bmRlZC14bCBzcGFjZS15LTEuNSB0ZXh0LXhzIGRhcms6YmctYnJhbmQtOTUwLzIwIGRhcms6Ym9yZGVyLWJyYW5kLTkwMC80MFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1icmFuZC02MDAgZGFyazp0ZXh0LWJyYW5kLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkF1dG8tRXh0cmFjdGVkIFRyYXZlbCBSb3V0ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1ncmF5LTgwMCBweC0yIHB5LTAuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgZGFyazpib3JkZXItZ3JheS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZXh0cmFjdGVkRGF0YS5vcmlnaW4gfHwgJ09yaWdpbid9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1icmFuZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLWdyYXktODAwIHB4LTIgcHktMC41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtleHRyYWN0ZWREYXRhLmRlc3RpbmF0aW9uIHx8ICdEZXN0aW5hdGlvbid9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBWZXJpZmllZCBBbW91bnQgQm94ICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLWdyYXktNTAvNzAgZGFyazpiZy13aGl0ZS9bMC4wMl0gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXN1Y2Nlc3MtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2Nhbm5lZCBCaWxsIEFtb3VudCAo4oK5KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LWdyYXktNDAwIHRydW5jYXRlIG1heC13LVsxODBweF1cIj57ZmlsZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIERldGVjdGVkIEFtb3VudFxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGV0ZWN0ZWRBbW91bnR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXRlY3RlZEFtb3VudChwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSB8fCAwKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHB4LTMgcHktMS41IHRleHQtc20gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIHNoYWRvdy10aGVtZS14cyBmb2N1czpib3JkZXItYnJhbmQtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEFzc2lnbmVkIFRvXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlLzcwIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5TGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZvb3RlciBBY3Rpb25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDAgYmctZ3JheS01MC81MCBkYXJrOmJnLWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIHtjYXB0dXJlZEltYWdlID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldENhcHR1cmVkSW1hZ2UobnVsbCk7XG4gICAgICAgICAgICAgICAgICBzZXRDbGFyaXR5UmVzdWx0KG51bGwpO1xuICAgICAgICAgICAgICAgICAgc2V0RXh0cmFjdGVkRGF0YShudWxsKTtcbiAgICAgICAgICAgICAgICAgIGlmIChtb2RlID09PSAnY2FtZXJhJykgc3RhcnRDYW1lcmEoKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS0xMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6aG92ZXI6YmctZ3JheS04MDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgUmV0YWtlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8QWN0aW9uQnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29uZmlybX1cbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJwcmltYXJ5XCJcbiAgICAgICAgICAgICAgICBpY29uPXs8Q2hlY2sgc2l6ZT17MTV9IC8+fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQXR0YWNoIFNjYW5uZWQgQmlsbFxuICAgICAgICAgICAgICA8L0FjdGlvbkJ1dHRvbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc3RvcENhbWVyYSgpO1xuICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtYXV0byBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgc2hhZG93LXRoZW1lLXhzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CaWxsU2Nhbm5lck1vZGFsLnRzeCJ9