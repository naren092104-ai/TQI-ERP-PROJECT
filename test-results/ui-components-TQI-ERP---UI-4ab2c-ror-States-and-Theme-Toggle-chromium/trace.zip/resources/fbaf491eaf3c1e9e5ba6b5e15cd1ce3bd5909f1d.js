import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DashboardView.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8975830d"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=8975830d"; const useState = __vite__cjsImport1_react["useState"]; const useEffect = __vite__cjsImport1_react["useEffect"];
import {
  Users,
  GraduationCap,
  CalendarCheck,
  ReceiptIndianRupee,
  ShieldAlert,
  MapPin,
  Plus,
  CheckCircle2,
  ArrowRight,
  ChevronRight,
  Search,
  ExternalLink,
  Calendar,
  TrendingUp
} from "/node_modules/.vite/deps/lucide-react.js?v=8975830d";
import { apiUrl } from "/src/utils/api.ts";
import Badge from "/src/components/ui/badge.tsx";
import { Table, TableBody, TableCell, TableHeader, TableRow } from "/src/components/ui/table.tsx";
export const DashboardView = ({
  onNavigate,
  onOpenNewSession,
  onOpenNewFinance,
  onOpenNewAttendance,
  panchayats = [],
  studentsCount = 0,
  volunteersCount = 0,
  sessionsCount = 0,
  pendingCount = 0,
  attendanceDrafts = [],
  userRole = "Cluster Admin",
  clusters = [],
  approvals = [],
  clusterName = "Dharmapuri Cluster",
  financeEntries = [],
  sessions = [],
  students = [],
  volunteers = []
}) => {
  _s();
  const [panchayatSearch, setPanchayatSearch] = useState("");
  const [setupDays, setSetupDays] = useState([]);
  const isSuperAdmin = userRole === "Super Admin";
  const pendingApprovals = approvals.filter((a) => a.status === "Pending");
  const totalVillages = panchayats.reduce((sum, p) => sum + (p.villages?.length || p.villagesCount || 0), 0);
  const totalExpenses = financeEntries.reduce((sum, f) => sum + (Number(f.amount) || 0), 0);
  const uniqueColleges = Array.from(new Set(volunteers.map((v) => v.college).filter(Boolean)));
  const collegesText = uniqueColleges.length > 0 ? `${uniqueColleges.length} Partner College${uniqueColleges.length > 1 ? "s" : ""}` : "No colleges mapped";
  useEffect(() => {
    fetch(apiUrl("/api/academic-setup")).then((res) => res.ok ? res.json() : null).then((data) => {
      if (data?.success && Array.isArray(data.setup)) {
        setSetupDays(data.setup.map((s) => ({
          dayNumber: s.day_number,
          sessionName: s.session_name
        })));
      }
    }).catch(() => {
    });
  }, []);
  const defaultSuggestedNames = {
    1: { name: "Spoken English & Goal Setting", month: "Feb", topic: "Communication" },
    2: { name: "Basic Arithmetic & Logic Puzzles", month: "Feb", topic: "Quantitative Aptitude" },
    3: { name: "Hands-on Science Observation", month: "Mar", topic: "Applied Sciences" },
    4: { name: "Life Skills, Health & Hygiene", month: "Mar", topic: "Wellness & Sanitation" },
    5: { name: "Creative Arts & Expression", month: "Mar", topic: "Creative Arts" },
    6: { name: "Digital Literacy Basics", month: "Apr", topic: "Technology" },
    7: { name: "Environment & Community Action", month: "Apr", topic: "Civic Action" },
    8: { name: "Culmination Showcase & Feedback", month: "Apr", topic: "Presentation" }
  };
  const dynamicRoadmap = Array.from({ length: 8 }, (_, i) => {
    const dayNum = i + 1;
    const customConfig = setupDays.find((s) => s.dayNumber === dayNum);
    const meta = defaultSuggestedNames[dayNum];
    const sessionName = customConfig?.sessionName || meta.name;
    const hasCompletedAttendance = attendanceDrafts.some((a) => a.dayNumber === dayNum && a.status === "Approved");
    const hasPendingAttendance = attendanceDrafts.some((a) => a.dayNumber === dayNum && a.status !== "Approved");
    let status = "Scheduled";
    if (hasCompletedAttendance) status = "Completed";
    else if (hasPendingAttendance) status = "In Progress";
    return {
      day: dayNum,
      title: sessionName,
      month: meta.month,
      topic: meta.topic,
      status
    };
  });
  const completedDaysCount = dynamicRoadmap.filter((d) => d.status === "Completed").length;
  const progressPercent = Math.round(completedDaysCount / 8 * 100);
  const filteredPanchayats = panchayats.filter(
    (p) => p.name.toLowerCase().includes(panchayatSearch.toLowerCase()) || p.villages?.some((v) => v.name.toLowerCase().includes(panchayatSearch.toLowerCase()))
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-white", children: [
          "Good day, ",
          isSuperAdmin ? "Super Administrator" : clusterName
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 151,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Overview of rural education operations, field mentorship, and 8-session cycle milestones." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 154,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 150,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2.5 shrink-0", children: [
        pendingApprovals.length > 0 && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("approvals"),
            className: "inline-flex items-center gap-2 rounded-xl border border-warning-200 bg-warning-50/70 px-3.5 py-2.5 text-xs font-semibold text-warning-700 hover:bg-warning-100 dark:border-warning-900/40 dark:bg-warning-500/10 dark:text-warning-400 transition",
            children: [
              /* @__PURE__ */ jsxDEV(ShieldAlert, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 167,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Pending Approvals" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 168,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center justify-center rounded-full bg-warning-500 px-2 py-0.5 text-[10px] font-bold text-white", children: pendingApprovals.length }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 169,
                columnNumber: 17
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 162,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenNewAttendance,
            className: "inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-xs font-semibold text-white shadow-theme-xs hover:bg-brand-600 transition",
            children: [
              /* @__PURE__ */ jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 180,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Mark Attendance" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 181,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 175,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: onOpenNewFinance,
            className: "inline-flex items-center gap-2 rounded-xl border border-gray-300 bg-white px-3.5 py-2.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
            children: [
              /* @__PURE__ */ jsxDEV(ReceiptIndianRupee, { className: "h-4 w-4 text-brand-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 189,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Record Expense" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 190,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 184,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 160,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
      lineNumber: 149,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 md:gap-6", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => onNavigate("students"),
          className: "cursor-pointer rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition hover:border-brand-300 dark:border-gray-800 dark:bg-white/[0.03] md:p-6",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 bg-brand-50 rounded-xl dark:bg-brand-500/10", children: /* @__PURE__ */ jsxDEV(GraduationCap, { className: "h-6 w-6 text-brand-500 dark:text-brand-400" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 204,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 203,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-between mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 dark:text-gray-400", children: "Enrolled Students" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 208,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90", children: studentsCount.toLocaleString("en-IN") }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 209,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 207,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { color: "success", children: [
                /* @__PURE__ */ jsxDEV(TrendingUp, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 214,
                  columnNumber: 15
                }, this),
                "Active"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 213,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 206,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 199,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => onNavigate("volunteers"),
          className: "cursor-pointer rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition hover:border-blue-light-300 dark:border-gray-800 dark:bg-white/[0.03] md:p-6",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 bg-blue-light-50 rounded-xl dark:bg-blue-light-500/10", children: /* @__PURE__ */ jsxDEV(Users, { className: "h-6 w-6 text-blue-light-500" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 226,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 225,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-between mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 dark:text-gray-400", children: "Field Mentors" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 230,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90", children: volunteersCount.toLocaleString("en-IN") }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 231,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 229,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { color: "info", children: [
                uniqueColleges.length,
                " Colleges"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 235,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 228,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 221,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => onNavigate("attendance"),
          className: "cursor-pointer rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition hover:border-success-300 dark:border-gray-800 dark:bg-white/[0.03] md:p-6",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 bg-success-50 rounded-xl dark:bg-success-500/10", children: /* @__PURE__ */ jsxDEV(CalendarCheck, { className: "h-6 w-6 text-success-500" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 247,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 246,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-between mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 dark:text-gray-400", children: "Attendance Logs" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 251,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90", children: (attendanceDrafts.length || sessionsCount).toLocaleString("en-IN") }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 252,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 250,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { color: "success", children: [
                completedDaysCount,
                "/8 Days (",
                progressPercent,
                "%)"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 256,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 249,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 242,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          onClick: () => onNavigate("finance"),
          className: "cursor-pointer rounded-2xl border border-gray-200 bg-white p-5 shadow-theme-xs transition hover:border-warning-300 dark:border-gray-800 dark:bg-white/[0.03] md:p-6",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 bg-warning-50 rounded-xl dark:bg-warning-500/10", children: /* @__PURE__ */ jsxDEV(ReceiptIndianRupee, { className: "h-6 w-6 text-warning-500" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 268,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 267,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-end justify-between mt-5", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 dark:text-gray-400", children: "Cluster Expenses" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 272,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "mt-2 font-bold text-gray-800 text-title-sm dark:text-white/90", children: [
                  "₹",
                  totalExpenses.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 273,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 271,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { color: "warning", children: [
                financeEntries.length,
                " Bills"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 277,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 270,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 263,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
      lineNumber: 197,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-12 gap-4 md:gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 xl:col-span-8 rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-5 border-b border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 dark:text-white/90", children: "8-Day Academic Curriculum (Feb–Apr)" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 291,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Badge, { color: "primary", size: "sm", children: [
                progressPercent,
                "% Delivered"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 294,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 290,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500 dark:text-gray-400", children: "Structured milestone progression synchronised across village school centres." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 298,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 289,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onNavigate(isSuperAdmin ? "academic-setup" : "module-library"),
              className: "inline-flex items-center gap-1.5 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition self-start sm:self-auto",
              children: [
                /* @__PURE__ */ jsxDEV("span", { children: isSuperAdmin ? "Configure term" : "Module library" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 308,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(ArrowRight, { className: "h-3.5 w-3.5" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 309,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 303,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 288,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-5 space-y-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 font-medium", children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Delivery Status" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 316,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 dark:text-white", children: [
              completedDaysCount,
              " of 8 Sessions Completed"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 317,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 315,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "h-2 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "h-full rounded-full bg-brand-500 transition-all duration-500",
              style: { width: `${progressPercent}%` }
            },
            void 0,
            false,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 320,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 319,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 314,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5", children: dynamicRoadmap.map((item) => {
          const badgeVariant = item.status === "Completed" ? "success" : item.status === "In Progress" ? "primary" : "light";
          return /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => onNavigate("attendance"),
              className: "group cursor-pointer rounded-xl border border-gray-200 bg-gray-50/50 p-4 hover:border-brand-300 hover:bg-brand-50/30 transition-all dark:border-gray-800 dark:bg-white/[0.02] dark:hover:border-brand-800 dark:hover:bg-brand-500/5",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400", children: [
                    "Day 0",
                    item.day
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 338,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-brand-500 dark:text-brand-400", children: item.month }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 341,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 337,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-sm font-semibold text-gray-800 group-hover:text-brand-500 dark:text-white dark:group-hover:text-brand-400 transition-colors line-clamp-1", children: item.title }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 345,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-gray-500 dark:text-gray-400 truncate", children: item.topic }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 348,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-2.5 border-t border-gray-200/60 dark:border-gray-800 flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV(Badge, { color: badgeVariant, size: "sm", children: item.status }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 352,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-400 group-hover:text-brand-500 dark:text-gray-500 dark:group-hover:text-brand-400 transition-colors", children: "Logs →" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 355,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 351,
                  columnNumber: 19
                }, this)
              ]
            },
            item.day,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 332,
              columnNumber: 17
            },
            this
          );
        }) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 328,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 287,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 xl:col-span-4 rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03] flex flex-col justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 dark:text-white/90", children: "Pending Approvals" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 370,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-xs text-gray-500 dark:text-gray-400", children: [
                pendingApprovals.length,
                " entries requiring verification"
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 373,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 369,
              columnNumber: 15
            }, this),
            pendingApprovals.length > 0 && /* @__PURE__ */ jsxDEV(Badge, { color: "warning", size: "sm", children: pendingApprovals.length }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 378,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 368,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: pendingApprovals.length > 0 ? pendingApprovals.slice(0, 4).map(
            (appr) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => onNavigate("approvals"),
                className: "cursor-pointer rounded-xl p-3 bg-gray-50 hover:bg-brand-50/40 dark:bg-white/[0.02] dark:hover:bg-brand-500/5 transition space-y-1",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800 dark:text-white", children: appr.module }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 393,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-warning-600 dark:text-warning-400", children: "Review →" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 396,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 392,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400 truncate", children: [
                    appr.recordId,
                    " · ",
                    appr.submittedBy || "Volunteer"
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 400,
                    columnNumber: 21
                  }, this)
                ]
              },
              appr.id,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 387,
                columnNumber: 15
              },
              this
            )
          ) : /* @__PURE__ */ jsxDEV("div", { className: "py-10 text-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-success-50 dark:bg-success-500/10 text-success-500", children: /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "h-6 w-6" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 408,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 407,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm font-medium text-gray-600 dark:text-gray-400", children: "All field logs and expenses approved." }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 410,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 406,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 384,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 367,
          columnNumber: 11
        }, this),
        pendingApprovals.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-100 dark:border-gray-800", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => onNavigate("approvals"),
            className: "w-full inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 bg-white py-2 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
            children: "Open Approval Center"
          },
          void 0,
          false,
          {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 420,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 419,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 366,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 dark:text-white/90", children: "8-Day Curriculum Progress by Cluster" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 435,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-xs text-gray-500 dark:text-gray-400", children: "Milestone tracking across all 8 academic program days" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 438,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 434,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-xs", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-gray-600 dark:text-gray-300", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 444,
                columnNumber: 17
              }, this),
              " Completed"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 443,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-gray-600 dark:text-gray-300", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-amber-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 447,
                columnNumber: 17
              }, this),
              " In Progress"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 446,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-gray-600 dark:text-gray-300", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-blue-500" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 450,
                columnNumber: 17
              }, this),
              " Scheduled"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 449,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5 text-gray-600 dark:text-gray-300", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-gray-300 dark:bg-gray-600" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 453,
                columnNumber: 17
              }, this),
              " Pending"
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 452,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 442,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 433,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-3.5", children: clusters.length > 0 ? clusters.map((cluster) => {
          const clusterSessions = sessions.filter((s) => s.clusterId === cluster.id);
          const daysStatus = Array.from({ length: 8 }, (_, i) => {
            const day = i + 1;
            const daySession = clusterSessions.find((s) => s.dayNumber === day);
            if (daySession && (daySession.status === "Completed" || daySession.status === "Approved")) {
              return { state: "Completed", label: daySession.name || `Day ${day}` };
            } else if (daySession && (daySession.status === "In Progress" || daySession.status === "Submitted" || daySession.status === "Pending Review")) {
              return { state: "In Progress", label: daySession.name || `Day ${day}` };
            } else if (daySession && daySession.status === "Scheduled") {
              return { state: "Scheduled", label: daySession.name || `Day ${day}` };
            }
            return { state: "Pending", label: `Day ${day}` };
          });
          const compCount = daysStatus.filter((s) => s.state === "Completed").length;
          const inProgCount = daysStatus.filter((s) => s.state === "In Progress").length;
          const progressPct = Math.round(compCount / 8 * 100);
          return /* @__PURE__ */ jsxDEV("div", { className: "rounded-xl border border-gray-200/80 bg-gray-50/40 p-4 dark:border-gray-800 dark:bg-white/[0.02] hover:border-brand-300 dark:hover:border-brand-500/30 transition", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full lg:w-64 flex-shrink-0", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm text-gray-900 dark:text-white", children: cluster.name }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 484,
                  columnNumber: 25
                }, this),
                cluster.collegeName && /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400 dark:text-gray-500 truncate max-w-[120px]", children: [
                  "· ",
                  cluster.collegeName
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 486,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 483,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-1.5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1 bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "bg-brand-500 h-full rounded-full transition-all duration-500",
                    style: { width: `${progressPct}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 493,
                    columnNumber: 27
                  },
                  this
                ) }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 492,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-brand-600 dark:text-brand-400", children: [
                  progressPct,
                  "%"
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 498,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 491,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 482,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 grid grid-cols-4 sm:grid-cols-8 gap-2", children: daysStatus.map((d, idx) => {
              const isDone = d.state === "Completed";
              const isInProg = d.state === "In Progress";
              const isSched = d.state === "Scheduled";
              return /* @__PURE__ */ jsxDEV(
                "div",
                {
                  title: `Day ${idx + 1}: ${d.state} (${d.label})`,
                  className: `group relative flex flex-col items-center justify-center p-2 rounded-lg border text-center transition-all ${isDone ? "border-emerald-200 bg-emerald-50/80 text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-950/20 dark:text-emerald-400" : isInProg ? "border-amber-200 bg-amber-50/80 text-amber-700 dark:border-amber-900/40 dark:bg-amber-950/20 dark:text-amber-400 shadow-sm animate-pulse" : isSched ? "border-blue-200 bg-blue-50/80 text-blue-700 dark:border-blue-900/40 dark:bg-blue-950/20 dark:text-blue-400" : "border-gray-200/60 bg-white dark:border-gray-800 dark:bg-gray-800/40 text-gray-400"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold uppercase tracking-wider mb-0.5", children: [
                      "Day ",
                      idx + 1
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 524,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-4", children: [
                      isDone && /* @__PURE__ */ jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                        lineNumber: 528,
                        columnNumber: 42
                      }, this),
                      isInProg && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-amber-600 dark:text-amber-400", children: "Active" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                        lineNumber: 529,
                        columnNumber: 44
                      }, this),
                      isSched && /* @__PURE__ */ jsxDEV(Calendar, { className: "w-3 h-3 text-blue-600 dark:text-blue-400" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                        lineNumber: 530,
                        columnNumber: 43
                      }, this),
                      !isDone && !isInProg && !isSched && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-gray-300 dark:text-gray-600", children: "•" }, void 0, false, {
                        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                        lineNumber: 531,
                        columnNumber: 68
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 527,
                      columnNumber: 29
                    }, this)
                  ]
                },
                idx,
                true,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 511,
                  columnNumber: 27
                },
                this
              );
            }) }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 504,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 481,
            columnNumber: 19
          }, this) }, cluster.id, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 480,
            columnNumber: 17
          }, this);
        }) : /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 text-center py-6 border border-dashed border-gray-200 dark:border-gray-800 rounded-xl", children: "No clusters onboarded yet. Create a cluster under the Clusters tab to begin tracking 8-day progress." }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 541,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 458,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 432,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 xl:col-span-8 rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03] space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 dark:text-white/90", children: "Panchayats & Village Units" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 552,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-xs text-gray-500 dark:text-gray-400", children: [
              panchayats.length,
              " panchayats · ",
              totalVillages,
              " villages active under ",
              clusterName
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 555,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 551,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative w-44 sm:w-56", children: [
              /* @__PURE__ */ jsxDEV(Search, { className: "h-4 w-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 562,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Search panchayats...",
                  value: panchayatSearch,
                  onChange: (e) => setPanchayatSearch(e.target.value),
                  className: "w-full rounded-lg border border-gray-300 bg-transparent pl-9 pr-3 py-1.5 text-xs text-gray-800 placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-2 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white"
                },
                void 0,
                false,
                {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 563,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 561,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => onNavigate("panchayats"),
                className: "inline-flex items-center gap-1.5 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-xs font-semibold text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/5 transition",
                children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Directory" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 576,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(ExternalLink, { className: "h-3.5 w-3.5" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 577,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 571,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 560,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 550,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-xl border border-gray-200 dark:border-gray-800", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-full overflow-x-auto", children: /* @__PURE__ */ jsxDEV(Table, { children: [
          /* @__PURE__ */ jsxDEV(TableHeader, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
            /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Panchayat Hub" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 587,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, children: "Mapped Villages" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 588,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Active Students" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 589,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(TableCell, { isHeader: true, className: "text-right", children: "Action" }, void 0, false, {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 590,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 586,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 585,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TableBody, { children: filteredPanchayats.length > 0 ? filteredPanchayats.map(
            (p) => /* @__PURE__ */ jsxDEV(
              TableRow,
              {
                onClick: () => onNavigate("panchayats"),
                className: "cursor-pointer group",
                children: [
                  /* @__PURE__ */ jsxDEV(TableCell, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxDEV(MapPin, { className: "h-4 w-4 text-gray-400 group-hover:text-brand-500 transition-colors shrink-0" }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 603,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 group-hover:text-brand-500 dark:text-white/90 dark:group-hover:text-brand-400 transition-colors", children: p.name }, void 0, false, {
                      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                      lineNumber: 604,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 602,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 601,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(TableCell, { className: "text-gray-500 dark:text-gray-400 truncate max-w-xs", children: p.villages?.map((v) => v.name).join(", ") || `${p.villagesCount || 0} villages` }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 609,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right font-bold text-gray-800 dark:text-white tabular-nums", children: p.activeStudents || 0 }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 612,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(TableCell, { className: "text-right", children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4 text-gray-400 group-hover:text-gray-700 dark:group-hover:text-white transition-colors inline-block" }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 616,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 615,
                    columnNumber: 25
                  }, this)
                ]
              },
              p.id,
              true,
              {
                fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                lineNumber: 596,
                columnNumber: 19
              },
              this
            )
          ) : /* @__PURE__ */ jsxDEV(TableRow, { children: /* @__PURE__ */ jsxDEV(TableCell, { colSpan: 4, className: "py-8 text-center text-gray-500 dark:text-gray-400", children: [
            'No panchayats found matching "',
            panchayatSearch || clusterName,
            '".'
          ] }, void 0, true, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 622,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 621,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 593,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 584,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 583,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 582,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 549,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "col-span-12 xl:col-span-4 rounded-2xl border border-gray-200 bg-white p-5 md:p-6 shadow-theme-xs dark:border-gray-800 dark:bg-white/[0.03] space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "pb-4 border-b border-gray-100 dark:border-gray-800", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800 dark:text-white/90", children: "Operational Navigation" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 636,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-xs text-gray-500 dark:text-gray-400", children: "Direct access to field workflows" }, void 0, false, {
            fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
            lineNumber: 639,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 635,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          { label: "8-Day Attendance & Homework", tab: "attendance", desc: "Log daily marks & volunteer attendance" },
          { label: "Finance & OCR Bill Scanning", tab: "finance", desc: "Verify tickets, fuel & food bills" },
          { label: "Curriculum PPT Module Library", tab: "module-library", desc: "Teaching slides & worksheets" },
          { label: "Analytics & Semester Reports", tab: "reports", desc: "Download CSV & PDF completion reports" }
        ].map(
          (item) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onNavigate(item.tab),
              className: "group flex w-full items-start justify-between rounded-xl p-3 text-left transition-colors bg-gray-50/60 hover:bg-brand-50/40 dark:bg-white/[0.02] dark:hover:bg-brand-500/5",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-0.5", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-gray-800 group-hover:text-brand-500 dark:text-white/90 dark:group-hover:text-brand-400 transition-colors", children: item.label }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 658,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 dark:text-gray-400", children: item.desc }, void 0, false, {
                    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                    lineNumber: 661,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 657,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(ChevronRight, { className: "h-4 w-4 text-gray-400 group-hover:text-brand-500 dark:group-hover:text-brand-400 transition-colors mt-0.5 shrink-0" }, void 0, false, {
                  fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
                  lineNumber: 663,
                  columnNumber: 17
                }, this)
              ]
            },
            item.tab,
            true,
            {
              fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
              lineNumber: 651,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
          lineNumber: 644,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
        lineNumber: 634,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
      lineNumber: 285,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx",
    lineNumber: 146,
    columnNumber: 5
  }, this);
};
_s(DashboardView, "L4IFjnOITyk/lQF4WJGIbh6tqPA=");
_c = DashboardView;
var _c;
$RefreshReg$(_c, "DashboardView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/Project-Mainfiles/Client-Project/TQI-ERP/frontend/src/components/DashboardView.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0pZOztBQXRKWixTQUFnQkEsVUFBVUMsaUJBQWlCO0FBQzNDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFHQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFFQUM7QUFBQUEsT0FJSztBQUVQLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsV0FBVztBQUVsQixTQUFTQyxPQUFPQyxXQUFXQyxXQUFXQyxhQUFhQyxnQkFBZ0I7QUF1QjVELGFBQU1DLGdCQUE4Q0EsQ0FBQztBQUFBLEVBQzFEQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxhQUFhO0FBQUEsRUFDYkMsZ0JBQWdCO0FBQUEsRUFDaEJDLGtCQUFrQjtBQUFBLEVBQ2xCQyxnQkFBZ0I7QUFBQSxFQUNoQkMsZUFBZTtBQUFBLEVBQ2ZDLG1CQUFtQjtBQUFBLEVBQ25CQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUFBLEVBQ1hDLFlBQVk7QUFBQSxFQUNaQyxjQUFjO0FBQUEsRUFDZEMsaUJBQWlCO0FBQUEsRUFDakJDLFdBQVc7QUFBQSxFQUNYQyxXQUFXO0FBQUEsRUFDWEMsYUFBYTtBQUNmLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSTVDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM2QyxXQUFXQyxZQUFZLElBQUk5QyxTQUF1RCxFQUFFO0FBQzNGLFFBQU0rQyxlQUFlYixhQUFhO0FBQ2xDLFFBQU1jLG1CQUFtQlosVUFBVWEsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxXQUFXLFNBQVM7QUFHdkUsUUFBTUMsZ0JBQWdCeEIsV0FBV3lCLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsT0FBT0MsRUFBRUMsVUFBVUMsVUFBVUYsRUFBRUcsaUJBQWlCLElBQUksQ0FBQztBQUd6RyxRQUFNQyxnQkFBZ0JyQixlQUFlZSxPQUFPLENBQUNDLEtBQUtNLE1BQU1OLE9BQU9PLE9BQU9ELEVBQUVFLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFHeEYsUUFBTUMsaUJBQWlCQyxNQUFNQyxLQUFLLElBQUlDLElBQUl6QixXQUFXMEIsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxPQUFPLEVBQUVwQixPQUFPcUIsT0FBTyxDQUFDLENBQUM7QUFDM0YsUUFBTUMsZUFBZVIsZUFBZU4sU0FBUyxJQUN6QyxHQUFHTSxlQUFlTixNQUFNLG1CQUFtQk0sZUFBZU4sU0FBUyxJQUFJLE1BQU0sRUFBRSxLQUMvRTtBQUdKeEQsWUFBVSxNQUFNO0FBQ2R1RSxVQUFNeEQsT0FBTyxxQkFBcUIsQ0FBQyxFQUNoQ3lELEtBQUssQ0FBQ0MsUUFBU0EsSUFBSUMsS0FBS0QsSUFBSUUsS0FBSyxJQUFJLElBQUssRUFDMUNILEtBQUssQ0FBQ0ksU0FBUztBQUNkLFVBQUlBLE1BQU1DLFdBQVdkLE1BQU1lLFFBQVFGLEtBQUtHLEtBQUssR0FBRztBQUM5Q2xDLHFCQUFhK0IsS0FBS0csTUFBTWIsSUFBSSxDQUFDYyxPQUFxRDtBQUFBLFVBQ2hGQyxXQUFXRCxFQUFFRTtBQUFBQSxVQUNiQyxhQUFhSCxFQUFFSTtBQUFBQSxRQUNqQixFQUFFLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDRixDQUFDLEVBQ0FDLE1BQU0sTUFBTTtBQUFBLElBQUMsQ0FBQztBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMLFFBQU1DLHdCQUF3RjtBQUFBLElBQzVGLEdBQUcsRUFBRUMsTUFBTSxpQ0FBaUNDLE9BQU8sT0FBT0MsT0FBTyxnQkFBZ0I7QUFBQSxJQUNqRixHQUFHLEVBQUVGLE1BQU0sb0NBQW9DQyxPQUFPLE9BQU9DLE9BQU8sd0JBQXdCO0FBQUEsSUFDNUYsR0FBRyxFQUFFRixNQUFNLGdDQUFnQ0MsT0FBTyxPQUFPQyxPQUFPLG1CQUFtQjtBQUFBLElBQ25GLEdBQUcsRUFBRUYsTUFBTSxpQ0FBaUNDLE9BQU8sT0FBT0MsT0FBTyx3QkFBd0I7QUFBQSxJQUN6RixHQUFHLEVBQUVGLE1BQU0sOEJBQThCQyxPQUFPLE9BQU9DLE9BQU8sZ0JBQWdCO0FBQUEsSUFDOUUsR0FBRyxFQUFFRixNQUFNLDJCQUEyQkMsT0FBTyxPQUFPQyxPQUFPLGFBQWE7QUFBQSxJQUN4RSxHQUFHLEVBQUVGLE1BQU0sa0NBQWtDQyxPQUFPLE9BQU9DLE9BQU8sZUFBZTtBQUFBLElBQ2pGLEdBQUcsRUFBRUYsTUFBTSxtQ0FBbUNDLE9BQU8sT0FBT0MsT0FBTyxlQUFlO0FBQUEsRUFDcEY7QUFHQSxRQUFNQyxpQkFBaUIzQixNQUFNQyxLQUFLLEVBQUVSLFFBQVEsRUFBRSxHQUFHLENBQUNtQyxHQUFHQyxNQUFNO0FBQ3pELFVBQU1DLFNBQVNELElBQUk7QUFDbkIsVUFBTUUsZUFBZWxELFVBQVVtRCxLQUFLLENBQUNmLE1BQU1BLEVBQUVDLGNBQWNZLE1BQU07QUFDakUsVUFBTUcsT0FBT1Ysc0JBQXNCTyxNQUFNO0FBQ3pDLFVBQU1WLGNBQWNXLGNBQWNYLGVBQWVhLEtBQUtUO0FBRXRELFVBQU1VLHlCQUF5QmpFLGlCQUFpQmtFLEtBQUssQ0FBQ2pELE1BQU1BLEVBQUVnQyxjQUFjWSxVQUFVNUMsRUFBRUMsV0FBVyxVQUFVO0FBQzdHLFVBQU1pRCx1QkFBdUJuRSxpQkFBaUJrRSxLQUFLLENBQUNqRCxNQUFNQSxFQUFFZ0MsY0FBY1ksVUFBVTVDLEVBQUVDLFdBQVcsVUFBVTtBQUUzRyxRQUFJQSxTQUFvRDtBQUN4RCxRQUFJK0MsdUJBQXdCL0MsVUFBUztBQUFBLGFBQzVCaUQscUJBQXNCakQsVUFBUztBQUV4QyxXQUFPO0FBQUEsTUFDTGtELEtBQUtQO0FBQUFBLE1BQ0xRLE9BQU9sQjtBQUFBQSxNQUNQSyxPQUFPUSxLQUFLUjtBQUFBQSxNQUNaQyxPQUFPTyxLQUFLUDtBQUFBQSxNQUNadkM7QUFBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU1vRCxxQkFBcUJaLGVBQWUxQyxPQUFPLENBQUN1RCxNQUFNQSxFQUFFckQsV0FBVyxXQUFXLEVBQUVNO0FBQ2xGLFFBQU1nRCxrQkFBa0JDLEtBQUtDLE1BQU9KLHFCQUFxQixJQUFLLEdBQUc7QUFFakUsUUFBTUsscUJBQXFCaEYsV0FBV3FCO0FBQUFBLElBQU8sQ0FBQ00sTUFDNUNBLEVBQUVpQyxLQUFLcUIsWUFBWSxFQUFFQyxTQUFTbkUsZ0JBQWdCa0UsWUFBWSxDQUFDLEtBQzNEdEQsRUFBRUMsVUFBVTJDLEtBQUssQ0FBQy9CLE1BQU1BLEVBQUVvQixLQUFLcUIsWUFBWSxFQUFFQyxTQUFTbkUsZ0JBQWdCa0UsWUFBWSxDQUFDLENBQUM7QUFBQSxFQUN0RjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9IQUNiLGlDQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLDZCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsOEVBQTRFO0FBQUE7QUFBQSxVQUM3RTlELGVBQWUsd0JBQXdCVjtBQUFBQSxhQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxpREFBK0MseUdBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ1pXO0FBQUFBLHlCQUFpQlMsU0FBUyxLQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNakMsV0FBVyxXQUFXO0FBQUEsWUFDckMsV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxVQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCO0FBQUEsY0FDdkIsdUJBQUMsVUFBSyxXQUFVLG9IQUNid0IsMkJBQWlCUyxVQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxRQUdGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTOUI7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFFBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQ3pCLHVCQUFDLFVBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQTtBQUFBO0FBQUEsVUFOdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTRDtBQUFBQSxZQUNULFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsc0JBQW1CLFdBQVUsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsY0FDdEQsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBO0FBQUE7QUFBQSxVQU50QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxTQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNENBLEtBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpRUFFYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1GLFdBQVcsVUFBVTtBQUFBLFVBQ3BDLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBGQUNiLGlDQUFDLGlCQUFjLFdBQVUsZ0RBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFLEtBRHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNENBQTJDLGlDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0RTtBQUFBLGdCQUM1RSx1QkFBQyxRQUFHLFdBQVUsaUVBQ1hLLHdCQUFja0YsZUFBZSxPQUFPLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFNLE9BQU0sV0FDWDtBQUFBLHVDQUFDLGNBQVcsV0FBVSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUM7QUFBQTtBQUFBLG1CQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBO0FBQUE7QUFBQSxRQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFtQkE7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU12RixXQUFXLFlBQVk7QUFBQSxVQUN0QyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksV0FBVSxvR0FDYixpQ0FBQyxTQUFNLFdBQVUsaUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsNENBQTJDLDZCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUN4RSx1QkFBQyxRQUFHLFdBQVUsaUVBQ1hNLDBCQUFnQmlGLGVBQWUsT0FBTyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBTSxPQUFNLFFBQ1ZoRDtBQUFBQSwrQkFBZU47QUFBQUEsZ0JBQU87QUFBQSxtQkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQTtBQUFBO0FBQUEsUUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0JBO0FBQUEsTUFHQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNakMsV0FBVyxZQUFZO0FBQUEsVUFDdEMsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsaUJBQWMsV0FBVSw4QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFVBQUssV0FBVSw0Q0FBMkMsK0JBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBFO0FBQUEsZ0JBQzFFLHVCQUFDLFFBQUcsV0FBVSxpRUFDVlMsNEJBQWlCd0IsVUFBVTFCLGVBQWVnRixlQUFlLE9BQU8sS0FEcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQU0sT0FBTSxXQUNWUjtBQUFBQTtBQUFBQSxnQkFBbUI7QUFBQSxnQkFBVUU7QUFBQUEsZ0JBQWdCO0FBQUEsbUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUE7QUFBQTtBQUFBLFFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtCQTtBQUFBLE1BR0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVMsTUFBTWpGLFdBQVcsU0FBUztBQUFBLFVBQ25DLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhGQUNiLGlDQUFDLHNCQUFtQixXQUFVLDhCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RCxLQUQxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsVUFBSyxXQUFVLDRDQUEyQyxnQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFDM0UsdUJBQUMsUUFBRyxXQUFVLGlFQUErRDtBQUFBO0FBQUEsa0JBQ25FbUMsY0FBY29ELGVBQWUsT0FBTztBQUFBLHFCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FBTSxPQUFNLFdBQ1Z6RTtBQUFBQSwrQkFBZW1CO0FBQUFBLGdCQUFPO0FBQUEsbUJBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUE7QUFBQTtBQUFBLFFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtCQTtBQUFBLFNBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxvQ0FFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw4SUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx5SEFDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNERBQTBELG1EQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFNLE9BQU0sV0FBVSxNQUFLLE1BQ3pCZ0Q7QUFBQUE7QUFBQUEsZ0JBQWdCO0FBQUEsbUJBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsaURBQStDLDRGQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNakYsV0FBV3VCLGVBQWUsbUJBQW1CLGdCQUFnQjtBQUFBLGNBQzVFLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBTUEseUJBQWUsbUJBQW1CLG9CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRDtBQUFBLGdCQUMxRCx1QkFBQyxjQUFXLFdBQVUsaUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1DO0FBQUE7QUFBQTtBQUFBLFlBTnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEsbUNBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLFlBQ3JCLHVCQUFDLFVBQUssV0FBVSwrQ0FBK0N3RDtBQUFBQTtBQUFBQSxjQUFtQjtBQUFBLGlCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRztBQUFBLGVBRjVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsT0FBTyxFQUFFUyxPQUFPLEdBQUdQLGVBQWUsSUFBSTtBQUFBO0FBQUEsWUFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRTBDLEtBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLCtEQUNaZCx5QkFBZXhCLElBQUksQ0FBQzhDLFNBQVM7QUFDNUIsZ0JBQU1DLGVBQWVELEtBQUs5RCxXQUFXLGNBQWMsWUFBWThELEtBQUs5RCxXQUFXLGdCQUFnQixZQUFZO0FBQzNHLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU0zQixXQUFXLFlBQVk7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSwrRUFBNkU7QUFBQTtBQUFBLG9CQUNyRnlGLEtBQUtaO0FBQUFBLHVCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsNERBQ2JZLGVBQUt4QixTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNKQUNad0IsZUFBS1gsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDBEQUNaVyxlQUFLdkIsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtHQUNiO0FBQUEseUNBQUMsU0FBTSxPQUFPd0IsY0FBcUIsTUFBSyxNQUNyQ0QsZUFBSzlELFVBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSx1SUFBcUksc0JBQXJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUE7QUFBQTtBQUFBLFlBekJLOEQsS0FBS1o7QUFBQUEsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBMkJBO0FBQUEsUUFFSixDQUFDLEtBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQ0E7QUFBQSxXQTNFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNEtBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNERBQTBELGlDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsbURBQ1ZyRDtBQUFBQSxpQ0FBaUJTO0FBQUFBLGdCQUFPO0FBQUEsbUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQ1QsaUJBQWlCUyxTQUFTLEtBQ3pCLHVCQUFDLFNBQU0sT0FBTSxXQUFVLE1BQUssTUFDekJULDJCQUFpQlMsVUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1pULDJCQUFpQlMsU0FBUyxJQUN6QlQsaUJBQWlCbUUsTUFBTSxHQUFHLENBQUMsRUFBRWhEO0FBQUFBLFlBQUksQ0FBQ2lELFNBQ2hDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNNUYsV0FBVyxXQUFXO0FBQUEsZ0JBQ3JDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx1REFDYjRGLGVBQUtDLFVBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSxnRUFBOEQsd0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFEQUNaRDtBQUFBQSx5QkFBS0U7QUFBQUEsb0JBQVM7QUFBQSxvQkFBV0YsS0FBS0csZUFBZTtBQUFBLHVCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBZEtILEtBQUtJO0FBQUFBLGNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCQTtBQUFBLFVBQ0QsSUFFRCx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUhBQ2IsaUNBQUMsZ0JBQWEsV0FBVSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsNkRBQTJELHFEQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsYUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlEQTtBQUFBLFFBRUN4RSxpQkFBaUJTLFNBQVMsS0FDekIsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1qQyxXQUFXLFdBQVc7QUFBQSxZQUNyQyxXQUFVO0FBQUEsWUFBcVE7QUFBQTtBQUFBLFVBSGpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0E3REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGdJQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBMEQsb0RBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFBaUQscUVBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSw4REFDZDtBQUFBLHFDQUFDLFVBQUssV0FBVSw2Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUFHO0FBQUEsaUJBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4REFDZDtBQUFBLHFDQUFDLFVBQUssV0FBVSwyQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxjQUFHO0FBQUEsaUJBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4REFDZDtBQUFBLHFDQUFDLFVBQUssV0FBVSwwQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxjQUFHO0FBQUEsaUJBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4REFDZDtBQUFBLHFDQUFDLFVBQUssV0FBVSwyREFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUU7QUFBQSxjQUFHO0FBQUEsaUJBRDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDWlcsbUJBQVNzQixTQUFTLElBQUl0QixTQUFTZ0MsSUFBSSxDQUFBc0QsWUFBVztBQUM3QyxnQkFBTUMsa0JBQWtCbkYsU0FBU1UsT0FBTyxDQUFBZ0MsTUFBS0EsRUFBRTBDLGNBQWNGLFFBQVFELEVBQUU7QUFFdkUsZ0JBQU1JLGFBQWE1RCxNQUFNQyxLQUFLLEVBQUNSLFFBQVEsRUFBQyxHQUFHLENBQUNtQyxHQUFHQyxNQUFNO0FBQ25ELGtCQUFNUSxNQUFNUixJQUFJO0FBQ2hCLGtCQUFNZ0MsYUFBYUgsZ0JBQWdCMUIsS0FBSyxDQUFBZixNQUFLQSxFQUFFQyxjQUFjbUIsR0FBRztBQUNoRSxnQkFBSXdCLGVBQWVBLFdBQVcxRSxXQUFXLGVBQWUwRSxXQUFXMUUsV0FBVyxhQUFhO0FBQ3pGLHFCQUFPLEVBQUUyRSxPQUFPLGFBQWFDLE9BQU9GLFdBQVdyQyxRQUFRLE9BQU9hLEdBQUcsR0FBRztBQUFBLFlBQ3RFLFdBQVd3QixlQUFlQSxXQUFXMUUsV0FBVyxpQkFBaUIwRSxXQUFXMUUsV0FBVyxlQUFlMEUsV0FBVzFFLFdBQVcsbUJBQW1CO0FBQzdJLHFCQUFPLEVBQUUyRSxPQUFPLGVBQWVDLE9BQU9GLFdBQVdyQyxRQUFRLE9BQU9hLEdBQUcsR0FBRztBQUFBLFlBQ3hFLFdBQVd3QixjQUFjQSxXQUFXMUUsV0FBVyxhQUFhO0FBQzFELHFCQUFPLEVBQUUyRSxPQUFPLGFBQWFDLE9BQU9GLFdBQVdyQyxRQUFRLE9BQU9hLEdBQUcsR0FBRztBQUFBLFlBQ3RFO0FBQ0EsbUJBQU8sRUFBRXlCLE9BQU8sV0FBV0MsT0FBTyxPQUFPMUIsR0FBRyxHQUFHO0FBQUEsVUFDakQsQ0FBQztBQUVELGdCQUFNMkIsWUFBWUosV0FBVzNFLE9BQU8sQ0FBQWdDLE1BQUtBLEVBQUU2QyxVQUFVLFdBQVcsRUFBRXJFO0FBQ2xFLGdCQUFNd0UsY0FBY0wsV0FBVzNFLE9BQU8sQ0FBQWdDLE1BQUtBLEVBQUU2QyxVQUFVLGFBQWEsRUFBRXJFO0FBQ3RFLGdCQUFNeUUsY0FBY3hCLEtBQUtDLE1BQU9xQixZQUFZLElBQUssR0FBRztBQUVwRCxpQkFDRSx1QkFBQyxTQUFxQixXQUFVLHFLQUM5QixpQ0FBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsdURBQXVEUCxrQkFBUWpDLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9GO0FBQUEsZ0JBQ25GaUMsUUFBUVUsZUFDUCx1QkFBQyxVQUFLLFdBQVUsdUVBQXFFO0FBQUE7QUFBQSxrQkFDekVWLFFBQVFVO0FBQUFBLHFCQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLEVBQUVuQixPQUFPLEdBQUdrQixXQUFXLElBQUk7QUFBQTtBQUFBLGtCQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXNDLEtBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsNERBQ2JBO0FBQUFBO0FBQUFBLGtCQUFZO0FBQUEscUJBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxnREFDWk4scUJBQVd6RCxJQUFJLENBQUNxQyxHQUFHNEIsUUFBUTtBQUMxQixvQkFBTUMsU0FBUzdCLEVBQUVzQixVQUFVO0FBQzNCLG9CQUFNUSxXQUFXOUIsRUFBRXNCLFVBQVU7QUFDN0Isb0JBQU1TLFVBQVUvQixFQUFFc0IsVUFBVTtBQUU1QixxQkFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxPQUFPLE9BQU9NLE1BQU0sQ0FBQyxLQUFLNUIsRUFBRXNCLEtBQUssS0FBS3RCLEVBQUV1QixLQUFLO0FBQUEsa0JBQzdDLFdBQVcsNkdBQ1RNLFNBQ0ksaUlBQ0FDLFdBQ0EsNklBQ0FDLFVBQ0EsK0dBQ0Esb0ZBQW9GO0FBQUEsa0JBRzFGO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlEQUF1RDtBQUFBO0FBQUEsc0JBQ2hFSCxNQUFNO0FBQUEseUJBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSx3Q0FDWkM7QUFBQUEsZ0NBQVUsdUJBQUMsZ0JBQWEsV0FBVSx3REFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEU7QUFBQSxzQkFDdEZDLFlBQVksdUJBQUMsVUFBSyxXQUFVLDREQUEyRCxzQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUY7QUFBQSxzQkFDN0ZDLFdBQVcsdUJBQUMsWUFBUyxXQUFVLDhDQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RDtBQUFBLHNCQUN6RSxDQUFDRixVQUFVLENBQUNDLFlBQVksQ0FBQ0MsV0FBVyx1QkFBQyxVQUFLLFdBQVUsZ0RBQStDLGlCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRTtBQUFBLHlCQUo1RztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUE7QUFBQTtBQUFBLGdCQXBCS0g7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXNCQTtBQUFBLFlBRUosQ0FBQyxLQS9CSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdDQTtBQUFBLGVBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0RBLEtBekRRWCxRQUFRRCxJQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBEQTtBQUFBLFFBRUosQ0FBQyxJQUNDLHVCQUFDLFNBQUksV0FBVSwrR0FBNkcsb0hBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQXJGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUZBO0FBQUEsV0FqSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtIQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHdKQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlIQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBMEQsMENBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxtREFDVjVGO0FBQUFBLHlCQUFXNkI7QUFBQUEsY0FBTztBQUFBLGNBQXNCTDtBQUFBQSxjQUFjO0FBQUEsY0FBd0JmO0FBQUFBLGlCQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxxQ0FBQyxVQUFPLFdBQVUsb0VBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtGO0FBQUEsY0FDbEY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLGFBQVk7QUFBQSxrQkFDWixPQUFPTTtBQUFBQSxrQkFDUCxVQUFVLENBQUM2RixNQUFNNUYsbUJBQW1CNEYsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGtCQUNsRCxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLNlE7QUFBQSxpQkFQL1E7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNbEgsV0FBVyxZQUFZO0FBQUEsZ0JBQ3RDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUNmLHVCQUFDLGdCQUFhLFdBQVUsaUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUE7QUFBQTtBQUFBLGNBTnZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2IsaUNBQUMsU0FBSSxXQUFVLDhCQUNiLGlDQUFDLFNBQ0M7QUFBQSxpQ0FBQyxlQUNDLGlDQUFDLFlBQ0M7QUFBQSxtQ0FBQyxhQUFVLFVBQVEsTUFBQyw2QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUNqQyx1QkFBQyxhQUFVLFVBQVEsTUFBQywrQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUM7QUFBQSxZQUNuQyx1QkFBQyxhQUFVLFVBQVEsTUFBQyxXQUFVLGNBQWEsK0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsYUFBVSxVQUFRLE1BQUMsV0FBVSxjQUFhLHNCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLGVBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxhQUNFb0YsNkJBQW1CbkQsU0FBUyxJQUMzQm1ELG1CQUFtQnpDO0FBQUFBLFlBQUksQ0FBQ1osTUFDdEI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxTQUFTLE1BQU0vQixXQUFXLFlBQVk7QUFBQSxnQkFDdEMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsYUFDQyxpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSwyQ0FBQyxVQUFPLFdBQVUsaUZBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStGO0FBQUEsb0JBQy9GLHVCQUFDLFVBQUssV0FBVSwrSEFDYitCLFlBQUVpQyxRQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLGFBQVUsV0FBVSxzREFDbEJqQyxZQUFFQyxVQUFVVyxJQUFJLENBQUNDLE1BQU1BLEVBQUVvQixJQUFJLEVBQUVtRCxLQUFLLElBQUksS0FBSyxHQUFHcEYsRUFBRUcsaUJBQWlCLENBQUMsZUFEdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGFBQVUsV0FBVSxtRUFDbEJILFlBQUVxRixrQkFBa0IsS0FEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLGFBQVUsV0FBVSxjQUNuQixpQ0FBQyxnQkFBYSxXQUFVLGdIQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvSSxLQUR0STtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBcEJLckYsRUFBRWlFO0FBQUFBLGNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQTtBQUFBLFVBQ0QsSUFFRCx1QkFBQyxZQUNDLGlDQUFDLGFBQVUsU0FBUyxHQUFHLFdBQVUscURBQW1EO0FBQUE7QUFBQSxZQUNuRDdFLG1CQUFtQk47QUFBQUEsWUFBWTtBQUFBLGVBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLEtBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsYUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQSxLQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOENBLEtBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxXQWpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0ZBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsd0pBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTBELHNDQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsbURBQWlELGdEQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNaO0FBQUEsVUFDQyxFQUFFMEYsT0FBTywrQkFBK0JjLEtBQUssY0FBeUJDLE1BQU0seUNBQXlDO0FBQUEsVUFDckgsRUFBRWYsT0FBTywrQkFBK0JjLEtBQUssV0FBc0JDLE1BQU0sb0NBQW9DO0FBQUEsVUFDN0csRUFBRWYsT0FBTyxpQ0FBaUNjLEtBQUssa0JBQTZCQyxNQUFNLCtCQUErQjtBQUFBLFVBQ2pILEVBQUVmLE9BQU8sZ0NBQWdDYyxLQUFLLFdBQXNCQyxNQUFNLHdDQUF3QztBQUFBLFFBQUMsRUFDbkgzRTtBQUFBQSxVQUFJLENBQUM4QyxTQUNMO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU16RixXQUFXeUYsS0FBSzRCLEdBQUc7QUFBQSxjQUNsQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHVJQUNaNUIsZUFBS2MsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUE0Q2QsZUFBSzZCLFFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFFO0FBQUEscUJBSnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxnQkFBYSxXQUFVLHdIQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0STtBQUFBO0FBQUE7QUFBQSxZQVh2STdCLEtBQUs0QjtBQUFBQSxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLFFBQ0QsS0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxTQTlYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK1hBO0FBQUEsT0ExZ0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyZ0JBO0FBRUo7QUFBRW5HLEdBNW1CV25CLGVBQTJDO0FBQUEsS0FBM0NBO0FBQTJDLElBQUF3SDtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlVzZXJzIiwiR3JhZHVhdGlvbkNhcCIsIkNhbGVuZGFyQ2hlY2siLCJSZWNlaXB0SW5kaWFuUnVwZWUiLCJTaGllbGRBbGVydCIsIk1hcFBpbiIsIlBsdXMiLCJDaGVja0NpcmNsZTIiLCJBcnJvd1JpZ2h0IiwiQ2hldnJvblJpZ2h0IiwiU2VhcmNoIiwiRXh0ZXJuYWxMaW5rIiwiQ2FsZW5kYXIiLCJUcmVuZGluZ1VwIiwiYXBpVXJsIiwiQmFkZ2UiLCJUYWJsZSIsIlRhYmxlQm9keSIsIlRhYmxlQ2VsbCIsIlRhYmxlSGVhZGVyIiwiVGFibGVSb3ciLCJEYXNoYm9hcmRWaWV3Iiwib25OYXZpZ2F0ZSIsIm9uT3Blbk5ld1Nlc3Npb24iLCJvbk9wZW5OZXdGaW5hbmNlIiwib25PcGVuTmV3QXR0ZW5kYW5jZSIsInBhbmNoYXlhdHMiLCJzdHVkZW50c0NvdW50Iiwidm9sdW50ZWVyc0NvdW50Iiwic2Vzc2lvbnNDb3VudCIsInBlbmRpbmdDb3VudCIsImF0dGVuZGFuY2VEcmFmdHMiLCJ1c2VyUm9sZSIsImNsdXN0ZXJzIiwiYXBwcm92YWxzIiwiY2x1c3Rlck5hbWUiLCJmaW5hbmNlRW50cmllcyIsInNlc3Npb25zIiwic3R1ZGVudHMiLCJ2b2x1bnRlZXJzIiwiX3MiLCJwYW5jaGF5YXRTZWFyY2giLCJzZXRQYW5jaGF5YXRTZWFyY2giLCJzZXR1cERheXMiLCJzZXRTZXR1cERheXMiLCJpc1N1cGVyQWRtaW4iLCJwZW5kaW5nQXBwcm92YWxzIiwiZmlsdGVyIiwiYSIsInN0YXR1cyIsInRvdGFsVmlsbGFnZXMiLCJyZWR1Y2UiLCJzdW0iLCJwIiwidmlsbGFnZXMiLCJsZW5ndGgiLCJ2aWxsYWdlc0NvdW50IiwidG90YWxFeHBlbnNlcyIsImYiLCJOdW1iZXIiLCJhbW91bnQiLCJ1bmlxdWVDb2xsZWdlcyIsIkFycmF5IiwiZnJvbSIsIlNldCIsIm1hcCIsInYiLCJjb2xsZWdlIiwiQm9vbGVhbiIsImNvbGxlZ2VzVGV4dCIsImZldGNoIiwidGhlbiIsInJlcyIsIm9rIiwianNvbiIsImRhdGEiLCJzdWNjZXNzIiwiaXNBcnJheSIsInNldHVwIiwicyIsImRheU51bWJlciIsImRheV9udW1iZXIiLCJzZXNzaW9uTmFtZSIsInNlc3Npb25fbmFtZSIsImNhdGNoIiwiZGVmYXVsdFN1Z2dlc3RlZE5hbWVzIiwibmFtZSIsIm1vbnRoIiwidG9waWMiLCJkeW5hbWljUm9hZG1hcCIsIl8iLCJpIiwiZGF5TnVtIiwiY3VzdG9tQ29uZmlnIiwiZmluZCIsIm1ldGEiLCJoYXNDb21wbGV0ZWRBdHRlbmRhbmNlIiwic29tZSIsImhhc1BlbmRpbmdBdHRlbmRhbmNlIiwiZGF5IiwidGl0bGUiLCJjb21wbGV0ZWREYXlzQ291bnQiLCJkIiwicHJvZ3Jlc3NQZXJjZW50IiwiTWF0aCIsInJvdW5kIiwiZmlsdGVyZWRQYW5jaGF5YXRzIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInRvTG9jYWxlU3RyaW5nIiwid2lkdGgiLCJpdGVtIiwiYmFkZ2VWYXJpYW50Iiwic2xpY2UiLCJhcHByIiwibW9kdWxlIiwicmVjb3JkSWQiLCJzdWJtaXR0ZWRCeSIsImlkIiwiY2x1c3RlciIsImNsdXN0ZXJTZXNzaW9ucyIsImNsdXN0ZXJJZCIsImRheXNTdGF0dXMiLCJkYXlTZXNzaW9uIiwic3RhdGUiLCJsYWJlbCIsImNvbXBDb3VudCIsImluUHJvZ0NvdW50IiwicHJvZ3Jlc3NQY3QiLCJjb2xsZWdlTmFtZSIsImlkeCIsImlzRG9uZSIsImlzSW5Qcm9nIiwiaXNTY2hlZCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImpvaW4iLCJhY3RpdmVTdHVkZW50cyIsInRhYiIsImRlc2MiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmRWaWV3LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBVc2VycywgXG4gIEdyYWR1YXRpb25DYXAsIFxuICBDYWxlbmRhckNoZWNrLCBcbiAgUmVjZWlwdEluZGlhblJ1cGVlLCBcbiAgU2hpZWxkQWxlcnQsIFxuICBNYXBQaW4sIFxuICBQbHVzLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQXJyb3dSaWdodCwgXG4gIENoZXZyb25SaWdodCwgXG4gIFNlYXJjaCwgXG4gIEJvb2tPcGVuLCBcbiAgQ2xvY2ssIFxuICBFeHRlcm5hbExpbmssXG4gIENhbGVuZGFyLFxuICBTcGFya2xlcyxcbiAgVHJlbmRpbmdVcCxcbiAgQXJyb3dVcFJpZ2h0LFxuICBBcnJvd0Rvd25SaWdodCxcbiAgTGF5ZXJzXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBUYWJUeXBlLCBQYW5jaGF5YXQsIEF0dGVuZGFuY2VTZXNzaW9uLCBDbHVzdGVyLCBBcHByb3ZhbEl0ZW0sIFVzZXJSb2xlLCBGaW5hbmNlRW50cnksIFNlc3Npb24sIFN0dWRlbnQsIFZvbHVudGVlciB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IGFwaVVybCB9IGZyb20gJy4uL3V0aWxzL2FwaSc7XG5pbXBvcnQgQmFkZ2UgZnJvbSAnLi91aS9iYWRnZSc7XG5pbXBvcnQgQ29tcG9uZW50Q2FyZCBmcm9tICcuL3VpL0NvbXBvbmVudENhcmQnO1xuaW1wb3J0IHsgVGFibGUsIFRhYmxlQm9keSwgVGFibGVDZWxsLCBUYWJsZUhlYWRlciwgVGFibGVSb3cgfSBmcm9tICcuL3VpL3RhYmxlJztcblxuaW50ZXJmYWNlIERhc2hib2FyZFZpZXdQcm9wcyB7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IFRhYlR5cGUsIHRhcmdldElkPzogc3RyaW5nKSA9PiB2b2lkO1xuICBvbk9wZW5OZXdTZXNzaW9uOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5OZXdGaW5hbmNlOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5OZXdBdHRlbmRhbmNlOiAoKSA9PiB2b2lkO1xuICBwYW5jaGF5YXRzOiBQYW5jaGF5YXRbXTtcbiAgc3R1ZGVudHNDb3VudDogbnVtYmVyO1xuICB2b2x1bnRlZXJzQ291bnQ6IG51bWJlcjtcbiAgc2Vzc2lvbnNDb3VudDogbnVtYmVyO1xuICBwZW5kaW5nQ291bnQ6IG51bWJlcjtcbiAgYXR0ZW5kYW5jZURyYWZ0czogQXR0ZW5kYW5jZVNlc3Npb25bXTtcbiAgdXNlclJvbGU/OiBVc2VyUm9sZTtcbiAgY2x1c3RlcnM/OiBDbHVzdGVyW107XG4gIGFwcHJvdmFscz86IEFwcHJvdmFsSXRlbVtdO1xuICBjbHVzdGVyTmFtZT86IHN0cmluZztcbiAgZmluYW5jZUVudHJpZXM/OiBGaW5hbmNlRW50cnlbXTtcbiAgc2Vzc2lvbnM/OiBTZXNzaW9uW107XG4gIHN0dWRlbnRzPzogU3R1ZGVudFtdO1xuICB2b2x1bnRlZXJzPzogVm9sdW50ZWVyW107XG59XG5cbmV4cG9ydCBjb25zdCBEYXNoYm9hcmRWaWV3OiBSZWFjdC5GQzxEYXNoYm9hcmRWaWV3UHJvcHM+ID0gKHtcbiAgb25OYXZpZ2F0ZSxcbiAgb25PcGVuTmV3U2Vzc2lvbixcbiAgb25PcGVuTmV3RmluYW5jZSxcbiAgb25PcGVuTmV3QXR0ZW5kYW5jZSxcbiAgcGFuY2hheWF0cyA9IFtdLFxuICBzdHVkZW50c0NvdW50ID0gMCxcbiAgdm9sdW50ZWVyc0NvdW50ID0gMCxcbiAgc2Vzc2lvbnNDb3VudCA9IDAsXG4gIHBlbmRpbmdDb3VudCA9IDAsXG4gIGF0dGVuZGFuY2VEcmFmdHMgPSBbXSxcbiAgdXNlclJvbGUgPSAnQ2x1c3RlciBBZG1pbicsXG4gIGNsdXN0ZXJzID0gW10sXG4gIGFwcHJvdmFscyA9IFtdLFxuICBjbHVzdGVyTmFtZSA9ICdEaGFybWFwdXJpIENsdXN0ZXInLFxuICBmaW5hbmNlRW50cmllcyA9IFtdLFxuICBzZXNzaW9ucyA9IFtdLFxuICBzdHVkZW50cyA9IFtdLFxuICB2b2x1bnRlZXJzID0gW10sXG59KSA9PiB7XG4gIGNvbnN0IFtwYW5jaGF5YXRTZWFyY2gsIHNldFBhbmNoYXlhdFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzZXR1cERheXMsIHNldFNldHVwRGF5c10gPSB1c2VTdGF0ZTx7IGRheU51bWJlcjogbnVtYmVyOyBzZXNzaW9uTmFtZTogc3RyaW5nIH1bXT4oW10pO1xuICBjb25zdCBpc1N1cGVyQWRtaW4gPSB1c2VyUm9sZSA9PT0gJ1N1cGVyIEFkbWluJztcbiAgY29uc3QgcGVuZGluZ0FwcHJvdmFscyA9IGFwcHJvdmFscy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSAnUGVuZGluZycpO1xuICBcbiAgLy8gVG90YWwgZHluYW1pYyB2aWxsYWdlc1xuICBjb25zdCB0b3RhbFZpbGxhZ2VzID0gcGFuY2hheWF0cy5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgKHAudmlsbGFnZXM/Lmxlbmd0aCB8fCBwLnZpbGxhZ2VzQ291bnQgfHwgMCksIDApO1xuICBcbiAgLy8gVG90YWwgZHluYW1pYyBleHBlbnNlcyBjYWxjdWxhdGVkIGZyb20gdmVyaWZpZWQgZW50cmllc1xuICBjb25zdCB0b3RhbEV4cGVuc2VzID0gZmluYW5jZUVudHJpZXMucmVkdWNlKChzdW0sIGYpID0+IHN1bSArIChOdW1iZXIoZi5hbW91bnQpIHx8IDApLCAwKTtcblxuICAvLyBEeW5hbWljIHVuaXF1ZSBjb2xsZWdlcyBjb3VudFxuICBjb25zdCB1bmlxdWVDb2xsZWdlcyA9IEFycmF5LmZyb20obmV3IFNldCh2b2x1bnRlZXJzLm1hcCgodikgPT4gdi5jb2xsZWdlKS5maWx0ZXIoQm9vbGVhbikpKTtcbiAgY29uc3QgY29sbGVnZXNUZXh0ID0gdW5pcXVlQ29sbGVnZXMubGVuZ3RoID4gMCBcbiAgICA/IGAke3VuaXF1ZUNvbGxlZ2VzLmxlbmd0aH0gUGFydG5lciBDb2xsZWdlJHt1bmlxdWVDb2xsZWdlcy5sZW5ndGggPiAxID8gJ3MnIDogJyd9YCBcbiAgICA6ICdObyBjb2xsZWdlcyBtYXBwZWQnO1xuXG4gIC8vIExvYWQgY3VzdG9tIGFjYWRlbWljIGRheSBuYW1lcyBkeW5hbWljYWxseSBpZiBjb25maWd1cmVkXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2goYXBpVXJsKCcvYXBpL2FjYWRlbWljLXNldHVwJykpXG4gICAgICAudGhlbigocmVzKSA9PiAocmVzLm9rID8gcmVzLmpzb24oKSA6IG51bGwpKVxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgaWYgKGRhdGE/LnN1Y2Nlc3MgJiYgQXJyYXkuaXNBcnJheShkYXRhLnNldHVwKSkge1xuICAgICAgICAgIHNldFNldHVwRGF5cyhkYXRhLnNldHVwLm1hcCgoczogeyBkYXlfbnVtYmVyOiBudW1iZXI7IHNlc3Npb25fbmFtZTogc3RyaW5nIH0pID0+ICh7XG4gICAgICAgICAgICBkYXlOdW1iZXI6IHMuZGF5X251bWJlcixcbiAgICAgICAgICAgIHNlc3Npb25OYW1lOiBzLnNlc3Npb25fbmFtZSxcbiAgICAgICAgICB9KSkpO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGRlZmF1bHRTdWdnZXN0ZWROYW1lczogUmVjb3JkPG51bWJlciwgeyBuYW1lOiBzdHJpbmc7IG1vbnRoOiBzdHJpbmc7IHRvcGljOiBzdHJpbmcgfT4gPSB7XG4gICAgMTogeyBuYW1lOiAnU3Bva2VuIEVuZ2xpc2ggJiBHb2FsIFNldHRpbmcnLCBtb250aDogJ0ZlYicsIHRvcGljOiAnQ29tbXVuaWNhdGlvbicgfSxcbiAgICAyOiB7IG5hbWU6ICdCYXNpYyBBcml0aG1ldGljICYgTG9naWMgUHV6emxlcycsIG1vbnRoOiAnRmViJywgdG9waWM6ICdRdWFudGl0YXRpdmUgQXB0aXR1ZGUnIH0sXG4gICAgMzogeyBuYW1lOiAnSGFuZHMtb24gU2NpZW5jZSBPYnNlcnZhdGlvbicsIG1vbnRoOiAnTWFyJywgdG9waWM6ICdBcHBsaWVkIFNjaWVuY2VzJyB9LFxuICAgIDQ6IHsgbmFtZTogJ0xpZmUgU2tpbGxzLCBIZWFsdGggJiBIeWdpZW5lJywgbW9udGg6ICdNYXInLCB0b3BpYzogJ1dlbGxuZXNzICYgU2FuaXRhdGlvbicgfSxcbiAgICA1OiB7IG5hbWU6ICdDcmVhdGl2ZSBBcnRzICYgRXhwcmVzc2lvbicsIG1vbnRoOiAnTWFyJywgdG9waWM6ICdDcmVhdGl2ZSBBcnRzJyB9LFxuICAgIDY6IHsgbmFtZTogJ0RpZ2l0YWwgTGl0ZXJhY3kgQmFzaWNzJywgbW9udGg6ICdBcHInLCB0b3BpYzogJ1RlY2hub2xvZ3knIH0sXG4gICAgNzogeyBuYW1lOiAnRW52aXJvbm1lbnQgJiBDb21tdW5pdHkgQWN0aW9uJywgbW9udGg6ICdBcHInLCB0b3BpYzogJ0NpdmljIEFjdGlvbicgfSxcbiAgICA4OiB7IG5hbWU6ICdDdWxtaW5hdGlvbiBTaG93Y2FzZSAmIEZlZWRiYWNrJywgbW9udGg6ICdBcHInLCB0b3BpYzogJ1ByZXNlbnRhdGlvbicgfSxcbiAgfTtcblxuICAvLyBCdWlsZCBkeW5hbWljIDgtZGF5IHN0YXR1cyBiYXNlZCBvbiBsb2dnZWQgYXR0ZW5kYW5jZVxuICBjb25zdCBkeW5hbWljUm9hZG1hcCA9IEFycmF5LmZyb20oeyBsZW5ndGg6IDggfSwgKF8sIGkpID0+IHtcbiAgICBjb25zdCBkYXlOdW0gPSBpICsgMTtcbiAgICBjb25zdCBjdXN0b21Db25maWcgPSBzZXR1cERheXMuZmluZCgocykgPT4gcy5kYXlOdW1iZXIgPT09IGRheU51bSk7XG4gICAgY29uc3QgbWV0YSA9IGRlZmF1bHRTdWdnZXN0ZWROYW1lc1tkYXlOdW1dO1xuICAgIGNvbnN0IHNlc3Npb25OYW1lID0gY3VzdG9tQ29uZmlnPy5zZXNzaW9uTmFtZSB8fCBtZXRhLm5hbWU7XG4gICAgXG4gICAgY29uc3QgaGFzQ29tcGxldGVkQXR0ZW5kYW5jZSA9IGF0dGVuZGFuY2VEcmFmdHMuc29tZSgoYSkgPT4gYS5kYXlOdW1iZXIgPT09IGRheU51bSAmJiBhLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJyk7XG4gICAgY29uc3QgaGFzUGVuZGluZ0F0dGVuZGFuY2UgPSBhdHRlbmRhbmNlRHJhZnRzLnNvbWUoKGEpID0+IGEuZGF5TnVtYmVyID09PSBkYXlOdW0gJiYgYS5zdGF0dXMgIT09ICdBcHByb3ZlZCcpO1xuICAgIFxuICAgIGxldCBzdGF0dXM6ICdDb21wbGV0ZWQnIHwgJ0luIFByb2dyZXNzJyB8ICdTY2hlZHVsZWQnID0gJ1NjaGVkdWxlZCc7XG4gICAgaWYgKGhhc0NvbXBsZXRlZEF0dGVuZGFuY2UpIHN0YXR1cyA9ICdDb21wbGV0ZWQnO1xuICAgIGVsc2UgaWYgKGhhc1BlbmRpbmdBdHRlbmRhbmNlKSBzdGF0dXMgPSAnSW4gUHJvZ3Jlc3MnO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGRheTogZGF5TnVtLFxuICAgICAgdGl0bGU6IHNlc3Npb25OYW1lLFxuICAgICAgbW9udGg6IG1ldGEubW9udGgsXG4gICAgICB0b3BpYzogbWV0YS50b3BpYyxcbiAgICAgIHN0YXR1cyxcbiAgICB9O1xuICB9KTtcblxuICBjb25zdCBjb21wbGV0ZWREYXlzQ291bnQgPSBkeW5hbWljUm9hZG1hcC5maWx0ZXIoKGQpID0+IGQuc3RhdHVzID09PSAnQ29tcGxldGVkJykubGVuZ3RoO1xuICBjb25zdCBwcm9ncmVzc1BlcmNlbnQgPSBNYXRoLnJvdW5kKChjb21wbGV0ZWREYXlzQ291bnQgLyA4KSAqIDEwMCk7XG5cbiAgY29uc3QgZmlsdGVyZWRQYW5jaGF5YXRzID0gcGFuY2hheWF0cy5maWx0ZXIoKHApID0+XG4gICAgcC5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocGFuY2hheWF0U2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgcC52aWxsYWdlcz8uc29tZSgodikgPT4gdi5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocGFuY2hheWF0U2VhcmNoLnRvTG93ZXJDYXNlKCkpKVxuICApO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02XCI+XG4gICAgICB7LyogMS4gVGFpbEFkbWluIFdlbGNvbWUgSGVhZGVyIENhcmQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IG1kOnAtNiBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM11cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIEdvb2QgZGF5LCB7aXNTdXBlckFkbWluID8gJ1N1cGVyIEFkbWluaXN0cmF0b3InIDogY2x1c3Rlck5hbWV9XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgIE92ZXJ2aWV3IG9mIHJ1cmFsIGVkdWNhdGlvbiBvcGVyYXRpb25zLCBmaWVsZCBtZW50b3JzaGlwLCBhbmQgOC1zZXNzaW9uIGN5Y2xlIG1pbGVzdG9uZXMuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUXVpY2sgQWN0aW9uIFRvb2xiYXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBzaHJpbmstMFwiPlxuICAgICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdhcHByb3ZhbHMnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdhcm5pbmctMjAwIGJnLXdhcm5pbmctNTAvNzAgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13YXJuaW5nLTcwMCBob3ZlcjpiZy13YXJuaW5nLTEwMCBkYXJrOmJvcmRlci13YXJuaW5nLTkwMC80MCBkYXJrOmJnLXdhcm5pbmctNTAwLzEwIGRhcms6dGV4dC13YXJuaW5nLTQwMCB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5QZW5kaW5nIEFwcHJvdmFsczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXdhcm5pbmctNTAwIHB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICB7cGVuZGluZ0FwcHJvdmFscy5sZW5ndGh9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uT3Blbk5ld0F0dGVuZGFuY2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWJyYW5kLTUwMCBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctYnJhbmQtNjAwIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+TWFyayBBdHRlbmRhbmNlPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uT3Blbk5ld0ZpbmFuY2V9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcHgtMy41IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWNlaXB0SW5kaWFuUnVwZWUgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWJyYW5kLTUwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlJlY29yZCBFeHBlbnNlPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiAyLiBUYWlsQWRtaW4gRWNvbW1lcmNlL0VSUCBNZXRyaWNzIDQtR3JpZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNCBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBtZDpnYXAtNlwiPlxuICAgICAgICB7LyogTWV0cmljIDE6IEVucm9sbGVkIFN0dWRlbnRzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnc3R1ZGVudHMnKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBzaGFkb3ctdGhlbWUteHMgdHJhbnNpdGlvbiBob3Zlcjpib3JkZXItYnJhbmQtMzAwIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdIG1kOnAtNlwiXG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1icmFuZC01MCByb3VuZGVkLXhsIGRhcms6YmctYnJhbmQtNTAwLzEwXCI+XG4gICAgICAgICAgICA8R3JhZHVhdGlvbkNhcCBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC1icmFuZC00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIG10LTVcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5FbnJvbGxlZCBTdHVkZW50czwvc3Bhbj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LTIgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgdGV4dC10aXRsZS1zbSBkYXJrOnRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgICAgICB7c3R1ZGVudHNDb3VudC50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwic3VjY2Vzc1wiPlxuICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgIEFjdGl2ZVxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1ldHJpYyAyOiBGaWVsZCBNZW50b3JzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgndm9sdW50ZWVycycpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci1ibHVlLWxpZ2h0LTMwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXSBtZDpwLTZcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmctYmx1ZS1saWdodC01MCByb3VuZGVkLXhsIGRhcms6YmctYmx1ZS1saWdodC01MDAvMTBcIj5cbiAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQtYmx1ZS1saWdodC01MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIG10LTVcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5GaWVsZCBNZW50b3JzPC9zcGFuPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwibXQtMiBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXRpdGxlLXNtIGRhcms6dGV4dC13aGl0ZS85MFwiPlxuICAgICAgICAgICAgICAgIHt2b2x1bnRlZXJzQ291bnQudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cImluZm9cIj5cbiAgICAgICAgICAgICAge3VuaXF1ZUNvbGxlZ2VzLmxlbmd0aH0gQ29sbGVnZXNcbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWMgMzogQXR0ZW5kYW5jZSBMb2dzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnYXR0ZW5kYW5jZScpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci1zdWNjZXNzLTMwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXSBtZDpwLTZcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmctc3VjY2Vzcy01MCByb3VuZGVkLXhsIGRhcms6Ymctc3VjY2Vzcy01MDAvMTBcIj5cbiAgICAgICAgICAgIDxDYWxlbmRhckNoZWNrIGNsYXNzTmFtZT1cImgtNiB3LTYgdGV4dC1zdWNjZXNzLTUwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBqdXN0aWZ5LWJldHdlZW4gbXQtNVwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPkF0dGVuZGFuY2UgTG9nczwvc3Bhbj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LTIgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgdGV4dC10aXRsZS1zbSBkYXJrOnRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgICAgICB7KGF0dGVuZGFuY2VEcmFmdHMubGVuZ3RoIHx8IHNlc3Npb25zQ291bnQpLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8QmFkZ2UgY29sb3I9XCJzdWNjZXNzXCI+XG4gICAgICAgICAgICAgIHtjb21wbGV0ZWREYXlzQ291bnR9LzggRGF5cyAoe3Byb2dyZXNzUGVyY2VudH0lKVxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1ldHJpYyA0OiBDbHVzdGVyIEV4cGVuc2VzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnZmluYW5jZScpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IHNoYWRvdy10aGVtZS14cyB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci13YXJuaW5nLTMwMCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXSBtZDpwLTZcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmctd2FybmluZy01MCByb3VuZGVkLXhsIGRhcms6Ymctd2FybmluZy01MDAvMTBcIj5cbiAgICAgICAgICAgIDxSZWNlaXB0SW5kaWFuUnVwZWUgY2xhc3NOYW1lPVwiaC02IHctNiB0ZXh0LXdhcm5pbmctNTAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBtdC01XCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+Q2x1c3RlciBFeHBlbnNlczwvc3Bhbj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LTIgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgdGV4dC10aXRsZS1zbSBkYXJrOnRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgICAgICAmIzgzNzc7e3RvdGFsRXhwZW5zZXMudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cIndhcm5pbmdcIj5cbiAgICAgICAgICAgICAge2ZpbmFuY2VFbnRyaWVzLmxlbmd0aH0gQmlsbHNcbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiAzLiBNYWluIERhc2hib2FyZCBCZW50byBMYXlvdXQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEyIGdhcC00IG1kOmdhcC02XCI+XG4gICAgICAgIHsvKiBBY2FkZW1pYyBDdXJyaWN1bHVtIFJvYWRtYXAgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgeGw6Y29sLXNwYW4tOCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBtZDpwLTYgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItNSBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgZGFyazpib3JkZXItZ3JheS04MDBcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZS85MFwiPlxuICAgICAgICAgICAgICAgICAgOC1EYXkgQWNhZGVtaWMgQ3VycmljdWx1bSAoRmViJm5kYXNoO0FwcilcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj1cInByaW1hcnlcIiBzaXplPVwic21cIj5cbiAgICAgICAgICAgICAgICAgIHtwcm9ncmVzc1BlcmNlbnR9JSBEZWxpdmVyZWRcbiAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgU3RydWN0dXJlZCBtaWxlc3RvbmUgcHJvZ3Jlc3Npb24gc3luY2hyb25pc2VkIGFjcm9zcyB2aWxsYWdlIHNjaG9vbCBjZW50cmVzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZShpc1N1cGVyQWRtaW4gPyAnYWNhZGVtaWMtc2V0dXAnIDogJ21vZHVsZS1saWJyYXJ5Jyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBzaGFkb3ctdGhlbWUteHMgaG92ZXI6YmctZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTcwMCBkYXJrOmJnLWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMCBkYXJrOmhvdmVyOmJnLXdoaXRlLzUgdHJhbnNpdGlvbiBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPntpc1N1cGVyQWRtaW4gPyAnQ29uZmlndXJlIHRlcm0nIDogJ01vZHVsZSBsaWJyYXJ5J308L3NwYW4+XG4gICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFByb2dyZXNzIGJhciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgIDxzcGFuPkRlbGl2ZXJ5IFN0YXR1czwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPntjb21wbGV0ZWREYXlzQ291bnR9IG9mIDggU2Vzc2lvbnMgQ29tcGxldGVkPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMiB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCBkYXJrOmJnLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgcm91bmRlZC1mdWxsIGJnLWJyYW5kLTUwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwcm9ncmVzc1BlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIDggTWlsZXN0b25lIENhcmRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC0zLjVcIj5cbiAgICAgICAgICAgIHtkeW5hbWljUm9hZG1hcC5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgYmFkZ2VWYXJpYW50ID0gaXRlbS5zdGF0dXMgPT09ICdDb21wbGV0ZWQnID8gJ3N1Y2Nlc3MnIDogaXRlbS5zdGF0dXMgPT09ICdJbiBQcm9ncmVzcycgPyAncHJpbWFyeScgOiAnbGlnaHQnO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5kYXl9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdhdHRlbmRhbmNlJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlciByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MC81MCBwLTQgaG92ZXI6Ym9yZGVyLWJyYW5kLTMwMCBob3ZlcjpiZy1icmFuZC01MC8zMCB0cmFuc2l0aW9uLWFsbCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBkYXJrOmhvdmVyOmJvcmRlci1icmFuZC04MDAgZGFyazpob3ZlcjpiZy1icmFuZC01MDAvNVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRGF5IDB7aXRlbS5kYXl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC1icmFuZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5tb250aH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1icmFuZC01MDAgZGFyazp0ZXh0LXdoaXRlIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbi1jb2xvcnMgbGluZS1jbGFtcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS50b3BpY31cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTIuNSBib3JkZXItdCBib3JkZXItZ3JheS0yMDAvNjAgZGFyazpib3JkZXItZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxCYWRnZSBjb2xvcj17YmFkZ2VWYXJpYW50IGFzIGFueX0gc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTUwMCBkYXJrOnRleHQtZ3JheS01MDAgZGFyazpncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIExvZ3MgJnJhcnI7XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBcHByb3ZhbHMgUXVldWUgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgeGw6Y29sLXNwYW4tNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBtZDpwLTYgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlLzkwXCI+XG4gICAgICAgICAgICAgICAgICBQZW5kaW5nIEFwcHJvdmFsc1xuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtwZW5kaW5nQXBwcm92YWxzLmxlbmd0aH0gZW50cmllcyByZXF1aXJpbmcgdmVyaWZpY2F0aW9uXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPEJhZGdlIGNvbG9yPVwid2FybmluZ1wiIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHMubGVuZ3RofVxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICBwZW5kaW5nQXBwcm92YWxzLnNsaWNlKDAsIDQpLm1hcCgoYXBwcikgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9e2FwcHIuaWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2FwcHJvdmFscycpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciByb3VuZGVkLXhsIHAtMyBiZy1ncmF5LTUwIGhvdmVyOmJnLWJyYW5kLTUwLzQwIGRhcms6Ymctd2hpdGUvWzAuMDJdIGRhcms6aG92ZXI6YmctYnJhbmQtNTAwLzUgdHJhbnNpdGlvbiBzcGFjZS15LTFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcHIubW9kdWxlfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13YXJuaW5nLTYwMCBkYXJrOnRleHQtd2FybmluZy00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJldmlldyAmcmFycjtcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7YXBwci5yZWNvcmRJZH0gJm1pZGRvdDsge2FwcHIuc3VibWl0dGVkQnkgfHwgJ1ZvbHVudGVlcid9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBoLTEyIHctMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctc3VjY2Vzcy01MCBkYXJrOmJnLXN1Y2Nlc3MtNTAwLzEwIHRleHQtc3VjY2Vzcy01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTYgdy02XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEFsbCBmaWVsZCBsb2dzIGFuZCBleHBlbnNlcyBhcHByb3ZlZC5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAge3BlbmRpbmdBcHByb3ZhbHMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdhcHByb3ZhbHMnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy13aGl0ZSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHNoYWRvdy10aGVtZS14cyBob3ZlcjpiZy1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6aG92ZXI6Ymctd2hpdGUvNSB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIE9wZW4gQXBwcm92YWwgQ2VudGVyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIDgtRGF5IFByb2dyZXNzIGJ5IENsdXN0ZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZSBwLTUgbWQ6cC02IHNoYWRvdy10aGVtZS14cyBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAzXVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGdhcC0yIG1iLTVcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZS85MFwiPlxuICAgICAgICAgICAgICAgIDgtRGF5IEN1cnJpY3VsdW0gUHJvZ3Jlc3MgYnkgQ2x1c3RlclxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIE1pbGVzdG9uZSB0cmFja2luZyBhY3Jvc3MgYWxsIDggYWNhZGVtaWMgcHJvZ3JhbSBkYXlzXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDBcIiAvPiBDb21wbGV0ZWRcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtZ3JheS02MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwMFwiIC8+IEluIFByb2dyZXNzXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWdyYXktNjAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiIC8+IFNjaGVkdWxlZFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1ncmF5LTYwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctZ3JheS0zMDAgZGFyazpiZy1ncmF5LTYwMFwiIC8+IFBlbmRpbmdcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMy41XCI+XG4gICAgICAgICAgICB7Y2x1c3RlcnMubGVuZ3RoID4gMCA/IGNsdXN0ZXJzLm1hcChjbHVzdGVyID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY2x1c3RlclNlc3Npb25zID0gc2Vzc2lvbnMuZmlsdGVyKHMgPT4gcy5jbHVzdGVySWQgPT09IGNsdXN0ZXIuaWQpO1xuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgY29uc3QgZGF5c1N0YXR1cyA9IEFycmF5LmZyb20oe2xlbmd0aDogOH0sIChfLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF5ID0gaSArIDE7XG4gICAgICAgICAgICAgICAgY29uc3QgZGF5U2Vzc2lvbiA9IGNsdXN0ZXJTZXNzaW9ucy5maW5kKHMgPT4gcy5kYXlOdW1iZXIgPT09IGRheSk7XG4gICAgICAgICAgICAgICAgaWYgKGRheVNlc3Npb24gJiYgKGRheVNlc3Npb24uc3RhdHVzID09PSAnQ29tcGxldGVkJyB8fCBkYXlTZXNzaW9uLnN0YXR1cyA9PT0gJ0FwcHJvdmVkJykpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB7IHN0YXRlOiAnQ29tcGxldGVkJywgbGFiZWw6IGRheVNlc3Npb24ubmFtZSB8fCBgRGF5ICR7ZGF5fWAgfTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRheVNlc3Npb24gJiYgKGRheVNlc3Npb24uc3RhdHVzID09PSAnSW4gUHJvZ3Jlc3MnIHx8IGRheVNlc3Npb24uc3RhdHVzID09PSAnU3VibWl0dGVkJyB8fCBkYXlTZXNzaW9uLnN0YXR1cyA9PT0gJ1BlbmRpbmcgUmV2aWV3JykpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB7IHN0YXRlOiAnSW4gUHJvZ3Jlc3MnLCBsYWJlbDogZGF5U2Vzc2lvbi5uYW1lIHx8IGBEYXkgJHtkYXl9YCB9O1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZGF5U2Vzc2lvbiAmJiBkYXlTZXNzaW9uLnN0YXR1cyA9PT0gJ1NjaGVkdWxlZCcpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB7IHN0YXRlOiAnU2NoZWR1bGVkJywgbGFiZWw6IGRheVNlc3Npb24ubmFtZSB8fCBgRGF5ICR7ZGF5fWAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgc3RhdGU6ICdQZW5kaW5nJywgbGFiZWw6IGBEYXkgJHtkYXl9YCB9O1xuICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICBjb25zdCBjb21wQ291bnQgPSBkYXlzU3RhdHVzLmZpbHRlcihzID0+IHMuc3RhdGUgPT09ICdDb21wbGV0ZWQnKS5sZW5ndGg7XG4gICAgICAgICAgICAgIGNvbnN0IGluUHJvZ0NvdW50ID0gZGF5c1N0YXR1cy5maWx0ZXIocyA9PiBzLnN0YXRlID09PSAnSW4gUHJvZ3Jlc3MnKS5sZW5ndGg7XG4gICAgICAgICAgICAgIGNvbnN0IHByb2dyZXNzUGN0ID0gTWF0aC5yb3VuZCgoY29tcENvdW50IC8gOCkgKiAxMDApO1xuXG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NsdXN0ZXIuaWR9IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMC84MCBiZy1ncmF5LTUwLzQwIHAtNCBkYXJrOmJvcmRlci1ncmF5LTgwMCBkYXJrOmJnLXdoaXRlL1swLjAyXSBob3Zlcjpib3JkZXItYnJhbmQtMzAwIGRhcms6aG92ZXI6Ym9yZGVyLWJyYW5kLTUwMC8zMCB0cmFuc2l0aW9uXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBsZzp3LTY0IGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc20gdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGVcIj57Y2x1c3Rlci5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjbHVzdGVyLmNvbGxlZ2VOYW1lICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMCBkYXJrOnRleHQtZ3JheS01MDAgdHJ1bmNhdGUgbWF4LXctWzEyMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICZtaWRkb3Q7IHtjbHVzdGVyLmNvbGxlZ2VOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbXQtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBiZy1ncmF5LTIwMCBkYXJrOmJnLWdyYXktNzAwIGgtMS41IHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJyYW5kLTUwMCBoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3Byb2dyZXNzUGN0fSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLTYwMCBkYXJrOnRleHQtYnJhbmQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9ncmVzc1BjdH0lXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGdyaWQgZ3JpZC1jb2xzLTQgc206Z3JpZC1jb2xzLTggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGF5c1N0YXR1cy5tYXAoKGQsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEb25lID0gZC5zdGF0ZSA9PT0gJ0NvbXBsZXRlZCc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0luUHJvZyA9IGQuc3RhdGUgPT09ICdJbiBQcm9ncmVzcyc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1NjaGVkID0gZC5zdGF0ZSA9PT0gJ1NjaGVkdWxlZCc7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YERheSAke2lkeCArIDF9OiAke2Quc3RhdGV9ICgke2QubGFiZWx9KWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0yIHJvdW5kZWQtbGcgYm9yZGVyIHRleHQtY2VudGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWVtZXJhbGQtMjAwIGJnLWVtZXJhbGQtNTAvODAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTkwMC80MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzIwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpc0luUHJvZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItYW1iZXItMjAwIGJnLWFtYmVyLTUwLzgwIHRleHQtYW1iZXItNzAwIGRhcms6Ym9yZGVyLWFtYmVyLTkwMC80MCBkYXJrOmJnLWFtYmVyLTk1MC8yMCBkYXJrOnRleHQtYW1iZXItNDAwIHNoYWRvdy1zbSBhbmltYXRlLXB1bHNlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGlzU2NoZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWJsdWUtMjAwIGJnLWJsdWUtNTAvODAgdGV4dC1ibHVlLTcwMCBkYXJrOmJvcmRlci1ibHVlLTkwMC80MCBkYXJrOmJnLWJsdWUtOTUwLzIwIGRhcms6dGV4dC1ibHVlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLWdyYXktMjAwLzYwIGJnLXdoaXRlIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6YmctZ3JheS04MDAvNDAgdGV4dC1ncmF5LTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEYXkge2lkeCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNEb25lICYmIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0luUHJvZyAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPkFjdGl2ZTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNTY2hlZCAmJiA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0RvbmUgJiYgIWlzSW5Qcm9nICYmICFpc1NjaGVkICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwXCI+JmJ1bGw7PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyIHB5LTYgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICBObyBjbHVzdGVycyBvbmJvYXJkZWQgeWV0LiBDcmVhdGUgYSBjbHVzdGVyIHVuZGVyIHRoZSBDbHVzdGVycyB0YWIgdG8gYmVnaW4gdHJhY2tpbmcgOC1kYXkgcHJvZ3Jlc3MuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICB7LyogUGFuY2hheWF0cyAmIFZpbGxhZ2UgVW5pdHMgVGFibGUgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMTIgeGw6Y29sLXNwYW4tOCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHAtNSBtZDpwLTYgc2hhZG93LXRoZW1lLXhzIGRhcms6Ym9yZGVyLWdyYXktODAwIGRhcms6Ymctd2hpdGUvWzAuMDNdIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtd2hpdGUvOTBcIj5cbiAgICAgICAgICAgICAgICBQYW5jaGF5YXRzICYgVmlsbGFnZSBVbml0c1xuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgIHtwYW5jaGF5YXRzLmxlbmd0aH0gcGFuY2hheWF0cyAmbWlkZG90OyB7dG90YWxWaWxsYWdlc30gdmlsbGFnZXMgYWN0aXZlIHVuZGVyIHtjbHVzdGVyTmFtZX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctNDQgc206dy01NlwiPlxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggcGFuY2hheWF0cy4uLlwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGFuY2hheWF0U2VhcmNofVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYW5jaGF5YXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy10cmFuc3BhcmVudCBwbC05IHByLTMgcHktMS41IHRleHQteHMgdGV4dC1ncmF5LTgwMCBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktNDAwIGZvY3VzOmJvcmRlci1icmFuZC0zMDAgZm9jdXM6b3V0bGluZS1oaWRkZW4gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYnJhbmQtNTAwLzEwIGRhcms6Ym9yZGVyLWdyYXktNzAwIGRhcms6YmctZ3JheS05MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ3BhbmNoYXlhdHMnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctd2hpdGUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgc2hhZG93LXRoZW1lLXhzIGhvdmVyOmJnLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS03MDAgZGFyazpiZy1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3ZlcjpiZy13aGl0ZS81IHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+RGlyZWN0b3J5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGRhcms6Ym9yZGVyLWdyYXktODAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LWZ1bGwgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDxUYWJsZT5cbiAgICAgICAgICAgICAgICA8VGFibGVIZWFkZXI+XG4gICAgICAgICAgICAgICAgICA8VGFibGVSb3c+XG4gICAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgaXNIZWFkZXI+UGFuY2hheWF0IEh1YjwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGlzSGVhZGVyPk1hcHBlZCBWaWxsYWdlczwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICA8VGFibGVDZWxsIGlzSGVhZGVyIGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5BY3RpdmUgU3R1ZGVudHM8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBpc0hlYWRlciBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+QWN0aW9uPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICAgIDwvVGFibGVIZWFkZXI+XG4gICAgICAgICAgICAgICAgPFRhYmxlQm9keT5cbiAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFBhbmNoYXlhdHMubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRQYW5jaGF5YXRzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxUYWJsZVJvd1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgncGFuY2hheWF0cycpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNTAwIHRyYW5zaXRpb24tY29sb3JzIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZ3JvdXAtaG92ZXI6dGV4dC1icmFuZC01MDAgZGFyazp0ZXh0LXdoaXRlLzkwIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCB0cnVuY2F0ZSBtYXgtdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cC52aWxsYWdlcz8ubWFwKCh2KSA9PiB2Lm5hbWUpLmpvaW4oJywgJykgfHwgYCR7cC52aWxsYWdlc0NvdW50IHx8IDB9IHZpbGxhZ2VzYH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3AuYWN0aXZlU3R1ZGVudHMgfHwgMH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFibGVDZWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRhYmxlQ2VsbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGdyb3VwLWhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpncm91cC1ob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGlubGluZS1ibG9ja1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cbiAgICAgICAgICAgICAgICAgICAgICA8L1RhYmxlUm93PlxuICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPFRhYmxlUm93PlxuICAgICAgICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgY29sU3Bhbj17NH0gY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gcGFuY2hheWF0cyBmb3VuZCBtYXRjaGluZyBcIntwYW5jaGF5YXRTZWFyY2ggfHwgY2x1c3Rlck5hbWV9XCIuXG4gICAgICAgICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XG4gICAgICAgICAgICAgICAgICAgIDwvVGFibGVSb3c+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvVGFibGVCb2R5PlxuICAgICAgICAgICAgICA8L1RhYmxlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBPcGVyYXRpb25hbCBRdWljayBMaW5rcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0xMiB4bDpjb2wtc3Bhbi00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgcC01IG1kOnAtNiBzaGFkb3ctdGhlbWUteHMgZGFyazpib3JkZXItZ3JheS04MDAgZGFyazpiZy13aGl0ZS9bMC4wM10gc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBkYXJrOmJvcmRlci1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LXdoaXRlLzkwXCI+XG4gICAgICAgICAgICAgIE9wZXJhdGlvbmFsIE5hdmlnYXRpb25cbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC14cyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuICAgICAgICAgICAgICBEaXJlY3QgYWNjZXNzIHRvIGZpZWxkIHdvcmtmbG93c1xuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgbGFiZWw6ICc4LURheSBBdHRlbmRhbmNlICYgSG9tZXdvcmsnLCB0YWI6ICdhdHRlbmRhbmNlJyBhcyBUYWJUeXBlLCBkZXNjOiAnTG9nIGRhaWx5IG1hcmtzICYgdm9sdW50ZWVyIGF0dGVuZGFuY2UnIH0sXG4gICAgICAgICAgICAgIHsgbGFiZWw6ICdGaW5hbmNlICYgT0NSIEJpbGwgU2Nhbm5pbmcnLCB0YWI6ICdmaW5hbmNlJyBhcyBUYWJUeXBlLCBkZXNjOiAnVmVyaWZ5IHRpY2tldHMsIGZ1ZWwgJiBmb29kIGJpbGxzJyB9LFxuICAgICAgICAgICAgICB7IGxhYmVsOiAnQ3VycmljdWx1bSBQUFQgTW9kdWxlIExpYnJhcnknLCB0YWI6ICdtb2R1bGUtbGlicmFyeScgYXMgVGFiVHlwZSwgZGVzYzogJ1RlYWNoaW5nIHNsaWRlcyAmIHdvcmtzaGVldHMnIH0sXG4gICAgICAgICAgICAgIHsgbGFiZWw6ICdBbmFseXRpY3MgJiBTZW1lc3RlciBSZXBvcnRzJywgdGFiOiAncmVwb3J0cycgYXMgVGFiVHlwZSwgZGVzYzogJ0Rvd25sb2FkIENTViAmIFBERiBjb21wbGV0aW9uIHJlcG9ydHMnIH0sXG4gICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtpdGVtLnRhYn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKGl0ZW0udGFiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBmbGV4IHctZnVsbCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC14bCBwLTMgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzIGJnLWdyYXktNTAvNjAgaG92ZXI6YmctYnJhbmQtNTAvNDAgZGFyazpiZy13aGl0ZS9bMC4wMl0gZGFyazpob3ZlcjpiZy1icmFuZC01MDAvNVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6dGV4dC13aGl0ZS85MCBkYXJrOmdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNDAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj57aXRlbS5kZXNjfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWdyYXktNDAwIGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtNTAwIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1icmFuZC00MDAgdHJhbnNpdGlvbi1jb2xvcnMgbXQtMC41IHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbiJdLCJmaWxlIjoiRDovUHJvamVjdC1NYWluZmlsZXMvQ2xpZW50LVByb2plY3QvVFFJLUVSUC9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3LnRzeCJ9